Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/638542485447397376\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/qwVq9i6uur",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNyO7RIWoAERTuS.png",
      "id_str" : "638542396041633793",
      "id" : 638542396041633793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNyO7RIWoAERTuS.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 701
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 701
      } ],
      "display_url" : "pic.twitter.com\/qwVq9i6uur"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/GjMCjEZzZ7",
      "expanded_url" : "https:\/\/medium.com\/@PresidentObama\/my-visit-to-alaska-touching-down-in-anchorage-beb35f773a62",
      "display_url" : "medium.com\/@PresidentObam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "638542485447397376",
  "text" : "\"I\u2019ll be sharing my experiences with you along the way.\"\n@POTUS previews his trip to Alaska: https:\/\/t.co\/GjMCjEZzZ7 http:\/\/t.co\/qwVq9i6uur",
  "id" : 638542485447397376,
  "created_at" : "2015-09-01 02:42:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/WJw0WUcocl",
      "expanded_url" : "http:\/\/snpy.tv\/1LGEhEw",
      "display_url" : "snpy.tv\/1LGEhEw"
    } ]
  },
  "geo" : { },
  "id_str" : "638537417625071616",
  "text" : "\"Let's go to Alaska!\"\nGo behind the scenes with @POTUS as he previews his trip to the frontlines of climate change. http:\/\/t.co\/WJw0WUcocl",
  "id" : 638537417625071616,
  "created_at" : "2015-09-01 02:22:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arctic",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638529424611254278",
  "text" : "RT @StateDept: .@POTUS: This once distant threat is in the present - the #Arctic is the leading edge of #climatechange \n http:\/\/t.co\/EtGsPk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Arctic",
        "indices" : [ 58, 65 ]
      }, {
        "text" : "climatechange",
        "indices" : [ 89, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/EtGsPkNu5P",
        "expanded_url" : "http:\/\/snpy.tv\/1UiGJIA",
        "display_url" : "snpy.tv\/1UiGJIA"
      } ]
    },
    "geo" : { },
    "id_str" : "638522233158176769",
    "text" : ".@POTUS: This once distant threat is in the present - the #Arctic is the leading edge of #climatechange \n http:\/\/t.co\/EtGsPkNu5P",
    "id" : 638522233158176769,
    "created_at" : "2015-09-01 01:22:18 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 638529424611254278,
  "created_at" : "2015-09-01 01:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638522293891780609",
  "text" : "\"On this issue, of all issues, there is such a thing as being too late. And that moment is almost upon us.\" \u2014@POTUS #ActOnClimate",
  "id" : 638522293891780609,
  "created_at" : "2015-09-01 01:22:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/638521414555959296\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/fcsadSmT5U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNx7z-TWoAAV2Q3.jpg",
      "id_str" : "638521380007485440",
      "id" : 638521380007485440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNx7z-TWoAAV2Q3.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      } ],
      "display_url" : "pic.twitter.com\/fcsadSmT5U"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638521414555959296",
  "text" : "\"We know that human activity is changing the climate. That is beyond dispute.\" \u2014@POTUS #ActOnClimate http:\/\/t.co\/fcsadSmT5U",
  "id" : 638521414555959296,
  "created_at" : "2015-09-01 01:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638520841609826304",
  "text" : "\"This year...has to be the year that the world finally reaches an agreement to protect the one planet we\u2019ve got while we still can.\" \u2014@POTUS",
  "id" : 638520841609826304,
  "created_at" : "2015-09-01 01:16:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638520023984812032",
  "text" : "\"America recognizes our role in creating this problem and embraces our responsibility to help solve it\" \u2014@POTUS on the need to #ActOnClimate",
  "id" : 638520023984812032,
  "created_at" : "2015-09-01 01:13:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/638519455199444992\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/rLB8eDOY7L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNx5-6-WsAEUuOx.jpg",
      "id_str" : "638519369069408257",
      "id" : 638519369069408257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNx5-6-WsAEUuOx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1202
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rLB8eDOY7L"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638519455199444992",
  "text" : "Sea levels are \"projected to rise another 1 to 4 feet this century.\" \u2014@POTUS in Alaska #ActOnClimate http:\/\/t.co\/rLB8eDOY7L",
  "id" : 638519455199444992,
  "created_at" : "2015-09-01 01:11:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/638519103020531712\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/fCFU78O8ju",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNx5sM4WIAAUC3m.jpg",
      "id_str" : "638519047458529280",
      "id" : 638519047458529280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNx5sM4WIAAUC3m.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fCFU78O8ju"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638519103020531712",
  "text" : "\"Climate change is no longer some far-off problem. It is happening here and now.\" \u2014@POTUS in Alaska #ActOnClimate http:\/\/t.co\/fCFU78O8ju",
  "id" : 638519103020531712,
  "created_at" : "2015-09-01 01:09:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/638517508929155072\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/FzxmUWpiL4",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CNx4RGqWIAED-wr.png",
      "id_str" : "638517482421100545",
      "id" : 638517482421100545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CNx4RGqWIAED-wr.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FzxmUWpiL4"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638517508929155072",
  "text" : "\u201CArctic temperatures are rising about twice as fast as the global average.\u201D \u2014@POTUS #ActOnClimate http:\/\/t.co\/FzxmUWpiL4",
  "id" : 638517508929155072,
  "created_at" : "2015-09-01 01:03:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638517093797888002",
  "text" : "\"The science is stark, it is sharpening, and it proves that this once-distant threat is now very much in the present.\" \u2014@POTUS #ActOnClimate",
  "id" : 638517093797888002,
  "created_at" : "2015-09-01 01:01:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/638516712422383617\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/rCCnYSUaBB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNx3aWbWIAArdTB.jpg",
      "id_str" : "638516541760348160",
      "id" : 638516541760348160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNx3aWbWIAArdTB.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/rCCnYSUaBB"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 51, 64 ]
    }, {
      "text" : "GLACIER",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/9YIoJPVfEA",
      "expanded_url" : "http:\/\/go.wh.gov\/5ACwSo",
      "display_url" : "go.wh.gov\/5ACwSo"
    } ]
  },
  "geo" : { },
  "id_str" : "638516712422383617",
  "text" : "Watch live: @POTUS speaks in Alaska on the need to #ActOnClimate \u2192 http:\/\/t.co\/9YIoJPVfEA #GLACIER http:\/\/t.co\/rCCnYSUaBB",
  "id" : 638516712422383617,
  "created_at" : "2015-09-01 01:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 49, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/9YIoJPVfEA",
      "expanded_url" : "http:\/\/go.wh.gov\/5ACwSo",
      "display_url" : "go.wh.gov\/5ACwSo"
    } ]
  },
  "geo" : { },
  "id_str" : "638515336246116352",
  "text" : "Starting soon: Watch @POTUS speak on the need to #ActOnClimate at the GLACIER conference in Alaska \u2192 http:\/\/t.co\/9YIoJPVfEA",
  "id" : 638515336246116352,
  "created_at" : "2015-09-01 00:54:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/638472572842156032\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/qp2ES9um99",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNxM32PU8AAWEQz.jpg",
      "id_str" : "638469769516085248",
      "id" : 638469769516085248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNxM32PU8AAWEQz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qp2ES9um99"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/J8KIPD0vMd",
      "expanded_url" : "https:\/\/instagram.com\/p\/7EB3nkQirZ\/",
      "display_url" : "instagram.com\/p\/7EB3nkQirZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "638472572842156032",
  "text" : ".@POTUS just arrived in Alaska and posted his first photo on Instagram \u2192 https:\/\/t.co\/J8KIPD0vMd #ActOnClimate http:\/\/t.co\/qp2ES9um99",
  "id" : 638472572842156032,
  "created_at" : "2015-08-31 22:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/4Vgqx2sD5D",
      "expanded_url" : "http:\/\/go.nasa.gov\/1JxyP66",
      "display_url" : "go.nasa.gov\/1JxyP66"
    } ]
  },
  "geo" : { },
  "id_str" : "638448544815427586",
  "text" : "RT @NASA: See America\u2019s tallest peak, now named Mount Denali, from the unique vantage point of space: http:\/\/t.co\/4Vgqx2sD5D http:\/\/t.co\/Vs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/638447855653548032\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/VsdAdlScEy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNw48SPW8AEZHaj.jpg",
        "id_str" : "638447855519330305",
        "id" : 638447855519330305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNw48SPW8AEZHaj.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/VsdAdlScEy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/4Vgqx2sD5D",
        "expanded_url" : "http:\/\/go.nasa.gov\/1JxyP66",
        "display_url" : "go.nasa.gov\/1JxyP66"
      } ]
    },
    "geo" : { },
    "id_str" : "638447855653548032",
    "text" : "See America\u2019s tallest peak, now named Mount Denali, from the unique vantage point of space: http:\/\/t.co\/4Vgqx2sD5D http:\/\/t.co\/VsdAdlScEy",
    "id" : 638447855653548032,
    "created_at" : "2015-08-31 20:26:45 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 638448544815427586,
  "created_at" : "2015-08-31 20:29:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Patrick Murphy",
      "screen_name" : "RepMurphyFL",
      "indices" : [ 3, 15 ],
      "id_str" : "1128781184",
      "id" : 1128781184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638439315417243648",
  "text" : "RT @RepMurphyFL: I'm supporting the nuclear deal with Iran as the best available option to stop Iran from obtaining nuclear weapons. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/tD8TIAU58U",
        "expanded_url" : "http:\/\/patrickmurphy.house.gov\/news\/documentsingle.aspx?DocumentID=398629",
        "display_url" : "patrickmurphy.house.gov\/news\/documents\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638432007316443136",
    "text" : "I'm supporting the nuclear deal with Iran as the best available option to stop Iran from obtaining nuclear weapons. http:\/\/t.co\/tD8TIAU58U",
    "id" : 638432007316443136,
    "created_at" : "2015-08-31 19:23:46 +0000",
    "user" : {
      "name" : "Rep. Patrick Murphy",
      "screen_name" : "RepMurphyFL",
      "protected" : false,
      "id_str" : "1128781184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574354842677706752\/NAzlBdmr_normal.jpeg",
      "id" : 1128781184,
      "verified" : true
    }
  },
  "id" : 638439315417243648,
  "created_at" : "2015-08-31 19:52:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/638416490623053824\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/8TrzLWnRzU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNwcHomVEAAdDqQ.jpg",
      "id_str" : "638416164662611968",
      "id" : 638416164662611968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNwcHomVEAAdDqQ.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/8TrzLWnRzU"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/XkhBK1W6w2",
      "expanded_url" : "http:\/\/go.wh.gov\/a1HTrE",
      "display_url" : "go.wh.gov\/a1HTrE"
    } ]
  },
  "geo" : { },
  "id_str" : "638416490623053824",
  "text" : "As @POTUS heads to Alaska, take a look back at why it's so important to protect: http:\/\/t.co\/XkhBK1W6w2 #ActOnClimate http:\/\/t.co\/8TrzLWnRzU",
  "id" : 638416490623053824,
  "created_at" : "2015-08-31 18:22:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "indices" : [ 3, 13 ],
      "id_str" : "1707321486",
      "id" : 1707321486
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 105, 109 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/r1mSDGpGoO",
      "expanded_url" : "http:\/\/cnn.it\/1EsIH23",
      "display_url" : "cnn.it\/1EsIH23"
    } ]
  },
  "geo" : { },
  "id_str" : "638409402253463552",
  "text" : "RT @madeleine: #IranDeal is a bold stroke of diplomacy, and an opportunity we must not waste. My oped on @cnn: http:\/\/t.co\/r1mSDGpGoO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 90, 94 ],
        "id_str" : "759251",
        "id" : 759251
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/r1mSDGpGoO",
        "expanded_url" : "http:\/\/cnn.it\/1EsIH23",
        "display_url" : "cnn.it\/1EsIH23"
      } ]
    },
    "geo" : { },
    "id_str" : "638318117404430336",
    "text" : "#IranDeal is a bold stroke of diplomacy, and an opportunity we must not waste. My oped on @cnn: http:\/\/t.co\/r1mSDGpGoO",
    "id" : 638318117404430336,
    "created_at" : "2015-08-31 11:51:13 +0000",
    "user" : {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "protected" : false,
      "id_str" : "1707321486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482147628650856448\/oTqqAjkX_normal.jpeg",
      "id" : 1707321486,
      "verified" : true
    }
  },
  "id" : 638409402253463552,
  "created_at" : "2015-08-31 17:53:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638404585158279168",
  "text" : "RT @POTUS: Today we\u2019re returning Mount McKinley to its native name - Denali, a step to reflect the heritage of Alaska Natives. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/638403631306248192\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/WyzQImKymX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNwQuCvWEAAlThQ.jpg",
        "id_str" : "638403630375243776",
        "id" : 638403630375243776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNwQuCvWEAAlThQ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/WyzQImKymX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "638403631306248192",
    "text" : "Today we\u2019re returning Mount McKinley to its native name - Denali, a step to reflect the heritage of Alaska Natives. http:\/\/t.co\/WyzQImKymX",
    "id" : 638403631306248192,
    "created_at" : "2015-08-31 17:31:01 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 638404585158279168,
  "created_at" : "2015-08-31 17:34:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Joe Kennedy III",
      "screen_name" : "RepJoeKennedy",
      "indices" : [ 3, 17 ],
      "id_str" : "1055907624",
      "id" : 1055907624
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638401398758055939",
  "text" : "RT @RepJoeKennedy: #IranDeal is not perfect or risk-free. But it is best means we have to stop a nuclear Iran. Read my full statement: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8FY3A3TtW7",
        "expanded_url" : "http:\/\/kennedy.house.gov\/media\/press-releases\/kennedy-statement-on-iran-nuclear-deal",
        "display_url" : "kennedy.house.gov\/media\/press-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "638397956450877440",
    "text" : "#IranDeal is not perfect or risk-free. But it is best means we have to stop a nuclear Iran. Read my full statement: http:\/\/t.co\/8FY3A3TtW7",
    "id" : 638397956450877440,
    "created_at" : "2015-08-31 17:08:28 +0000",
    "user" : {
      "name" : "Rep. Joe Kennedy III",
      "screen_name" : "RepJoeKennedy",
      "protected" : false,
      "id_str" : "1055907624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775775331605241856\/mWMJIZHq_normal.jpg",
      "id" : 1055907624,
      "verified" : true
    }
  },
  "id" : 638401398758055939,
  "created_at" : "2015-08-31 17:22:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/638384231283093504\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/aqtYvjmm8A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNv_EOEWsAAgBAA.jpg",
      "id_str" : "638384220163977216",
      "id" : 638384220163977216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNv_EOEWsAAgBAA.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/aqtYvjmm8A"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/eAVC9RAQbv",
      "expanded_url" : "http:\/\/go.wh.gov\/Alaska",
      "display_url" : "go.wh.gov\/Alaska"
    } ]
  },
  "geo" : { },
  "id_str" : "638384231283093504",
  "text" : "Follow along as @POTUS heads to the frontlines of our fight against climate change in Alaska \u2192 http:\/\/t.co\/eAVC9RAQbv http:\/\/t.co\/aqtYvjmm8A",
  "id" : 638384231283093504,
  "created_at" : "2015-08-31 16:13:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "It's On Us",
      "screen_name" : "ItsOnUs",
      "indices" : [ 3, 11 ],
      "id_str" : "2840712124",
      "id" : 2840712124
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/n18cRwN3k3",
      "expanded_url" : "http:\/\/itsonus.org\/#pledge",
      "display_url" : "itsonus.org\/#pledge"
    } ]
  },
  "geo" : { },
  "id_str" : "638342625985196032",
  "text" : "RT @ItsOnUs: .@POTUS took the #ItsOnUs pledge. Have you? Pledge to help keep your community safe at http:\/\/t.co\/n18cRwN3k3. http:\/\/t.co\/YJq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsOnUs\/status\/638126548529319937\/video\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/YJq63BDjiE",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/638126510889672704\/pu\/img\/5PnlIjflZ5jjwcjr.jpg",
        "id_str" : "638126510889672704",
        "id" : 638126510889672704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/638126510889672704\/pu\/img\/5PnlIjflZ5jjwcjr.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/YJq63BDjiE"
      } ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 17, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/n18cRwN3k3",
        "expanded_url" : "http:\/\/itsonus.org\/#pledge",
        "display_url" : "itsonus.org\/#pledge"
      } ]
    },
    "geo" : { },
    "id_str" : "638126548529319937",
    "text" : ".@POTUS took the #ItsOnUs pledge. Have you? Pledge to help keep your community safe at http:\/\/t.co\/n18cRwN3k3. http:\/\/t.co\/YJq63BDjiE",
    "id" : 638126548529319937,
    "created_at" : "2015-08-30 23:09:59 +0000",
    "user" : {
      "name" : "It's On Us",
      "screen_name" : "ItsOnUs",
      "protected" : false,
      "id_str" : "2840712124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666281106770173952\/tPVjIzos_normal.png",
      "id" : 2840712124,
      "verified" : false
    }
  },
  "id" : 638342625985196032,
  "created_at" : "2015-08-31 13:28:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eD80BNJKTg",
      "expanded_url" : "http:\/\/on.doi.gov\/1KVKg5s",
      "display_url" : "on.doi.gov\/1KVKg5s"
    } ]
  },
  "geo" : { },
  "id_str" : "638112661096538112",
  "text" : "RT @SecretaryJewell: Generations of Alaskans, Alaska Natives hold Denali sacred. Time to honor its original name.SJ http:\/\/t.co\/eD80BNJKTg \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/638099426624602112\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/mS3kFiLoST",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNr8Cr9WwAAXJvu.jpg",
        "id_str" : "638099420316352512",
        "id" : 638099420316352512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNr8Cr9WwAAXJvu.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mS3kFiLoST"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/eD80BNJKTg",
        "expanded_url" : "http:\/\/on.doi.gov\/1KVKg5s",
        "display_url" : "on.doi.gov\/1KVKg5s"
      } ]
    },
    "geo" : { },
    "id_str" : "638099426624602112",
    "text" : "Generations of Alaskans, Alaska Natives hold Denali sacred. Time to honor its original name.SJ http:\/\/t.co\/eD80BNJKTg http:\/\/t.co\/mS3kFiLoST",
    "id" : 638099426624602112,
    "created_at" : "2015-08-30 21:22:13 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 638112661096538112,
  "created_at" : "2015-08-30 22:14:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/VSN2vl7yZo",
      "expanded_url" : "http:\/\/on.doi.gov\/1KVKg5s",
      "display_url" : "on.doi.gov\/1KVKg5s"
    } ]
  },
  "geo" : { },
  "id_str" : "638109576466964481",
  "text" : "RT @Interior: The mountain has spoken \uD83D\uDDFB\nMt McKinley officially renamed Denali: http:\/\/t.co\/VSN2vl7yZo \nCongrats, Alaska! http:\/\/t.co\/ZdRTJ2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/638095591860502528\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/ZdRTJ2PEHL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNr4jzgXAAAUI9Q.jpg",
        "id_str" : "638095591231389696",
        "id" : 638095591231389696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNr4jzgXAAAUI9Q.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ZdRTJ2PEHL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/VSN2vl7yZo",
        "expanded_url" : "http:\/\/on.doi.gov\/1KVKg5s",
        "display_url" : "on.doi.gov\/1KVKg5s"
      } ]
    },
    "geo" : { },
    "id_str" : "638095591860502528",
    "text" : "The mountain has spoken \uD83D\uDDFB\nMt McKinley officially renamed Denali: http:\/\/t.co\/VSN2vl7yZo \nCongrats, Alaska! http:\/\/t.co\/ZdRTJ2PEHL",
    "id" : 638095591860502528,
    "created_at" : "2015-08-30 21:06:58 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 638109576466964481,
  "created_at" : "2015-08-30 22:02:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/VET7C1ByTd",
      "expanded_url" : "http:\/\/go.wh.gov\/PyNXga",
      "display_url" : "go.wh.gov\/PyNXga"
    } ]
  },
  "geo" : { },
  "id_str" : "638093875119173637",
  "text" : "\"As long as I\u2019m President, America will lead the world to meet the threat of climate change.\" \u2014@POTUS: http:\/\/t.co\/VET7C1ByTd #ActOnClimate",
  "id" : 638093875119173637,
  "created_at" : "2015-08-30 21:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/9mBzLHbDAZ",
      "expanded_url" : "http:\/\/WhiteHouse.gov\/Alaska",
      "display_url" : "WhiteHouse.gov\/Alaska"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/VET7C1jY1F",
      "expanded_url" : "http:\/\/go.wh.gov\/PyNXga",
      "display_url" : "go.wh.gov\/PyNXga"
    } ]
  },
  "geo" : { },
  "id_str" : "638009512390184960",
  "text" : "\"We\u2019re going to offer unique and engaging ways for you to join me on this trip all week at http:\/\/t.co\/9mBzLHbDAZ.\" http:\/\/t.co\/VET7C1jY1F",
  "id" : 638009512390184960,
  "created_at" : "2015-08-30 15:24:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Katrina10",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/h4PFK32oUi",
      "expanded_url" : "http:\/\/go.wh.gov\/ms6UWx",
      "display_url" : "go.wh.gov\/ms6UWx"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/SFV2BvhLGF",
      "expanded_url" : "http:\/\/snpy.tv\/1UdImHF",
      "display_url" : "snpy.tv\/1UdImHF"
    } ]
  },
  "geo" : { },
  "id_str" : "637791894232170496",
  "text" : "\"The progress that you have made is remarkable.\" \nWatch @POTUS in New Orleans for #Katrina10: http:\/\/t.co\/h4PFK32oUi http:\/\/t.co\/SFV2BvhLGF",
  "id" : 637791894232170496,
  "created_at" : "2015-08-30 01:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637762280399204356\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/L1cO0Wajvs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNnJYiwWsAA0K5Z.jpg",
      "id_str" : "637762245733298176",
      "id" : 637762245733298176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNnJYiwWsAA0K5Z.jpg",
      "sizes" : [ {
        "h" : 1665,
        "resize" : "fit",
        "w" : 2496
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/L1cO0Wajvs"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637762280399204356\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/L1cO0Wajvs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNnJYeZW8AAQ6JS.jpg",
      "id_str" : "637762244563103744",
      "id" : 637762244563103744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNnJYeZW8AAQ6JS.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2744
      }, {
        "h" : 697,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/L1cO0Wajvs"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637762280399204356\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/L1cO0Wajvs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNnJYdxWwAA6lll.jpg",
      "id_str" : "637762244395319296",
      "id" : 637762244395319296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNnJYdxWwAA6lll.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/L1cO0Wajvs"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637762280399204356\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/L1cO0Wajvs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNnJYayXAAU4g_I.jpg",
      "id_str" : "637762243594223621",
      "id" : 637762243594223621,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNnJYayXAAU4g_I.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/L1cO0Wajvs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/a2twvZ2WST",
      "expanded_url" : "http:\/\/go.wh.gov\/CommunityMap",
      "display_url" : "go.wh.gov\/CommunityMap"
    } ]
  },
  "geo" : { },
  "id_str" : "637762280399204356",
  "text" : "\"The recovery has been an example of what\u2019s possible when government works together.\" \u2014@POTUS: http:\/\/t.co\/a2twvZ2WST http:\/\/t.co\/L1cO0Wajvs",
  "id" : 637762280399204356,
  "created_at" : "2015-08-29 23:02:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637739989204365312",
  "text" : "RT @POTUS: In Treme, I was inspired by the progress &amp; people 10 years after Katrina. It gives us hope, but our work isn't done. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/637733790090199040\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/LDqsARhnZt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNmvfxTVEAQRZLx.jpg",
        "id_str" : "637733782594850820",
        "id" : 637733782594850820,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNmvfxTVEAQRZLx.jpg",
        "sizes" : [ {
          "h" : 687,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LDqsARhnZt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637733790090199040",
    "text" : "In Treme, I was inspired by the progress &amp; people 10 years after Katrina. It gives us hope, but our work isn't done. http:\/\/t.co\/LDqsARhnZt",
    "id" : 637733790090199040,
    "created_at" : "2015-08-29 21:09:18 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 637739989204365312,
  "created_at" : "2015-08-29 21:33:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/VET7C1ByTd",
      "expanded_url" : "http:\/\/go.wh.gov\/PyNXga",
      "display_url" : "go.wh.gov\/PyNXga"
    } ]
  },
  "geo" : { },
  "id_str" : "637716431585472512",
  "text" : "\"If we do nothing, Alaskan temperatures are projected to rise between 6 and 12 degrees by the end of the century.\" http:\/\/t.co\/VET7C1ByTd",
  "id" : 637716431585472512,
  "created_at" : "2015-08-29 20:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637713583820943360\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/w1XQP9XSiw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNmdH8-UYAAjgAB.jpg",
      "id_str" : "637713582201790464",
      "id" : 637713582201790464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNmdH8-UYAAjgAB.jpg",
      "sizes" : [ {
        "h" : 703,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2985
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/w1XQP9XSiw"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637713583820943360\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/w1XQP9XSiw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNmdHW0VEAAdOEB.jpg",
      "id_str" : "637713571959345152",
      "id" : 637713571959345152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNmdHW0VEAAdOEB.jpg",
      "sizes" : [ {
        "h" : 431,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2671
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/w1XQP9XSiw"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637713583820943360\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/w1XQP9XSiw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNmdGyqVAAAPOKY.jpg",
      "id_str" : "637713562253721600",
      "id" : 637713562253721600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNmdGyqVAAAPOKY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/w1XQP9XSiw"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637713583820943360\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/w1XQP9XSiw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNmdHedUwAAkKBs.jpg",
      "id_str" : "637713574010339328",
      "id" : 637713574010339328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNmdHedUwAAkKBs.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/w1XQP9XSiw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/zcyA0dGv4a",
      "expanded_url" : "http:\/\/go.wh.gov\/Katrina10",
      "display_url" : "go.wh.gov\/Katrina10"
    } ]
  },
  "geo" : { },
  "id_str" : "637713583820943360",
  "text" : "\"Everybody adds their culture and their flavor into this city\u2019s gumbo\" \u2014@POTUS on New Orleans: http:\/\/t.co\/zcyA0dGv4a http:\/\/t.co\/w1XQP9XSiw",
  "id" : 637713583820943360,
  "created_at" : "2015-08-29 19:49:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/VET7C1ByTd",
      "expanded_url" : "http:\/\/go.wh.gov\/PyNXga",
      "display_url" : "go.wh.gov\/PyNXga"
    } ]
  },
  "geo" : { },
  "id_str" : "637686227165011968",
  "text" : "\"Alaska\u2019s glaciers are melting faster\u2026threatening tourism and adding to rising seas.\" \u2014@POTUS: http:\/\/t.co\/VET7C1ByTd #ActOnClimate",
  "id" : 637686227165011968,
  "created_at" : "2015-08-29 18:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/VET7C1jY1F",
      "expanded_url" : "http:\/\/go.wh.gov\/PyNXga",
      "display_url" : "go.wh.gov\/PyNXga"
    } ]
  },
  "geo" : { },
  "id_str" : "637655388943466496",
  "text" : "Watch President Obama's weekly address on his upcoming trip to Alaska and steps to #ActOnClimate: http:\/\/t.co\/VET7C1jY1F",
  "id" : 637655388943466496,
  "created_at" : "2015-08-29 15:57:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637424249796456448\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/RKkQ8pXb66",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNiV5hCWsAAwGs-.jpg",
      "id_str" : "637424162626252800",
      "id" : 637424162626252800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNiV5hCWsAAwGs-.jpg",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1060,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RKkQ8pXb66"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/dW0u3E1bqs",
      "expanded_url" : "http:\/\/go.wh.gov\/3yqEvS",
      "display_url" : "go.wh.gov\/3yqEvS"
    } ]
  },
  "geo" : { },
  "id_str" : "637424249796456448",
  "text" : "It's the 52nd anniversary of the March on Washington. Read @POTUS's remarks 2 years ago today: http:\/\/t.co\/dW0u3E1bqs http:\/\/t.co\/RKkQ8pXb66",
  "id" : 637424249796456448,
  "created_at" : "2015-08-29 00:39:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637341513207279616",
  "text" : "RT @TheIranDeal: \"The friendship, the love between the Israeli people and the American people...that's not going anywhere. That's there.\" \u2014\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 122, 128 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JFedTalk",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637341410933534721",
    "text" : "\"The friendship, the love between the Israeli people and the American people...that's not going anywhere. That's there.\" \u2014@POTUS #JFedTalk",
    "id" : 637341410933534721,
    "created_at" : "2015-08-28 19:10:08 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 637341513207279616,
  "created_at" : "2015-08-28 19:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Jewish Feds of NA",
      "screen_name" : "jfederations",
      "indices" : [ 51, 64 ],
      "id_str" : "119421760",
      "id" : 119421760
    }, {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 70, 79 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 123, 135 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 17, 26 ]
    }, {
      "text" : "JFedTalk",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637340731401740289",
  "text" : "Questions on the #IranDeal talk between @POTUS and @JFederations?\nAsk @Rhodes44 using #JFedTalk.\nHe'll answer a bunch from @TheIranDeal.",
  "id" : 637340731401740289,
  "created_at" : "2015-08-28 19:07:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637340143888781312",
  "text" : "\"The fact is this is our best way to make sure Iran does not get a nuclear weapon. That should be our number one priority\" \u2014@POTUS #IranDeal",
  "id" : 637340143888781312,
  "created_at" : "2015-08-28 19:05:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637337717374865409",
  "text" : "RT @TheIranDeal: \"If we determine that Iran has violated this agreement we are in a position to reimpose all of the multilateral sanctions\"\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 124, 130 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637337637049757696",
    "text" : "\"If we determine that Iran has violated this agreement we are in a position to reimpose all of the multilateral sanctions\" \u2014@POTUS #IranDeal",
    "id" : 637337637049757696,
    "created_at" : "2015-08-28 18:55:08 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 637337717374865409,
  "created_at" : "2015-08-28 18:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637336880699285504",
  "text" : "\"We're still going to have all the tools in our toolbox to go after nefarious activities by Iran in the region.\" \u2014@POTUS on the #IranDeal",
  "id" : 637336880699285504,
  "created_at" : "2015-08-28 18:52:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637336648666251264",
  "text" : "\"Nothing in this agreement prevents us from continuing to push back forcefully against terrorist activity.\" \u2014@POTUS on the #IranDeal",
  "id" : 637336648666251264,
  "created_at" : "2015-08-28 18:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637334713045250048",
  "text" : "RT @TheIranDeal: Q: \"Will America continue to help Israel maintain it's strategic and qualitative military edge in the region?\"\n@POTUS: \"Ye\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 111, 117 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JFedTalk",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637334576491180032",
    "text" : "Q: \"Will America continue to help Israel maintain it's strategic and qualitative military edge in the region?\"\n@POTUS: \"Yes.\"\n#JFedTalk",
    "id" : 637334576491180032,
    "created_at" : "2015-08-28 18:42:58 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 637334713045250048,
  "created_at" : "2015-08-28 18:43:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/637328618415374336\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/1W1tiqFi1O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNg--_AUwAAMK6g.jpg",
      "id_str" : "637328599058530304",
      "id" : 637328599058530304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNg--_AUwAAMK6g.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1W1tiqFi1O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637328618415374336",
  "text" : "\"This deal blocks every way, every pathway that Iran might take in order to obtain a nuclear weapon.\" \u2014@POTUS http:\/\/t.co\/1W1tiqFi1O",
  "id" : 637328618415374336,
  "created_at" : "2015-08-28 18:19:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Jewish Feds of NA",
      "screen_name" : "jfederations",
      "indices" : [ 59, 72 ],
      "id_str" : "119421760",
      "id" : 119421760
    }, {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 107, 116 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "JFedTalk",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637327545256558592",
  "text" : "RT @TheIranDeal: After @POTUS discusses the #IranDeal with @JFederations:\nAsk your Qs on the #JFedTalk for @Rhodes44.\nHe'll answer a bunch \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Jewish Feds of NA",
        "screen_name" : "jfederations",
        "indices" : [ 42, 55 ],
        "id_str" : "119421760",
        "id" : 119421760
      }, {
        "name" : "Ben Rhodes",
        "screen_name" : "rhodes44",
        "indices" : [ 90, 99 ],
        "id_str" : "249722522",
        "id" : 249722522
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 27, 36 ]
      }, {
        "text" : "JFedTalk",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637325476831326208",
    "text" : "After @POTUS discusses the #IranDeal with @JFederations:\nAsk your Qs on the #JFedTalk for @Rhodes44.\nHe'll answer a bunch here.",
    "id" : 637325476831326208,
    "created_at" : "2015-08-28 18:06:49 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 637327545256558592,
  "created_at" : "2015-08-28 18:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Jewish Feds of NA",
      "screen_name" : "jfederations",
      "indices" : [ 56, 69 ],
      "id_str" : "119421760",
      "id" : 119421760
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "JFedTalk",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/5zTo4ZMtJr",
      "expanded_url" : "http:\/\/go.wh.gov\/JFedTalk",
      "display_url" : "go.wh.gov\/JFedTalk"
    } ]
  },
  "geo" : { },
  "id_str" : "637327038496423936",
  "text" : "RT @WHLive: Watch at 2:10pm ET as @POTUS sits down with @JFederations to answer questions on the #IranDeal: http:\/\/t.co\/5zTo4ZMtJr #JFedTalk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 22, 28 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Jewish Feds of NA",
        "screen_name" : "jfederations",
        "indices" : [ 44, 57 ],
        "id_str" : "119421760",
        "id" : 119421760
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 85, 94 ]
      }, {
        "text" : "JFedTalk",
        "indices" : [ 119, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/5zTo4ZMtJr",
        "expanded_url" : "http:\/\/go.wh.gov\/JFedTalk",
        "display_url" : "go.wh.gov\/JFedTalk"
      } ]
    },
    "geo" : { },
    "id_str" : "637323887169040384",
    "text" : "Watch at 2:10pm ET as @POTUS sits down with @JFederations to answer questions on the #IranDeal: http:\/\/t.co\/5zTo4ZMtJr #JFedTalk",
    "id" : 637323887169040384,
    "created_at" : "2015-08-28 18:00:30 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 637327038496423936,
  "created_at" : "2015-08-28 18:13:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jewish Feds of NA",
      "screen_name" : "jfederations",
      "indices" : [ 49, 62 ],
      "id_str" : "119421760",
      "id" : 119421760
    }, {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 64, 73 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 91, 103 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/637314505932935168\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/t7zwBgHvGS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNgx-KlWsAAVXfB.jpg",
      "id_str" : "637314291335606272",
      "id" : 637314291335606272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNgx-KlWsAAVXfB.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/t7zwBgHvGS"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637314505932935168",
  "text" : "Questions on the President's #IranDeal talk with @JFederations?\n@Rhodes44 will answer from @TheIranDeal afterward. http:\/\/t.co\/t7zwBgHvGS",
  "id" : 637314505932935168,
  "created_at" : "2015-08-28 17:23:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Jewish Feds of NA",
      "screen_name" : "jfederations",
      "indices" : [ 53, 66 ],
      "id_str" : "119421760",
      "id" : 119421760
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JFedTalk",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/73ziFUUVC6",
      "expanded_url" : "http:\/\/go.wh.gov\/JFedTalk",
      "display_url" : "go.wh.gov\/JFedTalk"
    } ]
  },
  "geo" : { },
  "id_str" : "637308440164073472",
  "text" : "RT @TheIranDeal: Join @POTUS for a conversation with @jfederations today at 2:10pm ET \u2192 http:\/\/t.co\/73ziFUUVC6 #JFedTalk http:\/\/t.co\/78FDI3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 5, 11 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Jewish Feds of NA",
        "screen_name" : "jfederations",
        "indices" : [ 36, 49 ],
        "id_str" : "119421760",
        "id" : 119421760
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/637302040813633536\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/78FDI3nXWl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNgmr4EVEAAfJmV.jpg",
        "id_str" : "637301882499698688",
        "id" : 637301882499698688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNgmr4EVEAAfJmV.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/78FDI3nXWl"
      } ],
      "hashtags" : [ {
        "text" : "JFedTalk",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/73ziFUUVC6",
        "expanded_url" : "http:\/\/go.wh.gov\/JFedTalk",
        "display_url" : "go.wh.gov\/JFedTalk"
      } ]
    },
    "geo" : { },
    "id_str" : "637302040813633536",
    "text" : "Join @POTUS for a conversation with @jfederations today at 2:10pm ET \u2192 http:\/\/t.co\/73ziFUUVC6 #JFedTalk http:\/\/t.co\/78FDI3nXWl",
    "id" : 637302040813633536,
    "created_at" : "2015-08-28 16:33:41 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 637308440164073472,
  "created_at" : "2015-08-28 16:59:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/oOSPo38DRP",
      "expanded_url" : "http:\/\/snpy.tv\/1ImocyZ",
      "display_url" : "snpy.tv\/1ImocyZ"
    } ]
  },
  "geo" : { },
  "id_str" : "637267178778193921",
  "text" : "\"You know the sun comes out after every storm.\" \u2014@POTUS on the progress since Katrina and the work still ahead: http:\/\/t.co\/oOSPo38DRP",
  "id" : 637267178778193921,
  "created_at" : "2015-08-28 14:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Katrina10",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/UzGUEogg7N",
      "expanded_url" : "http:\/\/snpy.tv\/1Vf6Jlj",
      "display_url" : "snpy.tv\/1Vf6Jlj"
    } ]
  },
  "geo" : { },
  "id_str" : "637074687055392768",
  "text" : "Watch @POTUS tell the stories of how the people of New Orleans rebuilt after Hurricane Katrina. #Katrina10 http:\/\/t.co\/UzGUEogg7N",
  "id" : 637074687055392768,
  "created_at" : "2015-08-28 01:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Katrina10",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/zcyA0doTFA",
      "expanded_url" : "http:\/\/go.wh.gov\/Katrina10",
      "display_url" : "go.wh.gov\/Katrina10"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ILtATtS4Ws",
      "expanded_url" : "http:\/\/snpy.tv\/1JzCfC4",
      "display_url" : "snpy.tv\/1JzCfC4"
    } ]
  },
  "geo" : { },
  "id_str" : "637052044948340736",
  "text" : "\"You inspire me. Your efforts inspire me.\" \u2014@POTUS to New Orleans: http:\/\/t.co\/zcyA0doTFA #Katrina10 http:\/\/t.co\/ILtATtS4Ws",
  "id" : 637052044948340736,
  "created_at" : "2015-08-28 00:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Katrina10",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637016475262447616",
  "text" : "\"If we stay focused on that common purpose...we'll leave behind a city and a nation that's worthy of generations to come\" \u2014@POTUS #Katrina10",
  "id" : 637016475262447616,
  "created_at" : "2015-08-27 21:38:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637014780625055744",
  "text" : "RT @WHLive: \"Making our communities more resilient is going to be increasingly important as we see more extreme weather events.\" \u2014@POTUS #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 118, 124 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "637013563840659457",
    "text" : "\"Making our communities more resilient is going to be increasingly important as we see more extreme weather events.\" \u2014@POTUS #ActOnClimate",
    "id" : 637013563840659457,
    "created_at" : "2015-08-27 21:27:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 637014780625055744,
  "created_at" : "2015-08-27 21:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637013094951186432",
  "text" : "\"New Orleans has become a model for the nation as the first city, the first major city to end veteran\u2019s homelessness\" \u2014@POTUS to New Orleans",
  "id" : 637013094951186432,
  "created_at" : "2015-08-27 21:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/637012278425055233\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/uVfCVwhEPa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNcfQYEUcAAzz61.jpg",
      "id_str" : "637012238495150080",
      "id" : 637012238495150080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNcfQYEUcAAzz61.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uVfCVwhEPa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637012278425055233",
  "text" : "\"Together, we\u2019re building a New Orleans that is as entrepreneurial as any place in the country.\" \u2014@POTUS http:\/\/t.co\/uVfCVwhEPa",
  "id" : 637012278425055233,
  "created_at" : "2015-08-27 21:22:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637011821061234690\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/okKKGmTWQg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNce3NmUYAAcZR6.jpg",
      "id_str" : "637011806188232704",
      "id" : 637011806188232704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNce3NmUYAAcZR6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/okKKGmTWQg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637011821061234690",
  "text" : "\"We\u2019re providing housing assistance to more families today than before the storm.\" \u2014@POTUS http:\/\/t.co\/okKKGmTWQg",
  "id" : 637011821061234690,
  "created_at" : "2015-08-27 21:20:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Katrina10",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637011681340604416",
  "text" : "\"Before the storm, college enrollment was 37%. Today, it\u2019s almost 60%.\" \u2014@POTUS on New Orleans #Katrina10",
  "id" : 637011681340604416,
  "created_at" : "2015-08-27 21:19:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Katrina10",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637011589623848960",
  "text" : "\"Before the storm, the high school graduation rate was 54%. Today, it\u2019s up to 73%.\" \u2014@POTUS on New Orleans #Katrina10",
  "id" : 637011589623848960,
  "created_at" : "2015-08-27 21:19:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637011409843429377\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/K5o5qwq9hK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNceNMdUwAAosNt.jpg",
      "id_str" : "637011084327567360",
      "id" : 637011084327567360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNceNMdUwAAosNt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/K5o5qwq9hK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637011409843429377",
  "text" : "\"We\u2019ve delivered resources to help Louisiana, Mississippi, Alabama, and Florida rebuild schools &amp; hospitals.\" \u2014@POTUS http:\/\/t.co\/K5o5qwq9hK",
  "id" : 637011409843429377,
  "created_at" : "2015-08-27 21:18:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Katrina10",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637010957617745920",
  "text" : "\"Because of you, the people of New Orleans, working together, this city is moving in the right direction.\" \u2014@POTUS #Katrina10",
  "id" : 637010957617745920,
  "created_at" : "2015-08-27 21:17:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/637003743645581312\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/69gYOKe5AY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNcXfRYUAAE7MsV.jpg",
      "id_str" : "637003698304974849",
      "id" : 637003698304974849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNcXfRYUAAE7MsV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/69gYOKe5AY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/zcyA0dGv4a",
      "expanded_url" : "http:\/\/go.wh.gov\/Katrina10",
      "display_url" : "go.wh.gov\/Katrina10"
    } ]
  },
  "geo" : { },
  "id_str" : "637003743645581312",
  "text" : "At 4:55pm ET, @POTUS is speaking on the Gulf Coast's rebirth 10 years after Hurricane Katrina: http:\/\/t.co\/zcyA0dGv4a http:\/\/t.co\/69gYOKe5AY",
  "id" : 637003743645581312,
  "created_at" : "2015-08-27 20:48:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "indices" : [ 3, 11 ],
      "id_str" : "1563426390",
      "id" : 1563426390
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Katrina10",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Et1V3X7Xcv",
      "expanded_url" : "http:\/\/go.wh.gov\/cWmtcS",
      "display_url" : "go.wh.gov\/cWmtcS"
    } ]
  },
  "geo" : { },
  "id_str" : "636993562715013125",
  "text" : "RT @Holst44: Today @POTUS is in New Orleans commemorating #Katrina10. Follow along with his day here \u2192 http:\/\/t.co\/Et1V3X7Xcv http:\/\/t.co\/r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Holst44\/status\/636951015632314368\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/ry0U8tWtPi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNbnktCUYAEDaW5.jpg",
        "id_str" : "636951015070130177",
        "id" : 636951015070130177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNbnktCUYAEDaW5.jpg",
        "sizes" : [ {
          "h" : 267,
          "resize" : "fit",
          "w" : 780
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 116,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 780
        } ],
        "display_url" : "pic.twitter.com\/ry0U8tWtPi"
      } ],
      "hashtags" : [ {
        "text" : "Katrina10",
        "indices" : [ 45, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Et1V3X7Xcv",
        "expanded_url" : "http:\/\/go.wh.gov\/cWmtcS",
        "display_url" : "go.wh.gov\/cWmtcS"
      } ]
    },
    "geo" : { },
    "id_str" : "636951015632314368",
    "text" : "Today @POTUS is in New Orleans commemorating #Katrina10. Follow along with his day here \u2192 http:\/\/t.co\/Et1V3X7Xcv http:\/\/t.co\/ry0U8tWtPi",
    "id" : 636951015632314368,
    "created_at" : "2015-08-27 17:18:50 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 636993562715013125,
  "created_at" : "2015-08-27 20:07:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/636991631606964225\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/x4aqt6hoKo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNcMYosVAAACsY-.jpg",
      "id_str" : "636991489675952128",
      "id" : 636991489675952128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNcMYosVAAACsY-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/x4aqt6hoKo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/3zGaU1tVyR",
      "expanded_url" : "http:\/\/wh.gov\/Katrina-Anniversary",
      "display_url" : "wh.gov\/Katrina-Annive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636991631606964225",
  "text" : "Tune in at 4:55pm ET to watch @POTUS speak in New Orleans 10 years after Hurricane Katrina: http:\/\/t.co\/3zGaU1tVyR http:\/\/t.co\/x4aqt6hoKo",
  "id" : 636991631606964225,
  "created_at" : "2015-08-27 20:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/GjZovVN4Kv",
      "expanded_url" : "https:\/\/twitter.com\/GovMalloyOffice\/status\/636955141741113344",
      "display_url" : "twitter.com\/GovMalloyOffic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636989057235456000",
  "text" : "Congratulations to Connecticut on becoming the first state to successfully end chronic veteran homelessness: https:\/\/t.co\/GjZovVN4Kv",
  "id" : 636989057235456000,
  "created_at" : "2015-08-27 19:50:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/636968046469492736\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/9B0mQkZ8OA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNb3DHdWcAAvsmf.jpg",
      "id_str" : "636968030233325568",
      "id" : 636968030233325568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNb3DHdWcAAvsmf.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9B0mQkZ8OA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636982846821941249",
  "text" : "RT @vj44: .@POTUS pauses to say hello to a darling little boy in Treme http:\/\/t.co\/9B0mQkZ8OA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/636968046469492736\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/9B0mQkZ8OA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNb3DHdWcAAvsmf.jpg",
        "id_str" : "636968030233325568",
        "id" : 636968030233325568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNb3DHdWcAAvsmf.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9B0mQkZ8OA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636968046469492736",
    "text" : ".@POTUS pauses to say hello to a darling little boy in Treme http:\/\/t.co\/9B0mQkZ8OA",
    "id" : 636968046469492736,
    "created_at" : "2015-08-27 18:26:31 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 636982846821941249,
  "created_at" : "2015-08-27 19:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Philip Hammond",
      "screen_name" : "PHammondMP",
      "indices" : [ 31, 42 ],
      "id_str" : "2653613168",
      "id" : 2653613168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/aclVlsuT4f",
      "expanded_url" : "http:\/\/go.wh.gov\/AA4CQY",
      "display_url" : "go.wh.gov\/AA4CQY"
    } ]
  },
  "geo" : { },
  "id_str" : "636972836058464256",
  "text" : "RT @jesseclee44: New from UK's @PHammondMP: \"If US were to walk away, international unity would disintegrate\" http:\/\/t.co\/aclVlsuT4f http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philip Hammond",
        "screen_name" : "PHammondMP",
        "indices" : [ 14, 25 ],
        "id_str" : "2653613168",
        "id" : 2653613168
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jesseclee44\/status\/636969350088388608\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/DHx49dqFm2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNb4P0tUkAAfNop.jpg",
        "id_str" : "636969348049965056",
        "id" : 636969348049965056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNb4P0tUkAAfNop.jpg",
        "sizes" : [ {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 708
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 708
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DHx49dqFm2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/aclVlsuT4f",
        "expanded_url" : "http:\/\/go.wh.gov\/AA4CQY",
        "display_url" : "go.wh.gov\/AA4CQY"
      } ]
    },
    "geo" : { },
    "id_str" : "636969350088388608",
    "text" : "New from UK's @PHammondMP: \"If US were to walk away, international unity would disintegrate\" http:\/\/t.co\/aclVlsuT4f http:\/\/t.co\/DHx49dqFm2",
    "id" : 636969350088388608,
    "created_at" : "2015-08-27 18:31:42 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 636972836058464256,
  "created_at" : "2015-08-27 18:45:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "Philip Hammond",
      "screen_name" : "PHammondMP",
      "indices" : [ 38, 49 ],
      "id_str" : "2653613168",
      "id" : 2653613168
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/1ZZ9IGl2i9",
      "expanded_url" : "http:\/\/go.wh.gov\/AA4CQY",
      "display_url" : "go.wh.gov\/AA4CQY"
    } ]
  },
  "geo" : { },
  "id_str" : "636968038550667264",
  "text" : "RT @TheIranDeal: The United Kingdom's @PHammondMP adds his perspective to the #IranDeal text. See it here \u2192 http:\/\/t.co\/1ZZ9IGl2i9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philip Hammond",
        "screen_name" : "PHammondMP",
        "indices" : [ 21, 32 ],
        "id_str" : "2653613168",
        "id" : 2653613168
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/1ZZ9IGl2i9",
        "expanded_url" : "http:\/\/go.wh.gov\/AA4CQY",
        "display_url" : "go.wh.gov\/AA4CQY"
      } ]
    },
    "geo" : { },
    "id_str" : "636967714096041984",
    "text" : "The United Kingdom's @PHammondMP adds his perspective to the #IranDeal text. See it here \u2192 http:\/\/t.co\/1ZZ9IGl2i9",
    "id" : 636967714096041984,
    "created_at" : "2015-08-27 18:25:11 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 636968038550667264,
  "created_at" : "2015-08-27 18:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/iEAYtQ0ovW",
      "expanded_url" : "http:\/\/snpy.tv\/1Emxmkg",
      "display_url" : "snpy.tv\/1Emxmkg"
    } ]
  },
  "geo" : { },
  "id_str" : "636960125924810752",
  "text" : "RT @TheIranDeal: Watch a nuclear physicist explain the science behind the #IranDeal: http:\/\/t.co\/iEAYtQ0ovW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/iEAYtQ0ovW",
        "expanded_url" : "http:\/\/snpy.tv\/1Emxmkg",
        "display_url" : "snpy.tv\/1Emxmkg"
      } ]
    },
    "geo" : { },
    "id_str" : "636918237020725248",
    "text" : "Watch a nuclear physicist explain the science behind the #IranDeal: http:\/\/t.co\/iEAYtQ0ovW",
    "id" : 636918237020725248,
    "created_at" : "2015-08-27 15:08:35 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 636960125924810752,
  "created_at" : "2015-08-27 17:55:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 13, 20 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 43, 55 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/5bhmPPZNx8",
      "expanded_url" : "http:\/\/wh.gov\/IranDeal",
      "display_url" : "wh.gov\/IranDeal"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/fxXTtz9ZLE",
      "expanded_url" : "http:\/\/snpy.tv\/1Emxmkg",
      "display_url" : "snpy.tv\/1Emxmkg"
    } ]
  },
  "geo" : { },
  "id_str" : "636934991235055616",
  "text" : "Secretary of @Energy \u2713\nNuclear physicist \u2713\n@ErnestMoniz explains the #IranDeal science: http:\/\/t.co\/5bhmPPZNx8 http:\/\/t.co\/fxXTtz9ZLE",
  "id" : 636934991235055616,
  "created_at" : "2015-08-27 16:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636923578127118336",
  "text" : "RT @POTUS: Amidst global volatility, Congress should protect the momentum of our growing economy (not kill it). We must avoid shutdown \/ au\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636923084818259968",
    "text" : "Amidst global volatility, Congress should protect the momentum of our growing economy (not kill it). We must avoid shutdown \/ austerity.",
    "id" : 636923084818259968,
    "created_at" : "2015-08-27 15:27:51 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 636923578127118336,
  "created_at" : "2015-08-27 15:29:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 10, 22 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/fxXTtz9ZLE",
      "expanded_url" : "http:\/\/snpy.tv\/1Emxmkg",
      "display_url" : "snpy.tv\/1Emxmkg"
    } ]
  },
  "geo" : { },
  "id_str" : "636920854895419392",
  "text" : "Secretary @ErnestMoniz spent 40 years on the nuclear physics faculty at MIT. Watch him explain the #IranDeal science: http:\/\/t.co\/fxXTtz9ZLE",
  "id" : 636920854895419392,
  "created_at" : "2015-08-27 15:18:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636900833565605892",
  "text" : "RT @AmbassadorPower: My op-ed on how walking away from the #IranDeal will undercut US foreign policy heft beyond Iran: http:\/\/t.co\/IM0Q7g6b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 38, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/IM0Q7g6brc",
        "expanded_url" : "http:\/\/politi.co\/1Jy1RPY",
        "display_url" : "politi.co\/1Jy1RPY"
      } ]
    },
    "geo" : { },
    "id_str" : "636891904475574272",
    "text" : "My op-ed on how walking away from the #IranDeal will undercut US foreign policy heft beyond Iran: http:\/\/t.co\/IM0Q7g6brc",
    "id" : 636891904475574272,
    "created_at" : "2015-08-27 13:23:57 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 636900833565605892,
  "created_at" : "2015-08-27 13:59:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 87, 98 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 102, 109 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zyyz50gldS",
      "expanded_url" : "http:\/\/bit.ly\/1K3VIBE",
      "display_url" : "bit.ly\/1K3VIBE"
    } ]
  },
  "geo" : { },
  "id_str" : "636688676978733056",
  "text" : "RT @ErnestMoniz: Watch me explain the science of the #IranDeal in a new video from the @WhiteHouse on @PopSci: http:\/\/t.co\/zyyz50gldS http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 70, 81 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Popular Science",
        "screen_name" : "PopSci",
        "indices" : [ 85, 92 ],
        "id_str" : "19722699",
        "id" : 19722699
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ErnestMoniz\/status\/636642154446745600\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/N6LN7Gk1OB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNXOqlsU8AAXFMv.jpg",
        "id_str" : "636642153410654208",
        "id" : 636642153410654208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNXOqlsU8AAXFMv.jpg",
        "sizes" : [ {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/N6LN7Gk1OB"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 36, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/zyyz50gldS",
        "expanded_url" : "http:\/\/bit.ly\/1K3VIBE",
        "display_url" : "bit.ly\/1K3VIBE"
      } ]
    },
    "geo" : { },
    "id_str" : "636642154446745600",
    "text" : "Watch me explain the science of the #IranDeal in a new video from the @WhiteHouse on @PopSci: http:\/\/t.co\/zyyz50gldS http:\/\/t.co\/N6LN7Gk1OB",
    "id" : 636642154446745600,
    "created_at" : "2015-08-26 20:51:32 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 636688676978733056,
  "created_at" : "2015-08-26 23:56:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 3, 10 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/636643197180100609\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/On5oO9Ljgy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNXPMxWVAAAAgtt.jpg",
      "id_str" : "636642740655161344",
      "id" : 636642740655161344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNXPMxWVAAAAgtt.jpg",
      "sizes" : [ {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/On5oO9Ljgy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/XyMLhMyI0J",
      "expanded_url" : "http:\/\/www.popsci.com\/ernest-moniz-explains-science-iran-deal?src=SOC&dom=tw",
      "display_url" : "popsci.com\/ernest-moniz-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636686206361669636",
  "text" : "RT @PopSci: Exclusive new White House video makes the scientific case for the Iran deal \nhttp:\/\/t.co\/XyMLhMyI0J http:\/\/t.co\/On5oO9Ljgy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/636643197180100609\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/On5oO9Ljgy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNXPMxWVAAAAgtt.jpg",
        "id_str" : "636642740655161344",
        "id" : 636642740655161344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNXPMxWVAAAAgtt.jpg",
        "sizes" : [ {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/On5oO9Ljgy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/XyMLhMyI0J",
        "expanded_url" : "http:\/\/www.popsci.com\/ernest-moniz-explains-science-iran-deal?src=SOC&dom=tw",
        "display_url" : "popsci.com\/ernest-moniz-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "636643197180100609",
    "text" : "Exclusive new White House video makes the scientific case for the Iran deal \nhttp:\/\/t.co\/XyMLhMyI0J http:\/\/t.co\/On5oO9Ljgy",
    "id" : 636643197180100609,
    "created_at" : "2015-08-26 20:55:41 +0000",
    "user" : {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "protected" : false,
      "id_str" : "19722699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793561660833267712\/Y5RPH9Te_normal.jpg",
      "id" : 19722699,
      "verified" : true
    }
  },
  "id" : 636686206361669636,
  "created_at" : "2015-08-26 23:46:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Diamond",
      "screen_name" : "Rob44",
      "indices" : [ 3, 9 ],
      "id_str" : "3065348142",
      "id" : 3065348142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "WomensEqualityDay",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/bvm52CS7xe",
      "expanded_url" : "http:\/\/go.wh.gov\/c9iQHp",
      "display_url" : "go.wh.gov\/c9iQHp"
    } ]
  },
  "geo" : { },
  "id_str" : "636681195015696385",
  "text" : "RT @Rob44: The President's trade deal encourages #EqualPay for women around the world: http:\/\/t.co\/bvm52CS7xe #WomensEqualityDay http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Rob44\/status\/636664257950576641\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/DxUpPsakQO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNXiw0hVAAAClum.jpg",
        "id_str" : "636664250702823424",
        "id" : 636664250702823424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNXiw0hVAAAClum.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DxUpPsakQO"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 38, 47 ]
      }, {
        "text" : "WomensEqualityDay",
        "indices" : [ 99, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/bvm52CS7xe",
        "expanded_url" : "http:\/\/go.wh.gov\/c9iQHp",
        "display_url" : "go.wh.gov\/c9iQHp"
      } ]
    },
    "geo" : { },
    "id_str" : "636664257950576641",
    "text" : "The President's trade deal encourages #EqualPay for women around the world: http:\/\/t.co\/bvm52CS7xe #WomensEqualityDay http:\/\/t.co\/DxUpPsakQO",
    "id" : 636664257950576641,
    "created_at" : "2015-08-26 22:19:22 +0000",
    "user" : {
      "name" : "Rob Diamond",
      "screen_name" : "Rob44",
      "protected" : false,
      "id_str" : "3065348142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628268968214724608\/D4RYPQmQ_normal.jpg",
      "id" : 3065348142,
      "verified" : true
    }
  },
  "id" : 636681195015696385,
  "created_at" : "2015-08-26 23:26:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "indices" : [ 3, 11 ],
      "id_str" : "3274836392",
      "id" : 3274836392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 102, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636670450735583232",
  "text" : "RT @Diana44: FACT: Women business owners who export sell 20 times more products than those who don't. #WomensEqualityDay http:\/\/t.co\/uiWNj9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Diana44\/status\/636656891142123521\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/uiWNj9Wucs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNXOVHVUwAE0xdO.jpg",
        "id_str" : "636641784483856385",
        "id" : 636641784483856385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNXOVHVUwAE0xdO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/uiWNj9Wucs"
      } ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 89, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636656891142123521",
    "text" : "FACT: Women business owners who export sell 20 times more products than those who don't. #WomensEqualityDay http:\/\/t.co\/uiWNj9Wucs",
    "id" : 636656891142123521,
    "created_at" : "2015-08-26 21:50:06 +0000",
    "user" : {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "protected" : false,
      "id_str" : "3274836392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671831357371191296\/CQ0VNiYR_normal.jpg",
      "id" : 3274836392,
      "verified" : true
    }
  },
  "id" : 636670450735583232,
  "created_at" : "2015-08-26 22:43:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "WomensEqualityDay",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/kBVUqIxUyn",
      "expanded_url" : "http:\/\/snpy.tv\/1U5vnYx",
      "display_url" : "snpy.tv\/1U5vnYx"
    } ]
  },
  "geo" : { },
  "id_str" : "636643225466335232",
  "text" : "It's 2015. Women should earn the same pay as men for doing the same work. Period. #EqualPay #WomensEqualityDay http:\/\/t.co\/kBVUqIxUyn",
  "id" : 636643225466335232,
  "created_at" : "2015-08-26 20:55:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "City of Dayton, Ohio",
      "screen_name" : "cityofdayton",
      "indices" : [ 12, 25 ],
      "id_str" : "33903907",
      "id" : 33903907
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/EAT3KvZWP5",
      "expanded_url" : "http:\/\/go.wh.gov\/3ViTLh",
      "display_url" : "go.wh.gov\/3ViTLh"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/44O2u99DzI",
      "expanded_url" : "https:\/\/twitter.com\/cityofdayton\/status\/636557583034253312",
      "display_url" : "twitter.com\/cityofdayton\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "636634133104578561",
  "text" : "Congrats to @CityOfDayton and every city in America expanding paid leave: http:\/\/t.co\/EAT3KvZWP5 #LeadOnLeave https:\/\/t.co\/44O2u99DzI",
  "id" : 636634133104578561,
  "created_at" : "2015-08-26 20:19:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Ezjvn9FSY5",
      "expanded_url" : "http:\/\/go.wh.gov\/m1wu7J",
      "display_url" : "go.wh.gov\/m1wu7J"
    } ]
  },
  "geo" : { },
  "id_str" : "636632615030771712",
  "text" : "See how the federal government's partnering with your community. \nThen share how you've seen the partnership at work: http:\/\/t.co\/Ezjvn9FSY5",
  "id" : 636632615030771712,
  "created_at" : "2015-08-26 20:13:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/636609464741830656\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/F8xfFuxZnP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNWw5daUcAA6u4p.png",
      "id_str" : "636609423536844800",
      "id" : 636609423536844800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNWw5daUcAA6u4p.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 727
      }, {
        "h" : 145,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 727
      } ],
      "display_url" : "pic.twitter.com\/F8xfFuxZnP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636609464741830656",
  "text" : "\"Amelia committed herself to a simple, American principle: that everybody deserves the right to vote.\" \u2014@POTUS: http:\/\/t.co\/F8xfFuxZnP",
  "id" : 636609464741830656,
  "created_at" : "2015-08-26 18:41:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WIRED\/status\/636576921732648960\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/xXg7jyDdrT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNWTVkGVAAAgclR.png",
      "id_str" : "636576921019547648",
      "id" : 636576921019547648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNWTVkGVAAAgclR.png",
      "sizes" : [ {
        "h" : 310,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 181,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 582
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 582
      } ],
      "display_url" : "pic.twitter.com\/xXg7jyDdrT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/evX3Jsdf5F",
      "expanded_url" : "http:\/\/wrd.cm\/1K2LOjx",
      "display_url" : "wrd.cm\/1K2LOjx"
    } ]
  },
  "geo" : { },
  "id_str" : "636599859294765056",
  "text" : "RT @WIRED: An open source tool for visualizing government work across the country http:\/\/t.co\/evX3Jsdf5F http:\/\/t.co\/xXg7jyDdrT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WIRED\/status\/636576921732648960\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/xXg7jyDdrT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNWTVkGVAAAgclR.png",
        "id_str" : "636576921019547648",
        "id" : 636576921019547648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNWTVkGVAAAgclR.png",
        "sizes" : [ {
          "h" : 310,
          "resize" : "fit",
          "w" : 582
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 582
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 582
        } ],
        "display_url" : "pic.twitter.com\/xXg7jyDdrT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/evX3Jsdf5F",
        "expanded_url" : "http:\/\/wrd.cm\/1K2LOjx",
        "display_url" : "wrd.cm\/1K2LOjx"
      } ]
    },
    "geo" : { },
    "id_str" : "636576921732648960",
    "text" : "An open source tool for visualizing government work across the country http:\/\/t.co\/evX3Jsdf5F http:\/\/t.co\/xXg7jyDdrT",
    "id" : 636576921732648960,
    "created_at" : "2015-08-26 16:32:19 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 636599859294765056,
  "created_at" : "2015-08-26 18:03:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/636588106553036801\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/BzIHWv7P2l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNWdewAU8AAkobj.png",
      "id_str" : "636588073950703616",
      "id" : 636588073950703616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNWdewAU8AAkobj.png",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 707
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 707
      } ],
      "display_url" : "pic.twitter.com\/BzIHWv7P2l"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ZiyIzAZfuT",
      "expanded_url" : "http:\/\/go.wh.gov\/kbQWtD",
      "display_url" : "go.wh.gov\/kbQWtD"
    } ]
  },
  "geo" : { },
  "id_str" : "636588106553036801",
  "text" : "Here\u2019s a map of how the federal government is working with local communities to create change: http:\/\/t.co\/ZiyIzAZfuT http:\/\/t.co\/BzIHWv7P2l",
  "id" : 636588106553036801,
  "created_at" : "2015-08-26 17:16:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ipt5tEQKLD",
      "expanded_url" : "http:\/\/LettersToPresidentObama.tumblr.com",
      "display_url" : "LettersToPresidentObama.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "636357438933852160",
  "text" : "\u201CIf the research hadn\u2019t continued, I wouldn\u2019t be here today.\u201D \u2014Gavin writing to @POTUS about his battle with cancer: http:\/\/t.co\/ipt5tEQKLD",
  "id" : 636357438933852160,
  "created_at" : "2015-08-26 02:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MAKERS",
      "screen_name" : "MAKERSwomen",
      "indices" : [ 3, 15 ],
      "id_str" : "491350825",
      "id" : 491350825
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 129, 134 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ValerieJarrett",
      "indices" : [ 27, 42 ]
    }, {
      "text" : "WomensEqualityDay",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636331802085298176",
  "text" : "RT @MAKERSwomen: New MAKER #ValerieJarrett will host a LIVE Twitter chat tomorrow at 11am ET. Tweet #WomensEqualityDay questions @vj44 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 112, 117 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ValerieJarrett",
        "indices" : [ 10, 25 ]
      }, {
        "text" : "WomensEqualityDay",
        "indices" : [ 83, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/OeSNoBZRn4",
        "expanded_url" : "http:\/\/aol.it\/1Poa6mf",
        "display_url" : "aol.it\/1Poa6mf"
      } ]
    },
    "geo" : { },
    "id_str" : "636285673666809856",
    "text" : "New MAKER #ValerieJarrett will host a LIVE Twitter chat tomorrow at 11am ET. Tweet #WomensEqualityDay questions @vj44 http:\/\/t.co\/OeSNoBZRn4",
    "id" : 636285673666809856,
    "created_at" : "2015-08-25 21:15:00 +0000",
    "user" : {
      "name" : "MAKERS",
      "screen_name" : "MAKERSwomen",
      "protected" : false,
      "id_str" : "491350825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750309035052789760\/eJDVWMir_normal.jpg",
      "id" : 491350825,
      "verified" : true
    }
  },
  "id" : 636331802085298176,
  "created_at" : "2015-08-26 00:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PIF",
      "screen_name" : "InnovFellows",
      "indices" : [ 39, 52 ],
      "id_str" : "3184883153",
      "id" : 3184883153
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/636328225992495104\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Ah30xx9HRt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNSw_1mUwAEYAwS.jpg",
      "id_str" : "636328058132152321",
      "id" : 636328058132152321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNSw_1mUwAEYAwS.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1067
      } ],
      "display_url" : "pic.twitter.com\/Ah30xx9HRt"
    } ],
    "hashtags" : [ {
      "text" : "OpenData",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Ey9kEK21AM",
      "expanded_url" : "http:\/\/go.wh.gov\/FvYMNJ",
      "display_url" : "go.wh.gov\/FvYMNJ"
    } ]
  },
  "geo" : { },
  "id_str" : "636328225992495104",
  "text" : "Ten years after Katrina: Find out from @InnovFellows how #OpenData helped New Orleans \u2192 http:\/\/t.co\/Ey9kEK21AM http:\/\/t.co\/Ah30xx9HRt",
  "id" : 636328225992495104,
  "created_at" : "2015-08-26 00:04:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "indices" : [ 3, 15 ],
      "id_str" : "293131808",
      "id" : 293131808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636303103046848512",
  "text" : "RT @PattyMurray: Murray: I'm convinced that moving fwd w\/ this deal is the best chance we have at a strong diplomatic solution. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/yXy9R1N5YB",
        "expanded_url" : "http:\/\/bit.ly\/1Jhw6LJ",
        "display_url" : "bit.ly\/1Jhw6LJ"
      } ]
    },
    "geo" : { },
    "id_str" : "636271859042926592",
    "text" : "Murray: I'm convinced that moving fwd w\/ this deal is the best chance we have at a strong diplomatic solution. http:\/\/t.co\/yXy9R1N5YB #Iran",
    "id" : 636271859042926592,
    "created_at" : "2015-08-25 20:20:07 +0000",
    "user" : {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "protected" : false,
      "id_str" : "293131808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430384292917555200\/ULj2LMsW_normal.jpeg",
      "id" : 293131808,
      "verified" : true
    }
  },
  "id" : 636303103046848512,
  "created_at" : "2015-08-25 22:24:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 46, 51 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "MAKERS",
      "screen_name" : "MAKERSwomen",
      "indices" : [ 77, 89 ],
      "id_str" : "491350825",
      "id" : 491350825
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 12, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FgkXIJ8M5X",
      "expanded_url" : "http:\/\/aol.it\/1Poa6mf",
      "display_url" : "aol.it\/1Poa6mf"
    } ]
  },
  "geo" : { },
  "id_str" : "636281949468753920",
  "text" : "Tomorrow is #WomensEqualityDay!\nTo celebrate, @VJ44's holding a Q&amp;A with @MAKERSWomen.\nAsk yours Qs by 11am ET. http:\/\/t.co\/FgkXIJ8M5X",
  "id" : 636281949468753920,
  "created_at" : "2015-08-25 21:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 3, 19 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 110, 123 ]
    }, {
      "text" : "NPS99",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636267444072349697",
  "text" : "RT @NatlParkService: These guys might be headed to a birthday party. How are you celebrating 99 years of NPS? #FindYourPark #NPS99 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatlParkService\/status\/636158298325188608\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/DhBPHkRrny",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQWmIFVAAANtJV.jpg",
        "id_str" : "636158291626754048",
        "id" : 636158291626754048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQWmIFVAAANtJV.jpg",
        "sizes" : [ {
          "h" : 483,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 283,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 160,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DhBPHkRrny"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 89, 102 ]
      }, {
        "text" : "NPS99",
        "indices" : [ 103, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636158298325188608",
    "text" : "These guys might be headed to a birthday party. How are you celebrating 99 years of NPS? #FindYourPark #NPS99 http:\/\/t.co\/DhBPHkRrny",
    "id" : 636158298325188608,
    "created_at" : "2015-08-25 12:48:52 +0000",
    "user" : {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "protected" : false,
      "id_str" : "36771809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179200522\/NPS_SocialMediaProfilePic_Blue_normal.png",
      "id" : 36771809,
      "verified" : true
    }
  },
  "id" : 636267444072349697,
  "created_at" : "2015-08-25 20:02:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636236549907087360",
  "text" : "RT @POTUS: The National Park Service: 99 years and 84 million acres strong. Congrats to all who work to protect these treasures. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/636235501658222592\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/R8RyB9vkVW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNRc0Q1U8AI3-ew.jpg",
        "id_str" : "636235500307673090",
        "id" : 636235500307673090,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNRc0Q1U8AI3-ew.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/R8RyB9vkVW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636235501658222592",
    "text" : "The National Park Service: 99 years and 84 million acres strong. Congrats to all who work to protect these treasures. http:\/\/t.co\/R8RyB9vkVW",
    "id" : 636235501658222592,
    "created_at" : "2015-08-25 17:55:38 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 636236549907087360,
  "created_at" : "2015-08-25 17:59:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MAKERS",
      "screen_name" : "MAKERSwomen",
      "indices" : [ 3, 15 ],
      "id_str" : "491350825",
      "id" : 491350825
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 121, 126 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MAKER",
      "indices" : [ 22, 28 ]
    }, {
      "text" : "ValerieJarrett",
      "indices" : [ 29, 44 ]
    }, {
      "text" : "WomensEqualityDay",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636232860303785985",
  "text" : "RT @MAKERSwomen: Join #MAKER #ValerieJarrett in a live Twitter chat TOMORROW 11am ET. Tweet #WomensEqualityDay questions @vj44: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 104, 109 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MAKER",
        "indices" : [ 5, 11 ]
      }, {
        "text" : "ValerieJarrett",
        "indices" : [ 12, 27 ]
      }, {
        "text" : "WomensEqualityDay",
        "indices" : [ 75, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/OeSNoBIgvw",
        "expanded_url" : "http:\/\/aol.it\/1Poa6mf",
        "display_url" : "aol.it\/1Poa6mf"
      } ]
    },
    "geo" : { },
    "id_str" : "636190338047209472",
    "text" : "Join #MAKER #ValerieJarrett in a live Twitter chat TOMORROW 11am ET. Tweet #WomensEqualityDay questions @vj44: http:\/\/t.co\/OeSNoBIgvw",
    "id" : 636190338047209472,
    "created_at" : "2015-08-25 14:56:11 +0000",
    "user" : {
      "name" : "MAKERS",
      "screen_name" : "MAKERSwomen",
      "protected" : false,
      "id_str" : "491350825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750309035052789760\/eJDVWMir_normal.jpg",
      "id" : 491350825,
      "verified" : true
    }
  },
  "id" : 636232860303785985,
  "created_at" : "2015-08-25 17:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 31, 47 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/VObGo7u5og",
      "expanded_url" : "http:\/\/go.nasa.gov\/1V7h6HZ",
      "display_url" : "go.nasa.gov\/1V7h6HZ"
    } ]
  },
  "geo" : { },
  "id_str" : "636228473401540608",
  "text" : "RT @NASA: Happy 99th birthday, @NatlParkService! You look better than ever, especially from space! http:\/\/t.co\/VObGo7u5og http:\/\/t.co\/pC1fc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 21, 37 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/636191057856888832\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/pC1fcRFBBq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQ0ZGAWEAE3mOS.jpg",
        "id_str" : "636191053079515137",
        "id" : 636191053079515137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQ0ZGAWEAE3mOS.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/pC1fcRFBBq"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/636191057856888832\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/pC1fcRFBBq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQ0ZJBXAAAs-eZ.jpg",
        "id_str" : "636191053889077248",
        "id" : 636191053889077248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQ0ZJBXAAAs-eZ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/pC1fcRFBBq"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/636191057856888832\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/pC1fcRFBBq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQ0ZPyWIAAmkiQ.jpg",
        "id_str" : "636191055705153536",
        "id" : 636191055705153536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQ0ZPyWIAAmkiQ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/pC1fcRFBBq"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/636191057856888832\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/pC1fcRFBBq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQ0ZWVWcAAeHa6.jpg",
        "id_str" : "636191057462587392",
        "id" : 636191057462587392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQ0ZWVWcAAeHa6.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/pC1fcRFBBq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/VObGo7u5og",
        "expanded_url" : "http:\/\/go.nasa.gov\/1V7h6HZ",
        "display_url" : "go.nasa.gov\/1V7h6HZ"
      } ]
    },
    "geo" : { },
    "id_str" : "636191057856888832",
    "text" : "Happy 99th birthday, @NatlParkService! You look better than ever, especially from space! http:\/\/t.co\/VObGo7u5og http:\/\/t.co\/pC1fcRFBBq",
    "id" : 636191057856888832,
    "created_at" : "2015-08-25 14:59:02 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 636228473401540608,
  "created_at" : "2015-08-25 17:27:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/jmJUBHSLqb",
      "expanded_url" : "http:\/\/snpy.tv\/1U3kSow",
      "display_url" : "snpy.tv\/1U3kSow"
    } ]
  },
  "geo" : { },
  "id_str" : "636214028323282944",
  "text" : "\"We refuse to surrender the hope of a clean energy future to those who fear it and fight it.\" \u2014@POTUS: http:\/\/t.co\/jmJUBHSLqb #ActOnClimate",
  "id" : 636214028323282944,
  "created_at" : "2015-08-25 16:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 21, 37 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/636199484700004352\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/A53lIXhBdc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNQ75FMWIAAy2_r.jpg",
      "id_str" : "636199299198623744",
      "id" : 636199299198623744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNQ75FMWIAAy2_r.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/A53lIXhBdc"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636199484700004352",
  "text" : "Happy 99th Birthday, @NatlParkService! \nRT if you're getting out to #FindYourPark. \nEntrance fees are waived today. http:\/\/t.co\/A53lIXhBdc",
  "id" : 636199484700004352,
  "created_at" : "2015-08-25 15:32:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNSC",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635991806212239360",
  "text" : "RT @AmbassadorPower: Before today, the #UNSC had never had a meeting on #LGBT rights. This was long overdue\u2014a small but important step that\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNSC",
        "indices" : [ 18, 23 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 51, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635873001913851904",
    "text" : "Before today, the #UNSC had never had a meeting on #LGBT rights. This was long overdue\u2014a small but important step that must not be our last.",
    "id" : 635873001913851904,
    "created_at" : "2015-08-24 17:55:12 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 635991806212239360,
  "created_at" : "2015-08-25 01:47:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/du67N7C0la",
      "expanded_url" : "http:\/\/snpy.tv\/1U3jAKf",
      "display_url" : "snpy.tv\/1U3jAKf"
    } ]
  },
  "geo" : { },
  "id_str" : "635989168775135232",
  "text" : "Watch @POTUS announce the new steps we're taking to move America toward a clean energy future: http:\/\/t.co\/du67N7C0la #ActOnClimate",
  "id" : 635989168775135232,
  "created_at" : "2015-08-25 01:36:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635975542878044161",
  "text" : "\"That's what Americans do. We can do anything. And, you guys are proving it every single day.\" \u2014@POTUS #ActOnClimate",
  "id" : 635975542878044161,
  "created_at" : "2015-08-25 00:42:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635974191326453760",
  "text" : "\"There is something big happening in America...For the first time, we can actually see what our clean energy future looks like.\" \u2014@POTUS",
  "id" : 635974191326453760,
  "created_at" : "2015-08-25 00:37:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635972432600412164",
  "text" : "RT @WHLive: \"People are beginning to realize they can take more control over their own energy\u2014what kind they use, how much, and when.\" \u2014@PO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 124, 130 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635972367508856832",
    "text" : "\"People are beginning to realize they can take more control over their own energy\u2014what kind they use, how much, and when.\" \u2014@POTUS",
    "id" : 635972367508856832,
    "created_at" : "2015-08-25 00:30:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 635972432600412164,
  "created_at" : "2015-08-25 00:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/635971578749018112\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/dLopOjrvPD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNNsuvMWEAEfdk8.jpg",
      "id_str" : "635971522587398145",
      "id" : 635971522587398145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNNsuvMWEAEfdk8.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dLopOjrvPD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635971578749018112",
  "text" : "\"We\u2019re also going to make it even easier for individual homeowners to put solar panels on their roof\" \u2014@POTUS on PACE http:\/\/t.co\/dLopOjrvPD",
  "id" : 635971578749018112,
  "created_at" : "2015-08-25 00:26:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635970575177879552",
  "text" : "\"For decades, we\u2019ve been told that it doesn\u2019t make economic sense to switch to renewable energy. Today, that\u2019s no longer true.\" \u2014@POTUS",
  "id" : 635970575177879552,
  "created_at" : "2015-08-25 00:22:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635969207457423360",
  "text" : "RT @WHLive: \"The single most important step America has ever taken to combat climate change.\" \u2014@POTUS on the #CleanPowerPlan: http:\/\/t.co\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 83, 89 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/635969099470872576\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/tPEU9NpgFU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNNqXjMWcAAZ47c.jpg",
        "id_str" : "635968925205950464",
        "id" : 635968925205950464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNNqXjMWcAAZ47c.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 1201
        } ],
        "display_url" : "pic.twitter.com\/tPEU9NpgFU"
      } ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 97, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635969099470872576",
    "text" : "\"The single most important step America has ever taken to combat climate change.\" \u2014@POTUS on the #CleanPowerPlan: http:\/\/t.co\/tPEU9NpgFU",
    "id" : 635969099470872576,
    "created_at" : "2015-08-25 00:17:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 635969207457423360,
  "created_at" : "2015-08-25 00:17:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/WHt0jT8KmX",
      "expanded_url" : "http:\/\/go.wh.gov\/ChN8xt",
      "display_url" : "go.wh.gov\/ChN8xt"
    } ]
  },
  "geo" : { },
  "id_str" : "635968713464922112",
  "text" : "\"No challenge poses a greater threat to our future than climate change.\" \u2014@POTUS: http:\/\/t.co\/WHt0jT8KmX #ActOnClimate",
  "id" : 635968713464922112,
  "created_at" : "2015-08-25 00:15:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/635897933703983104\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/EjZXxHbIWU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNMppnMWIAAaasg.jpg",
      "id_str" : "635897767261511680",
      "id" : 635897767261511680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNMppnMWIAAaasg.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EjZXxHbIWU"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/L4sRUMEvmX",
      "expanded_url" : "http:\/\/go.wh.gov\/2dAmXW",
      "display_url" : "go.wh.gov\/2dAmXW"
    } ]
  },
  "geo" : { },
  "id_str" : "635967939146027010",
  "text" : "Watch @POTUS announce new steps to move America toward a clean energy future \u2192 http:\/\/t.co\/L4sRUMEvmX #ActOnClimate http:\/\/t.co\/EjZXxHbIWU",
  "id" : 635967939146027010,
  "created_at" : "2015-08-25 00:12:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 22, 29 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635956602701512704",
  "text" : "RT @SecretaryCastro: .@HUDgov and the Obama Administration are proud to invest in American families and in the future of our planet. #ActOn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUDgov",
        "screen_name" : "HUDgov",
        "indices" : [ 1, 8 ],
        "id_str" : "19948202",
        "id" : 19948202
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 112, 125 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "635861505859260416",
    "geo" : { },
    "id_str" : "635861560347525120",
    "in_reply_to_user_id" : 2695663285,
    "text" : ".@HUDgov and the Obama Administration are proud to invest in American families and in the future of our planet. #ActOnClimate",
    "id" : 635861560347525120,
    "in_reply_to_status_id" : 635861505859260416,
    "created_at" : "2015-08-24 17:09:44 +0000",
    "in_reply_to_screen_name" : "SecretaryCastro",
    "in_reply_to_user_id_str" : "2695663285",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 635956602701512704,
  "created_at" : "2015-08-24 23:27:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 54, 61 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solar",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/IYKmh0VZf2",
      "expanded_url" : "http:\/\/1.usa.gov\/1hCYPUL",
      "display_url" : "1.usa.gov\/1hCYPUL"
    } ]
  },
  "geo" : { },
  "id_str" : "635952745728471040",
  "text" : "RT @ErnestMoniz: Big news from @POTUS: $1 Billion for @Energy projects like methane capture &amp; rooftop #solar: http:\/\/t.co\/IYKmh0VZf2 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 14, 20 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Energy Department",
        "screen_name" : "ENERGY",
        "indices" : [ 37, 44 ],
        "id_str" : "166252256",
        "id" : 166252256
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ErnestMoniz\/status\/635891766412058624\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/KDKqobVmfu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNMkMRfWoAEivui.png",
        "id_str" : "635891765661310977",
        "id" : 635891765661310977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNMkMRfWoAEivui.png",
        "sizes" : [ {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 939
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 345,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 939
        } ],
        "display_url" : "pic.twitter.com\/KDKqobVmfu"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/ErnestMoniz\/status\/635891766412058624\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/KDKqobVmfu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNMkMOQWEAAr_Qt.png",
        "id_str" : "635891764793053184",
        "id" : 635891764793053184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNMkMOQWEAAr_Qt.png",
        "sizes" : [ {
          "h" : 422,
          "resize" : "fit",
          "w" : 647
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 647
        }, {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KDKqobVmfu"
      } ],
      "hashtags" : [ {
        "text" : "solar",
        "indices" : [ 89, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/IYKmh0VZf2",
        "expanded_url" : "http:\/\/1.usa.gov\/1hCYPUL",
        "display_url" : "1.usa.gov\/1hCYPUL"
      } ]
    },
    "geo" : { },
    "id_str" : "635891766412058624",
    "text" : "Big news from @POTUS: $1 Billion for @Energy projects like methane capture &amp; rooftop #solar: http:\/\/t.co\/IYKmh0VZf2 http:\/\/t.co\/KDKqobVmfu",
    "id" : 635891766412058624,
    "created_at" : "2015-08-24 19:09:46 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 635952745728471040,
  "created_at" : "2015-08-24 23:12:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/a5BDHjPoLt",
      "expanded_url" : "http:\/\/go.wh.gov\/2dAmXW",
      "display_url" : "go.wh.gov\/2dAmXW"
    } ]
  },
  "geo" : { },
  "id_str" : "635947978172289025",
  "text" : "RT @WHLive: At 8pm ET, @POTUS is announcing new commitments to clean energy technology: http:\/\/t.co\/a5BDHjPoLt #ActOnClimate http:\/\/t.co\/kr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/635897933703983104\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/krOmIIDhfp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNMppnMWIAAaasg.jpg",
        "id_str" : "635897767261511680",
        "id" : 635897767261511680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNMppnMWIAAaasg.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/krOmIIDhfp"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/a5BDHjPoLt",
        "expanded_url" : "http:\/\/go.wh.gov\/2dAmXW",
        "display_url" : "go.wh.gov\/2dAmXW"
      } ]
    },
    "geo" : { },
    "id_str" : "635946902261886976",
    "text" : "At 8pm ET, @POTUS is announcing new commitments to clean energy technology: http:\/\/t.co\/a5BDHjPoLt #ActOnClimate http:\/\/t.co\/krOmIIDhfp",
    "id" : 635946902261886976,
    "created_at" : "2015-08-24 22:48:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 635947978172289025,
  "created_at" : "2015-08-24 22:53:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/WHt0jTqlev",
      "expanded_url" : "http:\/\/go.wh.gov\/ChN8xt",
      "display_url" : "go.wh.gov\/ChN8xt"
    } ]
  },
  "geo" : { },
  "id_str" : "635939856468709380",
  "text" : "Solar energy commitments to 40+ bases will:\nSave military families $ \u2713\nMake military communities more energy secure \u2713\nhttp:\/\/t.co\/WHt0jTqlev",
  "id" : 635939856468709380,
  "created_at" : "2015-08-24 22:20:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Moulton",
      "screen_name" : "sethmoulton",
      "indices" : [ 60, 72 ],
      "id_str" : "248495200",
      "id" : 248495200
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/xBwUUTAUE8",
      "expanded_url" : "http:\/\/go.wh.gov\/Zxdnvr",
      "display_url" : "go.wh.gov\/Zxdnvr"
    } ]
  },
  "geo" : { },
  "id_str" : "635919600102735872",
  "text" : "\"As a combat veteran, I know the cost of war.\" \u2014Congressman @SethMoulton on supporting the #IranDeal: http:\/\/t.co\/xBwUUTAUE8",
  "id" : 635919600102735872,
  "created_at" : "2015-08-24 21:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "MAKERS",
      "screen_name" : "MAKERSwomen",
      "indices" : [ 35, 47 ],
      "id_str" : "491350825",
      "id" : 491350825
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 68, 76 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 111, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635908160297943044",
  "text" : "RT @vj44: So excited to be part of @MAKERSwomen! Join me for a LIVE @twitter chat 8\/26 11am EST. Tweet me your #WomensEqualityDay questions\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MAKERS",
        "screen_name" : "MAKERSwomen",
        "indices" : [ 25, 37 ],
        "id_str" : "491350825",
        "id" : 491350825
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 58, 66 ],
        "id_str" : "783214",
        "id" : 783214
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 133, 138 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 101, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635895093396836352",
    "text" : "So excited to be part of @MAKERSwomen! Join me for a LIVE @twitter chat 8\/26 11am EST. Tweet me your #WomensEqualityDay questions to @vj44",
    "id" : 635895093396836352,
    "created_at" : "2015-08-24 19:22:59 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 635908160297943044,
  "created_at" : "2015-08-24 20:14:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/635901792740446208\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/x7YluMJwF9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNMtK_AVAAAfsww.jpg",
      "id_str" : "635901639124123648",
      "id" : 635901639124123648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNMtK_AVAAAfsww.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/x7YluMJwF9"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/WHt0jTqlev",
      "expanded_url" : "http:\/\/go.wh.gov\/ChN8xt",
      "display_url" : "go.wh.gov\/ChN8xt"
    } ]
  },
  "geo" : { },
  "id_str" : "635901792740446208",
  "text" : "We're making it easier for homeowners to put solar panels on the roof with PACE: http:\/\/t.co\/WHt0jTqlev #ActOnClimate http:\/\/t.co\/x7YluMJwF9",
  "id" : 635901792740446208,
  "created_at" : "2015-08-24 19:49:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/635897933703983104\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/EjZXxHbIWU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNMppnMWIAAaasg.jpg",
      "id_str" : "635897767261511680",
      "id" : 635897767261511680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNMppnMWIAAaasg.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EjZXxHbIWU"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 4, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/WHt0jTqlev",
      "expanded_url" : "http:\/\/go.wh.gov\/ChN8xt",
      "display_url" : "go.wh.gov\/ChN8xt"
    } ]
  },
  "geo" : { },
  "id_str" : "635897933703983104",
  "text" : "Big #ActOnClimate news today: @POTUS is announcing $1 billion in new clean energy commitments: http:\/\/t.co\/WHt0jTqlev http:\/\/t.co\/EjZXxHbIWU",
  "id" : 635897933703983104,
  "created_at" : "2015-08-24 19:34:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Moulton",
      "screen_name" : "sethmoulton",
      "indices" : [ 3, 15 ],
      "id_str" : "248495200",
      "id" : 248495200
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 95, 106 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635890661540007936",
  "text" : "RT @sethmoulton: My experience as a combat vet informs my support for the #IranDeal. Read more @WhiteHouse and tell me what you think: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 78, 89 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/kY0Spo7r0G",
        "expanded_url" : "http:\/\/1.usa.gov\/1fBHsld",
        "display_url" : "1.usa.gov\/1fBHsld"
      } ]
    },
    "geo" : { },
    "id_str" : "635887282608820225",
    "text" : "My experience as a combat vet informs my support for the #IranDeal. Read more @WhiteHouse and tell me what you think: http:\/\/t.co\/kY0Spo7r0G",
    "id" : 635887282608820225,
    "created_at" : "2015-08-24 18:51:57 +0000",
    "user" : {
      "name" : "Seth Moulton",
      "screen_name" : "sethmoulton",
      "protected" : false,
      "id_str" : "248495200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/530114548854845440\/ceX1JfaZ_normal.png",
      "id" : 248495200,
      "verified" : true
    }
  },
  "id" : 635890661540007936,
  "created_at" : "2015-08-24 19:05:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "Sen. Debbie Stabenow",
      "screen_name" : "SenStabenow",
      "indices" : [ 22, 34 ],
      "id_str" : "76456274",
      "id" : 76456274
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/635836541462446080\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/lA7uoOXvEw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CNLulPMUcAAmUfN.png",
      "id_str" : "635832820913434624",
      "id" : 635832820913434624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNLulPMUcAAmUfN.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com\/lA7uoOXvEw"
    } ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/AgniK4vbOl",
      "expanded_url" : "http:\/\/1.usa.gov\/1EQWtWX",
      "display_url" : "1.usa.gov\/1EQWtWX"
    } ]
  },
  "geo" : { },
  "id_str" : "635840095862390784",
  "text" : "RT @TheIranDeal: Read @SenStabenow's statement on why she supports the #Iran Deal \u2192 http:\/\/t.co\/AgniK4vbOl http:\/\/t.co\/lA7uoOXvEw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sen. Debbie Stabenow",
        "screen_name" : "SenStabenow",
        "indices" : [ 5, 17 ],
        "id_str" : "76456274",
        "id" : 76456274
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/635836541462446080\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/lA7uoOXvEw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CNLulPMUcAAmUfN.png",
        "id_str" : "635832820913434624",
        "id" : 635832820913434624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CNLulPMUcAAmUfN.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 394,
          "resize" : "fit",
          "w" : 648
        } ],
        "display_url" : "pic.twitter.com\/lA7uoOXvEw"
      } ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 54, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/AgniK4vbOl",
        "expanded_url" : "http:\/\/1.usa.gov\/1EQWtWX",
        "display_url" : "1.usa.gov\/1EQWtWX"
      } ]
    },
    "geo" : { },
    "id_str" : "635836541462446080",
    "text" : "Read @SenStabenow's statement on why she supports the #Iran Deal \u2192 http:\/\/t.co\/AgniK4vbOl http:\/\/t.co\/lA7uoOXvEw",
    "id" : 635836541462446080,
    "created_at" : "2015-08-24 15:30:19 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 635840095862390784,
  "created_at" : "2015-08-24 15:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/qryxtoG216",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/7e7a6ce9-5279-464e-94db-05d00d75d9bc",
      "display_url" : "amp.twimg.com\/v\/7e7a6ce9-527\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635813048461037568",
  "text" : "Getting ready for the week ahead? Check out a sneak peek of what's coming up this week at the White House:\nhttps:\/\/t.co\/qryxtoG216",
  "id" : 635813048461037568,
  "created_at" : "2015-08-24 13:56:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635555759531683840",
  "text" : "RT @SenatorReid: I strongly support the historic agreement with Iran and will do everything in my power to ensure that it stands. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/o79wQeYTof",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/politics\/harry-reid-endorses-iran-deal-giving-boost-to-obamas-supporters\/2015\/08\/23\/8fb89a40-49c0-11e5-846d-02792f854297_story.html",
        "display_url" : "washingtonpost.com\/politics\/harry\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "635537098968313857",
    "text" : "I strongly support the historic agreement with Iran and will do everything in my power to ensure that it stands. http:\/\/t.co\/o79wQeYTof",
    "id" : 635537098968313857,
    "created_at" : "2015-08-23 19:40:26 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 635555759531683840,
  "created_at" : "2015-08-23 20:54:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/bwLlqUqffG",
      "expanded_url" : "http:\/\/snpy.tv\/1I2xlfU",
      "display_url" : "snpy.tv\/1I2xlfU"
    } ]
  },
  "geo" : { },
  "id_str" : "635542074004103168",
  "text" : "\"When Congress gets back, they should prevent a shutdown, pass a responsible budget.\" \u2014@POTUS: http:\/\/t.co\/bwLlqUqffG",
  "id" : 635542074004103168,
  "created_at" : "2015-08-23 20:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewExIm",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/bwLlqUqffG",
      "expanded_url" : "http:\/\/snpy.tv\/1I2xlfU",
      "display_url" : "snpy.tv\/1I2xlfU"
    } ]
  },
  "geo" : { },
  "id_str" : "635511891675123712",
  "text" : "\"Congress failed to reauthorize the Export-Import Bank...That\u2019s not good for jobs.\" \u2014@POTUS: http:\/\/t.co\/bwLlqUqffG #RenewExIm",
  "id" : 635511891675123712,
  "created_at" : "2015-08-23 18:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/3yG3fYwuDO",
      "expanded_url" : "http:\/\/go.wh.gov\/Rtoycy",
      "display_url" : "go.wh.gov\/Rtoycy"
    } ]
  },
  "geo" : { },
  "id_str" : "635490933056757760",
  "text" : "\"34 states have increased funding for preschool. And that\u2019s good for all of us.\" \u2014@POTUS: http:\/\/t.co\/3yG3fYwuDO",
  "id" : 635490933056757760,
  "created_at" : "2015-08-23 16:36:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Zoo",
      "screen_name" : "NationalZoo",
      "indices" : [ 3, 15 ],
      "id_str" : "17045060",
      "id" : 17045060
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PandaStory",
      "indices" : [ 84, 95 ]
    }, {
      "text" : "WeSaveSpecies",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635264061467443200",
  "text" : "RT @NationalZoo: Panda cub born at 5:34pm live on panda cam. Video and pix to come. #PandaStory #WeSaveSpecies",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PandaStory",
        "indices" : [ 67, 78 ]
      }, {
        "text" : "WeSaveSpecies",
        "indices" : [ 79, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "635204518033104896",
    "text" : "Panda cub born at 5:34pm live on panda cam. Video and pix to come. #PandaStory #WeSaveSpecies",
    "id" : 635204518033104896,
    "created_at" : "2015-08-22 21:38:53 +0000",
    "user" : {
      "name" : "National Zoo",
      "screen_name" : "NationalZoo",
      "protected" : false,
      "id_str" : "17045060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671384071294070784\/HCjIdoN9_normal.jpg",
      "id" : 17045060,
      "verified" : true
    }
  },
  "id" : 635264061467443200,
  "created_at" : "2015-08-23 01:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/bwLlqUqffG",
      "expanded_url" : "http:\/\/snpy.tv\/1I2xlfU",
      "display_url" : "snpy.tv\/1I2xlfU"
    } ]
  },
  "geo" : { },
  "id_str" : "635157025245167616",
  "text" : "\"17 states, and more than two dozen cities and counties, have raised their minimum wage\" \u2014@POTUS: http:\/\/t.co\/bwLlqUqffG #RaiseTheWage",
  "id" : 635157025245167616,
  "created_at" : "2015-08-22 18:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/bwLlqUqffG",
      "expanded_url" : "http:\/\/snpy.tv\/1I2xlfU",
      "display_url" : "snpy.tv\/1I2xlfU"
    } ]
  },
  "geo" : { },
  "id_str" : "635141922915401728",
  "text" : "\"Over the past few years, nearly 20 cities and counties have implemented paid sick days.\" \u2014@POTUS: http:\/\/t.co\/bwLlqUqffG #LeadOnLeave",
  "id" : 635141922915401728,
  "created_at" : "2015-08-22 17:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/629658184395956225\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0Q8Si5Eipr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLz-puHWgAA0VMa.jpg",
      "id_str" : "629658040631984128",
      "id" : 629658040631984128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLz-puHWgAA0VMa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0Q8Si5Eipr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/bwLlqUqffG",
      "expanded_url" : "http:\/\/snpy.tv\/1I2xlfU",
      "display_url" : "snpy.tv\/1I2xlfU"
    } ]
  },
  "geo" : { },
  "id_str" : "635126827262935042",
  "text" : "\"Our businesses have created 13 million new jobs over the past five and a half years\" \u2014@POTUS: http:\/\/t.co\/bwLlqUqffG http:\/\/t.co\/0Q8Si5Eipr",
  "id" : 635126827262935042,
  "created_at" : "2015-08-22 16:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/bwLlqUqffG",
      "expanded_url" : "http:\/\/snpy.tv\/1I2xlfU",
      "display_url" : "snpy.tv\/1I2xlfU"
    } ]
  },
  "geo" : { },
  "id_str" : "635110934541811712",
  "text" : "Watch President Obama's weekly address on why it's time for Congress to pass a responsible budget: http:\/\/t.co\/bwLlqUqffG",
  "id" : 635110934541811712,
  "created_at" : "2015-08-22 15:27:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/634877693763260416\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/EvswLDk5F9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM9wF-NWgAAAtr2.jpg",
      "id_str" : "634849320383184896",
      "id" : 634849320383184896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM9wF-NWgAAAtr2.jpg",
      "sizes" : [ {
        "h" : 1855,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EvswLDk5F9"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/ipt5tEQKLD",
      "expanded_url" : "http:\/\/LettersToPresidentObama.tumblr.com",
      "display_url" : "LettersToPresidentObama.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "634877693763260416",
  "text" : "\"It was something we never thought we'd see.\"\nRead Kathy &amp; Julie's letter to @POTUS:\nhttp:\/\/t.co\/ipt5tEQKLD #LoveWins http:\/\/t.co\/EvswLDk5F9",
  "id" : 634877693763260416,
  "created_at" : "2015-08-22 00:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/xQDERBPXgB",
      "expanded_url" : "http:\/\/wh.gov\/climate",
      "display_url" : "wh.gov\/climate"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/cDXf5vDWk0",
      "expanded_url" : "http:\/\/snpy.tv\/1NKRCvz",
      "display_url" : "snpy.tv\/1NKRCvz"
    } ]
  },
  "geo" : { },
  "id_str" : "634862610958016512",
  "text" : "Hear the stories of students and educators from around the country working to #ActOnClimate: http:\/\/t.co\/xQDERBPXgB http:\/\/t.co\/cDXf5vDWk0",
  "id" : 634862610958016512,
  "created_at" : "2015-08-21 23:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 3, 10 ],
      "id_str" : "52484614",
      "id" : 52484614
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tumblr\/status\/634515351691247616\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/r2GIz1tprD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM5AWa3WIAA1uK8.jpg",
      "id_str" : "634515351418576896",
      "id" : 634515351418576896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM5AWa3WIAA1uK8.jpg",
      "sizes" : [ {
        "h" : 121,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 169,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/r2GIz1tprD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/2vszTLoCxz",
      "expanded_url" : "http:\/\/tumblr.co\/RaCi1",
      "display_url" : "tumblr.co\/RaCi1"
    } ]
  },
  "geo" : { },
  "id_str" : "634852120655622145",
  "text" : "RT @tumblr: The @WhiteHouse has started a new Tumblr. Check out Letters to President Obama. http:\/\/t.co\/2vszTLoCxz http:\/\/t.co\/r2GIz1tprD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tumblr\/status\/634515351691247616\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/r2GIz1tprD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM5AWa3WIAA1uK8.jpg",
        "id_str" : "634515351418576896",
        "id" : 634515351418576896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM5AWa3WIAA1uK8.jpg",
        "sizes" : [ {
          "h" : 121,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 169,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 169,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 169,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/r2GIz1tprD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/2vszTLoCxz",
        "expanded_url" : "http:\/\/tumblr.co\/RaCi1",
        "display_url" : "tumblr.co\/RaCi1"
      } ]
    },
    "geo" : { },
    "id_str" : "634515351691247616",
    "text" : "The @WhiteHouse has started a new Tumblr. Check out Letters to President Obama. http:\/\/t.co\/2vszTLoCxz http:\/\/t.co\/r2GIz1tprD",
    "id" : 634515351691247616,
    "created_at" : "2015-08-21 00:00:23 +0000",
    "user" : {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "protected" : false,
      "id_str" : "52484614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791014307089747968\/jqxriE5C_normal.jpg",
      "id" : 52484614,
      "verified" : true
    }
  },
  "id" : 634852120655622145,
  "created_at" : "2015-08-21 22:18:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/cDXf5vDWk0",
      "expanded_url" : "http:\/\/snpy.tv\/1NKRCvz",
      "display_url" : "snpy.tv\/1NKRCvz"
    } ]
  },
  "geo" : { },
  "id_str" : "634847542740561920",
  "text" : "\"My advice to any students that would like to be involved in climate change is to be fearless.\" #ActOnClimate http:\/\/t.co\/cDXf5vDWk0",
  "id" : 634847542740561920,
  "created_at" : "2015-08-21 22:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/cDXf5vmlss",
      "expanded_url" : "http:\/\/snpy.tv\/1NKRCvz",
      "display_url" : "snpy.tv\/1NKRCvz"
    } ]
  },
  "geo" : { },
  "id_str" : "634835323114102784",
  "text" : "Watch students from our Back-To-School Climate Education Event tell their stories about working to #ActOnClimate: http:\/\/t.co\/cDXf5vmlss",
  "id" : 634835323114102784,
  "created_at" : "2015-08-21 21:11:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 77, 84 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/bw80WHX25Z",
      "expanded_url" : "http:\/\/bit.ly\/1KabwkD",
      "display_url" : "bit.ly\/1KabwkD"
    } ]
  },
  "geo" : { },
  "id_str" : "634742079499866112",
  "text" : "Tune in at 11am ET to watch the first two women in history graduate from the @USArmy's Ranger School: http:\/\/t.co\/bw80WHX25Z",
  "id" : 634742079499866112,
  "created_at" : "2015-08-21 15:01:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Rep. Nadler)))",
      "screen_name" : "RepJerryNadler",
      "indices" : [ 3, 18 ],
      "id_str" : "40302336",
      "id" : 40302336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634729501134467072",
  "text" : "RT @RepJerryNadler: Congressman Nadler Announces Support for the Iran Nuclear Agreement, Condemns Troubling Rhetoric. Read full statement h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/eDrKucIJBj",
        "expanded_url" : "http:\/\/nadler.house.gov\/press-release\/congressman-nadler-announces-support-iran-nuclear-agreement-condemns-troubling",
        "display_url" : "nadler.house.gov\/press-release\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634723377371041792",
    "text" : "Congressman Nadler Announces Support for the Iran Nuclear Agreement, Condemns Troubling Rhetoric. Read full statement http:\/\/t.co\/eDrKucIJBj",
    "id" : 634723377371041792,
    "created_at" : "2015-08-21 13:47:00 +0000",
    "user" : {
      "name" : "(((Rep. Nadler)))",
      "screen_name" : "RepJerryNadler",
      "protected" : false,
      "id_str" : "40302336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000675065729\/bbd633a57e8333412d6147bbc077427d_normal.jpeg",
      "id" : 40302336,
      "verified" : true
    }
  },
  "id" : 634729501134467072,
  "created_at" : "2015-08-21 14:11:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ErnestMoniz\/status\/634448873528889345\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/i2QTRczjxZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4D45KXAAA9TuQ.png",
      "id_str" : "634448873457647616",
      "id" : 634448873457647616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4D45KXAAA9TuQ.png",
      "sizes" : [ {
        "h" : 169,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 997
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 997
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/i2QTRczjxZ"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634499818384179201",
  "text" : "RT @ErnestMoniz: FACT: the #IranDeal mandates the most robust nuclear inspections ever peacefully negotiated. @POTUS http:\/\/t.co\/i2QTRczjxZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 93, 99 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ErnestMoniz\/status\/634448873528889345\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/i2QTRczjxZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4D45KXAAA9TuQ.png",
        "id_str" : "634448873457647616",
        "id" : 634448873457647616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4D45KXAAA9TuQ.png",
        "sizes" : [ {
          "h" : 169,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 997
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 997
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/i2QTRczjxZ"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 10, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634448873528889345",
    "text" : "FACT: the #IranDeal mandates the most robust nuclear inspections ever peacefully negotiated. @POTUS http:\/\/t.co\/i2QTRczjxZ",
    "id" : 634448873528889345,
    "created_at" : "2015-08-20 19:36:13 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 634499818384179201,
  "created_at" : "2015-08-20 22:58:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/634468502343127040\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/5iGwNwvaxi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM4VoK7WsAARDYP.jpg",
      "id_str" : "634468377378074624",
      "id" : 634468377378074624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM4VoK7WsAARDYP.jpg",
      "sizes" : [ {
        "h" : 441,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/5iGwNwvaxi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/jId1xhptxS",
      "expanded_url" : "http:\/\/LettersToPresidentObama.Tumblr.com",
      "display_url" : "LettersToPresidentObama.Tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "634468502343127040",
  "text" : "\"I wrote President Obama a letter straight from my heart...and he actually read it!\" http:\/\/t.co\/jId1xhptxS http:\/\/t.co\/5iGwNwvaxi",
  "id" : 634468502343127040,
  "created_at" : "2015-08-20 20:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/HkSzfhaIWm",
      "expanded_url" : "http:\/\/on.mash.to\/1UVnrG4",
      "display_url" : "on.mash.to\/1UVnrG4"
    } ]
  },
  "geo" : { },
  "id_str" : "634452566215102465",
  "text" : "RT @mashable: President Obama gets a lot of mail, and now the White House is posting it to Tumblr http:\/\/t.co\/HkSzfhaIWm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/HkSzfhaIWm",
        "expanded_url" : "http:\/\/on.mash.to\/1UVnrG4",
        "display_url" : "on.mash.to\/1UVnrG4"
      } ]
    },
    "geo" : { },
    "id_str" : "634404787811971076",
    "text" : "President Obama gets a lot of mail, and now the White House is posting it to Tumblr http:\/\/t.co\/HkSzfhaIWm",
    "id" : 634404787811971076,
    "created_at" : "2015-08-20 16:41:02 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760998040949841922\/XT79xzRT_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 634452566215102465,
  "created_at" : "2015-08-20 19:50:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634414019638599681",
  "text" : "RT @POTUS: President Carter is as good a man as they come. Michelle and I are praying for him and Rosalynn. We're all pulling for you, Jimm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634413305516412928",
    "text" : "President Carter is as good a man as they come. Michelle and I are praying for him and Rosalynn. We're all pulling for you, Jimmy.",
    "id" : 634413305516412928,
    "created_at" : "2015-08-20 17:14:53 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 634414019638599681,
  "created_at" : "2015-08-20 17:17:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634399814696894464",
  "text" : "RT @SecretaryJewell: My heart goes out to families &amp; fellow firefighters of the fallen heroes as we mourn their loss in service to others. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/wFfxC7XyIQ",
        "expanded_url" : "http:\/\/on.doi.gov\/1J7UCz1",
        "display_url" : "on.doi.gov\/1J7UCz1"
      } ]
    },
    "geo" : { },
    "id_str" : "634389684601364480",
    "text" : "My heart goes out to families &amp; fellow firefighters of the fallen heroes as we mourn their loss in service to others. http:\/\/t.co\/wFfxC7XyIQ",
    "id" : 634389684601364480,
    "created_at" : "2015-08-20 15:41:01 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 634399814696894464,
  "created_at" : "2015-08-20 16:21:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 42, 49 ],
      "id_str" : "52484614",
      "id" : 52484614
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/634383443262967808\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/KNbwKuQFkC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM3IPRgWoAA5_9j.jpg",
      "id_str" : "634383287251804160",
      "id" : 634383287251804160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM3IPRgWoAA5_9j.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/KNbwKuQFkC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/jId1xh7S9i",
      "expanded_url" : "http:\/\/LettersToPresidentObama.Tumblr.com",
      "display_url" : "LettersToPresidentObama.Tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "634383443262967808",
  "text" : "Introducing http:\/\/t.co\/jId1xh7S9i, a new @Tumblr to showcase letters Americans have written to @POTUS. http:\/\/t.co\/KNbwKuQFkC",
  "id" : 634383443262967808,
  "created_at" : "2015-08-20 15:16:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/634380557330313216\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/JnG6E04yXo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM3FuyUWoAAwLY-.jpg",
      "id_str" : "634380530100903936",
      "id" : 634380530100903936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM3FuyUWoAAwLY-.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/JnG6E04yXo"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 0, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Y95bMnQdPM",
      "expanded_url" : "http:\/\/wpo.st\/YYzV0",
      "display_url" : "wpo.st\/YYzV0"
    } ]
  },
  "geo" : { },
  "id_str" : "634380557330313216",
  "text" : "#MyBrothersKeeper in action: Check out White House mentee Noah McQueen's inspiring story \u2192 http:\/\/t.co\/Y95bMnQdPM http:\/\/t.co\/JnG6E04yXo",
  "id" : 634380557330313216,
  "created_at" : "2015-08-20 15:04:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "indices" : [ 3, 8 ],
      "id_str" : "14342564",
      "id" : 14342564
    }, {
      "name" : "NOAA NCEI Climate",
      "screen_name" : "NOAANCEIclimate",
      "indices" : [ 72, 88 ],
      "id_str" : "916735110",
      "id" : 916735110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfClimate",
      "indices" : [ 89, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/XGv9BkJJsT",
      "expanded_url" : "http:\/\/1.usa.gov\/1PjEWMC",
      "display_url" : "1.usa.gov\/1PjEWMC"
    } ]
  },
  "geo" : { },
  "id_str" : "634374703004680193",
  "text" : "RT @NOAA: JUST IN: July 2015 warmest month ever recorded for globe says @NOAANCEIclimate #StateOfClimate http:\/\/t.co\/XGv9BkJJsT http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NOAA NCEI Climate",
        "screen_name" : "NOAANCEIclimate",
        "indices" : [ 62, 78 ],
        "id_str" : "916735110",
        "id" : 916735110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NOAA\/status\/634373469090770944\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/MPmobyGAK7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CM2_HFLWUAAZeDi.png",
        "id_str" : "634373250898874368",
        "id" : 634373250898874368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM2_HFLWUAAZeDi.png",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        } ],
        "display_url" : "pic.twitter.com\/MPmobyGAK7"
      } ],
      "hashtags" : [ {
        "text" : "StateOfClimate",
        "indices" : [ 79, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/XGv9BkJJsT",
        "expanded_url" : "http:\/\/1.usa.gov\/1PjEWMC",
        "display_url" : "1.usa.gov\/1PjEWMC"
      } ]
    },
    "geo" : { },
    "id_str" : "634373469090770944",
    "text" : "JUST IN: July 2015 warmest month ever recorded for globe says @NOAANCEIclimate #StateOfClimate http:\/\/t.co\/XGv9BkJJsT http:\/\/t.co\/MPmobyGAK7",
    "id" : 634373469090770944,
    "created_at" : "2015-08-20 14:36:35 +0000",
    "user" : {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "protected" : false,
      "id_str" : "14342564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529277799018676225\/MOsMKe14_normal.jpeg",
      "id" : 14342564,
      "verified" : true
    }
  },
  "id" : 634374703004680193,
  "created_at" : "2015-08-20 14:41:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/FRdWhGDGKk",
      "expanded_url" : "http:\/\/s.nj.com\/SzNkt9E",
      "display_url" : "s.nj.com\/SzNkt9E"
    } ]
  },
  "geo" : { },
  "id_str" : "634369424431165440",
  "text" : "\"We have the opportunity to make the world safer for our children without resorting to war\" \u2014@POTUS on the #IranDeal: http:\/\/t.co\/FRdWhGDGKk",
  "id" : 634369424431165440,
  "created_at" : "2015-08-20 14:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634355568921190400",
  "text" : "RT @whitehouseostp: Learn more about new Administration &amp; supporting efforts to #ActOnClimate through climate ed and literacy at http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 64, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/M3uCT7b6MQ",
        "expanded_url" : "http:\/\/wh.gov\/sites\/default\/files\/microsites\/ostp\/climate_ed_fact_sheet.pdf",
        "display_url" : "wh.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634351153279467523",
    "text" : "Learn more about new Administration &amp; supporting efforts to #ActOnClimate through climate ed and literacy at http:\/\/t.co\/M3uCT7b6MQ",
    "id" : 634351153279467523,
    "created_at" : "2015-08-20 13:07:55 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 634355568921190400,
  "created_at" : "2015-08-20 13:25:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/634131544135876608\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ifJBC8DPMN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMzjEb_WwAIADYa.jpg",
      "id_str" : "634131312924868610",
      "id" : 634131312924868610,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMzjEb_WwAIADYa.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ifJBC8DPMN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/J9NbJbFFhH",
      "expanded_url" : "http:\/\/go.wh.gov\/StartupDay2015",
      "display_url" : "go.wh.gov\/StartupDay2015"
    } ]
  },
  "geo" : { },
  "id_str" : "634131544135876608",
  "text" : "Good ideas can come from anywhere.\nThat's why we're making it easier to start a business \u2192 http:\/\/t.co\/J9NbJbFFhH http:\/\/t.co\/ifJBC8DPMN",
  "id" : 634131544135876608,
  "created_at" : "2015-08-19 22:35:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/vBn6SvRFiJ",
      "expanded_url" : "http:\/\/on.msnbc.com\/1NDqe2z",
      "display_url" : "on.msnbc.com\/1NDqe2z"
    } ]
  },
  "geo" : { },
  "id_str" : "634109378858217474",
  "text" : "RT @TheIranDeal: What the former GOP chair of the Senate Foreign Relations Committee says about the #IranDeal: http:\/\/t.co\/vBn6SvRFiJ http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheIranDeal\/status\/634103819727597569\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Gm4BH0zS0M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMzIxlMWEAAN8Dh.jpg",
        "id_str" : "634102401675431936",
        "id" : 634102401675431936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMzIxlMWEAAN8Dh.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Gm4BH0zS0M"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/vBn6SvRFiJ",
        "expanded_url" : "http:\/\/on.msnbc.com\/1NDqe2z",
        "display_url" : "on.msnbc.com\/1NDqe2z"
      } ]
    },
    "geo" : { },
    "id_str" : "634103819727597569",
    "text" : "What the former GOP chair of the Senate Foreign Relations Committee says about the #IranDeal: http:\/\/t.co\/vBn6SvRFiJ http:\/\/t.co\/Gm4BH0zS0M",
    "id" : 634103819727597569,
    "created_at" : "2015-08-19 20:45:06 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 634109378858217474,
  "created_at" : "2015-08-19 21:07:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHData",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/KFX36wXrpn",
      "expanded_url" : "http:\/\/go.wh.gov\/PoliceData",
      "display_url" : "go.wh.gov\/PoliceData"
    } ]
  },
  "geo" : { },
  "id_str" : "634094642171146240",
  "text" : "Listen to how data science can help improve the relationship between police and the communities they serve \u2192 http:\/\/t.co\/KFX36wXrpn #WHData",
  "id" : 634094642171146240,
  "created_at" : "2015-08-19 20:08:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Joe Donnelly",
      "screen_name" : "SenDonnelly",
      "indices" : [ 3, 15 ],
      "id_str" : "216503958",
      "id" : 216503958
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SenDonnelly\/status\/634075981909753856\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/gl3qy7TB0b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMywvsNUYAAbCgj.png",
      "id_str" : "634075980919758848",
      "id" : 634075980919758848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMywvsNUYAAbCgj.png",
      "sizes" : [ {
        "h" : 506,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 493
      } ],
      "display_url" : "pic.twitter.com\/gl3qy7TB0b"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/KJaz8HTS2u",
      "expanded_url" : "http:\/\/1.usa.gov\/1JiEgTf",
      "display_url" : "1.usa.gov\/1JiEgTf"
    } ]
  },
  "geo" : { },
  "id_str" : "634076832082497536",
  "text" : "RT @SenDonnelly: Joe announced he will support the proposed Iran Nuclear Agreement. #IranDeal http:\/\/t.co\/KJaz8HTS2u http:\/\/t.co\/gl3qy7TB0b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenDonnelly\/status\/634075981909753856\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/gl3qy7TB0b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMywvsNUYAAbCgj.png",
        "id_str" : "634075980919758848",
        "id" : 634075980919758848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMywvsNUYAAbCgj.png",
        "sizes" : [ {
          "h" : 506,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 493
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 493
        }, {
          "h" : 734,
          "resize" : "fit",
          "w" : 493
        } ],
        "display_url" : "pic.twitter.com\/gl3qy7TB0b"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 67, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/KJaz8HTS2u",
        "expanded_url" : "http:\/\/1.usa.gov\/1JiEgTf",
        "display_url" : "1.usa.gov\/1JiEgTf"
      } ]
    },
    "geo" : { },
    "id_str" : "634075981909753856",
    "text" : "Joe announced he will support the proposed Iran Nuclear Agreement. #IranDeal http:\/\/t.co\/KJaz8HTS2u http:\/\/t.co\/gl3qy7TB0b",
    "id" : 634075981909753856,
    "created_at" : "2015-08-19 18:54:29 +0000",
    "user" : {
      "name" : "Senator Joe Donnelly",
      "screen_name" : "SenDonnelly",
      "protected" : false,
      "id_str" : "216503958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3056574144\/492143cf67a261108b6d06dafb5864b8_normal.jpeg",
      "id" : 216503958,
      "verified" : true
    }
  },
  "id" : 634076832082497536,
  "created_at" : "2015-08-19 18:57:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "Senator Joe Donnelly",
      "screen_name" : "SenDonnelly",
      "indices" : [ 18, 30 ],
      "id_str" : "216503958",
      "id" : 216503958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634068475984642048",
  "text" : "RT @TheIranDeal: .@SenDonnelly backs the #IranDeal: \"I owe it to the men and women of our Armed Forces...to have exhausted every other opti\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Joe Donnelly",
        "screen_name" : "SenDonnelly",
        "indices" : [ 1, 13 ],
        "id_str" : "216503958",
        "id" : 216503958
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 24, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "634065647186538496",
    "text" : ".@SenDonnelly backs the #IranDeal: \"I owe it to the men and women of our Armed Forces...to have exhausted every other option to stop Iran.\"",
    "id" : 634065647186538496,
    "created_at" : "2015-08-19 18:13:25 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 634068475984642048,
  "created_at" : "2015-08-19 18:24:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "indices" : [ 3, 11 ],
      "id_str" : "3274836392",
      "id" : 3274836392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "LeadOnTrade",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634058713637097473",
  "text" : "RT @Diana44: 300k businesses export, 98% are small biz. Huge opportunity to grow w\/ #TPP. More exports = more jobs. #LeadOnTrade https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 71, 75 ]
      }, {
        "text" : "LeadOnTrade",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DEeYObWjyR",
        "expanded_url" : "https:\/\/twitter.com\/thewayofshum\/status\/634050679020122112",
        "display_url" : "twitter.com\/thewayofshum\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634057544076554244",
    "text" : "300k businesses export, 98% are small biz. Huge opportunity to grow w\/ #TPP. More exports = more jobs. #LeadOnTrade https:\/\/t.co\/DEeYObWjyR",
    "id" : 634057544076554244,
    "created_at" : "2015-08-19 17:41:13 +0000",
    "user" : {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "protected" : false,
      "id_str" : "3274836392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671831357371191296\/CQ0VNiYR_normal.jpg",
      "id" : 3274836392,
      "verified" : true
    }
  },
  "id" : 634058713637097473,
  "created_at" : "2015-08-19 17:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Jared Polis",
      "screen_name" : "RepJaredPolis",
      "indices" : [ 31, 45 ],
      "id_str" : "463132556",
      "id" : 463132556
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartupDay",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/v55SyA51f3",
      "expanded_url" : "https:\/\/twitter.com\/RepJaredPolis\/status\/634030067367211008",
      "display_url" : "twitter.com\/RepJaredPolis\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634049728624259072",
  "text" : "Thanks for leading the charge, @RepJaredPolis. Small biz economy and our entrepreneurs need your voice. #StartupDay https:\/\/t.co\/v55SyA51f3",
  "id" : 634049728624259072,
  "created_at" : "2015-08-19 17:10:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/634048706627571712\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/2kSWAkhNB2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMyX5o7WEAAh_7j.jpg",
      "id_str" : "634048664047063040",
      "id" : 634048664047063040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMyX5o7WEAAh_7j.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2kSWAkhNB2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634048706627571712",
  "text" : "\"Michelle and I were saddened to learn of the passing of former Congressman Louis Stokes.\" \u2014@POTUS http:\/\/t.co\/2kSWAkhNB2",
  "id" : 634048706627571712,
  "created_at" : "2015-08-19 17:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "indices" : [ 3, 11 ],
      "id_str" : "3274836392",
      "id" : 3274836392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartupDay",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634040796673609728",
  "text" : "RT @Diana44: Happy #StartupDay from the WH! I'm taking your Qs at 1pm on steps we're taking to make starting a business easier. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StartupDay",
        "indices" : [ 6, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/blOy8rB9ff",
        "expanded_url" : "https:\/\/twitter.com\/USCTO\/status\/634005734800388097",
        "display_url" : "twitter.com\/USCTO\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "634016353666625536",
    "text" : "Happy #StartupDay from the WH! I'm taking your Qs at 1pm on steps we're taking to make starting a business easier. https:\/\/t.co\/blOy8rB9ff",
    "id" : 634016353666625536,
    "created_at" : "2015-08-19 14:57:32 +0000",
    "user" : {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "protected" : false,
      "id_str" : "3274836392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671831357371191296\/CQ0VNiYR_normal.jpg",
      "id" : 3274836392,
      "verified" : true
    }
  },
  "id" : 634040796673609728,
  "created_at" : "2015-08-19 16:34:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 3, 8 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    }, {
      "name" : "Debra",
      "screen_name" : "IamGoldie22",
      "indices" : [ 11, 23 ],
      "id_str" : "215136224",
      "id" : 215136224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/XFLvGBjJlS",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/precision-medicine",
      "display_url" : "whitehouse.gov\/precision-medi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634039683584909312",
  "text" : "RT @DJ44: .@IamGoldie22 We're stepping up our game big time on cancer through the Precision Medicine Iniative https:\/\/t.co\/XFLvGBjJlS.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Debra",
        "screen_name" : "IamGoldie22",
        "indices" : [ 1, 13 ],
        "id_str" : "215136224",
        "id" : 215136224
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/XFLvGBjJlS",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/precision-medicine",
        "display_url" : "whitehouse.gov\/precision-medi\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "634034918922842112",
    "geo" : { },
    "id_str" : "634039409671692288",
    "in_reply_to_user_id" : 215136224,
    "text" : ".@IamGoldie22 We're stepping up our game big time on cancer through the Precision Medicine Iniative https:\/\/t.co\/XFLvGBjJlS.",
    "id" : 634039409671692288,
    "in_reply_to_status_id" : 634034918922842112,
    "created_at" : "2015-08-19 16:29:09 +0000",
    "in_reply_to_screen_name" : "IamGoldie22",
    "in_reply_to_user_id_str" : "215136224",
    "user" : {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "protected" : false,
      "id_str" : "3030922321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570697565977313280\/aoCw1bC5_normal.jpeg",
      "id" : 3030922321,
      "verified" : true
    }
  },
  "id" : 634039683584909312,
  "created_at" : "2015-08-19 16:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 14, 19 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/634029710452756480\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/fgbl7gDseY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMyF2oIWEAAD8wp.jpg",
      "id_str" : "634028821084246016",
      "id" : 634028821084246016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMyF2oIWEAAD8wp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fgbl7gDseY"
    } ],
    "hashtags" : [ {
      "text" : "WHdata",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/feA68Ffl0m",
      "expanded_url" : "http:\/\/go.wh.gov\/WHdata",
      "display_url" : "go.wh.gov\/WHdata"
    } ]
  },
  "geo" : { },
  "id_str" : "634029710452756480",
  "text" : "Worth a read: @DJ44 on how we're using data to benefit all Americans \u2192 http:\/\/t.co\/feA68Ffl0m #WHdata http:\/\/t.co\/fgbl7gDseY",
  "id" : 634029710452756480,
  "created_at" : "2015-08-19 15:50:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 3, 8 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/FY0fvdaTT4",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/a-six-month-update-on-how-we-ve-been-using-data-and-how-it-benefits-all-americans-b1221b5cbb0e",
      "display_url" : "medium.com\/@WhiteHouse\/a-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "634012010858962944",
  "text" : "RT @DJ44: Here's my 6 month memo on our progress so far and plan ahead: https:\/\/t.co\/FY0fvdaTT4\nJoin in at noon for the twitter chat!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/FY0fvdaTT4",
        "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/a-six-month-update-on-how-we-ve-been-using-data-and-how-it-benefits-all-americans-b1221b5cbb0e",
        "display_url" : "medium.com\/@WhiteHouse\/a-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633988347992510464",
    "text" : "Here's my 6 month memo on our progress so far and plan ahead: https:\/\/t.co\/FY0fvdaTT4\nJoin in at noon for the twitter chat!",
    "id" : 633988347992510464,
    "created_at" : "2015-08-19 13:06:15 +0000",
    "user" : {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "protected" : false,
      "id_str" : "3030922321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570697565977313280\/aoCw1bC5_normal.jpeg",
      "id" : 3030922321,
      "verified" : true
    }
  },
  "id" : 634012010858962944,
  "created_at" : "2015-08-19 14:40:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "indices" : [ 3, 11 ],
      "id_str" : "3274836392",
      "id" : 3274836392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartupDay",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633764162045276160",
  "text" : "RT @Diana44: What's #StartupDay? Ask by tomorrow at 1pm. I'm taking Qs on steps we're taking to make it easier to start a business http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Diana44\/status\/633750725361733632\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/23EpUmhcpw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMuI5DhUAAAAu4y.jpg",
        "id_str" : "633750686354636800",
        "id" : 633750686354636800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMuI5DhUAAAAu4y.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/23EpUmhcpw"
      } ],
      "hashtags" : [ {
        "text" : "StartupDay",
        "indices" : [ 7, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633750725361733632",
    "text" : "What's #StartupDay? Ask by tomorrow at 1pm. I'm taking Qs on steps we're taking to make it easier to start a business http:\/\/t.co\/23EpUmhcpw",
    "id" : 633750725361733632,
    "created_at" : "2015-08-18 21:22:02 +0000",
    "user" : {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "protected" : false,
      "id_str" : "3274836392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671831357371191296\/CQ0VNiYR_normal.jpg",
      "id" : 3274836392,
      "verified" : true
    }
  },
  "id" : 633764162045276160,
  "created_at" : "2015-08-18 22:15:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheldon Whitehouse",
      "screen_name" : "SenWhitehouse",
      "indices" : [ 3, 17 ],
      "id_str" : "242555999",
      "id" : 242555999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633756141474852864",
  "text" : "RT @SenWhitehouse: I thank the many Rhode Islanders who shared their thoughts w\/ me about the #Iran deal. Here\u2019s why I\u2019ll support it: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenWhitehouse\/status\/633741847861395456\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/kRuUCk32E6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMuA2i9UsAQi56y.png",
        "id_str" : "633741847160991748",
        "id" : 633741847160991748,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMuA2i9UsAQi56y.png",
        "sizes" : [ {
          "h" : 209,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 118,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kRuUCk32E6"
      } ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 75, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "633741847861395456",
    "text" : "I thank the many Rhode Islanders who shared their thoughts w\/ me about the #Iran deal. Here\u2019s why I\u2019ll support it: http:\/\/t.co\/kRuUCk32E6",
    "id" : 633741847861395456,
    "created_at" : "2015-08-18 20:46:45 +0000",
    "user" : {
      "name" : "Sheldon Whitehouse",
      "screen_name" : "SenWhitehouse",
      "protected" : false,
      "id_str" : "242555999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000051321410\/55ff7ed4f6264c8eec19a81a66be6bb0_normal.png",
      "id" : 242555999,
      "verified" : true
    }
  },
  "id" : 633756141474852864,
  "created_at" : "2015-08-18 21:43:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "indices" : [ 3, 14 ],
      "id_str" : "562385224",
      "id" : 562385224
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/IKlhGPcmXK",
      "expanded_url" : "http:\/\/1.usa.gov\/1JfD1Zq",
      "display_url" : "1.usa.gov\/1JfD1Zq"
    } ]
  },
  "geo" : { },
  "id_str" : "633753263943258112",
  "text" : "RT @Abramson44: 29 localities have acted to #RaiseTheWage since @POTUS called for a \u2191\nProud Louisville is one: http:\/\/t.co\/IKlhGPcmXK http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 48, 54 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Abramson44\/status\/633752395386744835\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/8PxmPlXkw1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMuKchsUYAAiH31.jpg",
        "id_str" : "633752395260911616",
        "id" : 633752395260911616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMuKchsUYAAiH31.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8PxmPlXkw1"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 28, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/IKlhGPcmXK",
        "expanded_url" : "http:\/\/1.usa.gov\/1JfD1Zq",
        "display_url" : "1.usa.gov\/1JfD1Zq"
      } ]
    },
    "geo" : { },
    "id_str" : "633752395386744835",
    "text" : "29 localities have acted to #RaiseTheWage since @POTUS called for a \u2191\nProud Louisville is one: http:\/\/t.co\/IKlhGPcmXK http:\/\/t.co\/8PxmPlXkw1",
    "id" : 633752395386744835,
    "created_at" : "2015-08-18 21:28:40 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 633753263943258112,
  "created_at" : "2015-08-18 21:32:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Jack Reed",
      "screen_name" : "SenJackReed",
      "indices" : [ 3, 15 ],
      "id_str" : "486694111",
      "id" : 486694111
    }, {
      "name" : "Sheldon Whitehouse",
      "screen_name" : "SenWhitehouse",
      "indices" : [ 24, 38 ],
      "id_str" : "242555999",
      "id" : 242555999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/6JnFzOIYq5",
      "expanded_url" : "http:\/\/1.usa.gov\/1KuhY1z",
      "display_url" : "1.usa.gov\/1KuhY1z"
    } ]
  },
  "geo" : { },
  "id_str" : "633738516833275905",
  "text" : "RT @SenJackReed: Today, @SenWhitehouse &amp; I are announcing our support for the Iran nuclear agreement. Here is why: http:\/\/t.co\/6JnFzOIYq5 #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sheldon Whitehouse",
        "screen_name" : "SenWhitehouse",
        "indices" : [ 7, 21 ],
        "id_str" : "242555999",
        "id" : 242555999
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 125, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/6JnFzOIYq5",
        "expanded_url" : "http:\/\/1.usa.gov\/1KuhY1z",
        "display_url" : "1.usa.gov\/1KuhY1z"
      } ]
    },
    "geo" : { },
    "id_str" : "633735470497697793",
    "text" : "Today, @SenWhitehouse &amp; I are announcing our support for the Iran nuclear agreement. Here is why: http:\/\/t.co\/6JnFzOIYq5 #IranDeal",
    "id" : 633735470497697793,
    "created_at" : "2015-08-18 20:21:25 +0000",
    "user" : {
      "name" : "Senator Jack Reed",
      "screen_name" : "SenJackReed",
      "protected" : false,
      "id_str" : "486694111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611042380846907393\/L-JV9zuJ_normal.jpg",
      "id" : 486694111,
      "verified" : true
    }
  },
  "id" : 633738516833275905,
  "created_at" : "2015-08-18 20:33:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/633729296461230080\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HHNnlo8AGZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMt0lQzU8AQgaVZ.jpg",
      "id_str" : "633728356089917444",
      "id" : 633728356089917444,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMt0lQzU8AQgaVZ.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 893
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 893
      } ],
      "display_url" : "pic.twitter.com\/HHNnlo8AGZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/5ADQ37zkOC",
      "expanded_url" : "http:\/\/tmblr.co\/ZKvbjx1sHJNnq",
      "display_url" : "tmblr.co\/ZKvbjx1sHJNnq"
    } ]
  },
  "geo" : { },
  "id_str" : "633729296461230080",
  "text" : "The 19th Amendment was ratified 95 years ago, giving every American woman the right to vote \u2192 http:\/\/t.co\/5ADQ37zkOC http:\/\/t.co\/HHNnlo8AGZ",
  "id" : 633729296461230080,
  "created_at" : "2015-08-18 19:56:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 43, 52 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633709476151996416",
  "text" : "RT @TheIranDeal: Go behind the scenes with @Rhodes44 on the day he told @POTUS we successfully negotiated the historic #IranDeal.\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Rhodes",
        "screen_name" : "rhodes44",
        "indices" : [ 26, 35 ],
        "id_str" : "249722522",
        "id" : 249722522
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 55, 61 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/W0GsTM8d2f",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/24ea53f9-cac7-4729-84bb-b44858d10bfc",
        "display_url" : "amp.twimg.com\/v\/24ea53f9-cac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633708595566153728",
    "text" : "Go behind the scenes with @Rhodes44 on the day he told @POTUS we successfully negotiated the historic #IranDeal.\nhttps:\/\/t.co\/W0GsTM8d2f",
    "id" : 633708595566153728,
    "created_at" : "2015-08-18 18:34:37 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 633709476151996416,
  "created_at" : "2015-08-18 18:38:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/633699177755738112\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Db3tsfOo6Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMtZFFdWcAArUUM.jpg",
      "id_str" : "633698116475187200",
      "id" : 633698116475187200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMtZFFdWcAArUUM.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Db3tsfOo6Z"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 37, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633699177755738112",
  "text" : "RT if your state has taken action to #RaiseTheWage since 2013:\nAK AR CA CT DC DE HI MA MD MN MI NE NY NJ RI SD VT WV. http:\/\/t.co\/Db3tsfOo6Z",
  "id" : 633699177755738112,
  "created_at" : "2015-08-18 17:57:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Mazie Hirono",
      "screen_name" : "maziehirono",
      "indices" : [ 3, 15 ],
      "id_str" : "92186819",
      "id" : 92186819
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633671208072941568",
  "text" : "RT @maziehirono: After careful consideration, I support the #IranDeal as it is our best option to halt Iran's nuclear weapons program http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/vSDQiwpzf8",
        "expanded_url" : "http:\/\/1.usa.gov\/1UQ6Cwd",
        "display_url" : "1.usa.gov\/1UQ6Cwd"
      } ]
    },
    "geo" : { },
    "id_str" : "633493623007518720",
    "text" : "After careful consideration, I support the #IranDeal as it is our best option to halt Iran's nuclear weapons program http:\/\/t.co\/vSDQiwpzf8",
    "id" : 633493623007518720,
    "created_at" : "2015-08-18 04:20:24 +0000",
    "user" : {
      "name" : "Senator Mazie Hirono",
      "screen_name" : "maziehirono",
      "protected" : false,
      "id_str" : "92186819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3379750217\/6864e4a02eee1286985bf803b2c3d4ac_normal.jpeg",
      "id" : 92186819,
      "verified" : true
    }
  },
  "id" : 633671208072941568,
  "created_at" : "2015-08-18 16:06:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/633666665134211072\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QlRLy4ORo2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMs7ccpUcAQW0ME.jpg",
      "id_str" : "633665532487561220",
      "id" : 633665532487561220,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMs7ccpUcAQW0ME.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QlRLy4ORo2"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/4RqeKnGuES",
      "expanded_url" : "http:\/\/bit.ly\/1JorsAT",
      "display_url" : "bit.ly\/1JorsAT"
    } ]
  },
  "geo" : { },
  "id_str" : "633666665134211072",
  "text" : "\"The stakes are simply too high to punt on this deal.\" \u2014Former Army Captain on the #IranDeal: http:\/\/t.co\/4RqeKnGuES http:\/\/t.co\/QlRLy4ORo2",
  "id" : 633666665134211072,
  "created_at" : "2015-08-18 15:48:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Today's Document",
      "screen_name" : "TodaysDocument",
      "indices" : [ 3, 18 ],
      "id_str" : "22656792",
      "id" : 22656792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "19thAmendment",
      "indices" : [ 91, 105 ]
    }, {
      "text" : "TDiH",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633648105922166784",
  "text" : "RT @TodaysDocument: \u201CThe right\u2026to vote shall not be denied or abridged\u2026on account of sex.\u201D #19thAmendment ratified 95 yrs ago #TDiH 1920: h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "19thAmendment",
        "indices" : [ 71, 85 ]
      }, {
        "text" : "TDiH",
        "indices" : [ 106, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/swvweW9SZv",
        "expanded_url" : "http:\/\/todaysdocument.tumblr.com\/post\/126991826036\/the-right-of-citizens-of-the-united-states-to",
        "display_url" : "todaysdocument.tumblr.com\/post\/126991826\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633629489365446656",
    "text" : "\u201CThe right\u2026to vote shall not be denied or abridged\u2026on account of sex.\u201D #19thAmendment ratified 95 yrs ago #TDiH 1920: http:\/\/t.co\/swvweW9SZv",
    "id" : 633629489365446656,
    "created_at" : "2015-08-18 13:20:17 +0000",
    "user" : {
      "name" : "Today's Document",
      "screen_name" : "TodaysDocument",
      "protected" : false,
      "id_str" : "22656792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1208582961\/app_icon_v2_normal.jpg",
      "id" : 22656792,
      "verified" : true
    }
  },
  "id" : 633648105922166784,
  "created_at" : "2015-08-18 14:34:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/633386380635213824\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/J3A8svtOiE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMo9UyUU8AAHpNa.jpg",
      "id_str" : "633386124912685056",
      "id" : 633386124912685056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMo9UyUU8AAHpNa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J3A8svtOiE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633386380635213824",
  "text" : "\"Emma Didlake served her country with distinction and honor, a true trailblazer for generations of Americans\" \u2014@POTUS http:\/\/t.co\/J3A8svtOiE",
  "id" : 633386380635213824,
  "created_at" : "2015-08-17 21:14:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "PIF",
      "screen_name" : "InnovFellows",
      "indices" : [ 22, 35 ],
      "id_str" : "3184883153",
      "id" : 3184883153
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PIF",
      "indices" : [ 86, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/Uyw3oeI7qx",
      "expanded_url" : "http:\/\/go.wh.gov\/PIF",
      "display_url" : "go.wh.gov\/PIF"
    }, {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/GxLB0uewVW",
      "expanded_url" : "http:\/\/snpy.tv\/1Jmygiw",
      "display_url" : "snpy.tv\/1Jmygiw"
    } ]
  },
  "geo" : { },
  "id_str" : "633358615311597572",
  "text" : ".@POTUS just made the @InnovFellows program permanent.\nWatch \u2192 http:\/\/t.co\/Uyw3oeI7qx #PIF http:\/\/t.co\/GxLB0uewVW",
  "id" : 633358615311597572,
  "created_at" : "2015-08-17 19:23:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/633316835627106304\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/VHlxhcRkWd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMn-STEU8AEd_fV.jpg",
      "id_str" : "633316812931788801",
      "id" : 633316812931788801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMn-STEU8AEd_fV.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1204
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/VHlxhcRkWd"
    } ],
    "hashtags" : [ {
      "text" : "PIF",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Uyw3oeI7qx",
      "expanded_url" : "http:\/\/go.wh.gov\/PIF",
      "display_url" : "go.wh.gov\/PIF"
    } ]
  },
  "geo" : { },
  "id_str" : "633316835627106304",
  "text" : "Meet the people working to make our government as modern &amp; innovative as the tech sector: http:\/\/t.co\/Uyw3oeI7qx #PIF http:\/\/t.co\/VHlxhcRkWd",
  "id" : 633316835627106304,
  "created_at" : "2015-08-17 16:37:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 3, 8 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    }, {
      "name" : "PIF",
      "screen_name" : "InnovFellows",
      "indices" : [ 27, 40 ],
      "id_str" : "3184883153",
      "id" : 3184883153
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/HJm2fEAxga",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/meet-the-presidential-innovation-fellows-194dec20442b",
      "display_url" : "medium.com\/@WhiteHouse\/me\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "633312158441312257",
  "text" : "RT @DJ44: Want to know why @InnovFellows rock? Read here and why @POTUS just made it permanent.  https:\/\/t.co\/HJm2fEAxga",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PIF",
        "screen_name" : "InnovFellows",
        "indices" : [ 17, 30 ],
        "id_str" : "3184883153",
        "id" : 3184883153
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 55, 61 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/HJm2fEAxga",
        "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/meet-the-presidential-innovation-fellows-194dec20442b",
        "display_url" : "medium.com\/@WhiteHouse\/me\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "633311121848594432",
    "text" : "Want to know why @InnovFellows rock? Read here and why @POTUS just made it permanent.  https:\/\/t.co\/HJm2fEAxga",
    "id" : 633311121848594432,
    "created_at" : "2015-08-17 16:15:12 +0000",
    "user" : {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "protected" : false,
      "id_str" : "3030922321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570697565977313280\/aoCw1bC5_normal.jpeg",
      "id" : 3030922321,
      "verified" : true
    }
  },
  "id" : 633312158441312257,
  "created_at" : "2015-08-17 16:19:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PIF",
      "screen_name" : "InnovFellows",
      "indices" : [ 22, 35 ],
      "id_str" : "3184883153",
      "id" : 3184883153
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PIF",
      "indices" : [ 113, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Uyw3oeI7qx",
      "expanded_url" : "http:\/\/go.wh.gov\/PIF",
      "display_url" : "go.wh.gov\/PIF"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GxLB0uewVW",
      "expanded_url" : "http:\/\/snpy.tv\/1Jmygiw",
      "display_url" : "snpy.tv\/1Jmygiw"
    } ]
  },
  "geo" : { },
  "id_str" : "633305069694291968",
  "text" : "Meet the Presidential @InnovFellows and learn why @POTUS just made the program permanent: http:\/\/t.co\/Uyw3oeI7qx #PIF http:\/\/t.co\/GxLB0uewVW",
  "id" : 633305069694291968,
  "created_at" : "2015-08-17 15:51:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "633296324075503617",
  "text" : "RT @ErnestMoniz: In Lausanne, we got a better agreement than people expected. The final #IranDeal is even better. Read it here: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 71, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/C5ttjXQzxo",
        "expanded_url" : "http:\/\/go.wh.gov\/IranDealText",
        "display_url" : "go.wh.gov\/IranDealText"
      } ]
    },
    "geo" : { },
    "id_str" : "633278648217378816",
    "text" : "In Lausanne, we got a better agreement than people expected. The final #IranDeal is even better. Read it here: http:\/\/t.co\/C5ttjXQzxo",
    "id" : 633278648217378816,
    "created_at" : "2015-08-17 14:06:10 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 633296324075503617,
  "created_at" : "2015-08-17 15:16:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/zOS0Rl42P0",
      "expanded_url" : "http:\/\/goo.gl\/Ksu0Du",
      "display_url" : "goo.gl\/Ksu0Du"
    } ]
  },
  "geo" : { },
  "id_str" : "633277156852760576",
  "text" : "RT @TheIranDeal: More than 100 former American Ambassadors strongly back the #IranDeal. Read their letter \u2192 http:\/\/t.co\/zOS0Rl42P0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 60, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/zOS0Rl42P0",
        "expanded_url" : "http:\/\/goo.gl\/Ksu0Du",
        "display_url" : "goo.gl\/Ksu0Du"
      } ]
    },
    "geo" : { },
    "id_str" : "633276006946729985",
    "text" : "More than 100 former American Ambassadors strongly back the #IranDeal. Read their letter \u2192 http:\/\/t.co\/zOS0Rl42P0",
    "id" : 633276006946729985,
    "created_at" : "2015-08-17 13:55:40 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 633277156852760576,
  "created_at" : "2015-08-17 14:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/MIrjXT7tr3",
      "expanded_url" : "http:\/\/snpy.tv\/1HNSA59",
      "display_url" : "snpy.tv\/1HNSA59"
    } ]
  },
  "geo" : { },
  "id_str" : "633035556759298048",
  "text" : "\"Expanding that opportunity to every American willing to work for it...that\u2019s always been the promise of America.\" http:\/\/t.co\/MIrjXT7tr3",
  "id" : 633035556759298048,
  "created_at" : "2015-08-16 22:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/MIrjXT7tr3",
      "expanded_url" : "http:\/\/snpy.tv\/1HNSA59",
      "display_url" : "snpy.tv\/1HNSA59"
    } ]
  },
  "geo" : { },
  "id_str" : "633005379195039745",
  "text" : "\"We need to keep working to help more prisoners take steps to turn their lives around.\" \u2014@POTUS: http:\/\/t.co\/MIrjXT7tr3",
  "id" : 633005379195039745,
  "created_at" : "2015-08-16 20:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/MIrjXSPSzv",
      "expanded_url" : "http:\/\/snpy.tv\/1HNSA59",
      "display_url" : "snpy.tv\/1HNSA59"
    } ]
  },
  "geo" : { },
  "id_str" : "632987384708243456",
  "text" : "\"Dozens of police departments are now sharing more data with the public.\" \u2014@POTUS on improving community policing: http:\/\/t.co\/MIrjXSPSzv",
  "id" : 632987384708243456,
  "created_at" : "2015-08-16 18:48:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/632956378253012993\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Td1ig20iSz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMi2czAW8AAzO2e.png",
      "id_str" : "632956353489858560",
      "id" : 632956353489858560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMi2czAW8AAzO2e.png",
      "sizes" : [ {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 695
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 695
      } ],
      "display_url" : "pic.twitter.com\/Td1ig20iSz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632956378253012993",
  "text" : "\"Julian Bond helped change this country for the better. And what better way to be remembered than that.\" \u2014@POTUS: http:\/\/t.co\/Td1ig20iSz",
  "id" : 632956378253012993,
  "created_at" : "2015-08-16 16:45:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/MIrjXT7tr3",
      "expanded_url" : "http:\/\/snpy.tv\/1HNSA59",
      "display_url" : "snpy.tv\/1HNSA59"
    } ]
  },
  "geo" : { },
  "id_str" : "632620305714810881",
  "text" : "\"We need to truly invest in our children and our communities so that more young people see a better path.\" \u2014@POTUS: http:\/\/t.co\/MIrjXT7tr3",
  "id" : 632620305714810881,
  "created_at" : "2015-08-15 18:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/MIrjXT7tr3",
      "expanded_url" : "http:\/\/snpy.tv\/1HNSA59",
      "display_url" : "snpy.tv\/1HNSA59"
    } ]
  },
  "geo" : { },
  "id_str" : "632590101424377856",
  "text" : "\"Over the past year, we\u2019ve come to see more clearly than ever the frustration in many communities of color.\" \u2014@POTUS: http:\/\/t.co\/MIrjXT7tr3",
  "id" : 632590101424377856,
  "created_at" : "2015-08-15 16:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/OrUN3TKUv5",
      "expanded_url" : "http:\/\/go.wh.gov\/oALcpf",
      "display_url" : "go.wh.gov\/oALcpf"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/MIrjXSPSzv",
      "expanded_url" : "http:\/\/snpy.tv\/1HNSA59",
      "display_url" : "snpy.tv\/1HNSA59"
    } ]
  },
  "geo" : { },
  "id_str" : "632566455414980608",
  "text" : "Watch President Obama's weekly address on continuing the work to improve community policing: http:\/\/t.co\/OrUN3TKUv5 http:\/\/t.co\/MIrjXSPSzv",
  "id" : 632566455414980608,
  "created_at" : "2015-08-15 14:56:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Timberlake",
      "screen_name" : "jtimberlake",
      "indices" : [ 3, 15 ],
      "id_str" : "26565946",
      "id" : 26565946
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSplaylist",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/jpJ2IZIAuN",
      "expanded_url" : "https:\/\/twitter.com\/ew\/status\/632238037334888448",
      "display_url" : "twitter.com\/ew\/status\/6322\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "632248202117443584",
  "text" : "RT @jtimberlake: \uD83C\uDFC6\u203C\uFE0F #POTUSplaylist  https:\/\/t.co\/jpJ2IZIAuN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUSplaylist",
        "indices" : [ 4, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 20, 43 ],
        "url" : "https:\/\/t.co\/jpJ2IZIAuN",
        "expanded_url" : "https:\/\/twitter.com\/ew\/status\/632238037334888448",
        "display_url" : "twitter.com\/ew\/status\/6322\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "632238764606119936",
    "text" : "\uD83C\uDFC6\u203C\uFE0F #POTUSplaylist  https:\/\/t.co\/jpJ2IZIAuN",
    "id" : 632238764606119936,
    "created_at" : "2015-08-14 17:14:02 +0000",
    "user" : {
      "name" : "Justin Timberlake",
      "screen_name" : "jtimberlake",
      "protected" : false,
      "id_str" : "26565946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733026741862567936\/Oern1Pc2_normal.jpg",
      "id" : 26565946,
      "verified" : true
    }
  },
  "id" : 632248202117443584,
  "created_at" : "2015-08-14 17:51:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 3, 11 ],
      "id_str" : "17230018",
      "id" : 17230018
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSplaylist",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/lUVxwVM9vj",
      "expanded_url" : "http:\/\/spoti.fi\/1gy7Gps",
      "display_url" : "spoti.fi\/1gy7Gps"
    } ]
  },
  "geo" : { },
  "id_str" : "632238599027752960",
  "text" : "RT @Spotify: The @WhiteHouse is now on Spotify! Celebrate summer with President Obama's #POTUSplaylist \uD83C\uDDFA\uD83C\uDDF8 http:\/\/t.co\/lUVxwVM9vj http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Spotify\/status\/632237337938919424\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/gOwCSMzl7A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMYogibXAAAAk77.png",
        "id_str" : "632237337154617344",
        "id" : 632237337154617344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMYogibXAAAAk77.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gOwCSMzl7A"
      } ],
      "hashtags" : [ {
        "text" : "POTUSplaylist",
        "indices" : [ 75, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/lUVxwVM9vj",
        "expanded_url" : "http:\/\/spoti.fi\/1gy7Gps",
        "display_url" : "spoti.fi\/1gy7Gps"
      } ]
    },
    "geo" : { },
    "id_str" : "632237337938919424",
    "text" : "The @WhiteHouse is now on Spotify! Celebrate summer with President Obama's #POTUSplaylist \uD83C\uDDFA\uD83C\uDDF8 http:\/\/t.co\/lUVxwVM9vj http:\/\/t.co\/gOwCSMzl7A",
    "id" : 632237337938919424,
    "created_at" : "2015-08-14 17:08:22 +0000",
    "user" : {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "protected" : false,
      "id_str" : "17230018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753188521540714497\/ge3tfN8Z_normal.jpg",
      "id" : 17230018,
      "verified" : true
    }
  },
  "id" : 632238599027752960,
  "created_at" : "2015-08-14 17:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 55, 63 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/632222993482018816\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Ffe6M5ABC3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMYa6EtXAAAL9Ck.jpg",
      "id_str" : "632222382690861056",
      "id" : 632222382690861056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMYa6EtXAAAL9Ck.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/Ffe6M5ABC3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ie5hb9e9Hd",
      "expanded_url" : "http:\/\/spoti.fi\/potusplaylist1",
      "display_url" : "spoti.fi\/potusplaylist1"
    }, {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/i7izh2eMeb",
      "expanded_url" : "http:\/\/spoti.fi\/potusplaylist2",
      "display_url" : "spoti.fi\/potusplaylist2"
    } ]
  },
  "geo" : { },
  "id_str" : "632222993482018816",
  "text" : "DJ @POTUS just dropped his summer playlists.\nListen on @Spotify:\nhttp:\/\/t.co\/ie5hb9e9Hd\nhttp:\/\/t.co\/i7izh2eMeb http:\/\/t.co\/Ffe6M5ABC3",
  "id" : 632222993482018816,
  "created_at" : "2015-08-14 16:11:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 27, 42 ],
      "id_str" : "14511951",
      "id" : 14511951
    }, {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 113, 123 ],
      "id_str" : "133769083",
      "id" : 133769083
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632219080821506049",
  "text" : "RT @JohnKerry: Shared with @HuffingtonPost my thoughts on our new relationship with #Cuba, today\u2019s re-opening of @USEmbCuba: http:\/\/t.co\/KA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huffington Post",
        "screen_name" : "HuffingtonPost",
        "indices" : [ 12, 27 ],
        "id_str" : "14511951",
        "id" : 14511951
      }, {
        "name" : "Embajada EE.UU. Cuba",
        "screen_name" : "USEmbCuba",
        "indices" : [ 98, 108 ],
        "id_str" : "133769083",
        "id" : 133769083
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 69, 74 ]
      }, {
        "text" : "USCuba",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/KArhdLzZYu",
        "expanded_url" : "http:\/\/goo.gl\/VHT38z",
        "display_url" : "goo.gl\/VHT38z"
      } ]
    },
    "geo" : { },
    "id_str" : "632218798154760193",
    "text" : "Shared with @HuffingtonPost my thoughts on our new relationship with #Cuba, today\u2019s re-opening of @USEmbCuba: http:\/\/t.co\/KArhdLzZYu #USCuba",
    "id" : 632218798154760193,
    "created_at" : "2015-08-14 15:54:42 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 632219080821506049,
  "created_at" : "2015-08-14 15:55:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/uer5sIl4Vk",
      "expanded_url" : "http:\/\/spoti.fi\/potusplaylist1",
      "display_url" : "spoti.fi\/potusplaylist1"
    }, {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/zHEekHvQBr",
      "expanded_url" : "http:\/\/spoti.fi\/potusplaylist2",
      "display_url" : "spoti.fi\/potusplaylist2"
    } ]
  },
  "geo" : { },
  "id_str" : "632214191563145216",
  "text" : "RT @POTUS: Due to popular request, here are my vacation playlists: http:\/\/t.co\/uer5sIl4Vk http:\/\/t.co\/zHEekHvQBr What's your favorite summe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/uer5sIl4Vk",
        "expanded_url" : "http:\/\/spoti.fi\/potusplaylist1",
        "display_url" : "spoti.fi\/potusplaylist1"
      }, {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/zHEekHvQBr",
        "expanded_url" : "http:\/\/spoti.fi\/potusplaylist2",
        "display_url" : "spoti.fi\/potusplaylist2"
      } ]
    },
    "geo" : { },
    "id_str" : "632212730209009664",
    "text" : "Due to popular request, here are my vacation playlists: http:\/\/t.co\/uer5sIl4Vk http:\/\/t.co\/zHEekHvQBr What's your favorite summer song?",
    "id" : 632212730209009664,
    "created_at" : "2015-08-14 15:30:35 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 632214191563145216,
  "created_at" : "2015-08-14 15:36:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 57, 67 ],
      "id_str" : "133769083",
      "id" : 133769083
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Havana",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "SecState",
      "indices" : [ 91, 100 ]
    }, {
      "text" : "Cuba",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632209440981147648",
  "text" : "RT @JohnKerry: Pleased to be in #Havana for historic day @USEmbCuba. Incredible: last time #SecState visited #Cuba, FDR was @POTUS. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Embajada EE.UU. Cuba",
        "screen_name" : "USEmbCuba",
        "indices" : [ 42, 52 ],
        "id_str" : "133769083",
        "id" : 133769083
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 109, 115 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/632205031740153856\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/URedAaDpZs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMYLIGAWgAAb3JW.jpg",
        "id_str" : "632205031371079680",
        "id" : 632205031371079680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMYLIGAWgAAb3JW.jpg",
        "sizes" : [ {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/URedAaDpZs"
      } ],
      "hashtags" : [ {
        "text" : "Havana",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "SecState",
        "indices" : [ 76, 85 ]
      }, {
        "text" : "Cuba",
        "indices" : [ 94, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632205031740153856",
    "text" : "Pleased to be in #Havana for historic day @USEmbCuba. Incredible: last time #SecState visited #Cuba, FDR was @POTUS. http:\/\/t.co\/URedAaDpZs",
    "id" : 632205031740153856,
    "created_at" : "2015-08-14 15:00:00 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 632209440981147648,
  "created_at" : "2015-08-14 15:17:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9YfpZYBNJN",
      "expanded_url" : "http:\/\/snpy.tv\/1INPzpr",
      "display_url" : "snpy.tv\/1INPzpr"
    } ]
  },
  "geo" : { },
  "id_str" : "632207573404352512",
  "text" : "\u201CThe time is now to reach out to one another as two peoples who are no longer enemies...but neighbors.\u201D \u2014Kerry #Cuba http:\/\/t.co\/9YfpZYBNJN",
  "id" : 632207573404352512,
  "created_at" : "2015-08-14 15:10:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 6, 16 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 57, 67 ],
      "id_str" : "133769083",
      "id" : 133769083
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/wpUa2E1hU4",
      "expanded_url" : "http:\/\/snpy.tv\/1KlvnJh",
      "display_url" : "snpy.tv\/1KlvnJh"
    } ]
  },
  "geo" : { },
  "id_str" : "632204024217862144",
  "text" : "Watch @JohnKerry speak about the importance of reopening @USEmbCuba. #Cuba http:\/\/t.co\/wpUa2E1hU4",
  "id" : 632204024217862144,
  "created_at" : "2015-08-14 14:55:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 62, 72 ],
      "id_str" : "133769083",
      "id" : 133769083
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/0O4X1m5bb8",
      "expanded_url" : "http:\/\/snpy.tv\/1TB2Xp3",
      "display_url" : "snpy.tv\/1TB2Xp3"
    } ]
  },
  "geo" : { },
  "id_str" : "632200981837574144",
  "text" : "For the first time in 54 years, the American flag flies above @USEmbCuba. #Cuba \uD83C\uDDFA\uD83C\uDDF8 http:\/\/t.co\/0O4X1m5bb8",
  "id" : 632200981837574144,
  "created_at" : "2015-08-14 14:43:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StateDept Live",
      "screen_name" : "StateDeptLive",
      "indices" : [ 3, 17 ],
      "id_str" : "271024433",
      "id" : 271024433
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 20, 30 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632199098456629248",
  "text" : "RT @StateDeptLive: .@JohnKerry: The time is now to reach out to one another, as two peoples who are no longer enemies or rivals, but neighb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 1, 11 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632198671614898176",
    "text" : ".@JohnKerry: The time is now to reach out to one another, as two peoples who are no longer enemies or rivals, but neighbors.",
    "id" : 632198671614898176,
    "created_at" : "2015-08-14 14:34:43 +0000",
    "user" : {
      "name" : "StateDept Live",
      "screen_name" : "StateDeptLive",
      "protected" : false,
      "id_str" : "271024433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2907833517\/b149481e47adb7abbe0e4a9602658d7b_normal.jpeg",
      "id" : 271024433,
      "verified" : true
    }
  },
  "id" : 632199098456629248,
  "created_at" : "2015-08-14 14:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StateDept Live",
      "screen_name" : "StateDeptLive",
      "indices" : [ 3, 17 ],
      "id_str" : "271024433",
      "id" : 271024433
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 20, 30 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632198634738597888",
  "text" : "RT @StateDeptLive: .@JohnKerry: I applaud @POTUS &amp; President Castro for having the courage to bring us together in the face of considerable\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 1, 11 ],
        "id_str" : "15007149",
        "id" : 15007149
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 23, 29 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632198173092659200",
    "text" : ".@JohnKerry: I applaud @POTUS &amp; President Castro for having the courage to bring us together in the face of considerable opposition.",
    "id" : 632198173092659200,
    "created_at" : "2015-08-14 14:32:44 +0000",
    "user" : {
      "name" : "StateDept Live",
      "screen_name" : "StateDeptLive",
      "protected" : false,
      "id_str" : "271024433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2907833517\/b149481e47adb7abbe0e4a9602658d7b_normal.jpeg",
      "id" : 271024433,
      "verified" : true
    }
  },
  "id" : 632198634738597888,
  "created_at" : "2015-08-14 14:34:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StateDept Live",
      "screen_name" : "StateDeptLive",
      "indices" : [ 3, 17 ],
      "id_str" : "271024433",
      "id" : 271024433
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 20, 30 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632198159440191489",
  "text" : "RT @StateDeptLive: .@JohnKerry: Overall US embargo on trade with #Cuba remains in place, can only be lifted by Congressional action \u2013a step\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 1, 11 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 46, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632197751430881280",
    "text" : ".@JohnKerry: Overall US embargo on trade with #Cuba remains in place, can only be lifted by Congressional action \u2013a step we strongly favor.",
    "id" : 632197751430881280,
    "created_at" : "2015-08-14 14:31:04 +0000",
    "user" : {
      "name" : "StateDept Live",
      "screen_name" : "StateDeptLive",
      "protected" : false,
      "id_str" : "271024433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2907833517\/b149481e47adb7abbe0e4a9602658d7b_normal.jpeg",
      "id" : 271024433,
      "verified" : true
    }
  },
  "id" : 632198159440191489,
  "created_at" : "2015-08-14 14:32:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 114, 124 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632197347754119168",
  "text" : "\u201CThe road of mutual isolation and estrangement that the U.S. and Cuba have been traveling is not the right one.\u201D \u2014@JohnKerry #Cuba",
  "id" : 632197347754119168,
  "created_at" : "2015-08-14 14:29:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 108, 118 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632195937897590784",
  "text" : "\"This is truly a memorable occasion\u2014a day for pushing aside old barriers and exploring new possibilities.\" \u2014@JohnKerry in #Cuba",
  "id" : 632195937897590784,
  "created_at" : "2015-08-14 14:23:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632195296047398912",
  "text" : "RT @WHLive: \"Thank you for joining us at this truly historic moment as we prepare to raise the United States flag here in Havana.\" \u2014@JohnKe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 120, 130 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632195250967089152",
    "text" : "\"Thank you for joining us at this truly historic moment as we prepare to raise the United States flag here in Havana.\" \u2014@JohnKerry in Cuba",
    "id" : 632195250967089152,
    "created_at" : "2015-08-14 14:21:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 632195296047398912,
  "created_at" : "2015-08-14 14:21:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 24, 34 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 56, 66 ],
      "id_str" : "133769083",
      "id" : 133769083
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/632194522403893248\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/RbVRpJ0qWF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMX_Xr0WEAAIGi9.jpg",
      "id_str" : "632192105079771136",
      "id" : 632192105079771136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMX_Xr0WEAAIGi9.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RbVRpJ0qWF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/tzU6VfruH9",
      "expanded_url" : "http:\/\/go.wh.gov\/KerryInCuba",
      "display_url" : "go.wh.gov\/KerryInCuba"
    } ]
  },
  "geo" : { },
  "id_str" : "632194522403893248",
  "text" : "Happening now: Watch as @JohnKerry raises our flag over @USEmbCuba in Havana once more \u2192 http:\/\/t.co\/tzU6VfruH9 \uD83C\uDDFA\uD83C\uDDF8 http:\/\/t.co\/RbVRpJ0qWF",
  "id" : 632194522403893248,
  "created_at" : "2015-08-14 14:18:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632194380552515584",
  "text" : "RT @VP: Secretary of State John Kerry is raising the American flag in Cuba today. Here's what it looked like 54 years ago. http:\/\/t.co\/kdEN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/632193793199050752\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/kdENncFY1t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMYA53bUcAA1WtP.jpg",
        "id_str" : "632193791823212544",
        "id" : 632193791823212544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMYA53bUcAA1WtP.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kdENncFY1t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "632193793199050752",
    "text" : "Secretary of State John Kerry is raising the American flag in Cuba today. Here's what it looked like 54 years ago. http:\/\/t.co\/kdENncFY1t",
    "id" : 632193793199050752,
    "created_at" : "2015-08-14 14:15:20 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 632194380552515584,
  "created_at" : "2015-08-14 14:17:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 21, 31 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "USCuba",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632189071838724096",
  "text" : "RT @StateDept: Watch @JohnKerry's arrival in #Cuba. Last Secretary of State to visit Cuba was Edward Stettinius in 1945! #USCuba http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 6, 16 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 30, 35 ]
      }, {
        "text" : "USCuba",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/NPVOoTnTFd",
        "expanded_url" : "http:\/\/snpy.tv\/1KlsBDT",
        "display_url" : "snpy.tv\/1KlsBDT"
      } ]
    },
    "geo" : { },
    "id_str" : "632188687753703424",
    "text" : "Watch @JohnKerry's arrival in #Cuba. Last Secretary of State to visit Cuba was Edward Stettinius in 1945! #USCuba http:\/\/t.co\/NPVOoTnTFd",
    "id" : 632188687753703424,
    "created_at" : "2015-08-14 13:55:03 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 632189071838724096,
  "created_at" : "2015-08-14 13:56:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 36, 46 ],
      "id_str" : "133769083",
      "id" : 133769083
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 85, 99 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/FL5Wo5B8BT",
      "expanded_url" : "http:\/\/go.nasa.gov\/1J4uFz6",
      "display_url" : "go.nasa.gov\/1J4uFz6"
    } ]
  },
  "geo" : { },
  "id_str" : "632188584032792576",
  "text" : "RT @NASA: As US flag is raised over @USEmbCuba in Havana, here's a look at Cuba from @Space_Station: http:\/\/t.co\/FL5Wo5B8BT http:\/\/t.co\/GJo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Embajada EE.UU. Cuba",
        "screen_name" : "USEmbCuba",
        "indices" : [ 26, 36 ],
        "id_str" : "133769083",
        "id" : 133769083
      }, {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 75, 89 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/632187348550352896\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/GJoi403FX5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMX7C0GWUAARr2f.jpg",
        "id_str" : "632187348479004672",
        "id" : 632187348479004672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMX7C0GWUAARr2f.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/GJoi403FX5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/FL5Wo5B8BT",
        "expanded_url" : "http:\/\/go.nasa.gov\/1J4uFz6",
        "display_url" : "go.nasa.gov\/1J4uFz6"
      } ]
    },
    "geo" : { },
    "id_str" : "632187348550352896",
    "text" : "As US flag is raised over @USEmbCuba in Havana, here's a look at Cuba from @Space_Station: http:\/\/t.co\/FL5Wo5B8BT http:\/\/t.co\/GJoi403FX5",
    "id" : 632187348550352896,
    "created_at" : "2015-08-14 13:49:44 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 632188584032792576,
  "created_at" : "2015-08-14 13:54:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 29, 39 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 53, 63 ],
      "id_str" : "133769083",
      "id" : 133769083
    }, {
      "name" : "StateDept Live",
      "screen_name" : "StateDeptLive",
      "indices" : [ 106, 120 ],
      "id_str" : "271024433",
      "id" : 271024433
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USCuba",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/58Uc9lZRv7",
      "expanded_url" : "http:\/\/state.gov",
      "display_url" : "state.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "632187161089978369",
  "text" : "RT @StateDept: At 9:45am ET, @JohnKerry will re-open @USEmbCuba. \nWatch: http:\/\/t.co\/58Uc9lZRv7 | Follow: @StateDeptLive \n#USCuba http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 14, 24 ],
        "id_str" : "15007149",
        "id" : 15007149
      }, {
        "name" : "Embajada EE.UU. Cuba",
        "screen_name" : "USEmbCuba",
        "indices" : [ 38, 48 ],
        "id_str" : "133769083",
        "id" : 133769083
      }, {
        "name" : "StateDept Live",
        "screen_name" : "StateDeptLive",
        "indices" : [ 91, 105 ],
        "id_str" : "271024433",
        "id" : 271024433
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/632175660434198528\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/q7SN3AGbVF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMXwacTWEAASW2j.jpg",
        "id_str" : "632175659780018176",
        "id" : 632175659780018176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMXwacTWEAASW2j.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q7SN3AGbVF"
      } ],
      "hashtags" : [ {
        "text" : "USCuba",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/58Uc9lZRv7",
        "expanded_url" : "http:\/\/state.gov",
        "display_url" : "state.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "632175660434198528",
    "text" : "At 9:45am ET, @JohnKerry will re-open @USEmbCuba. \nWatch: http:\/\/t.co\/58Uc9lZRv7 | Follow: @StateDeptLive \n#USCuba http:\/\/t.co\/q7SN3AGbVF",
    "id" : 632175660434198528,
    "created_at" : "2015-08-14 13:03:17 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 632187161089978369,
  "created_at" : "2015-08-14 13:48:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 100, 110 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632185563647361024",
  "text" : "RT @VP: The last time we had an embassy in Cuba was January 1961. Today, we're changing that. Watch @JohnKerry in Havana \u2192 http:\/\/t.co\/yc39\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 92, 102 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/yc39a6NBSD",
        "expanded_url" : "http:\/\/go.wh.gov\/KerryInCuba",
        "display_url" : "go.wh.gov\/KerryInCuba"
      } ]
    },
    "geo" : { },
    "id_str" : "632185126961594369",
    "text" : "The last time we had an embassy in Cuba was January 1961. Today, we're changing that. Watch @JohnKerry in Havana \u2192 http:\/\/t.co\/yc39a6NBSD",
    "id" : 632185126961594369,
    "created_at" : "2015-08-14 13:40:54 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 632185563647361024,
  "created_at" : "2015-08-14 13:42:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 50, 60 ],
      "id_str" : "133769083",
      "id" : 133769083
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 86, 96 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/tzU6VfruH9",
      "expanded_url" : "http:\/\/go.wh.gov\/KerryInCuba",
      "display_url" : "go.wh.gov\/KerryInCuba"
    } ]
  },
  "geo" : { },
  "id_str" : "632183166913015808",
  "text" : "54 years ago we lowered the American flag outside @USEmbCuba.\nTune in at 9:45am ET as @JohnKerry raises it once more: http:\/\/t.co\/tzU6VfruH9",
  "id" : 632183166913015808,
  "created_at" : "2015-08-14 13:33:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/632016339285078016\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/vtVSp7bDTl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMVc3LHW8AAJV7l.jpg",
      "id_str" : "632013425661636608",
      "id" : 632013425661636608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMVc3LHW8AAJV7l.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3500,
        "resize" : "fit",
        "w" : 2333
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vtVSp7bDTl"
    } ],
    "hashtags" : [ {
      "text" : "LeftHandersDay",
      "indices" : [ 6, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632016339285078016",
  "text" : "Happy #LeftHandersDay! http:\/\/t.co\/vtVSp7bDTl",
  "id" : 632016339285078016,
  "created_at" : "2015-08-14 02:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632012590110109696",
  "text" : "RT @NancyPelosi: Joined current &amp; former House Intel Members expressing confidence #IranDeal is strong &amp; deserves support: http:\/\/t.co\/1KIB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 70, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/1KIBWGIh6Q",
        "expanded_url" : "http:\/\/goo.gl\/YNsC4B",
        "display_url" : "goo.gl\/YNsC4B"
      } ]
    },
    "geo" : { },
    "id_str" : "632005298979532800",
    "text" : "Joined current &amp; former House Intel Members expressing confidence #IranDeal is strong &amp; deserves support: http:\/\/t.co\/1KIBWGIh6Q",
    "id" : 632005298979532800,
    "created_at" : "2015-08-14 01:46:20 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 632012590110109696,
  "created_at" : "2015-08-14 02:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/631924478306615296\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/IOlPvZeqs2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMUJ8DDWIAANYVL.jpg",
      "id_str" : "631922249931563008",
      "id" : 631922249931563008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMUJ8DDWIAANYVL.jpg",
      "sizes" : [ {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 744
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 744
      } ],
      "display_url" : "pic.twitter.com\/IOlPvZeqs2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/UvHC2UnuDz",
      "expanded_url" : "http:\/\/go.wh.gov\/FNZKcp",
      "display_url" : "go.wh.gov\/FNZKcp"
    } ]
  },
  "geo" : { },
  "id_str" : "631924478306615296",
  "text" : "The White House blog has a whole new look.\nCheck it out and let us know what you think \u2192 http:\/\/t.co\/UvHC2UnuDz http:\/\/t.co\/IOlPvZeqs2",
  "id" : 631924478306615296,
  "created_at" : "2015-08-13 20:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Jon Tester",
      "screen_name" : "SenatorTester",
      "indices" : [ 3, 17 ],
      "id_str" : "515822213",
      "id" : 515822213
    }, {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 61, 73 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631918117644427264",
  "text" : "RT @SenatorTester: After thoughtful deliberation, it\u2019s clear @TheIranDeal is the only option right now to stop #Iran from developing a nucl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Iran Deal",
        "screen_name" : "TheIranDeal",
        "indices" : [ 42, 54 ],
        "id_str" : "3281853858",
        "id" : 3281853858
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "631916451604074496",
    "text" : "After thoughtful deliberation, it\u2019s clear @TheIranDeal is the only option right now to stop #Iran from developing a nuclear weapon.",
    "id" : 631916451604074496,
    "created_at" : "2015-08-13 19:53:17 +0000",
    "user" : {
      "name" : "Senator Jon Tester",
      "screen_name" : "SenatorTester",
      "protected" : false,
      "id_str" : "515822213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758049957547048960\/dneTkzDC_normal.jpg",
      "id" : 515822213,
      "verified" : true
    }
  },
  "id" : 631918117644427264,
  "created_at" : "2015-08-13 19:59:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 18, 27 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/631907653447389184\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/zEHN1EpEX7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMT8kOJWoAA86f4.jpg",
      "id_str" : "631907546941530112",
      "id" : 631907546941530112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMT8kOJWoAA86f4.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zEHN1EpEX7"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631908685413937152",
  "text" : "RT @TheIranDeal: .@BuzzFeed And thanks to the #IranDeal, Iran will be ... http:\/\/t.co\/zEHN1EpEX7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BuzzFeed",
        "screen_name" : "BuzzFeed",
        "indices" : [ 1, 10 ],
        "id_str" : "5695632",
        "id" : 5695632
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/631907653447389184\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/zEHN1EpEX7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMT8kOJWoAA86f4.jpg",
        "id_str" : "631907546941530112",
        "id" : 631907546941530112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMT8kOJWoAA86f4.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zEHN1EpEX7"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 29, 38 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "631691161325821953",
    "geo" : { },
    "id_str" : "631907653447389184",
    "in_reply_to_user_id" : 5695632,
    "text" : ".@BuzzFeed And thanks to the #IranDeal, Iran will be ... http:\/\/t.co\/zEHN1EpEX7",
    "id" : 631907653447389184,
    "in_reply_to_status_id" : 631691161325821953,
    "created_at" : "2015-08-13 19:18:19 +0000",
    "in_reply_to_screen_name" : "BuzzFeed",
    "in_reply_to_user_id_str" : "5695632",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 631908685413937152,
  "created_at" : "2015-08-13 19:22:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 36, 46 ],
      "id_str" : "133769083",
      "id" : 133769083
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 85, 95 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/s5wT220cQ5",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/14366894-e384-47c6-b0dc-c8278a9bfd9f",
      "display_url" : "amp.twimg.com\/v\/14366894-e38\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631901254931738624",
  "text" : "These Marines lowered our flag over @USEmbCuba back in 1961.\nOn Friday, they'll help @JohnKerry raise it again.\nhttps:\/\/t.co\/s5wT220cQ5",
  "id" : 631901254931738624,
  "created_at" : "2015-08-13 18:52:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/eAVC9RjeMV",
      "expanded_url" : "http:\/\/go.wh.gov\/Alaska",
      "display_url" : "go.wh.gov\/Alaska"
    }, {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/X1iKf8dKDb",
      "expanded_url" : "http:\/\/snpy.tv\/1Kjl9Jr",
      "display_url" : "snpy.tv\/1Kjl9Jr"
    } ]
  },
  "geo" : { },
  "id_str" : "631854001940660224",
  "text" : "RT if you agree: It's time to #ActOnClimate.\nWatch @POTUS preview his trip to Alaska \u2192 http:\/\/t.co\/eAVC9RjeMV http:\/\/t.co\/X1iKf8dKDb",
  "id" : 631854001940660224,
  "created_at" : "2015-08-13 15:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Embajada EE.UU. Cuba",
      "screen_name" : "USEmbCuba",
      "indices" : [ 47, 57 ],
      "id_str" : "133769083",
      "id" : 133769083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/j7GTWTtVfu",
      "expanded_url" : "https:\/\/youtu.be\/-SHIRE0_Dlk",
      "display_url" : "youtu.be\/-SHIRE0_Dlk"
    } ]
  },
  "geo" : { },
  "id_str" : "631847583388971008",
  "text" : "RT @StateDept: 54 years after lowering US flag @USEmbCuba, 3 Marines head to Havana for Embassy re-opening. https:\/\/t.co\/j7GTWTtVfu http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Embajada EE.UU. Cuba",
        "screen_name" : "USEmbCuba",
        "indices" : [ 32, 42 ],
        "id_str" : "133769083",
        "id" : 133769083
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/StateDept\/status\/631824207253504001\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/AIaBRVycki",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMSwxJFWsAAhGfh.jpg",
        "id_str" : "631824206037168128",
        "id" : 631824206037168128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMSwxJFWsAAhGfh.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3280,
          "resize" : "fit",
          "w" : 4928
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/AIaBRVycki"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/j7GTWTtVfu",
        "expanded_url" : "https:\/\/youtu.be\/-SHIRE0_Dlk",
        "display_url" : "youtu.be\/-SHIRE0_Dlk"
      } ]
    },
    "geo" : { },
    "id_str" : "631824207253504001",
    "text" : "54 years after lowering US flag @USEmbCuba, 3 Marines head to Havana for Embassy re-opening. https:\/\/t.co\/j7GTWTtVfu http:\/\/t.co\/AIaBRVycki",
    "id" : 631824207253504001,
    "created_at" : "2015-08-13 13:46:44 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 631847583388971008,
  "created_at" : "2015-08-13 15:19:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/eAVC9RjeMV",
      "expanded_url" : "http:\/\/go.wh.gov\/Alaska",
      "display_url" : "go.wh.gov\/Alaska"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/X1iKf8dKDb",
      "expanded_url" : "http:\/\/snpy.tv\/1Kjl9Jr",
      "display_url" : "snpy.tv\/1Kjl9Jr"
    } ]
  },
  "geo" : { },
  "id_str" : "631842609560838145",
  "text" : ".@POTUS is headed to the frontlines of our fight against climate change.\nWatch \u2192 http:\/\/t.co\/eAVC9RjeMV #ActOnClimate http:\/\/t.co\/X1iKf8dKDb",
  "id" : 631842609560838145,
  "created_at" : "2015-08-13 14:59:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/631590909642014720\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/BHfntH0Sh6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPch4DWgAAVeNX.jpg",
      "id_str" : "631590847302238208",
      "id" : 631590847302238208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPch4DWgAAVeNX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BHfntH0Sh6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631590909642014720",
  "text" : "\"Michelle and I send our best wishes to President Carter for a fast and full recovery.\" \u2014@POTUS http:\/\/t.co\/BHfntH0Sh6",
  "id" : 631590909642014720,
  "created_at" : "2015-08-12 22:19:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/631569356372230144\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Ska5rLJrSi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMPIgdgWUAIn4EN.jpg",
      "id_str" : "631568832763678722",
      "id" : 631568832763678722,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMPIgdgWUAIn4EN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ska5rLJrSi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/oJLbFgH4d1",
      "expanded_url" : "http:\/\/nyti.ms\/1L53B9G",
      "display_url" : "nyti.ms\/1L53B9G"
    } ]
  },
  "geo" : { },
  "id_str" : "631569356372230144",
  "text" : "RT the good news: The number of uninsured Americans has dropped by 15.8 million since 2013 \u2192 http:\/\/t.co\/oJLbFgH4d1 http:\/\/t.co\/Ska5rLJrSi",
  "id" : 631569356372230144,
  "created_at" : "2015-08-12 20:54:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Players' Tribune",
      "screen_name" : "PlayersTribune",
      "indices" : [ 3, 18 ],
      "id_str" : "415605847",
      "id" : 415605847
    }, {
      "name" : "Elena Delle Donne",
      "screen_name" : "De11eDonne",
      "indices" : [ 21, 32 ],
      "id_str" : "609476852",
      "id" : 609476852
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPTAssist",
      "indices" : [ 98, 108 ]
    }, {
      "text" : "MyBrothersKeeper",
      "indices" : [ 109, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/L6bj9PEdxB",
      "expanded_url" : "http:\/\/playerstribu.ne\/lizzie",
      "display_url" : "playerstribu.ne\/lizzie"
    } ]
  },
  "geo" : { },
  "id_str" : "631531509900382208",
  "text" : "RT @PlayersTribune: .@De11eDonne on what her sister Lizzie has taught her. http:\/\/t.co\/L6bj9PEdxB #TPTAssist #MyBrothersKeeper http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elena Delle Donne",
        "screen_name" : "De11eDonne",
        "indices" : [ 1, 12 ],
        "id_str" : "609476852",
        "id" : 609476852
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PlayersTribune\/status\/631507099177086976\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/MbzPiLNfix",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMOQW2aWgAABiRw.jpg",
        "id_str" : "631507094999564288",
        "id" : 631507094999564288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMOQW2aWgAABiRw.jpg",
        "sizes" : [ {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 573,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 670,
          "resize" : "fit",
          "w" : 1198
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/MbzPiLNfix"
      } ],
      "hashtags" : [ {
        "text" : "TPTAssist",
        "indices" : [ 78, 88 ]
      }, {
        "text" : "MyBrothersKeeper",
        "indices" : [ 89, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/L6bj9PEdxB",
        "expanded_url" : "http:\/\/playerstribu.ne\/lizzie",
        "display_url" : "playerstribu.ne\/lizzie"
      } ]
    },
    "geo" : { },
    "id_str" : "631507099177086976",
    "text" : ".@De11eDonne on what her sister Lizzie has taught her. http:\/\/t.co\/L6bj9PEdxB #TPTAssist #MyBrothersKeeper http:\/\/t.co\/MbzPiLNfix",
    "id" : 631507099177086976,
    "created_at" : "2015-08-12 16:46:39 +0000",
    "user" : {
      "name" : "The Players' Tribune",
      "screen_name" : "PlayersTribune",
      "protected" : false,
      "id_str" : "415605847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666226514174812160\/WHgyQ265_normal.jpg",
      "id" : 415605847,
      "verified" : true
    }
  },
  "id" : 631531509900382208,
  "created_at" : "2015-08-12 18:23:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 3, 18 ],
      "id_str" : "73181712",
      "id" : 73181712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldElephantDay",
      "indices" : [ 25, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/byh1uW03F1",
      "expanded_url" : "http:\/\/www.justice.gov\/enrd\/wildlife-trafficking",
      "display_url" : "justice.gov\/enrd\/wildlife-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631506665930518530",
  "text" : "RT @TheJusticeDept: It\u2019s #WorldElephantDay! Read about what we\u2019re doing to fight against wildlife trafficking: http:\/\/t.co\/byh1uW03F1 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheJusticeDept\/status\/631505109118115840\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Ahiu5Lsw1E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMOOjLsUEAAzfqb.jpg",
        "id_str" : "631505107847221248",
        "id" : 631505107847221248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMOOjLsUEAAzfqb.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ahiu5Lsw1E"
      } ],
      "hashtags" : [ {
        "text" : "WorldElephantDay",
        "indices" : [ 5, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/byh1uW03F1",
        "expanded_url" : "http:\/\/www.justice.gov\/enrd\/wildlife-trafficking",
        "display_url" : "justice.gov\/enrd\/wildlife-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "631505109118115840",
    "text" : "It\u2019s #WorldElephantDay! Read about what we\u2019re doing to fight against wildlife trafficking: http:\/\/t.co\/byh1uW03F1 http:\/\/t.co\/Ahiu5Lsw1E",
    "id" : 631505109118115840,
    "created_at" : "2015-08-12 16:38:45 +0000",
    "user" : {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "protected" : false,
      "id_str" : "73181712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445550654\/twitter_logo_normal.png",
      "id" : 73181712,
      "verified" : true
    }
  },
  "id" : 631506665930518530,
  "created_at" : "2015-08-12 16:44:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NYT Magazine",
      "screen_name" : "NYTmag",
      "indices" : [ 58, 65 ],
      "id_str" : "16929600",
      "id" : 16929600
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/631484077934116864\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/c2H4ZSJiZx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMN4g9xWgAA3xSN.jpg",
      "id_str" : "631480880494706688",
      "id" : 631480880494706688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMN4g9xWgAA3xSN.jpg",
      "sizes" : [ {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1376,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/c2H4ZSJiZx"
    } ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/GfkrJ8JRBD",
      "expanded_url" : "http:\/\/nyti.ms\/1L5jU6l",
      "display_url" : "nyti.ms\/1L5jU6l"
    } ]
  },
  "geo" : { },
  "id_str" : "631484077934116864",
  "text" : "\"Congress must restore the Voting Rights Act.\" \u2014@POTUS in @NYTmag: http:\/\/t.co\/GfkrJ8JRBD #VRA50 http:\/\/t.co\/c2H4ZSJiZx",
  "id" : 631484077934116864,
  "created_at" : "2015-08-12 15:15:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/631433709074411520\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/yysGJkJ1fn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMNNnLmWcAApd8c.jpg",
      "id_str" : "631433708285882368",
      "id" : 631433708285882368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMNNnLmWcAApd8c.jpg",
      "sizes" : [ {
        "h" : 559,
        "resize" : "fit",
        "w" : 999
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 999
      } ],
      "display_url" : "pic.twitter.com\/yysGJkJ1fn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/GfkrJ8JRBD",
      "expanded_url" : "http:\/\/nyti.ms\/1L5jU6l",
      "display_url" : "nyti.ms\/1L5jU6l"
    } ]
  },
  "geo" : { },
  "id_str" : "631475051401883649",
  "text" : "\"What makes America special is our capacity to change.\" \u2014@POTUS on the Voting Rights Act: http:\/\/t.co\/GfkrJ8JRBD http:\/\/t.co\/yysGJkJ1fn",
  "id" : 631475051401883649,
  "created_at" : "2015-08-12 14:39:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    }, {
      "name" : "NYT Magazine",
      "screen_name" : "NYTmag",
      "indices" : [ 39, 46 ],
      "id_str" : "16929600",
      "id" : 16929600
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/631433709074411520\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/g1HobvZ3kZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMNNnLmWcAApd8c.jpg",
      "id_str" : "631433708285882368",
      "id" : 631433708285882368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMNNnLmWcAApd8c.jpg",
      "sizes" : [ {
        "h" : 559,
        "resize" : "fit",
        "w" : 999
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 559,
        "resize" : "fit",
        "w" : 999
      } ],
      "display_url" : "pic.twitter.com\/g1HobvZ3kZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/UrFCSJGr6u",
      "expanded_url" : "http:\/\/nyti.ms\/1DMnFej",
      "display_url" : "nyti.ms\/1DMnFej"
    } ]
  },
  "geo" : { },
  "id_str" : "631458744384122880",
  "text" : "RT @nytimes: A letter to the editor of @NYTmag from @POTUS  http:\/\/t.co\/UrFCSJGr6u http:\/\/t.co\/g1HobvZ3kZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NYT Magazine",
        "screen_name" : "NYTmag",
        "indices" : [ 26, 33 ],
        "id_str" : "16929600",
        "id" : 16929600
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 39, 45 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/631433709074411520\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/g1HobvZ3kZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMNNnLmWcAApd8c.jpg",
        "id_str" : "631433708285882368",
        "id" : 631433708285882368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMNNnLmWcAApd8c.jpg",
        "sizes" : [ {
          "h" : 559,
          "resize" : "fit",
          "w" : 999
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 999
        } ],
        "display_url" : "pic.twitter.com\/g1HobvZ3kZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/UrFCSJGr6u",
        "expanded_url" : "http:\/\/nyti.ms\/1DMnFej",
        "display_url" : "nyti.ms\/1DMnFej"
      } ]
    },
    "geo" : { },
    "id_str" : "631433709074411520",
    "text" : "A letter to the editor of @NYTmag from @POTUS  http:\/\/t.co\/UrFCSJGr6u http:\/\/t.co\/g1HobvZ3kZ",
    "id" : 631433709074411520,
    "created_at" : "2015-08-12 11:55:02 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 631458744384122880,
  "created_at" : "2015-08-12 13:34:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. CBO",
      "screen_name" : "USCBO",
      "indices" : [ 107, 113 ],
      "id_str" : "1531265618",
      "id" : 1531265618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Jenshltyby",
      "expanded_url" : "http:\/\/bit.ly\/1IXfjwr",
      "display_url" : "bit.ly\/1IXfjwr"
    } ]
  },
  "geo" : { },
  "id_str" : "631236727202447361",
  "text" : "If Republicans in Congress agree to end harmful budget cuts, America could add up to 1.4 million jobs (via @USCBO): http:\/\/t.co\/Jenshltyby",
  "id" : 631236727202447361,
  "created_at" : "2015-08-11 22:52:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631199438560624640",
  "text" : "RT @SenatorReid: Once again, Republicans are leading us down the path of a shutdown. Here's how Democrats plan to avoid it: http:\/\/t.co\/Whq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/WhqrTX4iZG",
        "expanded_url" : "http:\/\/nyti.ms\/1IWekMZ",
        "display_url" : "nyti.ms\/1IWekMZ"
      } ]
    },
    "geo" : { },
    "id_str" : "631098822970572800",
    "text" : "Once again, Republicans are leading us down the path of a shutdown. Here's how Democrats plan to avoid it: http:\/\/t.co\/WhqrTX4iZG",
    "id" : 631098822970572800,
    "created_at" : "2015-08-11 13:44:19 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 631199438560624640,
  "created_at" : "2015-08-11 20:24:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ecological Society",
      "screen_name" : "ESA_org",
      "indices" : [ 39, 47 ],
      "id_str" : "18049298",
      "id" : 18049298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631190611492773889",
  "text" : "RT @Deese44: Watch @POTUS congratulate @ESA_org on 100 years of working to protect our environment and ecosystems. #ActOnClimate http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Ecological Society",
        "screen_name" : "ESA_org",
        "indices" : [ 26, 34 ],
        "id_str" : "18049298",
        "id" : 18049298
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/UeJUx6GQKe",
        "expanded_url" : "http:\/\/snpy.tv\/1KfPIje",
        "display_url" : "snpy.tv\/1KfPIje"
      } ]
    },
    "geo" : { },
    "id_str" : "631148431654793216",
    "text" : "Watch @POTUS congratulate @ESA_org on 100 years of working to protect our environment and ecosystems. #ActOnClimate http:\/\/t.co\/UeJUx6GQKe",
    "id" : 631148431654793216,
    "created_at" : "2015-08-11 17:01:26 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 631190611492773889,
  "created_at" : "2015-08-11 19:49:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631186562558996480",
  "text" : "RT @TheIranDeal: 36 former U.S. generals and admirals: The #IranDeal is \"the most effective means\" to stop a nuclear-armed Iran. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/8ZKROX5Vn4",
        "expanded_url" : "http:\/\/wapo.st\/1L3wxvQ",
        "display_url" : "wapo.st\/1L3wxvQ"
      } ]
    },
    "geo" : { },
    "id_str" : "631186233180487680",
    "text" : "36 former U.S. generals and admirals: The #IranDeal is \"the most effective means\" to stop a nuclear-armed Iran. http:\/\/t.co\/8ZKROX5Vn4",
    "id" : 631186233180487680,
    "created_at" : "2015-08-11 19:31:39 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 631186562558996480,
  "created_at" : "2015-08-11 19:32:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "indices" : [ 20, 25 ],
      "id_str" : "2983206962",
      "id" : 2983206962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/xxYldUI0OD",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/62ab498f-2e90-4fd9-80b5-e0bebe36bf51",
      "display_url" : "amp.twimg.com\/v\/62ab498f-2e9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "631183211557556224",
  "text" : "Happy 1st birthday, @USDS!\nHere's a taste of how they're improving digital government services.\nhttps:\/\/t.co\/xxYldUI0OD",
  "id" : 631183211557556224,
  "created_at" : "2015-08-11 19:19:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaun Donovan",
      "screen_name" : "ShaunOMB",
      "indices" : [ 3, 12 ],
      "id_str" : "2207588833",
      "id" : 2207588833
    }, {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 20, 32 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631159061879197696",
  "text" : "RT @ShaunOMB: Agree @SenatorReid: R's threaten government shutdown with a budget that guts the ACA and fails to lift the sequester. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Harry Reid",
        "screen_name" : "SenatorReid",
        "indices" : [ 6, 18 ],
        "id_str" : "16789970",
        "id" : 16789970
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/zvXdAp0lOy",
        "expanded_url" : "http:\/\/nyti.ms\/1DKrQYb",
        "display_url" : "nyti.ms\/1DKrQYb"
      } ]
    },
    "geo" : { },
    "id_str" : "631152305782390784",
    "text" : "Agree @SenatorReid: R's threaten government shutdown with a budget that guts the ACA and fails to lift the sequester. http:\/\/t.co\/zvXdAp0lOy",
    "id" : 631152305782390784,
    "created_at" : "2015-08-11 17:16:50 +0000",
    "user" : {
      "name" : "Shaun Donovan",
      "screen_name" : "ShaunOMB",
      "protected" : false,
      "id_str" : "2207588833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000771300655\/430835535c9ab3f854683bc176cc0a65_normal.jpeg",
      "id" : 2207588833,
      "verified" : true
    }
  },
  "id" : 631159061879197696,
  "created_at" : "2015-08-11 17:43:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/631138031311851520\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/FZ7U4P11BI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMI5Ol4W8AAi4FG.jpg",
      "id_str" : "631129820634738688",
      "id" : 631129820634738688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMI5Ol4W8AAi4FG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FZ7U4P11BI"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Bo7R8Lld2v",
      "expanded_url" : "http:\/\/n.pr\/1f3ZP1R",
      "display_url" : "n.pr\/1f3ZP1R"
    } ]
  },
  "geo" : { },
  "id_str" : "631138031311851520",
  "text" : "\"It cuts off all the pathways for Iran getting a nuclear weapon.\" \u2014@POTUS on the #IranDeal: http:\/\/t.co\/Bo7R8Lld2v http:\/\/t.co\/FZ7U4P11BI",
  "id" : 631138031311851520,
  "created_at" : "2015-08-11 16:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adobe",
      "screen_name" : "Adobe",
      "indices" : [ 3, 9 ],
      "id_str" : "63786611",
      "id" : 63786611
    }, {
      "name" : "Donna Morris",
      "screen_name" : "DonnaCMorris",
      "indices" : [ 54, 67 ],
      "id_str" : "204501827",
      "id" : 204501827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631135036700360705",
  "text" : "RT @Adobe: We're expanding our family leave programs. @DonnaCMorris on how we're helping employees care for their families: http:\/\/t.co\/hDT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donna Morris",
        "screen_name" : "DonnaCMorris",
        "indices" : [ 43, 56 ],
        "id_str" : "204501827",
        "id" : 204501827
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/hDTnZ7VsAq",
        "expanded_url" : "http:\/\/adobe.ly\/1gthd12",
        "display_url" : "adobe.ly\/1gthd12"
      } ]
    },
    "geo" : { },
    "id_str" : "630769798452899840",
    "text" : "We're expanding our family leave programs. @DonnaCMorris on how we're helping employees care for their families: http:\/\/t.co\/hDTnZ7VsAq",
    "id" : 630769798452899840,
    "created_at" : "2015-08-10 15:56:53 +0000",
    "user" : {
      "name" : "Adobe",
      "screen_name" : "Adobe",
      "protected" : false,
      "id_str" : "63786611",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782975599203667968\/Wehq2tqG_normal.jpg",
      "id" : 63786611,
      "verified" : true
    }
  },
  "id" : 631135036700360705,
  "created_at" : "2015-08-11 16:08:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Steve Inskeep",
      "screen_name" : "NPRinskeep",
      "indices" : [ 21, 32 ],
      "id_str" : "115710058",
      "id" : 115710058
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Bo7R8Lld2v",
      "expanded_url" : "http:\/\/n.pr\/1f3ZP1R",
      "display_url" : "n.pr\/1f3ZP1R"
    } ]
  },
  "geo" : { },
  "id_str" : "631126890913214464",
  "text" : "Listen to @POTUS and @NPRInskeep discuss how the #IranDeal prevents Iran from obtaining a nuclear weapon \u2192 http:\/\/t.co\/Bo7R8Lld2v",
  "id" : 631126890913214464,
  "created_at" : "2015-08-11 15:35:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/engadget\/status\/630479150613196800\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/g08JId9O9b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL_pcihUMAAt8p8.jpg",
      "id_str" : "630479149367308288",
      "id" : 630479149367308288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL_pcihUMAAt8p8.jpg",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g08JId9O9b"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/6UP7MYIN3t",
      "expanded_url" : "http:\/\/engt.co\/1W4jjoM",
      "display_url" : "engt.co\/1W4jjoM"
    } ]
  },
  "geo" : { },
  "id_str" : "631103837651103746",
  "text" : "RT @engadget: White House Demo Day focuses on diversity http:\/\/t.co\/6UP7MYIN3t http:\/\/t.co\/g08JId9O9b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/engadget\/status\/630479150613196800\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/g08JId9O9b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL_pcihUMAAt8p8.jpg",
        "id_str" : "630479149367308288",
        "id" : 630479149367308288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL_pcihUMAAt8p8.jpg",
        "sizes" : [ {
          "h" : 326,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/g08JId9O9b"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/6UP7MYIN3t",
        "expanded_url" : "http:\/\/engt.co\/1W4jjoM",
        "display_url" : "engt.co\/1W4jjoM"
      } ]
    },
    "geo" : { },
    "id_str" : "630479150613196800",
    "text" : "White House Demo Day focuses on diversity http:\/\/t.co\/6UP7MYIN3t http:\/\/t.co\/g08JId9O9b",
    "id" : 630479150613196800,
    "created_at" : "2015-08-09 20:41:57 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 631103837651103746,
  "created_at" : "2015-08-11 14:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mic",
      "screen_name" : "micnews",
      "indices" : [ 3, 11 ],
      "id_str" : "738709709608353792",
      "id" : 738709709608353792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 65, 74 ]
    }, {
      "text" : "POTUSMic",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/990omgSzsi",
      "expanded_url" : "http:\/\/bit.ly\/1KdWgyW",
      "display_url" : "bit.ly\/1KdWgyW"
    } ]
  },
  "geo" : { },
  "id_str" : "630845769193422848",
  "text" : "RT @micnews: President Obama slams Republicans for rejecting the #IranDeal without reading it http:\/\/t.co\/990omgSzsi #POTUSMic http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/micnews\/status\/630772446942089216\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/44xk0e7ibq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMD0MsDXAAAXwl8.png",
        "id_str" : "630772446652727296",
        "id" : 630772446652727296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMD0MsDXAAAXwl8.png",
        "sizes" : [ {
          "h" : 166,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 293,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 665
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 665
        } ],
        "display_url" : "pic.twitter.com\/44xk0e7ibq"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 52, 61 ]
      }, {
        "text" : "POTUSMic",
        "indices" : [ 104, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/990omgSzsi",
        "expanded_url" : "http:\/\/bit.ly\/1KdWgyW",
        "display_url" : "bit.ly\/1KdWgyW"
      } ]
    },
    "geo" : { },
    "id_str" : "630772446942089216",
    "text" : "President Obama slams Republicans for rejecting the #IranDeal without reading it http:\/\/t.co\/990omgSzsi #POTUSMic http:\/\/t.co\/44xk0e7ibq",
    "id" : 630772446942089216,
    "created_at" : "2015-08-10 16:07:25 +0000",
    "user" : {
      "name" : "Mic",
      "screen_name" : "mic",
      "protected" : false,
      "id_str" : "139909832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796262163488722944\/mGmueDSt_normal.jpg",
      "id" : 139909832,
      "verified" : true
    }
  },
  "id" : 630845769193422848,
  "created_at" : "2015-08-10 20:58:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 33, 45 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/630830521287716864\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8aCMEU9Qbg",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CMEo06kWsAA__zJ.png",
      "id_str" : "630830312348626944",
      "id" : 630830312348626944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CMEo06kWsAA__zJ.png",
      "sizes" : [ {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 539
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 539
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 539
      } ],
      "display_url" : "pic.twitter.com\/8aCMEU9Qbg"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/XaIBSZSOqz",
      "expanded_url" : "http:\/\/mic.com\/obama",
      "display_url" : "mic.com\/obama"
    } ]
  },
  "geo" : { },
  "id_str" : "630830521287716864",
  "text" : "Watch @POTUS answer questions on @TheIranDeal from young people around the world \u2192 http:\/\/t.co\/XaIBSZSOqz #IranDeal http:\/\/t.co\/8aCMEU9Qbg",
  "id" : 630830521287716864,
  "created_at" : "2015-08-10 19:58:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 42, 55 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/jHbU3ptcRD",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/c8aaa6d5-802e-478c-9ba0-34cc1c5c1894",
      "display_url" : "amp.twimg.com\/v\/c8aaa6d5-802\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "630800431862558720",
  "text" : ".@POTUS is taking the biggest step yet to #ActOnClimate.\nWatch a 3-minute recap of the past week. #CleanPowerPlan\nhttps:\/\/t.co\/jHbU3ptcRD",
  "id" : 630800431862558720,
  "created_at" : "2015-08-10 17:58:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 3, 18 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HuffingtonPost\/status\/630793034393866240\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/QCbjIICSpA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CMEG7A_UAAAagF6.jpg",
      "id_str" : "630793033756180480",
      "id" : 630793033756180480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMEG7A_UAAAagF6.jpg",
      "sizes" : [ {
        "h" : 177,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 470
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 470
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 470
      } ],
      "display_url" : "pic.twitter.com\/QCbjIICSpA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/IbTqs4oGjT",
      "expanded_url" : "http:\/\/huff.to\/1IEGqNA",
      "display_url" : "huff.to\/1IEGqNA"
    } ]
  },
  "geo" : { },
  "id_str" : "630794766456856580",
  "text" : "RT @HuffingtonPost: Yet another survey tells good news about Obamacare http:\/\/t.co\/IbTqs4oGjT http:\/\/t.co\/QCbjIICSpA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HuffingtonPost\/status\/630793034393866240\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/QCbjIICSpA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMEG7A_UAAAagF6.jpg",
        "id_str" : "630793033756180480",
        "id" : 630793033756180480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMEG7A_UAAAagF6.jpg",
        "sizes" : [ {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 470
        } ],
        "display_url" : "pic.twitter.com\/QCbjIICSpA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/IbTqs4oGjT",
        "expanded_url" : "http:\/\/huff.to\/1IEGqNA",
        "display_url" : "huff.to\/1IEGqNA"
      } ]
    },
    "geo" : { },
    "id_str" : "630793034393866240",
    "text" : "Yet another survey tells good news about Obamacare http:\/\/t.co\/IbTqs4oGjT http:\/\/t.co\/QCbjIICSpA",
    "id" : 630793034393866240,
    "created_at" : "2015-08-10 17:29:13 +0000",
    "user" : {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "protected" : false,
      "id_str" : "14511951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720642862551928832\/I58EQMCH_normal.jpg",
      "id" : 14511951,
      "verified" : true
    }
  },
  "id" : 630794766456856580,
  "created_at" : "2015-08-10 17:36:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PolicyMic",
      "screen_name" : "PolicyMic",
      "indices" : [ 3, 13 ],
      "id_str" : "2575941744",
      "id" : 2575941744
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "POTUSMic",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/uM7L9lWHmJ",
      "expanded_url" : "http:\/\/bit.ly\/1TkLI5Y",
      "display_url" : "bit.ly\/1TkLI5Y"
    } ]
  },
  "geo" : { },
  "id_str" : "630780388852391936",
  "text" : "RT @PolicyMic: President Obama to critics of the #IranDeal: Come up with an alternative http:\/\/t.co\/uM7L9lWHmJ #POTUSMic http:\/\/t.co\/8HtqnJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PolicyMic\/status\/630768880596709377\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/8HtqnJzuKK",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CMDw9C_WIAALPsv.png",
        "id_str" : "630768879397117952",
        "id" : 630768879397117952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CMDw9C_WIAALPsv.png",
        "sizes" : [ {
          "h" : 304,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 304,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 304,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8HtqnJzuKK"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 34, 43 ]
      }, {
        "text" : "POTUSMic",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/uM7L9lWHmJ",
        "expanded_url" : "http:\/\/bit.ly\/1TkLI5Y",
        "display_url" : "bit.ly\/1TkLI5Y"
      } ]
    },
    "geo" : { },
    "id_str" : "630768880596709377",
    "text" : "President Obama to critics of the #IranDeal: Come up with an alternative http:\/\/t.co\/uM7L9lWHmJ #POTUSMic http:\/\/t.co\/8HtqnJzuKK",
    "id" : 630768880596709377,
    "created_at" : "2015-08-10 15:53:14 +0000",
    "user" : {
      "name" : "PolicyMic",
      "screen_name" : "PolicyMic",
      "protected" : false,
      "id_str" : "2575941744",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479457406359851008\/T4PFR6kU_normal.png",
      "id" : 2575941744,
      "verified" : true
    }
  },
  "id" : 630780388852391936,
  "created_at" : "2015-08-10 16:38:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mic",
      "screen_name" : "micnews",
      "indices" : [ 3, 11 ],
      "id_str" : "738709709608353792",
      "id" : 738709709608353792
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "POTUSMic",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/PCbluVasLN",
      "expanded_url" : "http:\/\/bit.ly\/1MkALm7",
      "display_url" : "bit.ly\/1MkALm7"
    } ]
  },
  "geo" : { },
  "id_str" : "630769710926327809",
  "text" : "RT @micnews: We took your toughest #IranDeal questions to the White House, and @POTUS responded: http:\/\/t.co\/PCbluVasLN #POTUSMic http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 66, 72 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/micnews\/status\/630767699694592001\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/KRD2Jf0evN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMDv4X_WsAAERC-.png",
        "id_str" : "630767699623325696",
        "id" : 630767699623325696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMDv4X_WsAAERC-.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 275,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 275,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 275,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/KRD2Jf0evN"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 22, 31 ]
      }, {
        "text" : "POTUSMic",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/PCbluVasLN",
        "expanded_url" : "http:\/\/bit.ly\/1MkALm7",
        "display_url" : "bit.ly\/1MkALm7"
      } ]
    },
    "geo" : { },
    "id_str" : "630767699694592001",
    "text" : "We took your toughest #IranDeal questions to the White House, and @POTUS responded: http:\/\/t.co\/PCbluVasLN #POTUSMic http:\/\/t.co\/KRD2Jf0evN",
    "id" : 630767699694592001,
    "created_at" : "2015-08-10 15:48:33 +0000",
    "user" : {
      "name" : "Mic",
      "screen_name" : "mic",
      "protected" : false,
      "id_str" : "139909832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796262163488722944\/mGmueDSt_normal.jpg",
      "id" : 139909832,
      "verified" : true
    }
  },
  "id" : 630769710926327809,
  "created_at" : "2015-08-10 15:56:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "Mic",
      "screen_name" : "micnews",
      "indices" : [ 24, 32 ],
      "id_str" : "738709709608353792",
      "id" : 738709709608353792
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630758601691414528",
  "text" : "RT @TheIranDeal: WATCH: @micnews dives into the #IranDeal with @POTUS and explores what it means for young people across the globe. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mic",
        "screen_name" : "micnews",
        "indices" : [ 7, 15 ],
        "id_str" : "738709709608353792",
        "id" : 738709709608353792
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 46, 52 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/3Wy4BLyQAk",
        "expanded_url" : "http:\/\/mic.com\/obama",
        "display_url" : "mic.com\/obama"
      } ]
    },
    "geo" : { },
    "id_str" : "630758225659346945",
    "text" : "WATCH: @micnews dives into the #IranDeal with @POTUS and explores what it means for young people across the globe. http:\/\/t.co\/3Wy4BLyQAk",
    "id" : 630758225659346945,
    "created_at" : "2015-08-10 15:10:54 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 630758601691414528,
  "created_at" : "2015-08-10 15:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/thQQaYH5TV",
      "expanded_url" : "http:\/\/go.wh.gov\/VRA50",
      "display_url" : "go.wh.gov\/VRA50"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/iHtuGTUK1w",
      "expanded_url" : "http:\/\/snpy.tv\/1IocQhu",
      "display_url" : "snpy.tv\/1IocQhu"
    } ]
  },
  "geo" : { },
  "id_str" : "630755142866993152",
  "text" : "The right to vote is sacred.\nEvery American deserves equal access to the polls \u2192 http:\/\/t.co\/thQQaYH5TV #VRA50 http:\/\/t.co\/iHtuGTUK1w",
  "id" : 630755142866993152,
  "created_at" : "2015-08-10 14:58:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BoulderWhiteClouds",
      "indices" : [ 68, 87 ]
    }, {
      "text" : "Idaho",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/2oQW1fgRlh",
      "expanded_url" : "http:\/\/on.doi.gov\/1J1xur6",
      "display_url" : "on.doi.gov\/1J1xur6"
    } ]
  },
  "geo" : { },
  "id_str" : "630748330054676480",
  "text" : "RT @Interior: Here's a gorgeous pic of America's newest wilderness: #BoulderWhiteClouds by Ed Cannady #Idaho http:\/\/t.co\/2oQW1fgRlh http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/629778290040008704\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/QzR85Ei14X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1sAFrVEAAZtsP.jpg",
        "id_str" : "629778271681449984",
        "id" : 629778271681449984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1sAFrVEAAZtsP.jpg",
        "sizes" : [ {
          "h" : 626,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 626,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 208,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QzR85Ei14X"
      } ],
      "hashtags" : [ {
        "text" : "BoulderWhiteClouds",
        "indices" : [ 54, 73 ]
      }, {
        "text" : "Idaho",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/2oQW1fgRlh",
        "expanded_url" : "http:\/\/on.doi.gov\/1J1xur6",
        "display_url" : "on.doi.gov\/1J1xur6"
      } ]
    },
    "geo" : { },
    "id_str" : "629778290040008704",
    "text" : "Here's a gorgeous pic of America's newest wilderness: #BoulderWhiteClouds by Ed Cannady #Idaho http:\/\/t.co\/2oQW1fgRlh http:\/\/t.co\/QzR85Ei14X",
    "id" : 629778290040008704,
    "created_at" : "2015-08-07 22:16:59 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 630748330054676480,
  "created_at" : "2015-08-10 14:31:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lois Capps",
      "screen_name" : "RepLoisCapps",
      "indices" : [ 3, 16 ],
      "id_str" : "292990703",
      "id" : 292990703
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 27, 42 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630738130170056705",
  "text" : "RT @RepLoisCapps: .@POTUS' #CleanPowerPlan will bring a healthier future for Americans. RT if you agree: It's time to #ActOnClimate! http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RepLoisCapps\/status\/630736566059667457\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/vJTB5NeWFd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMDTkH-UcAAoKAU.jpg",
        "id_str" : "630736565401055232",
        "id" : 630736565401055232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMDTkH-UcAAoKAU.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1023
        } ],
        "display_url" : "pic.twitter.com\/vJTB5NeWFd"
      } ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 9, 24 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630736566059667457",
    "text" : ".@POTUS' #CleanPowerPlan will bring a healthier future for Americans. RT if you agree: It's time to #ActOnClimate! http:\/\/t.co\/vJTB5NeWFd",
    "id" : 630736566059667457,
    "created_at" : "2015-08-10 13:44:50 +0000",
    "user" : {
      "name" : "Lois Capps",
      "screen_name" : "RepLoisCapps",
      "protected" : false,
      "id_str" : "292990703",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/604321306578788352\/sF1VQ607_normal.jpg",
      "id" : 292990703,
      "verified" : true
    }
  },
  "id" : 630738130170056705,
  "created_at" : "2015-08-10 13:51:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoodMorning",
      "indices" : [ 21, 33 ]
    }, {
      "text" : "USA",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "YearInSpace",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630736578093027329",
  "text" : "RT @StationCDRKelly: #GoodMorning to those in the western #USA. Looks like there's a lot going on down there. #YearInSpace http:\/\/t.co\/Zeab\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StationCDRKelly\/status\/630719952555786240\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/ZeabnHFPFJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CMDEdGPXAAAHgfR.jpg",
        "id_str" : "630719952002154496",
        "id" : 630719952002154496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CMDEdGPXAAAHgfR.jpg",
        "sizes" : [ {
          "h" : 1065,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZeabnHFPFJ"
      } ],
      "hashtags" : [ {
        "text" : "GoodMorning",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "USA",
        "indices" : [ 37, 41 ]
      }, {
        "text" : "YearInSpace",
        "indices" : [ 89, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "630719952555786240",
    "text" : "#GoodMorning to those in the western #USA. Looks like there's a lot going on down there. #YearInSpace http:\/\/t.co\/ZeabnHFPFJ",
    "id" : 630719952555786240,
    "created_at" : "2015-08-10 12:38:49 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 630736578093027329,
  "created_at" : "2015-08-10 13:44:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/kNElqSPUsD",
      "expanded_url" : "http:\/\/go.wh.gov\/3bXM7p",
      "display_url" : "go.wh.gov\/3bXM7p"
    } ]
  },
  "geo" : { },
  "id_str" : "630483752737636353",
  "text" : "\"Let\u2019s keep marching forward, keep perfecting our union, and keep building a better country for our kids.\" \u2014@POTUS: http:\/\/t.co\/kNElqSPUsD",
  "id" : 630483752737636353,
  "created_at" : "2015-08-09 21:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/kNElqSPUsD",
      "expanded_url" : "http:\/\/go.wh.gov\/3bXM7p",
      "display_url" : "go.wh.gov\/3bXM7p"
    } ]
  },
  "geo" : { },
  "id_str" : "630445996032430084",
  "text" : "\"My message to every American is simple: get out there and vote.\" \u2014@POTUS: http:\/\/t.co\/kNElqSPUsD #VRA50",
  "id" : 630445996032430084,
  "created_at" : "2015-08-09 18:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 118, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/kNElqSPUsD",
      "expanded_url" : "http:\/\/go.wh.gov\/3bXM7p",
      "display_url" : "go.wh.gov\/3bXM7p"
    } ]
  },
  "geo" : { },
  "id_str" : "630405534357696512",
  "text" : "\"Fifty years after the Voting Rights Act, there are still too many barriers to vote.\" \u2014@POTUS: http:\/\/t.co\/kNElqSPUsD #VRA50",
  "id" : 630405534357696512,
  "created_at" : "2015-08-09 15:49:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/kNElqSPUsD",
      "expanded_url" : "http:\/\/go.wh.gov\/3bXM7p",
      "display_url" : "go.wh.gov\/3bXM7p"
    } ]
  },
  "geo" : { },
  "id_str" : "630106267558674433",
  "text" : "\"Our country is a better place because of all those heroes did for us.\" \u2014@POTUS on the Civil Rights Movement: http:\/\/t.co\/kNElqSPUsD #VRA50",
  "id" : 630106267558674433,
  "created_at" : "2015-08-08 20:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/kNElqSPUsD",
      "expanded_url" : "http:\/\/go.wh.gov\/3bXM7p",
      "display_url" : "go.wh.gov\/3bXM7p"
    } ]
  },
  "geo" : { },
  "id_str" : "630076067806445569",
  "text" : "\"It was, and still is, one of the greatest victories in our country\u2019s struggle for civil rights.\" \u2014@POTUS on #VRA50: http:\/\/t.co\/kNElqSPUsD",
  "id" : 630076067806445569,
  "created_at" : "2015-08-08 18:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/kNElqT7vRd",
      "expanded_url" : "http:\/\/go.wh.gov\/3bXM7p",
      "display_url" : "go.wh.gov\/3bXM7p"
    } ]
  },
  "geo" : { },
  "id_str" : "630028770779512836",
  "text" : "\"The right to vote is one of the most fundamental rights of any democracy.\" \u2014@POTUS: http:\/\/t.co\/kNElqT7vRd #VRA50",
  "id" : 630028770779512836,
  "created_at" : "2015-08-08 14:52:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/629762916703580160\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/1snIcTKuEa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL1deDoWcAAHEPE.jpg",
      "id_str" : "629762293853745152",
      "id" : 629762293853745152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL1deDoWcAAHEPE.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1208
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1snIcTKuEa"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 75, 88 ]
    }, {
      "text" : "BoulderWhiteClouds",
      "indices" : [ 89, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/N4ohGwWjvK",
      "expanded_url" : "http:\/\/go.wh.gov\/S55x1j",
      "display_url" : "go.wh.gov\/S55x1j"
    } ]
  },
  "geo" : { },
  "id_str" : "629762916703580160",
  "text" : ".@POTUS just protected more public lands in Idaho \u2192 http:\/\/t.co\/N4ohGwWjvK #FindYourPark #BoulderWhiteClouds http:\/\/t.co\/1snIcTKuEa",
  "id" : 629762916703580160,
  "created_at" : "2015-08-07 21:15:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/629755202086633472\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/691isiugdm",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CL1WvvvWoAAqbkC.png",
      "id_str" : "629754901170659328",
      "id" : 629754901170659328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CL1WvvvWoAAqbkC.png",
      "sizes" : [ {
        "h" : 253,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/691isiugdm"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 70, 85 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 86, 95 ]
    }, {
      "text" : "LoveWins",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "IranDeal",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/qK23wtqSbB",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es1rTGB-9",
      "display_url" : "tmblr.co\/ZW21es1rTGB-9"
    } ]
  },
  "geo" : { },
  "id_str" : "629755202086633472",
  "text" : "Interesting things happen in the 4th quarter \u2192 http:\/\/t.co\/qK23wtqSbB\n#CleanPowerPlan #ACAWorks #LoveWins #IranDeal http:\/\/t.co\/691isiugdm",
  "id" : 629755202086633472,
  "created_at" : "2015-08-07 20:45:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RestoreTheVRA",
      "indices" : [ 88, 102 ]
    }, {
      "text" : "VRA50",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Xc7SEzuXOM",
      "expanded_url" : "http:\/\/go.wh.gov\/VotingRightsAct",
      "display_url" : "go.wh.gov\/VotingRightsAct"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/iHtuGUckT4",
      "expanded_url" : "http:\/\/snpy.tv\/1IocQhu",
      "display_url" : "snpy.tv\/1IocQhu"
    } ]
  },
  "geo" : { },
  "id_str" : "629742101509484544",
  "text" : "Every American deserves equal access to the polls \u2192 http:\/\/t.co\/Xc7SEzuXOM\nIt's time to #RestoreTheVRA. #VRA50 http:\/\/t.co\/iHtuGUckT4",
  "id" : 629742101509484544,
  "created_at" : "2015-08-07 19:53:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/629688734854856704\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/QE3qUvKIzz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL0adxOWoAAxF-X.jpg",
      "id_str" : "629688621633806336",
      "id" : 629688621633806336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL0adxOWoAAxF-X.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QE3qUvKIzz"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 13, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629688734854856704",
  "text" : "In 2030, the #CleanPowerPlan will PREVENT:\nUp to 3,600 premature deaths.\n90,000 asthma attacks among kids. http:\/\/t.co\/QE3qUvKIzz",
  "id" : 629688734854856704,
  "created_at" : "2015-08-07 16:21:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/629673699310981120\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/qdKXH268ch",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CL0MnCKWwAAFkgZ.jpg",
      "id_str" : "629673387636473856",
      "id" : 629673387636473856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL0MnCKWwAAFkgZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qdKXH268ch"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629673699310981120",
  "text" : "Our businesses added more than 200,000 jobs in 15 of the past 17 months\u2014the first time that\u2019s happened since 1995. http:\/\/t.co\/qdKXH268ch",
  "id" : 629673699310981120,
  "created_at" : "2015-08-07 15:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BoulderWhiteClouds",
      "indices" : [ 72, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/YVTrAyn2Vc",
      "expanded_url" : "http:\/\/www.idahostatesman.com\/2015\/08\/04\/3924035_boulder-white-clouds-bill-passes.html?rh=1",
      "display_url" : "idahostatesman.com\/2015\/08\/04\/392\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629662235699355648",
  "text" : "RT @Deese44: Big news: POTUS will sign bill protecting 275,000 acres of #BoulderWhiteClouds as wilderness http:\/\/t.co\/YVTrAyn2Vc http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/629661927145246722\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/APsefjme8X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CL0BusyWUAAM7Ab.jpg",
        "id_str" : "629661424709685248",
        "id" : 629661424709685248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CL0BusyWUAAM7Ab.jpg",
        "sizes" : [ {
          "h" : 219,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 124,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/APsefjme8X"
      } ],
      "hashtags" : [ {
        "text" : "BoulderWhiteClouds",
        "indices" : [ 59, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/YVTrAyn2Vc",
        "expanded_url" : "http:\/\/www.idahostatesman.com\/2015\/08\/04\/3924035_boulder-white-clouds-bill-passes.html?rh=1",
        "display_url" : "idahostatesman.com\/2015\/08\/04\/392\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629661927145246722",
    "text" : "Big news: POTUS will sign bill protecting 275,000 acres of #BoulderWhiteClouds as wilderness http:\/\/t.co\/YVTrAyn2Vc http:\/\/t.co\/APsefjme8X",
    "id" : 629661927145246722,
    "created_at" : "2015-08-07 14:34:36 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 629662235699355648,
  "created_at" : "2015-08-07 14:35:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/629658184395956225\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/0Q8Si5Eipr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLz-puHWgAA0VMa.jpg",
      "id_str" : "629658040631984128",
      "id" : 629658040631984128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLz-puHWgAA0VMa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0Q8Si5Eipr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/C8P76lnNkb",
      "expanded_url" : "http:\/\/go.wh.gov\/JulyJobs",
      "display_url" : "go.wh.gov\/JulyJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "629658184395956225",
  "text" : "Last month, our businesses extended the longest streak of job growth on record \u2192 http:\/\/t.co\/C8P76lnNkb http:\/\/t.co\/0Q8Si5Eipr",
  "id" : 629658184395956225,
  "created_at" : "2015-08-07 14:19:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629653679931564033",
  "text" : "RT @CEAChair: Unemployment rate has now fully recovered from Great Recession but we must build on progress to help all workers. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CEAChair\/status\/629652004894175232\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/KWxKxNiEp5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLz5KWZXAAAqwl6.jpg",
        "id_str" : "629652004130979840",
        "id" : 629652004130979840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLz5KWZXAAAqwl6.jpg",
        "sizes" : [ {
          "h" : 825,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KWxKxNiEp5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629652004894175232",
    "text" : "Unemployment rate has now fully recovered from Great Recession but we must build on progress to help all workers. http:\/\/t.co\/KWxKxNiEp5",
    "id" : 629652004894175232,
    "created_at" : "2015-08-07 13:55:10 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 629653679931564033,
  "created_at" : "2015-08-07 14:01:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/629487159766978560\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/jlqvb2uL5Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLxUzcrWsAAy6k3.jpg",
      "id_str" : "629471290773123072",
      "id" : 629471290773123072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLxUzcrWsAAy6k3.jpg",
      "sizes" : [ {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jlqvb2uL5Q"
    } ],
    "hashtags" : [ {
      "text" : "JonVoyage",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/l1IEX8pKpR",
      "expanded_url" : "http:\/\/go.wh.gov\/SJ2jzy",
      "display_url" : "go.wh.gov\/SJ2jzy"
    } ]
  },
  "geo" : { },
  "id_str" : "629487159766978560",
  "text" : "\"I\u2019m issuing a new executive order\u2014that Jon Stewart cannot leave the show\" \u2014@POTUS: http:\/\/t.co\/l1IEX8pKpR #JonVoyage http:\/\/t.co\/jlqvb2uL5Q",
  "id" : 629487159766978560,
  "created_at" : "2015-08-07 03:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 59, 72 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/629447611255164929\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/UxCVwBC2EW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLw_LsCW8AA5vtp.jpg",
      "id_str" : "629447517957189632",
      "id" : 629447517957189632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLw_LsCW8AA5vtp.jpg",
      "sizes" : [ {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UxCVwBC2EW"
    } ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/4MCfT7xdYX",
      "expanded_url" : "http:\/\/go.wh.gov\/uWTLVk",
      "display_url" : "go.wh.gov\/uWTLVk"
    } ]
  },
  "geo" : { },
  "id_str" : "629447611255164929",
  "text" : "\"We didn't give up.\nWe didn't give in.\nWe kept the faith\"\n\u2014@RepJohnLewis: http:\/\/t.co\/4MCfT7xdYX #VRA50 http:\/\/t.co\/UxCVwBC2EW",
  "id" : 629447611255164929,
  "created_at" : "2015-08-07 00:22:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629406445264486403",
  "text" : "RT @VP: Medgar Evers. Fannie Lou Hamer. Bob Moses. James Chaney. Andrew Goodman. Michael Schwerner. We salute you. #VRA50 http:\/\/t.co\/03r2c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/629391564104568832\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/03r2cBgDLP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLwMSquUMAAZ98e.jpg",
        "id_str" : "629391562770755584",
        "id" : 629391562770755584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLwMSquUMAAZ98e.jpg",
        "sizes" : [ {
          "h" : 537,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 537,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/03r2cBgDLP"
      } ],
      "hashtags" : [ {
        "text" : "VRA50",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629391564104568832",
    "text" : "Medgar Evers. Fannie Lou Hamer. Bob Moses. James Chaney. Andrew Goodman. Michael Schwerner. We salute you. #VRA50 http:\/\/t.co\/03r2cBgDLP",
    "id" : 629391564104568832,
    "created_at" : "2015-08-06 20:40:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 629406445264486403,
  "created_at" : "2015-08-06 21:39:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 1, 14 ],
      "id_str" : "29450962",
      "id" : 29450962
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 46, 56 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/629392820483194880\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/J6DLTbPQiy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLwNRMuVEAAXkqE.jpg",
      "id_str" : "629392637049507840",
      "id" : 629392637049507840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLwNRMuVEAAXkqE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/J6DLTbPQiy"
    } ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/RLfPczV7P2",
      "expanded_url" : "https:\/\/instagram.com\/p\/6Dh4UIwikP\/",
      "display_url" : "instagram.com\/p\/6Dh4UIwikP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "629392820483194880",
  "text" : ".@RepJohnLewis is taking over the White House @Instagram.\nFollow along \u2192 https:\/\/t.co\/RLfPczV7P2 #VRA50 http:\/\/t.co\/J6DLTbPQiy",
  "id" : 629392820483194880,
  "created_at" : "2015-08-06 20:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/G0yhLEUfIV",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/08\/06\/statement-vice-president-biden-50th-anniversary-voting-rights-act",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629389024621301760",
  "text" : "RT @VP: The right to vote is the most fundamental right. It's the right from which all others flow. https:\/\/t.co\/G0yhLEUfIV http:\/\/t.co\/Cst\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/629385462415671296\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/CstxRBEijN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLwGvhBUcAAT4jW.jpg",
        "id_str" : "629385461312548864",
        "id" : 629385461312548864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLwGvhBUcAAT4jW.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/CstxRBEijN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/G0yhLEUfIV",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/08\/06\/statement-vice-president-biden-50th-anniversary-voting-rights-act",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629385462415671296",
    "text" : "The right to vote is the most fundamental right. It's the right from which all others flow. https:\/\/t.co\/G0yhLEUfIV http:\/\/t.co\/CstxRBEijN",
    "id" : 629385462415671296,
    "created_at" : "2015-08-06 20:16:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 629389024621301760,
  "created_at" : "2015-08-06 20:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 3, 9 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ldJJqmF5hw",
      "expanded_url" : "http:\/\/nbcnews.to\/1DtAMRV",
      "display_url" : "nbcnews.to\/1DtAMRV"
    } ]
  },
  "geo" : { },
  "id_str" : "629379152089583616",
  "text" : "RT @msnbc: JUST IN: President Obama proclaims September 22 National Voter Registration Day. #VRA50 http:\/\/t.co\/ldJJqmF5hw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VRA50",
        "indices" : [ 81, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/ldJJqmF5hw",
        "expanded_url" : "http:\/\/nbcnews.to\/1DtAMRV",
        "display_url" : "nbcnews.to\/1DtAMRV"
      } ]
    },
    "geo" : { },
    "id_str" : "629365310836051968",
    "text" : "JUST IN: President Obama proclaims September 22 National Voter Registration Day. #VRA50 http:\/\/t.co\/ldJJqmF5hw",
    "id" : 629365310836051968,
    "created_at" : "2015-08-06 18:55:57 +0000",
    "user" : {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "protected" : false,
      "id_str" : "2836421",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753308587498364928\/b53eqF6C_normal.jpg",
      "id" : 2836421,
      "verified" : true
    }
  },
  "id" : 629379152089583616,
  "created_at" : "2015-08-06 19:50:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 85, 98 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 103, 116 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/629374896892706817\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WhuHY0UnlK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLv9If5WIAMSUB5.jpg",
      "id_str" : "629374895391121411",
      "id" : 629374895391121411,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLv9If5WIAMSUB5.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WhuHY0UnlK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629377797455249410",
  "text" : "RT @vj44: .@POTUS makes a surprise visit to address the 50th anniversary of VRA with @LorettaLynch and @repjohnlewis http:\/\/t.co\/WhuHY0UnlK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "AG Loretta Lynch",
        "screen_name" : "LorettaLynch",
        "indices" : [ 75, 88 ],
        "id_str" : "3290070855",
        "id" : 3290070855
      }, {
        "name" : "John Lewis",
        "screen_name" : "repjohnlewis",
        "indices" : [ 93, 106 ],
        "id_str" : "29450962",
        "id" : 29450962
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/629374896892706817\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/WhuHY0UnlK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLv9If5WIAMSUB5.jpg",
        "id_str" : "629374895391121411",
        "id" : 629374895391121411,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLv9If5WIAMSUB5.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WhuHY0UnlK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629374896892706817",
    "text" : ".@POTUS makes a surprise visit to address the 50th anniversary of VRA with @LorettaLynch and @repjohnlewis http:\/\/t.co\/WhuHY0UnlK",
    "id" : 629374896892706817,
    "created_at" : "2015-08-06 19:34:03 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 629377797455249410,
  "created_at" : "2015-08-06 19:45:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/629363361231294465\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/4Rl7bI9vuj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLvynXNWUAIt0CZ.jpg",
      "id_str" : "629363331007139842",
      "id" : 629363331007139842,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLvynXNWUAIt0CZ.jpg",
      "sizes" : [ {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1272,
        "resize" : "fit",
        "w" : 1934
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4Rl7bI9vuj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629363361231294465",
  "text" : "\"Do not succumb to cynicism.\nHeroic things happen when people get involved.\" \u2014@POTUS on the importance of voting http:\/\/t.co\/4Rl7bI9vuj",
  "id" : 629363361231294465,
  "created_at" : "2015-08-06 18:48:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629362810745696256",
  "text" : "RT @WHLive: \"Huge chunks of us\u2014citizens\u2014just give away our power. We\u2019d rather complain than do something about it.\" \u2014@POTUS on the importan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 105, 111 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629362737110482944",
    "text" : "\"Huge chunks of us\u2014citizens\u2014just give away our power. We\u2019d rather complain than do something about it.\" \u2014@POTUS on the importance of voting",
    "id" : 629362737110482944,
    "created_at" : "2015-08-06 18:45:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 629362810745696256,
  "created_at" : "2015-08-06 18:46:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629362380586254336",
  "text" : "\"Far more people disenfranchise themselves than any law does by not participating.\" \u2014@POTUS on the importance of voting #VRA50",
  "id" : 629362380586254336,
  "created_at" : "2015-08-06 18:44:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629361592052936704",
  "text" : "\"In theory, everybody\u2019s in favor of the right to vote.\nIn practice, we have state legislatures\u2026trying to make it harder to vote.\" \u2014@POTUS",
  "id" : 629361592052936704,
  "created_at" : "2015-08-06 18:41:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RestoreTheVRA",
      "indices" : [ 110, 124 ]
    }, {
      "text" : "VRA50",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629360910402985984",
  "text" : "\u201CThis has to be a priority. If this isn\u2019t working, then nothing\u2019s working. We\u2019ve got to get it done.\u201D \u2014@POTUS #RestoreTheVRA #VRA50",
  "id" : 629360910402985984,
  "created_at" : "2015-08-06 18:38:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/XMXdOTP08C",
      "expanded_url" : "http:\/\/go.wh.gov\/VotingRightsAct",
      "display_url" : "go.wh.gov\/VotingRightsAct"
    } ]
  },
  "geo" : { },
  "id_str" : "629360601215692801",
  "text" : "RT @WHLive: \"One order of business is for...Congress to pass an updated version of the Voting Rights Act\" \u2014@POTUS: http:\/\/t.co\/XMXdOTP08C #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 95, 101 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RestoreTheVRA",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/XMXdOTP08C",
        "expanded_url" : "http:\/\/go.wh.gov\/VotingRightsAct",
        "display_url" : "go.wh.gov\/VotingRightsAct"
      } ]
    },
    "geo" : { },
    "id_str" : "629360572874797057",
    "text" : "\"One order of business is for...Congress to pass an updated version of the Voting Rights Act\" \u2014@POTUS: http:\/\/t.co\/XMXdOTP08C #RestoreTheVRA",
    "id" : 629360572874797057,
    "created_at" : "2015-08-06 18:37:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 629360601215692801,
  "created_at" : "2015-08-06 18:37:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RestoreTheVRA",
      "indices" : [ 109, 123 ]
    }, {
      "text" : "VRA50",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Xc7SEzMzdm",
      "expanded_url" : "http:\/\/go.wh.gov\/VotingRightsAct",
      "display_url" : "go.wh.gov\/VotingRightsAct"
    } ]
  },
  "geo" : { },
  "id_str" : "629359780142956547",
  "text" : "\"There are still too many ways in which people are discouraged from voting.\u201D \u2014@POTUS: http:\/\/t.co\/Xc7SEzMzdm #RestoreTheVRA #VRA50",
  "id" : 629359780142956547,
  "created_at" : "2015-08-06 18:33:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Xc7SEzMzdm",
      "expanded_url" : "http:\/\/go.wh.gov\/VotingRightsAct",
      "display_url" : "go.wh.gov\/VotingRightsAct"
    } ]
  },
  "geo" : { },
  "id_str" : "629359144567472128",
  "text" : "\"50 years ago today, President Johnson signed the Voting Rights Act into law to protect this precious right\" \u2014@POTUS: http:\/\/t.co\/Xc7SEzMzdm",
  "id" : 629359144567472128,
  "created_at" : "2015-08-06 18:31:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 95, 108 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Xc7SEzMzdm",
      "expanded_url" : "http:\/\/go.wh.gov\/VotingRightsAct",
      "display_url" : "go.wh.gov\/VotingRightsAct"
    } ]
  },
  "geo" : { },
  "id_str" : "629357858463875074",
  "text" : "\u201CWe didn\u2019t give up.\nWe didn\u2019t give in.\nWe kept the faith.\nAnd we kept our eyes on the prize.\u201D \u2014@RepJohnLewis: http:\/\/t.co\/Xc7SEzMzdm #VRA50",
  "id" : 629357858463875074,
  "created_at" : "2015-08-06 18:26:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 32, 45 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/629352649620606977\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/xbEWzpptkw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLvooG8XAAArJVY.jpg",
      "id_str" : "629352348704505856",
      "id" : 629352348704505856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLvooG8XAAArJVY.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xbEWzpptkw"
    } ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Xc7SEzMzdm",
      "expanded_url" : "http:\/\/go.wh.gov\/VotingRightsAct",
      "display_url" : "go.wh.gov\/VotingRightsAct"
    } ]
  },
  "geo" : { },
  "id_str" : "629352649620606977",
  "text" : "In 5 minutes: Join @POTUS &amp; @RepJohnLewis for a conversation on the Voting Rights Act \u2192 http:\/\/t.co\/Xc7SEzMzdm #VRA50 http:\/\/t.co\/xbEWzpptkw",
  "id" : 629352649620606977,
  "created_at" : "2015-08-06 18:05:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629346298341232641",
  "text" : "RT @POTUS: Thank you for all you've done to protect our sacred right to vote. It's as important today as it's ever been. https:\/\/t.co\/ge74w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/ge74wu5nc1",
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/629343428925636609",
        "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629343799299411969",
    "text" : "Thank you for all you've done to protect our sacred right to vote. It's as important today as it's ever been. https:\/\/t.co\/ge74wu5nc1",
    "id" : 629343799299411969,
    "created_at" : "2015-08-06 17:30:29 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 629346298341232641,
  "created_at" : "2015-08-06 17:40:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 23, 36 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629345177073774592",
  "text" : "RT @POTUS: Heroes like @RepJohnLewis, Dr. King, and countless others sacrificed so that all of our voices could be heard. http:\/\/t.co\/L7kxt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Lewis",
        "screen_name" : "repjohnlewis",
        "indices" : [ 12, 25 ],
        "id_str" : "29450962",
        "id" : 29450962
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/629342681962049538\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/L7kxtWQlYW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLvf0AIXAAAiLNM.jpg",
        "id_str" : "629342657429569536",
        "id" : 629342657429569536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLvf0AIXAAAiLNM.jpg",
        "sizes" : [ {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/L7kxtWQlYW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629342056876503040",
    "geo" : { },
    "id_str" : "629342681962049538",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Heroes like @RepJohnLewis, Dr. King, and countless others sacrificed so that all of our voices could be heard. http:\/\/t.co\/L7kxtWQlYW",
    "id" : 629342681962049538,
    "in_reply_to_status_id" : 629342056876503040,
    "created_at" : "2015-08-06 17:26:02 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 629345177073774592,
  "created_at" : "2015-08-06 17:35:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629344585542725632",
  "text" : "RT @POTUS: Before 1965, African Americans faced poll taxes, literacy tests, or having to count jellybeans in a jar when they tried to regis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "629341526439653377",
    "geo" : { },
    "id_str" : "629342056876503040",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Before 1965, African Americans faced poll taxes, literacy tests, or having to count jellybeans in a jar when they tried to register to vote.",
    "id" : 629342056876503040,
    "in_reply_to_status_id" : 629341526439653377,
    "created_at" : "2015-08-06 17:23:33 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 629344585542725632,
  "created_at" : "2015-08-06 17:33:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629344341853650945",
  "text" : "RT @POTUS: 50 years ago today, President Johnson signed the Voting Rights Act into law, securing the right to vote for millions of African \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629341526439653377",
    "text" : "50 years ago today, President Johnson signed the Voting Rights Act into law, securing the right to vote for millions of African Americans.",
    "id" : 629341526439653377,
    "created_at" : "2015-08-06 17:21:27 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 629344341853650945,
  "created_at" : "2015-08-06 17:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RestoreTheVRA",
      "indices" : [ 96, 110 ]
    }, {
      "text" : "VRA50",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/iHtuGTUK1w",
      "expanded_url" : "http:\/\/snpy.tv\/1IocQhu",
      "display_url" : "snpy.tv\/1IocQhu"
    } ]
  },
  "geo" : { },
  "id_str" : "629334089691234305",
  "text" : "50 years ago, President Johnson signed the Voting Rights Act into law.\nIt's time to restore it. #RestoreTheVRA #VRA50 http:\/\/t.co\/iHtuGTUK1w",
  "id" : 629334089691234305,
  "created_at" : "2015-08-06 16:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 16, 29 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/629325462796308480\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/4K4dLS9KnX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLvP_GhWUAAVbbB.jpg",
      "id_str" : "629325255937511424",
      "id" : 629325255937511424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLvP_GhWUAAVbbB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1615,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 827,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4K4dLS9KnX"
    } ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Xc7SEzuXOM",
      "expanded_url" : "http:\/\/go.wh.gov\/VotingRightsAct",
      "display_url" : "go.wh.gov\/VotingRightsAct"
    } ]
  },
  "geo" : { },
  "id_str" : "629325462796308480",
  "text" : "Join @POTUS and @RepJohnLewis for a conversation on the Voting Rights Act at 2pm ET \u2192 http:\/\/t.co\/Xc7SEzuXOM #VRA50 http:\/\/t.co\/4K4dLS9KnX",
  "id" : 629325462796308480,
  "created_at" : "2015-08-06 16:17:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/629290880512434176\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/TBcsbgplSy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLuwuIxUcAAdRNx.jpg",
      "id_str" : "629290879623131136",
      "id" : 629290879623131136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLuwuIxUcAAdRNx.jpg",
      "sizes" : [ {
        "h" : 658,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1316,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TBcsbgplSy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629322145064095744",
  "text" : "RT @repjohnlewis: At this time 50 yrs ago today, the Voting Rights Act of 1965 was signed into law. http:\/\/t.co\/TBcsbgplSy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/629290880512434176\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/TBcsbgplSy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLuwuIxUcAAdRNx.jpg",
        "id_str" : "629290879623131136",
        "id" : 629290879623131136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLuwuIxUcAAdRNx.jpg",
        "sizes" : [ {
          "h" : 658,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 218,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1316,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TBcsbgplSy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629290880512434176",
    "text" : "At this time 50 yrs ago today, the Voting Rights Act of 1965 was signed into law. http:\/\/t.co\/TBcsbgplSy",
    "id" : 629290880512434176,
    "created_at" : "2015-08-06 14:00:12 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 629322145064095744,
  "created_at" : "2015-08-06 16:04:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/weTkySiI0L",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/dd788f2c-319f-4e68-a432-43484a3c38f4",
      "display_url" : "amp.twimg.com\/v\/dd788f2c-319\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629316658021056512",
  "text" : "RT if you agree:\nThe right to vote is sacred.\nEvery American deserves equal access to the polls. #VRA50\nhttps:\/\/t.co\/weTkySiI0L",
  "id" : 629316658021056512,
  "created_at" : "2015-08-06 15:42:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/629301691255422976\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/idLoakSOio",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLu6BbCUwAAjkk7.jpg",
      "id_str" : "629301106548457472",
      "id" : 629301106548457472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLu6BbCUwAAjkk7.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/idLoakSOio"
    } ],
    "hashtags" : [ {
      "text" : "VRA50",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/thQQaYYGLt",
      "expanded_url" : "http:\/\/go.wh.gov\/VRA50",
      "display_url" : "go.wh.gov\/VRA50"
    } ]
  },
  "geo" : { },
  "id_str" : "629301691255422976",
  "text" : "\"The right to vote is one of the most fundamental rights of any democracy.\" \u2014@POTUS on #VRA50: http:\/\/t.co\/thQQaYYGLt http:\/\/t.co\/idLoakSOio",
  "id" : 629301691255422976,
  "created_at" : "2015-08-06 14:43:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RestoreTheVRA",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629299350808711168",
  "text" : "RT @NancyPelosi: As 50 yrs ago when LBJ signed VRA, we must live up to the promise of our democracy &amp; act swiftly to #RestoreTheVRA! http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RestoreTheVRA",
        "indices" : [ 104, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/4fYRls4G3Y",
        "expanded_url" : "http:\/\/goo.gl\/W1yK0m",
        "display_url" : "goo.gl\/W1yK0m"
      } ]
    },
    "geo" : { },
    "id_str" : "629299098940801024",
    "text" : "As 50 yrs ago when LBJ signed VRA, we must live up to the promise of our democracy &amp; act swiftly to #RestoreTheVRA! http:\/\/t.co\/4fYRls4G3Y",
    "id" : 629299098940801024,
    "created_at" : "2015-08-06 14:32:51 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 629299350808711168,
  "created_at" : "2015-08-06 14:33:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 23, 36 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 43, 56 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629293052020940801",
  "text" : "RT @vj44: Join @POTUS, @LorettaLynch &amp; @repjohnlewis today to commemorate the 50th Anniversary of the Voting Rights Act http:\/\/t.co\/1IwwYPh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 5, 11 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "AG Loretta Lynch",
        "screen_name" : "LorettaLynch",
        "indices" : [ 13, 26 ],
        "id_str" : "3290070855",
        "id" : 3290070855
      }, {
        "name" : "John Lewis",
        "screen_name" : "repjohnlewis",
        "indices" : [ 33, 46 ],
        "id_str" : "29450962",
        "id" : 29450962
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VRA50",
        "indices" : [ 137, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/1IwwYPhcnT",
        "expanded_url" : "http:\/\/WhiteHouse.gov\/VotingRightsAct",
        "display_url" : "WhiteHouse.gov\/VotingRightsAct"
      } ]
    },
    "geo" : { },
    "id_str" : "629289568336896000",
    "text" : "Join @POTUS, @LorettaLynch &amp; @repjohnlewis today to commemorate the 50th Anniversary of the Voting Rights Act http:\/\/t.co\/1IwwYPhcnT #VRA50",
    "id" : 629289568336896000,
    "created_at" : "2015-08-06 13:54:59 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 629293052020940801,
  "created_at" : "2015-08-06 14:08:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629277604734865409",
  "text" : "RT @repjohnlewis: Our vote is the foundation of democracy. A just &amp; fair society requires the removal of any &amp; all barriers to the ballot b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RestoreTheVRA",
        "indices" : [ 133, 147 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629265088214638592",
    "text" : "Our vote is the foundation of democracy. A just &amp; fair society requires the removal of any &amp; all barriers to the ballot box. #RestoreTheVRA",
    "id" : 629265088214638592,
    "created_at" : "2015-08-06 12:17:42 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 629277604734865409,
  "created_at" : "2015-08-06 13:07:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 84, 94 ],
      "id_str" : "74286565",
      "id" : 74286565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Co3X1R96um",
      "expanded_url" : "https:\/\/twitter.com\/MSFTnews\/status\/628975635810140160",
      "display_url" : "twitter.com\/MSFTnews\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "629090368374632448",
  "text" : "RT @vj44: Companies across America continue to step up and #LeadOnLeave.  Well done @Microsoft! https:\/\/t.co\/Co3X1R96um",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Microsoft",
        "screen_name" : "Microsoft",
        "indices" : [ 74, 84 ],
        "id_str" : "74286565",
        "id" : 74286565
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 49, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/Co3X1R96um",
        "expanded_url" : "https:\/\/twitter.com\/MSFTnews\/status\/628975635810140160",
        "display_url" : "twitter.com\/MSFTnews\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629058713291223040",
    "text" : "Companies across America continue to step up and #LeadOnLeave.  Well done @Microsoft! https:\/\/t.co\/Co3X1R96um",
    "id" : 629058713291223040,
    "created_at" : "2015-08-05 22:37:39 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 629090368374632448,
  "created_at" : "2015-08-06 00:43:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 88, 93 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629065219583520768",
  "text" : "RT @POTUS: Pretty incredible time lapse of the dark side of the moon passing Earth from @NASA. American ingenuity at work! http:\/\/t.co\/JKep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 77, 82 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/629064761188184064\/video\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/JKep9bcxGQ",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/629064721891766272\/pu\/img\/JVUKrM9Uo3LvGCSN.jpg",
        "id_str" : "629064721891766272",
        "id" : 629064721891766272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/629064721891766272\/pu\/img\/JVUKrM9Uo3LvGCSN.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JKep9bcxGQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "629064761188184064",
    "text" : "Pretty incredible time lapse of the dark side of the moon passing Earth from @NASA. American ingenuity at work! http:\/\/t.co\/JKep9bcxGQ",
    "id" : 629064761188184064,
    "created_at" : "2015-08-05 23:01:41 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 629065219583520768,
  "created_at" : "2015-08-05 23:03:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629032745461747713",
  "text" : "RT @POTUS: Important detail \u2013 there are no secret deals. My staff can brief you on any question about any part of the deal. https:\/\/t.co\/UO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/UO0B5xCOPh",
        "expanded_url" : "https:\/\/twitter.com\/stevescalise\/status\/628971521663475712",
        "display_url" : "twitter.com\/stevescalise\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629030795299147776",
    "text" : "Important detail \u2013 there are no secret deals. My staff can brief you on any question about any part of the deal. https:\/\/t.co\/UO0B5xCOPh",
    "id" : 629030795299147776,
    "created_at" : "2015-08-05 20:46:43 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 629032745461747713,
  "created_at" : "2015-08-05 20:54:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629031159293280257",
  "text" : "RT @POTUS: The choice is ultimately between diplomacy and war. Iran's nuclear program accelerates if Congress kills this deal. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/nvBeO1Omko",
        "expanded_url" : "https:\/\/twitter.com\/senatemajldr\/status\/628946892236451840",
        "display_url" : "twitter.com\/senatemajldr\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629030461449338881",
    "text" : "The choice is ultimately between diplomacy and war. Iran's nuclear program accelerates if Congress kills this deal. https:\/\/t.co\/nvBeO1Omko",
    "id" : 629030461449338881,
    "created_at" : "2015-08-05 20:45:23 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 629031159293280257,
  "created_at" : "2015-08-05 20:48:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629028670431064064",
  "text" : "RT @POTUS: It's the strongest nuclear deal ever negotiated. There's no such thing as a \"better deal.\" Walking away risks war. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/la7GhQXfzl",
        "expanded_url" : "https:\/\/twitter.com\/angelakkmiller\/status\/628944989406556160",
        "display_url" : "twitter.com\/angelakkmiller\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "629028301454094336",
    "text" : "It's the strongest nuclear deal ever negotiated. There's no such thing as a \"better deal.\" Walking away risks war. https:\/\/t.co\/la7GhQXfzl",
    "id" : 629028301454094336,
    "created_at" : "2015-08-05 20:36:48 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 629028670431064064,
  "created_at" : "2015-08-05 20:38:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/uLwwXnXtbA",
      "expanded_url" : "http:\/\/snpy.tv\/1MbaFBL",
      "display_url" : "snpy.tv\/1MbaFBL"
    } ]
  },
  "geo" : { },
  "id_str" : "629018046129139712",
  "text" : "\"The choice we face is ultimately between diplomacy or some form of war\" \u2014@POTUS on the importance of the #IranDeal http:\/\/t.co\/uLwwXnXtbA",
  "id" : 629018046129139712,
  "created_at" : "2015-08-05 19:56:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628982805758877698",
  "text" : "RT @TheIranDeal: \"Many of the same people who argued for the war in Iraq are now making the case against the #IranDeal.\"\u2014@POTUS http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 104, 110 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/dLN9crJfJk",
        "expanded_url" : "http:\/\/snpy.tv\/1DqigtD",
        "display_url" : "snpy.tv\/1DqigtD"
      } ]
    },
    "geo" : { },
    "id_str" : "628981367619981312",
    "text" : "\"Many of the same people who argued for the war in Iraq are now making the case against the #IranDeal.\"\u2014@POTUS http:\/\/t.co\/dLN9crJfJk",
    "id" : 628981367619981312,
    "created_at" : "2015-08-05 17:30:18 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628982805758877698,
  "created_at" : "2015-08-05 17:36:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628979343767810048",
  "text" : "RT @TheIranDeal: .@POTUS: \"A nuclear-armed Iran is far more dangerous to Israel ... than an Iran that benefits from sanctions relief.\" http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/niNdmNp5Af",
        "expanded_url" : "http:\/\/snpy.tv\/1Mbbs5G",
        "display_url" : "snpy.tv\/1Mbbs5G"
      } ]
    },
    "geo" : { },
    "id_str" : "628978183224868864",
    "text" : ".@POTUS: \"A nuclear-armed Iran is far more dangerous to Israel ... than an Iran that benefits from sanctions relief.\" http:\/\/t.co\/niNdmNp5Af",
    "id" : 628978183224868864,
    "created_at" : "2015-08-05 17:17:39 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628979343767810048,
  "created_at" : "2015-08-05 17:22:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/sQQaSr6Otx",
      "expanded_url" : "http:\/\/snpy.tv\/1Mb9Clu",
      "display_url" : "snpy.tv\/1Mb9Clu"
    } ]
  },
  "geo" : { },
  "id_str" : "628974527595315200",
  "text" : "\"By killing this deal, Congress wouldn't merely pave Iran\u2019s pathway to a bomb, it would accelerate it\" \u2014@POTUS http:\/\/t.co\/sQQaSr6Otx",
  "id" : 628974527595315200,
  "created_at" : "2015-08-05 17:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628972340190117888",
  "text" : "\"If Congress kills this deal, we will lose...America\u2019s credibility as a leader of diplomacy\" \u2014@POTUS on the #IranDeal",
  "id" : 628972340190117888,
  "created_at" : "2015-08-05 16:54:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628971945338499072",
  "text" : "\"We now have a solution that prevents Iran from obtaining a nuclear weapon, without resorting to war.\" \u2014@POTUS on the #IranDeal",
  "id" : 628971945338499072,
  "created_at" : "2015-08-05 16:52:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628971228343078912",
  "text" : "\"'Peace is not absence of conflict,' President Reagan once said. It is 'the ability to cope with conflict by peaceful means'\" \u2014@POTUS",
  "id" : 628971228343078912,
  "created_at" : "2015-08-05 16:50:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628970794668834816",
  "text" : "RT @TheIranDeal: \"I have challenged anyone to put forward a better, plausible alternative. I have yet to hear one.\" \u2014@POTUS on the #IranDeal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 100, 106 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 114, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628970761303257088",
    "text" : "\"I have challenged anyone to put forward a better, plausible alternative. I have yet to hear one.\" \u2014@POTUS on the #IranDeal",
    "id" : 628970761303257088,
    "created_at" : "2015-08-05 16:48:09 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628970794668834816,
  "created_at" : "2015-08-05 16:48:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628970440141197312",
  "text" : "\"A nuclear-armed Iran is far more dangerous\u2014to Israel, to America...than an Iran that ultimately benefits from sanctions relief\" \u2014@POTUS",
  "id" : 628970440141197312,
  "created_at" : "2015-08-05 16:46:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628969257393479680",
  "text" : "RT @TheIranDeal: \"When we carefully examine the arguments against the deal, none of them stand up to scrutiny.\" \u2014@POTUS: http:\/\/t.co\/HjNGpv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 96, 102 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/HjNGpvCjxc",
        "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
        "display_url" : "go.wh.gov\/IranDeal"
      } ]
    },
    "geo" : { },
    "id_str" : "628969213240209408",
    "text" : "\"When we carefully examine the arguments against the deal, none of them stand up to scrutiny.\" \u2014@POTUS: http:\/\/t.co\/HjNGpvCjxc #IranDeal",
    "id" : 628969213240209408,
    "created_at" : "2015-08-05 16:42:00 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628969257393479680,
  "created_at" : "2015-08-05 16:42:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628968727200071681",
  "text" : "\"Just because Iranian hardliners chant 'Death to America' does not mean that\u2019s what all Iranians believe\" \u2014@POTUS #IranDeal",
  "id" : 628968727200071681,
  "created_at" : "2015-08-05 16:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628968397552758786",
  "text" : "\u201CHow can we in good conscience justify war before we have tested a diplomatic agreement that achieves our objectives?\" \u2014@POTUS #IranDeal",
  "id" : 628968397552758786,
  "created_at" : "2015-08-05 16:38:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628967945255792640",
  "text" : "\"If we\u2019ve learned anything from the last decade, it\u2019s that wars...particularly in the Middle East, are anything but simple.\" \u2014@POTUS",
  "id" : 628967945255792640,
  "created_at" : "2015-08-05 16:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/3PJ1t0Zk7U",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628967476269703169",
  "text" : "\"Let\u2019s not mince words\u2014the choice we face is ultimately between diplomacy or some form of war.\" \u2014@POTUS: http:\/\/t.co\/3PJ1t0Zk7U #IranDeal",
  "id" : 628967476269703169,
  "created_at" : "2015-08-05 16:35:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/3PJ1t1gVwu",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628967198661451776",
  "text" : "\"Congressional rejection of this deal leaves\u2026one option: Another war in the Middle East.\" \u2014@POTUS: http:\/\/t.co\/3PJ1t1gVwu #IranDeal",
  "id" : 628967198661451776,
  "created_at" : "2015-08-05 16:34:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628965740297756672",
  "text" : "\"If we\u2019re serious about confronting Iran\u2019s destabilizing activities, it is hard to imagine a worse approach than blocking this deal\" \u2014@POTUS",
  "id" : 628965740297756672,
  "created_at" : "2015-08-05 16:28:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628965586505043969",
  "text" : "RT @TheIranDeal: \"We will continue to have sanctions in place on Iran\u2019s support for terrorism and violation of human rights\" \u2014@POTUS #IranD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 109, 115 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 116, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628965553051336704",
    "text" : "\"We will continue to have sanctions in place on Iran\u2019s support for terrorism and violation of human rights\" \u2014@POTUS #IranDeal",
    "id" : 628965553051336704,
    "created_at" : "2015-08-05 16:27:28 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628965586505043969,
  "created_at" : "2015-08-05 16:27:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628965220157755392",
  "text" : "RT @TheIranDeal: \"Whatever benefit Iran may claim from sanctions relief pales in comparison to the danger it could pose with a nuclear weap\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 128, 134 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628965193834438656",
    "text" : "\"Whatever benefit Iran may claim from sanctions relief pales in comparison to the danger it could pose with a nuclear weapon.\" \u2014@POTUS",
    "id" : 628965193834438656,
    "created_at" : "2015-08-05 16:26:02 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628965220157755392,
  "created_at" : "2015-08-05 16:26:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628964590865547264\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/52Ut2MBsnG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqH9kUVAAAsIXb.jpg",
      "id_str" : "628964589762314240",
      "id" : 628964589762314240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqH9kUVAAAsIXb.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/52Ut2MBsnG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628964590865547264",
  "text" : "\"By killing this deal, Congress wouldn't merely pave Iran\u2019s pathway to a bomb, it would accelerate it\" \u2014@POTUS http:\/\/t.co\/52Ut2MBsnG",
  "id" : 628964590865547264,
  "created_at" : "2015-08-05 16:23:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628964162123730944",
  "text" : "\"The prohibition on Iran having a nuclear weapon is permanent. The ban on weapons-related research is permanent.\" \u2014@POTUS #IranDeal",
  "id" : 628964162123730944,
  "created_at" : "2015-08-05 16:21:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628964048608997377\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/U9lcSPjfde",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqHdlYUsAALXzE.jpg",
      "id_str" : "628964040291692544",
      "id" : 628964040291692544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqHdlYUsAALXzE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/U9lcSPjfde"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628964048608997377",
  "text" : "\"Nuclear material isn\u2019t something you hide in the closet...if Iran cheats, we can catch them.\" \u2014@POTUS #IranDeal http:\/\/t.co\/U9lcSPjfde",
  "id" : 628964048608997377,
  "created_at" : "2015-08-05 16:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628963372222943232",
  "text" : "\"This deal is not just the best choice among alternatives\u2014this is the strongest non-proliferation agreement ever negotiated.\" \u2014@POTUS",
  "id" : 628963372222943232,
  "created_at" : "2015-08-05 16:18:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/3PJ1t0Zk7U",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628963265138143233",
  "text" : "\"If Iran violates the agreement, all of the sanctions can snap back into place\" \u2014@POTUS: http:\/\/t.co\/3PJ1t0Zk7U #IranDeal",
  "id" : 628963265138143233,
  "created_at" : "2015-08-05 16:18:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/HjNGpvCjxc",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628963135215419392",
  "text" : "RT @TheIranDeal: \"Inspectors will also have the ability to inspect any suspicious sites in Iran.\" \u2014@POTUS: http:\/\/t.co\/HjNGpvCjxc http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 82, 88 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/628963094698569728\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/MFVekQWJp9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqGmPgVEAEhnrN.jpg",
        "id_str" : "628963089526886401",
        "id" : 628963089526886401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqGmPgVEAEhnrN.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MFVekQWJp9"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/HjNGpvCjxc",
        "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
        "display_url" : "go.wh.gov\/IranDeal"
      } ]
    },
    "geo" : { },
    "id_str" : "628963094698569728",
    "text" : "\"Inspectors will also have the ability to inspect any suspicious sites in Iran.\" \u2014@POTUS: http:\/\/t.co\/HjNGpvCjxc http:\/\/t.co\/MFVekQWJp9",
    "id" : 628963094698569728,
    "created_at" : "2015-08-05 16:17:42 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628963135215419392,
  "created_at" : "2015-08-05 16:17:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628962483655589888\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/0gFSzPUxb5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqGBjNVAAA0HCb.jpg",
      "id_str" : "628962459160739840",
      "id" : 628962459160739840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqGBjNVAAA0HCb.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 259
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2497,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 457
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 779
      } ],
      "display_url" : "pic.twitter.com\/0gFSzPUxb5"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/3PJ1t1gVwu",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628962483655589888",
  "text" : "\"Under its terms, Iran is never allowed to build a nuclear weapon.\" \u2014@POTUS on the #IranDeal: http:\/\/t.co\/3PJ1t1gVwu http:\/\/t.co\/0gFSzPUxb5",
  "id" : 628962483655589888,
  "created_at" : "2015-08-05 16:15:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628961968083333120",
  "text" : "RT @TheIranDeal: \"The progress of Iran\u2019s nuclear program was halted for the first time in a decade.\" \u2014@POTUS on the interim deal with Iran \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 85, 91 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628961945945829376",
    "text" : "\"The progress of Iran\u2019s nuclear program was halted for the first time in a decade.\" \u2014@POTUS on the interim deal with Iran in 2013 #IranDeal",
    "id" : 628961945945829376,
    "created_at" : "2015-08-05 16:13:08 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628961968083333120,
  "created_at" : "2015-08-05 16:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/3PJ1t1gVwu",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628961573294505984",
  "text" : "\"It was diplomacy\u2014hard, painstaking diplomacy...that ratcheted up the pressure on Iran\" \u2014@POTUS: http:\/\/t.co\/3PJ1t1gVwu #IranDeal",
  "id" : 628961573294505984,
  "created_at" : "2015-08-05 16:11:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628960954248769536",
  "text" : "\"A negotiated agreement offered a more effective, verifiable &amp; durable resolution\" \u2014@POTUS on preventing Iran from obtaining a nuclear bomb",
  "id" : 628960954248769536,
  "created_at" : "2015-08-05 16:09:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628960815270490112",
  "text" : "\"Even before taking office, I made clear that Iran would not be allowed to acquire a nuclear weapon on my watch\" \u2014@POTUS #IranDeal",
  "id" : 628960815270490112,
  "created_at" : "2015-08-05 16:08:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628959709480005637",
  "text" : "\"America didn\u2019t just have to end that war\u2014we had to end the mindset that got us there in the first place.\" \u2014@POTUS on the war in Iraq",
  "id" : 628959709480005637,
  "created_at" : "2015-08-05 16:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/628959353366822912\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/t9Nw2ntpuz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqDMGnUcAEtZKB.jpg",
      "id_str" : "628959341928804353",
      "id" : 628959341928804353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqDMGnUcAEtZKB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/t9Nw2ntpuz"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/HjNGpvCjxc",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628959377106595840",
  "text" : "RT @TheIranDeal: \"It cuts off all of Iran\u2019s pathways to a bomb.\" \u2014@POTUS on the #IranDeal: http:\/\/t.co\/HjNGpvCjxc http:\/\/t.co\/t9Nw2ntpuz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 49, 55 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/628959353366822912\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/t9Nw2ntpuz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqDMGnUcAEtZKB.jpg",
        "id_str" : "628959341928804353",
        "id" : 628959341928804353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqDMGnUcAEtZKB.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/t9Nw2ntpuz"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 63, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/HjNGpvCjxc",
        "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
        "display_url" : "go.wh.gov\/IranDeal"
      } ]
    },
    "geo" : { },
    "id_str" : "628959353366822912",
    "text" : "\"It cuts off all of Iran\u2019s pathways to a bomb.\" \u2014@POTUS on the #IranDeal: http:\/\/t.co\/HjNGpvCjxc http:\/\/t.co\/t9Nw2ntpuz",
    "id" : 628959353366822912,
    "created_at" : "2015-08-05 16:02:49 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628959377106595840,
  "created_at" : "2015-08-05 16:02:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/628959263092834304\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/QCs1Q7b8DZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLqDG9vUMAAvTP6.jpg",
      "id_str" : "628959253647077376",
      "id" : 628959253647077376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLqDG9vUMAAvTP6.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QCs1Q7b8DZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628959263092834304",
  "text" : "\"We have achieved a detailed arrangement that permanently prohibits Iran from obtaining a nuclear weapon\" \u2014@POTUS http:\/\/t.co\/QCs1Q7b8DZ",
  "id" : 628959263092834304,
  "created_at" : "2015-08-05 16:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628958401662439424",
  "text" : "\"52 years ago, President Kennedy, at the height of the Cold War, addressed this University on the subject of peace.\" \u2014@POTUS #IranDeal",
  "id" : 628958401662439424,
  "created_at" : "2015-08-05 15:59:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 37, 49 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "American University",
      "screen_name" : "AmericanU",
      "indices" : [ 53, 63 ],
      "id_str" : "32433037",
      "id" : 32433037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/3PJ1t0Zk7U",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628958307768623104",
  "text" : "Happening now: Watch @POTUS speak on @TheIranDeal at @AmericanU \u2192 http:\/\/t.co\/3PJ1t0Zk7U",
  "id" : 628958307768623104,
  "created_at" : "2015-08-05 15:58:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/628936082436980737\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/E1aLeB9k4g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLpq-GGUAAEAeMJ.jpg",
      "id_str" : "628932712993128449",
      "id" : 628932712993128449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLpq-GGUAAEAeMJ.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E1aLeB9k4g"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/8Ok1VoFm2z",
      "expanded_url" : "http:\/\/theatln.tc\/1M3vwFN",
      "display_url" : "theatln.tc\/1M3vwFN"
    } ]
  },
  "geo" : { },
  "id_str" : "628951080865525760",
  "text" : "RT @TheIranDeal: 9 reasons to support the #IranDeal: http:\/\/t.co\/8Ok1VoFm2z http:\/\/t.co\/E1aLeB9k4g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/628936082436980737\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/E1aLeB9k4g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLpq-GGUAAEAeMJ.jpg",
        "id_str" : "628932712993128449",
        "id" : 628932712993128449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLpq-GGUAAEAeMJ.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/E1aLeB9k4g"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 25, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/8Ok1VoFm2z",
        "expanded_url" : "http:\/\/theatln.tc\/1M3vwFN",
        "display_url" : "theatln.tc\/1M3vwFN"
      } ]
    },
    "geo" : { },
    "id_str" : "628936082436980737",
    "text" : "9 reasons to support the #IranDeal: http:\/\/t.co\/8Ok1VoFm2z http:\/\/t.co\/E1aLeB9k4g",
    "id" : 628936082436980737,
    "created_at" : "2015-08-05 14:30:21 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628951080865525760,
  "created_at" : "2015-08-05 15:29:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 36, 48 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "American University",
      "screen_name" : "AmericanU",
      "indices" : [ 52, 62 ],
      "id_str" : "32433037",
      "id" : 32433037
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/628939138746617856\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/QilgFu7AkX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLpwzGTUsAAC3Hu.jpg",
      "id_str" : "628939121138905088",
      "id" : 628939121138905088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLpwzGTUsAAC3Hu.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QilgFu7AkX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/3PJ1t0Zk7U",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628939138746617856",
  "text" : "Watch @POTUS speak at 11:20am ET on @TheIranDeal at @AmericanU \u2192 http:\/\/t.co\/3PJ1t0Zk7U http:\/\/t.co\/QilgFu7AkX",
  "id" : 628939138746617856,
  "created_at" : "2015-08-05 14:42:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 21, 33 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/628915818252926976\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/e1NziXjd8F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLpbeqhUwAEoZ4r.jpg",
      "id_str" : "628915680339869697",
      "id" : 628915680339869697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLpbeqhUwAEoZ4r.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e1NziXjd8F"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/3PJ1t1gVwu",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDeal",
      "display_url" : "go.wh.gov\/IranDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "628915818252926976",
  "text" : "Have questions about @TheIranDeal?\nAsk with #IranDeal before @POTUS speaks at 11:20am ET \u2192 http:\/\/t.co\/3PJ1t1gVwu http:\/\/t.co\/e1NziXjd8F",
  "id" : 628915818252926976,
  "created_at" : "2015-08-05 13:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/628713363934031872\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/mKmRwnHAoe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLmjeOIUYAATJr_.jpg",
      "id_str" : "628713362579283968",
      "id" : 628713362579283968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLmjeOIUYAATJr_.jpg",
      "sizes" : [ {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mKmRwnHAoe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/f1JoQtNqHx",
      "expanded_url" : "https:\/\/instagram.com\/p\/5-vVO3Fwe-\/?taken-by=vp",
      "display_url" : "instagram.com\/p\/5-vVO3Fwe-\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628755947486380032",
  "text" : "RT @VP: Happy 54th birthday, Mr. President. Proud to have your back every day. https:\/\/t.co\/f1JoQtNqHx http:\/\/t.co\/mKmRwnHAoe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/628713363934031872\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/mKmRwnHAoe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLmjeOIUYAATJr_.jpg",
        "id_str" : "628713362579283968",
        "id" : 628713362579283968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLmjeOIUYAATJr_.jpg",
        "sizes" : [ {
          "h" : 2731,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/mKmRwnHAoe"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/f1JoQtNqHx",
        "expanded_url" : "https:\/\/instagram.com\/p\/5-vVO3Fwe-\/?taken-by=vp",
        "display_url" : "instagram.com\/p\/5-vVO3Fwe-\/?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628713363934031872",
    "text" : "Happy 54th birthday, Mr. President. Proud to have your back every day. https:\/\/t.co\/f1JoQtNqHx http:\/\/t.co\/mKmRwnHAoe",
    "id" : 628713363934031872,
    "created_at" : "2015-08-04 23:45:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 628755947486380032,
  "created_at" : "2015-08-05 02:34:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 59, 62 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628754135756750848",
  "text" : "RT @AmbassadorPower: Ahead of September UNGA, @POTUS &amp; @UN Sec-Gen today discuss strengthening UN peacekeeping &amp; combatting climate change \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 25, 31 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "United Nations",
        "screen_name" : "UN",
        "indices" : [ 38, 41 ],
        "id_str" : "14159148",
        "id" : 14159148
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmbassadorPower\/status\/628726707869077505\/photo\/1",
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/U0h014xfnt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLmvm-_WwAAlHF2.jpg",
        "id_str" : "628726707273515008",
        "id" : 628726707273515008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLmvm-_WwAAlHF2.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/U0h014xfnt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628726707869077505",
    "text" : "Ahead of September UNGA, @POTUS &amp; @UN Sec-Gen today discuss strengthening UN peacekeeping &amp; combatting climate change http:\/\/t.co\/U0h014xfnt",
    "id" : 628726707869077505,
    "created_at" : "2015-08-05 00:38:22 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 628754135756750848,
  "created_at" : "2015-08-05 02:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628715747917856768",
  "text" : "RT @TheIranDeal: Tomorrow, @POTUS will speak on how the Iran deal prevents Iran from obtaining a nuclear weapon. Have questions? Ask us wit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628714288790646784",
    "text" : "Tomorrow, @POTUS will speak on how the Iran deal prevents Iran from obtaining a nuclear weapon. Have questions? Ask us with #IranDeal.",
    "id" : 628714288790646784,
    "created_at" : "2015-08-04 23:49:02 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628715747917856768,
  "created_at" : "2015-08-04 23:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628708029865656320\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/gZeypQJBkr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLmejwqWIAQQCyQ.jpg",
      "id_str" : "628707960190017540",
      "id" : 628707960190017540,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLmejwqWIAQQCyQ.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 453
      } ],
      "display_url" : "pic.twitter.com\/gZeypQJBkr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628708029865656320",
  "text" : "Happy birthday, @POTUS! http:\/\/t.co\/gZeypQJBkr",
  "id" : 628708029865656320,
  "created_at" : "2015-08-04 23:24:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netflix US",
      "screen_name" : "netflix",
      "indices" : [ 3, 11 ],
      "id_str" : "16573941",
      "id" : 16573941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/zO6OtRPZvX",
      "expanded_url" : "http:\/\/nflx.it\/1W03kIv",
      "display_url" : "nflx.it\/1W03kIv"
    } ]
  },
  "geo" : { },
  "id_str" : "628695039573655552",
  "text" : "RT @netflix: Netflix moms and dads now get unlimited time off in their new baby's first year: http:\/\/t.co\/zO6OtRPZvX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/zO6OtRPZvX",
        "expanded_url" : "http:\/\/nflx.it\/1W03kIv",
        "display_url" : "nflx.it\/1W03kIv"
      } ]
    },
    "geo" : { },
    "id_str" : "628687139006509056",
    "text" : "Netflix moms and dads now get unlimited time off in their new baby's first year: http:\/\/t.co\/zO6OtRPZvX",
    "id" : 628687139006509056,
    "created_at" : "2015-08-04 22:01:09 +0000",
    "user" : {
      "name" : "Netflix US",
      "screen_name" : "netflix",
      "protected" : false,
      "id_str" : "16573941",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744949842720391168\/wuzyVTTX_normal.jpg",
      "id" : 16573941,
      "verified" : true
    }
  },
  "id" : 628695039573655552,
  "created_at" : "2015-08-04 22:32:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Weather Channel",
      "screen_name" : "weatherchannel",
      "indices" : [ 3, 18 ],
      "id_str" : "20998647",
      "id" : 20998647
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 67, 71 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 74, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628693892301475842",
  "text" : "RT @weatherchannel: The estimated climate &amp; health benefits of @EPA's #CleanPowerPlan are as much as $54 billion in the year 2030 alone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 47, 51 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 54, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628679305824964608",
    "text" : "The estimated climate &amp; health benefits of @EPA's #CleanPowerPlan are as much as $54 billion in the year 2030 alone.",
    "id" : 628679305824964608,
    "created_at" : "2015-08-04 21:30:01 +0000",
    "user" : {
      "name" : "The Weather Channel",
      "screen_name" : "weatherchannel",
      "protected" : false,
      "id_str" : "20998647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786232930108669952\/6099cLdV_normal.jpg",
      "id" : 20998647,
      "verified" : true
    }
  },
  "id" : 628693892301475842,
  "created_at" : "2015-08-04 22:27:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 29, 35 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 92, 99 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/628664428997820416\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/IQo3laOwxs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLl2nNyUcAAu8vU.jpg",
      "id_str" : "628664039082586112",
      "id" : 628664039082586112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLl2nNyUcAAu8vU.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IQo3laOwxs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628676347930349568",
  "text" : "RT @DrBiden: Happy birthday, @POTUS! Joe and I hope your birthday is as much fun as you and @FLOTUS are! \u2013Jill http:\/\/t.co\/IQo3laOwxs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 16, 22 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 79, 86 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/628664428997820416\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/IQo3laOwxs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLl2nNyUcAAu8vU.jpg",
        "id_str" : "628664039082586112",
        "id" : 628664039082586112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLl2nNyUcAAu8vU.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/IQo3laOwxs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628664428997820416",
    "text" : "Happy birthday, @POTUS! Joe and I hope your birthday is as much fun as you and @FLOTUS are! \u2013Jill http:\/\/t.co\/IQo3laOwxs",
    "id" : 628664428997820416,
    "created_at" : "2015-08-04 20:30:54 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 628676347930349568,
  "created_at" : "2015-08-04 21:18:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628667581197586432",
  "text" : "RT @FLOTUS: Happy birthday to a loving husband, wonderful father and my favorite dance partner. 54 looks good on you, @POTUS! -mo http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 106, 112 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/628647361380626432\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/B2JSxCTcCo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlmqYVWcAASzwB.jpg",
        "id_str" : "628646501267435520",
        "id" : 628646501267435520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlmqYVWcAASzwB.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1535,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1366
        } ],
        "display_url" : "pic.twitter.com\/B2JSxCTcCo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628647361380626432",
    "text" : "Happy birthday to a loving husband, wonderful father and my favorite dance partner. 54 looks good on you, @POTUS! -mo http:\/\/t.co\/B2JSxCTcCo",
    "id" : 628647361380626432,
    "created_at" : "2015-08-04 19:23:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 628667581197586432,
  "created_at" : "2015-08-04 20:43:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/eHvUuk4N9m",
      "expanded_url" : "http:\/\/go.wh.gov\/DemoDay",
      "display_url" : "go.wh.gov\/DemoDay"
    } ]
  },
  "geo" : { },
  "id_str" : "628664371342786560",
  "text" : "\"Ideas can come from anyone, anywhere, and they can be inspired by any kind of life experience.\" \u2014@POTUS: http:\/\/t.co\/eHvUuk4N9m #WHDemoDay",
  "id" : 628664371342786560,
  "created_at" : "2015-08-04 20:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628662987331620864",
  "text" : "RT @WHLive: \"We\u2019ve got to unleash the full potential of every American\u2014not leave more than half the team on the bench.\" \u2014@POTUS #WHDemoDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 109, 115 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHDemoDay",
        "indices" : [ 116, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628662837142024192",
    "text" : "\"We\u2019ve got to unleash the full potential of every American\u2014not leave more than half the team on the bench.\" \u2014@POTUS #WHDemoDay",
    "id" : 628662837142024192,
    "created_at" : "2015-08-04 20:24:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 628662987331620864,
  "created_at" : "2015-08-04 20:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628662672352014336",
  "text" : "\"We\u2019ve got to make sure everybody\u2019s getting a fair shot\u2014because the next Steve Jobs might be named Stephanie or Esteban.\" \u2014@POTUS #WHDemoDay",
  "id" : 628662672352014336,
  "created_at" : "2015-08-04 20:23:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628662532962709504\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/leq7CZWFIa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLl1OXCWgAAghwe.jpg",
      "id_str" : "628662512557391872",
      "id" : 628662512557391872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLl1OXCWgAAghwe.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/leq7CZWFIa"
    } ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628662532962709504",
  "text" : "\"Fewer than 3% of venture capital-backed companies have a woman as their CEO.\" \u2014@POTUS #WHDemoDay http:\/\/t.co\/leq7CZWFIa",
  "id" : 628662532962709504,
  "created_at" : "2015-08-04 20:23:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/CSNTGeVCCV",
      "expanded_url" : "http:\/\/go.wh.gov\/DemoDay",
      "display_url" : "go.wh.gov\/DemoDay"
    } ]
  },
  "geo" : { },
  "id_str" : "628662344160116736",
  "text" : "RT @WHLive: \"Today, America is home to more high-tech companies than anywhere else in the world.\" \u2014@POTUS: http:\/\/t.co\/CSNTGeVCCV #WHDemoDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 87, 93 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHDemoDay",
        "indices" : [ 118, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/CSNTGeVCCV",
        "expanded_url" : "http:\/\/go.wh.gov\/DemoDay",
        "display_url" : "go.wh.gov\/DemoDay"
      } ]
    },
    "geo" : { },
    "id_str" : "628662318407135232",
    "text" : "\"Today, America is home to more high-tech companies than anywhere else in the world.\" \u2014@POTUS: http:\/\/t.co\/CSNTGeVCCV #WHDemoDay",
    "id" : 628662318407135232,
    "created_at" : "2015-08-04 20:22:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 628662344160116736,
  "created_at" : "2015-08-04 20:22:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628662073384251392",
  "text" : "\"From Lewis and Clark to Sally Ride.\nWe\u2019re the nation of Franklin and Edison.\nCarver and Salk.\nJobs, Gates.\"\n\u2014@POTUS #WHDemoDay",
  "id" : 628662073384251392,
  "created_at" : "2015-08-04 20:21:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628661965963943936",
  "text" : "RT @WHLive: \"In America, that\u2019s who we\u2019ve always been\u2014explorers of that next frontier, pioneers with a vision of tomorrow.\" \u2014@POTUS #WHDemo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 113, 119 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHDemoDay",
        "indices" : [ 120, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628661940965879808",
    "text" : "\"In America, that\u2019s who we\u2019ve always been\u2014explorers of that next frontier, pioneers with a vision of tomorrow.\" \u2014@POTUS #WHDemoDay",
    "id" : 628661940965879808,
    "created_at" : "2015-08-04 20:21:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 628661965963943936,
  "created_at" : "2015-08-04 20:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 138, 144 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628661326659743745",
  "text" : "\"For my birthday, I thought I\u2019d invite business leaders, investors, &amp; government officials...for the 1st-ever White House Demo Day.\" \u2014@POTUS",
  "id" : 628661326659743745,
  "created_at" : "2015-08-04 20:18:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628649410122133505\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/YoAH1Q1BAc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlpRi6WUAANO5s.jpg",
      "id_str" : "628649373145124864",
      "id" : 628649373145124864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlpRi6WUAANO5s.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YoAH1Q1BAc"
    } ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/eHvUujNchO",
      "expanded_url" : "http:\/\/go.wh.gov\/DemoDay",
      "display_url" : "go.wh.gov\/DemoDay"
    } ]
  },
  "geo" : { },
  "id_str" : "628649410122133505",
  "text" : "Happening now: Watch @POTUS tour entrepreneurs' projects at the #WHDemoDay \u2192 http:\/\/t.co\/eHvUujNchO http:\/\/t.co\/YoAH1Q1BAc",
  "id" : 628649410122133505,
  "created_at" : "2015-08-04 19:31:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 6, 12 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/eHvUuk4N9m",
      "expanded_url" : "http:\/\/go.wh.gov\/DemoDay",
      "display_url" : "go.wh.gov\/DemoDay"
    }, {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/agJZFX13bM",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/4bd1908b-1d39-41fc-a290-fd2357520704",
      "display_url" : "amp.twimg.com\/v\/4bd1908b-1d3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628642831041609729",
  "text" : "Watch @USCTO Megan Smith introduce the first-ever #WHDemoDay \u2192 http:\/\/t.co\/eHvUuk4N9m\nhttps:\/\/t.co\/agJZFX13bM",
  "id" : 628642831041609729,
  "created_at" : "2015-08-04 19:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/repjohnlewis\/status\/628637651659280385\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Rapc20D9fU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlenO0W8AEiZ1Z.jpg",
      "id_str" : "628637651080507393",
      "id" : 628637651080507393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlenO0W8AEiZ1Z.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Rapc20D9fU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628638882310004736",
  "text" : "RT @repjohnlewis: Happy Birthday, Mr. President. Keep the faith. @POTUS http:\/\/t.co\/Rapc20D9fU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 47, 53 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/repjohnlewis\/status\/628637651659280385\/photo\/1",
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/Rapc20D9fU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlenO0W8AEiZ1Z.jpg",
        "id_str" : "628637651080507393",
        "id" : 628637651080507393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlenO0W8AEiZ1Z.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Rapc20D9fU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628637651659280385",
    "text" : "Happy Birthday, Mr. President. Keep the faith. @POTUS http:\/\/t.co\/Rapc20D9fU",
    "id" : 628637651659280385,
    "created_at" : "2015-08-04 18:44:30 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 628638882310004736,
  "created_at" : "2015-08-04 18:49:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/628634766078832640\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Xz17UVnhoV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlb9HQWgAAGZsV.jpg",
      "id_str" : "628634728472674304",
      "id" : 628634728472674304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlb9HQWgAAGZsV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Xz17UVnhoV"
    } ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/eHvUujNchO",
      "expanded_url" : "http:\/\/go.wh.gov\/DemoDay",
      "display_url" : "go.wh.gov\/DemoDay"
    } ]
  },
  "geo" : { },
  "id_str" : "628634766078832640",
  "text" : "RT if you agree: Every American should be able to pursue their bold ideas \u2192 http:\/\/t.co\/eHvUujNchO #WHDemoDay http:\/\/t.co\/Xz17UVnhoV",
  "id" : 628634766078832640,
  "created_at" : "2015-08-04 18:33:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 73, 83 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 85, 97 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628628868035809280",
  "text" : "RT @Medium: Read the full text of the historic #IranDeal with notes from @JohnKerry, @ErnestMoniz, and Secretary Jack Lew. https:\/\/t.co\/HeS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 61, 71 ],
        "id_str" : "15007149",
        "id" : 15007149
      }, {
        "name" : "Ernest Moniz",
        "screen_name" : "ErnestMoniz",
        "indices" : [ 73, 85 ],
        "id_str" : "1393155566",
        "id" : 1393155566
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/HeSEjqCP4y",
        "expanded_url" : "https:\/\/medium.com\/the-iran-deal\/introduction-fcb13560dfb9?source=tw-504c7870fdb6-1438707968635",
        "display_url" : "medium.com\/the-iran-deal\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628627461580812289",
    "text" : "Read the full text of the historic #IranDeal with notes from @JohnKerry, @ErnestMoniz, and Secretary Jack Lew. https:\/\/t.co\/HeSEjqCP4y",
    "id" : 628627461580812289,
    "created_at" : "2015-08-04 18:04:00 +0000",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752641363548581888\/fY6c3yTR_normal.jpg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 628628868035809280,
  "created_at" : "2015-08-04 18:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628616727438331904\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/5tidtNRXlK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlLkVyXAAAk3AC.jpg",
      "id_str" : "628616710690635776",
      "id" : 628616710690635776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlLkVyXAAAk3AC.jpg",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5tidtNRXlK"
    } ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/eHvUuk4N9m",
      "expanded_url" : "http:\/\/go.wh.gov\/DemoDay",
      "display_url" : "go.wh.gov\/DemoDay"
    } ]
  },
  "geo" : { },
  "id_str" : "628616727438331904",
  "text" : "Don't miss the first-ever #WHDemoDay! Watch dozens of entrepreneurs showcase their bold ideas: http:\/\/t.co\/eHvUuk4N9m http:\/\/t.co\/5tidtNRXlK",
  "id" : 628616727438331904,
  "created_at" : "2015-08-04 17:21:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628613815114924032",
  "text" : "RT @whitehouseostp: Learn more about new commitments, announced today at #WHDemoDay, to promote inclusive entrepreneurship at http:\/\/t.co\/y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHDemoDay",
        "indices" : [ 53, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/yzhhS8HZBV",
        "expanded_url" : "http:\/\/1.usa.gov\/1gH6FfD",
        "display_url" : "1.usa.gov\/1gH6FfD"
      } ]
    },
    "geo" : { },
    "id_str" : "628613619329044480",
    "text" : "Learn more about new commitments, announced today at #WHDemoDay, to promote inclusive entrepreneurship at http:\/\/t.co\/yzhhS8HZBV",
    "id" : 628613619329044480,
    "created_at" : "2015-08-04 17:09:00 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 628613815114924032,
  "created_at" : "2015-08-04 17:09:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "UniversityofMichigan",
      "screen_name" : "UMich",
      "indices" : [ 105, 111 ],
      "id_str" : "88836132",
      "id" : 88836132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "entrepreneurs",
      "indices" : [ 36, 50 ]
    }, {
      "text" : "WHDemoDay",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/GMP4YDCBgi",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/demo-day",
      "display_url" : "whitehouse.gov\/demo-day"
    } ]
  },
  "geo" : { },
  "id_str" : "628609811609948161",
  "text" : "RT @ENERGY: Meet some of the energy #entrepreneurs participating in #WHDemoDay! https:\/\/t.co\/GMP4YDCBgi (@umich photo) http:\/\/t.co\/kdUC7ZZ7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UniversityofMichigan",
        "screen_name" : "UMich",
        "indices" : [ 93, 99 ],
        "id_str" : "88836132",
        "id" : 88836132
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/628608871171497984\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/kdUC7ZZ70U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLlEcBEWIAAv3Uh.jpg",
        "id_str" : "628608871108583424",
        "id" : 628608871108583424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLlEcBEWIAAv3Uh.jpg",
        "sizes" : [ {
          "h" : 316,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/kdUC7ZZ70U"
      } ],
      "hashtags" : [ {
        "text" : "entrepreneurs",
        "indices" : [ 24, 38 ]
      }, {
        "text" : "WHDemoDay",
        "indices" : [ 56, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/GMP4YDCBgi",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/demo-day",
        "display_url" : "whitehouse.gov\/demo-day"
      } ]
    },
    "geo" : { },
    "id_str" : "628608871171497984",
    "text" : "Meet some of the energy #entrepreneurs participating in #WHDemoDay! https:\/\/t.co\/GMP4YDCBgi (@umich photo) http:\/\/t.co\/kdUC7ZZ70U",
    "id" : 628608871171497984,
    "created_at" : "2015-08-04 16:50:08 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 628609811609948161,
  "created_at" : "2015-08-04 16:53:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/C5ttjXQzxo",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDealText",
      "display_url" : "go.wh.gov\/IranDealText"
    } ]
  },
  "geo" : { },
  "id_str" : "628605428339994624",
  "text" : "RT @ErnestMoniz: Read the full text of the #IranDeal to see precisely how it blocks Iran from a nuclear bomb: http:\/\/t.co\/C5ttjXQzxo http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/628598692967260160\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/5RoPnKLTw3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLk7LkQWIAI2nO8.jpg",
        "id_str" : "628598692891729922",
        "id" : 628598692891729922,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLk7LkQWIAI2nO8.jpg",
        "sizes" : [ {
          "h" : 711,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 711,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5RoPnKLTw3"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 26, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/C5ttjXQzxo",
        "expanded_url" : "http:\/\/go.wh.gov\/IranDealText",
        "display_url" : "go.wh.gov\/IranDealText"
      } ]
    },
    "geo" : { },
    "id_str" : "628598692967260160",
    "text" : "Read the full text of the #IranDeal to see precisely how it blocks Iran from a nuclear bomb: http:\/\/t.co\/C5ttjXQzxo http:\/\/t.co\/5RoPnKLTw3",
    "id" : 628598692967260160,
    "created_at" : "2015-08-04 16:09:41 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 628605428339994624,
  "created_at" : "2015-08-04 16:36:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/G7dUrA6xrM",
      "expanded_url" : "http:\/\/go.wh.gov\/IranDealText",
      "display_url" : "go.wh.gov\/IranDealText"
    } ]
  },
  "geo" : { },
  "id_str" : "628597756555337728",
  "text" : "RT @TheIranDeal: Read the text of the #IranDeal with annotated comments from the people who negotiated it: http:\/\/t.co\/G7dUrA6xrM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 21, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/G7dUrA6xrM",
        "expanded_url" : "http:\/\/go.wh.gov\/IranDealText",
        "display_url" : "go.wh.gov\/IranDealText"
      } ]
    },
    "geo" : { },
    "id_str" : "628597152206483456",
    "text" : "Read the text of the #IranDeal with annotated comments from the people who negotiated it: http:\/\/t.co\/G7dUrA6xrM",
    "id" : 628597152206483456,
    "created_at" : "2015-08-04 16:03:34 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 628597756555337728,
  "created_at" : "2015-08-04 16:05:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628571715581444096\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/PT9x7HKyer",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLkinXFWEAA7OJB.jpg",
      "id_str" : "628571682601570304",
      "id" : 628571682601570304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLkinXFWEAA7OJB.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PT9x7HKyer"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 18, 33 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/knl0MO6eD0",
      "expanded_url" : "http:\/\/go.wh.gov\/CleanPowerPlan",
      "display_url" : "go.wh.gov\/CleanPowerPlan"
    } ]
  },
  "geo" : { },
  "id_str" : "628571715581444096",
  "text" : "President Obama's #CleanPowerPlan will save Americans billions of dollars \u2192 http:\/\/t.co\/knl0MO6eD0 #ActOnClimate http:\/\/t.co\/PT9x7HKyer",
  "id" : 628571715581444096,
  "created_at" : "2015-08-04 14:22:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 76, 91 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/khMQeQwmq7",
      "expanded_url" : "http:\/\/snpy.tv\/1IUrEHZ",
      "display_url" : "snpy.tv\/1IUrEHZ"
    } ]
  },
  "geo" : { },
  "id_str" : "628365970873163776",
  "text" : "\"We only get one home.\nWe only get one planet.\nThere is no plan B.\"\n\u2014@POTUS\n#CleanPowerPlan #ActOnClimate http:\/\/t.co\/khMQeQwmq7",
  "id" : 628365970873163776,
  "created_at" : "2015-08-04 00:44:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StandWithPP",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628334861221240833",
  "text" : "RT @NancyPelosi: RT to show you #StandWithPP and support a woman\u2019s right to affordable health care!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StandWithPP",
        "indices" : [ 15, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628323260522995712",
    "text" : "RT to show you #StandWithPP and support a woman\u2019s right to affordable health care!",
    "id" : 628323260522995712,
    "created_at" : "2015-08-03 21:55:13 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 628334861221240833,
  "created_at" : "2015-08-03 22:41:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/0mjv24on1Z",
      "expanded_url" : "http:\/\/snpy.tv\/1M7if0u",
      "display_url" : "snpy.tv\/1M7if0u"
    } ]
  },
  "geo" : { },
  "id_str" : "628331387133816832",
  "text" : "\"Suddenly I had this weird feeling, like I couldn't breathe\" \u2014@POTUS on running in L.A. in 1979 #CleanPowerPlan http:\/\/t.co\/0mjv24on1Z",
  "id" : 628331387133816832,
  "created_at" : "2015-08-03 22:27:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628316860308660225",
  "text" : "RT @POTUS: I refuse to condemn our kids to a planet that's beyond fixing. Let's meet this challenge and #ActOnClimate together.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 93, 106 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628285077970153472",
    "geo" : { },
    "id_str" : "628286472781754368",
    "in_reply_to_user_id" : 1536791610,
    "text" : "I refuse to condemn our kids to a planet that's beyond fixing. Let's meet this challenge and #ActOnClimate together.",
    "id" : 628286472781754368,
    "in_reply_to_status_id" : 628285077970153472,
    "created_at" : "2015-08-03 19:29:02 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 628316860308660225,
  "created_at" : "2015-08-03 21:29:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 41, 56 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/frq5ooqcUY",
      "expanded_url" : "http:\/\/snpy.tv\/1If9qNO",
      "display_url" : "snpy.tv\/1If9qNO"
    } ]
  },
  "geo" : { },
  "id_str" : "628313502055329792",
  "text" : "Watch @POTUS explain the benefits of the #CleanPowerPlan\u2014the biggest step we've ever taken to #ActOnClimate. http:\/\/t.co\/frq5ooqcUY",
  "id" : 628313502055329792,
  "created_at" : "2015-08-03 21:16:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FQ3msViYTm",
      "expanded_url" : "http:\/\/snpy.tv\/1M7fRXj",
      "display_url" : "snpy.tv\/1M7fRXj"
    } ]
  },
  "geo" : { },
  "id_str" : "628297951895494656",
  "text" : "RT if you agree: For the sake of our kids and the future of our planet, it's time to #ActOnClimate. #CleanPowerPlan http:\/\/t.co\/FQ3msViYTm",
  "id" : 628297951895494656,
  "created_at" : "2015-08-03 20:14:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Patrick Leahy",
      "screen_name" : "SenatorLeahy",
      "indices" : [ 3, 16 ],
      "id_str" : "242836537",
      "id" : 242836537
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateChange",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628293691950649344",
  "text" : "RT @SenatorLeahy: As @POTUS said, there IS such a thing as waiting too long to act on #ClimateChange. The time to act is NOW.  #CleanPowerP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 3, 9 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ClimateChange",
        "indices" : [ 68, 82 ]
      }, {
        "text" : "CleanPowerPlan",
        "indices" : [ 109, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628293534974504960",
    "text" : "As @POTUS said, there IS such a thing as waiting too long to act on #ClimateChange. The time to act is NOW.  #CleanPowerPlan",
    "id" : 628293534974504960,
    "created_at" : "2015-08-03 19:57:06 +0000",
    "user" : {
      "name" : "Sen. Patrick Leahy",
      "screen_name" : "SenatorLeahy",
      "protected" : false,
      "id_str" : "242836537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793093163401506816\/kLHLbN0V_normal.jpg",
      "id" : 242836537,
      "verified" : true
    }
  },
  "id" : 628293691950649344,
  "created_at" : "2015-08-03 19:57:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateChange",
      "indices" : [ 63, 77 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628291210801729540",
  "text" : "RT @Surgeon_General: This is a huge leap in the battle against #ClimateChange It will benefit the health of all Americans. #CleanPowerPlan \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Surgeon_General\/status\/628268957812789248\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/FA4MovEEjW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgO29hWEAA1AIU.jpg",
        "id_str" : "628268485408329728",
        "id" : 628268485408329728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgO29hWEAA1AIU.jpg",
        "sizes" : [ {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FA4MovEEjW"
      } ],
      "hashtags" : [ {
        "text" : "ClimateChange",
        "indices" : [ 42, 56 ]
      }, {
        "text" : "CleanPowerPlan",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628268957812789248",
    "text" : "This is a huge leap in the battle against #ClimateChange It will benefit the health of all Americans. #CleanPowerPlan http:\/\/t.co\/FA4MovEEjW",
    "id" : 628268957812789248,
    "created_at" : "2015-08-03 18:19:26 +0000",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 628291210801729540,
  "created_at" : "2015-08-03 19:47:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628285746936455168",
  "text" : "RT @POTUS: Despite what the critics will tell you, this plan will ultimately save the average American family nearly $85 a year on their en\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628283831104237569",
    "geo" : { },
    "id_str" : "628285077970153472",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Despite what the critics will tell you, this plan will ultimately save the average American family nearly $85 a year on their energy bills.",
    "id" : 628285077970153472,
    "in_reply_to_status_id" : 628283831104237569,
    "created_at" : "2015-08-03 19:23:30 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 628285746936455168,
  "created_at" : "2015-08-03 19:26:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628284602814218240",
  "text" : "RT @POTUS: Thanks to this plan, there will be 90,000 fewer asthma attacks among our kids and we'll avoid 3,600 premature deaths in 2030.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628283044772868097",
    "geo" : { },
    "id_str" : "628283831104237569",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Thanks to this plan, there will be 90,000 fewer asthma attacks among our kids and we'll avoid 3,600 premature deaths in 2030.",
    "id" : 628283831104237569,
    "in_reply_to_status_id" : 628283044772868097,
    "created_at" : "2015-08-03 19:18:32 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 628284602814218240,
  "created_at" : "2015-08-03 19:21:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628283352303411200",
  "text" : "RT @POTUS: It's time to change that. With the Clean Power Plan, by 2030, carbon pollution from power plants will be 32% lower than it was a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628282174869999616",
    "geo" : { },
    "id_str" : "628283044772868097",
    "in_reply_to_user_id" : 1536791610,
    "text" : "It's time to change that. With the Clean Power Plan, by 2030, carbon pollution from power plants will be 32% lower than it was a decade ago.",
    "id" : 628283044772868097,
    "in_reply_to_status_id" : 628282174869999616,
    "created_at" : "2015-08-03 19:15:25 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 628283352303411200,
  "created_at" : "2015-08-03 19:16:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628282603242713088",
  "text" : "RT @POTUS: Right now, power plants account for about one-third of America\u2019s carbon pollution. That\u2019s more than our cars, airplanes, and hom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628280902817304578",
    "geo" : { },
    "id_str" : "628282174869999616",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Right now, power plants account for about one-third of America\u2019s carbon pollution. That\u2019s more than our cars, airplanes, and homes combined.",
    "id" : 628282174869999616,
    "in_reply_to_status_id" : 628280902817304578,
    "created_at" : "2015-08-03 19:11:58 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 628282603242713088,
  "created_at" : "2015-08-03 19:13:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628281944397217792",
  "text" : "RT @POTUS: Levels of carbon dioxide in our atmosphere are higher than they\u2019ve been in 800,000 years. 2014 was the planet\u2019s warmest year on \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "628280710017720321",
    "geo" : { },
    "id_str" : "628280902817304578",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Levels of carbon dioxide in our atmosphere are higher than they\u2019ve been in 800,000 years. 2014 was the planet\u2019s warmest year on record.",
    "id" : 628280902817304578,
    "in_reply_to_status_id" : 628280710017720321,
    "created_at" : "2015-08-03 19:06:54 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 628281944397217792,
  "created_at" : "2015-08-03 19:11:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628281748279926784",
  "text" : "RT @POTUS: Today, we're announcing America's Clean Power Plan\u2014the most important step we've ever taken to combat climate change. Here are t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628280710017720321",
    "text" : "Today, we're announcing America's Clean Power Plan\u2014the most important step we've ever taken to combat climate change. Here are the facts:",
    "id" : 628280710017720321,
    "created_at" : "2015-08-03 19:06:08 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 628281748279926784,
  "created_at" : "2015-08-03 19:10:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 3, 15 ],
      "id_str" : "133880286",
      "id" : 133880286
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AvqKkepbEU",
      "expanded_url" : "http:\/\/go.wh.gov\/CleanPowerPlan",
      "display_url" : "go.wh.gov\/CleanPowerPlan"
    } ]
  },
  "geo" : { },
  "id_str" : "628280344870039552",
  "text" : "RT @LeoDiCaprio: \"Join us.\nWe can do this.\nIt\u2019s time for America,\nand the world,\nto #ActOnClimate change.\"\n\u2014@POTUS: http:\/\/t.co\/AvqKkepbEU \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 91, 97 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 67, 80 ]
      }, {
        "text" : "CleanPowerPlan",
        "indices" : [ 122, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/AvqKkepbEU",
        "expanded_url" : "http:\/\/go.wh.gov\/CleanPowerPlan",
        "display_url" : "go.wh.gov\/CleanPowerPlan"
      } ]
    },
    "geo" : { },
    "id_str" : "628272639715450880",
    "text" : "\"Join us.\nWe can do this.\nIt\u2019s time for America,\nand the world,\nto #ActOnClimate change.\"\n\u2014@POTUS: http:\/\/t.co\/AvqKkepbEU #CleanPowerPlan",
    "id" : 628272639715450880,
    "created_at" : "2015-08-03 18:34:04 +0000",
    "user" : {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "protected" : false,
      "id_str" : "133880286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694662257586892802\/mdc5ELjj_normal.jpg",
      "id" : 133880286,
      "verified" : true
    }
  },
  "id" : 628280344870039552,
  "created_at" : "2015-08-03 19:04:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patagonia",
      "screen_name" : "patagonia",
      "indices" : [ 3, 13 ],
      "id_str" : "16191793",
      "id" : 16191793
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/aE62XHZKeL",
      "expanded_url" : "http:\/\/pat.ag\/dyy6",
      "display_url" : "pat.ag\/dyy6"
    } ]
  },
  "geo" : { },
  "id_str" : "628278877446664192",
  "text" : "RT @patagonia: We applaud @POTUS\u2019 goals to maximize renewable energy and reduce emissions in the new #CleanPowerPlan: http:\/\/t.co\/aE62XHZKeL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 86, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/aE62XHZKeL",
        "expanded_url" : "http:\/\/pat.ag\/dyy6",
        "display_url" : "pat.ag\/dyy6"
      } ]
    },
    "geo" : { },
    "id_str" : "628255502905024512",
    "text" : "We applaud @POTUS\u2019 goals to maximize renewable energy and reduce emissions in the new #CleanPowerPlan: http:\/\/t.co\/aE62XHZKeL",
    "id" : 628255502905024512,
    "created_at" : "2015-08-03 17:25:58 +0000",
    "user" : {
      "name" : "Patagonia",
      "screen_name" : "patagonia",
      "protected" : false,
      "id_str" : "16191793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725446734726336513\/AwZNaoVG_normal.jpg",
      "id" : 16191793,
      "verified" : true
    }
  },
  "id" : 628278877446664192,
  "created_at" : "2015-08-03 18:58:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628275045480202240\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/FNxerX9Nkj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgUzGTUsAEa_MW.jpg",
      "id_str" : "628275016115728385",
      "id" : 628275016115728385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgUzGTUsAEa_MW.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/FNxerX9Nkj"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628275045480202240",
  "text" : "\"This is our moment to leave something better for our kids...let\u2019s make the most of it.\" \u2014@POTUS #CleanPowerPlan http:\/\/t.co\/FNxerX9Nkj",
  "id" : 628275045480202240,
  "created_at" : "2015-08-03 18:43:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628274378275463168\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/YVIrDYe7rO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgUM1rWIAAAT90.jpg",
      "id_str" : "628274358818054144",
      "id" : 628274358818054144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgUM1rWIAAAT90.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/YVIrDYe7rO"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 76, 89 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628274378275463168",
  "text" : "\"We only get one home.\nWe only get one planet.\nThere is no plan B.\"\n\u2014@POTUS\n#ActOnClimate #CleanPowerPlan http:\/\/t.co\/YVIrDYe7rO",
  "id" : 628274378275463168,
  "created_at" : "2015-08-03 18:40:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628273661405982720",
  "text" : "\"When the world faces its toughest challenges, America leads the way forward\u2014that\u2019s what this plan is all about.\" \u2014@POTUS #CleanPowerPlan",
  "id" : 628273661405982720,
  "created_at" : "2015-08-03 18:38:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628272333497745408",
  "text" : "\"If you care so much about low-income and minority communities, then start protecting the air they breathe\" \u2014@POTUS to the GOP in Congress",
  "id" : 628272333497745408,
  "created_at" : "2015-08-03 18:32:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 108, 121 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628271979360092161",
  "text" : "\"Today, an African American child is more than twice than as likely to be hospitalized from asthma\" \u2014@POTUS #ActOnClimate #CleanPowerPlan",
  "id" : 628271979360092161,
  "created_at" : "2015-08-03 18:31:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628271597200252932\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/5m2rZnYHms",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgRqomUwAAgFyb.jpg",
      "id_str" : "628271572168523776",
      "id" : 628271572168523776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgRqomUwAAgFyb.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5m2rZnYHms"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628271597200252932",
  "text" : "\"This plan will ultimately save the average American nearly $85 a year on their energy bills\" \u2014@POTUS #CleanPowerPlan http:\/\/t.co\/5m2rZnYHms",
  "id" : 628271597200252932,
  "created_at" : "2015-08-03 18:29:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628270988342525952\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/FxVjvmFczr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgRGrKWEAAH6aw.jpg",
      "id_str" : "628270954381185024",
      "id" : 628270954381185024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgRGrKWEAAH6aw.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FxVjvmFczr"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628270988342525952",
  "text" : "\"Thanks to this plan, there will be 90,000 fewer asthma attacks among our children each year\" \u2014@POTUS #CleanPowerPlan http:\/\/t.co\/FxVjvmFczr",
  "id" : 628270988342525952,
  "created_at" : "2015-08-03 18:27:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628270781890437120\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/joS9jtvRBP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgQ6tUUMAA9Hf9.jpg",
      "id_str" : "628270748801445888",
      "id" : 628270748801445888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgQ6tUUMAA9Hf9.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/joS9jtvRBP"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628270781890437120",
  "text" : "\"By 2030, we will reduce premature deaths from power plant emissions by nearly 90%\" \u2014@POTUS #CleanPowerPlan http:\/\/t.co\/joS9jtvRBP",
  "id" : 628270781890437120,
  "created_at" : "2015-08-03 18:26:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/GBSJ8hDkgd",
      "expanded_url" : "http:\/\/snpy.tv\/1STbXjG",
      "display_url" : "snpy.tv\/1STbXjG"
    } ]
  },
  "geo" : { },
  "id_str" : "628269757834391557",
  "text" : "\"Today, we\u2019re here to announce...the single most important step America has ever taken\" to #ActOnClimate \u2014@POTUS http:\/\/t.co\/GBSJ8hDkgd",
  "id" : 628269757834391557,
  "created_at" : "2015-08-03 18:22:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628269304845336581\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Ba9pWNDFVf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgPjaeUAAAoLJ8.jpg",
      "id_str" : "628269249094483968",
      "id" : 628269249094483968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgPjaeUAAAoLJ8.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ba9pWNDFVf"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628269304845336581",
  "text" : "\"We\u2019re now generating 3 times as much wind and 20 times as much solar as we did in 2008.\" \u2014@POTUS #CleanPowerPlan http:\/\/t.co\/Ba9pWNDFVf",
  "id" : 628269304845336581,
  "created_at" : "2015-08-03 18:20:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 98, 111 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628269123823341569",
  "text" : "\"There is such a thing as being too late when it comes to climate change.\u201D \u2014@POTUS on the need to #ActOnClimate now #CleanPowerPlan",
  "id" : 628269123823341569,
  "created_at" : "2015-08-03 18:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628268853328539648",
  "text" : "\"We\u2019re the first generation to feel the impact of climate change &amp; the last generation that can do something about it\" \u2014@POTUS #ActOnClimate",
  "id" : 628268853328539648,
  "created_at" : "2015-08-03 18:19:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628268757337702400\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/1GqIDPXWzd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgPFgdUMAEWfHJ.jpg",
      "id_str" : "628268735304839169",
      "id" : 628268735304839169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgPFgdUMAEWfHJ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1GqIDPXWzd"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 86, 101 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628268757337702400",
  "text" : "\"Over the past three decades, nationwide asthma rates have more than doubled\" \u2014@POTUS #CleanPowerPlan #ActOnClimate http:\/\/t.co\/1GqIDPXWzd",
  "id" : 628268757337702400,
  "created_at" : "2015-08-03 18:18:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/kbmH3IayE2",
      "expanded_url" : "http:\/\/go.wh.gov\/CleanPowerPlan",
      "display_url" : "go.wh.gov\/CleanPowerPlan"
    } ]
  },
  "geo" : { },
  "id_str" : "628268483827101696",
  "text" : "RT @WHLive: \"The Pentagon says that climate change poses immediate risks to our national security.\" \u2014@POTUS: http:\/\/t.co\/kbmH3IayE2 #CleanP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 89, 95 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 120, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/kbmH3IayE2",
        "expanded_url" : "http:\/\/go.wh.gov\/CleanPowerPlan",
        "display_url" : "go.wh.gov\/CleanPowerPlan"
      } ]
    },
    "geo" : { },
    "id_str" : "628268451535187968",
    "text" : "\"The Pentagon says that climate change poses immediate risks to our national security.\" \u2014@POTUS: http:\/\/t.co\/kbmH3IayE2 #CleanPowerPlan",
    "id" : 628268451535187968,
    "created_at" : "2015-08-03 18:17:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 628268483827101696,
  "created_at" : "2015-08-03 18:17:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628268234974883840",
  "text" : "\"Levels of carbon dioxide, which heats up our atmosphere, are higher than they\u2019ve been in 800,000 years.\" \u2014@POTUS #CleanPowerPlan",
  "id" : 628268234974883840,
  "created_at" : "2015-08-03 18:16:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628268146739281920\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/u1UpqCc0HI",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CLgOaQOVAAACRns.png",
      "id_str" : "628267992212635648",
      "id" : 628267992212635648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CLgOaQOVAAACRns.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/u1UpqCc0HI"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 95, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628268146739281920",
  "text" : "\"No challenge poses a greater threat to...future generations than a changing climate.\" \u2014@POTUS #CleanPowerPlan http:\/\/t.co\/u1UpqCc0HI",
  "id" : 628268146739281920,
  "created_at" : "2015-08-03 18:16:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628267782308761600\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/D7Ubmhb27d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgOMNhUYAAACXD.jpg",
      "id_str" : "628267750968811520",
      "id" : 628267750968811520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgOMNhUYAAACXD.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      } ],
      "display_url" : "pic.twitter.com\/D7Ubmhb27d"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 61, 74 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/knl0MO6eD0",
      "expanded_url" : "http:\/\/go.wh.gov\/CleanPowerPlan",
      "display_url" : "go.wh.gov\/CleanPowerPlan"
    } ]
  },
  "geo" : { },
  "id_str" : "628267782308761600",
  "text" : "Watch live: @POTUS speaks on the biggest step we've taken to #ActOnClimate \u2192 http:\/\/t.co\/knl0MO6eD0 #CleanPowerPlan http:\/\/t.co\/D7Ubmhb27d",
  "id" : 628267782308761600,
  "created_at" : "2015-08-03 18:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 39, 54 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/R4s8b0cur3",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "628266933520105472",
  "text" : "RT @EPA: TUNE IN NOW. @POTUS announces #CleanPowerPlan: http:\/\/t.co\/R4s8b0cur3. #ActOnClimate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 30, 45 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 71, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/R4s8b0cur3",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "628266878893469697",
    "text" : "TUNE IN NOW. @POTUS announces #CleanPowerPlan: http:\/\/t.co\/R4s8b0cur3. #ActOnClimate",
    "id" : 628266878893469697,
    "created_at" : "2015-08-03 18:11:11 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 628266933520105472,
  "created_at" : "2015-08-03 18:11:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/628259477737897985\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/rBtt3XCDTJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLgGo-5WgAADctE.jpg",
      "id_str" : "628259449166266368",
      "id" : 628259449166266368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLgGo-5WgAADctE.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      } ],
      "display_url" : "pic.twitter.com\/rBtt3XCDTJ"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 45, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/knl0MO6eD0",
      "expanded_url" : "http:\/\/go.wh.gov\/CleanPowerPlan",
      "display_url" : "go.wh.gov\/CleanPowerPlan"
    } ]
  },
  "geo" : { },
  "id_str" : "628259477737897985",
  "text" : "Watch @POTUS speak at 2:15pm ET on America's #CleanPowerPlan \u2192 http:\/\/t.co\/knl0MO6eD0 http:\/\/t.co\/rBtt3XCDTJ",
  "id" : 628259477737897985,
  "created_at" : "2015-08-03 17:41:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 38, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628250860066226176",
  "text" : "RT @SecretaryCastro: .@POTUS's latest #CleanPowerPlan will protect the health of all Americans and boost our economy \u2192 https:\/\/t.co\/lMDdg4L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 17, 32 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/lMDdg4LTj0",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/climate-change",
        "display_url" : "whitehouse.gov\/climate-change"
      } ]
    },
    "geo" : { },
    "id_str" : "628244730275610624",
    "text" : ".@POTUS's latest #CleanPowerPlan will protect the health of all Americans and boost our economy \u2192 https:\/\/t.co\/lMDdg4LTj0 #ActOnClimate",
    "id" : 628244730275610624,
    "created_at" : "2015-08-03 16:43:10 +0000",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 628250860066226176,
  "created_at" : "2015-08-03 17:07:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628241481254354944\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2nzePBxUGp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLf0PWiUYAAFRcq.jpg",
      "id_str" : "628239217626210304",
      "id" : 628239217626210304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLf0PWiUYAAFRcq.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2nzePBxUGp"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628241481254354944",
  "text" : "FACT: The average American family will save nearly $85 on their energy bills in 2030 thanks to the #CleanPowerPlan. http:\/\/t.co\/2nzePBxUGp",
  "id" : 628241481254354944,
  "created_at" : "2015-08-03 16:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628235566296006656\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/iP1Woc8aoN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLfw3I4WUAAXEZ9.jpg",
      "id_str" : "628235503108771840",
      "id" : 628235503108771840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLfw3I4WUAAXEZ9.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iP1Woc8aoN"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 13, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628235566296006656",
  "text" : "In 2030, the #CleanPowerPlan will PREVENT:\nUp to 3,600 premature deaths.\n90,000 asthma attacks among kids. http:\/\/t.co\/iP1Woc8aoN",
  "id" : 628235566296006656,
  "created_at" : "2015-08-03 16:06:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 67, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628231613592109057",
  "text" : "RT @VP: We owe it to our kids to act on climate change. Here's our #CleanPowerPlan. It's the biggest step we've ever taken. http:\/\/t.co\/D9b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 59, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/D9bw2ZSlRU",
        "expanded_url" : "http:\/\/snpy.tv\/1STbXjG",
        "display_url" : "snpy.tv\/1STbXjG"
      } ]
    },
    "geo" : { },
    "id_str" : "628230829366341633",
    "text" : "We owe it to our kids to act on climate change. Here's our #CleanPowerPlan. It's the biggest step we've ever taken. http:\/\/t.co\/D9bw2ZSlRU",
    "id" : 628230829366341633,
    "created_at" : "2015-08-03 15:47:56 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 628231613592109057,
  "created_at" : "2015-08-03 15:51:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 80, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/x0c3PatYdo",
      "expanded_url" : "https:\/\/medium.com\/@GinaEPA\/6-things-every-american-should-know-about-the-clean-power-plan-e06b34fc2a57",
      "display_url" : "medium.com\/@GinaEPA\/6-thi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "628229970775543808",
  "text" : "RT @GinaEPA: Here are the 6 most important things you should know about today's #CleanPowerPlan: https:\/\/t.co\/x0c3PatYdo. It's time to #Act\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 67, 82 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/x0c3PatYdo",
        "expanded_url" : "https:\/\/medium.com\/@GinaEPA\/6-things-every-american-should-know-about-the-clean-power-plan-e06b34fc2a57",
        "display_url" : "medium.com\/@GinaEPA\/6-thi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628221984657272832",
    "text" : "Here are the 6 most important things you should know about today's #CleanPowerPlan: https:\/\/t.co\/x0c3PatYdo. It's time to #ActOnClimate!",
    "id" : 628221984657272832,
    "created_at" : "2015-08-03 15:12:47 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 628229970775543808,
  "created_at" : "2015-08-03 15:44:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628228004108468224",
  "text" : "RT @SenatorReid: President Obama's #CleanPowerPlan is the strongest action ever taken by our nation to curb the effects of climate change.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 18, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "628226399363538944",
    "text" : "President Obama's #CleanPowerPlan is the strongest action ever taken by our nation to curb the effects of climate change.",
    "id" : 628226399363538944,
    "created_at" : "2015-08-03 15:30:20 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 628228004108468224,
  "created_at" : "2015-08-03 15:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2015",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628226241867313152",
  "text" : "\"Our greatest challenges...are bigger than any one nation or even one continent.\" \u2014@POTUS to young African leaders #YALI2015",
  "id" : 628226241867313152,
  "created_at" : "2015-08-03 15:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628223636973879296",
  "text" : "\"Even as Africa continues to confront many challenges, Africa is on the move. It\u2019s one of the fastest-growing regions in the world.\" \u2014@POTUS",
  "id" : 628223636973879296,
  "created_at" : "2015-08-03 15:19:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2015",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/OtAdUlLK7n",
      "expanded_url" : "http:\/\/go.wh.gov\/N5hPkP",
      "display_url" : "go.wh.gov\/N5hPkP"
    } ]
  },
  "geo" : { },
  "id_str" : "628223385231724544",
  "text" : "RT @WHLive: Happening now: @POTUS talks with the next generation of young leaders from Sub-Saharan Africa: http:\/\/t.co\/OtAdUlLK7n #YALI2015",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YALI2015",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/OtAdUlLK7n",
        "expanded_url" : "http:\/\/go.wh.gov\/N5hPkP",
        "display_url" : "go.wh.gov\/N5hPkP"
      } ]
    },
    "geo" : { },
    "id_str" : "628222802626277376",
    "text" : "Happening now: @POTUS talks with the next generation of young leaders from Sub-Saharan Africa: http:\/\/t.co\/OtAdUlLK7n #YALI2015",
    "id" : 628222802626277376,
    "created_at" : "2015-08-03 15:16:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 628223385231724544,
  "created_at" : "2015-08-03 15:18:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/628218596104101888\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/aOOqnSbOA0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLfheWAUYAQPBLx.jpg",
      "id_str" : "628218584460713988",
      "id" : 628218584460713988,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLfheWAUYAQPBLx.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      } ],
      "display_url" : "pic.twitter.com\/aOOqnSbOA0"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 18, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/knl0MOnPuy",
      "expanded_url" : "http:\/\/go.wh.gov\/CleanPowerPlan",
      "display_url" : "go.wh.gov\/CleanPowerPlan"
    } ]
  },
  "geo" : { },
  "id_str" : "628218596104101888",
  "text" : "President Obama's #CleanPowerPlan will \u2193 carbon pollution from power plants by 32% by 2030 \u2192 http:\/\/t.co\/knl0MOnPuy http:\/\/t.co\/aOOqnSbOA0",
  "id" : 628218596104101888,
  "created_at" : "2015-08-03 14:59:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 56, 69 ]
    }, {
      "text" : "BlueMarble",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628217993080631296",
  "text" : "RT @Deese44: Today @POTUS takes his biggest step yet to #ActOnClimate. Show your support with this beautiful #BlueMarble avatar: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 43, 56 ]
      }, {
        "text" : "BlueMarble",
        "indices" : [ 96, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/85BogSSbDb",
        "expanded_url" : "https:\/\/www.facebook.com\/WhiteHouse\/photos\/a.437372744237.233573.63811549237\/10153666938609238\/",
        "display_url" : "facebook.com\/WhiteHouse\/pho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "628217267138920448",
    "text" : "Today @POTUS takes his biggest step yet to #ActOnClimate. Show your support with this beautiful #BlueMarble avatar: https:\/\/t.co\/85BogSSbDb",
    "id" : 628217267138920448,
    "created_at" : "2015-08-03 14:54:02 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 628217993080631296,
  "created_at" : "2015-08-03 14:56:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rohan Patel",
      "screen_name" : "Rohan44",
      "indices" : [ 3, 11 ],
      "id_str" : "3304470901",
      "id" : 3304470901
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628214785868451840",
  "text" : "RT @Rohan44: Today! @POTUS announces \"biggest, most important step we've ever taken to combat climate change\" #ActOnClimate http:\/\/t.co\/1Gq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 97, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/1GqRS9CxzA",
        "expanded_url" : "http:\/\/1.usa.gov\/1SAXjmi",
        "display_url" : "1.usa.gov\/1SAXjmi"
      } ]
    },
    "geo" : { },
    "id_str" : "628181507547402240",
    "text" : "Today! @POTUS announces \"biggest, most important step we've ever taken to combat climate change\" #ActOnClimate http:\/\/t.co\/1GqRS9CxzA",
    "id" : 628181507547402240,
    "created_at" : "2015-08-03 12:31:57 +0000",
    "user" : {
      "name" : "Rohan Patel",
      "screen_name" : "Rohan44",
      "protected" : false,
      "id_str" : "3304470901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633812379021803520\/w56GrR6I_normal.jpg",
      "id" : 3304470901,
      "verified" : true
    }
  },
  "id" : 628214785868451840,
  "created_at" : "2015-08-03 14:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 31, 46 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/GBSJ8hlIRD",
      "expanded_url" : "http:\/\/snpy.tv\/1STbXjG",
      "display_url" : "snpy.tv\/1STbXjG"
    } ]
  },
  "geo" : { },
  "id_str" : "628210948839321600",
  "text" : "Today, @POTUS is releasing his #CleanPowerPlan\u2014the biggest step we've ever taken to #ActOnClimate. http:\/\/t.co\/GBSJ8hlIRD",
  "id" : 628210948839321600,
  "created_at" : "2015-08-03 14:28:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendell Pierce",
      "screen_name" : "WendellPierce",
      "indices" : [ 3, 17 ],
      "id_str" : "247114704",
      "id" : 247114704
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628041494956412928",
  "text" : "RT @WendellPierce: Tomorrow President Obama @POTUS will announce the final version of the Clean Power Plan- the biggest step to combat clim\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 25, 31 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627916302179561472",
    "text" : "Tomorrow President Obama @POTUS will announce the final version of the Clean Power Plan- the biggest step to combat climate change!",
    "id" : 627916302179561472,
    "created_at" : "2015-08-02 18:58:07 +0000",
    "user" : {
      "name" : "Wendell Pierce",
      "screen_name" : "WendellPierce",
      "protected" : false,
      "id_str" : "247114704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725460021518176256\/Kmqsq7YF_normal.jpg",
      "id" : 247114704,
      "verified" : true
    }
  },
  "id" : 628041494956412928,
  "created_at" : "2015-08-03 03:15:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bette Midler",
      "screen_name" : "BetteMidler",
      "indices" : [ 3, 15 ],
      "id_str" : "139823781",
      "id" : 139823781
    }, {
      "name" : "ob",
      "screen_name" : "obama",
      "indices" : [ 57, 63 ],
      "id_str" : "246601433",
      "id" : 246601433
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 124, 132 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "628024721418883073",
  "text" : "RT @BetteMidler: Most exciting thing to happen in YEARS! @Obama to Unveil Tougher Climate Plan With His Legacy in Mind, via @nytimes http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ob",
        "screen_name" : "obama",
        "indices" : [ 40, 46 ],
        "id_str" : "246601433",
        "id" : 246601433
      }, {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 107, 115 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/bHZjVzaswm",
        "expanded_url" : "http:\/\/www.nytimes.com\/2015\/08\/02\/us\/obama-to-unveil-tougher-climate-plan-with-his-legacy-in-mind.html?smprod=nytcore-iphone&smid=nytcore-iphone-share",
        "display_url" : "nytimes.com\/2015\/08\/02\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627927081431732224",
    "text" : "Most exciting thing to happen in YEARS! @Obama to Unveil Tougher Climate Plan With His Legacy in Mind, via @nytimes http:\/\/t.co\/bHZjVzaswm",
    "id" : 627927081431732224,
    "created_at" : "2015-08-02 19:40:57 +0000",
    "user" : {
      "name" : "Bette Midler",
      "screen_name" : "BetteMidler",
      "protected" : false,
      "id_str" : "139823781",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793394076787757056\/Fnx0wN6Q_normal.jpg",
      "id" : 139823781,
      "verified" : true
    }
  },
  "id" : 628024721418883073,
  "created_at" : "2015-08-03 02:08:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 67, 80 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/GBSJ8hDkgd",
      "expanded_url" : "http:\/\/snpy.tv\/1STbXjG",
      "display_url" : "snpy.tv\/1STbXjG"
    } ]
  },
  "geo" : { },
  "id_str" : "627956840266080256",
  "text" : "\"Join us.\nWe can do this.\nIt\u2019s time for America,\nand the world,\nto #ActOnClimate change.\"\n\u2014@POTUS #CleanPowerPlan http:\/\/t.co\/GBSJ8hDkgd",
  "id" : 627956840266080256,
  "created_at" : "2015-08-02 21:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piper Perabo",
      "screen_name" : "PiperPerabo",
      "indices" : [ 3, 15 ],
      "id_str" : "586749256",
      "id" : 586749256
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/mTurLjeqhd",
      "expanded_url" : "http:\/\/www.whosay.com\/l\/bkTaS90",
      "display_url" : "whosay.com\/l\/bkTaS90"
    } ]
  },
  "geo" : { },
  "id_str" : "627944787484782593",
  "text" : "RT @PiperPerabo: .@POTUS I'm proud of you! Let's do this! #ActOnClimate The biggest step we've ever taken http:\/\/t.co\/mTurLjeqhd http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PiperPerabo\/status\/627924340827406337\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/FNpQC5xCym",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLbV3GlW8AAITb1.jpg",
        "id_str" : "627924340701589504",
        "id" : 627924340701589504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLbV3GlW8AAITb1.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/FNpQC5xCym"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 41, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/mTurLjeqhd",
        "expanded_url" : "http:\/\/www.whosay.com\/l\/bkTaS90",
        "display_url" : "whosay.com\/l\/bkTaS90"
      } ]
    },
    "geo" : { },
    "id_str" : "627924340827406337",
    "text" : ".@POTUS I'm proud of you! Let's do this! #ActOnClimate The biggest step we've ever taken http:\/\/t.co\/mTurLjeqhd http:\/\/t.co\/FNpQC5xCym",
    "id" : 627924340827406337,
    "created_at" : "2015-08-02 19:30:03 +0000",
    "user" : {
      "name" : "Piper Perabo",
      "screen_name" : "PiperPerabo",
      "protected" : false,
      "id_str" : "586749256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793162857265426434\/2ct5DqIT_normal.jpg",
      "id" : 586749256,
      "verified" : true
    }
  },
  "id" : 627944787484782593,
  "created_at" : "2015-08-02 20:51:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627925504796966912",
  "text" : "RT @EPA: .@POTUS says #CleanPowerPlan is \"the biggest, most important step we've ever taken to combat climate change.\" WATCH: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 13, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/cX58LtKQvK",
        "expanded_url" : "https:\/\/www.facebook.com\/WhiteHouse\/videos\/vb.63811549237\/10153662873839238\/?type=2&theater",
        "display_url" : "facebook.com\/WhiteHouse\/vid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627838088312672256",
    "text" : ".@POTUS says #CleanPowerPlan is \"the biggest, most important step we've ever taken to combat climate change.\" WATCH: https:\/\/t.co\/cX58LtKQvK",
    "id" : 627838088312672256,
    "created_at" : "2015-08-02 13:47:19 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 627925504796966912,
  "created_at" : "2015-08-02 19:34:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 48, 63 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/GBSJ8hlIRD",
      "expanded_url" : "http:\/\/snpy.tv\/1STbXjG",
      "display_url" : "snpy.tv\/1STbXjG"
    } ]
  },
  "geo" : { },
  "id_str" : "627901863677968385",
  "text" : "RT the news: On Monday, @POTUS will release his #CleanPowerPlan\u2014the biggest step we've ever taken to #ActOnClimate. http:\/\/t.co\/GBSJ8hlIRD",
  "id" : 627901863677968385,
  "created_at" : "2015-08-02 18:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Rovin",
      "screen_name" : "MomRovin",
      "indices" : [ 3, 12 ],
      "id_str" : "413407657",
      "id" : 413407657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 86, 99 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bppt7rLHsY",
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/627870205432107008",
      "display_url" : "twitter.com\/whitehouse\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627896017552171008",
  "text" : "RT @MomRovin: Because I love my kids~ and their friends~ and my future grandchildren~ #ActOnClimate #CleanPowerPlan  https:\/\/t.co\/bppt7rLHsY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 72, 85 ]
      }, {
        "text" : "CleanPowerPlan",
        "indices" : [ 86, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/bppt7rLHsY",
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/627870205432107008",
        "display_url" : "twitter.com\/whitehouse\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627873219974815745",
    "text" : "Because I love my kids~ and their friends~ and my future grandchildren~ #ActOnClimate #CleanPowerPlan  https:\/\/t.co\/bppt7rLHsY",
    "id" : 627873219974815745,
    "created_at" : "2015-08-02 16:06:55 +0000",
    "user" : {
      "name" : "Amy Rovin",
      "screen_name" : "MomRovin",
      "protected" : false,
      "id_str" : "413407657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797079501779910660\/02FYaFmz_normal.jpg",
      "id" : 413407657,
      "verified" : false
    }
  },
  "id" : 627896017552171008,
  "created_at" : "2015-08-02 17:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627883794788319232",
  "text" : "RT @Deese44: A Memo to America\nFrom: @POTUS \nRE: Our planet\n\nWe're taking out biggest step yet to #ActOnClimate. Watch: https:\/\/t.co\/7KBPJk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 24, 30 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/7KBPJkVviP",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/48ecc1f6-1ec4-4065-b03d-4577adc8eece",
        "display_url" : "amp.twimg.com\/v\/48ecc1f6-1ec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627851607665815552",
    "text" : "A Memo to America\nFrom: @POTUS \nRE: Our planet\n\nWe're taking out biggest step yet to #ActOnClimate. Watch: https:\/\/t.co\/7KBPJkVviP",
    "id" : 627851607665815552,
    "created_at" : "2015-08-02 14:41:02 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 627883794788319232,
  "created_at" : "2015-08-02 16:48:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 73, 86 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 88, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/GBSJ8hlIRD",
      "expanded_url" : "http:\/\/snpy.tv\/1STbXjG",
      "display_url" : "snpy.tv\/1STbXjG"
    } ]
  },
  "geo" : { },
  "id_str" : "627870205432107008",
  "text" : "We can't condemn our kids to a planet that's beyond fixing.\nIt's time to #ActOnClimate. #CleanPowerPlan http:\/\/t.co\/GBSJ8hlIRD",
  "id" : 627870205432107008,
  "created_at" : "2015-08-02 15:54:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 45, 60 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/BU1PF0wjUK",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/48ecc1f6-1ec4-4065-b03d-4577adc8eece",
      "display_url" : "amp.twimg.com\/v\/48ecc1f6-1ec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627690347691274240",
  "text" : "BREAKING: On Monday, @POTUS will release his #CleanPowerPlan\u2014the biggest step we've ever taken to #ActOnClimate.\nhttps:\/\/t.co\/BU1PF0wjUK",
  "id" : 627690347691274240,
  "created_at" : "2015-08-02 04:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SHAQ",
      "screen_name" : "SHAQ",
      "indices" : [ 3, 8 ],
      "id_str" : "17461978",
      "id" : 17461978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/yjon4oxfYl",
      "expanded_url" : "https:\/\/instagram.com\/whitehouse\/",
      "display_url" : "instagram.com\/whitehouse\/"
    } ]
  },
  "geo" : { },
  "id_str" : "627593426322726912",
  "text" : "RT @SHAQ: Honored to be doing a White House Instagram takeover today! Follow along at https:\/\/t.co\/yjon4oxfYl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/yjon4oxfYl",
        "expanded_url" : "https:\/\/instagram.com\/whitehouse\/",
        "display_url" : "instagram.com\/whitehouse\/"
      } ]
    },
    "geo" : { },
    "id_str" : "627552505535184896",
    "text" : "Honored to be doing a White House Instagram takeover today! Follow along at https:\/\/t.co\/yjon4oxfYl",
    "id" : 627552505535184896,
    "created_at" : "2015-08-01 18:52:31 +0000",
    "user" : {
      "name" : "SHAQ",
      "screen_name" : "SHAQ",
      "protected" : false,
      "id_str" : "17461978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1673907275\/image_normal.jpg",
      "id" : 17461978,
      "verified" : true
    }
  },
  "id" : 627593426322726912,
  "created_at" : "2015-08-01 21:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 79, 92 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/b6ImMd77UI",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=rqu21-f7Qus",
      "display_url" : "youtube.com\/watch?v=rqu21-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627585493237149696",
  "text" : "RT @GinaEPA: We have to ensure a safe climate for generations to come. We must #ActOnClimate now. #CleanPowerPlan https:\/\/t.co\/b6ImMd77UI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 66, 79 ]
      }, {
        "text" : "CleanPowerPlan",
        "indices" : [ 85, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/b6ImMd77UI",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=rqu21-f7Qus",
        "display_url" : "youtube.com\/watch?v=rqu21-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627497498194640896",
    "text" : "We have to ensure a safe climate for generations to come. We must #ActOnClimate now. #CleanPowerPlan https:\/\/t.co\/b6ImMd77UI",
    "id" : 627497498194640896,
    "created_at" : "2015-08-01 15:13:56 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 627585493237149696,
  "created_at" : "2015-08-01 21:03:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/AT0nvUXkq4",
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/627560699347255297",
      "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627563296951017472",
  "text" : "RT @StationCDRKelly: I don't freak out about anything, Mr. President. Except getting a Twitter question from you. \n https:\/\/t.co\/AT0nvUXkq4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/AT0nvUXkq4",
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/627560699347255297",
        "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "627561435330015232",
    "text" : "I don't freak out about anything, Mr. President. Except getting a Twitter question from you. \n https:\/\/t.co\/AT0nvUXkq4",
    "id" : 627561435330015232,
    "created_at" : "2015-08-01 19:28:00 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 627563296951017472,
  "created_at" : "2015-08-01 19:35:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 15, 31 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627561800595316736",
  "text" : "RT @POTUS: Hey @StationCDRKelly, loving the photos. Do you ever look out the window and just freak out?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Kelly",
        "screen_name" : "StationCDRKelly",
        "indices" : [ 4, 20 ],
        "id_str" : "65647594",
        "id" : 65647594
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627560699347255297",
    "text" : "Hey @StationCDRKelly, loving the photos. Do you ever look out the window and just freak out?",
    "id" : 627560699347255297,
    "created_at" : "2015-08-01 19:25:04 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 627561800595316736,
  "created_at" : "2015-08-01 19:29:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInSpace",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627560257582202880",
  "text" : "RT @StationCDRKelly: Alrighty! Ready for your Qs. This should be fun. Be sure to include #YearInSpace. I don't want to miss a thing! TWEETC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YearInSpace",
        "indices" : [ 68, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "627554794392006656",
    "text" : "Alrighty! Ready for your Qs. This should be fun. Be sure to include #YearInSpace. I don't want to miss a thing! TWEETCHAT from space now!",
    "id" : 627554794392006656,
    "created_at" : "2015-08-01 19:01:37 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 627560257582202880,
  "created_at" : "2015-08-01 19:23:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SHAQ",
      "screen_name" : "SHAQ",
      "indices" : [ 16, 21 ],
      "id_str" : "17461978",
      "id" : 17461978
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/627550453912440832\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/XYv3YlcbJh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLWBrFiWoAAKKs3.jpg",
      "id_str" : "627550300308676608",
      "id" : 627550300308676608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLWBrFiWoAAKKs3.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/XYv3YlcbJh"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/dRnuXOQZx3",
      "expanded_url" : "http:\/\/Instagram.com\/WhiteHouse",
      "display_url" : "Instagram.com\/WhiteHouse"
    } ]
  },
  "geo" : { },
  "id_str" : "627550453912440832",
  "text" : "Follow along as @Shaq takes over http:\/\/t.co\/dRnuXOQZx3 today to talk about his mentor, Uncle Mike. #MyBrothersKeeper http:\/\/t.co\/XYv3YlcbJh",
  "id" : 627550453912440832,
  "created_at" : "2015-08-01 18:44:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Medicare50",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/piljPgu5i1",
      "expanded_url" : "http:\/\/go.wh.gov\/XU78ST",
      "display_url" : "go.wh.gov\/XU78ST"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/gp8hhDdq5a",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/c282b01e-4244-44a8-910f-9481b20a9977",
      "display_url" : "amp.twimg.com\/v\/c282b01e-424\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627518507308089344",
  "text" : "RT if you agree: Every American deserves a basic measure of dignity and security. http:\/\/t.co\/piljPgu5i1 #Medicare50\nhttps:\/\/t.co\/gp8hhDdq5a",
  "id" : 627518507308089344,
  "created_at" : "2015-08-01 16:37:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/piljPgcuqt",
      "expanded_url" : "http:\/\/go.wh.gov\/XU78ST",
      "display_url" : "go.wh.gov\/XU78ST"
    } ]
  },
  "geo" : { },
  "id_str" : "627497348256636928",
  "text" : "\"We all deserve a health care system that delivers efficient, high-quality care.\" \u2014@POTUS on Medicare and Medicaid: http:\/\/t.co\/piljPgcuqt",
  "id" : 627497348256636928,
  "created_at" : "2015-08-01 15:13:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]