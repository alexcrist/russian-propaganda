Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 21, 31 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/vs82RydE",
      "expanded_url" : "http:\/\/flic.kr\/s\/aHsjyr2MP8",
      "display_url" : "flic.kr\/s\/aHsjyr2MP8"
    } ]
  },
  "geo" : { },
  "id_str" : "164500174104825856",
  "text" : "New Photo Slideshow: @PeteSouza & the WH photo office give you a look behind-the-scenes in December: http:\/\/t.co\/vs82RydE",
  "id" : 164500174104825856,
  "created_at" : "2012-02-01 00:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/164496844276236289\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/HUoSETFa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkhpAiJCAAAee1T.jpg",
      "id_str" : "164496844284624896",
      "id" : 164496844284624896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkhpAiJCAAAee1T.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HUoSETFa"
    } ],
    "hashtags" : [ {
      "text" : "WAS12",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/1rwjXjvo",
      "expanded_url" : "http:\/\/1.usa.gov\/wT0t3f",
      "display_url" : "1.usa.gov\/wT0t3f"
    } ]
  },
  "geo" : { },
  "id_str" : "164496844276236289",
  "text" : "\"The U.S. auto industry is back\" -President Obama @ the Washington Auto Show: http:\/\/t.co\/1rwjXjvo #WAS12 http:\/\/t.co\/HUoSETFa",
  "id" : 164496844276236289,
  "created_at" : "2012-01-31 23:54:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164441099090407424",
  "text" : "RT @startupamerica: Singing happy birthday to Startup America in a room of 300 was a great way to kick off this event!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164438670651310081",
    "text" : "Singing happy birthday to Startup America in a room of 300 was a great way to kick off this event!",
    "id" : 164438670651310081,
    "created_at" : "2012-01-31 20:03:28 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 164441099090407424,
  "created_at" : "2012-01-31 20:13:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "CNN iReport",
      "screen_name" : "cnnireport",
      "indices" : [ 103, 114 ],
      "id_str" : "9411482",
      "id" : 9411482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/dFtGw7nT",
      "expanded_url" : "http:\/\/ow.ly\/8N1Yd",
      "display_url" : "ow.ly\/8N1Yd"
    } ]
  },
  "geo" : { },
  "id_str" : "164428625876230144",
  "text" : "RT @letsmove: Do you have a question for First Lady Michelle Obama about #LetsMove? Add your story via @CNNiReport: http:\/\/t.co\/dFtGw7nT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN iReport",
        "screen_name" : "cnnireport",
        "indices" : [ 89, 100 ],
        "id_str" : "9411482",
        "id" : 9411482
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 59, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/dFtGw7nT",
        "expanded_url" : "http:\/\/ow.ly\/8N1Yd",
        "display_url" : "ow.ly\/8N1Yd"
      } ]
    },
    "geo" : { },
    "id_str" : "164428546805207042",
    "text" : "Do you have a question for First Lady Michelle Obama about #LetsMove? Add your story via @CNNiReport: http:\/\/t.co\/dFtGw7nT",
    "id" : 164428546805207042,
    "created_at" : "2012-01-31 19:23:15 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 164428625876230144,
  "created_at" : "2012-01-31 19:23:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 31, 46 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/nj5jMOvg",
      "expanded_url" : "http:\/\/ow.ly\/8MZtS",
      "display_url" : "ow.ly\/8MZtS"
    } ]
  },
  "geo" : { },
  "id_str" : "164421826871697408",
  "text" : "On the one year anniversary of @startupamerica, President Obama takes steps to accelerate startup & #smallbiz growth: http:\/\/t.co\/nj5jMOvg",
  "id" : 164421826871697408,
  "created_at" : "2012-01-31 18:56:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NFL",
      "screen_name" : "NFL",
      "indices" : [ 39, 43 ],
      "id_str" : "19426551",
      "id" : 19426551
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/164414529374134272\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/TTwHi55G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkgeJLOCIAAQcDL.jpg",
      "id_str" : "164414529378328576",
      "id" : 164414529378328576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkgeJLOCIAAQcDL.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TTwHi55G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164414529374134272",
  "text" : "Photo of the Day: The First Lady shows @NFL PLAY 60 Super Kid James Gale historical photos in the East Wing: http:\/\/t.co\/TTwHi55G",
  "id" : 164414529374134272,
  "created_at" : "2012-01-31 18:27:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 93, 108 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164385318538194944",
  "text" : "RT @whitehouseostp: On 1-Year Anniversary of Startup America Initiative, the President sends @startupamerica legislative agenda to Congr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 73, 88 ],
        "id_str" : "211921304",
        "id" : 211921304
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/IYXk1Cil",
        "expanded_url" : "http:\/\/go.ostp.gov\/wnkCf1",
        "display_url" : "go.ostp.gov\/wnkCf1"
      } ]
    },
    "geo" : { },
    "id_str" : "164385140397703168",
    "text" : "On 1-Year Anniversary of Startup America Initiative, the President sends @startupamerica legislative agenda to Congress http:\/\/t.co\/IYXk1Cil",
    "id" : 164385140397703168,
    "created_at" : "2012-01-31 16:30:46 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 164385318538194944,
  "created_at" : "2012-01-31 16:31:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 76, 87 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaHangout",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/cV4Gtg4x",
      "expanded_url" : "http:\/\/flic.kr\/p\/bmeB5R",
      "display_url" : "flic.kr\/p\/bmeB5R"
    } ]
  },
  "geo" : { },
  "id_str" : "164152323503960064",
  "text" : "PHOTO: President Obama joins a Google+ Hangout in the Roosevelt Room of the @WhiteHouse #ObamaHangout http:\/\/t.co\/cV4Gtg4x",
  "id" : 164152323503960064,
  "created_at" : "2012-01-31 01:05:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamahangout",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/xMOpNEv6",
      "expanded_url" : "http:\/\/youtu.be\/eeTj5qMGTAI",
      "display_url" : "youtu.be\/eeTj5qMGTAI"
    } ]
  },
  "geo" : { },
  "id_str" : "164148866344681472",
  "text" : "VIDEO: Watch President Obama's Google+ Hangout here: http:\/\/t.co\/xMOpNEv6 #obamahangout",
  "id" : 164148866344681472,
  "created_at" : "2012-01-31 00:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 105, 113 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamahangout",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/2DnKfl48",
      "expanded_url" : "http:\/\/ow.ly\/8LWuW",
      "display_url" : "ow.ly\/8LWuW"
    } ]
  },
  "geo" : { },
  "id_str" : "164145961633972224",
  "text" : "RT @ks44: Check out some of the responses to President Obama's Google+ Hangout: http:\/\/t.co\/2DnKfl48 via @Storify #obamahangout",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Storify",
        "screen_name" : "Storify",
        "indices" : [ 95, 103 ],
        "id_str" : "17814938",
        "id" : 17814938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "obamahangout",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/2DnKfl48",
        "expanded_url" : "http:\/\/ow.ly\/8LWuW",
        "display_url" : "ow.ly\/8LWuW"
      } ]
    },
    "geo" : { },
    "id_str" : "164145789021589504",
    "text" : "Check out some of the responses to President Obama's Google+ Hangout: http:\/\/t.co\/2DnKfl48 via @Storify #obamahangout",
    "id" : 164145789021589504,
    "created_at" : "2012-01-31 00:39:40 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 164145961633972224,
  "created_at" : "2012-01-31 00:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amy",
      "screen_name" : "dolphins87ae",
      "indices" : [ 3, 16 ],
      "id_str" : "23937339",
      "id" : 23937339
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamahangout",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/bPhKxavO",
      "expanded_url" : "http:\/\/wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "164134252051578880",
  "text" : "RT @dolphins87ae: @whitehouse where can we view the #obamahangout if we missed it? Full video will be up on http:\/\/t.co\/bPhKxavO soon.",
  "id" : 164134252051578880,
  "created_at" : "2012-01-30 23:53:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 87, 98 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaHangout",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164132173228675072",
  "text" : "Lots of folks talking about the #ObamaHangout. Did you watch? Share your feedback with @whitehouse",
  "id" : 164132173228675072,
  "created_at" : "2012-01-30 23:45:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Fitzpatrick",
      "screen_name" : "AlexJamesFitz",
      "indices" : [ 3, 17 ],
      "id_str" : "24622734",
      "id" : 24622734
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamahangout",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/7Ess5O9G",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "164131271482671104",
  "text" : "RT @AlexJamesFitz: We're seeing something revolutionary in open government tonight. #obamahangout http:\/\/t.co\/7Ess5O9G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "obamahangout",
        "indices" : [ 65, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/7Ess5O9G",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "164121116170928128",
    "text" : "We're seeing something revolutionary in open government tonight. #obamahangout http:\/\/t.co\/7Ess5O9G",
    "id" : 164121116170928128,
    "created_at" : "2012-01-30 23:01:37 +0000",
    "user" : {
      "name" : "Alex Fitzpatrick",
      "screen_name" : "AlexJamesFitz",
      "protected" : false,
      "id_str" : "24622734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791099866642583553\/bEhZ1_AT_normal.jpg",
      "id" : 24622734,
      "verified" : true
    }
  },
  "id" : 164131271482671104,
  "created_at" : "2012-01-30 23:41:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Maestas",
      "screen_name" : "jmaestas22",
      "indices" : [ 3, 14 ],
      "id_str" : "541392596",
      "id" : 541392596
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 26, 38 ],
      "id_str" : "813286",
      "id" : 813286
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 97, 104 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaHangout",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164130829231063040",
  "text" : "RT @jmaestas22: President @BarackObama chatting with people like you and me from their homes via @Google+ in a live #ObamaHangout... thi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 10, 22 ],
        "id_str" : "813286",
        "id" : 813286
      }, {
        "name" : "Google",
        "screen_name" : "google",
        "indices" : [ 81, 88 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaHangout",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164126585040019456",
    "text" : "President @BarackObama chatting with people like you and me from their homes via @Google+ in a live #ObamaHangout... this is incredible",
    "id" : 164126585040019456,
    "created_at" : "2012-01-30 23:23:21 +0000",
    "user" : {
      "name" : "Joey Maestas",
      "screen_name" : "SportsJoey",
      "protected" : false,
      "id_str" : "291862618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758723144676847617\/Y4ly1DYz_normal.jpg",
      "id" : 291862618,
      "verified" : true
    }
  },
  "id" : 164130829231063040,
  "created_at" : "2012-01-30 23:40:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie Bradshaw",
      "screen_name" : "LeslieBradshaw",
      "indices" : [ 3, 18 ],
      "id_str" : "1090561",
      "id" : 1090561
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 75, 87 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamahangout",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164130490792673280",
  "text" : "RT @LeslieBradshaw: Was awesome to watch a mom looping in her kids to meet @BarackObama. In sum: So real-time + so real. #obamahangout h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 55, 67 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "obamahangout",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/8baORbCy",
        "expanded_url" : "http:\/\/twitpic.com\/8dr2nv",
        "display_url" : "twitpic.com\/8dr2nv"
      } ]
    },
    "geo" : { },
    "id_str" : "164127170892009473",
    "text" : "Was awesome to watch a mom looping in her kids to meet @BarackObama. In sum: So real-time + so real. #obamahangout http:\/\/t.co\/8baORbCy",
    "id" : 164127170892009473,
    "created_at" : "2012-01-30 23:25:41 +0000",
    "user" : {
      "name" : "Leslie Bradshaw",
      "screen_name" : "LeslieBradshaw",
      "protected" : false,
      "id_str" : "1090561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770334236553469957\/CqGWvnoB_normal.jpg",
      "id" : 1090561,
      "verified" : true
    }
  },
  "id" : 164130490792673280,
  "created_at" : "2012-01-30 23:38:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 63, 74 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Smallbiz",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "jobs",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "Google",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164123546816229376",
  "text" : "RT @SBAgov: #Smallbiz create most of our new #jobs- Pres Obama @whitehouse #Google+Hangout",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 51, 62 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Smallbiz",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "jobs",
        "indices" : [ 33, 38 ]
      }, {
        "text" : "Google",
        "indices" : [ 63, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164119799457251330",
    "text" : "#Smallbiz create most of our new #jobs- Pres Obama @whitehouse #Google+Hangout",
    "id" : 164119799457251330,
    "created_at" : "2012-01-30 22:56:24 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 164123546816229376,
  "created_at" : "2012-01-30 23:11:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/9Zc4y7S1",
      "expanded_url" : "http:\/\/YouTube.com\/Whitehouse",
      "display_url" : "YouTube.com\/Whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "164123319568826368",
  "text" : "President Obama talks to students about investing in #education in a Google+ Hangout right now. Watch live: http:\/\/t.co\/9Zc4y7S1",
  "id" : 164123319568826368,
  "created_at" : "2012-01-30 23:10:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zerlina Maxwell",
      "screen_name" : "ZerlinaMaxwell",
      "indices" : [ 3, 18 ],
      "id_str" : "21879831",
      "id" : 21879831
    }, {
      "name" : "Laffy",
      "screen_name" : "GottaLaff",
      "indices" : [ 35, 45 ],
      "id_str" : "15368940",
      "id" : 15368940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164122004847468544",
  "text" : "RT @ZerlinaMaxwell: I LOVE THIS RT @GottaLaff: I am impressed that participants able to challenge Pres O, have real convo! http:\/\/t.co\/f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Laffy",
        "screen_name" : "GottaLaff",
        "indices" : [ 15, 25 ],
        "id_str" : "15368940",
        "id" : 15368940
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/f5i6oyGG",
        "expanded_url" : "http:\/\/tinyurl.com\/6ws6gb9",
        "display_url" : "tinyurl.com\/6ws6gb9"
      } ]
    },
    "geo" : { },
    "id_str" : "164120094803374081",
    "text" : "I LOVE THIS RT @GottaLaff: I am impressed that participants able to challenge Pres O, have real convo! http:\/\/t.co\/f5i6oyGG LIVE",
    "id" : 164120094803374081,
    "created_at" : "2012-01-30 22:57:34 +0000",
    "user" : {
      "name" : "Zerlina Maxwell",
      "screen_name" : "ZerlinaMaxwell",
      "protected" : false,
      "id_str" : "21879831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773364923896299520\/lqSSE76g_normal.jpg",
      "id" : 21879831,
      "verified" : false
    }
  },
  "id" : 164122004847468544,
  "created_at" : "2012-01-30 23:05:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/9Zc4y7S1",
      "expanded_url" : "http:\/\/YouTube.com\/Whitehouse",
      "display_url" : "YouTube.com\/Whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "164114318797975552",
  "text" : "Happening now: President Obama answers your questions live in Google+ Hangout from the West Wing. Watch: http:\/\/t.co\/9Zc4y7S1",
  "id" : 164114318797975552,
  "created_at" : "2012-01-30 22:34:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/9Zc4y7S1",
      "expanded_url" : "http:\/\/YouTube.com\/Whitehouse",
      "display_url" : "YouTube.com\/Whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "164113873098641408",
  "text" : "Starting now: President Obama answers your questions live in a Google+ Hangout from the West Wing. Watch: http:\/\/t.co\/9Zc4y7S1",
  "id" : 164113873098641408,
  "created_at" : "2012-01-30 22:32:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/9Zc4y7S1",
      "expanded_url" : "http:\/\/YouTube.com\/Whitehouse",
      "display_url" : "YouTube.com\/Whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "164109416130560000",
  "text" : "Join President Obama for a Google+ Hangout live from the White House at 5:30ET. Watch: http:\/\/t.co\/9Zc4y7S1",
  "id" : 164109416130560000,
  "created_at" : "2012-01-30 22:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 107, 118 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/IJacH4W5",
      "expanded_url" : "http:\/\/youtube.com\/whitehouse",
      "display_url" : "youtube.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "164107646859882497",
  "text" : "RT @WHLive: Happening @ 5:30ET: The President answers your questions in the 1st virtual interview from the @WhiteHouse: http:\/\/t.co\/IJacH4W5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 95, 106 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/IJacH4W5",
        "expanded_url" : "http:\/\/youtube.com\/whitehouse",
        "display_url" : "youtube.com\/whitehouse"
      } ]
    },
    "geo" : { },
    "id_str" : "164107501804060672",
    "text" : "Happening @ 5:30ET: The President answers your questions in the 1st virtual interview from the @WhiteHouse: http:\/\/t.co\/IJacH4W5",
    "id" : 164107501804060672,
    "created_at" : "2012-01-30 22:07:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 164107646859882497,
  "created_at" : "2012-01-30 22:08:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/KAdwWOgD",
      "expanded_url" : "http:\/\/ow.ly\/8LJ5z",
      "display_url" : "ow.ly\/8LJ5z"
    } ]
  },
  "geo" : { },
  "id_str" : "164094174134677504",
  "text" : "From the Archives: President Obama Signs the Lilly Ledbetter Fair Pay Act: http:\/\/t.co\/KAdwWOgD",
  "id" : 164094174134677504,
  "created_at" : "2012-01-30 21:14:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent Pliskow",
      "screen_name" : "bpliskow",
      "indices" : [ 3, 12 ],
      "id_str" : "97792247",
      "id" : 97792247
    }, {
      "name" : "Berkley MI Patch",
      "screen_name" : "BerkleyPatch",
      "indices" : [ 99, 112 ],
      "id_str" : "160552477",
      "id" : 160552477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 77, 82 ]
    }, {
      "text" : "WHTweetup",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/SA1R6nD8",
      "expanded_url" : "http:\/\/berkley.patch.com\/articles\/bhs-grad-shares-his-white-house-adventure",
      "display_url" : "berkley.patch.com\/articles\/bhs-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164081775683977216",
  "text" : "RT @bpliskow: BHS Grad Shares His White House Adventure http:\/\/t.co\/SA1R6nD8 #SOTU #WHTweetup (via @BerkleyPatch)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Berkley MI Patch",
        "screen_name" : "BerkleyPatch",
        "indices" : [ 85, 98 ],
        "id_str" : "160552477",
        "id" : 160552477
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "WHTweetup",
        "indices" : [ 69, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/SA1R6nD8",
        "expanded_url" : "http:\/\/berkley.patch.com\/articles\/bhs-grad-shares-his-white-house-adventure",
        "display_url" : "berkley.patch.com\/articles\/bhs-g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "164081161881128960",
    "text" : "BHS Grad Shares His White House Adventure http:\/\/t.co\/SA1R6nD8 #SOTU #WHTweetup (via @BerkleyPatch)",
    "id" : 164081161881128960,
    "created_at" : "2012-01-30 20:22:52 +0000",
    "user" : {
      "name" : "Brent Pliskow",
      "screen_name" : "bpliskow",
      "protected" : false,
      "id_str" : "97792247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527191290832633856\/OrwCZPwF_normal.jpeg",
      "id" : 97792247,
      "verified" : false
    }
  },
  "id" : 164081775683977216,
  "created_at" : "2012-01-30 20:25:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mohammed Ademo",
      "screen_name" : "OPride",
      "indices" : [ 3, 10 ],
      "id_str" : "67883839",
      "id" : 67883839
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 30, 41 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Solome Lemma",
      "screen_name" : "InnovateAfrica",
      "indices" : [ 97, 112 ],
      "id_str" : "234668137",
      "id" : 234668137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164076263101829120",
  "text" : "RT @OPride: Live-Tweeting the @WhiteHouse Champions of Change panel. See how one of the champion @InnovateAfrica uses social media http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 18, 29 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Solome Lemma",
        "screen_name" : "InnovateAfrica",
        "indices" : [ 85, 100 ],
        "id_str" : "234668137",
        "id" : 234668137
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/Os8sI4Gy",
        "expanded_url" : "http:\/\/bit.ly\/zKwZil",
        "display_url" : "bit.ly\/zKwZil"
      } ]
    },
    "geo" : { },
    "id_str" : "164076081392005120",
    "text" : "Live-Tweeting the @WhiteHouse Champions of Change panel. See how one of the champion @InnovateAfrica uses social media http:\/\/t.co\/Os8sI4Gy",
    "id" : 164076081392005120,
    "created_at" : "2012-01-30 20:02:40 +0000",
    "user" : {
      "name" : "Mohammed Ademo",
      "screen_name" : "OPride",
      "protected" : false,
      "id_str" : "67883839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646924589679923200\/7D9k0vbM_normal.jpg",
      "id" : 67883839,
      "verified" : true
    }
  },
  "id" : 164076263101829120,
  "created_at" : "2012-01-30 20:03:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AARP North Dakota",
      "screen_name" : "AARP_ND",
      "indices" : [ 3, 11 ],
      "id_str" : "111126978",
      "id" : 111126978
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "caregiving",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/OuBEmwac",
      "expanded_url" : "http:\/\/aarp.us\/xgq89A",
      "display_url" : "aarp.us\/xgq89A"
    } ]
  },
  "geo" : { },
  "id_str" : "164075596425605121",
  "text" : "RT @AARP_ND: The @whitehouse proposes wage protection for 2M home care workers. http:\/\/t.co\/OuBEmwac #caregiving",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/socialdashboard.aarp.org\" rel=\"nofollow\"\u003EAARP Social \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "caregiving",
        "indices" : [ 88, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/OuBEmwac",
        "expanded_url" : "http:\/\/aarp.us\/xgq89A",
        "display_url" : "aarp.us\/xgq89A"
      } ]
    },
    "geo" : { },
    "id_str" : "164073956247224321",
    "text" : "The @whitehouse proposes wage protection for 2M home care workers. http:\/\/t.co\/OuBEmwac #caregiving",
    "id" : 164073956247224321,
    "created_at" : "2012-01-30 19:54:14 +0000",
    "user" : {
      "name" : "AARP North Dakota",
      "screen_name" : "AARP_ND",
      "protected" : false,
      "id_str" : "111126978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760937914809348096\/jzUoT-DD_normal.jpg",
      "id" : 111126978,
      "verified" : false
    }
  },
  "id" : 164075596425605121,
  "created_at" : "2012-01-30 20:00:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WGRZ",
      "screen_name" : "WGRZ",
      "indices" : [ 3, 8 ],
      "id_str" : "15308015",
      "id" : 15308015
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 79, 90 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "President",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "Obama",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/cHQERdN3",
      "expanded_url" : "http:\/\/on.wgrz.com\/zBy2JY",
      "display_url" : "on.wgrz.com\/zBy2JY"
    } ]
  },
  "geo" : { },
  "id_str" : "164074834354118657",
  "text" : "RT @WGRZ: #President #Obama to answer your questions live\nhttp:\/\/t.co\/cHQERdN3 @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 69, 80 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "President",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "Obama",
        "indices" : [ 11, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/cHQERdN3",
        "expanded_url" : "http:\/\/on.wgrz.com\/zBy2JY",
        "display_url" : "on.wgrz.com\/zBy2JY"
      } ]
    },
    "geo" : { },
    "id_str" : "164074269754671104",
    "text" : "#President #Obama to answer your questions live\nhttp:\/\/t.co\/cHQERdN3 @whitehouse",
    "id" : 164074269754671104,
    "created_at" : "2012-01-30 19:55:28 +0000",
    "user" : {
      "name" : "WGRZ",
      "screen_name" : "WGRZ",
      "protected" : false,
      "id_str" : "15308015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795942427274186752\/-vce2JN9_normal.jpg",
      "id" : 15308015,
      "verified" : true
    }
  },
  "id" : 164074834354118657,
  "created_at" : "2012-01-30 19:57:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 19, 26 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/164072765719199746\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/jXsnOMRB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkbnT6aCQAAGl91.jpg",
      "id_str" : "164072765727588352",
      "id" : 164072765727588352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkbnT6aCQAAGl91.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/jXsnOMRB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/5hHXggI6",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse",
      "display_url" : "youtube.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "164072765719199746",
  "text" : "Behind-the-scenes: @Google sets up for President Obama's Hangout in the West Wing. Watch @ 5:30ET: http:\/\/t.co\/5hHXggI6 http:\/\/t.co\/jXsnOMRB",
  "id" : 164072765719199746,
  "created_at" : "2012-01-30 19:49:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Done....",
      "screen_name" : "KellicTiger",
      "indices" : [ 0, 12 ],
      "id_str" : "14470431",
      "id" : 14470431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164069442622468096",
  "geo" : { },
  "id_str" : "164071992230821888",
  "in_reply_to_user_id" : 14470431,
  "text" : "@kellictiger nope - the answers will be straight from him to you (and the rest of the world)",
  "id" : 164071992230821888,
  "in_reply_to_status_id" : 164069442622468096,
  "created_at" : "2012-01-30 19:46:25 +0000",
  "in_reply_to_screen_name" : "KellicTiger",
  "in_reply_to_user_id_str" : "14470431",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kaolin fire",
      "screen_name" : "kaolinfire",
      "indices" : [ 0, 11 ],
      "id_str" : "21798156",
      "id" : 21798156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/ELuPhwgH",
      "expanded_url" : "http:\/\/youtube.com\/live",
      "display_url" : "youtube.com\/live"
    } ]
  },
  "in_reply_to_status_id_str" : "164066528889806848",
  "geo" : { },
  "id_str" : "164067405218324480",
  "in_reply_to_user_id" : 21798156,
  "text" : "@kaolinfire everyone can watch @ http:\/\/t.co\/ELuPhwgH & there will be limited space for live participants",
  "id" : 164067405218324480,
  "in_reply_to_status_id" : 164066528889806848,
  "created_at" : "2012-01-30 19:28:12 +0000",
  "in_reply_to_screen_name" : "kaolinfire",
  "in_reply_to_user_id_str" : "21798156",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Done....",
      "screen_name" : "KellicTiger",
      "indices" : [ 0, 12 ],
      "id_str" : "14470431",
      "id" : 14470431
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 55, 66 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164066628546465794",
  "geo" : { },
  "id_str" : "164067185831055360",
  "in_reply_to_user_id" : 14470431,
  "text" : "@kellictiger questions are not vetted or chosen by the @whitehouse",
  "id" : 164067185831055360,
  "in_reply_to_status_id" : 164066628546465794,
  "created_at" : "2012-01-30 19:27:19 +0000",
  "in_reply_to_screen_name" : "KellicTiger",
  "in_reply_to_user_id_str" : "14470431",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Expert Labs",
      "screen_name" : "expertlabs",
      "indices" : [ 3, 14 ],
      "id_str" : "82788404",
      "id" : 82788404
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164065315712532482",
  "text" : "RT @expertlabs: Did you know the @whitehouse rickrolled a Twitter follower? Find this, and more, insights in our 2011 year in review: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 17, 28 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/5snZk8a2",
        "expanded_url" : "http:\/\/expertlabs.org\/2012\/01\/how-the-white-house-drives-engagement-on-twitter-without-linkbait-infographics.html",
        "display_url" : "expertlabs.org\/2012\/01\/how-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "164065077329281024",
    "text" : "Did you know the @whitehouse rickrolled a Twitter follower? Find this, and more, insights in our 2011 year in review: http:\/\/t.co\/5snZk8a2",
    "id" : 164065077329281024,
    "created_at" : "2012-01-30 19:18:57 +0000",
    "user" : {
      "name" : "Expert Labs",
      "screen_name" : "expertlabs",
      "protected" : false,
      "id_str" : "82788404",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480803064\/aaas-bug_normal.gif",
      "id" : 82788404,
      "verified" : false
    }
  },
  "id" : 164065315712532482,
  "created_at" : "2012-01-30 19:19:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Belanger",
      "screen_name" : "StickyHandsHerp",
      "indices" : [ 3, 19 ],
      "id_str" : "63223938",
      "id" : 63223938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/mNTDfz7o",
      "expanded_url" : "http:\/\/fb.me\/1oiGauvZn",
      "display_url" : "fb.me\/1oiGauvZn"
    } ]
  },
  "geo" : { },
  "id_str" : "164047123569057793",
  "text" : "RT @StickyHandsHerp: WORTH KNOWING: President Obama Answers Question Live And Interactive Today. http:\/\/t.co\/mNTDfz7o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/mNTDfz7o",
        "expanded_url" : "http:\/\/fb.me\/1oiGauvZn",
        "display_url" : "fb.me\/1oiGauvZn"
      } ]
    },
    "geo" : { },
    "id_str" : "164046311438561280",
    "text" : "WORTH KNOWING: President Obama Answers Question Live And Interactive Today. http:\/\/t.co\/mNTDfz7o",
    "id" : 164046311438561280,
    "created_at" : "2012-01-30 18:04:23 +0000",
    "user" : {
      "name" : "Adam Belanger",
      "screen_name" : "StickyHandsHerp",
      "protected" : false,
      "id_str" : "63223938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/441444438817005569\/1p4Xts3d_normal.jpeg",
      "id" : 63223938,
      "verified" : false
    }
  },
  "id" : 164047123569057793,
  "created_at" : "2012-01-30 18:07:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/164040643868508160\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/RIDshgwZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkbKGLLCQAEllTJ.jpg",
      "id_str" : "164040643872702465",
      "id" : 164040643872702465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkbKGLLCQAEllTJ.jpg",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 610
      } ],
      "display_url" : "pic.twitter.com\/RIDshgwZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/IGHIzMVW",
      "expanded_url" : "http:\/\/bit.ly\/z3WVnu",
      "display_url" : "bit.ly\/z3WVnu"
    } ]
  },
  "geo" : { },
  "id_str" : "164040643868508160",
  "text" : "President Obama answers your questions in a live Google+ Hangout today. Follow us & watch live: http:\/\/t.co\/IGHIzMVW http:\/\/t.co\/RIDshgwZ",
  "id" : 164040643868508160,
  "created_at" : "2012-01-30 17:41:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Widener University",
      "screen_name" : "WidenerUniv",
      "indices" : [ 3, 15 ],
      "id_str" : "134865043",
      "id" : 134865043
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 32, 36 ],
      "id_str" : "759251",
      "id" : 759251
    }, {
      "name" : "Widener Alumni",
      "screen_name" : "WidenerAlumni",
      "indices" : [ 47, 61 ],
      "id_str" : "38488400",
      "id" : 38488400
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 101, 113 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164027083784335360",
  "text" : "RT @WidenerUniv: Check out this @CNN oped from @WidenerAlumni & Chester-Upland teacher who President @BarackObama invited to the #SOTU h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 15, 19 ],
        "id_str" : "759251",
        "id" : 759251
      }, {
        "name" : "Widener Alumni",
        "screen_name" : "WidenerAlumni",
        "indices" : [ 30, 44 ],
        "id_str" : "38488400",
        "id" : 38488400
      }, {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 84, 96 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/Vd8wpbq3",
        "expanded_url" : "http:\/\/bit.ly\/x4Lr9N",
        "display_url" : "bit.ly\/x4Lr9N"
      } ]
    },
    "geo" : { },
    "id_str" : "164026443825815552",
    "text" : "Check out this @CNN oped from @WidenerAlumni & Chester-Upland teacher who President @BarackObama invited to the #SOTU http:\/\/t.co\/Vd8wpbq3",
    "id" : 164026443825815552,
    "created_at" : "2012-01-30 16:45:26 +0000",
    "user" : {
      "name" : "Widener University",
      "screen_name" : "WidenerUniv",
      "protected" : false,
      "id_str" : "134865043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705832730215501824\/SjyHUFAA_normal.jpg",
      "id" : 134865043,
      "verified" : false
    }
  },
  "id" : 164027083784335360,
  "created_at" : "2012-01-30 16:47:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/6q0Mm9iG",
      "expanded_url" : "http:\/\/ow.ly\/8L9fv",
      "display_url" : "ow.ly\/8L9fv"
    } ]
  },
  "geo" : { },
  "id_str" : "164004799698833410",
  "text" : "Watch Live: President Obama answers your questions in a Google+ Hangout today @ 5:30ET: http:\/\/t.co\/6q0Mm9iG",
  "id" : 164004799698833410,
  "created_at" : "2012-01-30 15:19:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 3, 11 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/YliLZmC4",
      "expanded_url" : "http:\/\/goo.gl\/UAIfg",
      "display_url" : "goo.gl\/UAIfg"
    } ]
  },
  "geo" : { },
  "id_str" : "164004106132922368",
  "text" : "RT @YouTube: Today: Your interview with the President will be live-streamed on YouTube at 2:30 p.m. PT \/ 5:30 p.m. ET http:\/\/t.co\/YliLZmC4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/YliLZmC4",
        "expanded_url" : "http:\/\/goo.gl\/UAIfg",
        "display_url" : "goo.gl\/UAIfg"
      } ]
    },
    "geo" : { },
    "id_str" : "163999984654614528",
    "text" : "Today: Your interview with the President will be live-streamed on YouTube at 2:30 p.m. PT \/ 5:30 p.m. ET http:\/\/t.co\/YliLZmC4",
    "id" : 163999984654614528,
    "created_at" : "2012-01-30 15:00:17 +0000",
    "user" : {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "protected" : false,
      "id_str" : "10228272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796368050878611461\/OG_OqzTW_normal.jpg",
      "id" : 10228272,
      "verified" : true
    }
  },
  "id" : 164004106132922368,
  "created_at" : "2012-01-30 15:16:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163996960469172225",
  "text" : "RT @pfeiffer44: The front page of Google is promoting President Obama's Q&A at 5:30 EST. For more information go to this link http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/lHAh7KUL",
        "expanded_url" : "http:\/\/bit.ly\/wa7hsu",
        "display_url" : "bit.ly\/wa7hsu"
      } ]
    },
    "geo" : { },
    "id_str" : "163994593334001665",
    "text" : "The front page of Google is promoting President Obama's Q&A at 5:30 EST. For more information go to this link http:\/\/t.co\/lHAh7KUL",
    "id" : 163994593334001665,
    "created_at" : "2012-01-30 14:38:52 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 163996960469172225,
  "created_at" : "2012-01-30 14:48:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 3, 11 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/rRJbnl6x",
      "expanded_url" : "http:\/\/bit.ly\/ObamaInterview",
      "display_url" : "bit.ly\/ObamaInterview"
    } ]
  },
  "geo" : { },
  "id_str" : "163414268400771072",
  "text" : "RT @YouTube: Today is your last chance to question one of the most powerful men in the world. What will you ask #Obama? http:\/\/t.co\/rRJbnl6x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/rRJbnl6x",
        "expanded_url" : "http:\/\/bit.ly\/ObamaInterview",
        "display_url" : "bit.ly\/ObamaInterview"
      } ]
    },
    "geo" : { },
    "id_str" : "163305404590342144",
    "text" : "Today is your last chance to question one of the most powerful men in the world. What will you ask #Obama? http:\/\/t.co\/rRJbnl6x",
    "id" : 163305404590342144,
    "created_at" : "2012-01-28 17:00:17 +0000",
    "user" : {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "protected" : false,
      "id_str" : "10228272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796368050878611461\/OG_OqzTW_normal.jpg",
      "id" : 10228272,
      "verified" : true
    }
  },
  "id" : 163414268400771072,
  "created_at" : "2012-01-29 00:12:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/RST7myPS",
      "expanded_url" : "http:\/\/youtu.be\/J6NopOWj5dg",
      "display_url" : "youtu.be\/J6NopOWj5dg"
    } ]
  },
  "geo" : { },
  "id_str" : "163364936028913664",
  "text" : "\"Tell your Member of Congress that it\u2019s time to end the gridlock & start tackling the issues that really matter\" -Obama http:\/\/t.co\/RST7myPS",
  "id" : 163364936028913664,
  "created_at" : "2012-01-28 20:56:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/5hHXggI6",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse",
      "display_url" : "youtube.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "163363130561396736",
  "text" : "Only 8hrs left to vote & ask your question for President Obama: http:\/\/t.co\/5hHXggI6 Obama answers your Qs in a live Google+ Hangout on 1\/30",
  "id" : 163363130561396736,
  "created_at" : "2012-01-28 20:49:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/jpuGQLtX",
      "expanded_url" : "http:\/\/bit.ly\/weiUzI",
      "display_url" : "bit.ly\/weiUzI"
    } ]
  },
  "geo" : { },
  "id_str" : "163046112985489408",
  "text" : "RT @petesouza: Photo of potus mtg w Bush 41 and son Jeb: http:\/\/t.co\/jpuGQLtX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/jpuGQLtX",
        "expanded_url" : "http:\/\/bit.ly\/weiUzI",
        "display_url" : "bit.ly\/weiUzI"
      } ]
    },
    "geo" : { },
    "id_str" : "163045227937009664",
    "text" : "Photo of potus mtg w Bush 41 and son Jeb: http:\/\/t.co\/jpuGQLtX",
    "id" : 163045227937009664,
    "created_at" : "2012-01-27 23:46:26 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 163046112985489408,
  "created_at" : "2012-01-27 23:49:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 45, 55 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/5saeMxLq",
      "expanded_url" : "http:\/\/youtu.be\/4-zCiATLbhg",
      "display_url" : "youtu.be\/4-zCiATLbhg"
    } ]
  },
  "geo" : { },
  "id_str" : "163013800373661697",
  "text" : "First Lady Michelle Obama strikes a pose for @Instagram. Watch: http:\/\/t.co\/5saeMxLq",
  "id" : 163013800373661697,
  "created_at" : "2012-01-27 21:41:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 77, 88 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/CMscv0iF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=yJZu6MgRG3Q",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162989367370063872",
  "text" : "West Wing Week: Special State of the Union Edition: http:\/\/t.co\/CMscv0iF cc: @jearnest44 #SOTU",
  "id" : 162989367370063872,
  "created_at" : "2012-01-27 20:04:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Nate Merrill",
      "screen_name" : "Nate_Merrill",
      "indices" : [ 13, 26 ],
      "id_str" : "86039158",
      "id" : 86039158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162948327745404929",
  "text" : "RT @WHLive: .@nate_merrill just announced first round of Race to the Top (RTT) Early Learning Challenge grants to 9 states. http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nate Merrill",
        "screen_name" : "Nate_Merrill",
        "indices" : [ 1, 14 ],
        "id_str" : "86039158",
        "id" : 86039158
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/9jPEz2oy",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/12\/16\/we-cant-wait-nine-states-awarded-race-top-early-learning-challenge-grant",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162946931524513794",
    "text" : ".@nate_merrill just announced first round of Race to the Top (RTT) Early Learning Challenge grants to 9 states. http:\/\/t.co\/9jPEz2oy #whchat",
    "id" : 162946931524513794,
    "created_at" : "2012-01-27 17:15:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162948327745404929,
  "created_at" : "2012-01-27 17:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Merrill",
      "screen_name" : "Nate_Merrill",
      "indices" : [ 3, 16 ],
      "id_str" : "86039158",
      "id" : 86039158
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 92, 104 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "education",
      "indices" : [ 62, 72 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162948297563185152",
  "text" : "RT @Nate_Merrill: #WHchat What is being done to support early #education programs? A lot of @BarackObama #SOTU was about higher ed innov ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 74, 86 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "education",
        "indices" : [ 44, 54 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 87, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162946175455076353",
    "text" : "#WHchat What is being done to support early #education programs? A lot of @BarackObama #SOTU was about higher ed innovation and loans.",
    "id" : 162946175455076353,
    "created_at" : "2012-01-27 17:12:50 +0000",
    "user" : {
      "name" : "Nate Merrill",
      "screen_name" : "Nate_Merrill",
      "protected" : false,
      "id_str" : "86039158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1076825219\/IMG_0554__Small__normal.JPG",
      "id" : 86039158,
      "verified" : false
    }
  },
  "id" : 162948297563185152,
  "created_at" : "2012-01-27 17:21:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162914173007822848",
  "text" : "RT @JonCarson44: Know someone drowning in student debt? Make sure they learn about President Obama's Income Based Repayment Program: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/Jd2ulTFU",
        "expanded_url" : "http:\/\/studentaid.ed.gov\/PORTALSWebApp\/students\/english\/IBRPlan.jsp",
        "display_url" : "studentaid.ed.gov\/PORTALSWebApp\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162913483485233152",
    "text" : "Know someone drowning in student debt? Make sure they learn about President Obama's Income Based Repayment Program: http:\/\/t.co\/Jd2ulTFU",
    "id" : 162913483485233152,
    "created_at" : "2012-01-27 15:02:55 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 162914173007822848,
  "created_at" : "2012-01-27 15:05:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/Ucdp8FQI",
      "expanded_url" : "http:\/\/goo.gl\/fb\/ZANE2",
      "display_url" : "goo.gl\/fb\/ZANE2"
    } ]
  },
  "geo" : { },
  "id_str" : "162702219685269506",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: President Obama Discusses the Blueprint for American-Made Energy http:\/\/t.co\/Ucdp8FQI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/Ucdp8FQI",
        "expanded_url" : "http:\/\/goo.gl\/fb\/ZANE2",
        "display_url" : "goo.gl\/fb\/ZANE2"
      } ]
    },
    "geo" : { },
    "id_str" : "162701310850891777",
    "text" : "http:\/\/t.co\/HxTO58SB: President Obama Discusses the Blueprint for American-Made Energy http:\/\/t.co\/Ucdp8FQI",
    "id" : 162701310850891777,
    "created_at" : "2012-01-27 00:59:50 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 162702219685269506,
  "created_at" : "2012-01-27 01:03:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lu",
      "screen_name" : "ChrisLu44",
      "indices" : [ 3, 13 ],
      "id_str" : "461697741",
      "id" : 461697741
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162673810355666946",
  "text" : "RT @ChrisLu44: #whchat Hi this is Chris Lu. Ready to start my chat on #SOTU. Fire away",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 55, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162670258300260354",
    "text" : "#whchat Hi this is Chris Lu. Ready to start my chat on #SOTU. Fire away",
    "id" : 162670258300260354,
    "created_at" : "2012-01-26 22:56:26 +0000",
    "user" : {
      "name" : "Chris Lu",
      "screen_name" : "ChrisLu44",
      "protected" : false,
      "id_str" : "461697741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739167604514934784\/as9mVLOb_normal.jpg",
      "id" : 461697741,
      "verified" : true
    }
  },
  "id" : 162673810355666946,
  "created_at" : "2012-01-26 23:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162642503982522371",
  "text" : "RT @WHLive: Hi, Christine here, ready to answer your small business questions #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162641954105065472",
    "text" : "Hi, Christine here, ready to answer your small business questions #WHChat",
    "id" : 162641954105065472,
    "created_at" : "2012-01-26 21:03:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162642503982522371,
  "created_at" : "2012-01-26 21:06:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/lJnuP1KD",
      "expanded_url" : "http:\/\/ow.ly\/8HHCJ",
      "display_url" : "ow.ly\/8HHCJ"
    } ]
  },
  "geo" : { },
  "id_str" : "162636950342348801",
  "text" : "What do you want to know about the President's blueprint for manufacturing? Here's everything: http:\/\/t.co\/lJnuP1KD #SOTU",
  "id" : 162636950342348801,
  "created_at" : "2012-01-26 20:44:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 7, 10 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 98, 106 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/XkkKaI8x",
      "expanded_url" : "http:\/\/ow.ly\/8HCOV",
      "display_url" : "ow.ly\/8HCOV"
    } ]
  },
  "geo" : { },
  "id_str" : "162621921626824704",
  "text" : "Missed @VP Biden's #SOTU twitter interview? The full Q&A is posted here: http:\/\/t.co\/XkkKaI8x via @Storify",
  "id" : 162621921626824704,
  "created_at" : "2012-01-26 19:44:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 43, 51 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/162612732561080320\/photo\/1",
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/Bs1FKb2v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkG3azCCQAEmGwj.jpg",
      "id_str" : "162612732565274625",
      "id" : 162612732565274625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkG3azCCQAEmGwj.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/Bs1FKb2v"
    } ],
    "hashtags" : [ {
      "text" : "NewHampshire",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162616073101905920",
  "text" : "RT @VP: PHOTO: VP kicking off his 1st live @Twitter chat in #NewHampshire earlier today http:\/\/t.co\/Bs1FKb2v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 35, 43 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/162612732561080320\/photo\/1",
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/Bs1FKb2v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AkG3azCCQAEmGwj.jpg",
        "id_str" : "162612732565274625",
        "id" : 162612732565274625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkG3azCCQAEmGwj.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 816
        } ],
        "display_url" : "pic.twitter.com\/Bs1FKb2v"
      } ],
      "hashtags" : [ {
        "text" : "NewHampshire",
        "indices" : [ 52, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162612732561080320",
    "text" : "PHOTO: VP kicking off his 1st live @Twitter chat in #NewHampshire earlier today http:\/\/t.co\/Bs1FKb2v",
    "id" : 162612732561080320,
    "created_at" : "2012-01-26 19:07:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 162616073101905920,
  "created_at" : "2012-01-26 19:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obtaining Currency",
      "screen_name" : "abigailcollazo",
      "indices" : [ 3, 18 ],
      "id_str" : "2759890528",
      "id" : 2759890528
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 132, 135 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fairpay",
      "indices" : [ 99, 107 ]
    }, {
      "text" : "equality",
      "indices" : [ 108, 117 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "fem2",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162605214510231552",
  "text" : "RT @abigailcollazo: How will @whitehouse make good on pledge to women: \u201Cequal pay for equal work?\u201D #fairpay #equality #WHChat #fem2 @VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 9, 20 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 112, 115 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fairpay",
        "indices" : [ 79, 87 ]
      }, {
        "text" : "equality",
        "indices" : [ 88, 97 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "fem2",
        "indices" : [ 106, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162603334736429056",
    "text" : "How will @whitehouse make good on pledge to women: \u201Cequal pay for equal work?\u201D #fairpay #equality #WHChat #fem2 @VP",
    "id" : 162603334736429056,
    "created_at" : "2012-01-26 18:30:30 +0000",
    "user" : {
      "name" : "Abigail Collazo",
      "screen_name" : "LeftStandingUp",
      "protected" : false,
      "id_str" : "25388412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705098981060153344\/SuZl72EM_normal.jpg",
      "id" : 25388412,
      "verified" : false
    }
  },
  "id" : 162605214510231552,
  "created_at" : "2012-01-26 18:37:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Mark Andrew",
      "screen_name" : "chickentrooper",
      "indices" : [ 9, 24 ],
      "id_str" : "27160427",
      "id" : 27160427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162603343070507008",
  "text" : "RT @VP: .@chickentrooper yes already cut $2 trillion - ready to cut $2 trillion more if Republicans cooperate & everyone contributes. -v ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Andrew",
        "screen_name" : "chickentrooper",
        "indices" : [ 1, 16 ],
        "id_str" : "27160427",
        "id" : 27160427
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162603030368362497",
    "text" : ".@chickentrooper yes already cut $2 trillion - ready to cut $2 trillion more if Republicans cooperate & everyone contributes. -vp #whchat",
    "id" : 162603030368362497,
    "created_at" : "2012-01-26 18:29:18 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 162603343070507008,
  "created_at" : "2012-01-26 18:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 62, 67 ]
    }, {
      "text" : "whchat",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162599713772810240",
  "text" : "RT @VP: Ready to go, anxious to hear your questions, lets go  #SOTU #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 54, 59 ]
      }, {
        "text" : "whchat",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162599636530495489",
    "text" : "Ready to go, anxious to hear your questions, lets go  #SOTU #whchat",
    "id" : 162599636530495489,
    "created_at" : "2012-01-26 18:15:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 162599713772810240,
  "created_at" : "2012-01-26 18:16:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 32, 35 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 74, 79 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162599694114103296",
  "text" : "RT @gov: Stand by. Our Q&A with @VP Biden will begin shortly. Submit your #SOTU-related questions using #WHChat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 23, 26 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 65, 70 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 95, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162598336547917825",
    "text" : "Stand by. Our Q&A with @VP Biden will begin shortly. Submit your #SOTU-related questions using #WHChat.",
    "id" : 162598336547917825,
    "created_at" : "2012-01-26 18:10:39 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663898965784395776\/rEWW6euI_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 162599694114103296,
  "created_at" : "2012-01-26 18:16:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 20, 23 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 43, 48 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162576975767142400",
  "text" : "Happening @ 1:10ET: @VP Biden answers your #SOTU questions live from New Hampshire in his inaugural twitter interview. Ask now: #WHChat",
  "id" : 162576975767142400,
  "created_at" : "2012-01-26 16:45:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 12, 17 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162553989643243520",
  "text" : "RT @WHLive: #SOTU Good morning - up on comms here to take your questions on veterans, military families and wounded warrior issues. #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162551345356873728",
    "text" : "#SOTU Good morning - up on comms here to take your questions on veterans, military families and wounded warrior issues. #WHChat",
    "id" : 162551345356873728,
    "created_at" : "2012-01-26 15:03:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162553989643243520,
  "created_at" : "2012-01-26 15:14:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 72, 80 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "NewHampshire",
      "indices" : [ 102, 115 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162536543918112769",
  "text" : "RT @VP: Have a Q for VP on #SOTU? Tune in @ 1:10pm ET today for his 1st @Twitter chat from Rochester, #NewHampshire. Use #WHChat or #SOT ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 64, 72 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 19, 24 ]
      }, {
        "text" : "NewHampshire",
        "indices" : [ 94, 107 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 113, 120 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162503538105270272",
    "text" : "Have a Q for VP on #SOTU? Tune in @ 1:10pm ET today for his 1st @Twitter chat from Rochester, #NewHampshire. Use #WHChat or #SOTU to ask Qs",
    "id" : 162503538105270272,
    "created_at" : "2012-01-26 11:53:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 162536543918112769,
  "created_at" : "2012-01-26 14:05:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162536520220286976",
  "text" : "RT @VP: VP in Rochester, NH today to discuss Admin effort to promote partnerships b\/t community colleges & businesses to train skilled w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162504555496611841",
    "text" : "VP in Rochester, NH today to discuss Admin effort to promote partnerships b\/t community colleges & businesses to train skilled workers",
    "id" : 162504555496611841,
    "created_at" : "2012-01-26 11:57:59 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 162536520220286976,
  "created_at" : "2012-01-26 14:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 44, 47 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 92, 96 ],
      "id_str" : "222953824",
      "id" : 222953824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162532440336900096",
  "text" : "RT @gov: Have #SOTU follow-up questions for @VP Joe Biden? Ask using #WHChat and follow our @gov Q&A with him at 1:10p ET.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 35, 38 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "Twitter Government",
        "screen_name" : "gov",
        "indices" : [ 83, 87 ],
        "id_str" : "222953824",
        "id" : 222953824
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 5, 10 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162530047780061184",
    "text" : "Have #SOTU follow-up questions for @VP Joe Biden? Ask using #WHChat and follow our @gov Q&A with him at 1:10p ET.",
    "id" : 162530047780061184,
    "created_at" : "2012-01-26 13:39:17 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663898965784395776\/rEWW6euI_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 162532440336900096,
  "created_at" : "2012-01-26 13:48:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 130, 133 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 136, 140 ],
      "id_str" : "222953824",
      "id" : 222953824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162374981639090176",
  "text" : "Don't miss your twitter interview with Vice President Biden on 1\/26 @ 1:10ET. What are your #SOTU questions? Ask: #WHChat Follow: @VP & @gov",
  "id" : 162374981639090176,
  "created_at" : "2012-01-26 03:23:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 45, 48 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 91, 99 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 124, 131 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162328916764270594",
  "text" : "Have questions about the State of the Union? @VP Biden will answer your Qs in his 1st ever @Twitter interview. Ask now with #WHChat & #SOTU",
  "id" : 162328916764270594,
  "created_at" : "2012-01-26 00:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "John Curtis Smith",
      "screen_name" : "johncsmith88",
      "indices" : [ 17, 30 ],
      "id_str" : "21971963",
      "id" : 21971963
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 49, 54 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162276087970283522",
  "text" : "RT @pfeiffer44: .@johncsmith88 Last night in the #SOTU he proposed ending deductions for companies that ship jobs overseas #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Curtis Smith",
        "screen_name" : "johncsmith88",
        "indices" : [ 1, 14 ],
        "id_str" : "21971963",
        "id" : 21971963
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 33, 38 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162275427124117504",
    "text" : ".@johncsmith88 Last night in the #SOTU he proposed ending deductions for companies that ship jobs overseas #WHchat",
    "id" : 162275427124117504,
    "created_at" : "2012-01-25 20:47:31 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 162276087970283522,
  "created_at" : "2012-01-25 20:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Curtis Smith",
      "screen_name" : "johncsmith88",
      "indices" : [ 3, 16 ],
      "id_str" : "21971963",
      "id" : 21971963
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 18, 29 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162276074649161728",
  "text" : "RT @johncsmith88: @pfeiffer44 What does President Obama think should be done to encourage Americans companies to put American jobs first ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 0, 11 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162274810657898496",
    "in_reply_to_user_id" : 131144091,
    "text" : "@pfeiffer44 What does President Obama think should be done to encourage Americans companies to put American jobs first? #whchat",
    "id" : 162274810657898496,
    "created_at" : "2012-01-25 20:45:04 +0000",
    "in_reply_to_screen_name" : "Goldman44",
    "in_reply_to_user_id_str" : "131144091",
    "user" : {
      "name" : "John Curtis Smith",
      "screen_name" : "johncsmith88",
      "protected" : false,
      "id_str" : "21971963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761773072353460224\/FxSs1NC3_normal.jpg",
      "id" : 21971963,
      "verified" : false
    }
  },
  "id" : 162276074649161728,
  "created_at" : "2012-01-25 20:50:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Lamb",
      "screen_name" : "bennyfactor",
      "indices" : [ 3, 15 ],
      "id_str" : "14962879",
      "id" : 14962879
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/jYWIfl8K",
      "expanded_url" : "http:\/\/ow.ly\/8Gm2Z",
      "display_url" : "ow.ly\/8Gm2Z"
    } ]
  },
  "in_reply_to_status_id_str" : "162270936438022144",
  "geo" : { },
  "id_str" : "162274316149473282",
  "in_reply_to_user_id" : 14962879,
  "text" : "RT @bennyfactor How does the President & his advisors prepare the speech? \/\/ Go behind-the-scenes in this video http:\/\/t.co\/jYWIfl8K #whchat",
  "id" : 162274316149473282,
  "in_reply_to_status_id" : 162270936438022144,
  "created_at" : "2012-01-25 20:43:06 +0000",
  "in_reply_to_screen_name" : "bennyfactor",
  "in_reply_to_user_id_str" : "14962879",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Ben Lamb",
      "screen_name" : "bennyfactor",
      "indices" : [ 17, 29 ],
      "id_str" : "14962879",
      "id" : 14962879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162272346844053504",
  "text" : "RT @pfeiffer44: .@bennyfactor POTUS often writes big portions out long hand on a yellow legal pad and then works with his speechwriters. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Lamb",
        "screen_name" : "bennyfactor",
        "indices" : [ 1, 13 ],
        "id_str" : "14962879",
        "id" : 14962879
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162272024704720898",
    "text" : ".@bennyfactor POTUS often writes big portions out long hand on a yellow legal pad and then works with his speechwriters. #whchat",
    "id" : 162272024704720898,
    "created_at" : "2012-01-25 20:34:00 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 162272346844053504,
  "created_at" : "2012-01-25 20:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Lamb",
      "screen_name" : "bennyfactor",
      "indices" : [ 3, 15 ],
      "id_str" : "14962879",
      "id" : 14962879
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 17, 28 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162272345749340160",
  "text" : "RT @bennyfactor: @pfeiffer44 How does the President (and his advisors) prepare the speech? Does he type it up on a laptop? Write it out? ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 0, 11 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "162268337001332736",
    "geo" : { },
    "id_str" : "162270936438022144",
    "in_reply_to_user_id" : 131144091,
    "text" : "@pfeiffer44 How does the President (and his advisors) prepare the speech? Does he type it up on a laptop? Write it out? Dictate it? #whchat",
    "id" : 162270936438022144,
    "in_reply_to_status_id" : 162268337001332736,
    "created_at" : "2012-01-25 20:29:40 +0000",
    "in_reply_to_screen_name" : "Goldman44",
    "in_reply_to_user_id_str" : "131144091",
    "user" : {
      "name" : "Ben Lamb",
      "screen_name" : "bennyfactor",
      "protected" : false,
      "id_str" : "14962879",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790646764495785984\/s8HDIZm7_normal.jpg",
      "id" : 14962879,
      "verified" : false
    }
  },
  "id" : 162272345749340160,
  "created_at" : "2012-01-25 20:35:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Ino",
      "screen_name" : "juan0018",
      "indices" : [ 16, 25 ],
      "id_str" : "752197477546225664",
      "id" : 752197477546225664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162270960790159361",
  "text" : "RT @pfeiffer44: @juan0018 He does have an Immigration Reform plan. He laid it out in Texas last year. Wants to work with R's and D's to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ino",
        "screen_name" : "juan0018",
        "indices" : [ 0, 9 ],
        "id_str" : "752197477546225664",
        "id" : 752197477546225664
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162270534116188160",
    "in_reply_to_user_id" : 18441016,
    "text" : "@juan0018 He does have an Immigration Reform plan. He laid it out in Texas last year. Wants to work with R's and D's to pass it #whchat",
    "id" : 162270534116188160,
    "created_at" : "2012-01-25 20:28:04 +0000",
    "in_reply_to_screen_name" : "JuanWritesAgain",
    "in_reply_to_user_id_str" : "18441016",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 162270960790159361,
  "created_at" : "2012-01-25 20:29:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ino",
      "screen_name" : "juan0018",
      "indices" : [ 3, 12 ],
      "id_str" : "752197477546225664",
      "id" : 752197477546225664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162270926191333376",
  "text" : "RT @juan0018: #whchat POTUS spoke of an immigration reform, does he have a plan?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162269503546343424",
    "text" : "#whchat POTUS spoke of an immigration reform, does he have a plan?",
    "id" : 162269503546343424,
    "created_at" : "2012-01-25 20:23:59 +0000",
    "user" : {
      "name" : "Juan Yoshika",
      "screen_name" : "JuanWritesAgain",
      "protected" : false,
      "id_str" : "18441016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782585430617288704\/R8iiam8C_normal.jpg",
      "id" : 18441016,
      "verified" : false
    }
  },
  "id" : 162270926191333376,
  "created_at" : "2012-01-25 20:29:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "MR",
      "screen_name" : "alaskaDJ",
      "indices" : [ 17, 26 ],
      "id_str" : "125040544",
      "id" : 125040544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162270432530153476",
  "text" : "RT @pfeiffer44: .@alaskadj POTUS wants to make the code simpler and more fair but we need GOP partners who will ask weatlthy to pay thei ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MR",
        "screen_name" : "alaskaDJ",
        "indices" : [ 1, 10 ],
        "id_str" : "125040544",
        "id" : 125040544
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162270074638569472",
    "text" : ".@alaskadj POTUS wants to make the code simpler and more fair but we need GOP partners who will ask weatlthy to pay their fair share #whchat",
    "id" : 162270074638569472,
    "created_at" : "2012-01-25 20:26:15 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 162270432530153476,
  "created_at" : "2012-01-25 20:27:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MR",
      "screen_name" : "alaskaDJ",
      "indices" : [ 3, 12 ],
      "id_str" : "125040544",
      "id" : 125040544
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 14, 25 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162269953070870528",
  "text" : "RT @alaskaDJ: @pfeiffer44 will President Obama push for tax reform this year? #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 0, 11 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "162268337001332736",
    "geo" : { },
    "id_str" : "162269009285365761",
    "in_reply_to_user_id" : 131144091,
    "text" : "@pfeiffer44 will President Obama push for tax reform this year? #whchat",
    "id" : 162269009285365761,
    "in_reply_to_status_id" : 162268337001332736,
    "created_at" : "2012-01-25 20:22:01 +0000",
    "in_reply_to_screen_name" : "Goldman44",
    "in_reply_to_user_id_str" : "131144091",
    "user" : {
      "name" : "MR",
      "screen_name" : "alaskaDJ",
      "protected" : false,
      "id_str" : "125040544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520405280182390784\/BaD3DWUd_normal.jpeg",
      "id" : 125040544,
      "verified" : false
    }
  },
  "id" : 162269953070870528,
  "created_at" : "2012-01-25 20:25:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 54, 65 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 89, 94 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162266197092610049",
  "text" : "RT @WHLive: Starting soon: WH Communications Director @pfeiffer44 will answer your ?s on #SOTU. Ask now with #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 42, 53 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 77, 82 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162265830221029376",
    "text" : "Starting soon: WH Communications Director @pfeiffer44 will answer your ?s on #SOTU. Ask now with #WHChat",
    "id" : 162265830221029376,
    "created_at" : "2012-01-25 20:09:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162266197092610049,
  "created_at" : "2012-01-25 20:10:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/Ukj9eQYd",
      "expanded_url" : "http:\/\/wapo.st\/zjzlsq",
      "display_url" : "wapo.st\/zjzlsq"
    } ]
  },
  "geo" : { },
  "id_str" : "162253455929516032",
  "text" : "RT @DeptVetAffairs: Secretary Shinseki heading to Atlanta to promote Veterans employment http:\/\/t.co\/Ukj9eQYd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/Ukj9eQYd",
        "expanded_url" : "http:\/\/wapo.st\/zjzlsq",
        "display_url" : "wapo.st\/zjzlsq"
      } ]
    },
    "geo" : { },
    "id_str" : "162253223300825090",
    "text" : "Secretary Shinseki heading to Atlanta to promote Veterans employment http:\/\/t.co\/Ukj9eQYd",
    "id" : 162253223300825090,
    "created_at" : "2012-01-25 19:19:17 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 162253455929516032,
  "created_at" : "2012-01-25 19:20:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 56, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/bXC7Kf46",
      "expanded_url" : "http:\/\/ow.ly\/8GfAH",
      "display_url" : "ow.ly\/8GfAH"
    } ]
  },
  "geo" : { },
  "id_str" : "162252438315859970",
  "text" : "2012 State of the Union Address in pictures. Launch the #SOTU slideshow: http:\/\/t.co\/bXC7Kf46",
  "id" : 162252438315859970,
  "created_at" : "2012-01-25 19:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "Joe Wentworth",
      "screen_name" : "jwentworth79",
      "indices" : [ 16, 29 ],
      "id_str" : "377455923",
      "id" : 377455923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/F1VYJO1S",
      "expanded_url" : "http:\/\/wh.gov\/jobsact",
      "display_url" : "wh.gov\/jobsact"
    } ]
  },
  "geo" : { },
  "id_str" : "162222793092644864",
  "text" : "RT @jearnest44: @jwentworth79 POTUS intro'd American Jobs Act last Sept - bipartisan job-creating ideas.  http:\/\/t.co\/F1VYJO1S  #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Wentworth",
        "screen_name" : "jwentworth79",
        "indices" : [ 0, 13 ],
        "id_str" : "377455923",
        "id" : 377455923
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/F1VYJO1S",
        "expanded_url" : "http:\/\/wh.gov\/jobsact",
        "display_url" : "wh.gov\/jobsact"
      } ]
    },
    "geo" : { },
    "id_str" : "162221165589446656",
    "in_reply_to_user_id" : 377455923,
    "text" : "@jwentworth79 POTUS intro'd American Jobs Act last Sept - bipartisan job-creating ideas.  http:\/\/t.co\/F1VYJO1S  #WHChat",
    "id" : 162221165589446656,
    "created_at" : "2012-01-25 17:11:54 +0000",
    "in_reply_to_screen_name" : "jwentworth79",
    "in_reply_to_user_id_str" : "377455923",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 162222793092644864,
  "created_at" : "2012-01-25 17:18:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wentworth",
      "screen_name" : "jwentworth79",
      "indices" : [ 3, 16 ],
      "id_str" : "377455923",
      "id" : 377455923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162220983019782144",
  "text" : "RT @jwentworth79: Instead of talking about plans to create jobs, why doesn't Obama draft actual legislation and have it introduced? #WHc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 114, 121 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 122, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162219778709266432",
    "text" : "Instead of talking about plans to create jobs, why doesn't Obama draft actual legislation and have it introduced? #WHchat #SOTU",
    "id" : 162219778709266432,
    "created_at" : "2012-01-25 17:06:23 +0000",
    "user" : {
      "name" : "Joe Wentworth",
      "screen_name" : "jwentworth79",
      "protected" : false,
      "id_str" : "377455923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1554668533\/Joe_normal.jpg",
      "id" : 377455923,
      "verified" : false
    }
  },
  "id" : 162220983019782144,
  "created_at" : "2012-01-25 17:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "Geoffrey Stanton",
      "screen_name" : "GeoffreyStanton",
      "indices" : [ 17, 33 ],
      "id_str" : "412777299",
      "id" : 412777299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162219536261726208",
  "text" : "RT @jearnest44: .@GeoffreyStanton POTUS urging Congress to find bipartisan common ground. Making taxes fairer for middle class=prime rea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Geoffrey Stanton",
        "screen_name" : "GeoffreyStanton",
        "indices" : [ 1, 17 ],
        "id_str" : "412777299",
        "id" : 412777299
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162218679621267456",
    "text" : ".@GeoffreyStanton POTUS urging Congress to find bipartisan common ground. Making taxes fairer for middle class=prime real estate.  #WHChat",
    "id" : 162218679621267456,
    "created_at" : "2012-01-25 17:02:01 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 162219536261726208,
  "created_at" : "2012-01-25 17:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geoffrey Stanton",
      "screen_name" : "GeoffreyStanton",
      "indices" : [ 3, 19 ],
      "id_str" : "412777299",
      "id" : 412777299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162219511334965249",
  "text" : "RT @GeoffreyStanton: #whchat is the house attempting the tax reform? Did Obamas role as chief legislator prompt legislation?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162206641717133313",
    "text" : "#whchat is the house attempting the tax reform? Did Obamas role as chief legislator prompt legislation?",
    "id" : 162206641717133313,
    "created_at" : "2012-01-25 16:14:11 +0000",
    "user" : {
      "name" : "Geoffrey Stanton",
      "screen_name" : "GeoffreyStanton",
      "protected" : false,
      "id_str" : "412777299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3013910193\/613dbace1c4568318440569c0e35f94e_normal.jpeg",
      "id" : 412777299,
      "verified" : false
    }
  },
  "id" : 162219511334965249,
  "created_at" : "2012-01-25 17:05:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "Robert Burns",
      "screen_name" : "bigeye61",
      "indices" : [ 17, 26 ],
      "id_str" : "40888905",
      "id" : 40888905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162215663207858179",
  "text" : "RT @jearnest44: .@bigeye61 Last nite, POTUS announced AG Holder will investigate (w\/ state AGs) abusive lending & packaging of risky mor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robert Burns",
        "screen_name" : "bigeye61",
        "indices" : [ 1, 10 ],
        "id_str" : "40888905",
        "id" : 40888905
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 127, 132 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162215435104825346",
    "text" : ".@bigeye61 Last nite, POTUS announced AG Holder will investigate (w\/ state AGs) abusive lending & packaging of risky mortgages #SOTU #WHChat",
    "id" : 162215435104825346,
    "created_at" : "2012-01-25 16:49:08 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 162215663207858179,
  "created_at" : "2012-01-25 16:50:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Burns",
      "screen_name" : "bigeye61",
      "indices" : [ 3, 12 ],
      "id_str" : "40888905",
      "id" : 40888905
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "investigate",
      "indices" : [ 69, 81 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/FMifhwtO",
      "expanded_url" : "http:\/\/pol.moveon.org\/bankfraud\/?rc=tw",
      "display_url" : "pol.moveon.org\/bankfraud\/?rc=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162215655016374272",
  "text" : "RT @bigeye61: Question for #SOTU @WhiteHouse When will the president #investigate Wall Street bank fraud? #WHChat http:\/\/t.co\/FMifhwtO # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 19, 30 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 13, 18 ]
      }, {
        "text" : "investigate",
        "indices" : [ 55, 67 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 92, 99 ]
      }, {
        "text" : "yeshecan",
        "indices" : [ 121, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/FMifhwtO",
        "expanded_url" : "http:\/\/pol.moveon.org\/bankfraud\/?rc=tw",
        "display_url" : "pol.moveon.org\/bankfraud\/?rc=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162207668033953792",
    "text" : "Question for #SOTU @WhiteHouse When will the president #investigate Wall Street bank fraud? #WHChat http:\/\/t.co\/FMifhwtO #yeshecan",
    "id" : 162207668033953792,
    "created_at" : "2012-01-25 16:18:16 +0000",
    "user" : {
      "name" : "Robert Burns",
      "screen_name" : "bigeye61",
      "protected" : false,
      "id_str" : "40888905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2529868464\/bfh0ja74ts7pdtgg7jj8_normal.jpeg",
      "id" : 40888905,
      "verified" : false
    }
  },
  "id" : 162215655016374272,
  "created_at" : "2012-01-25 16:50:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162212877263056896",
  "text" : "RT @jearnest44: I'm settled in and, as advertised, ready to take some q's about last night's 'Blueprint for an America that's Built to L ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 125, 130 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162212820774162432",
    "text" : "I'm settled in and, as advertised, ready to take some q's about last night's 'Blueprint for an America that's Built to Last' #SOTU #WHChat",
    "id" : 162212820774162432,
    "created_at" : "2012-01-25 16:38:44 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 162212877263056896,
  "created_at" : "2012-01-25 16:38:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 3, 14 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162192216335450112",
  "text" : "RT @foursquare: Want a foursquare badge for your town? Share a list of the best spots in your city and you could get one! http:\/\/t.co\/Gj ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 127, 135 ]
      }, {
        "text" : "4sq",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/GjQBmAWh",
        "expanded_url" : "http:\/\/bit.ly\/wy2I9t",
        "display_url" : "bit.ly\/wy2I9t"
      } ]
    },
    "geo" : { },
    "id_str" : "161915576749531137",
    "text" : "Want a foursquare badge for your town? Share a list of the best spots in your city and you could get one! http:\/\/t.co\/GjQBmAWh #visitUS #4sq",
    "id" : 161915576749531137,
    "created_at" : "2012-01-24 20:57:36 +0000",
    "user" : {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "protected" : false,
      "id_str" : "14120151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776115264291307520\/q5Tp332e_normal.jpg",
      "id" : 14120151,
      "verified" : true
    }
  },
  "id" : 162192216335450112,
  "created_at" : "2012-01-25 15:16:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 39, 53 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/162178467276926976\/photo\/1",
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/0Ug7tCZi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AkAsdOyCMAAMm9J.jpg",
      "id_str" : "162178467281121280",
      "id" : 162178467281121280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AkAsdOyCMAAMm9J.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0Ug7tCZi"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162178467276926976",
  "text" : "Photo of the Day: President Obama hugs @GabbyGiffords at the State of the Union #SOTU: http:\/\/t.co\/0Ug7tCZi",
  "id" : 162178467276926976,
  "created_at" : "2012-01-25 14:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/lWpUyMuK",
      "expanded_url" : "http:\/\/youtu.be\/Zgfi7wnGZlE",
      "display_url" : "youtu.be\/Zgfi7wnGZlE"
    }, {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/TG1F4J33",
      "expanded_url" : "http:\/\/WH.gov\/SOTU",
      "display_url" : "WH.gov\/SOTU"
    } ]
  },
  "geo" : { },
  "id_str" : "162055577978150912",
  "text" : "VIDEO of President Obama's #SOTU Address: A Blueprint for an America Built To Last http:\/\/t.co\/lWpUyMuK More @ http:\/\/t.co\/TG1F4J33",
  "id" : 162055577978150912,
  "created_at" : "2012-01-25 06:13:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/lWpUyMuK",
      "expanded_url" : "http:\/\/youtu.be\/Zgfi7wnGZlE",
      "display_url" : "youtu.be\/Zgfi7wnGZlE"
    }, {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "162055446906150914",
  "text" : "Watch President Obama's State of the Union Address: http:\/\/t.co\/lWpUyMuK & join the conversation @ http:\/\/t.co\/Cq1szOIA #SOTU",
  "id" : 162055446906150914,
  "created_at" : "2012-01-25 06:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "\u0417\u0430\u0439\u0446\u0435\u0432\u0430   \u041A\u0441\u0435\u043D\u0438\u044F",
      "screen_name" : "mashusworld",
      "indices" : [ 14, 26 ],
      "id_str" : "2982156399",
      "id" : 2982156399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/1FngOivY",
      "expanded_url" : "http:\/\/WH.gov\/SOTU",
      "display_url" : "WH.gov\/SOTU"
    } ]
  },
  "geo" : { },
  "id_str" : "162045761683595264",
  "text" : "RT @macon44: .@mashusworld I was wrong - we had more. 3.2 million streams so far. 26,000 still watching the #SOTU @ http:\/\/t.co\/1FngOivY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0417\u0430\u0439\u0446\u0435\u0432\u0430   \u041A\u0441\u0435\u043D\u0438\u044F",
        "screen_name" : "mashusworld",
        "indices" : [ 1, 13 ],
        "id_str" : "2982156399",
        "id" : 2982156399
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 95, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/1FngOivY",
        "expanded_url" : "http:\/\/WH.gov\/SOTU",
        "display_url" : "WH.gov\/SOTU"
      } ]
    },
    "in_reply_to_status_id_str" : "162016078774534144",
    "geo" : { },
    "id_str" : "162042952703676416",
    "in_reply_to_user_id" : 372502604,
    "text" : ".@mashusworld I was wrong - we had more. 3.2 million streams so far. 26,000 still watching the #SOTU @ http:\/\/t.co\/1FngOivY",
    "id" : 162042952703676416,
    "in_reply_to_status_id" : 162016078774534144,
    "created_at" : "2012-01-25 05:23:45 +0000",
    "in_reply_to_screen_name" : "MashableNews",
    "in_reply_to_user_id_str" : "372502604",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 162045761683595264,
  "created_at" : "2012-01-25 05:34:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/BlK9tULb",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/01\/24\/remarks-president-state-union-address",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162041631229485057",
  "text" : "Read the remarks from President Obama's State of the Union Address: http:\/\/t.co\/BlK9tULb #SOTU",
  "id" : 162041631229485057,
  "created_at" : "2012-01-25 05:18:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn SlideShare",
      "screen_name" : "SlideShare",
      "indices" : [ 74, 85 ],
      "id_str" : "9676152",
      "id" : 9676152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/aqkcLQ75",
      "expanded_url" : "http:\/\/www.slideshare.net\/whitehouse\/state-of-the-union-enhanced-graphics",
      "display_url" : "slideshare.net\/whitehouse\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162040477707800576",
  "text" : "Check out the State of the Union enhanced slides http:\/\/t.co\/aqkcLQ75 via @slideshare #SOTU",
  "id" : 162040477707800576,
  "created_at" : "2012-01-25 05:13:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162037936299315201",
  "text" : "RT @jearnest44: Make no mistake: since POTUS took office oil & gas production has increased EACH year & in 2011 US produced more oil tha ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162031065148555264",
    "text" : "Make no mistake: since POTUS took office oil & gas production has increased EACH year & in 2011 US produced more oil than any time since '03",
    "id" : 162031065148555264,
    "created_at" : "2012-01-25 04:36:30 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 162037936299315201,
  "created_at" : "2012-01-25 05:03:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 20, 31 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "162025484098605057",
  "text" : "Education Secretary @arneduncan stopped by the #SOTU panel @ the White House. He's answering your Qs now. Watch: http:\/\/t.co\/Cq1szOIA",
  "id" : 162025484098605057,
  "created_at" : "2012-01-25 04:14:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162024312914706432",
  "text" : "\"[I believe what] Lincoln believed...government should do for people only what they cannot do better by themselves & no more\" -Obama #SOTU",
  "id" : 162024312914706432,
  "created_at" : "2012-01-25 04:09:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/162022775186395136\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/NtxBA9cf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj-e2wjCEAALfsf.jpg",
      "id_str" : "162022775190589440",
      "id" : 162022775190589440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj-e2wjCEAALfsf.jpg",
      "sizes" : [ {
        "h" : 492,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/NtxBA9cf"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 66, 71 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162022775186395136",
  "text" : "\"In the last 22 months, businesses have created more than million #jobs\" -President Obama in the #SOTU http:\/\/t.co\/NtxBA9cf",
  "id" : 162022775186395136,
  "created_at" : "2012-01-25 04:03:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162021178578436096",
  "text" : "RT @AmbassadorRice: Finally, the President said that as our men & women in uniform come home, we have an obligation to serve them as wel ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162020538649296896",
    "text" : "Finally, the President said that as our men & women in uniform come home, we have an obligation to serve them as well as they served us.",
    "id" : 162020538649296896,
    "created_at" : "2012-01-25 03:54:41 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 162021178578436096,
  "created_at" : "2012-01-25 03:57:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 81, 92 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 58, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/3PkrwuOo",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "162020259770023936",
  "text" : "RT @WHLive: A panel of senior advisors are answering your #SOTU questions at the @WhiteHouse now. Watch live: http:\/\/t.co\/3PkrwuOo & ask ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 69, 80 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 46, 51 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/3PkrwuOo",
        "expanded_url" : "http:\/\/wh.gov\/sotu",
        "display_url" : "wh.gov\/sotu"
      } ]
    },
    "geo" : { },
    "id_str" : "162020171677048832",
    "text" : "A panel of senior advisors are answering your #SOTU questions at the @WhiteHouse now. Watch live: http:\/\/t.co\/3PkrwuOo & ask Qs: #WHChat",
    "id" : 162020171677048832,
    "created_at" : "2012-01-25 03:53:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162020259770023936,
  "created_at" : "2012-01-25 03:53:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 34, 45 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 57, 62 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/serwSEBV",
      "expanded_url" : "http:\/\/go.usa.gov\/Nby",
      "display_url" : "go.usa.gov\/Nby"
    } ]
  },
  "geo" : { },
  "id_str" : "162018636406591489",
  "text" : "RT @arneduncan: I'm headed to the @WhiteHouse to discuss #SOTU. Ask questions using #WHchat & watch http:\/\/t.co\/serwSEBV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 18, 29 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 41, 46 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/serwSEBV",
        "expanded_url" : "http:\/\/go.usa.gov\/Nby",
        "display_url" : "go.usa.gov\/Nby"
      } ]
    },
    "geo" : { },
    "id_str" : "162015509083197442",
    "text" : "I'm headed to the @WhiteHouse to discuss #SOTU. Ask questions using #WHchat & watch http:\/\/t.co\/serwSEBV",
    "id" : 162015509083197442,
    "created_at" : "2012-01-25 03:34:42 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 162018636406591489,
  "created_at" : "2012-01-25 03:47:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162018628793933824",
  "text" : "RT @NancyPelosi: Together, we can fulfill the promise of an America built to last. #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 66, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162016900275113985",
    "text" : "Together, we can fulfill the promise of an America built to last. #SOTU",
    "id" : 162016900275113985,
    "created_at" : "2012-01-25 03:40:13 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 162018628793933824,
  "created_at" : "2012-01-25 03:47:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 93, 101 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 77, 82 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162015705733140482",
  "text" : "RT @VP: POTUS is right, we need an America built to last. Join me to discuss #SOTU in my 1st @Twitter chat 1\/26, 1:30pm ET. Use #WHChat  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 85, 93 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 69, 74 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162014737461297152",
    "text" : "POTUS is right, we need an America built to last. Join me to discuss #SOTU in my 1st @Twitter chat 1\/26, 1:30pm ET. Use #WHChat to ask Qs-VP",
    "id" : 162014737461297152,
    "created_at" : "2012-01-25 03:31:38 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 162015705733140482,
  "created_at" : "2012-01-25 03:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/162013334261075968\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/dtgS2loC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj-WROXCEAE_hT7.jpg",
      "id_str" : "162013334265270273",
      "id" : 162013334265270273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj-WROXCEAE_hT7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dtgS2loC"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162013334261075968",
  "text" : "\"As long as we\u2019re joined in common purpose...the state of our union will always be strong\" -President Obama #SOTU http:\/\/t.co\/dtgS2loC",
  "id" : 162013334261075968,
  "created_at" : "2012-01-25 03:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schneiderman",
      "screen_name" : "AGSchneiderman",
      "indices" : [ 3, 18 ],
      "id_str" : "132496568",
      "id" : 132496568
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 40, 51 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 52, 67 ],
      "id_str" : "73181712",
      "id" : 73181712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162011996957577216",
  "text" : "RT @AGSchneiderman: Would like to thank @whitehouse @TheJusticeDept for creating a joint investigation to bring justice for victims of t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 20, 31 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Justice Department",
        "screen_name" : "TheJusticeDept",
        "indices" : [ 32, 47 ],
        "id_str" : "73181712",
        "id" : 73181712
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162005479919321091",
    "text" : "Would like to thank @whitehouse @TheJusticeDept for creating a joint investigation to bring justice for victims of the mortgage crisis #SOTU",
    "id" : 162005479919321091,
    "created_at" : "2012-01-25 02:54:50 +0000",
    "user" : {
      "name" : "Eric Schneiderman",
      "screen_name" : "AGSchneiderman",
      "protected" : false,
      "id_str" : "132496568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738740865707868161\/gzD4g6BB_normal.jpg",
      "id" : 132496568,
      "verified" : true
    }
  },
  "id" : 162011996957577216,
  "created_at" : "2012-01-25 03:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/1LOT5ayj",
      "expanded_url" : "http:\/\/www.wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "162011248022663169",
  "text" : "President Obama's State of the Union just concluded. Watch a live panel with WH officials  now: http:\/\/t.co\/1LOT5ayj Ask Qs with #WHChat",
  "id" : 162011248022663169,
  "created_at" : "2012-01-25 03:17:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162010830752321539",
  "text" : "Obama: As long as we\u2019re joined in common purpose...our future is hopeful & the state of our union will always be strong #SOTU",
  "id" : 162010830752321539,
  "created_at" : "2012-01-25 03:16:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162010765300219904",
  "text" : "Obama: This nation is great because we built it together. This nation is great because we worked as a team. #SOTU",
  "id" : 162010765300219904,
  "created_at" : "2012-01-25 03:15:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162010241502949376",
  "text" : "RT @WHLive: Obama: When you\u2019re in the thick of the fight, you rise or fall as one unit, serving one nation, leaving no one behind. #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 119, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162010189065752576",
    "text" : "Obama: When you\u2019re in the thick of the fight, you rise or fall as one unit, serving one nation, leaving no one behind. #SOTU",
    "id" : 162010189065752576,
    "created_at" : "2012-01-25 03:13:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162010241502949376,
  "created_at" : "2012-01-25 03:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 115, 120 ]
    }, {
      "text" : "veterans",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162009897012178945",
  "text" : "RT @JoiningForces: Obama: Michelle & Jill Biden have worked with American businesses to secure a pledge of 135,000 #jobs for #veterans & ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "veterans",
        "indices" : [ 106, 115 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162009840246472707",
    "text" : "Obama: Michelle & Jill Biden have worked with American businesses to secure a pledge of 135,000 #jobs for #veterans & their families. #SOTU",
    "id" : 162009840246472707,
    "created_at" : "2012-01-25 03:12:10 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 162009897012178945,
  "created_at" : "2012-01-25 03:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162009584859496449",
  "text" : "Obama: Above all, our freedom endures because of the men and women in uniform who defend it. #SOTU",
  "id" : 162009584859496449,
  "created_at" : "2012-01-25 03:11:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162009331288637441",
  "text" : "Obama: America remains the one indispensable nation in world affairs & as long as I\u2019m President, I intend to keep it that way. #SOTU",
  "id" : 162009331288637441,
  "created_at" : "2012-01-25 03:10:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/162009034407428096\/photo\/1",
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/nMwX3v5S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj-SW8KCQAML7dG.jpg",
      "id_str" : "162009034411622403",
      "id" : 162009034411622403,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj-SW8KCQAML7dG.jpg",
      "sizes" : [ {
        "h" : 492,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/nMwX3v5S"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162009034407428096",
  "text" : "Obama: The renewal of American leadership can be felt across the globe. #SOTU http:\/\/t.co\/nMwX3v5S",
  "id" : 162009034407428096,
  "created_at" : "2012-01-25 03:08:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162008856623460353",
  "text" : "RT @WHLive: Obama: America is determined to prevent Iran from getting a nuclear weapon & I will take no options off the table to achieve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162008815242452993",
    "text" : "Obama: America is determined to prevent Iran from getting a nuclear weapon & I will take no options off the table to achieve that goal #SOTU",
    "id" : 162008815242452993,
    "created_at" : "2012-01-25 03:08:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162008856623460353,
  "created_at" : "2012-01-25 03:08:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162008593858695168",
  "text" : "RT @WHLive: Obama: We will stand against violence & intimidation. We will stand for the rights & dignity of all human beings #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 113, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162008558936928256",
    "text" : "Obama: We will stand against violence & intimidation. We will stand for the rights & dignity of all human beings #SOTU",
    "id" : 162008558936928256,
    "created_at" : "2012-01-25 03:07:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162008593858695168,
  "created_at" : "2012-01-25 03:07:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162008088893857795",
  "text" : "RT @WHLive: Obama: I can do a whole lot more with your help. Because when we act together, there is nothing the USA can\u2019t achieve. #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 119, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162008058971688961",
    "text" : "Obama: I can do a whole lot more with your help. Because when we act together, there is nothing the USA can\u2019t achieve. #SOTU",
    "id" : 162008058971688961,
    "created_at" : "2012-01-25 03:05:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162008088893857795,
  "created_at" : "2012-01-25 03:05:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162007881925926912",
  "text" : "RT @WHLive: Obama: With or without this Congress, I will keep taking actions that help the economy grow. #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 93, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162007852230262785",
    "text" : "Obama: With or without this Congress, I will keep taking actions that help the economy grow. #SOTU",
    "id" : 162007852230262785,
    "created_at" : "2012-01-25 03:04:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162007881925926912,
  "created_at" : "2012-01-25 03:04:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162007613066850305",
  "text" : "Obama: I believe what Repub...Lincoln believed...gov't should do for people only what they cannot do better by themselves & no more #SOTU",
  "id" : 162007613066850305,
  "created_at" : "2012-01-25 03:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162006886370127872",
  "text" : "Obama: I bet most Americans are thinking the same thing right now...nothing will get done ...because Washington is broken. #SOTU",
  "id" : 162006886370127872,
  "created_at" : "2012-01-25 03:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162006190019198976",
  "text" : "Obama: if you make under $250,000 a year, like 98% of American families, your taxes shouldn\u2019t go up...You\u2019re the ones who need relief #SOTU",
  "id" : 162006190019198976,
  "created_at" : "2012-01-25 02:57:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162005983453921281",
  "text" : "RT @WHLive: Obama: we need to change our tax code so that people like me & an awful lot of Members of Congress, pay our fair share of ta ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 128, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162005948397916160",
    "text" : "Obama: we need to change our tax code so that people like me & an awful lot of Members of Congress, pay our fair share of taxes #SOTU",
    "id" : 162005948397916160,
    "created_at" : "2012-01-25 02:56:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162005983453921281,
  "created_at" : "2012-01-25 02:56:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162005816117964800",
  "text" : "Obama: Do we want to keep these tax cuts for the wealthiest Americans?  Or do we want to keep our investments in everything else #SOTU",
  "id" : 162005816117964800,
  "created_at" : "2012-01-25 02:56:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "40dollars",
      "indices" : [ 47, 57 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162005452979310593",
  "text" : "RT @WHLive: Obama: People cannot afford losing #40dollars out of each paycheck this year...Pass the payroll tax cut without delay #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "40dollars",
        "indices" : [ 35, 45 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 118, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162005410155479040",
    "text" : "Obama: People cannot afford losing #40dollars out of each paycheck this year...Pass the payroll tax cut without delay #SOTU",
    "id" : 162005410155479040,
    "created_at" : "2012-01-25 02:54:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162005452979310593,
  "created_at" : "2012-01-25 02:54:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162005313816506371",
  "text" : "Obama: Our most immediate priority is stopping a tax hike on 160 million working Americans while the recovery is still fragile #SOTU",
  "id" : 162005313816506371,
  "created_at" : "2012-01-25 02:54:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "values",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "sotu",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162005234061811712",
  "text" : "Obama: A return to the American #values of fair play & shared responsibility will help protect our people & our economy.  #sotu",
  "id" : 162005234061811712,
  "created_at" : "2012-01-25 02:53:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162004975130652672",
  "text" : "RT @WHLive: Obama: Today, American consumers finally have a watchdog in Richard Cordray with one job: to look out for them. #sotu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sotu",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162004933934190592",
    "text" : "Obama: Today, American consumers finally have a watchdog in Richard Cordray with one job: to look out for them. #sotu",
    "id" : 162004933934190592,
    "created_at" : "2012-01-25 02:52:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162004975130652672,
  "created_at" : "2012-01-25 02:52:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162004687548198913",
  "text" : "RT @WHLive: Obama: I will not go back to the days when health insurance companies had unchecked power to cancel your policy, deny you co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sotu",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162004649551998977",
    "text" : "Obama: I will not go back to the days when health insurance companies had unchecked power to cancel your policy, deny you coverage #sotu",
    "id" : 162004649551998977,
    "created_at" : "2012-01-25 02:51:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162004687548198913,
  "created_at" : "2012-01-25 02:51:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/162004286493032448\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/FGWgjlO1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj-OCkzCAAI-KXm.jpg",
      "id_str" : "162004286497226754",
      "id" : 162004286497226754,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj-OCkzCAAI-KXm.jpg",
      "sizes" : [ {
        "h" : 492,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/FGWgjlO1"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162004286493032448",
  "text" : "\"Worth crying over spilled milk\" -Obama on outdated regulation that classified milk as oil & cost farmers 10k\/yr #SOTU http:\/\/t.co\/FGWgjlO1",
  "id" : 162004286493032448,
  "created_at" : "2012-01-25 02:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162003866353795073",
  "text" : "RT @WHLive: Obama: Millions of Americans who work hard & play by the rules every day deserve a government & a financial system that does ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162003814268928001",
    "text" : "Obama: Millions of Americans who work hard & play by the rules every day deserve a government & a financial system that does the same #SOTU",
    "id" : 162003814268928001,
    "created_at" : "2012-01-25 02:48:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162003866353795073,
  "created_at" : "2012-01-25 02:48:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 19, 33 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162002990029479936",
  "text" : "RT @WHLive: Obama: @deptofdefense, the world\u2019s largest consumer of #energy, will make one of the largest commitments to clean energy in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Dept of Defense",
        "screen_name" : "DeptofDefense",
        "indices" : [ 7, 21 ],
        "id_str" : "66369181",
        "id" : 66369181
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162002928230612992",
    "text" : "Obama: @deptofdefense, the world\u2019s largest consumer of #energy, will make one of the largest commitments to clean energy in history #SOTU",
    "id" : 162002928230612992,
    "created_at" : "2012-01-25 02:44:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162002990029479936,
  "created_at" : "2012-01-25 02:44:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "energy",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162002527896879104",
  "text" : "RT @WHLive: Obama at #sotu: I will not walk away from the promise of clean #energy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sotu",
        "indices" : [ 9, 14 ]
      }, {
        "text" : "energy",
        "indices" : [ 63, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162002473463197696",
    "text" : "Obama at #sotu: I will not walk away from the promise of clean #energy.",
    "id" : 162002473463197696,
    "created_at" : "2012-01-25 02:42:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162002527896879104,
  "created_at" : "2012-01-25 02:43:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162001752877568001",
  "text" : "RT @WHLive: Obama: This country needs an all-out, all-of-the-above strategy that develops every available source of American #energy. #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 113, 120 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 122, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162001699681214464",
    "text" : "Obama: This country needs an all-out, all-of-the-above strategy that develops every available source of American #energy. #SOTU",
    "id" : 162001699681214464,
    "created_at" : "2012-01-25 02:39:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162001752877568001,
  "created_at" : "2012-01-25 02:40:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/162001449260302336\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/D0GkbJdz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj-LdbSCQAA7KKx.jpg",
      "id_str" : "162001449264496640",
      "id" : 162001449264496640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj-LdbSCQAA7KKx.jpg",
      "sizes" : [ {
        "h" : 492,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/D0GkbJdz"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162001449260302336",
  "text" : "Obama: we should support...every risk-taker & entrepreneur who aspires to become the next Steve Jobs. #SOTU http:\/\/t.co\/D0GkbJdz",
  "id" : 162001449260302336,
  "created_at" : "2012-01-25 02:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162001085249241089",
  "text" : "RT @WHLive: Obama: You see, an economy built to last is one where we encourage the talent & ingenuity of every person in this country  #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 123, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162001039350964224",
    "text" : "Obama: You see, an economy built to last is one where we encourage the talent & ingenuity of every person in this country  #SOTU",
    "id" : 162001039350964224,
    "created_at" : "2012-01-25 02:37:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162001085249241089,
  "created_at" : "2012-01-25 02:37:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 57, 69 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162000758932377600",
  "text" : "RT @WHLive: Obama: We should be working on comprehensive #immigration reform right now. #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 45, 57 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 76, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162000718717390848",
    "text" : "Obama: We should be working on comprehensive #immigration reform right now. #SOTU",
    "id" : 162000718717390848,
    "created_at" : "2012-01-25 02:35:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 162000758932377600,
  "created_at" : "2012-01-25 02:36:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161999340284551168",
  "text" : "RT @WHLive: Obama: It\u2019s time to turn our unemployment system into a reemployment system that puts people to work #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 101, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161999242834092033",
    "text" : "Obama: It\u2019s time to turn our unemployment system into a reemployment system that puts people to work #SOTU",
    "id" : 161999242834092033,
    "created_at" : "2012-01-25 02:30:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 161999340284551168,
  "created_at" : "2012-01-25 02:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161998629928841216",
  "text" : "Obama: Our workers are the most productive on Earth & if the playing field is level, I promise you \u2013 America will always win #SOTU",
  "id" : 161998629928841216,
  "created_at" : "2012-01-25 02:27:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161998521208291328",
  "text" : "Obama: Tonight, I\u2019m announcing the creation of a Trade Enforcement Unit that will be charged w\/ investigating unfair trade practices #SOTU",
  "id" : 161998521208291328,
  "created_at" : "2012-01-25 02:27:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 98, 103 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161998132249497600",
  "text" : "Obama: Tonight, my message to business leaders is simple: ask yourselves what you can do to bring #jobs back to your country #SOTU",
  "id" : 161998132249497600,
  "created_at" : "2012-01-25 02:25:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161997865277849602",
  "text" : "Obama: We bet on American workers. We bet on American ingenuity & tonight, the American auto industry is back #SOTU",
  "id" : 161997865277849602,
  "created_at" : "2012-01-25 02:24:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161997796344463360",
  "text" : "Obama: Tonight, I want to speak about how we move forward & lay out a blueprint for an economy that\u2019s built to last #sotu",
  "id" : 161997796344463360,
  "created_at" : "2012-01-25 02:24:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161997761212989440",
  "text" : "\"American manufacturers are hiring again\" -President Obama #sotu",
  "id" : 161997761212989440,
  "created_at" : "2012-01-25 02:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161996380984971264",
  "text" : "Obama: In the last 22 months, businesses have created more than three million #jobs. #SOTU",
  "id" : 161996380984971264,
  "created_at" : "2012-01-25 02:18:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161995915807297536",
  "text" : "Obama: What\u2019s at stake are not Democratic values or Republican values, but American values. We have to reclaim them #SOTU",
  "id" : 161995915807297536,
  "created_at" : "2012-01-25 02:16:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161995347571380225",
  "text" : "Obama: Think about the America within our reach...An economy built to last, where hard work pays off & responsibility is rewarded #SOTU",
  "id" : 161995347571380225,
  "created_at" : "2012-01-25 02:14:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/161994976543248385\/photo\/1",
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/wD1abq1H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj-FkqiCEAEtMz8.jpg",
      "id_str" : "161994976547442689",
      "id" : 161994976547442689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj-FkqiCEAEtMz8.jpg",
      "sizes" : [ {
        "h" : 492,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/wD1abq1H"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161994976543248385",
  "text" : "Obama: For the first time in two decades, Osama bin Laden is not a threat to this country. #SOTU http:\/\/t.co\/wD1abq1H",
  "id" : 161994976543248385,
  "created_at" : "2012-01-25 02:13:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161994786654527488",
  "text" : "RT @WHLive: Obama: We gather tonight knowing that this generation of heroes has made the United States safer & more respected around the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161994734599024641",
    "text" : "Obama: We gather tonight knowing that this generation of heroes has made the United States safer & more respected around the world. #SOTU",
    "id" : 161994734599024641,
    "created_at" : "2012-01-25 02:12:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 161994786654527488,
  "created_at" : "2012-01-25 02:12:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "161993790545080325",
  "text" : "Happening now: President Obama delivers his State of the Union Address. Watch the enhanced speech live: http:\/\/t.co\/Cq1szOIA",
  "id" : 161993790545080325,
  "created_at" : "2012-01-25 02:08:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 114, 121 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "161990377237262336",
  "text" : "Just 5 minutes until President Obama delivers his State of the Union Address. Watch: http:\/\/t.co\/Cq1szOIA Follow: @WHLive Discuss: #SOTU",
  "id" : 161990377237262336,
  "created_at" : "2012-01-25 01:54:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/KmjW8B0R",
      "expanded_url" : "http:\/\/wh.gov\/K8V",
      "display_url" : "wh.gov\/K8V"
    } ]
  },
  "geo" : { },
  "id_str" : "161989775493038082",
  "text" : "RT @arneduncan: Happy to see a teacher & student in the First Lady's box. http:\/\/t.co\/KmjW8B0R #SOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 79, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/KmjW8B0R",
        "expanded_url" : "http:\/\/wh.gov\/K8V",
        "display_url" : "wh.gov\/K8V"
      } ]
    },
    "geo" : { },
    "id_str" : "161988568716292096",
    "text" : "Happy to see a teacher & student in the First Lady's box. http:\/\/t.co\/KmjW8B0R #SOTU",
    "id" : 161988568716292096,
    "created_at" : "2012-01-25 01:47:39 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 161989775493038082,
  "created_at" : "2012-01-25 01:52:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65707359",
      "id" : 65707359
    }, {
      "name" : "Michelle Obama",
      "screen_name" : "MichelleObama",
      "indices" : [ 77, 91 ],
      "id_str" : "409486555",
      "id" : 409486555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161989757004558336",
  "text" : "RT @ShuttleCDRKelly: Thankful to be watching tonight\u2019s #SOTU address next to @MichelleObama. Gabby's attendance will be a proud moment f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michelle Obama",
        "screen_name" : "MichelleObama",
        "indices" : [ 56, 70 ],
        "id_str" : "409486555",
        "id" : 409486555
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 34, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161987416008310785",
    "text" : "Thankful to be watching tonight\u2019s #SOTU address next to @MichelleObama. Gabby's attendance will be a proud moment for all of us.",
    "id" : 161987416008310785,
    "created_at" : "2012-01-25 01:43:04 +0000",
    "user" : {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "protected" : false,
      "id_str" : "65707359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738724057177325568\/QrZIaw99_normal.jpg",
      "id" : 65707359,
      "verified" : true
    }
  },
  "id" : 161989757004558336,
  "created_at" : "2012-01-25 01:52:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 3, 15 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161987739435278336",
  "text" : "RT @CommerceSec: On my way to Capitol Hill for the #SOTU. Excited about the President's vision for America, especially helping #manufact ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 34, 39 ]
      }, {
        "text" : "manufacturing",
        "indices" : [ 110, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161977860230356993",
    "text" : "On my way to Capitol Hill for the #SOTU. Excited about the President's vision for America, especially helping #manufacturing",
    "id" : 161977860230356993,
    "created_at" : "2012-01-25 01:05:05 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 161987739435278336,
  "created_at" : "2012-01-25 01:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "161982226358210561",
  "text" : "#SOTU excerpt: \"An America built to last insists on responsibility from everybody\" Watch live @ 9ET: http:\/\/t.co\/Cq1szOIA",
  "id" : 161982226358210561,
  "created_at" : "2012-01-25 01:22:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161977868828688385",
  "text" : "#SOTU excerpt: \"Think about the America within our reach...An economy built to last, where hard work pays off & responsibility is rewarded\"",
  "id" : 161977868828688385,
  "created_at" : "2012-01-25 01:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 87, 98 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "161969456619327488",
  "text" : "If you're not @ http:\/\/t.co\/Cq1szOIA, you're missing some really great videos from the @WhiteHouse archives playing ahead of the speech",
  "id" : 161969456619327488,
  "created_at" : "2012-01-25 00:31:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jylesB",
      "screen_name" : "jylesB",
      "indices" : [ 3, 10 ],
      "id_str" : "15665118",
      "id" : 15665118
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUS",
      "indices" : [ 12, 18 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/zoFEKoJm",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/state-of-the-union-2012",
      "display_url" : "whitehouse.gov\/state-of-the-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161962213505114113",
  "text" : "RT @jylesB: #POTUS bringing the funny on the #SOTU site RIGHT NOW: http:\/\/t.co\/zoFEKoJm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUS",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 33, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/zoFEKoJm",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/state-of-the-union-2012",
        "display_url" : "whitehouse.gov\/state-of-the-u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "161961795429470210",
    "text" : "#POTUS bringing the funny on the #SOTU site RIGHT NOW: http:\/\/t.co\/zoFEKoJm",
    "id" : 161961795429470210,
    "created_at" : "2012-01-25 00:01:15 +0000",
    "user" : {
      "name" : "jylesB",
      "screen_name" : "jylesB",
      "protected" : false,
      "id_str" : "15665118",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1387722616\/476px-Ezekial_normal.png",
      "id" : 15665118,
      "verified" : false
    }
  },
  "id" : 161962213505114113,
  "created_at" : "2012-01-25 00:02:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darren Ashton",
      "screen_name" : "DarrenJAshton",
      "indices" : [ 0, 14 ],
      "id_str" : "765424020",
      "id" : 765424020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "in_reply_to_status_id_str" : "161956428473581568",
  "geo" : { },
  "id_str" : "161957122224037888",
  "in_reply_to_user_id" : 258080679,
  "text" : "@darrenjashton yes - video, remarks and more will be posted to http:\/\/t.co\/Cq1szOIA later tonight",
  "id" : 161957122224037888,
  "in_reply_to_status_id" : 161956428473581568,
  "created_at" : "2012-01-24 23:42:41 +0000",
  "in_reply_to_screen_name" : "DarrenAJ_",
  "in_reply_to_user_id_str" : "258080679",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/zJhElWD2",
      "expanded_url" : "http:\/\/wh.gov\/K8V",
      "display_url" : "wh.gov\/K8V"
    } ]
  },
  "geo" : { },
  "id_str" : "161956878098759680",
  "text" : "Who's in the First Lady\u2019s box at the State of the Union? Find out in this interactive feature: http:\/\/t.co\/zJhElWD2 #SOTU",
  "id" : 161956878098759680,
  "created_at" : "2012-01-24 23:41:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 6, 11 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "161943242361933824",
  "text" : "After #SOTU, a panel of WH senior advisors will answer your Qs about the speech. Ask now: #WHChat Tune in: http:\/\/t.co\/Cq1szOIA",
  "id" : 161943242361933824,
  "created_at" : "2012-01-24 22:47:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BlueJersey",
      "screen_name" : "bluejersey",
      "indices" : [ 3, 14 ],
      "id_str" : "14727040",
      "id" : 14727040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhiteHouse",
      "indices" : [ 39, 50 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 100, 105 ]
    }, {
      "text" : "WH",
      "indices" : [ 106, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/8wbQ5Mhu",
      "expanded_url" : "http:\/\/1.usa.gov\/wPPxOF",
      "display_url" : "1.usa.gov\/wPPxOF"
    } ]
  },
  "geo" : { },
  "id_str" : "161939934469554178",
  "text" : "RT @bluejersey: Want to test drive new #WhiteHouse social media tools tonight? http:\/\/t.co\/8wbQ5Mhu #SOTU #WH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhiteHouse",
        "indices" : [ 23, 34 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 84, 89 ]
      }, {
        "text" : "WH",
        "indices" : [ 90, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/8wbQ5Mhu",
        "expanded_url" : "http:\/\/1.usa.gov\/wPPxOF",
        "display_url" : "1.usa.gov\/wPPxOF"
      } ]
    },
    "geo" : { },
    "id_str" : "161937062705106945",
    "text" : "Want to test drive new #WhiteHouse social media tools tonight? http:\/\/t.co\/8wbQ5Mhu #SOTU #WH",
    "id" : 161937062705106945,
    "created_at" : "2012-01-24 22:22:59 +0000",
    "user" : {
      "name" : "BlueJersey",
      "screen_name" : "bluejersey",
      "protected" : false,
      "id_str" : "14727040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1787359140\/Screen_shot_2012-01-28_at_10.19.28_AM_normal.png",
      "id" : 14727040,
      "verified" : false
    }
  },
  "id" : 161939934469554178,
  "created_at" : "2012-01-24 22:34:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent Pliskow",
      "screen_name" : "bpliskow",
      "indices" : [ 3, 12 ],
      "id_str" : "97792247",
      "id" : 97792247
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    }, {
      "text" : "WHTweetup",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161923387084636161",
  "text" : "RT @bpliskow: Amazing how we've spread out across DC for a quick break and are all still tweeting about the #SOTU #WHTweetup The excitem ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 94, 99 ]
      }, {
        "text" : "WHTweetup",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161922426618380288",
    "text" : "Amazing how we've spread out across DC for a quick break and are all still tweeting about the #SOTU #WHTweetup The excitement is palpable!",
    "id" : 161922426618380288,
    "created_at" : "2012-01-24 21:24:49 +0000",
    "user" : {
      "name" : "Brent Pliskow",
      "screen_name" : "bpliskow",
      "protected" : false,
      "id_str" : "97792247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527191290832633856\/OrwCZPwF_normal.jpeg",
      "id" : 97792247,
      "verified" : false
    }
  },
  "id" : 161923387084636161,
  "created_at" : "2012-01-24 21:28:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "JulianCastro",
      "indices" : [ 3, 16 ],
      "id_str" : "19682187",
      "id" : 19682187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161891146216386560",
  "text" : "RT @JulianCastro: I am honored to represent San Antonio as a guest in the First Lady's Box for this evening's State of the Union address.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161889784946630656",
    "text" : "I am honored to represent San Antonio as a guest in the First Lady's Box for this evening's State of the Union address.",
    "id" : 161889784946630656,
    "created_at" : "2012-01-24 19:15:07 +0000",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "JulianCastro",
      "protected" : false,
      "id_str" : "19682187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000807517354\/8ff478717e74b32301e08ec553df942d_normal.jpeg",
      "id" : 19682187,
      "verified" : true
    }
  },
  "id" : 161891146216386560,
  "created_at" : "2012-01-24 19:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/NIvsk9vq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=FxwcJx0-21E",
      "display_url" : "youtube.com\/watch?v=FxwcJx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161870607657615360",
  "text" : "Want a peek behind the scenes of the #SOTU? Here's the story of how it comes together http:\/\/t.co\/NIvsk9vq",
  "id" : 161870607657615360,
  "created_at" : "2012-01-24 17:58:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/yUN6m4xQ",
      "expanded_url" : "http:\/\/youtu.be\/fSEp77-NKE8",
      "display_url" : "youtu.be\/fSEp77-NKE8"
    } ]
  },
  "geo" : { },
  "id_str" : "161832639702114308",
  "text" : "\"We can't wait for Congress to do its job. So where they won't act, I will.\" -President Obama. Watch: http:\/\/t.co\/yUN6m4xQ",
  "id" : 161832639702114308,
  "created_at" : "2012-01-24 15:28:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "161818607188312067",
  "text" : "Tonight, President Obama will lay out a blueprint for an economy that\u2019s built to last. Watch live @ 9ET http:\/\/t.co\/Cq1szOIA #SOTU",
  "id" : 161818607188312067,
  "created_at" : "2012-01-24 14:32:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161813600447631360",
  "text" : "RT @pfeiffer44: Tonight President Obama will offer more details on the Buffett Rule and Buffett's secretary, Debbie Bosanek, will be in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161811801120579584",
    "text" : "Tonight President Obama will offer more details on the Buffett Rule and Buffett's secretary, Debbie Bosanek, will be in the First Lady's Box",
    "id" : 161811801120579584,
    "created_at" : "2012-01-24 14:05:14 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 161813600447631360,
  "created_at" : "2012-01-24 14:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "161691199260991488",
  "text" : "Watch the enhanced version of the State of the Union featuring graphics, data & stats. Only on http:\/\/t.co\/Cq1szOIA on Tues 1\/24 @ 9ET #SOTU",
  "id" : 161691199260991488,
  "created_at" : "2012-01-24 06:06:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "WHTweetup",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161662222488186880",
  "text" : "RT @ks44: Tomorrow's #SOTU #WHTweetup attendees represent 22 states + DC & range in age from 18 to 62. Looking forward to meeting you!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "WHTweetup",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161662144029528064",
    "text" : "Tomorrow's #SOTU #WHTweetup attendees represent 22 states + DC & range in age from 18 to 62. Looking forward to meeting you!",
    "id" : 161662144029528064,
    "created_at" : "2012-01-24 04:10:33 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 161662222488186880,
  "created_at" : "2012-01-24 04:10:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Bruins",
      "screen_name" : "NHLBruins",
      "indices" : [ 75, 85 ],
      "id_str" : "44166798",
      "id" : 44166798
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/161658228235710464\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/L5lh8ne9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj5TTVWCMAAXTps.jpg",
      "id_str" : "161658228244099072",
      "id" : 161658228244099072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj5TTVWCMAAXTps.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/L5lh8ne9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/UIfQpUiE",
      "expanded_url" : "http:\/\/wh.gov\/KDX",
      "display_url" : "wh.gov\/KDX"
    } ]
  },
  "geo" : { },
  "id_str" : "161658228235710464",
  "text" : "\"I know you are all wicked happy to be here\" -President Obama welcomes the @NHLBruins to the WH: http:\/\/t.co\/UIfQpUiE http:\/\/t.co\/L5lh8ne9",
  "id" : 161658228235710464,
  "created_at" : "2012-01-24 03:55:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/161634340399362048\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/I4FoaFlL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj49k4NCMAA1ppY.jpg",
      "id_str" : "161634340403556352",
      "id" : 161634340403556352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj49k4NCMAA1ppY.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/I4FoaFlL"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/Cq1szOIA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "161634340399362048",
  "text" : "Photo of the Day: President Obama talks #SOTU w\/ Speechwriting Director Jon Favreau in the Oval http:\/\/t.co\/Cq1szOIA: http:\/\/t.co\/I4FoaFlL",
  "id" : 161634340399362048,
  "created_at" : "2012-01-24 02:20:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 3, 9 ],
      "id_str" : "33696409",
      "id" : 33696409
    }, {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 43, 49 ],
      "id_str" : "33696409",
      "id" : 33696409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161611143633313792",
  "text" : "RT @Quora: Watch the State of the Union on @Quora & ask the White House your questions which will be answered in the coming days. http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quora",
        "screen_name" : "Quora",
        "indices" : [ 32, 38 ],
        "id_str" : "33696409",
        "id" : 33696409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/sXNPaB9Q",
        "expanded_url" : "http:\/\/qr.ae\/7QPRK",
        "display_url" : "qr.ae\/7QPRK"
      } ]
    },
    "geo" : { },
    "id_str" : "161598331649409025",
    "text" : "Watch the State of the Union on @Quora & ask the White House your questions which will be answered in the coming days. http:\/\/t.co\/sXNPaB9Q",
    "id" : 161598331649409025,
    "created_at" : "2012-01-23 23:56:59 +0000",
    "user" : {
      "name" : "Quora",
      "screen_name" : "Quora",
      "protected" : false,
      "id_str" : "33696409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615648367943651328\/51pM5n5v_normal.png",
      "id" : 33696409,
      "verified" : true
    }
  },
  "id" : 161611143633313792,
  "created_at" : "2012-01-24 00:47:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/yUN6m4xQ",
      "expanded_url" : "http:\/\/youtu.be\/fSEp77-NKE8",
      "display_url" : "youtu.be\/fSEp77-NKE8"
    } ]
  },
  "geo" : { },
  "id_str" : "161538244180316161",
  "text" : "We can't wait for Congress to act. Since October, Obama has taken 19 actions to support the middle class & create #jobs http:\/\/t.co\/yUN6m4xQ",
  "id" : 161538244180316161,
  "created_at" : "2012-01-23 19:58:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boston Bruins",
      "screen_name" : "NHLBruins",
      "indices" : [ 3, 13 ],
      "id_str" : "44166798",
      "id" : 44166798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161520433743667200",
  "text" : "RT @NHLBruins: President Obama said he's happy to welcome the Stanley Cup Champions to the White House. \"Wicked happy to be here...\"^BISH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161520100808208386",
    "text" : "President Obama said he's happy to welcome the Stanley Cup Champions to the White House. \"Wicked happy to be here...\"^BISH",
    "id" : 161520100808208386,
    "created_at" : "2012-01-23 18:46:07 +0000",
    "user" : {
      "name" : "Boston Bruins",
      "screen_name" : "NHLBruins",
      "protected" : false,
      "id_str" : "44166798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797918634815483904\/ion3wlx6_normal.jpg",
      "id" : 44166798,
      "verified" : true
    }
  },
  "id" : 161520433743667200,
  "created_at" : "2012-01-23 18:47:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "161520040355700737",
  "text" : "Happening now: President Obama Honors the Six-time Stanley Cup Champion Boston Bruins: http:\/\/t.co\/QDIpMRKE",
  "id" : 161520040355700737,
  "created_at" : "2012-01-23 18:45:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 3, 17 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GabbyGiffords\/status\/161486731932213248\/photo\/1",
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/yww7gifk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj23U70CIAEoL9U.jpg",
      "id_str" : "161486731936407553",
      "id" : 161486731936407553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj23U70CIAEoL9U.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/yww7gifk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161502363801239552",
  "text" : "RT @GabbyGiffords: Rep. Giffords hugs Daniel Hernandez, the former intern who saved her life. http:\/\/t.co\/yww7gifk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GabbyGiffords\/status\/161486731932213248\/photo\/1",
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/yww7gifk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj23U70CIAEoL9U.jpg",
        "id_str" : "161486731936407553",
        "id" : 161486731936407553,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj23U70CIAEoL9U.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/yww7gifk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161486731932213248",
    "text" : "Rep. Giffords hugs Daniel Hernandez, the former intern who saved her life. http:\/\/t.co\/yww7gifk",
    "id" : 161486731932213248,
    "created_at" : "2012-01-23 16:33:32 +0000",
    "user" : {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "protected" : false,
      "id_str" : "44177383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738723616485978117\/G9V0XAhU_normal.jpg",
      "id" : 44177383,
      "verified" : true
    }
  },
  "id" : 161502363801239552,
  "created_at" : "2012-01-23 17:35:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/5NtQAzJ1",
      "expanded_url" : "http:\/\/wh.gov\/KY4",
      "display_url" : "wh.gov\/KY4"
    } ]
  },
  "geo" : { },
  "id_str" : "161446709828923392",
  "text" : "What is your question for President Obama? On Jan 30, the President answers in a special Google+ Hangout. Ask now: http:\/\/t.co\/5NtQAzJ1",
  "id" : 161446709828923392,
  "created_at" : "2012-01-23 13:54:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 1, 15 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/OVmP9eM9",
      "expanded_url" : "http:\/\/wh.gov\/Krg",
      "display_url" : "wh.gov\/Krg"
    } ]
  },
  "geo" : { },
  "id_str" : "161212927574147073",
  "text" : "\"@GabbyGiffords embodies the very best of what public service should be.\" -President Obama on Giffords' resignation: http:\/\/t.co\/OVmP9eM9",
  "id" : 161212927574147073,
  "created_at" : "2012-01-22 22:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 13, 21 ]
    }, {
      "text" : "awesome",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/InCwkvUj",
      "expanded_url" : "http:\/\/1.usa.gov\/AjhyiH",
      "display_url" : "1.usa.gov\/AjhyiH"
    } ]
  },
  "geo" : { },
  "id_str" : "161188612413726720",
  "text" : "RT @macon44: #visitUS: Americans share what makes their hometown a great place to visit http:\/\/t.co\/InCwkvUj #awesome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "awesome",
        "indices" : [ 96, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/InCwkvUj",
        "expanded_url" : "http:\/\/1.usa.gov\/AjhyiH",
        "display_url" : "1.usa.gov\/AjhyiH"
      } ]
    },
    "geo" : { },
    "id_str" : "161186345828618240",
    "text" : "#visitUS: Americans share what makes their hometown a great place to visit http:\/\/t.co\/InCwkvUj #awesome",
    "id" : 161186345828618240,
    "created_at" : "2012-01-22 20:39:54 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 161188612413726720,
  "created_at" : "2012-01-22 20:48:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/EKiKxPVw",
      "expanded_url" : "http:\/\/wh.gov\/KCs",
      "display_url" : "wh.gov\/KCs"
    } ]
  },
  "geo" : { },
  "id_str" : "161157348486942722",
  "text" : "\"I remain committed to protecting a woman\u2019s right to choose\" -President Obama on the 39th Anniversary of Roe v. Wade: http:\/\/t.co\/EKiKxPVw",
  "id" : 161157348486942722,
  "created_at" : "2012-01-22 18:44:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/mT1m8sMu",
      "expanded_url" : "http:\/\/ow.ly\/8Bp4s",
      "display_url" : "ow.ly\/8Bp4s"
    } ]
  },
  "geo" : { },
  "id_str" : "160715179305340928",
  "text" : "\"The more folks who visit America, the more Americans we get back to work. It\u2019s that simple\" -President Obama: http:\/\/t.co\/mT1m8sMu #visitUS",
  "id" : 160715179305340928,
  "created_at" : "2012-01-21 13:27:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/160543661950631936\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/wn0Stocj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjpdnCYCAAA5-2G.jpg",
      "id_str" : "160543661959020544",
      "id" : 160543661959020544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjpdnCYCAAA5-2G.jpg",
      "sizes" : [ {
        "h" : 1494,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 875,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1316
      } ],
      "display_url" : "pic.twitter.com\/wn0Stocj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160543661950631936",
  "text" : "Photo of the Day: President Obama talks on the phone w\/ Field Marshal Mohamed Hussein Tantawi of Egypt in the Oval: http:\/\/t.co\/wn0Stocj",
  "id" : 160543661950631936,
  "created_at" : "2012-01-21 02:06:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "MOAA Spouse",
      "screen_name" : "MOAA_MilLife",
      "indices" : [ 94, 107 ],
      "id_str" : "231841962",
      "id" : 231841962
    }, {
      "name" : "Blue Star Families",
      "screen_name" : "BlueStarFamily",
      "indices" : [ 108, 123 ],
      "id_str" : "15909372",
      "id" : 15909372
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 54, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/PWerzjnR",
      "expanded_url" : "http:\/\/ow.ly\/8B1iO",
      "display_url" : "ow.ly\/8B1iO"
    } ]
  },
  "geo" : { },
  "id_str" : "160538398245912576",
  "text" : "RT @JoiningForces: Helping military spouses find good #jobs in 2012: http:\/\/t.co\/PWerzjnR cc: @MOAA_MilLife @BlueStarFamily",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MOAA Spouse",
        "screen_name" : "MOAA_MilLife",
        "indices" : [ 75, 88 ],
        "id_str" : "231841962",
        "id" : 231841962
      }, {
        "name" : "Blue Star Families",
        "screen_name" : "BlueStarFamily",
        "indices" : [ 89, 104 ],
        "id_str" : "15909372",
        "id" : 15909372
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 35, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/PWerzjnR",
        "expanded_url" : "http:\/\/ow.ly\/8B1iO",
        "display_url" : "ow.ly\/8B1iO"
      } ]
    },
    "geo" : { },
    "id_str" : "160530223790702592",
    "text" : "Helping military spouses find good #jobs in 2012: http:\/\/t.co\/PWerzjnR cc: @MOAA_MilLife @BlueStarFamily",
    "id" : 160530223790702592,
    "created_at" : "2012-01-21 01:12:42 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 160538398245912576,
  "created_at" : "2012-01-21 01:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Orlando Sentinel",
      "screen_name" : "orlandosentinel",
      "indices" : [ 1, 17 ],
      "id_str" : "1429761",
      "id" : 1429761
    }, {
      "name" : "The Arizona Republic",
      "screen_name" : "arizonarepublic",
      "indices" : [ 18, 34 ],
      "id_str" : "166632958",
      "id" : 166632958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/x9NsTSLj",
      "expanded_url" : "http:\/\/ow.ly\/8B8fP",
      "display_url" : "ow.ly\/8B8fP"
    } ]
  },
  "geo" : { },
  "id_str" : "160510890289004544",
  "text" : ".@orlandosentinel @arizonarepublic & more media outlets react to Obama's plan to boost tourism & the economy: http:\/\/t.co\/x9NsTSLj #visitUS",
  "id" : 160510890289004544,
  "created_at" : "2012-01-20 23:55:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 1, 12 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 69, 77 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 84, 95 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WelcomeToTwitter",
      "indices" : [ 103, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160443579460878336",
  "text" : ".@WhiteHouse Principal Deputy Press Secretary Josh Earnest debuts on @twitter. Give @jearnest44 a warm #WelcomeToTwitter",
  "id" : 160443579460878336,
  "created_at" : "2012-01-20 19:28:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 17, 29 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160441442936946690",
  "text" : "RT @jearnest44: .@jesseclee44 warned me that you dont get a 2nd chance on your 1st Tweet - but I'm fired up and ready to take your #SOTU ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jesse Lee",
        "screen_name" : "jesseclee44",
        "indices" : [ 1, 13 ],
        "id_str" : "113436175",
        "id" : 113436175
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 115, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160440999578046465",
    "text" : ".@jesseclee44 warned me that you dont get a 2nd chance on your 1st Tweet - but I'm fired up and ready to take your #SOTU questions next week",
    "id" : 160440999578046465,
    "created_at" : "2012-01-20 19:18:09 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 160441442936946690,
  "created_at" : "2012-01-20 19:19:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/uEoJBJF1",
      "expanded_url" : "http:\/\/ow.ly\/8AEjK",
      "display_url" : "ow.ly\/8AEjK"
    }, {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/2GpwbrDk",
      "expanded_url" : "http:\/\/ow.ly\/8AEud",
      "display_url" : "ow.ly\/8AEud"
    } ]
  },
  "geo" : { },
  "id_str" : "160408798706671616",
  "text" : "#SOTU 2012: We want to hear from you: http:\/\/t.co\/uEoJBJF1 Watch Senior Advisor David Plouffe discuss: http:\/\/t.co\/2GpwbrDk",
  "id" : 160408798706671616,
  "created_at" : "2012-01-20 17:10:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160394908321071105",
  "text" : "RT @ks44: .@WhiteHouse is on Google+. WH Hangouts w\/ admin officials coming soon. Have ideas for our page? Join the discussion: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/RJBm7QJQ",
        "expanded_url" : "http:\/\/ow.ly\/8AyfZ",
        "display_url" : "ow.ly\/8AyfZ"
      } ]
    },
    "geo" : { },
    "id_str" : "160394621309034496",
    "text" : ".@WhiteHouse is on Google+. WH Hangouts w\/ admin officials coming soon. Have ideas for our page? Join the discussion: http:\/\/t.co\/RJBm7QJQ",
    "id" : 160394621309034496,
    "created_at" : "2012-01-20 16:13:52 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 160394908321071105,
  "created_at" : "2012-01-20 16:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 50, 61 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/ZmizdELl",
      "expanded_url" : "http:\/\/goo.gl\/KOizY",
      "display_url" : "goo.gl\/KOizY"
    } ]
  },
  "geo" : { },
  "id_str" : "160392754097176576",
  "text" : "We\u2019re excited to announce that you can now follow @WhiteHouse on Google+: http:\/\/t.co\/ZmizdELl",
  "id" : 160392754097176576,
  "created_at" : "2012-01-20 16:06:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/1Q6yv6O9",
      "expanded_url" : "http:\/\/on.doi.gov\/zLGeEp",
      "display_url" : "on.doi.gov\/zLGeEp"
    } ]
  },
  "geo" : { },
  "id_str" : "160385517773520897",
  "text" : "RT @Interior: Want to see some of the best public lands to #visitUS? Follow our new Tumblr photo blog here: http:\/\/t.co\/1Q6yv6O9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 45, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/1Q6yv6O9",
        "expanded_url" : "http:\/\/on.doi.gov\/zLGeEp",
        "display_url" : "on.doi.gov\/zLGeEp"
      } ]
    },
    "geo" : { },
    "id_str" : "160218916797419520",
    "text" : "Want to see some of the best public lands to #visitUS? Follow our new Tumblr photo blog here: http:\/\/t.co\/1Q6yv6O9",
    "id" : 160218916797419520,
    "created_at" : "2012-01-20 04:35:41 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 160385517773520897,
  "created_at" : "2012-01-20 15:37:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maritime Heritage MN",
      "screen_name" : "MaritimeMinn",
      "indices" : [ 3, 16 ],
      "id_str" : "95253777",
      "id" : 95253777
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "Minnesota",
      "indices" : [ 60, 70 ]
    }, {
      "text" : "MississippiRiver",
      "indices" : [ 104, 121 ]
    }, {
      "text" : "Aitkin",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160189485122981888",
  "text" : "RT @MaritimeMinn: @WhiteHouse #VisitUS Everyone must come 2 #Minnesota MN has source of America's River #MississippiRiver at #Aitkin htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "Minnesota",
        "indices" : [ 42, 52 ]
      }, {
        "text" : "MississippiRiver",
        "indices" : [ 86, 103 ]
      }, {
        "text" : "Aitkin",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/dM3ivnZm",
        "expanded_url" : "http:\/\/twitpic.com\/89c95a",
        "display_url" : "twitpic.com\/89c95a"
      } ]
    },
    "geo" : { },
    "id_str" : "160188726306283520",
    "in_reply_to_user_id" : 30313925,
    "text" : "@WhiteHouse #VisitUS Everyone must come 2 #Minnesota MN has source of America's River #MississippiRiver at #Aitkin http:\/\/t.co\/dM3ivnZm",
    "id" : 160188726306283520,
    "created_at" : "2012-01-20 02:35:43 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Maritime Heritage MN",
      "screen_name" : "MaritimeMinn",
      "protected" : false,
      "id_str" : "95253777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563641594\/MHMLogoWhBack_normal.jpeg",
      "id" : 95253777,
      "verified" : false
    }
  },
  "id" : 160189485122981888,
  "created_at" : "2012-01-20 02:38:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Lynn Smith",
      "screen_name" : "alswrite",
      "indices" : [ 3, 12 ],
      "id_str" : "165537211",
      "id" : 165537211
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MI",
      "indices" : [ 82, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160179302690848768",
  "text" : "RT @alswrite: @whitehouse So many things to love about my hometown of Birmingham, #MI. Mostly, the local shops and groups that feel like ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MI",
        "indices" : [ 68, 71 ]
      }, {
        "text" : "VisitUS",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160162509435842560",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse So many things to love about my hometown of Birmingham, #MI. Mostly, the local shops and groups that feel like family. #VisitUS",
    "id" : 160162509435842560,
    "created_at" : "2012-01-20 00:51:32 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Amy Lynn Smith",
      "screen_name" : "alswrite",
      "protected" : false,
      "id_str" : "165537211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649187658007117825\/mSKVtL4c_normal.jpg",
      "id" : 165537211,
      "verified" : false
    }
  },
  "id" : 160179302690848768,
  "created_at" : "2012-01-20 01:58:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/4SqcnXRF",
      "expanded_url" : "http:\/\/ow.ly\/8zSZh",
      "display_url" : "ow.ly\/8zSZh"
    } ]
  },
  "geo" : { },
  "id_str" : "160178436898439168",
  "text" : "Over 18,000 people share their ideas for putting Americans back to work. We respond: http:\/\/t.co\/4SqcnXRF",
  "id" : 160178436898439168,
  "created_at" : "2012-01-20 01:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lu",
      "screen_name" : "ChrisLu44",
      "indices" : [ 3, 13 ],
      "id_str" : "461697741",
      "id" : 461697741
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LunarNewYear",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/zdPM0QOf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kd7tbOVJKZg&feature=youtube_gdata_player",
      "display_url" : "youtube.com\/watch?v=kd7tbO\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "160172421121445888",
  "text" : "RT @ChrisLu44: POTUS ushers in Year of the Dragon \nhttp:\/\/t.co\/zdPM0QOf #LunarNewYear",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LunarNewYear",
        "indices" : [ 57, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/zdPM0QOf",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kd7tbOVJKZg&feature=youtube_gdata_player",
        "display_url" : "youtube.com\/watch?v=kd7tbO\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "160165965961768960",
    "text" : "POTUS ushers in Year of the Dragon \nhttp:\/\/t.co\/zdPM0QOf #LunarNewYear",
    "id" : 160165965961768960,
    "created_at" : "2012-01-20 01:05:16 +0000",
    "user" : {
      "name" : "Chris Lu",
      "screen_name" : "ChrisLu44",
      "protected" : false,
      "id_str" : "461697741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739167604514934784\/as9mVLOb_normal.jpg",
      "id" : 461697741,
      "verified" : true
    }
  },
  "id" : 160172421121445888,
  "created_at" : "2012-01-20 01:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cammie Croft",
      "screen_name" : "cammiecroft",
      "indices" : [ 3, 15 ],
      "id_str" : "4227211",
      "id" : 4227211
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/cammiecroft\/status\/160135245113470976\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/hbN8ZXVh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjqKDFCMAAuJk9.jpg",
      "id_str" : "160135245117665280",
      "id" : 160135245117665280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjqKDFCMAAuJk9.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hbN8ZXVh"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160153604685180929",
  "text" : "RT @cammiecroft: Dear @whitehouse my hometown of Altoona is a great place to visit because of this #visitUS http:\/\/t.co\/hbN8ZXVh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 5, 16 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cammiecroft\/status\/160135245113470976\/photo\/1",
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/hbN8ZXVh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjqKDFCMAAuJk9.jpg",
        "id_str" : "160135245117665280",
        "id" : 160135245117665280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjqKDFCMAAuJk9.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/hbN8ZXVh"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 82, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160135245113470976",
    "text" : "Dear @whitehouse my hometown of Altoona is a great place to visit because of this #visitUS http:\/\/t.co\/hbN8ZXVh",
    "id" : 160135245113470976,
    "created_at" : "2012-01-19 23:03:13 +0000",
    "user" : {
      "name" : "Cammie Croft",
      "screen_name" : "cammiecroft",
      "protected" : false,
      "id_str" : "4227211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623964376375148545\/kOaKlJ8J_normal.jpg",
      "id" : 4227211,
      "verified" : false
    }
  },
  "id" : 160153604685180929,
  "created_at" : "2012-01-20 00:16:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Norman",
      "screen_name" : "mtnbikergj",
      "indices" : [ 3, 14 ],
      "id_str" : "76428577",
      "id" : 76428577
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mtnbikergj\/status\/160144475904155648\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/x1N4rcTA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjyjWdCIAAf_hI.jpg",
      "id_str" : "160144475908349952",
      "id" : 160144475908349952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjyjWdCIAAf_hI.jpg",
      "sizes" : [ {
        "h" : 183,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 103,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/x1N4rcTA"
    } ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160144691218747392",
  "text" : "RT @mtnbikergj: @whitehouse #VisitUS  Grand Junction, CO - hike, bike and ski all in the same day! http:\/\/t.co\/x1N4rcTA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mtnbikergj\/status\/160144475904155648\/photo\/1",
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/x1N4rcTA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjyjWdCIAAf_hI.jpg",
        "id_str" : "160144475908349952",
        "id" : 160144475908349952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjyjWdCIAAf_hI.jpg",
        "sizes" : [ {
          "h" : 183,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 103,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/x1N4rcTA"
      } ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 12, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160144475904155648",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #VisitUS  Grand Junction, CO - hike, bike and ski all in the same day! http:\/\/t.co\/x1N4rcTA",
    "id" : 160144475904155648,
    "created_at" : "2012-01-19 23:39:54 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Julie Norman",
      "screen_name" : "mtnbikergj",
      "protected" : false,
      "id_str" : "76428577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474655763273494528\/ff9l1-va_normal.jpeg",
      "id" : 76428577,
      "verified" : false
    }
  },
  "id" : 160144691218747392,
  "created_at" : "2012-01-19 23:40:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/160131279067676672\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ffoYzFIa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjmjMaCAAA75fO.jpg",
      "id_str" : "160131279071870976",
      "id" : 160131279071870976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjmjMaCAAA75fO.jpg",
      "sizes" : [ {
        "h" : 1285,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ffoYzFIa"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/cJ5Qdv7E",
      "expanded_url" : "http:\/\/wh.gov\/B65",
      "display_url" : "wh.gov\/B65"
    } ]
  },
  "geo" : { },
  "id_str" : "160131279067676672",
  "text" : "President Obama @ Disney World: I\u2019m here today because I want more tourists here tomorrow http:\/\/t.co\/cJ5Qdv7E #visitUS http:\/\/t.co\/ffoYzFIa",
  "id" : 160131279067676672,
  "created_at" : "2012-01-19 22:47:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Bob Menendez",
      "screen_name" : "SenatorMenendez",
      "indices" : [ 3, 19 ],
      "id_str" : "18695134",
      "id" : 18695134
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 63, 74 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NJ",
      "indices" : [ 21, 24 ]
    }, {
      "text" : "NJ",
      "indices" : [ 95, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160127080946868224",
  "text" : "RT @SenatorMenendez: #NJ let\u2019s join the conversation. Tell the @whitehouse about your favorite #NJ destination to visit & share a twit p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 42, 53 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NJ",
        "indices" : [ 0, 3 ]
      }, {
        "text" : "NJ",
        "indices" : [ 74, 77 ]
      }, {
        "text" : "visitUS",
        "indices" : [ 119, 127 ]
      }, {
        "text" : "visitNJ",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160119143339794432",
    "text" : "#NJ let\u2019s join the conversation. Tell the @whitehouse about your favorite #NJ destination to visit & share a twit pic  #visitUS #visitNJ",
    "id" : 160119143339794432,
    "created_at" : "2012-01-19 21:59:13 +0000",
    "user" : {
      "name" : "Senator Bob Menendez",
      "screen_name" : "SenatorMenendez",
      "protected" : false,
      "id_str" : "18695134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471994418266775552\/14FnKiYy_normal.jpeg",
      "id" : 18695134,
      "verified" : true
    }
  },
  "id" : 160127080946868224,
  "created_at" : "2012-01-19 22:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160115990234009600",
  "text" : "RT @arneduncan: Basketball, BBQ & the blues are the top 3 reasons to visit my hometown of Chicago. #VisitUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 83, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160115747190874113",
    "text" : "Basketball, BBQ & the blues are the top 3 reasons to visit my hometown of Chicago. #VisitUS",
    "id" : 160115747190874113,
    "created_at" : "2012-01-19 21:45:43 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 160115990234009600,
  "created_at" : "2012-01-19 21:46:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Maryland",
      "screen_name" : "TravelMD",
      "indices" : [ 125, 134 ],
      "id_str" : "18490288",
      "id" : 18490288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "Annapolis",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160112484571811840",
  "text" : "RT @GovernorOMalley: .@WhiteHouse oldest State House still in continuous use & home to the Naval Academy #VisitUS #Annapolis @TravelMD h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Maryland",
        "screen_name" : "TravelMD",
        "indices" : [ 104, 113 ],
        "id_str" : "18490288",
        "id" : 18490288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 84, 92 ]
      }, {
        "text" : "Annapolis",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/EMm0yfgr",
        "expanded_url" : "http:\/\/yfrog.com\/kil7uxnj",
        "display_url" : "yfrog.com\/kil7uxnj"
      } ]
    },
    "geo" : { },
    "id_str" : "160111900108144640",
    "text" : ".@WhiteHouse oldest State House still in continuous use & home to the Naval Academy #VisitUS #Annapolis @TravelMD http:\/\/t.co\/EMm0yfgr",
    "id" : 160111900108144640,
    "created_at" : "2012-01-19 21:30:26 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 160112484571811840,
  "created_at" : "2012-01-19 21:32:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 3, 19 ],
      "id_str" : "234141596",
      "id" : 234141596
    }, {
      "name" : "The Mark Twain House",
      "screen_name" : "TwainHouse",
      "indices" : [ 84, 95 ],
      "id_str" : "23117553",
      "id" : 23117553
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 124, 135 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 21, 29 ]
    }, {
      "text" : "NewEngland",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160111103588835329",
  "text" : "RT @GovMalloyOffice: #visitUS Hartford, CT- Home of nation's 1st public art museum, @TwainHouse, culture, #NewEngland charm @whitehouse  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Mark Twain House",
        "screen_name" : "TwainHouse",
        "indices" : [ 63, 74 ],
        "id_str" : "23117553",
        "id" : 23117553
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 103, 114 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GovMalloyOffice\/status\/160110555749810177\/photo\/1",
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/VGltn8XY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjTs8CCAAID-Bb.jpg",
        "id_str" : "160110555754004482",
        "id" : 160110555754004482,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjTs8CCAAID-Bb.jpg",
        "sizes" : [ {
          "h" : 645,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 645,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VGltn8XY"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "NewEngland",
        "indices" : [ 85, 96 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "160059667282804736",
    "geo" : { },
    "id_str" : "160110555749810177",
    "in_reply_to_user_id" : 30313925,
    "text" : "#visitUS Hartford, CT- Home of nation's 1st public art museum, @TwainHouse, culture, #NewEngland charm @whitehouse http:\/\/t.co\/VGltn8XY",
    "id" : 160110555749810177,
    "in_reply_to_status_id" : 160059667282804736,
    "created_at" : "2012-01-19 21:25:06 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "protected" : false,
      "id_str" : "234141596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738519424223858688\/_0xQvvKS_normal.jpg",
      "id" : 234141596,
      "verified" : true
    }
  },
  "id" : 160111103588835329,
  "created_at" : "2012-01-19 21:27:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mrs. Duh",
      "screen_name" : "Mrs_Duh",
      "indices" : [ 3, 11 ],
      "id_str" : "415839679",
      "id" : 415839679
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Mrs_Duh\/status\/160106346434400257\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/AVErLcAY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjP37ICEAApaYK.jpg",
      "id_str" : "160106346442788864",
      "id" : 160106346442788864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjP37ICEAApaYK.jpg",
      "sizes" : [ {
        "h" : 341,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/AVErLcAY"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160106803068280833",
  "text" : "RT @Mrs_Duh: Salt Lake City has America's most beautiful mountains... plus we have the \"Best Snow on Earth!\" #visitUS http:\/\/t.co\/AVErLcAY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Mrs_Duh\/status\/160106346434400257\/photo\/1",
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/AVErLcAY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjP37ICEAApaYK.jpg",
        "id_str" : "160106346442788864",
        "id" : 160106346442788864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjP37ICEAApaYK.jpg",
        "sizes" : [ {
          "h" : 341,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/AVErLcAY"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 96, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160106346434400257",
    "text" : "Salt Lake City has America's most beautiful mountains... plus we have the \"Best Snow on Earth!\" #visitUS http:\/\/t.co\/AVErLcAY",
    "id" : 160106346434400257,
    "created_at" : "2012-01-19 21:08:23 +0000",
    "user" : {
      "name" : "Mrs. Duh",
      "screen_name" : "Mrs_Duh",
      "protected" : false,
      "id_str" : "415839679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1783107075\/dw_normal.jpg",
      "id" : 415839679,
      "verified" : false
    }
  },
  "id" : 160106803068280833,
  "created_at" : "2012-01-19 21:10:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marqmanner",
      "screen_name" : "marqmanner",
      "indices" : [ 3, 14 ],
      "id_str" : "15328699",
      "id" : 15328699
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 86, 97 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/hXASUi9F",
      "expanded_url" : "http:\/\/exm.nr\/wMm4w3",
      "display_url" : "exm.nr\/wMm4w3"
    } ]
  },
  "geo" : { },
  "id_str" : "160106617218662400",
  "text" : "RT @marqmanner: Benson, Nebraksa! Where the beards and beer flow http:\/\/t.co\/hXASUi9F @whitehouse #VisitUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 70, 81 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 82, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/hXASUi9F",
        "expanded_url" : "http:\/\/exm.nr\/wMm4w3",
        "display_url" : "exm.nr\/wMm4w3"
      } ]
    },
    "geo" : { },
    "id_str" : "160106103315771392",
    "text" : "Benson, Nebraksa! Where the beards and beer flow http:\/\/t.co\/hXASUi9F @whitehouse #VisitUS",
    "id" : 160106103315771392,
    "created_at" : "2012-01-19 21:07:24 +0000",
    "user" : {
      "name" : "marqmanner",
      "screen_name" : "marqmanner",
      "protected" : false,
      "id_str" : "15328699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433018460566614016\/LBBDIwk7_normal.png",
      "id" : 15328699,
      "verified" : false
    }
  },
  "id" : 160106617218662400,
  "created_at" : "2012-01-19 21:09:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Archer",
      "screen_name" : "ericaaarcher",
      "indices" : [ 3, 16 ],
      "id_str" : "191276564",
      "id" : 191276564
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Miami University",
      "screen_name" : "miamiuniversity",
      "indices" : [ 96, 112 ],
      "id_str" : "42790918",
      "id" : 42790918
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ericaaarcher\/status\/160104869510922240\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/4ZZrxmEC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjOh9KCQAAZqs_.jpg",
      "id_str" : "160104869519310848",
      "id" : 160104869519310848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjOh9KCQAAZqs_.jpg",
      "sizes" : [ {
        "h" : 481,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4ZZrxmEC"
    } ],
    "hashtags" : [ {
      "text" : "miamiu",
      "indices" : [ 64, 71 ]
    }, {
      "text" : "visitUS",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160105415743504385",
  "text" : "RT @ericaaarcher: @whitehouse this is why everyone should visit #miamiu in Oxford, OH! #visitUS @MiamiUniversity http:\/\/t.co\/4ZZrxmEC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Miami University",
        "screen_name" : "miamiuniversity",
        "indices" : [ 78, 94 ],
        "id_str" : "42790918",
        "id" : 42790918
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ericaaarcher\/status\/160104869510922240\/photo\/1",
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/4ZZrxmEC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjOh9KCQAAZqs_.jpg",
        "id_str" : "160104869519310848",
        "id" : 160104869519310848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjOh9KCQAAZqs_.jpg",
        "sizes" : [ {
          "h" : 481,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4ZZrxmEC"
      } ],
      "hashtags" : [ {
        "text" : "miamiu",
        "indices" : [ 46, 53 ]
      }, {
        "text" : "visitUS",
        "indices" : [ 69, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160104869510922240",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse this is why everyone should visit #miamiu in Oxford, OH! #visitUS @MiamiUniversity http:\/\/t.co\/4ZZrxmEC",
    "id" : 160104869510922240,
    "created_at" : "2012-01-19 21:02:30 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Erica Archer",
      "screen_name" : "ericaaarcher",
      "protected" : false,
      "id_str" : "191276564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647119005229056000\/cmc7EqTr_normal.jpg",
      "id" : 191276564,
      "verified" : false
    }
  },
  "id" : 160105415743504385,
  "created_at" : "2012-01-19 21:04:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh broooo!!!",
      "screen_name" : "joshbry_4",
      "indices" : [ 3, 13 ],
      "id_str" : "236635817",
      "id" : 236635817
    }, {
      "name" : "El Paso 411",
      "screen_name" : "ElPaso411",
      "indices" : [ 18, 28 ],
      "id_str" : "28435162",
      "id" : 28435162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/HmnKDwFK",
      "expanded_url" : "http:\/\/twitpic.com\/898tun",
      "display_url" : "twitpic.com\/898tun"
    } ]
  },
  "geo" : { },
  "id_str" : "160105405652021248",
  "text" : "RT @joshbry_4: RT @ElPaso411 El Paso, Texas: 300+ days of sun, authentic Mexican cuisine, unique culture! http:\/\/t.co\/HmnKDwFK #visitUS  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "El Paso 411",
        "screen_name" : "ElPaso411",
        "indices" : [ 3, 13 ],
        "id_str" : "28435162",
        "id" : 28435162
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 121, 132 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 112, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/HmnKDwFK",
        "expanded_url" : "http:\/\/twitpic.com\/898tun",
        "display_url" : "twitpic.com\/898tun"
      } ]
    },
    "geo" : { },
    "id_str" : "160104998036963329",
    "text" : "RT @ElPaso411 El Paso, Texas: 300+ days of sun, authentic Mexican cuisine, unique culture! http:\/\/t.co\/HmnKDwFK #visitUS @whitehouse",
    "id" : 160104998036963329,
    "created_at" : "2012-01-19 21:03:00 +0000",
    "user" : {
      "name" : "josh broooo!!!",
      "screen_name" : "joshbry_4",
      "protected" : false,
      "id_str" : "236635817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261571385131\/4a258ae1a0bed28dd78ff40ed9b104a8_normal.jpeg",
      "id" : 236635817,
      "verified" : false
    }
  },
  "id" : 160105405652021248,
  "created_at" : "2012-01-19 21:04:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathy Cox",
      "screen_name" : "HotandSixty",
      "indices" : [ 3, 15 ],
      "id_str" : "175201688",
      "id" : 175201688
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HotandSixty\/status\/160104998804529152\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/128eXSnP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjOpe0CIAA1EZD.jpg",
      "id_str" : "160104998812917760",
      "id" : 160104998812917760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjOpe0CIAA1EZD.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/128eXSnP"
    } ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160105393324949504",
  "text" : "RT @HotandSixty: @whitehouse   Cincinnati, Ohio  The Greatest City ! Many,many things to do: #VisitUS http:\/\/t.co\/128eXSnP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HotandSixty\/status\/160104998804529152\/photo\/1",
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/128eXSnP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjOpe0CIAA1EZD.jpg",
        "id_str" : "160104998812917760",
        "id" : 160104998812917760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjOpe0CIAA1EZD.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/128eXSnP"
      } ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160104998804529152",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse   Cincinnati, Ohio  The Greatest City ! Many,many things to do: #VisitUS http:\/\/t.co\/128eXSnP",
    "id" : 160104998804529152,
    "created_at" : "2012-01-19 21:03:02 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Kathy Cox",
      "screen_name" : "HotandSixty",
      "protected" : false,
      "id_str" : "175201688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783458242093604864\/25KSzTmi_normal.jpg",
      "id" : 175201688,
      "verified" : false
    }
  },
  "id" : 160105393324949504,
  "created_at" : "2012-01-19 21:04:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "melody castillo",
      "screen_name" : "melody1228",
      "indices" : [ 3, 14 ],
      "id_str" : "3159286170",
      "id" : 3159286170
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Indianapolis",
      "indices" : [ 39, 52 ]
    }, {
      "text" : "SuperBowl2012",
      "indices" : [ 62, 76 ]
    }, {
      "text" : "Indy500",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "visitus",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160104605680807936",
  "text" : "RT @melody1228: @whitehouse come visit #Indianapolis, home of #SuperBowl2012 and the #Indy500. There's something for everyone! #visitus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Indianapolis",
        "indices" : [ 23, 36 ]
      }, {
        "text" : "SuperBowl2012",
        "indices" : [ 46, 60 ]
      }, {
        "text" : "Indy500",
        "indices" : [ 69, 77 ]
      }, {
        "text" : "visitus",
        "indices" : [ 111, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160103657097003008",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse come visit #Indianapolis, home of #SuperBowl2012 and the #Indy500. There's something for everyone! #visitus",
    "id" : 160103657097003008,
    "created_at" : "2012-01-19 20:57:41 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Harmony",
      "screen_name" : "MelodyINthecity",
      "protected" : false,
      "id_str" : "272063709",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440677758729854976\/JXyUeoRA_normal.jpeg",
      "id" : 272063709,
      "verified" : false
    }
  },
  "id" : 160104605680807936,
  "created_at" : "2012-01-19 21:01:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca King",
      "screen_name" : "Kingstulsa",
      "indices" : [ 3, 14 ],
      "id_str" : "82743920",
      "id" : 82743920
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160104509438304256",
  "text" : "RT @Kingstulsa: @whitehouse Tulsa for Art Deco architecture and Route 66! #visitUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 58, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160104013608665088",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Tulsa for Art Deco architecture and Route 66! #visitUS",
    "id" : 160104013608665088,
    "created_at" : "2012-01-19 20:59:06 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Rebecca King",
      "screen_name" : "Kingstulsa",
      "protected" : false,
      "id_str" : "82743920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668773341436637184\/g21FOfYS_normal.jpg",
      "id" : 82743920,
      "verified" : false
    }
  },
  "id" : 160104509438304256,
  "created_at" : "2012-01-19 21:01:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Mills",
      "screen_name" : "CourtneyLMills",
      "indices" : [ 3, 18 ],
      "id_str" : "25383805",
      "id" : 25383805
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CourtneyLMills\/status\/160103037820604416\/photo\/1",
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/MkAH1uHa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjM3VkCEAER3pq.jpg",
      "id_str" : "160103037824798721",
      "id" : 160103037824798721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjM3VkCEAER3pq.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/MkAH1uHa"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160104086845390848",
  "text" : "RT @CourtneyLMills: @whitehouse Camping on Lake Greeson in Central Arkansas. #visitUS http:\/\/t.co\/MkAH1uHa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CourtneyLMills\/status\/160103037820604416\/photo\/1",
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/MkAH1uHa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjM3VkCEAER3pq.jpg",
        "id_str" : "160103037824798721",
        "id" : 160103037824798721,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjM3VkCEAER3pq.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/MkAH1uHa"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160103037820604416",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Camping on Lake Greeson in Central Arkansas. #visitUS http:\/\/t.co\/MkAH1uHa",
    "id" : 160103037820604416,
    "created_at" : "2012-01-19 20:55:14 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Courtney Mills",
      "screen_name" : "CourtneyLMills",
      "protected" : false,
      "id_str" : "25383805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760850912759853056\/hTVaEtbp_normal.jpg",
      "id" : 25383805,
      "verified" : false
    }
  },
  "id" : 160104086845390848,
  "created_at" : "2012-01-19 20:59:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160104018297888768",
  "text" : "RT @beatlebug731: @whitehouse allentown, pa!! the city has both it's own Billy Joel song and Led Zepplin's favorite diner??  http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/E8F4gBM9",
        "expanded_url" : "http:\/\/www.google.com\/imgres?q=allentown+pa&um=1&hl=en&client=safari&sa=N&rls=en&biw=1008&bih=608&tbm=isch&tbnid=xwFxRMILtE7BAM:&imgrefurl=http:\/\/apartmentsilike.wordpress.com\/2011\/01\/25\/sights-to-see-in-allentown-pa\/&docid=XyBdgZ_D5lZ6NM&imgurl=http:\/\/apartmentsilike.files.wordpress.com\/2011\/01\/allentown-pa1.jpg&w=501&h=478&ei=-4IYT7nKN8ft0gHgvZm9Cw&zoom=1&iact=hc&vpx=737&vpy=261&dur=3899&hovh=219&hovw=230&tx=137&ty=130&sig=108728243680604826719&page=1&tbnh=113&tbnw=125&start=0&ndsp=16&ved=1t:429,r:9,s:0",
        "display_url" : "google.com\/imgres?q=allen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "160103326824939520",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse allentown, pa!! the city has both it's own Billy Joel song and Led Zepplin's favorite diner??  http:\/\/t.co\/E8F4gBM9 #visitUS",
    "id" : 160103326824939520,
    "created_at" : "2012-01-19 20:56:22 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Nessa Ann",
      "screen_name" : "comesthesun01",
      "protected" : false,
      "id_str" : "282382076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3159339720\/93c3165d4b2a0dd5c6c55f4901fc0f7f_normal.jpeg",
      "id" : 282382076,
      "verified" : false
    }
  },
  "id" : 160104018297888768,
  "created_at" : "2012-01-19 20:59:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dylan Horn",
      "screen_name" : "ItsDylanHorn",
      "indices" : [ 3, 16 ],
      "id_str" : "276813625",
      "id" : 276813625
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ItsDylanHorn\/status\/160103397146628096\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/X5DUhOKR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjNMQKCEAAQ0Tn.jpg",
      "id_str" : "160103397150822400",
      "id" : 160103397150822400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjNMQKCEAAQ0Tn.jpg",
      "sizes" : [ {
        "h" : 358,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/X5DUhOKR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160103927432491008",
  "text" : "RT @ItsDylanHorn: @whitehouse Lexington, Kentucky because it has the WORLDS most beautiful horse farms! http:\/\/t.co\/X5DUhOKR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsDylanHorn\/status\/160103397146628096\/photo\/1",
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/X5DUhOKR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjNMQKCEAAQ0Tn.jpg",
        "id_str" : "160103397150822400",
        "id" : 160103397150822400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjNMQKCEAAQ0Tn.jpg",
        "sizes" : [ {
          "h" : 358,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/X5DUhOKR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160103397146628096",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Lexington, Kentucky because it has the WORLDS most beautiful horse farms! http:\/\/t.co\/X5DUhOKR",
    "id" : 160103397146628096,
    "created_at" : "2012-01-19 20:56:40 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Dylan Horn",
      "screen_name" : "ItsDylanHorn",
      "protected" : false,
      "id_str" : "276813625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750872091252002821\/M22h451Y_normal.jpg",
      "id" : 276813625,
      "verified" : false
    }
  },
  "id" : 160103927432491008,
  "created_at" : "2012-01-19 20:58:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/yiJw86Yh",
      "expanded_url" : "http:\/\/ow.ly\/8zD3I",
      "display_url" : "ow.ly\/8zD3I"
    } ]
  },
  "geo" : { },
  "id_str" : "160099946534674432",
  "text" : "Keep the great pics coming! From SF to Jersey, South Dakota to Texas, people are sharing reasons to #VisitUS http:\/\/t.co\/yiJw86Yh",
  "id" : 160099946534674432,
  "created_at" : "2012-01-19 20:42:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kara",
      "screen_name" : "kcnyg",
      "indices" : [ 3, 9 ],
      "id_str" : "28737616",
      "id" : 28737616
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Bruce Springsteen",
      "screen_name" : "springsteen",
      "indices" : [ 23, 35 ],
      "id_str" : "43383705",
      "id" : 43383705
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kcnyg\/status\/160040205687078913\/photo\/1",
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/v5xTlbZN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiTuBoCQAI0_8i.jpg",
      "id_str" : "160040205691273218",
      "id" : 160040205691273218,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiTuBoCQAI0_8i.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/v5xTlbZN"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160098469896392704",
  "text" : "RT @kcnyg: @whitehouse @springsteen Asbury Park, NJ.  Where rock & roll legends are born #visitUS http:\/\/t.co\/v5xTlbZN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Bruce Springsteen",
        "screen_name" : "springsteen",
        "indices" : [ 12, 24 ],
        "id_str" : "43383705",
        "id" : 43383705
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kcnyg\/status\/160040205687078913\/photo\/1",
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/v5xTlbZN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiTuBoCQAI0_8i.jpg",
        "id_str" : "160040205691273218",
        "id" : 160040205691273218,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiTuBoCQAI0_8i.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/v5xTlbZN"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 78, 86 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "160033387170639872",
    "geo" : { },
    "id_str" : "160040205687078913",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @springsteen Asbury Park, NJ.  Where rock & roll legends are born #visitUS http:\/\/t.co\/v5xTlbZN",
    "id" : 160040205687078913,
    "in_reply_to_status_id" : 160033387170639872,
    "created_at" : "2012-01-19 16:45:33 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Kara",
      "screen_name" : "kcnyg",
      "protected" : false,
      "id_str" : "28737616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1728895054\/74c7a75f-2ead-4874-b2d6-f0769a565d76_normal.png",
      "id" : 28737616,
      "verified" : false
    }
  },
  "id" : 160098469896392704,
  "created_at" : "2012-01-19 20:37:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "ama125",
      "indices" : [ 3, 10 ],
      "id_str" : "27059776",
      "id" : 27059776
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nuffsaid",
      "indices" : [ 69, 78 ]
    }, {
      "text" : "visitUS",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160098446076940288",
  "text" : "RT @ama125: @whitehouse Hershey, PA because it smells like chocolate #nuffsaid #visitUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nuffsaid",
        "indices" : [ 57, 66 ]
      }, {
        "text" : "visitUS",
        "indices" : [ 67, 75 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "160033387170639872",
    "geo" : { },
    "id_str" : "160040064045416448",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Hershey, PA because it smells like chocolate #nuffsaid #visitUS",
    "id" : 160040064045416448,
    "in_reply_to_status_id" : 160033387170639872,
    "created_at" : "2012-01-19 16:44:59 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Andrew",
      "screen_name" : "ama125",
      "protected" : false,
      "id_str" : "27059776",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657651134283280384\/7X8ulEsR_normal.jpg",
      "id" : 27059776,
      "verified" : false
    }
  },
  "id" : 160098446076940288,
  "created_at" : "2012-01-19 20:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kara",
      "screen_name" : "kcnyg",
      "indices" : [ 3, 9 ],
      "id_str" : "28737616",
      "id" : 28737616
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kcnyg\/status\/160038721410957312\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/24u0voGA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiSXoRCAAAyLfl.jpg",
      "id_str" : "160038721415151616",
      "id" : 160038721415151616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiSXoRCAAAyLfl.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/24u0voGA"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160098415534022657",
  "text" : "RT @kcnyg: @whitehouse Southern New Jersey!  The most beautiful beaches on the east coast #visitUS http:\/\/t.co\/24u0voGA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kcnyg\/status\/160038721410957312\/photo\/1",
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/24u0voGA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiSXoRCAAAyLfl.jpg",
        "id_str" : "160038721415151616",
        "id" : 160038721415151616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiSXoRCAAAyLfl.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/24u0voGA"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "160033387170639872",
    "geo" : { },
    "id_str" : "160038721410957312",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Southern New Jersey!  The most beautiful beaches on the east coast #visitUS http:\/\/t.co\/24u0voGA",
    "id" : 160038721410957312,
    "in_reply_to_status_id" : 160033387170639872,
    "created_at" : "2012-01-19 16:39:40 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Kara",
      "screen_name" : "kcnyg",
      "protected" : false,
      "id_str" : "28737616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1728895054\/74c7a75f-2ead-4874-b2d6-f0769a565d76_normal.png",
      "id" : 28737616,
      "verified" : false
    }
  },
  "id" : 160098415534022657,
  "created_at" : "2012-01-19 20:36:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TravelKS",
      "screen_name" : "TravelKS",
      "indices" : [ 3, 12 ],
      "id_str" : "16370632",
      "id" : 16370632
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 23, 34 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160096730724044800",
  "text" : "RT @TravelKS: Tell the @whitehouse in words and pics why your town is a great place to visit with #visitUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 9, 20 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160091814991364096",
    "text" : "Tell the @whitehouse in words and pics why your town is a great place to visit with #visitUS",
    "id" : 160091814991364096,
    "created_at" : "2012-01-19 20:10:37 +0000",
    "user" : {
      "name" : "TravelKS",
      "screen_name" : "TravelKS",
      "protected" : false,
      "id_str" : "16370632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2204694145\/ProfilePic_normal.jpg",
      "id" : 16370632,
      "verified" : false
    }
  },
  "id" : 160096730724044800,
  "created_at" : "2012-01-19 20:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassi Jolley",
      "screen_name" : "pb_n_j",
      "indices" : [ 3, 10 ],
      "id_str" : "24247509",
      "id" : 24247509
    }, {
      "name" : "Visit Rapid City",
      "screen_name" : "VisitRapidCity",
      "indices" : [ 75, 90 ],
      "id_str" : "26855481",
      "id" : 26855481
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 91, 102 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pb_n_j\/status\/160094411991158784\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/zexzUYKQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjFBP2CEAEYuW5.jpg",
      "id_str" : "160094411995353089",
      "id" : 160094411995353089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjFBP2CEAEYuW5.jpg",
      "sizes" : [ {
        "h" : 247,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 370
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 370
      } ],
      "display_url" : "pic.twitter.com\/zexzUYKQ"
    } ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160096655117524993",
  "text" : "RT @pb_n_j: #VisitUS Mount Rushmore - Rapid City, SD! Most patriotic city! @VisitRapidCity @whitehouse http:\/\/t.co\/zexzUYKQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Visit Rapid City",
        "screen_name" : "VisitRapidCity",
        "indices" : [ 63, 78 ],
        "id_str" : "26855481",
        "id" : 26855481
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 79, 90 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pb_n_j\/status\/160094411991158784\/photo\/1",
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/zexzUYKQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjjFBP2CEAEYuW5.jpg",
        "id_str" : "160094411995353089",
        "id" : 160094411995353089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjjFBP2CEAEYuW5.jpg",
        "sizes" : [ {
          "h" : 247,
          "resize" : "fit",
          "w" : 370
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 370
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 370
        } ],
        "display_url" : "pic.twitter.com\/zexzUYKQ"
      } ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160094411991158784",
    "text" : "#VisitUS Mount Rushmore - Rapid City, SD! Most patriotic city! @VisitRapidCity @whitehouse http:\/\/t.co\/zexzUYKQ",
    "id" : 160094411991158784,
    "created_at" : "2012-01-19 20:20:58 +0000",
    "user" : {
      "name" : "Kassi Jolley",
      "screen_name" : "pb_n_j",
      "protected" : false,
      "id_str" : "24247509",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000149413126\/2a2cc11041ca7c3d5bf669d6564fc13c_normal.jpeg",
      "id" : 24247509,
      "verified" : false
    }
  },
  "id" : 160096655117524993,
  "created_at" : "2012-01-19 20:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New York Guide",
      "screen_name" : "TourguideStan",
      "indices" : [ 3, 17 ],
      "id_str" : "164380239",
      "id" : 164380239
    }, {
      "name" : "Urban Village Tours",
      "screen_name" : "UrbVillageTours",
      "indices" : [ 19, 35 ],
      "id_str" : "220913467",
      "id" : 220913467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160096440692125697",
  "text" : "RT @TourguideStan: @urbvillagetours I tweeted a photo to #visitUS at the White House, which resulted in 42 more followers an hour later. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Urban Village Tours",
        "screen_name" : "UrbVillageTours",
        "indices" : [ 0, 16 ],
        "id_str" : "220913467",
        "id" : 220913467
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 38, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160095751442137088",
    "in_reply_to_user_id" : 220913467,
    "text" : "@urbvillagetours I tweeted a photo to #visitUS at the White House, which resulted in 42 more followers an hour later. Start tweeting!",
    "id" : 160095751442137088,
    "created_at" : "2012-01-19 20:26:16 +0000",
    "in_reply_to_screen_name" : "UrbVillageTours",
    "in_reply_to_user_id_str" : "220913467",
    "user" : {
      "name" : "New York Guide",
      "screen_name" : "TourguideStan",
      "protected" : false,
      "id_str" : "164380239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793526783807217665\/sAWJllWH_normal.jpg",
      "id" : 164380239,
      "verified" : false
    }
  },
  "id" : 160096440692125697,
  "created_at" : "2012-01-19 20:29:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/160074645066883072\/photo\/1",
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/kKn3f473",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjizCqUCIAE3AqJ.jpg",
      "id_str" : "160074645071077377",
      "id" : 160074645071077377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjizCqUCIAE3AqJ.jpg",
      "sizes" : [ {
        "h" : 419,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kKn3f473"
    } ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 13, 21 ]
    }, {
      "text" : "spacecamp",
      "indices" : [ 74, 84 ]
    }, {
      "text" : "rolltide",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160074964018532353",
  "text" : "RT @macon44: #VisitUS in Huntsville, Alabama! Why? Two words: ROCKET CITY #spacecamp #rolltide http:\/\/t.co\/kKn3f473",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/160074645066883072\/photo\/1",
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/kKn3f473",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjizCqUCIAE3AqJ.jpg",
        "id_str" : "160074645071077377",
        "id" : 160074645071077377,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjizCqUCIAE3AqJ.jpg",
        "sizes" : [ {
          "h" : 419,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 419,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kKn3f473"
      } ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "spacecamp",
        "indices" : [ 61, 71 ]
      }, {
        "text" : "rolltide",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160074645066883072",
    "text" : "#VisitUS in Huntsville, Alabama! Why? Two words: ROCKET CITY #spacecamp #rolltide http:\/\/t.co\/kKn3f473",
    "id" : 160074645066883072,
    "created_at" : "2012-01-19 19:02:24 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 160074964018532353,
  "created_at" : "2012-01-19 19:03:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160073808554893313",
  "text" : "RT @Interior: What are your favorite national parks, wildlife refuges & public lands to visit? Tell us & share pic w\/ #visitUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160066283596034048",
    "text" : "What are your favorite national parks, wildlife refuges & public lands to visit? Tell us & share pic w\/ #visitUS",
    "id" : 160066283596034048,
    "created_at" : "2012-01-19 18:29:10 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 160073808554893313,
  "created_at" : "2012-01-19 18:59:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Trendsmap DC",
      "screen_name" : "TrendsDC",
      "indices" : [ 67, 76 ],
      "id_str" : "132332780",
      "id" : 132332780
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitus",
      "indices" : [ 10, 18 ]
    }, {
      "text" : "DC",
      "indices" : [ 38, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/ZmlE1inJ",
      "expanded_url" : "http:\/\/trendsmap.com\/us\/washington",
      "display_url" : "trendsmap.com\/us\/washington"
    } ]
  },
  "geo" : { },
  "id_str" : "160073351304445953",
  "text" : "RT @ks44: #visitus is now trending in #DC http:\/\/t.co\/ZmlE1inJ via @trendsdc. Help us trend worldwide! What makes your town a great plac ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Trendsmap DC",
        "screen_name" : "TrendsDC",
        "indices" : [ 57, 66 ],
        "id_str" : "132332780",
        "id" : 132332780
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitus",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "DC",
        "indices" : [ 28, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/ZmlE1inJ",
        "expanded_url" : "http:\/\/trendsmap.com\/us\/washington",
        "display_url" : "trendsmap.com\/us\/washington"
      } ]
    },
    "geo" : { },
    "id_str" : "160073234358874112",
    "text" : "#visitus is now trending in #DC http:\/\/t.co\/ZmlE1inJ via @trendsdc. Help us trend worldwide! What makes your town a great place to visit?",
    "id" : 160073234358874112,
    "created_at" : "2012-01-19 18:56:47 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 160073351304445953,
  "created_at" : "2012-01-19 18:57:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter True",
      "screen_name" : "peterwtrue",
      "indices" : [ 3, 14 ],
      "id_str" : "314764043",
      "id" : 314764043
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 67, 78 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160062789069709312",
  "text" : "RT @peterwtrue: Easier to show than tell! Berkeley, CA #visitUS RT @whitehouse: What makes your city or town a great place to visit?  ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 51, 62 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 39, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/jPR7W5VG",
        "expanded_url" : "http:\/\/twitpic.com\/896eoz",
        "display_url" : "twitpic.com\/896eoz"
      } ]
    },
    "geo" : { },
    "id_str" : "160036238815019008",
    "text" : "Easier to show than tell! Berkeley, CA #visitUS RT @whitehouse: What makes your city or town a great place to visit?  http:\/\/t.co\/jPR7W5VG",
    "id" : 160036238815019008,
    "created_at" : "2012-01-19 16:29:47 +0000",
    "user" : {
      "name" : "Peter True",
      "screen_name" : "peterwtrue",
      "protected" : false,
      "id_str" : "314764043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773881186603139072\/EtzcjJxC_normal.jpg",
      "id" : 314764043,
      "verified" : false
    }
  },
  "id" : 160062789069709312,
  "created_at" : "2012-01-19 18:15:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THCT",
      "screen_name" : "HillCountryTrav",
      "indices" : [ 3, 19 ],
      "id_str" : "91248778",
      "id" : 91248778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160061220735557632",
  "text" : "RT @HillCountryTrav: #visitUS Wimberley, TX is a quaint Hill Country town with friendly peeps, peace & quiet, scenery, scenery, scenery! ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HillCountryTrav\/status\/160060822800957442\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/u6siSuFM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjimeGYCAAAFlJB.jpg",
        "id_str" : "160060822809346048",
        "id" : 160060822809346048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjimeGYCAAAFlJB.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 150
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/u6siSuFM"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160060822800957442",
    "text" : "#visitUS Wimberley, TX is a quaint Hill Country town with friendly peeps, peace & quiet, scenery, scenery, scenery!! http:\/\/t.co\/u6siSuFM",
    "id" : 160060822800957442,
    "created_at" : "2012-01-19 18:07:29 +0000",
    "user" : {
      "name" : "THCT",
      "screen_name" : "HillCountryTrav",
      "protected" : false,
      "id_str" : "91248778",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757790663995822080\/h0JbhdF3_normal.jpg",
      "id" : 91248778,
      "verified" : false
    }
  },
  "id" : 160061220735557632,
  "created_at" : "2012-01-19 18:09:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Lopez",
      "screen_name" : "David_9_Lopez",
      "indices" : [ 3, 17 ],
      "id_str" : "43653282",
      "id" : 43653282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "travel",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "Colorado",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160059759884640256",
  "text" : "RT @David_9_Lopez: Colorado has incredible mountain views and so many wilderness areas to explore!  #VisitUS #travel #Colorado http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/David_9_Lopez\/status\/160059496281014272\/photo\/1",
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/s6q1NVIs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjilQ4sCAAEc94w.jpg",
        "id_str" : "160059496285208577",
        "id" : 160059496285208577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjilQ4sCAAEc94w.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/s6q1NVIs"
      } ],
      "hashtags" : [ {
        "text" : "VisitUS",
        "indices" : [ 81, 89 ]
      }, {
        "text" : "travel",
        "indices" : [ 90, 97 ]
      }, {
        "text" : "Colorado",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160059496281014272",
    "text" : "Colorado has incredible mountain views and so many wilderness areas to explore!  #VisitUS #travel #Colorado http:\/\/t.co\/s6q1NVIs",
    "id" : 160059496281014272,
    "created_at" : "2012-01-19 18:02:13 +0000",
    "user" : {
      "name" : "David Lopez",
      "screen_name" : "David_9_Lopez",
      "protected" : false,
      "id_str" : "43653282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1684594388\/030_normal.JPG",
      "id" : 43653282,
      "verified" : false
    }
  },
  "id" : 160059759884640256,
  "created_at" : "2012-01-19 18:03:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160059667282804736",
  "text" : "Obama just announced new initiatives to boost US tourism. Why is your town a great place to visit? Share pics & tell us w\/ #visitUS",
  "id" : 160059667282804736,
  "created_at" : "2012-01-19 18:02:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walt Disney World",
      "screen_name" : "WaltDisneyWorld",
      "indices" : [ 106, 122 ],
      "id_str" : "15220473",
      "id" : 15220473
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160058143450206211",
  "text" : "\"That\u2019s what this is all about. Telling the world that America is open for business.\" -President Obama at @waltdisneyworld #visitUS",
  "id" : 160058143450206211,
  "created_at" : "2012-01-19 17:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160057428036161537",
  "text" : "RT @WHLive: Obama: That\u2019s what this is all about...Helping our businesses all across the country grow & create #jobs; compete & win. #vi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 99, 104 ]
      }, {
        "text" : "visitUS",
        "indices" : [ 121, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160057387879903235",
    "text" : "Obama: That\u2019s what this is all about...Helping our businesses all across the country grow & create #jobs; compete & win. #visitUS",
    "id" : 160057387879903235,
    "created_at" : "2012-01-19 17:53:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 160057428036161537,
  "created_at" : "2012-01-19 17:53:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160056157040427008",
  "text" : "RT @WHLive: Obama: The more folks who visit America, the more Americans we get back to work. It\u2019s that simple. #visitUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160056114157862912",
    "text" : "Obama: The more folks who visit America, the more Americans we get back to work. It\u2019s that simple. #visitUS",
    "id" : 160056114157862912,
    "created_at" : "2012-01-19 17:48:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 160056157040427008,
  "created_at" : "2012-01-19 17:48:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160055808976109568",
  "text" : "RT @WHLive: Obama: I want America to be the top tourist destination in the world. #visitUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 70, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160055686997348352",
    "text" : "Obama: I want America to be the top tourist destination in the world. #visitUS",
    "id" : 160055686997348352,
    "created_at" : "2012-01-19 17:47:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 160055808976109568,
  "created_at" : "2012-01-19 17:47:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 119, 126 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "160055007062917120",
  "text" : "Happening now: President Obama announces strategy to help boost tourism & travel. Listen: http:\/\/t.co\/u95y7hhB Follow: @whlive #visitUS",
  "id" : 160055007062917120,
  "created_at" : "2012-01-19 17:44:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Smith",
      "screen_name" : "nycssmith",
      "indices" : [ 3, 13 ],
      "id_str" : "34091166",
      "id" : 34091166
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nycssmith\/status\/160048502221709313\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/Rgc5WTWj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjibQ8pCIAEWtuJ.jpg",
      "id_str" : "160048502230097921",
      "id" : 160048502230097921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjibQ8pCIAEWtuJ.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Rgc5WTWj"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160048827888451584",
  "text" : "RT @nycssmith: @whitehouse Come to Cheaha State Park, in Alabama where the Appalachian Mountains begin #visitUS http:\/\/t.co\/Rgc5WTWj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nycssmith\/status\/160048502221709313\/photo\/1",
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/Rgc5WTWj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjibQ8pCIAEWtuJ.jpg",
        "id_str" : "160048502230097921",
        "id" : 160048502230097921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjibQ8pCIAEWtuJ.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Rgc5WTWj"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160048502221709313",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Come to Cheaha State Park, in Alabama where the Appalachian Mountains begin #visitUS http:\/\/t.co\/Rgc5WTWj",
    "id" : 160048502221709313,
    "created_at" : "2012-01-19 17:18:32 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Shane Smith",
      "screen_name" : "nycssmith",
      "protected" : false,
      "id_str" : "34091166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/186386742\/File0000509_normal.JPG",
      "id" : 34091166,
      "verified" : false
    }
  },
  "id" : 160048827888451584,
  "created_at" : "2012-01-19 17:19:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160045256610557952",
  "text" : "\u201CThe more folks who visit America, the more Americans we get back to work\" -President Obama announces plan to boost US tourism #visitUS",
  "id" : 160045256610557952,
  "created_at" : "2012-01-19 17:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holdwynate",
      "screen_name" : "Holdwynate",
      "indices" : [ 3, 14 ],
      "id_str" : "329133433",
      "id" : 329133433
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Holdwynate\/status\/160042588768972800\/photo\/1",
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/Du6IzgDO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiV4vTCMAI5FgB.jpg",
      "id_str" : "160042588773167106",
      "id" : 160042588773167106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiV4vTCMAI5FgB.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Du6IzgDO"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 28, 36 ]
    }, {
      "text" : "2011WorldChamps",
      "indices" : [ 58, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160042875562893312",
  "text" : "RT @Holdwynate: @whitehouse #visitUS what about Missouri? #2011WorldChamps http:\/\/t.co\/Du6IzgDO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Holdwynate\/status\/160042588768972800\/photo\/1",
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/Du6IzgDO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiV4vTCMAI5FgB.jpg",
        "id_str" : "160042588773167106",
        "id" : 160042588773167106,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiV4vTCMAI5FgB.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/Du6IzgDO"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "2011WorldChamps",
        "indices" : [ 42, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.55949065, -90.508755525 ]
    },
    "id_str" : "160042588768972800",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #visitUS what about Missouri? #2011WorldChamps http:\/\/t.co\/Du6IzgDO",
    "id" : 160042588768972800,
    "created_at" : "2012-01-19 16:55:03 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Holdwynate",
      "screen_name" : "Holdwynate",
      "protected" : false,
      "id_str" : "329133433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699430991853522944\/Akgwvsk6_normal.jpg",
      "id" : 329133433,
      "verified" : false
    }
  },
  "id" : 160042875562893312,
  "created_at" : "2012-01-19 16:56:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disney",
      "screen_name" : "Disney",
      "indices" : [ 88, 95 ],
      "id_str" : "67418441",
      "id" : 67418441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "160041797144428545",
  "text" : "Live @ 12:35ET: President Obama announces plan to help boost tourism & the economy from @Disney World. Watch: http:\/\/t.co\/u95y7hhB #visitUS",
  "id" : 160041797144428545,
  "created_at" : "2012-01-19 16:51:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wham!",
      "screen_name" : "lastphrontier",
      "indices" : [ 3, 17 ],
      "id_str" : "200347380",
      "id" : 200347380
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lastphrontier\/status\/160039617284947968\/photo\/1",
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/wtG8fOxl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiTLxqCQAAj6Oa.jpg",
      "id_str" : "160039617289142272",
      "id" : 160039617289142272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiTLxqCQAAj6Oa.jpg",
      "sizes" : [ {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 468
      } ],
      "display_url" : "pic.twitter.com\/wtG8fOxl"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160039904074678273",
  "text" : "RT @lastphrontier: How about Alaska?  #visitUS http:\/\/t.co\/wtG8fOxl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lastphrontier\/status\/160039617284947968\/photo\/1",
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/wtG8fOxl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiTLxqCQAAj6Oa.jpg",
        "id_str" : "160039617289142272",
        "id" : 160039617289142272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiTLxqCQAAj6Oa.jpg",
        "sizes" : [ {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 468
        } ],
        "display_url" : "pic.twitter.com\/wtG8fOxl"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 19, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160039617284947968",
    "text" : "How about Alaska?  #visitUS http:\/\/t.co\/wtG8fOxl",
    "id" : 160039617284947968,
    "created_at" : "2012-01-19 16:43:13 +0000",
    "user" : {
      "name" : "wham!",
      "screen_name" : "lastphrontier",
      "protected" : false,
      "id_str" : "200347380",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657243040436744193\/DDR_tlbs_normal.jpg",
      "id" : 200347380,
      "verified" : false
    }
  },
  "id" : 160039904074678273,
  "created_at" : "2012-01-19 16:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netzac Trizacon",
      "screen_name" : "netzacon",
      "indices" : [ 3, 12 ],
      "id_str" : "266240527",
      "id" : 266240527
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/netzacon\/status\/160038074200498176\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Ojqaa9pp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiRx9PCIAAZq1_.jpg",
      "id_str" : "160038074208886784",
      "id" : 160038074208886784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiRx9PCIAAZq1_.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/Ojqaa9pp"
    } ],
    "hashtags" : [ {
      "text" : "Anchorage",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "Alaska",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "VisitUS",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160039356063682561",
  "text" : "RT @netzacon: @whitehouse Antlerless Caribous made of Ice make #Anchorage #Alaska Beautiful In the Winter. #VisitUS \n http:\/\/t.co\/Ojqaa9pp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/netzacon\/status\/160038074200498176\/photo\/1",
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/Ojqaa9pp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiRx9PCIAAZq1_.jpg",
        "id_str" : "160038074208886784",
        "id" : 160038074208886784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiRx9PCIAAZq1_.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/Ojqaa9pp"
      } ],
      "hashtags" : [ {
        "text" : "Anchorage",
        "indices" : [ 49, 59 ]
      }, {
        "text" : "Alaska",
        "indices" : [ 60, 67 ]
      }, {
        "text" : "VisitUS",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160039010574671872",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Antlerless Caribous made of Ice make #Anchorage #Alaska Beautiful In the Winter. #VisitUS \n http:\/\/t.co\/Ojqaa9pp",
    "id" : 160039010574671872,
    "created_at" : "2012-01-19 16:40:48 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Netzac Trizacon",
      "screen_name" : "netzacon",
      "protected" : false,
      "id_str" : "266240527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2229871239\/robot-lurking_normal.jpg",
      "id" : 266240527,
      "verified" : false
    }
  },
  "id" : 160039356063682561,
  "created_at" : "2012-01-19 16:42:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Morales",
      "screen_name" : "sosaysjonathan",
      "indices" : [ 19, 34 ],
      "id_str" : "55321526",
      "id" : 55321526
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/upKOMWh9",
      "expanded_url" : "http:\/\/yfrog.com\/gytiozij",
      "display_url" : "yfrog.com\/gytiozij"
    } ]
  },
  "geo" : { },
  "id_str" : "160038966798721024",
  "text" : "Nope! Nice pic. RT @sosaysjonathan San Francisco. Need I say more? http:\/\/t.co\/upKOMWh9 #visitUS",
  "id" : 160038966798721024,
  "created_at" : "2012-01-19 16:40:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New York Guide",
      "screen_name" : "TourguideStan",
      "indices" : [ 3, 17 ],
      "id_str" : "164380239",
      "id" : 164380239
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Manhattan",
      "indices" : [ 39, 49 ]
    }, {
      "text" : "VisitUS",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/g1jzgBxB",
      "expanded_url" : "http:\/\/yfrog.com\/nudhttj",
      "display_url" : "yfrog.com\/nudhttj"
    } ]
  },
  "geo" : { },
  "id_str" : "160037618745229313",
  "text" : "RT @TourguideStan: There are places in #Manhattan that tourists never see. Here's Fort Tryon Park. #VisitUS http:\/\/t.co\/g1jzgBxB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Manhattan",
        "indices" : [ 20, 30 ]
      }, {
        "text" : "VisitUS",
        "indices" : [ 80, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/g1jzgBxB",
        "expanded_url" : "http:\/\/yfrog.com\/nudhttj",
        "display_url" : "yfrog.com\/nudhttj"
      } ]
    },
    "geo" : { },
    "id_str" : "160037332706271232",
    "text" : "There are places in #Manhattan that tourists never see. Here's Fort Tryon Park. #VisitUS http:\/\/t.co\/g1jzgBxB",
    "id" : 160037332706271232,
    "created_at" : "2012-01-19 16:34:08 +0000",
    "user" : {
      "name" : "New York Guide",
      "screen_name" : "TourguideStan",
      "protected" : false,
      "id_str" : "164380239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793526783807217665\/sAWJllWH_normal.jpg",
      "id" : 164380239,
      "verified" : false
    }
  },
  "id" : 160037618745229313,
  "created_at" : "2012-01-19 16:35:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill McShane",
      "screen_name" : "bmcshane5",
      "indices" : [ 3, 13 ],
      "id_str" : "272210732",
      "id" : 272210732
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 85, 96 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bmcshane5\/status\/160035243829628929\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/LtLq2bvT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiPNNSCEAE3PmU.jpg",
      "id_str" : "160035243838017537",
      "id" : 160035243838017537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiPNNSCEAE3PmU.jpg",
      "sizes" : [ {
        "h" : 613,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1552,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/LtLq2bvT"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 97, 105 ]
    }, {
      "text" : "Pittsburgh",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160035753957654528",
  "text" : "RT @bmcshane5: Sunsets off the Hot Metal Bridge, Primanti Brothers, Carnegie museums @whitehouse #visitUS #Pittsburgh http:\/\/t.co\/LtLq2bvT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 70, 81 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bmcshane5\/status\/160035243829628929\/photo\/1",
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/LtLq2bvT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiPNNSCEAE3PmU.jpg",
        "id_str" : "160035243838017537",
        "id" : 160035243838017537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiPNNSCEAE3PmU.jpg",
        "sizes" : [ {
          "h" : 613,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1552,
          "resize" : "fit",
          "w" : 2592
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/LtLq2bvT"
      } ],
      "hashtags" : [ {
        "text" : "visitUS",
        "indices" : [ 82, 90 ]
      }, {
        "text" : "Pittsburgh",
        "indices" : [ 91, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160035243829628929",
    "text" : "Sunsets off the Hot Metal Bridge, Primanti Brothers, Carnegie museums @whitehouse #visitUS #Pittsburgh http:\/\/t.co\/LtLq2bvT",
    "id" : 160035243829628929,
    "created_at" : "2012-01-19 16:25:51 +0000",
    "user" : {
      "name" : "Bill McShane",
      "screen_name" : "bmcshane5",
      "protected" : false,
      "id_str" : "272210732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541460223\/295085_10150264421793583_647228582_7797628_5060965_n_normal.jpg",
      "id" : 272210732,
      "verified" : false
    }
  },
  "id" : 160035753957654528,
  "created_at" : "2012-01-19 16:27:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Kenyon",
      "screen_name" : "giddywithglee",
      "indices" : [ 3, 17 ],
      "id_str" : "256613166",
      "id" : 256613166
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CentralPA",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "visitUS",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160035543185506306",
  "text" : "RT @giddywithglee: @whitehouse Visit #CentralPA because we ARE the sweetest place on earth, and masters of the woopie pie! #visitUS http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/giddywithglee\/status\/160035013507821568\/photo\/1",
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/WHuFoDmK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiO_zQCMAIu2-4.jpg",
        "id_str" : "160035013512015874",
        "id" : 160035013512015874,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiO_zQCMAIu2-4.jpg",
        "sizes" : [ {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/WHuFoDmK"
      } ],
      "hashtags" : [ {
        "text" : "CentralPA",
        "indices" : [ 18, 28 ]
      }, {
        "text" : "visitUS",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160035013507821568",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Visit #CentralPA because we ARE the sweetest place on earth, and masters of the woopie pie! #visitUS http:\/\/t.co\/WHuFoDmK",
    "id" : 160035013507821568,
    "created_at" : "2012-01-19 16:24:55 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Allen Kenyon",
      "screen_name" : "giddywithglee",
      "protected" : false,
      "id_str" : "256613166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672805704172900353\/HM7Je8N8_normal.jpg",
      "id" : 256613166,
      "verified" : false
    }
  },
  "id" : 160035543185506306,
  "created_at" : "2012-01-19 16:27:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/160033387170639872\/photo\/1",
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/p1XKfIR6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjiNhIrCMAAfuTy.jpg",
      "id_str" : "160033387174834176",
      "id" : 160033387174834176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjiNhIrCMAAfuTy.jpg",
      "sizes" : [ {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/p1XKfIR6"
    } ],
    "hashtags" : [ {
      "text" : "visitUS",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160033387170639872",
  "text" : "What makes your city or town a great place to visit? Use #visitUS to share photos & explain why. http:\/\/t.co\/p1XKfIR6",
  "id" : 160033387170639872,
  "created_at" : "2012-01-19 16:18:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/160003948491710467\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/iZx1J4fo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjhyvlDCIAA5EVL.jpg",
      "id_str" : "160003948495904768",
      "id" : 160003948495904768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjhyvlDCIAA5EVL.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iZx1J4fo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160003948491710467",
  "text" : "Photo of the Day: President Obama talks to WH Counsel Kathryn Ruemmler in the Oval Office: http:\/\/t.co\/iZx1J4fo",
  "id" : 160003948491710467,
  "created_at" : "2012-01-19 14:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160003880158105602",
  "text" : "RT @pfeiffer44: President Obama heads to Disney World today to talk about executive actions to create jobs through increased travel and  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160003553207926785",
    "text" : "President Obama heads to Disney World today to talk about executive actions to create jobs through increased travel and tourism",
    "id" : 160003553207926785,
    "created_at" : "2012-01-19 14:19:54 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 160003880158105602,
  "created_at" : "2012-01-19 14:21:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Keystone",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/gw7cc7nd",
      "expanded_url" : "http:\/\/wh.gov\/B57",
      "display_url" : "wh.gov\/B57"
    } ]
  },
  "geo" : { },
  "id_str" : "159825575782002688",
  "text" : "GOP decision to deny #Keystone does not change Obama Administration\u2019s commitment to American-made energy. Statement: http:\/\/t.co\/gw7cc7nd",
  "id" : 159825575782002688,
  "created_at" : "2012-01-19 02:32:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Code for America",
      "screen_name" : "codeforamerica",
      "indices" : [ 59, 74 ],
      "id_str" : "64482503",
      "id" : 64482503
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AppsforHeroes",
      "indices" : [ 18, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159785048814518274",
  "text" : "RT @aneeshchopra: #AppsforHeroes event w\/ Dr. Jill Biden & @codeforamerica. Thx to everyone that's stepped up to help our vets find jobs ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Code for America",
        "screen_name" : "codeforamerica",
        "indices" : [ 41, 56 ],
        "id_str" : "64482503",
        "id" : 64482503
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AppsforHeroes",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/L41o6eop",
        "expanded_url" : "http:\/\/1.usa.gov\/wdOEYV",
        "display_url" : "1.usa.gov\/wdOEYV"
      } ]
    },
    "geo" : { },
    "id_str" : "159768035442429953",
    "text" : "#AppsforHeroes event w\/ Dr. Jill Biden & @codeforamerica. Thx to everyone that's stepped up to help our vets find jobs! http:\/\/t.co\/L41o6eop",
    "id" : 159768035442429953,
    "created_at" : "2012-01-18 22:44:02 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 159785048814518274,
  "created_at" : "2012-01-18 23:51:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOPA",
      "indices" : [ 93, 98 ]
    }, {
      "text" : "PIPA",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "OPEN",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/45mKbpuw",
      "expanded_url" : "http:\/\/1.usa.gov\/zXwogY",
      "display_url" : "1.usa.gov\/zXwogY"
    } ]
  },
  "geo" : { },
  "id_str" : "159716955232800768",
  "text" : "Combating Online Piracy while Protecting an Open & Innovative Internet: http:\/\/t.co\/45mKbpuw #SOPA #PIPA #OPEN",
  "id" : 159716955232800768,
  "created_at" : "2012-01-18 19:21:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/AbcsWQZO",
      "expanded_url" : "http:\/\/wh.gov\/B0X",
      "display_url" : "wh.gov\/B0X"
    } ]
  },
  "geo" : { },
  "id_str" : "159656034800111616",
  "text" : "RT @jesseclee44: New report: 28 States have taken important steps on their own Exchanges for health reform http:\/\/t.co\/AbcsWQZO #hcr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 111, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/AbcsWQZO",
        "expanded_url" : "http:\/\/wh.gov\/B0X",
        "display_url" : "wh.gov\/B0X"
      } ]
    },
    "geo" : { },
    "id_str" : "159655112753676288",
    "text" : "New report: 28 States have taken important steps on their own Exchanges for health reform http:\/\/t.co\/AbcsWQZO #hcr",
    "id" : 159655112753676288,
    "created_at" : "2012-01-18 15:15:19 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 159656034800111616,
  "created_at" : "2012-01-18 15:18:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 41, 46 ]
    }, {
      "text" : "whtweetup",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/n1Hl3nRv",
      "expanded_url" : "http:\/\/wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "159482512362577920",
  "text" : "Want to come to the @whitehouse to watch #SOTU & attend a policy panel? Just 1 hour left to apply for the #whtweetup: http:\/\/t.co\/n1Hl3nRv",
  "id" : 159482512362577920,
  "created_at" : "2012-01-18 03:49:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "St. Louis Cardinals",
      "screen_name" : "Cardinals",
      "indices" : [ 78, 88 ],
      "id_str" : "52847728",
      "id" : 52847728
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/159479562282090496\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/8DKleuc8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjaV0SMCQAEwRSV.jpg",
      "id_str" : "159479562286284801",
      "id" : 159479562286284801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjaV0SMCQAEwRSV.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8DKleuc8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/ZqaRCqqn",
      "expanded_url" : "http:\/\/wh.gov\/BZs",
      "display_url" : "wh.gov\/BZs"
    } ]
  },
  "geo" : { },
  "id_str" : "159479562282090496",
  "text" : "President Obama honors \"greatest comeback team\" in baseball history St. Louis @Cardinals @ the WH: http:\/\/t.co\/ZqaRCqqn http:\/\/t.co\/8DKleuc8",
  "id" : 159479562282090496,
  "created_at" : "2012-01-18 03:37:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 18, 21 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Girard College",
      "screen_name" : "GirardCollege",
      "indices" : [ 81, 95 ],
      "id_str" : "268088958",
      "id" : 268088958
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/159472622537687043\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/AFhhgwtC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjaPgVpCQAAMUOD.jpg",
      "id_str" : "159472622546075648",
      "id" : 159472622546075648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjaPgVpCQAAMUOD.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AFhhgwtC"
    } ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 62, 69 ]
    }, {
      "text" : "Philadelphia",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159472622537687043",
  "text" : "Photo of the Day: @VP Biden & Dr. Jill Biden package food for #MLKDay of Service @girardcollege in #Philadelphia: http:\/\/t.co\/AFhhgwtC",
  "id" : 159472622537687043,
  "created_at" : "2012-01-18 03:10:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 61, 72 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/cFaQrKqI",
      "expanded_url" : "http:\/\/ow.ly\/8x7A6",
      "display_url" : "ow.ly\/8x7A6"
    } ]
  },
  "geo" : { },
  "id_str" : "159441369931333632",
  "text" : "President Obama meets with King Abdullah II of Jordan at the @WhiteHouse: http:\/\/t.co\/cFaQrKqI",
  "id" : 159441369931333632,
  "created_at" : "2012-01-18 01:05:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159432150473654272",
  "text" : "RT @ks44: Have you signed up for the State of the Union #WHTweetup yet? Registration closes tonight @ midnight. Apply here: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 46, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/6aE20pAu",
        "expanded_url" : "http:\/\/wh.gov\/tweetup",
        "display_url" : "wh.gov\/tweetup"
      } ]
    },
    "geo" : { },
    "id_str" : "159432085860388865",
    "text" : "Have you signed up for the State of the Union #WHTweetup yet? Registration closes tonight @ midnight. Apply here: http:\/\/t.co\/6aE20pAu",
    "id" : 159432085860388865,
    "created_at" : "2012-01-18 00:29:06 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 159432150473654272,
  "created_at" : "2012-01-18 00:29:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/J2w5eIyd",
      "expanded_url" : "http:\/\/apne.ws\/2312gF",
      "display_url" : "apne.ws\/2312gF"
    } ]
  },
  "geo" : { },
  "id_str" : "159391669958098945",
  "text" : "RT @jesseclee44: More rubber hitting road in Wall St Reform... AP: \"Big banks must show break-up plans under new rule\" http:\/\/t.co\/J2w5eIyd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/J2w5eIyd",
        "expanded_url" : "http:\/\/apne.ws\/2312gF",
        "display_url" : "apne.ws\/2312gF"
      } ]
    },
    "geo" : { },
    "id_str" : "159390919664209920",
    "text" : "More rubber hitting road in Wall St Reform... AP: \"Big banks must show break-up plans under new rule\" http:\/\/t.co\/J2w5eIyd",
    "id" : 159390919664209920,
    "created_at" : "2012-01-17 21:45:31 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 159391669958098945,
  "created_at" : "2012-01-17 21:48:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "St. Louis Cardinals",
      "screen_name" : "Cardinals",
      "indices" : [ 41, 51 ],
      "id_str" : "52847728",
      "id" : 52847728
    }, {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 55, 60 ],
      "id_str" : "41144996",
      "id" : 41144996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/z59SlqHM",
      "expanded_url" : "http:\/\/joiningforces.gov",
      "display_url" : "joiningforces.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "159379933028818945",
  "text" : "RT @JoiningForces: No matter if you\u2019re a @Cardinals or @Cubs fan (like me), we all can give back to our troops: http:\/\/t.co\/z59SlqHM \u2013mo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "St. Louis Cardinals",
        "screen_name" : "Cardinals",
        "indices" : [ 22, 32 ],
        "id_str" : "52847728",
        "id" : 52847728
      }, {
        "name" : "Chicago Cubs",
        "screen_name" : "Cubs",
        "indices" : [ 36, 41 ],
        "id_str" : "41144996",
        "id" : 41144996
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/159379432618999808\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/B6wcL9NC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjY6v-ICQAAPd9Q.jpg",
        "id_str" : "159379432623194112",
        "id" : 159379432623194112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjY6v-ICQAAPd9Q.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/B6wcL9NC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/z59SlqHM",
        "expanded_url" : "http:\/\/joiningforces.gov",
        "display_url" : "joiningforces.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "159379432618999808",
    "text" : "No matter if you\u2019re a @Cardinals or @Cubs fan (like me), we all can give back to our troops: http:\/\/t.co\/z59SlqHM \u2013mo http:\/\/t.co\/B6wcL9NC",
    "id" : 159379432618999808,
    "created_at" : "2012-01-17 20:59:53 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 159379933028818945,
  "created_at" : "2012-01-17 21:01:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 80, 91 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STLCards",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "159372801034289153",
  "text" : "Happening now: The President & First Lady honor World Champion #STLCards at the @WhiteHouse. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 159372801034289153,
  "created_at" : "2012-01-17 20:33:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159370371336896513",
  "text" : "RT @OMBPress: POTUS designates Jeff Zients Acting Director of OMB.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159369515015208961",
    "text" : "POTUS designates Jeff Zients Acting Director of OMB.",
    "id" : 159369515015208961,
    "created_at" : "2012-01-17 20:20:27 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 159370371336896513,
  "created_at" : "2012-01-17 20:23:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "St. Louis Cardinals",
      "screen_name" : "Cardinals",
      "indices" : [ 88, 98 ],
      "id_str" : "52847728",
      "id" : 52847728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "159362031051476992",
  "text" : "Happening @ 3ET: President Obama & the First Lady honor World Series Champion St. Louis @Cardinals. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 159362031051476992,
  "created_at" : "2012-01-17 19:50:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "St. Louis Cardinals",
      "screen_name" : "Cardinals",
      "indices" : [ 38, 48 ],
      "id_str" : "52847728",
      "id" : 52847728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159347803267665920",
  "text" : "RT @JoiningForces: World Series Champ @Cardinals are #AtTheWH today. Watch Mrs. Obama @ Game 1 in St. Louis to support military families ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "St. Louis Cardinals",
        "screen_name" : "Cardinals",
        "indices" : [ 19, 29 ],
        "id_str" : "52847728",
        "id" : 52847728
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AtTheWH",
        "indices" : [ 34, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/6VVkQjHv",
        "expanded_url" : "http:\/\/ow.ly\/8wzbU",
        "display_url" : "ow.ly\/8wzbU"
      } ]
    },
    "geo" : { },
    "id_str" : "159346593752023041",
    "text" : "World Series Champ @Cardinals are #AtTheWH today. Watch Mrs. Obama @ Game 1 in St. Louis to support military families: http:\/\/t.co\/6VVkQjHv",
    "id" : 159346593752023041,
    "created_at" : "2012-01-17 18:49:23 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 159347803267665920,
  "created_at" : "2012-01-17 18:54:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 56, 67 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 20, 30 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/n1Hl3nRv",
      "expanded_url" : "http:\/\/wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "159300887506984960",
  "text" : "Announcing our next #WHTweetup: Watch #SOTU live at the @WhiteHouse & attend a panel with admin officials after. Apply: http:\/\/t.co\/n1Hl3nRv",
  "id" : 159300887506984960,
  "created_at" : "2012-01-17 15:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/159064744341413888\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/eJi7OHwn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjUcis9CIAA1BEJ.jpg",
      "id_str" : "159064744349802496",
      "id" : 159064744349802496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjUcis9CIAA1BEJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/eJi7OHwn"
    } ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/7TL5X23W",
      "expanded_url" : "http:\/\/wh.gov\/blog\/2012\/01\/16\/first-and-second-families-participate-national-day-service",
      "display_url" : "wh.gov\/blog\/2012\/01\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159064744341413888",
  "text" : "Photo of the Day: The Obama family volunteers @ a local elementary school for #MLKDay of service: http:\/\/t.co\/7TL5X23W http:\/\/t.co\/eJi7OHwn",
  "id" : 159064744341413888,
  "created_at" : "2012-01-17 00:09:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "iCarly",
      "screen_name" : "iCarly",
      "indices" : [ 48, 55 ],
      "id_str" : "37008705",
      "id" : 37008705
    }, {
      "name" : "Nickelodeon",
      "screen_name" : "NickelodeonTV",
      "indices" : [ 65, 79 ],
      "id_str" : "58309829",
      "id" : 58309829
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 94, 108 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159057405202808833",
  "text" : "RT @JoiningForces: Don't miss the First Lady on @iCarly tonight! @NickelodeonTV teams up with @JoiningForces to support military kids: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iCarly",
        "screen_name" : "iCarly",
        "indices" : [ 29, 36 ],
        "id_str" : "37008705",
        "id" : 37008705
      }, {
        "name" : "Nickelodeon",
        "screen_name" : "NickelodeonTV",
        "indices" : [ 46, 60 ],
        "id_str" : "58309829",
        "id" : 58309829
      }, {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 75, 89 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/0H37CsgN",
        "expanded_url" : "http:\/\/ow.ly\/8vCqe",
        "display_url" : "ow.ly\/8vCqe"
      } ]
    },
    "geo" : { },
    "id_str" : "159057299435040768",
    "text" : "Don't miss the First Lady on @iCarly tonight! @NickelodeonTV teams up with @JoiningForces to support military kids: http:\/\/t.co\/0H37CsgN",
    "id" : 159057299435040768,
    "created_at" : "2012-01-16 23:39:49 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 159057405202808833,
  "created_at" : "2012-01-16 23:40:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 34, 50 ],
      "id_str" : "17961886",
      "id" : 17961886
    }, {
      "name" : "The Root",
      "screen_name" : "theroot247",
      "indices" : [ 53, 64 ],
      "id_str" : "2293123297",
      "id" : 2293123297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 3, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/7r35mneE",
      "expanded_url" : "http:\/\/ow.ly\/8vq7U",
      "display_url" : "ow.ly\/8vq7U"
    } ]
  },
  "geo" : { },
  "id_str" : "159012005280366592",
  "text" : "On #MLKDay & throughout the year, @nationalservice & @TheRoot247 are honoring \"Drum Majors for Service\": http:\/\/t.co\/7r35mneE",
  "id" : 159012005280366592,
  "created_at" : "2012-01-16 20:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/yFz1Ii37",
      "expanded_url" : "http:\/\/ow.ly\/8voVM",
      "display_url" : "ow.ly\/8voVM"
    } ]
  },
  "geo" : { },
  "id_str" : "159007677320671232",
  "text" : "From the Archives: President Reagan designates Martin Luther King, Jr. Day a Federal Holiday: http:\/\/t.co\/yFz1Ii37 #MLKDay",
  "id" : 159007677320671232,
  "created_at" : "2012-01-16 20:22:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "indices" : [ 3, 10 ],
      "id_str" : "17001730",
      "id" : 17001730
    }, {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 84, 96 ],
      "id_str" : "59204932",
      "id" : 59204932
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159006676572311552",
  "text" : "RT @MLKDay: For those wondering how to keep spirit of #MLKDay year-round, check out @ServeDotGov. They connect Americans to service oppo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "United We Serve",
        "screen_name" : "ServeDotGov",
        "indices" : [ 72, 84 ],
        "id_str" : "59204932",
        "id" : 59204932
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 42, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159005308381970432",
    "text" : "For those wondering how to keep spirit of #MLKDay year-round, check out @ServeDotGov. They connect Americans to service opportunities 365",
    "id" : 159005308381970432,
    "created_at" : "2012-01-16 20:13:14 +0000",
    "user" : {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "protected" : false,
      "id_str" : "17001730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556146916442902528\/Cu6dRDjT_normal.jpeg",
      "id" : 17001730,
      "verified" : false
    }
  },
  "id" : 159006676572311552,
  "created_at" : "2012-01-16 20:18:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/158943634316734464\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/2IHv6sxk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjSuZK9CMAAHQIl.jpg",
      "id_str" : "158943634325123072",
      "id" : 158943634325123072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjSuZK9CMAAHQIl.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/2IHv6sxk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158949709757693953",
  "text" : "RT @VP: PHOTO: VP and Dr. B. packed boxes at the 17th annual Greater Philadelphia MLK Day of Service @ Girard College http:\/\/t.co\/2IHv6sxk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/158943634316734464\/photo\/1",
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/2IHv6sxk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjSuZK9CMAAHQIl.jpg",
        "id_str" : "158943634325123072",
        "id" : 158943634325123072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjSuZK9CMAAHQIl.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/2IHv6sxk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158943634316734464",
    "text" : "PHOTO: VP and Dr. B. packed boxes at the 17th annual Greater Philadelphia MLK Day of Service @ Girard College http:\/\/t.co\/2IHv6sxk",
    "id" : 158943634316734464,
    "created_at" : "2012-01-16 16:08:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 158949709757693953,
  "created_at" : "2012-01-16 16:32:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158949562076233729",
  "text" : "RT @VP: Out of every difficult moment in American history we have come out stronger, better, fairer; we\u2019ve come out more just-VP@ MLK Da ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158947119837888513",
    "text" : "Out of every difficult moment in American history we have come out stronger, better, fairer; we\u2019ve come out more just-VP@ MLK Day of Service",
    "id" : 158947119837888513,
    "created_at" : "2012-01-16 16:22:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 158949562076233729,
  "created_at" : "2012-01-16 16:31:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House History",
      "screen_name" : "WhiteHouseHstry",
      "indices" : [ 3, 19 ],
      "id_str" : "106448460",
      "id" : 106448460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158929292552712192",
  "text" : "RT @WhiteHouseHstry: Honoring Martin Luther King, Jr.: Historic Photos of the Civil Rights Leader at the White House http:\/\/t.co\/v2MXOKF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLK",
        "indices" : [ 117, 121 ]
      }, {
        "text" : "history",
        "indices" : [ 122, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/v2MXOKFz",
        "expanded_url" : "http:\/\/ow.ly\/8sg1A",
        "display_url" : "ow.ly\/8sg1A"
      } ]
    },
    "geo" : { },
    "id_str" : "158929054098128897",
    "text" : "Honoring Martin Luther King, Jr.: Historic Photos of the Civil Rights Leader at the White House http:\/\/t.co\/v2MXOKFz #MLK #history",
    "id" : 158929054098128897,
    "created_at" : "2012-01-16 15:10:13 +0000",
    "user" : {
      "name" : "White House History",
      "screen_name" : "WhiteHouseHstry",
      "protected" : false,
      "id_str" : "106448460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1877740109\/twittericonenlarged_normal.jpg",
      "id" : 106448460,
      "verified" : true
    }
  },
  "id" : 158929292552712192,
  "created_at" : "2012-01-16 15:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/AE1XzkbK",
      "expanded_url" : "http:\/\/ow.ly\/8uUGr",
      "display_url" : "ow.ly\/8uUGr"
    } ]
  },
  "geo" : { },
  "id_str" : "158929207118925825",
  "text" : "\"We honor this man because he had faith in us\" -President Obama @ the Martin Luther King, Jr. Memorial dedication: http:\/\/t.co\/AE1XzkbK",
  "id" : 158929207118925825,
  "created_at" : "2012-01-16 15:10:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 109, 123 ]
    }, {
      "text" : "Insourcing",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/h9Vnr48c",
      "expanded_url" : "http:\/\/ow.ly\/8u6Hs",
      "display_url" : "ow.ly\/8u6Hs"
    } ]
  },
  "geo" : { },
  "id_str" : "158638986934497280",
  "text" : "What do a padlock, a pair of boots & a candle have in common? President Obama explains: http:\/\/t.co\/h9Vnr48c #MadeInAmerica #Insourcing",
  "id" : 158638986934497280,
  "created_at" : "2012-01-15 19:57:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/zGUqR27G",
      "expanded_url" : "http:\/\/bit.ly\/xP1b73",
      "display_url" : "bit.ly\/xP1b73"
    } ]
  },
  "geo" : { },
  "id_str" : "158634419387772928",
  "text" : "RT @petesouza: Photo of the Obama family at Zion Baptist Church today: http:\/\/t.co\/zGUqR27G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/zGUqR27G",
        "expanded_url" : "http:\/\/bit.ly\/xP1b73",
        "display_url" : "bit.ly\/xP1b73"
      } ]
    },
    "geo" : { },
    "id_str" : "158622649667428352",
    "text" : "Photo of the Obama family at Zion Baptist Church today: http:\/\/t.co\/zGUqR27G",
    "id" : 158622649667428352,
    "created_at" : "2012-01-15 18:52:41 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 158634419387772928,
  "created_at" : "2012-01-15 19:39:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/CU60WHsz",
      "expanded_url" : "http:\/\/ow.ly\/8tvrr",
      "display_url" : "ow.ly\/8tvrr"
    } ]
  },
  "geo" : { },
  "id_str" : "158262198999842817",
  "text" : "\"You\u2019ve heard of outsourcing \u2013 well, this is #insourcing\" -President Obama in his Weekly Address: http:\/\/t.co\/CU60WHsz",
  "id" : 158262198999842817,
  "created_at" : "2012-01-14 19:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "indices" : [ 3, 10 ],
      "id_str" : "17001730",
      "id" : 17001730
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 91, 98 ]
    }, {
      "text" : "MLK",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158237436168777729",
  "text" : "RT @MLKDay: Dr. King once said, \"Everybody can be great, because everyone can serve\". This #MLKDay how will you be great & serve? #MLK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 79, 86 ]
      }, {
        "text" : "MLK",
        "indices" : [ 118, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158228236554354689",
    "text" : "Dr. King once said, \"Everybody can be great, because everyone can serve\". This #MLKDay how will you be great & serve? #MLK",
    "id" : 158228236554354689,
    "created_at" : "2012-01-14 16:45:25 +0000",
    "user" : {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "protected" : false,
      "id_str" : "17001730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556146916442902528\/Cu6dRDjT_normal.jpeg",
      "id" : 17001730,
      "verified" : false
    }
  },
  "id" : 158237436168777729,
  "created_at" : "2012-01-14 17:21:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 56, 68 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOPA",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158202568164638721",
  "text" : "RT @JonCarson44: Ever wondered if White House is taking @WeThePeople seriously? We are. This #SOPA petition made a big difference http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 39, 51 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOPA",
        "indices" : [ 76, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/QPI4xhhl",
        "expanded_url" : "http:\/\/bit.ly\/wWW82s",
        "display_url" : "bit.ly\/wWW82s"
      } ]
    },
    "geo" : { },
    "id_str" : "158202259468058625",
    "text" : "Ever wondered if White House is taking @WeThePeople seriously? We are. This #SOPA petition made a big difference http:\/\/t.co\/QPI4xhhl",
    "id" : 158202259468058625,
    "created_at" : "2012-01-14 15:02:12 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 158202568164638721,
  "created_at" : "2012-01-14 15:03:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 37, 49 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sopa",
      "indices" : [ 53, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158194299136245760",
  "text" : "RT @aneeshchopra: Thx for your input @ginatrapani on #sopa - you, and many others, have asked for our views and we've responded - http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina Trapani",
        "screen_name" : "ginatrapani",
        "indices" : [ 19, 31 ],
        "id_str" : "930061",
        "id" : 930061
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sopa",
        "indices" : [ 35, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/goIOeJJa",
        "expanded_url" : "http:\/\/bit.ly\/y8ihzu",
        "display_url" : "bit.ly\/y8ihzu"
      } ]
    },
    "geo" : { },
    "id_str" : "158182714439245824",
    "text" : "Thx for your input @ginatrapani on #sopa - you, and many others, have asked for our views and we've responded - http:\/\/t.co\/goIOeJJa",
    "id" : 158182714439245824,
    "created_at" : "2012-01-14 13:44:32 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 158194299136245760,
  "created_at" : "2012-01-14 14:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 94, 106 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sopa",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/ce72OoKr",
      "expanded_url" : "http:\/\/bit.ly\/y8ihzu",
      "display_url" : "bit.ly\/y8ihzu"
    } ]
  },
  "geo" : { },
  "id_str" : "158178416653385730",
  "text" : "\"Any effort to combat online piracy must guard against the risk of online censorship...\" More @WeThePeople: http:\/\/t.co\/ce72OoKr #sopa",
  "id" : 158178416653385730,
  "created_at" : "2012-01-14 13:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/157943418356633600\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Wz99BgUS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjEgs8ICEAAXHqB.jpg",
      "id_str" : "157943418360827904",
      "id" : 157943418360827904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjEgs8ICEAAXHqB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Wz99BgUS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/DPYwR1xl",
      "expanded_url" : "http:\/\/wh.gov\/Z48",
      "display_url" : "wh.gov\/Z48"
    } ]
  },
  "geo" : { },
  "id_str" : "157943418356633600",
  "text" : "Today, President Obama announced a new plan that will make it easier to do business in America: http:\/\/t.co\/DPYwR1xl http:\/\/t.co\/Wz99BgUS",
  "id" : 157943418356633600,
  "created_at" : "2012-01-13 21:53:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/H1cedG5Y",
      "expanded_url" : "http:\/\/ow.ly\/8sU3z",
      "display_url" : "ow.ly\/8sU3z"
    } ]
  },
  "geo" : { },
  "id_str" : "157933837903597570",
  "text" : "President Obama on #MLKDay: \"We celebrate the man who fought for the America he knew was possible\" Proclamation: http:\/\/t.co\/H1cedG5Y",
  "id" : 157933837903597570,
  "created_at" : "2012-01-13 21:15:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157933715618660352",
  "text" : "RT @JonCarson44: .@JrCubaGooding @servedotgov @mlkday looking forward to talking about #mlkday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "United We Serve",
        "screen_name" : "ServeDotGov",
        "indices" : [ 16, 28 ],
        "id_str" : "59204932",
        "id" : 59204932
      }, {
        "name" : "MLK Day",
        "screen_name" : "MLKDay",
        "indices" : [ 29, 36 ],
        "id_str" : "17001730",
        "id" : 17001730
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mlkday",
        "indices" : [ 70, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157930928029700097",
    "text" : ".@JrCubaGooding @servedotgov @mlkday looking forward to talking about #mlkday",
    "id" : 157930928029700097,
    "created_at" : "2012-01-13 21:04:02 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 157933715618660352,
  "created_at" : "2012-01-13 21:15:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biz",
      "indices" : [ 91, 95 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/h0HilpAy",
      "expanded_url" : "http:\/\/owl.li\/8sMzK",
      "display_url" : "owl.li\/8sMzK"
    } ]
  },
  "geo" : { },
  "id_str" : "157919747323867136",
  "text" : "RT @SBAgov: Here\u2019s more info from Pres. Obama\u2019s announcement today to make it easier to do #biz in America: http:\/\/t.co\/h0HilpAy #smallbiz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "biz",
        "indices" : [ 79, 83 ]
      }, {
        "text" : "smallbiz",
        "indices" : [ 117, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/h0HilpAy",
        "expanded_url" : "http:\/\/owl.li\/8sMzK",
        "display_url" : "owl.li\/8sMzK"
      } ]
    },
    "geo" : { },
    "id_str" : "157912331832135680",
    "text" : "Here\u2019s more info from Pres. Obama\u2019s announcement today to make it easier to do #biz in America: http:\/\/t.co\/h0HilpAy #smallbiz",
    "id" : 157912331832135680,
    "created_at" : "2012-01-13 19:50:08 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 157919747323867136,
  "created_at" : "2012-01-13 20:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157869668776935424",
  "text" : "RT @jesseclee44: Lot of talk of making govt more streamlined\/consumer-friendly can be fluff-giving small biz 1 dept, 1 phone #, 1 websit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157867158888652800",
    "text" : "Lot of talk of making govt more streamlined\/consumer-friendly can be fluff-giving small biz 1 dept, 1 phone #, 1 website is real improvement",
    "id" : 157867158888652800,
    "created_at" : "2012-01-13 16:50:38 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 157869668776935424,
  "created_at" : "2012-01-13 17:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/157869052340088832\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/GrJ2X1xh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjDdERJCMAAZgeG.jpg",
      "id_str" : "157869052348477440",
      "id" : 157869052348477440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjDdERJCMAAZgeG.jpg",
      "sizes" : [ {
        "h" : 472,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1354,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1354,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 832,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GrJ2X1xh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157869052340088832",
  "text" : "If Congress grants consolidation authority, POTUS can streamline bureaucracy to improve gvt & save $$$. Before & after: http:\/\/t.co\/GrJ2X1xh",
  "id" : 157869052340088832,
  "created_at" : "2012-01-13 16:58:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "iCarly",
      "screen_name" : "iCarly",
      "indices" : [ 72, 79 ],
      "id_str" : "37008705",
      "id" : 37008705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/e2SERM0m",
      "expanded_url" : "http:\/\/www.joiningforces.gov",
      "display_url" : "joiningforces.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "157866318287220738",
  "text" : "RT @JoiningForces: Military kids are strong, resilient, inspiring. Join @iCarly & me to honor our young heroes @ http:\/\/t.co\/e2SERM0m \u2013m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iCarly",
        "screen_name" : "iCarly",
        "indices" : [ 53, 60 ],
        "id_str" : "37008705",
        "id" : 37008705
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/157865488192520192\/photo\/1",
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/nA2Xq0WG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjDZ0zqCQAA0qCG.jpg",
        "id_str" : "157865488200908800",
        "id" : 157865488200908800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjDZ0zqCQAA0qCG.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/nA2Xq0WG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/e2SERM0m",
        "expanded_url" : "http:\/\/www.joiningforces.gov",
        "display_url" : "joiningforces.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "157865488192520192",
    "text" : "Military kids are strong, resilient, inspiring. Join @iCarly & me to honor our young heroes @ http:\/\/t.co\/e2SERM0m \u2013mo http:\/\/t.co\/nA2Xq0WG",
    "id" : 157865488192520192,
    "created_at" : "2012-01-13 16:44:00 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 157866318287220738,
  "created_at" : "2012-01-13 16:47:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157864387825238016",
  "text" : "RT @WHLive: Obama: With the authority I am requesting we could consolidate them all into one department with one website one phone numbe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157863254939549696",
    "text" : "Obama: With the authority I am requesting we could consolidate them all into one department with one website one phone number & one mission.",
    "id" : 157863254939549696,
    "created_at" : "2012-01-13 16:35:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 157864387825238016,
  "created_at" : "2012-01-13 16:39:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157864372671217664",
  "text" : "RT @WHLive: Obama: Right now, there are six departments and agencies focused primarily on business and trade in the federal government.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157862984843141120",
    "text" : "Obama: Right now, there are six departments and agencies focused primarily on business and trade in the federal government.",
    "id" : 157862984843141120,
    "created_at" : "2012-01-13 16:34:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 157864372671217664,
  "created_at" : "2012-01-13 16:39:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157861979351031808",
  "text" : "Obama: And let me be clear: I will only use this authority for reforms that result in more efficiency, better service & a leaner government.",
  "id" : 157861979351031808,
  "created_at" : "2012-01-13 16:30:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157861660365832192",
  "text" : "Obama: I am calling on Congress to reinstate the authority that past presidents have had to streamline and reform the Executive Branch.",
  "id" : 157861660365832192,
  "created_at" : "2012-01-13 16:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 112, 119 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/xI0hVw28",
      "expanded_url" : "http:\/\/ow.ly\/1gHjuG",
      "display_url" : "ow.ly\/1gHjuG"
    } ]
  },
  "geo" : { },
  "id_str" : "157860926706552832",
  "text" : "Starting now: President Obama Speaks on Government Reform from the White House.  http:\/\/t.co\/xI0hVw28 follow on @WHLive",
  "id" : 157860926706552832,
  "created_at" : "2012-01-13 16:25:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/157850505001963520\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/FEIEgYD6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjDMMq6CEAEKwlk.jpg",
      "id_str" : "157850505006157825",
      "id" : 157850505006157825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjDMMq6CEAEKwlk.jpg",
      "sizes" : [ {
        "h" : 741,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 258,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FEIEgYD6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "157850505001963520",
  "text" : "At 11:20 ET, President Obama speaks on government reform. Watch live: http:\/\/t.co\/u95y7hhB See why we need it: http:\/\/t.co\/FEIEgYD6",
  "id" : 157850505001963520,
  "created_at" : "2012-01-13 15:44:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/0ZZCE0zG",
      "expanded_url" : "http:\/\/wh.gov\/BusinessUSA",
      "display_url" : "wh.gov\/BusinessUSA"
    } ]
  },
  "geo" : { },
  "id_str" : "157841770724605952",
  "text" : "RT @pfeiffer44: Here's the problem POTUS is trying to solve with his Government reform plan.Full size: http:\/\/t.co\/0ZZCE0zG Twit size: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pfeiffer44\/status\/157841336190517248\/photo\/1",
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/iT9bjNEz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjDD2-bCQAAxohD.jpg",
        "id_str" : "157841336194711552",
        "id" : 157841336194711552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjDD2-bCQAAxohD.jpg",
        "sizes" : [ {
          "h" : 741,
          "resize" : "fit",
          "w" : 976
        }, {
          "h" : 741,
          "resize" : "fit",
          "w" : 976
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/iT9bjNEz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/0ZZCE0zG",
        "expanded_url" : "http:\/\/wh.gov\/BusinessUSA",
        "display_url" : "wh.gov\/BusinessUSA"
      } ]
    },
    "geo" : { },
    "id_str" : "157841336190517248",
    "text" : "Here's the problem POTUS is trying to solve with his Government reform plan.Full size: http:\/\/t.co\/0ZZCE0zG Twit size: http:\/\/t.co\/iT9bjNEz",
    "id" : 157841336190517248,
    "created_at" : "2012-01-13 15:08:02 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 157841770724605952,
  "created_at" : "2012-01-13 15:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 40, 51 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "157822000042221568",
  "text" : "Watch @ 11:20ET http:\/\/t.co\/u95y7hhB RT @pfeiffer44 Obama makes important announcement today on reorganizing, reforming & consolidating govt",
  "id" : 157822000042221568,
  "created_at" : "2012-01-13 13:51:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/157631846409191426\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/gWnD69xJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjAFVELCQAACjqv.jpg",
      "id_str" : "157631846413385728",
      "id" : 157631846413385728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjAFVELCQAACjqv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/gWnD69xJ"
    } ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/8VbgmS1j",
      "expanded_url" : "http:\/\/wh.gov\/WX9",
      "display_url" : "wh.gov\/WX9"
    } ]
  },
  "geo" : { },
  "id_str" : "157631846409191426",
  "text" : "By the numbers: 130 medical schools have committed to train students to treat #veterans issues: http:\/\/t.co\/8VbgmS1j http:\/\/t.co\/gWnD69xJ",
  "id" : 157631846409191426,
  "created_at" : "2012-01-13 01:15:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157619071301599232",
  "text" : "Welcome to Twitter! RT @MarthaGSA Excited to join the conversation on Twitter! Out in NV talking #jobs, sustainability & GSA\u2019s market share!",
  "id" : 157619071301599232,
  "created_at" : "2012-01-13 00:24:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiti",
      "indices" : [ 52, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/bxlLOO1g",
      "expanded_url" : "http:\/\/ow.ly\/8rF9j",
      "display_url" : "ow.ly\/8rF9j"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/WAJTpobd",
      "expanded_url" : "http:\/\/youtu.be\/49NW0MJO6mc",
      "display_url" : "youtu.be\/49NW0MJO6mc"
    } ]
  },
  "geo" : { },
  "id_str" : "157606182863904768",
  "text" : "From the Archives: A look back at the earthquake in #Haiti 2 yrs ago: http:\/\/t.co\/bxlLOO1g & the First Lady's visit: http:\/\/t.co\/WAJTpobd",
  "id" : 157606182863904768,
  "created_at" : "2012-01-12 23:33:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Revkin",
      "screen_name" : "Revkin",
      "indices" : [ 3, 10 ],
      "id_str" : "11178672",
      "id" : 11178672
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 104, 115 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/TrSzUu8W",
      "expanded_url" : "http:\/\/1.usa.gov\/xAM645",
      "display_url" : "1.usa.gov\/xAM645"
    } ]
  },
  "geo" : { },
  "id_str" : "157580037288247297",
  "text" : "RT @Revkin: Obama's National Ocean Policy Implementation Plan gets good reactions: http:\/\/t.co\/TrSzUu8W @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 92, 103 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/TrSzUu8W",
        "expanded_url" : "http:\/\/1.usa.gov\/xAM645",
        "display_url" : "1.usa.gov\/xAM645"
      } ]
    },
    "geo" : { },
    "id_str" : "157575089842421760",
    "text" : "Obama's National Ocean Policy Implementation Plan gets good reactions: http:\/\/t.co\/TrSzUu8W @whitehouse",
    "id" : 157575089842421760,
    "created_at" : "2012-01-12 21:30:03 +0000",
    "user" : {
      "name" : "Andy Revkin",
      "screen_name" : "Revkin",
      "protected" : false,
      "id_str" : "11178672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433051183289073664\/QCA_FvgX_normal.jpeg",
      "id" : 11178672,
      "verified" : true
    }
  },
  "id" : 157580037288247297,
  "created_at" : "2012-01-12 21:49:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 20, 31 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ohio",
      "indices" : [ 57, 62 ]
    }, {
      "text" : "GLHS",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157564730603606017",
  "text" : "RT @VP: PHOTO: VP & @arneduncan @ Lincoln HS in Gahanna, #Ohio discussing college affordability with students & parents #GLHS http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 12, 23 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/157562939505782784\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/KBttOGIl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai_GqJ9CMAEY3J2.jpg",
        "id_str" : "157562939509977089",
        "id" : 157562939509977089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai_GqJ9CMAEY3J2.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/KBttOGIl"
      } ],
      "hashtags" : [ {
        "text" : "Ohio",
        "indices" : [ 49, 54 ]
      }, {
        "text" : "GLHS",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157562939505782784",
    "text" : "PHOTO: VP & @arneduncan @ Lincoln HS in Gahanna, #Ohio discussing college affordability with students & parents #GLHS http:\/\/t.co\/KBttOGIl",
    "id" : 157562939505782784,
    "created_at" : "2012-01-12 20:41:47 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 157564730603606017,
  "created_at" : "2012-01-12 20:48:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 31, 35 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "Dallas Mavericks",
      "screen_name" : "dallasmavs",
      "indices" : [ 45, 56 ],
      "id_str" : "22185437",
      "id" : 22185437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/8rkXcNNM",
      "expanded_url" : "http:\/\/youtu.be\/qmOGGVMqN7Y",
      "display_url" : "youtu.be\/qmOGGVMqN7Y"
    } ]
  },
  "geo" : { },
  "id_str" : "157557457827270656",
  "text" : "Go behind the scenes with 2011 @NBA Champion @dallasmavs at the White House: http:\/\/t.co\/8rkXcNNM",
  "id" : 157557457827270656,
  "created_at" : "2012-01-12 20:19:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Observer",
      "screen_name" : "theobserver",
      "indices" : [ 1, 13 ],
      "id_str" : "8695932",
      "id" : 8695932
    }, {
      "name" : "Detroit Free Press",
      "screen_name" : "freep",
      "indices" : [ 14, 20 ],
      "id_str" : "8795772",
      "id" : 8795772
    }, {
      "name" : "AJC",
      "screen_name" : "ajc",
      "indices" : [ 21, 25 ],
      "id_str" : "4170491",
      "id" : 4170491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/61WNhRZN",
      "expanded_url" : "http:\/\/wh.gov\/W8F",
      "display_url" : "wh.gov\/W8F"
    } ]
  },
  "geo" : { },
  "id_str" : "157528101297979392",
  "text" : ".@theobserver @freep @ajc & more talking about Obama's #insourcing American jobs forum at the White House: http:\/\/t.co\/61WNhRZN",
  "id" : 157528101297979392,
  "created_at" : "2012-01-12 18:23:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/qfHDIi9L",
      "expanded_url" : "http:\/\/ow.ly\/8r2VA",
      "display_url" : "ow.ly\/8r2VA"
    } ]
  },
  "geo" : { },
  "id_str" : "157485718032224256",
  "text" : "RT @JoiningForces: Yesterday, the First Lady announced new commitments that will improve health care for our heroes: http:\/\/t.co\/qfHDIi9L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/qfHDIi9L",
        "expanded_url" : "http:\/\/ow.ly\/8r2VA",
        "display_url" : "ow.ly\/8r2VA"
      } ]
    },
    "geo" : { },
    "id_str" : "157485630094454785",
    "text" : "Yesterday, the First Lady announced new commitments that will improve health care for our heroes: http:\/\/t.co\/qfHDIi9L",
    "id" : 157485630094454785,
    "created_at" : "2012-01-12 15:34:34 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 157485718032224256,
  "created_at" : "2012-01-12 15:34:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/4sg64Y28",
      "expanded_url" : "http:\/\/ow.ly\/8qlBa",
      "display_url" : "ow.ly\/8qlBa"
    } ]
  },
  "geo" : { },
  "id_str" : "157261195794067456",
  "text" : "Obama: I want us to be known for making & selling products all over the world stamped w\/ 3 proud words: Made in America http:\/\/t.co\/4sg64Y28",
  "id" : 157261195794067456,
  "created_at" : "2012-01-12 00:42:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157244974801485824",
  "text" : "RT @JoiningForces: Today, the First Lady announced a major coordinated effort by America's academic institutions to combat PTSD & TBI: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/RwZLm4Fs",
        "expanded_url" : "http:\/\/ow.ly\/8qhzz",
        "display_url" : "ow.ly\/8qhzz"
      } ]
    },
    "geo" : { },
    "id_str" : "157239184585785344",
    "text" : "Today, the First Lady announced a major coordinated effort by America's academic institutions to combat PTSD & TBI: http:\/\/t.co\/RwZLm4Fs",
    "id" : 157239184585785344,
    "created_at" : "2012-01-11 23:15:17 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 157244974801485824,
  "created_at" : "2012-01-11 23:38:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 89, 102 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 103, 115 ],
      "id_str" : "110541296",
      "id" : 110541296
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 120, 128 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157236958500892672",
  "text" : "RT @ks44: Missed our #WHChat on investing in innovation? No worries. See the full Q&A w\/ @aneeshchopra @commercegov via @Storify: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aneesh Chopra",
        "screen_name" : "aneeshchopra",
        "indices" : [ 79, 92 ],
        "id_str" : "121539516",
        "id" : 121539516
      }, {
        "name" : "U.S. Commerce Dept.",
        "screen_name" : "CommerceGov",
        "indices" : [ 93, 105 ],
        "id_str" : "110541296",
        "id" : 110541296
      }, {
        "name" : "Storify",
        "screen_name" : "Storify",
        "indices" : [ 110, 118 ],
        "id_str" : "17814938",
        "id" : 17814938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 11, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/SOA4iu5d",
        "expanded_url" : "http:\/\/ow.ly\/8qhdP",
        "display_url" : "ow.ly\/8qhdP"
      } ]
    },
    "geo" : { },
    "id_str" : "157236537921253376",
    "text" : "Missed our #WHChat on investing in innovation? No worries. See the full Q&A w\/ @aneeshchopra @commercegov via @Storify: http:\/\/t.co\/SOA4iu5d",
    "id" : 157236537921253376,
    "created_at" : "2012-01-11 23:04:46 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 157236958500892672,
  "created_at" : "2012-01-11 23:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/yifwmuBJ",
      "expanded_url" : "http:\/\/ow.ly\/8qeKV",
      "display_url" : "ow.ly\/8qeKV"
    } ]
  },
  "geo" : { },
  "id_str" : "157225253184090112",
  "text" : "What do you want to know about #insourcing? Here's everything: http:\/\/t.co\/yifwmuBJ",
  "id" : 157225253184090112,
  "created_at" : "2012-01-11 22:19:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/157219677066633217\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/T6kTlSED",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai6OdpvCIAAxNl7.jpg",
      "id_str" : "157219677075021824",
      "id" : 157219677075021824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai6OdpvCIAAxNl7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/T6kTlSED"
    } ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157219677066633217",
  "text" : "After shedding jobs for over a decade, American manufacturers have added 334,000 jobs in the last 2 years #insourcing http:\/\/t.co\/T6kTlSED",
  "id" : 157219677066633217,
  "created_at" : "2012-01-11 21:57:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157160498666815488",
  "text" : "RT @WHLive: \"The more Americans who succeed, the more America succeeds\" -President Obama at #insourcing forum at the White House",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "insourcing",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157160457730408449",
    "text" : "\"The more Americans who succeed, the more America succeeds\" -President Obama at #insourcing forum at the White House",
    "id" : 157160457730408449,
    "created_at" : "2012-01-11 18:02:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 157160498666815488,
  "created_at" : "2012-01-11 18:02:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157159151166947328",
  "text" : "RT @WHLive: \"I want us to be known for making & selling products all over the world stamped with 3 proud words: Made in America\" -Pres O ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "insourcing",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157159121844584448",
    "text" : "\"I want us to be known for making & selling products all over the world stamped with 3 proud words: Made in America\" -Pres Obama #insourcing",
    "id" : 157159121844584448,
    "created_at" : "2012-01-11 17:57:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 157159151166947328,
  "created_at" : "2012-01-11 17:57:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 111, 118 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "157156957877321729",
  "text" : "Happening now: President Obama speaks on #insourcing American jobs. Watch live: http:\/\/t.co\/u95y7hhB & follow: @WHLive",
  "id" : 157156957877321729,
  "created_at" : "2012-01-11 17:48:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "INsourcing",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/UKls6UDl",
      "expanded_url" : "http:\/\/bsun.md\/zrs4kX",
      "display_url" : "bsun.md\/zrs4kX"
    }, {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/tuG24Fco",
      "expanded_url" : "http:\/\/bit.ly\/AjaysD",
      "display_url" : "bit.ly\/AjaysD"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/OZt98rES",
      "expanded_url" : "http:\/\/bit.ly\/xlnknS",
      "display_url" : "bit.ly\/xlnknS"
    } ]
  },
  "geo" : { },
  "id_str" : "157151683259006977",
  "text" : "RT @jesseclee44: Obama supporting #INsourcing today. Ex. from MD: http:\/\/t.co\/UKls6UDl  WI: http:\/\/t.co\/tuG24Fco  NC: http:\/\/t.co\/OZt98rES",
  "id" : 157151683259006977,
  "created_at" : "2012-01-11 17:27:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 129, 140 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157120802859397120",
  "text" : "Today, President Obama will call on companies across the nation to invest in America at an #insourcing American jobs forum @ the @whitehouse",
  "id" : 157120802859397120,
  "created_at" : "2012-01-11 15:24:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPAGov",
      "indices" : [ 78, 85 ],
      "id_str" : "1604108887",
      "id" : 1604108887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/a4l7LQaS",
      "expanded_url" : "http:\/\/ow.ly\/8oZ49",
      "display_url" : "ow.ly\/8oZ49"
    } ]
  },
  "geo" : { },
  "id_str" : "156897822967472130",
  "text" : "President Obama stopped by the Environmental Protection Agency today to thank @EPAgov staff for their work: http:\/\/t.co\/a4l7LQaS",
  "id" : 156897822967472130,
  "created_at" : "2012-01-11 00:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 40, 51 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/serwSEBV",
      "expanded_url" : "http:\/\/go.usa.gov\/Nby",
      "display_url" : "go.usa.gov\/Nby"
    } ]
  },
  "geo" : { },
  "id_str" : "156861119909212161",
  "text" : "RT @arneduncan: I'll be speaking at the @whitehouse abt connecting college, career & citizenship. Watch 5:30pm ET http:\/\/t.co\/serwSEBV # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 24, 35 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CivicEd",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/serwSEBV",
        "expanded_url" : "http:\/\/go.usa.gov\/Nby",
        "display_url" : "go.usa.gov\/Nby"
      } ]
    },
    "geo" : { },
    "id_str" : "156845692231491585",
    "text" : "I'll be speaking at the @whitehouse abt connecting college, career & citizenship. Watch 5:30pm ET http:\/\/t.co\/serwSEBV #CivicEd",
    "id" : 156845692231491585,
    "created_at" : "2012-01-10 21:11:41 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 156861119909212161,
  "created_at" : "2012-01-10 22:12:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 81, 92 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156840864306573313",
  "text" : "RT @JonCarson44: President announced Cecilia Munoz, my friend and colleague here @whitehouse as new Chair of Domestic Policy Council htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 64, 75 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/Rsi5y7qn",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/01\/10\/president-obama-announces-new-white-house-director-domestic-policy-counc",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "156812117721362432",
    "text" : "President announced Cecilia Munoz, my friend and colleague here @whitehouse as new Chair of Domestic Policy Council http:\/\/t.co\/Rsi5y7qn",
    "id" : 156812117721362432,
    "created_at" : "2012-01-10 18:58:16 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 156840864306573313,
  "created_at" : "2012-01-10 20:52:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/Q2R8V35l",
      "expanded_url" : "http:\/\/wh.gov\/WB6",
      "display_url" : "wh.gov\/WB6"
    }, {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/VSKR5aev",
      "expanded_url" : "http:\/\/youtu.be\/OEiitkI2WH0",
      "display_url" : "youtu.be\/OEiitkI2WH0"
    } ]
  },
  "geo" : { },
  "id_str" : "156834515682209793",
  "text" : "From the Archives: President Obama honors victims of the tragedy in Tucson: http:\/\/t.co\/Q2R8V35l Video: http:\/\/t.co\/VSKR5aev",
  "id" : 156834515682209793,
  "created_at" : "2012-01-10 20:27:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master Lock Co",
      "screen_name" : "MasterLockCo",
      "indices" : [ 96, 109 ],
      "id_str" : "1241556030",
      "id" : 1241556030
    }, {
      "name" : "Lincolnton Furniture",
      "screen_name" : "LincolntonFCo",
      "indices" : [ 110, 124 ],
      "id_str" : "436067376",
      "id" : 436067376
    }, {
      "name" : "DuPont News",
      "screen_name" : "DuPont_News",
      "indices" : [ 125, 137 ],
      "id_str" : "24054721",
      "id" : 24054721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 47, 58 ]
    }, {
      "text" : "jobs",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156823320682168320",
  "text" : "Tomorrow, President Obama will host a forum on #insourcing American #jobs with biz leaders incl @masterlockco @LincolntonFCo @DuPont_News",
  "id" : 156823320682168320,
  "created_at" : "2012-01-10 19:42:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    }, {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 38, 46 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 49, 60 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 85, 95 ]
    }, {
      "text" : "servicelearning",
      "indices" : [ 100, 116 ]
    }, {
      "text" : "CivicEd",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156813235352383489",
  "text" : "RT @ServeDotGov: Today, we're joining @usedgov & @whitehouse at 2PM ET to talk about #education and #servicelearning, #CivicEd go.usa.go ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 21, 29 ],
        "id_str" : "20437286",
        "id" : 20437286
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 32, 43 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "education",
        "indices" : [ 68, 78 ]
      }, {
        "text" : "servicelearning",
        "indices" : [ 83, 99 ]
      }, {
        "text" : "CivicEd",
        "indices" : [ 101, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156783737630228480",
    "text" : "Today, we're joining @usedgov & @whitehouse at 2PM ET to talk about #education and #servicelearning, #CivicEd go.usa.gov\/Rjy Watch it live!",
    "id" : 156783737630228480,
    "created_at" : "2012-01-10 17:05:30 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 156813235352383489,
  "created_at" : "2012-01-10 19:02:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/156774563320041472\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/l2eEvgqy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aiz5onzCEAAX4fU.jpg",
      "id_str" : "156774563324235776",
      "id" : 156774563324235776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aiz5onzCEAAX4fU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/l2eEvgqy"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/nbZP37qY",
      "expanded_url" : "http:\/\/wh.gov\/WBE",
      "display_url" : "wh.gov\/WBE"
    } ]
  },
  "geo" : { },
  "id_str" : "156774563320041472",
  "text" : "By the Numbers: 170,000: http:\/\/t.co\/nbZP37qY Since June of 2009, the auto industry has added 170,000 #jobs: http:\/\/t.co\/l2eEvgqy",
  "id" : 156774563320041472,
  "created_at" : "2012-01-10 16:29:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/Ss7nUSRs",
      "expanded_url" : "http:\/\/ow.ly\/8ofpi",
      "display_url" : "ow.ly\/8ofpi"
    } ]
  },
  "geo" : { },
  "id_str" : "156749080398270465",
  "text" : "Resurgence of the American Auto Industry: Since June of 2009, the auto industry has added back more than 170,000 jobs: http:\/\/t.co\/Ss7nUSRs",
  "id" : 156749080398270465,
  "created_at" : "2012-01-10 14:47:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 3, 13 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 22, 37 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/kCIon4mg",
      "expanded_url" : "http:\/\/ow.ly\/i\/pp5r",
      "display_url" : "ow.ly\/i\/pp5r"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Gksz5Ic6",
      "expanded_url" : "http:\/\/www.startupamericapartnership.org",
      "display_url" : "startupamericapartnership.org"
    } ]
  },
  "geo" : { },
  "id_str" : "156511298115485697",
  "text" : "RT @SteveCase: PHOTO: @StartupAmerica board meeting at the @WhiteHouse w\/ President Obama http:\/\/t.co\/kCIon4mg Info: http:\/\/t.co\/Gksz5Ic6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 7, 22 ],
        "id_str" : "211921304",
        "id" : 211921304
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 44, 55 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/kCIon4mg",
        "expanded_url" : "http:\/\/ow.ly\/i\/pp5r",
        "display_url" : "ow.ly\/i\/pp5r"
      }, {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/Gksz5Ic6",
        "expanded_url" : "http:\/\/www.startupamericapartnership.org",
        "display_url" : "startupamericapartnership.org"
      } ]
    },
    "geo" : { },
    "id_str" : "156490691227303938",
    "text" : "PHOTO: @StartupAmerica board meeting at the @WhiteHouse w\/ President Obama http:\/\/t.co\/kCIon4mg Info: http:\/\/t.co\/Gksz5Ic6",
    "id" : 156490691227303938,
    "created_at" : "2012-01-09 21:41:02 +0000",
    "user" : {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "protected" : false,
      "id_str" : "6708952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708164499014987780\/w8TcvuF0_normal.jpg",
      "id" : 6708952,
      "verified" : true
    }
  },
  "id" : 156511298115485697,
  "created_at" : "2012-01-09 23:02:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 70, 83 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 86, 98 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156490307498815488",
  "text" : "RT @ks44: Who followed today's #WHChat on American competitiveness w\/ @aneeshchopra & @commercegov? Let us know what you thought.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aneesh Chopra",
        "screen_name" : "aneeshchopra",
        "indices" : [ 60, 73 ],
        "id_str" : "121539516",
        "id" : 121539516
      }, {
        "name" : "U.S. Commerce Dept.",
        "screen_name" : "CommerceGov",
        "indices" : [ 76, 88 ],
        "id_str" : "110541296",
        "id" : 110541296
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 21, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156489871261839360",
    "text" : "Who followed today's #WHChat on American competitiveness w\/ @aneeshchopra & @commercegov? Let us know what you thought.",
    "id" : 156489871261839360,
    "created_at" : "2012-01-09 21:37:47 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 156490307498815488,
  "created_at" : "2012-01-09 21:39:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dallas Mavericks",
      "screen_name" : "dallasmavs",
      "indices" : [ 46, 57 ],
      "id_str" : "22185437",
      "id" : 22185437
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 65, 76 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/Pj6Wrbcx",
      "expanded_url" : "http:\/\/youtu.be\/3SfDs_tGrR8",
      "display_url" : "youtu.be\/3SfDs_tGrR8"
    } ]
  },
  "geo" : { },
  "id_str" : "156487968306118657",
  "text" : "Today, President Obama welcomed 2011 Champion @dallasmavs to the @whitehouse. Watch: http:\/\/t.co\/Pj6Wrbcx",
  "id" : 156487968306118657,
  "created_at" : "2012-01-09 21:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 3, 15 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 67, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/05KGqM1o",
      "expanded_url" : "http:\/\/owl.li\/8noko",
      "display_url" : "owl.li\/8noko"
    } ]
  },
  "geo" : { },
  "id_str" : "156478514013544449",
  "text" : "RT @CommerceGov: Lots of questions on education. Commerce supports #STEM education to improve competitiveness. See http:\/\/t.co\/05KGqM1o  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 50, 55 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/05KGqM1o",
        "expanded_url" : "http:\/\/owl.li\/8noko",
        "display_url" : "owl.li\/8noko"
      } ]
    },
    "geo" : { },
    "id_str" : "156476455927291904",
    "text" : "Lots of questions on education. Commerce supports #STEM education to improve competitiveness. See http:\/\/t.co\/05KGqM1o for more info #WHChat",
    "id" : 156476455927291904,
    "created_at" : "2012-01-09 20:44:28 +0000",
    "user" : {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "protected" : false,
      "id_str" : "110541296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645983513712459776\/3Q0H2IVF_normal.jpg",
      "id" : 110541296,
      "verified" : true
    }
  },
  "id" : 156478514013544449,
  "created_at" : "2012-01-09 20:52:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 65, 78 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 79, 91 ],
      "id_str" : "110541296",
      "id" : 110541296
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 92, 107 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COMPETES",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156476249164873728",
  "text" : "RT @WHLive: WH Office Hours on #COMPETES report happening now w\/ @aneeshchopra @commercegov @whitehouseostp. Ask your questions with #WH ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aneesh Chopra",
        "screen_name" : "aneeshchopra",
        "indices" : [ 53, 66 ],
        "id_str" : "121539516",
        "id" : 121539516
      }, {
        "name" : "U.S. Commerce Dept.",
        "screen_name" : "CommerceGov",
        "indices" : [ 67, 79 ],
        "id_str" : "110541296",
        "id" : 110541296
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 80, 95 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COMPETES",
        "indices" : [ 19, 28 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156476075625553920",
    "text" : "WH Office Hours on #COMPETES report happening now w\/ @aneeshchopra @commercegov @whitehouseostp. Ask your questions with #WHChat now.",
    "id" : 156476075625553920,
    "created_at" : "2012-01-09 20:42:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 156476249164873728,
  "created_at" : "2012-01-09 20:43:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 26, 38 ],
      "id_str" : "110541296",
      "id" : 110541296
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 59, 72 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156474311937507328",
  "text" : "RT @WHLive: Starting now: @commercegov Dep Sec Dr. Blank & @aneeshchopra taking your questions on investing in innovation. Use #WHChat t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Commerce Dept.",
        "screen_name" : "CommerceGov",
        "indices" : [ 14, 26 ],
        "id_str" : "110541296",
        "id" : 110541296
      }, {
        "name" : "Aneesh Chopra",
        "screen_name" : "aneeshchopra",
        "indices" : [ 47, 60 ],
        "id_str" : "121539516",
        "id" : 121539516
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156473319879749632",
    "text" : "Starting now: @commercegov Dep Sec Dr. Blank & @aneeshchopra taking your questions on investing in innovation. Use #WHChat to ask now",
    "id" : 156473319879749632,
    "created_at" : "2012-01-09 20:32:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 156474311937507328,
  "created_at" : "2012-01-09 20:35:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "156466428004929536",
  "text" : "Happening now: President Obama speaks on his Chief of Staff Bill Daley. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 156466428004929536,
  "created_at" : "2012-01-09 20:04:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "156454579096141826",
  "text" : "RT @WHLive: At 3:00 ET the President will deliver a statement in the State Dining Room. Watch live: http:\/\/t.co\/g5ih2w0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "156454527741079552",
    "text" : "At 3:00 ET the President will deliver a statement in the State Dining Room. Watch live: http:\/\/t.co\/g5ih2w0F",
    "id" : 156454527741079552,
    "created_at" : "2012-01-09 19:17:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 156454579096141826,
  "created_at" : "2012-01-09 19:17:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "volunteer",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156443824560930816",
  "text" : "RT @ServeDotGov: #MLKDay is in just one week! How are you celebrating this day of service? Find a place to #volunteer: mlkday.gov\/serve",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "volunteer",
        "indices" : [ 90, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156432153549344768",
    "text" : "#MLKDay is in just one week! How are you celebrating this day of service? Find a place to #volunteer: mlkday.gov\/serve",
    "id" : 156432153549344768,
    "created_at" : "2012-01-09 17:48:26 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 156443824560930816,
  "created_at" : "2012-01-09 18:34:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 46, 50 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "Dallas Mavericks",
      "screen_name" : "dallasmavs",
      "indices" : [ 60, 71 ],
      "id_str" : "22185437",
      "id" : 22185437
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 79, 90 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "156422155045830657",
  "text" : "Happening now: President Obama hosts the 2011 @NBA Champion @DallasMavs at the @WhiteHouse. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 156422155045830657,
  "created_at" : "2012-01-09 17:08:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA TV",
      "screen_name" : "NBATV",
      "indices" : [ 3, 9 ],
      "id_str" : "25319414",
      "id" : 25319414
    }, {
      "name" : "Dallas Mavericks",
      "screen_name" : "dallasmavs",
      "indices" : [ 55, 66 ],
      "id_str" : "22185437",
      "id" : 22185437
    }, {
      "name" : "NBA TV",
      "screen_name" : "NBATV",
      "indices" : [ 103, 109 ],
      "id_str" : "25319414",
      "id" : 25319414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156411065222168578",
  "text" : "RT @NBATV: The POTUS is hosting the NBA world champion @DallasMavs @ the White House TODAY! Tune in to @NBATV @ NOON & visit http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dallas Mavericks",
        "screen_name" : "dallasmavs",
        "indices" : [ 44, 55 ],
        "id_str" : "22185437",
        "id" : 22185437
      }, {
        "name" : "NBA TV",
        "screen_name" : "NBATV",
        "indices" : [ 92, 98 ],
        "id_str" : "25319414",
        "id" : 25319414
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/VIFKJ70y",
        "expanded_url" : "http:\/\/WWW.NBA.COM",
        "display_url" : "NBA.COM"
      } ]
    },
    "geo" : { },
    "id_str" : "156406316020154369",
    "text" : "The POTUS is hosting the NBA world champion @DallasMavs @ the White House TODAY! Tune in to @NBATV @ NOON & visit http:\/\/t.co\/VIFKJ70y!",
    "id" : 156406316020154369,
    "created_at" : "2012-01-09 16:05:46 +0000",
    "user" : {
      "name" : "NBA TV",
      "screen_name" : "NBATV",
      "protected" : false,
      "id_str" : "25319414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745667983557656576\/i6T6TgOn_normal.jpg",
      "id" : 25319414,
      "verified" : true
    }
  },
  "id" : 156411065222168578,
  "created_at" : "2012-01-09 16:24:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Nowitzki",
      "screen_name" : "swish41",
      "indices" : [ 3, 11 ],
      "id_str" : "205415788",
      "id" : 205415788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156410844492730368",
  "text" : "RT @swish41: On bus goin to the white house. What an honor to meet the POTUS. Check in out on nba tv at noon eastern.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156389034552340480",
    "text" : "On bus goin to the white house. What an honor to meet the POTUS. Check in out on nba tv at noon eastern.",
    "id" : 156389034552340480,
    "created_at" : "2012-01-09 14:57:06 +0000",
    "user" : {
      "name" : "Dirk Nowitzki",
      "screen_name" : "swish41",
      "protected" : false,
      "id_str" : "205415788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669044632\/8177070479aeb345d84745272ed1b614_normal.jpeg",
      "id" : 205415788,
      "verified" : true
    }
  },
  "id" : 156410844492730368,
  "created_at" : "2012-01-09 16:23:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 16, 29 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 32, 44 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/4OMz49GH",
      "expanded_url" : "http:\/\/ow.ly\/8mXhl",
      "display_url" : "ow.ly\/8mXhl"
    } ]
  },
  "geo" : { },
  "id_str" : "156405387199913984",
  "text" : "Today @ 3:30ET: @aneeshchopra & @commercegov Dep Sec take your #WHChat ?s on a new report on investing in innovation: http:\/\/t.co\/4OMz49GH",
  "id" : 156405387199913984,
  "created_at" : "2012-01-09 16:02:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/1jrEl0eW",
      "expanded_url" : "http:\/\/ow.ly\/8ly7M",
      "display_url" : "ow.ly\/8ly7M"
    } ]
  },
  "geo" : { },
  "id_str" : "155731326828412928",
  "text" : "President Obama's New Year\u2019s resolution: \"do whatever it takes to move the economy forward.\" Watch his Weekly Address: http:\/\/t.co\/1jrEl0eW",
  "id" : 155731326828412928,
  "created_at" : "2012-01-07 19:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 19, 24 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/7aPUbv8Z",
      "expanded_url" : "http:\/\/ow.ly\/8l3r5",
      "display_url" : "ow.ly\/8l3r5"
    } ]
  },
  "geo" : { },
  "id_str" : "155448289809014786",
  "text" : "President Obama on @cfpb's mission: \"to make sure that the American people have somebody in their corner\" http:\/\/t.co\/7aPUbv8Z",
  "id" : 155448289809014786,
  "created_at" : "2012-01-07 00:38:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 107, 120 ],
      "id_str" : "19546277",
      "id" : 19546277
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 121, 129 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155417804479279104",
  "text" : "RT @WHLive: Did you miss today's #WHChat on jobs & the economy? Check out the whole Q&A with Brian Deese & @YahooFinance @Storify: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yahoo Finance",
        "screen_name" : "YahooFinance",
        "indices" : [ 95, 108 ],
        "id_str" : "19546277",
        "id" : 19546277
      }, {
        "name" : "Storify",
        "screen_name" : "Storify",
        "indices" : [ 109, 117 ],
        "id_str" : "17814938",
        "id" : 17814938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 21, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/bSHrHm7L",
        "expanded_url" : "http:\/\/sfy.co\/TdT",
        "display_url" : "sfy.co\/TdT"
      } ]
    },
    "geo" : { },
    "id_str" : "155417724829450240",
    "text" : "Did you miss today's #WHChat on jobs & the economy? Check out the whole Q&A with Brian Deese & @YahooFinance @Storify: http:\/\/t.co\/bSHrHm7L",
    "id" : 155417724829450240,
    "created_at" : "2012-01-06 22:37:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 155417804479279104,
  "created_at" : "2012-01-06 22:37:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "AAUW",
      "screen_name" : "AAUW",
      "indices" : [ 46, 51 ],
      "id_str" : "19719380",
      "id" : 19719380
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "T9Talk",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155394572363644929",
  "text" : "RT @arneduncan: We're starting our tweetup w\/ @AAUW in a few moments. Join us by asking your Title IX ?'s using #T9Talk.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AAUW",
        "screen_name" : "AAUW",
        "indices" : [ 30, 35 ],
        "id_str" : "19719380",
        "id" : 19719380
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "T9Talk",
        "indices" : [ 96, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155392746528583680",
    "text" : "We're starting our tweetup w\/ @AAUW in a few moments. Join us by asking your Title IX ?'s using #T9Talk.",
    "id" : 155392746528583680,
    "created_at" : "2012-01-06 20:58:12 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 155394572363644929,
  "created_at" : "2012-01-06 21:05:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Daniel Gross",
      "screen_name" : "grossdm",
      "indices" : [ 13, 21 ],
      "id_str" : "41159876",
      "id" : 41159876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155381058542645248",
  "text" : "RT @WHLive: .@grossdm today's jobs report is evidence of economy healing but there is much more to do, eg extending payroll tax for rest ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Gross",
        "screen_name" : "grossdm",
        "indices" : [ 1, 9 ],
        "id_str" : "41159876",
        "id" : 41159876
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155380893240918016",
    "text" : ".@grossdm today's jobs report is evidence of economy healing but there is much more to do, eg extending payroll tax for rest of '12 #WHChat",
    "id" : 155380893240918016,
    "created_at" : "2012-01-06 20:11:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 155381058542645248,
  "created_at" : "2012-01-06 20:11:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 3, 16 ],
      "id_str" : "19546277",
      "id" : 19546277
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 36, 43 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Daniel Gross",
      "screen_name" : "grossdm",
      "indices" : [ 46, 54 ],
      "id_str" : "41159876",
      "id" : 41159876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155381020168945664",
  "text" : "RT @YahooFinance: 1st Questions for @WHLive - @grossdm My q: Data has been positive lately. Do you foresee econ. accelerating in 1st par ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 18, 25 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "Daniel Gross",
        "screen_name" : "grossdm",
        "indices" : [ 28, 36 ],
        "id_str" : "41159876",
        "id" : 41159876
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "155378705638768642",
    "geo" : { },
    "id_str" : "155380368634150912",
    "in_reply_to_user_id" : 41159876,
    "text" : "1st Questions for @WHLive - @grossdm My q: Data has been positive lately. Do you foresee econ. accelerating in 1st part of \u201912? #whchat",
    "id" : 155380368634150912,
    "in_reply_to_status_id" : 155378705638768642,
    "created_at" : "2012-01-06 20:09:01 +0000",
    "in_reply_to_screen_name" : "grossdm",
    "in_reply_to_user_id_str" : "41159876",
    "user" : {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "protected" : false,
      "id_str" : "19546277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710978975376388096\/1U2djlFO_normal.jpg",
      "id" : 19546277,
      "verified" : true
    }
  },
  "id" : 155381020168945664,
  "created_at" : "2012-01-06 20:11:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 90, 103 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155380689221595136",
  "text" : "RT @WHLive: Hi all \u2013 its Brian Deese here to answer your questions on the economy & jobs. @YahooFinance, ready for the 1st Q #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yahoo Finance",
        "screen_name" : "YahooFinance",
        "indices" : [ 78, 91 ],
        "id_str" : "19546277",
        "id" : 19546277
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 113, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155379853435224064",
    "text" : "Hi all \u2013 its Brian Deese here to answer your questions on the economy & jobs. @YahooFinance, ready for the 1st Q #whchat",
    "id" : 155379853435224064,
    "created_at" : "2012-01-06 20:06:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 155380689221595136,
  "created_at" : "2012-01-06 20:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 3, 9 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 75, 86 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 88, 95 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 98, 111 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155377342062149632",
  "text" : "RT @Yahoo: Got concerns about jobs & the economy? Chat live in 5 mins with @WhiteHouse, @WHLive & @YahooFinance. Send your questions usi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 64, 75 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 77, 84 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "Yahoo Finance",
        "screen_name" : "YahooFinance",
        "indices" : [ 87, 100 ],
        "id_str" : "19546277",
        "id" : 19546277
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155376866285461504",
    "text" : "Got concerns about jobs & the economy? Chat live in 5 mins with @WhiteHouse, @WHLive & @YahooFinance. Send your questions using #whchat.",
    "id" : 155376866285461504,
    "created_at" : "2012-01-06 19:55:06 +0000",
    "user" : {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "protected" : false,
      "id_str" : "19380829",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747326716746444800\/IRfRHRaE_normal.jpg",
      "id" : 19380829,
      "verified" : true
    }
  },
  "id" : 155377342062149632,
  "created_at" : "2012-01-06 19:56:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 45, 52 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 123, 136 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 93, 95 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155367652708192256",
  "text" : "RT @WHLive: Today @ 3ET: Brian Deese will be @WHLive to answer your Qs on the economy & jobs #s. Ask now with #WHChat. cc: @YahooFinance",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 33, 40 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "Yahoo Finance",
        "screen_name" : "YahooFinance",
        "indices" : [ 111, 124 ],
        "id_str" : "19546277",
        "id" : 19546277
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "s",
        "indices" : [ 81, 83 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155367551570944000",
    "text" : "Today @ 3ET: Brian Deese will be @WHLive to answer your Qs on the economy & jobs #s. Ask now with #WHChat. cc: @YahooFinance",
    "id" : 155367551570944000,
    "created_at" : "2012-01-06 19:18:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 155367652708192256,
  "created_at" : "2012-01-06 19:18:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 4, 9 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/g0JNXyV6",
      "expanded_url" : "http:\/\/youtu.be\/6-r4JFDsVmA",
      "display_url" : "youtu.be\/6-r4JFDsVmA"
    } ]
  },
  "geo" : { },
  "id_str" : "155366025054007296",
  "text" : "New @CFPB Director Richard Cordray wants to hear from consumers like you: http:\/\/t.co\/g0JNXyV6",
  "id" : 155366025054007296,
  "created_at" : "2012-01-06 19:12:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155317916399702018",
  "text" : "RT @jesseclee44: Chart: Last 4 years of private sector job gains\/losses. Note trends before & after Jan 2009. More to do. http:\/\/t.co\/Oe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/jesseclee44\/status\/155316574193074176\/photo\/1",
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/OeRNGrWb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AifLmfDCQAAL33a.jpg",
        "id_str" : "155316574197268480",
        "id" : 155316574197268480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AifLmfDCQAAL33a.jpg",
        "sizes" : [ {
          "h" : 671,
          "resize" : "fit",
          "w" : 920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 920
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OeRNGrWb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155316574193074176",
    "text" : "Chart: Last 4 years of private sector job gains\/losses. Note trends before & after Jan 2009. More to do. http:\/\/t.co\/OeRNGrWb",
    "id" : 155316574193074176,
    "created_at" : "2012-01-06 15:55:32 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 155317916399702018,
  "created_at" : "2012-01-06 16:00:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155313518063796225",
  "text" : "RT @aneeshchopra: Great ideas so far on ways to unleash entrepreneurship in energy, digital learning and health IT - keep em coming! htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/ON5w93Qi",
        "expanded_url" : "http:\/\/1.usa.gov\/x4qABH",
        "display_url" : "1.usa.gov\/x4qABH"
      } ]
    },
    "geo" : { },
    "id_str" : "155312434867994625",
    "text" : "Great ideas so far on ways to unleash entrepreneurship in energy, digital learning and health IT - keep em coming! http:\/\/t.co\/ON5w93Qi",
    "id" : 155312434867994625,
    "created_at" : "2012-01-06 15:39:04 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 155313518063796225,
  "created_at" : "2012-01-06 15:43:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 15, 27 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    }, {
      "name" : "American Progress",
      "screen_name" : "amprog",
      "indices" : [ 73, 80 ],
      "id_str" : "17171111",
      "id" : 17171111
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COMPETES",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/DHIDO2hI",
      "expanded_url" : "http:\/\/bit.ly\/y210hG",
      "display_url" : "bit.ly\/y210hG"
    } ]
  },
  "geo" : { },
  "id_str" : "155312927816171520",
  "text" : "Happening now: @CommerceSec John Bryson unveils the #COMPETES Act report @AmProg. Watch live: http:\/\/t.co\/DHIDO2hI",
  "id" : 155312927816171520,
  "created_at" : "2012-01-06 15:41:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/a8rVW4K0",
      "expanded_url" : "http:\/\/ow.ly\/8koIy",
      "display_url" : "ow.ly\/8koIy"
    } ]
  },
  "geo" : { },
  "id_str" : "155309488717565952",
  "text" : "Employment Situation in December: Private sector payrolls increased by 212,000 & the unemployment rate fell to 8.5%: http:\/\/t.co\/a8rVW4K0",
  "id" : 155309488717565952,
  "created_at" : "2012-01-06 15:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 3, 16 ],
      "id_str" : "19546277",
      "id" : 19546277
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 107, 114 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 115, 128 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155301151938588672",
  "text" : "RT @YahooFinance: Tune in today at 3 p.m. EST @whitehouse's Brian Deese answers your economic questions on @WHLive @YahooFinance. Send q ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 28, 39 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 89, 96 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "Yahoo Finance",
        "screen_name" : "YahooFinance",
        "indices" : [ 97, 110 ],
        "id_str" : "19546277",
        "id" : 19546277
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155295104301662208",
    "text" : "Tune in today at 3 p.m. EST @whitehouse's Brian Deese answers your economic questions on @WHLive @YahooFinance. Send questions to #WHChat",
    "id" : 155295104301662208,
    "created_at" : "2012-01-06 14:30:12 +0000",
    "user" : {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "protected" : false,
      "id_str" : "19546277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710978975376388096\/1U2djlFO_normal.jpg",
      "id" : 19546277,
      "verified" : true
    }
  },
  "id" : 155301151938588672,
  "created_at" : "2012-01-06 14:54:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/EdFtpQx4",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Rmcem7Kku_4&feature=share",
      "display_url" : "youtube.com\/watch?v=Rmcem7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155294986072629248",
  "text" : "First Friday of 2012 = Fresh West Wing Week: The Annual Resolutions Edition: http:\/\/t.co\/EdFtpQx4",
  "id" : 155294986072629248,
  "created_at" : "2012-01-06 14:29:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/155083243950063617\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/7F5zOtWt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aib3Y4LCQAAZXYM.jpg",
      "id_str" : "155083243958452224",
      "id" : 155083243958452224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aib3Y4LCQAAZXYM.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7F5zOtWt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/43aNj01s",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/01\/05\/president-obama-outlines-new-global-military-strategy",
      "display_url" : "whitehouse.gov\/blog\/2012\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155083243950063617",
  "text" : "President Obama outlines a new global military strategy @ the Pentagon. Video: http:\/\/t.co\/43aNj01s Photo: http:\/\/t.co\/7F5zOtWt",
  "id" : 155083243950063617,
  "created_at" : "2012-01-06 00:28:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155078981694128128",
  "text" : "RT @AmbassadorRice: Pres. #Obama's new defense strategy will ensure the world's finest military is shaped to meet the challenges of the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 6, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155074109552861184",
    "text" : "Pres. #Obama's new defense strategy will ensure the world's finest military is shaped to meet the challenges of the future.",
    "id" : 155074109552861184,
    "created_at" : "2012-01-05 23:52:03 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 155078981694128128,
  "created_at" : "2012-01-06 00:11:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 3, 8 ],
      "id_str" : "234826866",
      "id" : 234826866
    }, {
      "name" : "Stars and Stripes",
      "screen_name" : "starsandstripes",
      "indices" : [ 34, 50 ],
      "id_str" : "9130702",
      "id" : 9130702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/PtToDBly",
      "expanded_url" : "http:\/\/1.usa.gov\/xhr5pP",
      "display_url" : "1.usa.gov\/xhr5pP"
    } ]
  },
  "geo" : { },
  "id_str" : "155052671802421250",
  "text" : "RT @CFPB: Holly Petraeus talks to @starsandstripes about \"under water\" mortgages forcing military families apart. http:\/\/t.co\/PtToDBly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stars and Stripes",
        "screen_name" : "starsandstripes",
        "indices" : [ 24, 40 ],
        "id_str" : "9130702",
        "id" : 9130702
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/PtToDBly",
        "expanded_url" : "http:\/\/1.usa.gov\/xhr5pP",
        "display_url" : "1.usa.gov\/xhr5pP"
      } ]
    },
    "geo" : { },
    "id_str" : "155052471201443840",
    "text" : "Holly Petraeus talks to @starsandstripes about \"under water\" mortgages forcing military families apart. http:\/\/t.co\/PtToDBly",
    "id" : 155052471201443840,
    "created_at" : "2012-01-05 22:26:04 +0000",
    "user" : {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "protected" : false,
      "id_str" : "234826866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026267147\/ab435400ed4215d94370fdfcf836dfbe_normal.png",
      "id" : 234826866,
      "verified" : true
    }
  },
  "id" : 155052671802421250,
  "created_at" : "2012-01-05 22:26:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 5, 16 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 71, 84 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "economy",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "jobs",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/9MuI1jx5",
      "expanded_url" : "http:\/\/wh.gov\/W2W",
      "display_url" : "wh.gov\/W2W"
    } ]
  },
  "geo" : { },
  "id_str" : "155044243499520000",
  "text" : "Join @WhiteHouse Office Hours on the #economy & #jobs w\/ Brian Deese & @YahooFinance on 1\/6 @ 3ET. Ask Qs now: #WHChat http:\/\/t.co\/9MuI1jx5",
  "id" : 155044243499520000,
  "created_at" : "2012-01-05 21:53:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chegg Career Center",
      "screen_name" : "internships",
      "indices" : [ 3, 15 ],
      "id_str" : "92123107",
      "id" : 92123107
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 34, 45 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobs",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/tV9qXeT7",
      "expanded_url" : "http:\/\/ow.ly\/8jnND",
      "display_url" : "ow.ly\/8jnND"
    } ]
  },
  "geo" : { },
  "id_str" : "155035735689400321",
  "text" : "RT @internships: We're working w\/ @WhiteHouse on #SummerJobs+, providing 100,000+ jobs\/internships for youth: http:\/\/t.co\/tV9qXeT7. VERY ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 17, 28 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SummerJobs",
        "indices" : [ 32, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/tV9qXeT7",
        "expanded_url" : "http:\/\/ow.ly\/8jnND",
        "display_url" : "ow.ly\/8jnND"
      } ]
    },
    "geo" : { },
    "id_str" : "154980080764977152",
    "text" : "We're working w\/ @WhiteHouse on #SummerJobs+, providing 100,000+ jobs\/internships for youth: http:\/\/t.co\/tV9qXeT7. VERY proud!",
    "id" : 154980080764977152,
    "created_at" : "2012-01-05 17:38:25 +0000",
    "user" : {
      "name" : "Chegg Career Center",
      "screen_name" : "internships",
      "protected" : false,
      "id_str" : "92123107",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562757633619140608\/YRvSHuil_normal.png",
      "id" : 92123107,
      "verified" : false
    }
  },
  "id" : 155035735689400321,
  "created_at" : "2012-01-05 21:19:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gap Inc.",
      "screen_name" : "GapInc",
      "indices" : [ 3, 10 ],
      "id_str" : "207686162",
      "id" : 207686162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "summerjobs",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155035343505211392",
  "text" : "RT @GapInc: Just announced our commitment to support 80,000 youth through job skill development programs #summerjobs+ http:\/\/t.co\/TtmAdj ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 127, 138 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "summerjobs",
        "indices" : [ 93, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/TtmAdjF5",
        "expanded_url" : "http:\/\/ar.gy\/r4h",
        "display_url" : "ar.gy\/r4h"
      } ]
    },
    "geo" : { },
    "id_str" : "155020011528925186",
    "text" : "Just announced our commitment to support 80,000 youth through job skill development programs #summerjobs+ http:\/\/t.co\/TtmAdjF5 @whitehouse",
    "id" : 155020011528925186,
    "created_at" : "2012-01-05 20:17:05 +0000",
    "user" : {
      "name" : "Gap Inc.",
      "screen_name" : "GapInc",
      "protected" : false,
      "id_str" : "207686162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634867462404599808\/vrI08ztG_normal.jpg",
      "id" : 207686162,
      "verified" : true
    }
  },
  "id" : 155035343505211392,
  "created_at" : "2012-01-05 21:18:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskState",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/cyEDBa69",
      "expanded_url" : "http:\/\/go.usa.gov\/Nh5",
      "display_url" : "go.usa.gov\/Nh5"
    } ]
  },
  "geo" : { },
  "id_str" : "154986173822021632",
  "text" : "RT @StateDept: #AskState Department Spokesperson Victoria Nuland your foreign policy questions via Twitter: http:\/\/t.co\/cyEDBa69 #OpenGo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskState",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "OpenGov",
        "indices" : [ 114, 122 ]
      }, {
        "text" : "Gov20",
        "indices" : [ 123, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/cyEDBa69",
        "expanded_url" : "http:\/\/go.usa.gov\/Nh5",
        "display_url" : "go.usa.gov\/Nh5"
      } ]
    },
    "geo" : { },
    "id_str" : "154695621645832193",
    "text" : "#AskState Department Spokesperson Victoria Nuland your foreign policy questions via Twitter: http:\/\/t.co\/cyEDBa69 #OpenGov #Gov20",
    "id" : 154695621645832193,
    "created_at" : "2012-01-04 22:48:04 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 154986173822021632,
  "created_at" : "2012-01-05 18:02:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 94, 99 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/154981427627311104\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/457pelyY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AiaayY0CQAAcEat.jpg",
      "id_str" : "154981427635699712",
      "id" : 154981427635699712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiaayY0CQAAcEat.jpg",
      "sizes" : [ {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1389,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/457pelyY"
    } ],
    "hashtags" : [ {
      "text" : "BabyItsColdOutside",
      "indices" : [ 100, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154981427627311104",
  "text" : "Photo of the Day: Obama greets folks outside in Cleveland, OH after talking to a family about @cfpb #BabyItsColdOutside http:\/\/t.co\/457pelyY",
  "id" : 154981427627311104,
  "created_at" : "2012-01-05 17:43:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "154955903479713793",
  "text" : "RT @WHLive: Starting soon: President Obama speaks on the Defense Strategic Review at the Pentagon. Watch live: http:\/\/t.co\/g5ih2w0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "154955843417288704",
    "text" : "Starting soon: President Obama speaks on the Defense Strategic Review at the Pentagon. Watch live: http:\/\/t.co\/g5ih2w0F",
    "id" : 154955843417288704,
    "created_at" : "2012-01-05 16:02:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 154955903479713793,
  "created_at" : "2012-01-05 16:02:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 7, 18 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobs",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/r2N7s6Ni",
      "expanded_url" : "http:\/\/ow.ly\/8jbkm",
      "display_url" : "ow.ly\/8jbkm"
    } ]
  },
  "geo" : { },
  "id_str" : "154947504595664896",
  "text" : "Today, @whitehouse announces #SummerJobs+ to provide hundreds of thousands of summer jobs for America\u2019s youth: http:\/\/t.co\/r2N7s6Ni",
  "id" : 154947504595664896,
  "created_at" : "2012-01-05 15:28:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bon Jovi",
      "screen_name" : "BonJovi",
      "indices" : [ 3, 11 ],
      "id_str" : "22720074",
      "id" : 22720074
    }, {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 13, 25 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154945148655120384",
  "text" : "RT @BonJovi: @JonCarson44 We r here 2 tap into our greatest resource, our Nation\u2019s Youth. Many other organizations r also present in sup ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Carson",
        "screen_name" : "JonCarson44",
        "indices" : [ 0, 12 ],
        "id_str" : "1287388789",
        "id" : 1287388789
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "summerjobs",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "154941352222793728",
    "geo" : { },
    "id_str" : "154943845069627392",
    "in_reply_to_user_id" : 369232105,
    "text" : "@JonCarson44 We r here 2 tap into our greatest resource, our Nation\u2019s Youth. Many other organizations r also present in support #summerjobs+",
    "id" : 154943845069627392,
    "in_reply_to_status_id" : 154941352222793728,
    "created_at" : "2012-01-05 15:14:26 +0000",
    "in_reply_to_screen_name" : "PAniskoff44",
    "in_reply_to_user_id_str" : "369232105",
    "user" : {
      "name" : "Bon Jovi",
      "screen_name" : "BonJovi",
      "protected" : false,
      "id_str" : "22720074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771027859175383040\/z5PT9uv9_normal.jpg",
      "id" : 22720074,
      "verified" : true
    }
  },
  "id" : 154945148655120384,
  "created_at" : "2012-01-05 15:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "Bon Jovi",
      "screen_name" : "BonJovi",
      "indices" : [ 31, 39 ],
      "id_str" : "22720074",
      "id" : 22720074
    }, {
      "name" : "JBJ Soul Foundation",
      "screen_name" : "JBJSoulFound",
      "indices" : [ 75, 88 ],
      "id_str" : "201427510",
      "id" : 201427510
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 89, 100 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JonCarson44\/status\/154938668811952128\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/LVgjr1qA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AiZz5fzCIAA53eW.jpg",
      "id_str" : "154938668816146432",
      "id" : 154938668816146432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiZz5fzCIAA53eW.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/LVgjr1qA"
    } ],
    "hashtags" : [ {
      "text" : "summerjobs",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154939337295925248",
  "text" : "RT @JonCarson44: Check it out! @BonJovi engaged this morning talking about @JBJSoulFound @whitehouse #summerjobs http:\/\/t.co\/LVgjr1qA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bon Jovi",
        "screen_name" : "BonJovi",
        "indices" : [ 14, 22 ],
        "id_str" : "22720074",
        "id" : 22720074
      }, {
        "name" : "JBJ Soul Foundation",
        "screen_name" : "JBJSoulFound",
        "indices" : [ 58, 71 ],
        "id_str" : "201427510",
        "id" : 201427510
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 72, 83 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JonCarson44\/status\/154938668811952128\/photo\/1",
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/LVgjr1qA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AiZz5fzCIAA53eW.jpg",
        "id_str" : "154938668816146432",
        "id" : 154938668816146432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiZz5fzCIAA53eW.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/LVgjr1qA"
      } ],
      "hashtags" : [ {
        "text" : "summerjobs",
        "indices" : [ 84, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154938668811952128",
    "text" : "Check it out! @BonJovi engaged this morning talking about @JBJSoulFound @whitehouse #summerjobs http:\/\/t.co\/LVgjr1qA",
    "id" : 154938668811952128,
    "created_at" : "2012-01-05 14:53:52 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 154939337295925248,
  "created_at" : "2012-01-05 14:56:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "Bon Jovi",
      "screen_name" : "BonJovi",
      "indices" : [ 18, 26 ],
      "id_str" : "22720074",
      "id" : 22720074
    }, {
      "name" : "JBJ Soul Foundation",
      "screen_name" : "JBJSoulFound",
      "indices" : [ 74, 87 ],
      "id_str" : "201427510",
      "id" : 201427510
    }, {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 91, 103 ],
      "id_str" : "59204932",
      "id" : 59204932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Arb5gTC6",
      "expanded_url" : "http:\/\/www.serve.gov\/council",
      "display_url" : "serve.gov\/council"
    } ]
  },
  "geo" : { },
  "id_str" : "154932805749587968",
  "text" : "RT @JonCarson44: .@BonJovi is here at WH - to tell us about his work with @JBJSoulFound ,  @Servedotgov and http:\/\/t.co\/Arb5gTC6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bon Jovi",
        "screen_name" : "BonJovi",
        "indices" : [ 1, 9 ],
        "id_str" : "22720074",
        "id" : 22720074
      }, {
        "name" : "JBJ Soul Foundation",
        "screen_name" : "JBJSoulFound",
        "indices" : [ 57, 70 ],
        "id_str" : "201427510",
        "id" : 201427510
      }, {
        "name" : "United We Serve",
        "screen_name" : "ServeDotGov",
        "indices" : [ 74, 86 ],
        "id_str" : "59204932",
        "id" : 59204932
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/Arb5gTC6",
        "expanded_url" : "http:\/\/www.serve.gov\/council",
        "display_url" : "serve.gov\/council"
      } ]
    },
    "geo" : { },
    "id_str" : "154932378186432513",
    "text" : ".@BonJovi is here at WH - to tell us about his work with @JBJSoulFound ,  @Servedotgov and http:\/\/t.co\/Arb5gTC6",
    "id" : 154932378186432513,
    "created_at" : "2012-01-05 14:28:52 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 154932805749587968,
  "created_at" : "2012-01-05 14:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/cnbvRy6r",
      "expanded_url" : "http:\/\/ow.ly\/8ixc3",
      "display_url" : "ow.ly\/8ixc3"
    } ]
  },
  "geo" : { },
  "id_str" : "154715198102577153",
  "text" : "From the Archives: Holly Petraeus Joins the Consumer Financial Protection Bureau: http:\/\/t.co\/cnbvRy6r",
  "id" : 154715198102577153,
  "created_at" : "2012-01-05 00:05:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Coleman",
      "screen_name" : "MichaelBColeman",
      "indices" : [ 3, 19 ],
      "id_str" : "151943134",
      "id" : 151943134
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 63, 68 ],
      "id_str" : "234826866",
      "id" : 234826866
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 123, 135 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154674068090658817",
  "text" : "RT @MichaelBColeman: Richard Cordray is a great choice for the @CFPB. Rich will stand up our consumers. Great selection by @BarackObama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 42, 47 ],
        "id_str" : "234826866",
        "id" : 234826866
      }, {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 102, 114 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154667231412887553",
    "text" : "Richard Cordray is a great choice for the @CFPB. Rich will stand up our consumers. Great selection by @BarackObama",
    "id" : 154667231412887553,
    "created_at" : "2012-01-04 20:55:16 +0000",
    "user" : {
      "name" : "Mike Coleman",
      "screen_name" : "MichaelBColeman",
      "protected" : false,
      "id_str" : "151943134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618036641702260736\/DkC3Y_n4_normal.jpg",
      "id" : 151943134,
      "verified" : true
    }
  },
  "id" : 154674068090658817,
  "created_at" : "2012-01-04 21:22:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Mayors",
      "screen_name" : "usmayors",
      "indices" : [ 3, 12 ],
      "id_str" : "15012352",
      "id" : 15012352
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 78, 83 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154660771186491394",
  "text" : "RT @usmayors: President Obama's appointment of Richard Cordray as Director of @CFPB is a win for Wall Street accountability.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 64, 69 ],
        "id_str" : "234826866",
        "id" : 234826866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154658833493528576",
    "text" : "President Obama's appointment of Richard Cordray as Director of @CFPB is a win for Wall Street accountability.",
    "id" : 154658833493528576,
    "created_at" : "2012-01-04 20:21:53 +0000",
    "user" : {
      "name" : "U.S. Mayors",
      "screen_name" : "usmayors",
      "protected" : false,
      "id_str" : "15012352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458685000167084032\/OUALluiV_normal.png",
      "id" : 15012352,
      "verified" : false
    }
  },
  "id" : 154660771186491394,
  "created_at" : "2012-01-04 20:29:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AG George Jepsen",
      "screen_name" : "AGJepsen",
      "indices" : [ 3, 12 ],
      "id_str" : "238649532",
      "id" : 238649532
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 80, 85 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154649963853389824",
  "text" : "RT @AGJepsen: Pres. Obama's appointment of Richard Cordray as the first head of @CFPB is a historic step toward protecting consumers: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 66, 71 ],
        "id_str" : "234826866",
        "id" : 234826866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/HBDMOp7l",
        "expanded_url" : "http:\/\/1.usa.gov\/zwtAl0",
        "display_url" : "1.usa.gov\/zwtAl0"
      } ]
    },
    "geo" : { },
    "id_str" : "154647300285808640",
    "text" : "Pres. Obama's appointment of Richard Cordray as the first head of @CFPB is a historic step toward protecting consumers: http:\/\/t.co\/HBDMOp7l",
    "id" : 154647300285808640,
    "created_at" : "2012-01-04 19:36:04 +0000",
    "user" : {
      "name" : "AG George Jepsen",
      "screen_name" : "AGJepsen",
      "protected" : false,
      "id_str" : "238649532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1216499319\/GJ_Headshot_normal.jpg",
      "id" : 238649532,
      "verified" : false
    }
  },
  "id" : 154649963853389824,
  "created_at" : "2012-01-04 19:46:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154649503444647936",
  "text" : "RT @PressSec: Cordray has broad support from Dems AND Repubs across country, including majority of GOP AG's. Senate GOP refused him an u ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154638352564502528",
    "text" : "Cordray has broad support from Dems AND Repubs across country, including majority of GOP AG's. Senate GOP refused him an up-or-down vote.",
    "id" : 154638352564502528,
    "created_at" : "2012-01-04 19:00:30 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 154649503444647936,
  "created_at" : "2012-01-04 19:44:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 33, 38 ],
      "id_str" : "234826866",
      "id" : 234826866
    }, {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 70, 85 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/j0Xexz5E",
      "expanded_url" : "http:\/\/huff.to\/AwAziq",
      "display_url" : "huff.to\/AwAziq"
    } ]
  },
  "geo" : { },
  "id_str" : "154647037256798208",
  "text" : "\"Standing Up for Consumers\": New @CFPB Director Richard Cordray posts @huffingtonpost: http:\/\/t.co\/j0Xexz5E",
  "id" : 154647037256798208,
  "created_at" : "2012-01-04 19:35:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 31, 43 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154641371112808450",
  "text" : "RT @GovernorOMalley: I commend @BarackObama for appointing Richard Cordray as the 1st Director of the Consumer Financial Protection Bureau.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 10, 22 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154638176898650112",
    "text" : "I commend @BarackObama for appointing Richard Cordray as the 1st Director of the Consumer Financial Protection Bureau.",
    "id" : 154638176898650112,
    "created_at" : "2012-01-04 18:59:49 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 154641371112808450,
  "created_at" : "2012-01-04 19:12:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schneiderman",
      "screen_name" : "AGSchneiderman",
      "indices" : [ 3, 18 ],
      "id_str" : "132496568",
      "id" : 132496568
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 66, 71 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cordray",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154641312073777152",
  "text" : "RT @AGSchneiderman: Pres Obama's appt of Richard #Cordray to head @CFPB is a victory for American families & consumers who deserve prote ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 46, 51 ],
        "id_str" : "234826866",
        "id" : 234826866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cordray",
        "indices" : [ 29, 37 ]
      }, {
        "text" : "CFPB",
        "indices" : [ 123, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154631195056025600",
    "text" : "Pres Obama's appt of Richard #Cordray to head @CFPB is a victory for American families & consumers who deserve protection. #CFPB",
    "id" : 154631195056025600,
    "created_at" : "2012-01-04 18:32:04 +0000",
    "user" : {
      "name" : "Eric Schneiderman",
      "screen_name" : "AGSchneiderman",
      "protected" : false,
      "id_str" : "132496568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738740865707868161\/gzD4g6BB_normal.jpg",
      "id" : 132496568,
      "verified" : true
    }
  },
  "id" : 154641312073777152,
  "created_at" : "2012-01-04 19:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/FnAFXKbi",
      "expanded_url" : "http:\/\/bit.ly\/wzWxER",
      "display_url" : "bit.ly\/wzWxER"
    } ]
  },
  "geo" : { },
  "id_str" : "154637148153331712",
  "text" : "RT @jesseclee44: Cleveland Plain Dealer: \"Cordray's appointment gives CFPB instant clout: Plain Dealing\" http:\/\/t.co\/FnAFXKbi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/FnAFXKbi",
        "expanded_url" : "http:\/\/bit.ly\/wzWxER",
        "display_url" : "bit.ly\/wzWxER"
      } ]
    },
    "geo" : { },
    "id_str" : "154636563769331712",
    "text" : "Cleveland Plain Dealer: \"Cordray's appointment gives CFPB instant clout: Plain Dealing\" http:\/\/t.co\/FnAFXKbi",
    "id" : 154636563769331712,
    "created_at" : "2012-01-04 18:53:24 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 154637148153331712,
  "created_at" : "2012-01-04 18:55:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154635118860976128",
  "text" : "RT @WHLive: Obama: Now is not the time to play politics while people\u2019s livelihoods are at stake.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154635085084241920",
    "text" : "Obama: Now is not the time to play politics while people\u2019s livelihoods are at stake.",
    "id" : 154635085084241920,
    "created_at" : "2012-01-04 18:47:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 154635118860976128,
  "created_at" : "2012-01-04 18:47:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154632382518001664",
  "text" : "RT @WHLive: Obama: Financial firms have armies of lobbyists in Washington looking out for their interests. It\u2019s time someone fought for  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154632342269468673",
    "text" : "Obama: Financial firms have armies of lobbyists in Washington looking out for their interests. It\u2019s time someone fought for you, too.",
    "id" : 154632342269468673,
    "created_at" : "2012-01-04 18:36:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 154632382518001664,
  "created_at" : "2012-01-04 18:36:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 56, 61 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154632046260662274",
  "text" : "RT @WHLive: Obama on appointing Richard Cordray to lead @cfpb: He\u2019ll be in charge of 1 thing: looking out for the best interests of Amer ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 44, 49 ],
        "id_str" : "234826866",
        "id" : 234826866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154631990015033344",
    "text" : "Obama on appointing Richard Cordray to lead @cfpb: He\u2019ll be in charge of 1 thing: looking out for the best interests of American consumers",
    "id" : 154631990015033344,
    "created_at" : "2012-01-04 18:35:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 154632046260662274,
  "created_at" : "2012-01-04 18:35:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 109, 116 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "154630372129378304",
  "text" : "RT @WHLive: Happening now: Watch President Obama's remarks on the economy live: http:\/\/t.co\/g5ih2w0F Follow: @WHLive",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 97, 104 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "154630326545678336",
    "text" : "Happening now: Watch President Obama's remarks on the economy live: http:\/\/t.co\/g5ih2w0F Follow: @WHLive",
    "id" : 154630326545678336,
    "created_at" : "2012-01-04 18:28:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 154630372129378304,
  "created_at" : "2012-01-04 18:28:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "154629772394246144",
  "text" : "Happening now: President Obama speaks on the economy from Cleveland, Ohio. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 154629772394246144,
  "created_at" : "2012-01-04 18:26:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 64, 69 ],
      "id_str" : "234826866",
      "id" : 234826866
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 71, 82 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/uhANyQPB",
      "expanded_url" : "http:\/\/wh.gov\/Wrh",
      "display_url" : "wh.gov\/Wrh"
    } ]
  },
  "geo" : { },
  "id_str" : "154593604306862082",
  "text" : "Today, President Obama will appoint Richard Cordray to lead the @cfpb. @pfeiffer44 on America's consumer watchdog: http:\/\/t.co\/uhANyQPB",
  "id" : 154593604306862082,
  "created_at" : "2012-01-04 16:02:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154577524230328320",
  "text" : "RT @pfeiffer44: We Can't Wait: Today in Ohio, President Obama will announce the recess appointment of Consumer Watchdog Richard Cordray  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/BjQ2z4fq",
        "expanded_url" : "http:\/\/apne.ws\/8JyTJ",
        "display_url" : "apne.ws\/8JyTJ"
      } ]
    },
    "geo" : { },
    "id_str" : "154577412749934593",
    "text" : "We Can't Wait: Today in Ohio, President Obama will announce the recess appointment of Consumer Watchdog Richard Cordray http:\/\/t.co\/BjQ2z4fq",
    "id" : 154577412749934593,
    "created_at" : "2012-01-04 14:58:21 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 154577524230328320,
  "created_at" : "2012-01-04 14:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "154577301139488768",
  "text" : "Today, President Obama travels to Cleveland, OH to speak on the economy @ Shaker Heights High. Watch @ 1:15 ET on http:\/\/t.co\/u95y7hhB",
  "id" : 154577301139488768,
  "created_at" : "2012-01-04 14:57:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154576634358403072",
  "text" : "RT @arneduncan: Happy New Year. Parents & teachers, what education goal(s) do you have for your child\/students in 2012?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154576321752743936",
    "text" : "Happy New Year. Parents & teachers, what education goal(s) do you have for your child\/students in 2012?",
    "id" : 154576321752743936,
    "created_at" : "2012-01-04 14:54:01 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 154576634358403072,
  "created_at" : "2012-01-04 14:55:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/TwTJDtfX",
      "expanded_url" : "http:\/\/whitehouse.gov\/blog\/2012\/01\/03\/archives-president-obama-signs-james-zadroga-911-health-and-compensation-act",
      "display_url" : "whitehouse.gov\/blog\/2012\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154358340498108416",
  "text" : "From the Archives: President Obama Signs the James Zadroga 9\/11 Health & Compensation Act: http:\/\/t.co\/TwTJDtfX",
  "id" : 154358340498108416,
  "created_at" : "2012-01-04 00:27:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154311976355500032",
  "text" : "RT @SBAgov: The Small Business Innovation Research (SBIR) program is extended for 6 years, supporting #smallbiz R&D, job creation: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smallbiz",
        "indices" : [ 90, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/GWaVnUnk",
        "expanded_url" : "http:\/\/go.usa.gov\/NJY",
        "display_url" : "go.usa.gov\/NJY"
      } ]
    },
    "geo" : { },
    "id_str" : "154232025958723584",
    "text" : "The Small Business Innovation Research (SBIR) program is extended for 6 years, supporting #smallbiz R&D, job creation: http:\/\/t.co\/GWaVnUnk",
    "id" : 154232025958723584,
    "created_at" : "2012-01-03 16:05:55 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 154311976355500032,
  "created_at" : "2012-01-03 21:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 21, 31 ],
      "id_str" : "18215973",
      "id" : 18215973
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 34, 45 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/QNMGHzTO",
      "expanded_url" : "http:\/\/www.flickr.com\/\/photos\/whitehouse\/sets\/72157628633082149\/show\/",
      "display_url" : "flickr.com\/\/photos\/whiteh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154253477445500928",
  "text" : "2011 Year in Photos: @petesouza & @whitehouse photo office compiles favorite images from 2011. View the slideshow: http:\/\/t.co\/QNMGHzTO",
  "id" : 154253477445500928,
  "created_at" : "2012-01-03 17:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "resolution",
      "indices" : [ 26, 37 ]
    }, {
      "text" : "newyear",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "volunteer",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154228719106535424",
  "text" : "RT @ServeDotGov: Making a #resolution for the #newyear? Consider challenging yourself to more service & #volunteer activities! 1.usa.gov ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "resolution",
        "indices" : [ 9, 20 ]
      }, {
        "text" : "newyear",
        "indices" : [ 29, 37 ]
      }, {
        "text" : "volunteer",
        "indices" : [ 87, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154226806969483264",
    "text" : "Making a #resolution for the #newyear? Consider challenging yourself to more service & #volunteer activities! 1.usa.gov\/tkzbMB",
    "id" : 154226806969483264,
    "created_at" : "2012-01-03 15:45:10 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 154228719106535424,
  "created_at" : "2012-01-03 15:52:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHInternship",
      "indices" : [ 27, 40 ]
    }, {
      "text" : "AWESOME",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/QtcDg447",
      "expanded_url" : "http:\/\/wh.gov\/internship",
      "display_url" : "wh.gov\/internship"
    } ]
  },
  "geo" : { },
  "id_str" : "154228146898599936",
  "text" : "Reason # 14 to apply for a #WHInternship: \u201CRan into Bo, the Obama family dog, in the hallway. #AWESOME\u201D http:\/\/t.co\/QtcDg447",
  "id" : 154228146898599936,
  "created_at" : "2012-01-03 15:50:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 102, 110 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/t5bDZgX8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=tkbSON2C8_M&feature=share",
      "display_url" : "youtube.com\/watch?v=tkbSON\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "153586560250556416",
  "text" : "Check out President Obama's Weekly Address: Working Together in the New Year http:\/\/t.co\/t5bDZgX8 via @youtube",
  "id" : 153586560250556416,
  "created_at" : "2012-01-01 21:21:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/n1HVt2Fk",
      "expanded_url" : "http:\/\/ow.ly\/8eLTX",
      "display_url" : "ow.ly\/8eLTX"
    } ]
  },
  "geo" : { },
  "id_str" : "153339716656304128",
  "text" : "\"I want to wish everyone a happy & healthy New Year\" -President Obama in his Weekly Address. Watch: http:\/\/t.co\/n1HVt2Fk",
  "id" : 153339716656304128,
  "created_at" : "2012-01-01 05:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]