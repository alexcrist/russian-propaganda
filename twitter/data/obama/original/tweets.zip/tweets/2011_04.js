Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64512618945183744",
  "text" : "President Obama just presented a parody movie trailer @ the #WHCD Enjoy: http:\/\/www.youtube.com\/watch?v=508aCh2eVOI",
  "id" : 64512618945183744,
  "created_at" : "2011-05-01 02:13:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64413804255133696",
  "text" : "RT @fema: Survivors in eligible counties, apply for assistance: www.disasterassistance.gov http:\/\/m.fema.gov 800-621-3362 TTY 800-462-7585",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64367439277862912",
    "text" : "Survivors in eligible counties, apply for assistance: www.disasterassistance.gov http:\/\/m.fema.gov 800-621-3362 TTY 800-462-7585",
    "id" : 64367439277862912,
    "created_at" : "2011-04-30 16:36:08 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 64413804255133696,
  "created_at" : "2011-04-30 19:40:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64319371887116288",
  "text" : "President Obama renews call to invest in energy of the future, instead of subsidizing energy of the past: http:\/\/1.usa.gov\/lQtQ0l",
  "id" : 64319371887116288,
  "created_at" : "2011-04-30 13:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64087670871166976",
  "text" : "End your Friday with some nice West Wing Week http:\/\/wh.gov\/CcD",
  "id" : 64087670871166976,
  "created_at" : "2011-04-29 22:04:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64085927248666625",
  "text" : "Deadline for voting in Commencement Challenge: 11:59EDT tonight. Choose which HS gets Obama as their speaker http:\/\/wh.gov\/Cac",
  "id" : 64085927248666625,
  "created_at" : "2011-04-29 21:57:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 15, 24 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64084981676384256",
  "text" : "Statement from @PressSec on Syrian human rights abuses, EO on sanctions against those responsible, support UN condemnation http:\/\/wh.gov\/C1U",
  "id" : 64084981676384256,
  "created_at" : "2011-04-29 21:53:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64076950481809409",
  "text" : "New photo gallery: President Obama & the First Lady tour Alabama http:\/\/wh.gov\/C1k",
  "id" : 64076950481809409,
  "created_at" : "2011-04-29 21:21:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64073072168280064",
  "text" : "6:55 EDT: President Obama delivers the commencement address at Miami Dade College, watch live: http:\/\/wh.gov\/Ca6",
  "id" : 64073072168280064,
  "created_at" : "2011-04-29 21:06:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64071252620488704",
  "text" : "Jared Bernstein on an historic meeting btwn Obama & Memphis Sanitation Workers, who MLK was supporting when he was taken: http:\/\/wh.gov\/CCY",
  "id" : 64071252620488704,
  "created_at" : "2011-04-29 20:59:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64063876798496768",
  "text" : "The President in Alabama: \"We're Going to Make Sure that You\u2019re Not Forgotten\" Photo\/transcript: http:\/\/wh.gov\/CCx",
  "id" : 64063876798496768,
  "created_at" : "2011-04-29 20:29:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHSJournal",
      "screen_name" : "DHSJournal",
      "indices" : [ 3, 14 ],
      "id_str" : "376234273",
      "id" : 376234273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Alabama",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64015199212027905",
  "text" : "RT @DHSJournal: Those in #Alabama who sustained losses in the designated counties can apply for assistance at disasterassistance.gov or  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Alabama",
        "indices" : [ 9, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64013957312155649",
    "text" : "Those in #Alabama who sustained losses in the designated counties can apply for assistance at disasterassistance.gov or 18006213362",
    "id" : 64013957312155649,
    "created_at" : "2011-04-29 17:11:31 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 64015199212027905,
  "created_at" : "2011-04-29 17:16:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64011623442034688",
  "text" : "Photo of the Day: The President in the Blue Room before announcing key members of national security team  http:\/\/twitpic.com\/4r1y2n",
  "id" : 64011623442034688,
  "created_at" : "2011-04-29 17:02:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64004706070040576",
  "text" : "RT @NASA: Endeavour\u2019s launch has been scrubbed for at least 48 hours because of an issue with Auxiliary Power Unit 1 heaters.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "64001804521844738",
    "text" : "Endeavour\u2019s launch has been scrubbed for at least 48 hours because of an issue with Auxiliary Power Unit 1 heaters.",
    "id" : 64001804521844738,
    "created_at" : "2011-04-29 16:23:13 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 64004706070040576,
  "created_at" : "2011-04-29 16:34:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63996314073047040",
  "text" : "RT @pfeiffer44: Great column from NYT's Brooks about some really great stuff happening in government http:\/\/nyti.ms\/iz33wy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63987812239810561",
    "text" : "Great column from NYT's Brooks about some really great stuff happening in government http:\/\/nyti.ms\/iz33wy",
    "id" : 63987812239810561,
    "created_at" : "2011-04-29 15:27:37 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 63996314073047040,
  "created_at" : "2011-04-29 16:01:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63679506749198336",
  "text" : "3:10 President Obama makes personnel announcements, watch live: http:\/\/wh.gov\/live",
  "id" : 63679506749198336,
  "created_at" : "2011-04-28 19:02:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63645842380300288",
  "text" : "President travels to Alabama tomorrow to see damage, meet w\/ Governor & Alabamians; photo of briefing this morning: http:\/\/bit.ly\/kX6dSB",
  "id" : 63645842380300288,
  "created_at" : "2011-04-28 16:48:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63620708453986305",
  "text" : "Helping every American w\/ autism achieve their full potential is a top priority  for this administration: http:\/\/wh.gov\/CO8",
  "id" : 63620708453986305,
  "created_at" : "2011-04-28 15:08:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63590749236768770",
  "text" : "Obama on tornadoes: \"deepest condolences to the families of those who lost their lives\u2026stand ready to continue to help\" http:\/\/wh.gov\/COr",
  "id" : 63590749236768770,
  "created_at" : "2011-04-28 13:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "transit",
      "indices" : [ 46, 54 ]
    }, {
      "text" : "gas",
      "indices" : [ 87, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63310659605106688",
  "text" : "RT @RayLaHood: Obama Administration strategic #transit investments help Americans keep #gas $$$ in their pockets http:\/\/bit.ly\/fNflVP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "transit",
        "indices" : [ 31, 39 ]
      }, {
        "text" : "gas",
        "indices" : [ 72, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "63245756169060352",
    "text" : "Obama Administration strategic #transit investments help Americans keep #gas $$$ in their pockets http:\/\/bit.ly\/fNflVP",
    "id" : 63245756169060352,
    "created_at" : "2011-04-27 14:18:57 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 63310659605106688,
  "created_at" : "2011-04-27 18:36:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63274242925543425",
  "text" : "3 Days left to rate the Commencement Challenge finalists \u2013 watch a highlight reel of the schools' videos http:\/\/wh.gov\/Cig",
  "id" : 63274242925543425,
  "created_at" : "2011-04-27 16:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 88, 95 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 98, 113 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63273010102157313",
  "text" : "How can gov\u2019t help entrepreneurs startup & scale? Submit your ideas & vote, courtesy of @SBAgov & @startupamerica http:\/\/is.gd\/CJm6IJ",
  "id" : 63273010102157313,
  "created_at" : "2011-04-27 16:07:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63248926781865984",
  "text" : "The President: \"We\u2019ve got big problems to solve\u2026we can solve them, but we\u2019re going to have to focus on them - not on this\" http:\/\/wh.gov\/Cix",
  "id" : 63248926781865984,
  "created_at" : "2011-04-27 14:31:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63242087478472704",
  "text" : "Obama hopes we can move on to debating issues that matter to the American people. Long form birth certificate: http:\/\/wh.gov\/Cl6",
  "id" : 63242087478472704,
  "created_at" : "2011-04-27 14:04:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63239247020302337",
  "text" : "\"We're not going to be able to solve our problems if we're distracted.\" - POTUS on birth certificate http:\/\/www.wh.gov\/live",
  "id" : 63239247020302337,
  "created_at" : "2011-04-27 13:53:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63238002079580160",
  "text" : "Happening Now: President Obama speaks to the press beginning at 9:45 a.m. EDT. Watch live at http:\/\/wh.gov\/live.",
  "id" : 63238002079580160,
  "created_at" : "2011-04-27 13:48:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63225455687368705",
  "text" : "Obama's long form birth certificate released so that America can move on to real issues that matter to our future http:\/\/goo.gl\/fNmdR",
  "id" : 63225455687368705,
  "created_at" : "2011-04-27 12:58:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62941303528374273",
  "text" : "High gas prices=even more big oil profits. President to Congress: drop $4B in big oil tax breaks, invest in clean energy http:\/\/wh.gov\/CqC",
  "id" : 62941303528374273,
  "created_at" : "2011-04-26 18:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 92, 102 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62542220024225792",
  "text" : "Photo of the Day: The President boards AF1, reflected in one of its engines at left. Credit @petesouza  http:\/\/twitpic.com\/4pespq",
  "id" : 62542220024225792,
  "created_at" : "2011-04-25 15:43:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ihatemondays",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "62522486302056448",
  "text" : "Know who doesn\u2019t #ihatemondays? Tens of thousands of kids at the 133rd WH Easter Egg Roll. Watch all day: http:\/\/wh.gov\/live",
  "id" : 62522486302056448,
  "created_at" : "2011-04-25 14:24:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61559666982920192",
  "text" : "President Obama on #Syria: US condemns...use of force by the Syrian government against demonstrators. Statement: http:\/\/wh.gov\/aJC",
  "id" : 61559666982920192,
  "created_at" : "2011-04-22 22:39:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 3, 18 ],
      "id_str" : "73181712",
      "id" : 73181712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61537955038236672",
  "text" : "RT @TheJusticeDept: Attorney General Holder on Protecting Consumers at the Pump http:\/\/go.usa.gov\/bc0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61536127668072448",
    "text" : "Attorney General Holder on Protecting Consumers at the Pump http:\/\/go.usa.gov\/bc0",
    "id" : 61536127668072448,
    "created_at" : "2011-04-22 21:05:30 +0000",
    "user" : {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "protected" : false,
      "id_str" : "73181712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445550654\/twitter_logo_normal.png",
      "id" : 73181712,
      "verified" : true
    }
  },
  "id" : 61537955038236672,
  "created_at" : "2011-04-22 21:12:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "indices" : [ 3, 13 ],
      "id_str" : "1175221",
      "id" : 1175221
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61535155256434688",
  "text" : "MT @digiphile: @whitehouse humor is a fine spice but couldn't you feature the millionth here? \/\/Fair. Andrew Blum FTW http:\/\/on.fb.me\/g1DGWC",
  "id" : 61535155256434688,
  "created_at" : "2011-04-22 21:01:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPAGov",
      "indices" : [ 3, 10 ],
      "id_str" : "1604108887",
      "id" : 1604108887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61506045750677504",
  "text" : "RT @EPAgov: Happy Earth Day! Check out Adm. Jackson's blog post for lots of ways you can help protect the environment! http:\/\/1.usa.gov\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61494413075021825",
    "text" : "Happy Earth Day! Check out Adm. Jackson's blog post for lots of ways you can help protect the environment! http:\/\/1.usa.gov\/htoor0 Pls. RT.",
    "id" : 61494413075021825,
    "created_at" : "2011-04-22 18:19:45 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 61506045750677504,
  "created_at" : "2011-04-22 19:05:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61497354339098625",
  "text" : "White House Facebook page has 999,792 fans, now's your chance to be 1 millionth. Prize: As usual, nothing. http:\/\/facebook.com\/WhiteHouse",
  "id" : 61497354339098625,
  "created_at" : "2011-04-22 18:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61467476541706240",
  "text" : "Photo of the Day: The President turns the camera back at WH videographer\/ West Wing Week man Arun Chaudhary  http:\/\/twitpic.com\/4o22xc",
  "id" : 61467476541706240,
  "created_at" : "2011-04-22 16:32:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 70, 79 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61456338777157633",
  "text" : "Fresh West Wing Week: Town Halls down in VA, Reno & behind the scenes @facebook http:\/\/wh.gov\/atR",
  "id" : 61456338777157633,
  "created_at" : "2011-04-22 15:48:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61158533160378368",
  "text" : "4:30EDT - Open for Questions: Earth Day from the South Lawn w\/ CEQ Chair Sutley & Heather Zichal. Join discussion via FB http:\/\/wh.gov\/aF9",
  "id" : 61158533160378368,
  "created_at" : "2011-04-21 20:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61130237198602240",
  "text" : "2:50EDT: Obama town hall at Reno renewable energy co. on cutting the deficit & winning the future. Watch: http:\/\/wh.gov\/live",
  "id" : 61130237198602240,
  "created_at" : "2011-04-21 18:12:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61099909679550465",
  "text" : "The President at Facebook - photos, transcript, highlights. \"make sure this isn\u2019t just a one-way conversation...\" http:\/\/wh.gov\/aeM",
  "id" : 61099909679550465,
  "created_at" : "2011-04-21 16:12:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61085662547423232",
  "text" : "Your turn: choose the winner from 6 inspiring schools' videos in Commencement Challenge. Prize: Obama at their graduation http:\/\/wh.gov\/aek",
  "id" : 61085662547423232,
  "created_at" : "2011-04-21 15:15:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60828299382898689",
  "text" : "Follow-up on the President\u2019s Facebook Town Hall: Panel on Women in Tech now, 7:30EDT Startup America http:\/\/on.fb.me\/dF8fiG",
  "id" : 60828299382898689,
  "created_at" : "2011-04-20 22:12:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 40, 49 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60827497255813120",
  "text" : "RT @pfeiffer44: Here's a statement from @PressSec on journalists killed or wounded in Libya http:\/\/wh.gov\/aMv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 24, 33 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60827047186006017",
    "text" : "Here's a statement from @PressSec on journalists killed or wounded in Libya http:\/\/wh.gov\/aMv",
    "id" : 60827047186006017,
    "created_at" : "2011-04-20 22:07:52 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 60827497255813120,
  "created_at" : "2011-04-20 22:09:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60801275335421952",
  "text" : "Starting soon: President Obama's Facebook Town Hall, watch & join the discussion http:\/\/facebook.com\/WhiteHouse",
  "id" : 60801275335421952,
  "created_at" : "2011-04-20 20:25:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Census Bureau",
      "screen_name" : "uscensusbureau",
      "indices" : [ 3, 18 ],
      "id_str" : "23092890",
      "id" : 23092890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 38, 47 ]
    }, {
      "text" : "GreenData",
      "indices" : [ 71, 81 ]
    }, {
      "text" : "Census",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60712771393814528",
  "text" : "RT @uscensusbureau: Are you ready for #EarthDay? Get prepared with our #GreenData blog from Random Samplings. http:\/\/go.usa.gov\/THH #Census",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 18, 27 ]
      }, {
        "text" : "GreenData",
        "indices" : [ 51, 61 ]
      }, {
        "text" : "Census",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60693376806297600",
    "text" : "Are you ready for #EarthDay? Get prepared with our #GreenData blog from Random Samplings. http:\/\/go.usa.gov\/THH #Census",
    "id" : 60693376806297600,
    "created_at" : "2011-04-20 13:16:43 +0000",
    "user" : {
      "name" : "U.S. Census Bureau",
      "screen_name" : "uscensusbureau",
      "protected" : false,
      "id_str" : "23092890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687724707056095232\/SugZ1cgb_normal.jpg",
      "id" : 23092890,
      "verified" : true
    }
  },
  "id" : 60712771393814528,
  "created_at" : "2011-04-20 14:33:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60696721516265472",
  "text" : "On tap: President Obama at Facebook HQ taking questions on plan for shared responsibility & prosperity 1:45PST 4:45EST http:\/\/wh.gov\/a5B",
  "id" : 60696721516265472,
  "created_at" : "2011-04-20 13:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "android",
      "indices" : [ 44, 52 ]
    }, {
      "text" : "iPhone",
      "indices" : [ 54, 61 ]
    }, {
      "text" : "iOS",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60434309479284736",
  "text" : "RT @macon44: .@whitehouse mobile app now on #android, #iPhone update; in past 2 mos, 6.6% of WH.gov visits are #iOS or Android http:\/\/go ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "android",
        "indices" : [ 31, 39 ]
      }, {
        "text" : "iPhone",
        "indices" : [ 41, 48 ]
      }, {
        "text" : "iOS",
        "indices" : [ 98, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60426969501794304",
    "text" : ".@whitehouse mobile app now on #android, #iPhone update; in past 2 mos, 6.6% of WH.gov visits are #iOS or Android http:\/\/goo.gl\/ysgds",
    "id" : 60426969501794304,
    "created_at" : "2011-04-19 19:38:06 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 60434309479284736,
  "created_at" : "2011-04-19 20:07:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60398718171623424",
  "text" : "In case you missed it: Photo gallery of the First Lady & Dr. Jill Biden honoring our military & their families: http:\/\/wh.gov\/amJ",
  "id" : 60398718171623424,
  "created_at" : "2011-04-19 17:45:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60371330662535169",
  "text" : "\"Putting it Plainly\": Update on new efforts to make government agencies speak clearly instead of government-ese http:\/\/wh.gov\/aH7",
  "id" : 60371330662535169,
  "created_at" : "2011-04-19 15:57:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60356953414705152",
  "text" : "Now: President Obama at town hall in VA on the budget, shared responsibility & prosperity. Watch: http:\/\/wh.gov\/live",
  "id" : 60356953414705152,
  "created_at" : "2011-04-19 14:59:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startupamerica",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60347588146237440",
  "text" : "RT @startupamerica: Our New Website is LIVE with great new features for YOU: http:\/\/ar.gy\/GPr #startupamerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "startupamerica",
        "indices" : [ 74, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60347175980376064",
    "text" : "Our New Website is LIVE with great new features for YOU: http:\/\/ar.gy\/GPr #startupamerica",
    "id" : 60347175980376064,
    "created_at" : "2011-04-19 14:21:02 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 60347588146237440,
  "created_at" : "2011-04-19 14:22:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60336946886623232",
  "text" : "On tap: Easter breakfast earlier; Town hall in VA on shared responsibility & prosperity in budget; Broad meeting on immigration",
  "id" : 60336946886623232,
  "created_at" : "2011-04-19 13:40:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 3, 17 ],
      "id_str" : "28576135",
      "id" : 28576135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60336496363831297",
  "text" : "RT @thejointstaff: Great visit w\/ troops in Afghanistan today. Thanked them for their service.  Brought Bob Griese and Mayra Veronica wi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60334097595240449",
    "text" : "Great visit w\/ troops in Afghanistan today. Thanked them for their service.  Brought Bob Griese and Mayra Veronica with me.",
    "id" : 60334097595240449,
    "created_at" : "2011-04-19 13:29:04 +0000",
    "user" : {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "protected" : false,
      "id_str" : "28576135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459045440063672320\/SOEE5LHU_normal.png",
      "id" : 28576135,
      "verified" : true
    }
  },
  "id" : 60336496363831297,
  "created_at" : "2011-04-19 13:38:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60090500622987264",
  "text" : "Video\/photos: President gives Air Force Academy football Commander-in-Chief Trophy \"A Group That Has a Lot to Be Proud Of\" http:\/\/wh.gov\/aoQ",
  "id" : 60090500622987264,
  "created_at" : "2011-04-18 21:21:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60068924838002688",
  "text" : "Ahead of WH Seder tonight, 8 great Passover recipes from 8 great Jewish chefs http:\/\/wh.gov\/aoy",
  "id" : 60068924838002688,
  "created_at" : "2011-04-18 19:55:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60047752905768960",
  "text" : "RT @pfeiffer44: POTUS and VPOTUS release their tax returns. View the returns and their tax receipts here: http:\/\/1.usa.gov\/hlRHRl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "60046201927643136",
    "text" : "POTUS and VPOTUS release their tax returns. View the returns and their tax receipts here: http:\/\/1.usa.gov\/hlRHRl",
    "id" : 60046201927643136,
    "created_at" : "2011-04-18 18:25:04 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 60047752905768960,
  "created_at" : "2011-04-18 18:31:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60017853973270528",
  "text" : "President Obama's Facebook Invite: Facebook Town Hall on Wednesday 4:45 EST, 1:45 PST http:\/\/on.fb.me\/zy1YS",
  "id" : 60017853973270528,
  "created_at" : "2011-04-18 16:32:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59985488248963075",
  "text" : "RT @PressSec: i brief today at 12 noon. What questions would you have if you were in the briefing room?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "59974442209640448",
    "text" : "i brief today at 12 noon. What questions would you have if you were in the briefing room?",
    "id" : 59974442209640448,
    "created_at" : "2011-04-18 13:39:55 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 59985488248963075,
  "created_at" : "2011-04-18 14:23:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "59260484230184960",
  "text" : "\"We can live within our means & live up to the values we share as Americans.\u201D President Obama, Weekly Address: http:\/\/1.usa.gov\/ifVvWb",
  "id" : 59260484230184960,
  "created_at" : "2011-04-16 14:22:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58997078348677120",
  "text" : "In SOTU, POTUS promised Americans could go online & see how their tax $ is spent for the 1st time. Now, you can: wh.gov\/taxreceipt",
  "id" : 58997078348677120,
  "created_at" : "2011-04-15 20:56:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58979882352377856",
  "text" : "It's Your West Wing Week: In \"Open for Business\" President Obama focuses on fiscal responsibility. http:\/\/wh.gov\/a73",
  "id" : 58979882352377856,
  "created_at" : "2011-04-15 19:47:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58974140522184704",
  "text" : "Photo of the Day: Members of the press cover a Fiscal Commission mtg w\/ the President. Video: http:\/\/wh.gov\/afN http:\/\/twitpic.com\/4l8dca",
  "id" : 58974140522184704,
  "created_at" : "2011-04-15 19:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58919918816608256",
  "text" : "Ever wonder how much of your tax dollars go to support education? Or health care? Find out: http:\/\/www.wh.gov\/taxreceipt",
  "id" : 58919918816608256,
  "created_at" : "2011-04-15 15:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Garan",
      "screen_name" : "Astro_Ron",
      "indices" : [ 3, 13 ],
      "id_str" : "82453323",
      "id" : 82453323
    }, {
      "name" : "TwitPic",
      "screen_name" : "TwitPic",
      "indices" : [ 22, 30 ],
      "id_str" : "12925072",
      "id" : 12925072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FromSpace",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58897678343479296",
  "text" : "RT @Astro_Ron: My 1st @Twitpic #FromSpace. Anyone know where in the world this is? http:\/\/twitpic.com\/4l4les",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TwitPic",
        "screen_name" : "TwitPic",
        "indices" : [ 7, 15 ],
        "id_str" : "12925072",
        "id" : 12925072
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FromSpace",
        "indices" : [ 16, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58891833455022081",
    "text" : "My 1st @Twitpic #FromSpace. Anyone know where in the world this is? http:\/\/twitpic.com\/4l4les",
    "id" : 58891833455022081,
    "created_at" : "2011-04-15 13:58:01 +0000",
    "user" : {
      "name" : "Ron Garan",
      "screen_name" : "Astro_Ron",
      "protected" : false,
      "id_str" : "82453323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472830575\/Ron-cropped_normal.jpg",
      "id" : 82453323,
      "verified" : true
    }
  },
  "id" : 58897678343479296,
  "created_at" : "2011-04-15 14:21:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58888850281476096",
  "text" : "Understand how & where your tax dollars are being spent -- you might be surprised: http:\/\/www.wh.gov\/taxreceipt",
  "id" : 58888850281476096,
  "created_at" : "2011-04-15 13:46:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul (PJ) Rieckhoff",
      "screen_name" : "PaulRieckhoff",
      "indices" : [ 3, 17 ],
      "id_str" : "21542518",
      "id" : 21542518
    }, {
      "name" : "IAVA",
      "screen_name" : "iava",
      "indices" : [ 48, 53 ],
      "id_str" : "12296312",
      "id" : 12296312
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 88, 99 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STH2011",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58887506631991296",
  "text" : "RT @PaulRieckhoff: Proud moment! Great image of @IAVA's #STH2011 vets w\/ the First Lady @WhiteHouse: http:\/\/flic.kr\/p\/9xPjVb #JoiningFor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IAVA",
        "screen_name" : "iava",
        "indices" : [ 29, 34 ],
        "id_str" : "12296312",
        "id" : 12296312
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 69, 80 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STH2011",
        "indices" : [ 37, 45 ]
      }, {
        "text" : "JoiningForces",
        "indices" : [ 106, 120 ]
      }, {
        "text" : "FLOTUS",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58664185952866304",
    "text" : "Proud moment! Great image of @IAVA's #STH2011 vets w\/ the First Lady @WhiteHouse: http:\/\/flic.kr\/p\/9xPjVb #JoiningForces #FLOTUS",
    "id" : 58664185952866304,
    "created_at" : "2011-04-14 22:53:26 +0000",
    "user" : {
      "name" : "Paul (PJ) Rieckhoff",
      "screen_name" : "PaulRieckhoff",
      "protected" : false,
      "id_str" : "21542518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759757525482934272\/luqdDEaA_normal.jpg",
      "id" : 21542518,
      "verified" : true
    }
  },
  "id" : 58887506631991296,
  "created_at" : "2011-04-15 13:40:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 21, 30 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58870621148418048",
  "text" : "RT @pfeiffer44: Read @USATODAY http:\/\/usat.ly\/fe747P on the new Tax Receipt & then go to whitehouse.gov\/taxreceipt to see where your tax ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA TODAY",
        "screen_name" : "USATODAY",
        "indices" : [ 5, 14 ],
        "id_str" : "15754281",
        "id" : 15754281
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58859815493046272",
    "text" : "Read @USATODAY http:\/\/usat.ly\/fe747P on the new Tax Receipt & then go to whitehouse.gov\/taxreceipt to see where your tax dollars go",
    "id" : 58859815493046272,
    "created_at" : "2011-04-15 11:50:48 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 58870621148418048,
  "created_at" : "2011-04-15 12:33:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed O'Keefe",
      "screen_name" : "edatpost",
      "indices" : [ 3, 12 ],
      "id_str" : "16930125",
      "id" : 16930125
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tax",
      "indices" : [ 28, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58870367967645696",
  "text" : "RT @edatpost: Where do your #tax dollars go? White House launches a personalized tax receipt http:\/\/www.whitehouse.gov\/taxreceipt (via . ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "former Macon44",
        "screen_name" : "macon44",
        "indices" : [ 122, 130 ],
        "id_str" : "776593497122082820",
        "id" : 776593497122082820
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tax",
        "indices" : [ 14, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58869698133098496",
    "text" : "Where do your #tax dollars go? White House launches a personalized tax receipt http:\/\/www.whitehouse.gov\/taxreceipt (via .@macon44)",
    "id" : 58869698133098496,
    "created_at" : "2011-04-15 12:30:04 +0000",
    "user" : {
      "name" : "Ed O'Keefe",
      "screen_name" : "edatpost",
      "protected" : false,
      "id_str" : "16930125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689054172432355328\/tPrzOOLe_normal.jpg",
      "id" : 16930125,
      "verified" : true
    }
  },
  "id" : 58870367967645696,
  "created_at" : "2011-04-15 12:32:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Sesame Street",
      "screen_name" : "sesamestreet",
      "indices" : [ 94, 107 ],
      "id_str" : "86330674",
      "id" : 86330674
    }, {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 108, 116 ],
      "id_str" : "36681590",
      "id" : 36681590
    }, {
      "name" : "Nick Jonas",
      "screen_name" : "nickjonas",
      "indices" : [ 117, 127 ],
      "id_str" : "56783491",
      "id" : 56783491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58648439369637888",
  "text" : "RT @JoiningForces: Happening Now: The First Lady & Dr. Biden host a military families show w\/ @SesameStreet @the_USO @nickjonas http:\/\/w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sesame Street",
        "screen_name" : "sesamestreet",
        "indices" : [ 75, 88 ],
        "id_str" : "86330674",
        "id" : 86330674
      }, {
        "name" : "USO",
        "screen_name" : "the_USO",
        "indices" : [ 89, 97 ],
        "id_str" : "36681590",
        "id" : 36681590
      }, {
        "name" : "Nick Jonas",
        "screen_name" : "nickjonas",
        "indices" : [ 98, 108 ],
        "id_str" : "56783491",
        "id" : 56783491
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58648232053575680",
    "text" : "Happening Now: The First Lady & Dr. Biden host a military families show w\/ @SesameStreet @the_USO @nickjonas http:\/\/www.wh.gov\/live",
    "id" : 58648232053575680,
    "created_at" : "2011-04-14 21:50:02 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 58648439369637888,
  "created_at" : "2011-04-14 21:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AffordableCareAct",
      "indices" : [ 67, 85 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58647027562713088",
  "text" : "RT @SBAgov: Pres Obama just signed repeal of 1099 requirement from #AffordableCareAct=less paperwork for #smallbiz: http:\/\/go.usa.gov\/Tnu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AffordableCareAct",
        "indices" : [ 55, 73 ]
      }, {
        "text" : "smallbiz",
        "indices" : [ 93, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58635596188487680",
    "text" : "Pres Obama just signed repeal of 1099 requirement from #AffordableCareAct=less paperwork for #smallbiz: http:\/\/go.usa.gov\/Tnu",
    "id" : 58635596188487680,
    "created_at" : "2011-04-14 20:59:50 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 58647027562713088,
  "created_at" : "2011-04-14 21:45:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58620489215651842",
  "text" : "Starting Now: Join us as we celebrate one year of West Wing Week with a live chat. Submit your questions and watch: http:\/\/bit.ly\/bLTH91",
  "id" : 58620489215651842,
  "created_at" : "2011-04-14 19:59:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58602106835304448",
  "text" : "Infographic: President Obama's approach to reduce the deficit & win the future summed up in 4 steps. http:\/\/twitpic.com\/4ktvuq",
  "id" : 58602106835304448,
  "created_at" : "2011-04-14 18:46:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58535993631973376",
  "text" : "Photo of the Day: The President reviews fiscal policy speech w\/ advisors. Video: http:\/\/wh.gov\/avZ http:\/\/twitpic.com\/4kr19b",
  "id" : 58535993631973376,
  "created_at" : "2011-04-14 14:24:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 72, 82 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58316230792200192",
  "text" : "New Photostream: Check out 85 behind the scenes photos from March, 1 of @petesouza favorites: http:\/\/wh.gov\/avw",
  "id" : 58316230792200192,
  "created_at" : "2011-04-13 23:50:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58310072341762049",
  "text" : "President Obama lays out his plan for a balanced approach to achieve $4 trillion in deficit reduction. Video: http:\/\/wh.gov\/avZ",
  "id" : 58310072341762049,
  "created_at" : "2011-04-13 23:26:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurewewant",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58237866945425408",
  "text" : "NOW: Brian Deese of the National Economic Council takes questions on the President\u2019s Speech. Watch: www.whitehouse.gov\/live\n#futurewewant",
  "id" : 58237866945425408,
  "created_at" : "2011-04-13 18:39:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurewewant",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58236404370653184",
  "text" : "\"We have to think about what\u2019s required to preserve the American Dream for future generations.\" -POTUS #futurewewant",
  "id" : 58236404370653184,
  "created_at" : "2011-04-13 18:33:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurewewant",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58232942517956608",
  "text" : "\"We cannot afford $1 trillion worth of tax cuts for every millionaire and billionaire in our society.\" -POTUS #futurewewant",
  "id" : 58232942517956608,
  "created_at" : "2011-04-13 18:19:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WLS-AM 890",
      "screen_name" : "wlsam890",
      "indices" : [ 3, 12 ],
      "id_str" : "90934547",
      "id" : 90934547
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 14, 20 ]
    }, {
      "text" : "futurewewant",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58232166961790976",
  "text" : "RT @wlsam890: #Obama: I\u2019m proposing a more balanced approach to achieve $4 trillion in deficit reduction over twelve years #futurewewant",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "futurewewant",
        "indices" : [ 109, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58231574637969410",
    "text" : "#Obama: I\u2019m proposing a more balanced approach to achieve $4 trillion in deficit reduction over twelve years #futurewewant",
    "id" : 58231574637969410,
    "created_at" : "2011-04-13 18:14:23 +0000",
    "user" : {
      "name" : "WLS-AM 890",
      "screen_name" : "wlsam890",
      "protected" : false,
      "id_str" : "90934547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784357363717382144\/xhXgi97E_normal.jpg",
      "id" : 90934547,
      "verified" : true
    }
  },
  "id" : 58232166961790976,
  "created_at" : "2011-04-13 18:16:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurewewant",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58231541603643393",
  "text" : "\"We don\u2019t have to choose between a future of debt and one where we forfeit investments in our people and country.\"-POTUS #futurewewant",
  "id" : 58231541603643393,
  "created_at" : "2011-04-13 18:14:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stanimal",
      "screen_name" : "stanimal13",
      "indices" : [ 3, 14 ],
      "id_str" : "67089609",
      "id" : 67089609
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 16, 22 ]
    }, {
      "text" : "futurewewant",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58229788673974272",
  "text" : "RT @stanimal13: #Obama: Any serious plan to tackle the deficit will require us to put everything on the table #futurewewant",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "futurewewant",
        "indices" : [ 94, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58229448402673664",
    "text" : "#Obama: Any serious plan to tackle the deficit will require us to put everything on the table #futurewewant",
    "id" : 58229448402673664,
    "created_at" : "2011-04-13 18:05:57 +0000",
    "user" : {
      "name" : "Stanimal",
      "screen_name" : "stanimal13",
      "protected" : false,
      "id_str" : "67089609",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476831389107486720\/8cZV-A8m_normal.jpeg",
      "id" : 67089609,
      "verified" : false
    }
  },
  "id" : 58229788673974272,
  "created_at" : "2011-04-13 18:07:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurewewant",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58228778157088768",
  "text" : "Dem's and Republicans \"must come together and restore the fiscal responsibility that served us so well in the '90s.\" -POTUS #futurewewant",
  "id" : 58228778157088768,
  "created_at" : "2011-04-13 18:03:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Access CA",
      "screen_name" : "healthaccess",
      "indices" : [ 3, 16 ],
      "id_str" : "21019697",
      "id" : 21019697
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurewewant",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58226797854199808",
  "text" : "RT @healthaccess: Obama: Not about cutting or spending: This is about the \"future we want\" #futurewewant",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "futurewewant",
        "indices" : [ 73, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58225848783863808",
    "text" : "Obama: Not about cutting or spending: This is about the \"future we want\" #futurewewant",
    "id" : 58225848783863808,
    "created_at" : "2011-04-13 17:51:38 +0000",
    "user" : {
      "name" : "Health Access CA",
      "screen_name" : "healthaccess",
      "protected" : false,
      "id_str" : "21019697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791772647679938560\/JswL2pDO_normal.jpg",
      "id" : 21019697,
      "verified" : false
    }
  },
  "id" : 58226797854199808,
  "created_at" : "2011-04-13 17:55:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurewewant",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58225200503848960",
  "text" : "President Obama speaks now about a balanced approach to reduce the deficit: http:\/\/goo.gl\/5r66 Use #futurewewant to join the conversation",
  "id" : 58225200503848960,
  "created_at" : "2011-04-13 17:49:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "futurewewant",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58212523752689665",
  "text" : "135pm: POTUS speaks abt balanced approach to reduce deficit & win the #futurewewant (use that to discuss) Q&A after: http:\/\/wh.gov\/live",
  "id" : 58212523752689665,
  "created_at" : "2011-04-13 16:58:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USPTO",
      "screen_name" : "uspto",
      "indices" : [ 3, 9 ],
      "id_str" : "16057477",
      "id" : 16057477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanTech",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "patent",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "green",
      "indices" : [ 117, 123 ]
    }, {
      "text" : "energy",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58185916644200448",
  "text" : "RT @uspto: We're hosting our first #CleanTech Partnership Meeting on April 27. RSVP at http:\/\/go.usa.gov\/TDg #patent #green #energy #USP ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanTech",
        "indices" : [ 24, 34 ]
      }, {
        "text" : "patent",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "green",
        "indices" : [ 106, 112 ]
      }, {
        "text" : "energy",
        "indices" : [ 113, 120 ]
      }, {
        "text" : "USPTO",
        "indices" : [ 121, 127 ]
      }, {
        "text" : "1p",
        "indices" : [ 128, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "58179699817459712",
    "text" : "We're hosting our first #CleanTech Partnership Meeting on April 27. RSVP at http:\/\/go.usa.gov\/TDg #patent #green #energy #USPTO #1p",
    "id" : 58179699817459712,
    "created_at" : "2011-04-13 14:48:16 +0000",
    "user" : {
      "name" : "USPTO",
      "screen_name" : "uspto",
      "protected" : false,
      "id_str" : "16057477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684014734937559040\/WhfNiuZx_normal.png",
      "id" : 16057477,
      "verified" : true
    }
  },
  "id" : 58185916644200448,
  "created_at" : "2011-04-13 15:12:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 46, 60 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58165802863566848",
  "text" : "Photo of the Day: First Lady greets the crowd @JoiningForces launch to support military families http:\/\/twitpic.com\/4kd5st",
  "id" : 58165802863566848,
  "created_at" : "2011-04-13 13:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hc",
      "indices" : [ 82, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57882061926694912",
  "text" : "RT @HealthCareGov: Just announced: Partnership for Patients initiative to improve #hc quality, safety & affordability http:\/\/1.usa.gov\/f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hc",
        "indices" : [ 63, 66 ]
      }, {
        "text" : "ptsafety",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57855371473195008",
    "text" : "Just announced: Partnership for Patients initiative to improve #hc quality, safety & affordability http:\/\/1.usa.gov\/fnFJ93 #ptsafety",
    "id" : 57855371473195008,
    "created_at" : "2011-04-12 17:19:30 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 57882061926694912,
  "created_at" : "2011-04-12 19:05:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57858898962550784",
  "text" : "Photo of the Day: President Obama returns to the Oval after surprising students. Video: http:\/\/wh.gov\/ayw http:\/\/twitpic.com\/4k2baq",
  "id" : 57858898962550784,
  "created_at" : "2011-04-12 17:33:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 117, 131 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 132, 140 ],
      "id_str" : "36681590",
      "id" : 36681590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57855926874546176",
  "text" : "POTUS: \"Behind every one in uniform stands a wife, a husband, a mom, a dad, a son, a daughter, a sister, a brother.\" @joiningforces @the_uso",
  "id" : 57855926874546176,
  "created_at" : "2011-04-12 17:21:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57850236269363200",
  "text" : "RT @JoiningForces: \"A challenge...to mobilize, take action & make a real commitment to supporting our military families.\u201D -First Lady #J ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 115, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57849962641367041",
    "text" : "\"A challenge...to mobilize, take action & make a real commitment to supporting our military families.\u201D -First Lady #JoiningForces",
    "id" : 57849962641367041,
    "created_at" : "2011-04-12 16:58:00 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 57850236269363200,
  "created_at" : "2011-04-12 16:59:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "joiningforces",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57845995697999873",
  "text" : "RT @JoiningForces: \"These families \u2013 these remarkable families \u2013 are the force behind the force.\u201D - President Obama launching #joiningforces",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "joiningforces",
        "indices" : [ 107, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57845647688208384",
    "text" : "\"These families \u2013 these remarkable families \u2013 are the force behind the force.\u201D - President Obama launching #joiningforces",
    "id" : 57845647688208384,
    "created_at" : "2011-04-12 16:40:51 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 57845995697999873,
  "created_at" : "2011-04-12 16:42:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57835797172338688",
  "text" : "RT @JoiningForces: Happening Now: Pres Obama, VP, First Lady & Dr. Biden launch #JoiningForces to support our military families. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 61, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57835616628506624",
    "text" : "Happening Now: Pres Obama, VP, First Lady & Dr. Biden launch #JoiningForces to support our military families. http:\/\/www.wh.gov\/live",
    "id" : 57835616628506624,
    "created_at" : "2011-04-12 16:01:00 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 57835797172338688,
  "created_at" : "2011-04-12 16:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57822776052023297",
  "text" : "April 12 marks Equal Pay Day. Why young Americans should care: http:\/\/wh.gov\/aVN",
  "id" : 57822776052023297,
  "created_at" : "2011-04-12 15:09:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57597842654642176",
  "text" : "Surprise! It's the President. See Obama surprise some students visiting the White House: http:\/\/wh.gov\/ayw",
  "id" : 57597842654642176,
  "created_at" : "2011-04-12 00:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 0, 10 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57536076314714112",
  "in_reply_to_user_id" : 9624742,
  "text" : "@StateDept launches humanrights.gov - a portal for intl human rights info generated by the US Govt. http:\/\/wh.gov\/ayr",
  "id" : 57536076314714112,
  "created_at" : "2011-04-11 20:10:44 +0000",
  "in_reply_to_screen_name" : "StateDept",
  "in_reply_to_user_id_str" : "9624742",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56858644951736321",
  "text" : "RT @pfeiffer44: Here are some more details on the bipartisan budget deal reached last night. http:\/\/1.usa.gov\/haICML",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56854487154954240",
    "text" : "Here are some more details on the bipartisan budget deal reached last night. http:\/\/1.usa.gov\/haICML",
    "id" : 56854487154954240,
    "created_at" : "2011-04-09 23:02:20 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 56858644951736321,
  "created_at" : "2011-04-09 23:18:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56724207878406144",
  "text" : "Watch your Weekly Address: President Obama on the importance of the bipartisan budget agreement http:\/\/goo.gl\/7mPIB",
  "id" : 56724207878406144,
  "created_at" : "2011-04-09 14:24:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 48, 59 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56552024904450049",
  "text" : "President Obama speaks from the Blue Room @ the @whitehouse momentarily. Watch live: http:\/\/wh.gov\/live",
  "id" : 56552024904450049,
  "created_at" : "2011-04-09 03:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56405018798080000",
  "text" : "Listening to American Businesses: @seclocke on conversations on creating jobs & increasing competitiveness: http:\/\/wh.gov\/aUF",
  "id" : 56405018798080000,
  "created_at" : "2011-04-08 17:16:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 41, 56 ],
      "id_str" : "7713202",
      "id" : 7713202
    }, {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 61, 73 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56389417358721024",
  "text" : "RT @pfeiffer44: The President spoke with @SpeakerBoehner and @SenatorReid this morning. Discussions aimed at reaching a budget agreement ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 25, 40 ],
        "id_str" : "7713202",
        "id" : 7713202
      }, {
        "name" : "Senator Harry Reid",
        "screen_name" : "SenatorReid",
        "indices" : [ 45, 57 ],
        "id_str" : "16789970",
        "id" : 16789970
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56381671796244480",
    "text" : "The President spoke with @SpeakerBoehner and @SenatorReid this morning. Discussions aimed at reaching a budget agreement are continuing.",
    "id" : 56381671796244480,
    "created_at" : "2011-04-08 15:43:32 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 56389417358721024,
  "created_at" : "2011-04-08 16:14:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56381387955113985",
  "text" : "West Wing Week: Obama continues budget talks hoping to avoid a govt shutdown & focuses clean energy. Video: http:\/\/wh.gov\/aR2",
  "id" : 56381387955113985,
  "created_at" : "2011-04-08 15:42:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 34, 45 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 59, 66 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56356399122362368",
  "text" : "Don't miss anything posted to the @whitehouse blog. Follow @blog44, an official & automatic feed of WhiteHouse.gov\/blog.",
  "id" : 56356399122362368,
  "created_at" : "2011-04-08 14:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56211005625212928",
  "text" : "Obama on budget talks: what\u2019s at stake, why it\u2019s important to the American people. Video & remarks: http:\/\/1.usa.gov\/gjGtQb",
  "id" : 56211005625212928,
  "created_at" : "2011-04-08 04:25:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56168054291312641",
  "text" : "The President delivers remarks on budget talks. Watch live: http:\/\/www.whitehouse.gov\/live",
  "id" : 56168054291312641,
  "created_at" : "2011-04-08 01:34:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56168054366797825",
  "text" : "The President delivers remarks on budget talks. Watch live: http:\/\/www.whitehouse.gov\/live",
  "id" : 56168054366797825,
  "created_at" : "2011-04-08 01:34:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56167849798012928",
  "text" : "POTUS makes brief statement now http:\/\/wh.gov\/live",
  "id" : 56167849798012928,
  "created_at" : "2011-04-08 01:33:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 58, 67 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56016662142525440",
  "text" : "What You Missed: Open for Questions on Energy Security w\/ @Interior Sec. Salazar. Video: http:\/\/wh.gov\/anu",
  "id" : 56016662142525440,
  "created_at" : "2011-04-07 15:33:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 46, 61 ],
      "id_str" : "7713202",
      "id" : 7713202
    }, {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 66, 78 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55995653234503681",
  "text" : "RT @pfeiffer44: POTUS and VPOTUS to meet with @SpeakerBoehner and @SenatorReid at 1 PM today to resume discussions on the budget",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 30, 45 ],
        "id_str" : "7713202",
        "id" : 7713202
      }, {
        "name" : "Senator Harry Reid",
        "screen_name" : "SenatorReid",
        "indices" : [ 50, 62 ],
        "id_str" : "16789970",
        "id" : 16789970
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55995245636231169",
    "text" : "POTUS and VPOTUS to meet with @SpeakerBoehner and @SenatorReid at 1 PM today to resume discussions on the budget",
    "id" : 55995245636231169,
    "created_at" : "2011-04-07 14:08:01 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 55995653234503681,
  "created_at" : "2011-04-07 14:09:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rail",
      "indices" : [ 38, 43 ]
    }, {
      "text" : "hsr",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55748138786504704",
  "text" : "RT @RayLaHood: Benefits of high-speed #rail? Too many for 140 characters--just ask the governors of 24 states! #hsr http:\/\/bit.ly\/dVW4Sj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rail",
        "indices" : [ 23, 28 ]
      }, {
        "text" : "hsr",
        "indices" : [ 96, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55655012914835457",
    "text" : "Benefits of high-speed #rail? Too many for 140 characters--just ask the governors of 24 states! #hsr http:\/\/bit.ly\/dVW4Sj",
    "id" : 55655012914835457,
    "created_at" : "2011-04-06 15:36:03 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 55748138786504704,
  "created_at" : "2011-04-06 21:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55644820215046145",
  "text" : "RT @macon44: Video walk-thru of the tax cut calculator by Austan Goolsbee http:\/\/youtu.be\/NXHa7v9o1K4 calc: http:\/\/goo.gl\/IHJ4E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55644455432241152",
    "text" : "Video walk-thru of the tax cut calculator by Austan Goolsbee http:\/\/youtu.be\/NXHa7v9o1K4 calc: http:\/\/goo.gl\/IHJ4E",
    "id" : 55644455432241152,
    "created_at" : "2011-04-06 14:54:06 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 55644820215046145,
  "created_at" : "2011-04-06 14:55:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 67, 76 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55408803725848577",
  "text" : "Not your average facebook invite: Join President Obama's Town Hall @facebook HQ. RSVP now: http:\/\/on.fb.me\/fplXJH",
  "id" : 55408803725848577,
  "created_at" : "2011-04-05 23:17:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55355454083182592",
  "text" : "Obama: GOP saying \"we'd rather have these cuts rather than that cut\u2026that's not the basis for shutting down the government\" http:\/\/wh.gov\/aNq",
  "id" : 55355454083182592,
  "created_at" : "2011-04-05 19:45:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55331746929049600",
  "text" : "The President on budget cuts: \"No reason why we should not get an agreement\u2026we have now matched the number the Speaker originally sought\"",
  "id" : 55331746929049600,
  "created_at" : "2011-04-05 18:11:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55329408260653056",
  "text" : "President Obama at the briefing room podium now http:\/\/wh.gov\/live",
  "id" : 55329408260653056,
  "created_at" : "2011-04-05 18:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55322775354740738",
  "text" : "1:45: WH Daily Briefing, taking Qs on budget negotiations & more, watch live: http:\/\/is.gd\/qHl6ih",
  "id" : 55322775354740738,
  "created_at" : "2011-04-05 17:35:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ExportGov",
      "screen_name" : "ExportGov",
      "indices" : [ 3, 13 ],
      "id_str" : "19109172",
      "id" : 19109172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewableEnergy",
      "indices" : [ 51, 67 ]
    }, {
      "text" : "EnergyEfficiency",
      "indices" : [ 72, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55302151882289152",
  "text" : "RT @ExportGov: Download the flagship report of the #RenewableEnergy and #EnergyEfficiency export initiative launched last December: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RenewableEnergy",
        "indices" : [ 36, 52 ]
      }, {
        "text" : "EnergyEfficiency",
        "indices" : [ 57, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54862063805284352",
    "text" : "Download the flagship report of the #RenewableEnergy and #EnergyEfficiency export initiative launched last December: http:\/\/go.usa.gov\/2ba",
    "id" : 54862063805284352,
    "created_at" : "2011-04-04 11:05:09 +0000",
    "user" : {
      "name" : "ExportGov",
      "screen_name" : "ExportGov",
      "protected" : false,
      "id_str" : "19109172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648867658721554432\/vg-Sr54v_normal.jpg",
      "id" : 19109172,
      "verified" : false
    }
  },
  "id" : 55302151882289152,
  "created_at" : "2011-04-05 16:13:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55294922747678720",
  "text" : "Obama on Cote d'Ivoire \"To end this violence & prevent more bloodshed former President Gbagbo must stand down immediately\" http:\/\/wh.gov\/a5D",
  "id" : 55294922747678720,
  "created_at" : "2011-04-05 15:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55288295864803328",
  "text" : "New tax cut calculator: how the December tax deal will benefit you in your taxes for 2011 and in paychecks right now http:\/\/wh.gov\/a5O",
  "id" : 55288295864803328,
  "created_at" : "2011-04-05 15:18:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55023812273643520",
  "text" : "RT @usedgov: ED Blog: Strengthening Our Response to Sexual Assault in Schools and on College Campuses: \u201CWhen it comes to s... http:\/\/1.u ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54991864624971777",
    "text" : "ED Blog: Strengthening Our Response to Sexual Assault in Schools and on College Campuses: \u201CWhen it comes to s... http:\/\/1.usa.gov\/hVUSoL",
    "id" : 54991864624971777,
    "created_at" : "2011-04-04 19:40:56 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 55023812273643520,
  "created_at" : "2011-04-04 21:47:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CathyKirk",
      "screen_name" : "StormingGrace",
      "indices" : [ 0, 14 ],
      "id_str" : "267333837",
      "id" : 267333837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53512397473841152",
  "geo" : { },
  "id_str" : "53971760982405120",
  "in_reply_to_user_id" : 267333837,
  "text" : "@StormingGrace The WH Council on Environmental Quality responds to your Q. Going Green & Saving Green: http:\/\/wh.gov\/a9p",
  "id" : 53971760982405120,
  "in_reply_to_status_id" : 53512397473841152,
  "created_at" : "2011-04-02 00:07:25 +0000",
  "in_reply_to_screen_name" : "StormingGrace",
  "in_reply_to_user_id_str" : "267333837",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53914722659082242",
  "text" : "Photo of the Day: Obama points to OMB Director Jack Lew during Senior Advisors meeting  http:\/\/twitpic.com\/4fslxh",
  "id" : 53914722659082242,
  "created_at" : "2011-04-01 20:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53878164312686592",
  "text" : "RT @ENERGY: We\u2019ll be joined by a Clean Fleets expert starting at 2:30 EST. Send us your questions about reducing oil consumption and cle ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53877376903426048",
    "text" : "We\u2019ll be joined by a Clean Fleets expert starting at 2:30 EST. Send us your questions about reducing oil consumption and clean vehicle tech!",
    "id" : 53877376903426048,
    "created_at" : "2011-04-01 17:52:22 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 53878164312686592,
  "created_at" : "2011-04-01 17:55:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53845673631690753",
  "text" : "RT @whitehouseostp: Science Fair+Secret Service=Surprise Visitor...a 17-year-old's view of the President's NYC Sci Fair visit http:\/\/go. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "53841693371412480",
    "text" : "Science Fair+Secret Service=Surprise Visitor...a 17-year-old's view of the President's NYC Sci Fair visit http:\/\/go.ostp.gov\/gLdApx",
    "id" : 53841693371412480,
    "created_at" : "2011-04-01 15:30:34 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 53845673631690753,
  "created_at" : "2011-04-01 15:46:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53837460987326464",
  "text" : "Fresh West Wing Week: Libya, energy, education & a Big Blue Whale http:\/\/wh.gov\/a0r",
  "id" : 53837460987326464,
  "created_at" : "2011-04-01 15:13:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 23, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "53817996208123904",
  "text" : "Goolsbee on March jobs #s: private payrolls +230K; full % point drop in unemp.rate over past 4 months = largest since 1984 http:\/\/wh.gov\/a0E",
  "id" : 53817996208123904,
  "created_at" : "2011-04-01 13:56:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]