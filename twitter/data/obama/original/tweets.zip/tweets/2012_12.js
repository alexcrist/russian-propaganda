Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285828772391952384",
  "text" : "\"Our most immediate priority is to stop taxes from going up on middle-class families\" \u2014President Obama urges Congress to act today",
  "id" : 285828772391952384,
  "created_at" : "2012-12-31 19:24:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fiscalcliff",
      "indices" : [ 45, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/dfEWfXpi",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "285817108535861249",
  "text" : "Happening now: President Obama speaks on the #fiscalcliff at an event with middle-class Americans. Watch: http:\/\/t.co\/dfEWfXpi",
  "id" : 285817108535861249,
  "created_at" : "2012-12-31 18:38:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/285200554324529155\/photo\/1",
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/vvZVyENE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_U8ZKLCEAAC9o0.jpg",
      "id_str" : "285200554332917760",
      "id" : 285200554332917760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_U8ZKLCEAAC9o0.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vvZVyENE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285200554324529155",
  "text" : "Photo of the Day: President Obama talks on the phone in the Oval Office: http:\/\/t.co\/vvZVyENE",
  "id" : 285200554324529155,
  "created_at" : "2012-12-30 01:48:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 56, 64 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/yrixHs7i",
      "expanded_url" : "http:\/\/at.wh.gov\/gqf0w",
      "display_url" : "at.wh.gov\/gqf0w"
    } ]
  },
  "geo" : { },
  "id_str" : "285168367101427712",
  "text" : "In 2012, the @WhiteHouse surpassed 100,000,000 views on @YouTube. Check out our 10 most watched videos: http:\/\/t.co\/yrixHs7i",
  "id" : 285168367101427712,
  "created_at" : "2012-12-29 23:40:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/7RFmToKu",
      "expanded_url" : "http:\/\/at.wh.gov\/gqdC0",
      "display_url" : "at.wh.gov\/gqdC0"
    } ]
  },
  "geo" : { },
  "id_str" : "285135648724230144",
  "text" : "\"We cannot let Washington politics get in the way of America\u2019s progress.\" -President Obama: http:\/\/t.co\/7RFmToKu",
  "id" : 285135648724230144,
  "created_at" : "2012-12-29 21:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285126322425036800",
  "text" : "RT @JonCarson44: Unless Congress acts now, every American\u2019s tax rates will go up in couple of days. We must protect the middle class: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/BQp8gUco",
        "expanded_url" : "http:\/\/youtu.be\/V5_vUE9FlXk",
        "display_url" : "youtu.be\/V5_vUE9FlXk"
      } ]
    },
    "geo" : { },
    "id_str" : "285125560156438528",
    "text" : "Unless Congress acts now, every American\u2019s tax rates will go up in couple of days. We must protect the middle class: http:\/\/t.co\/BQp8gUco",
    "id" : 285125560156438528,
    "created_at" : "2012-12-29 20:50:05 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 285126322425036800,
  "created_at" : "2012-12-29 20:53:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/Sy2h9hiU",
      "expanded_url" : "http:\/\/at.wh.gov\/gqdxQ",
      "display_url" : "at.wh.gov\/gqdxQ"
    } ]
  },
  "geo" : { },
  "id_str" : "285039361647587328",
  "text" : "In this week\u2019s address, President Obama urges Congress to protect the middle class from an income tax hike. Watch: http:\/\/t.co\/Sy2h9hiU",
  "id" : 285039361647587328,
  "created_at" : "2012-12-29 15:07:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/WVfwFCpr",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=QIHLygiVxrw",
      "display_url" : "youtube.com\/watch?v=QIHLyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "284810273083244544",
  "text" : "Today President Obama spoke from the WH briefing room about the need to avoid tax hikes on the middle class. Watch: http:\/\/t.co\/WVfwFCpr",
  "id" : 284810273083244544,
  "created_at" : "2012-12-28 23:57:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/vrg5Id91",
      "expanded_url" : "http:\/\/at.wh.gov\/giD7U",
      "display_url" : "at.wh.gov\/giD7U"
    } ]
  },
  "geo" : { },
  "id_str" : "284793657536700416",
  "text" : "Happening now: President Obama speaks from the briefing room. Watch live: http:\/\/t.co\/vrg5Id91",
  "id" : 284793657536700416,
  "created_at" : "2012-12-28 22:51:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/vrg5Id91",
      "expanded_url" : "http:\/\/at.wh.gov\/giD7U",
      "display_url" : "at.wh.gov\/giD7U"
    } ]
  },
  "geo" : { },
  "id_str" : "284788467752374273",
  "text" : "Watch live at 5:45pm ET: President Obama delivers a statement from the briefing room. Watch: http:\/\/t.co\/vrg5Id91",
  "id" : 284788467752374273,
  "created_at" : "2012-12-28 22:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/284780805727866881\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/mA17lw4z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_O-okzCUAEQkQ1.jpg",
      "id_str" : "284780805736255489",
      "id" : 284780805736255489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_O-okzCUAEQkQ1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1351,
        "resize" : "fit",
        "w" : 2027
      } ],
      "display_url" : "pic.twitter.com\/mA17lw4z"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/riCes9wx",
      "expanded_url" : "http:\/\/on.wh.gov\/pxDc21X",
      "display_url" : "on.wh.gov\/pxDc21X"
    } ]
  },
  "geo" : { },
  "id_str" : "284780805727866881",
  "text" : "\"We want to say thank you.\" -President Obama at the Marine Corps Base in Hawaii on Christmas Day: http:\/\/t.co\/riCes9wx http:\/\/t.co\/mA17lw4z",
  "id" : 284780805727866881,
  "created_at" : "2012-12-28 22:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/WOE14RRa",
      "expanded_url" : "http:\/\/at.wh.gov\/gptKN",
      "display_url" : "at.wh.gov\/gptKN"
    } ]
  },
  "geo" : { },
  "id_str" : "284740343772110848",
  "text" : "2012 in Review: Watch some highlights from the archive in the latest West Wing Week: http:\/\/t.co\/WOE14RRa",
  "id" : 284740343772110848,
  "created_at" : "2012-12-28 19:19:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiscalCliff",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284456204154064896",
  "text" : "RT @pfeiffer44: President Obama will meet with Congressional Leaders at the White House tomorrow afternoon re #FiscalCliff",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FiscalCliff",
        "indices" : [ 94, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284449243589144578",
    "text" : "President Obama will meet with Congressional Leaders at the White House tomorrow afternoon re #FiscalCliff",
    "id" : 284449243589144578,
    "created_at" : "2012-12-28 00:02:39 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 284456204154064896,
  "created_at" : "2012-12-28 00:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 67, 70 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 88, 96 ],
      "id_str" : "21870081",
      "id" : 21870081
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 104, 115 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/gCLT99eY",
      "expanded_url" : "http:\/\/at.wh.gov\/goqmu",
      "display_url" : "at.wh.gov\/goqmu"
    } ]
  },
  "geo" : { },
  "id_str" : "284453746539393026",
  "text" : "2012 Year in Review: In September, the President, First Lady &amp; @VP Biden celebrated @TeamUSA at the @WhiteHouse: http:\/\/t.co\/gCLT99eY",
  "id" : 284453746539393026,
  "created_at" : "2012-12-28 00:20:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Brian Schatz",
      "screen_name" : "brianschatz",
      "indices" : [ 61, 73 ],
      "id_str" : "47747074",
      "id" : 47747074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284378164317278208",
  "text" : "RT @VP: Today at 2:30 ET, Vice President Biden will swear in @BrianSchatz as Senator of Hawaii at the U.S. Capitol.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Schatz",
        "screen_name" : "brianschatz",
        "indices" : [ 53, 65 ],
        "id_str" : "47747074",
        "id" : 47747074
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284377876197957633",
    "text" : "Today at 2:30 ET, Vice President Biden will swear in @BrianSchatz as Senator of Hawaii at the U.S. Capitol.",
    "id" : 284377876197957633,
    "created_at" : "2012-12-27 19:19:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 284378164317278208,
  "created_at" : "2012-12-27 19:20:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/aMbyREOt",
      "expanded_url" : "http:\/\/at.wh.gov\/gn53A",
      "display_url" : "at.wh.gov\/gn53A"
    } ]
  },
  "geo" : { },
  "id_str" : "284147874902716416",
  "text" : "Go behind the scenes at the W.H. with Kennedy Center Honorees, incl Led Zeppelin, Dustin Hoffman &amp; David Letterman: http:\/\/t.co\/aMbyREOt",
  "id" : 284147874902716416,
  "created_at" : "2012-12-27 04:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/gK4fALEu",
      "expanded_url" : "http:\/\/at.wh.gov\/gn5q7",
      "display_url" : "at.wh.gov\/gn5q7"
    } ]
  },
  "geo" : { },
  "id_str" : "284127734765076480",
  "text" : "\"Warm thoughts and best wishes to all those celebrating Kwanzaa this holiday season.\"\u2014President Obama: http:\/\/t.co\/gK4fALEu",
  "id" : 284127734765076480,
  "created_at" : "2012-12-27 02:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Kennedy Center",
      "screen_name" : "kencen",
      "indices" : [ 91, 98 ],
      "id_str" : "19936078",
      "id" : 19936078
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/284109888127373312\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/MNyshBmY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_FccB-CEAEPyDw.jpg",
      "id_str" : "284109888135761921",
      "id" : 284109888135761921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_FccB-CEAEPyDw.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/MNyshBmY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284109888127373312",
  "text" : "The Kennedy Center Honors airs tonight @ 9ET. Photo: The President &amp; First Lady attend @KenCen Honors in DC on Dec. 2: http:\/\/t.co\/MNyshBmY",
  "id" : 284109888127373312,
  "created_at" : "2012-12-27 01:34:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/283754047582920705\/photo\/1",
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/1aIoPrbj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_AYzYpCYAAFqDn.jpg",
      "id_str" : "283754047591309312",
      "id" : 283754047591309312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_AYzYpCYAAFqDn.jpg",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1795,
        "resize" : "fit",
        "w" : 2400
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1aIoPrbj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/Gg7UE5D2",
      "expanded_url" : "http:\/\/on.wh.gov\/D5Fb7h5",
      "display_url" : "on.wh.gov\/D5Fb7h5"
    } ]
  },
  "geo" : { },
  "id_str" : "283754047582920705",
  "text" : "The President and First Lady wish you a Merry Christmas and Happy Holidays: http:\/\/t.co\/Gg7UE5D2, http:\/\/t.co\/1aIoPrbj",
  "id" : 283754047582920705,
  "created_at" : "2012-12-26 02:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/283708745979158528\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/ni0zKLUG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-_vmfTCYAIngtx.jpg",
      "id_str" : "283708746063044610",
      "id" : 283708746063044610,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-_vmfTCYAIngtx.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ni0zKLUG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283708745979158528",
  "text" : "Photo: The First Lady, with Bo on her lap, reads \"'Twas the Night Before Christmas\" at Children's National in DC: http:\/\/t.co\/ni0zKLUG",
  "id" : 283708745979158528,
  "created_at" : "2012-12-25 23:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/283653575677198336\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/9ynZ7mdb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A--9bJoCQAAJ2eL.jpg",
      "id_str" : "283653575685586944",
      "id" : 283653575685586944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A--9bJoCQAAJ2eL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/9ynZ7mdb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283653575677198336",
  "text" : "\"Michelle and I want to wish you a Merry Christmas and a Happy Holidays.\" \u2014President Obama http:\/\/t.co\/9ynZ7mdb",
  "id" : 283653575677198336,
  "created_at" : "2012-12-25 19:20:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NORAD Santa",
      "screen_name" : "NoradSanta",
      "indices" : [ 86, 97 ],
      "id_str" : "16460682",
      "id" : 16460682
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/283408003154186240\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/ThKJgcFK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-7eE8sCEAE-w4U.jpg",
      "id_str" : "283408003162574849",
      "id" : 283408003162574849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-7eE8sCEAE-w4U.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ThKJgcFK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283408003154186240",
  "text" : "Today, First Lady Michelle Obama talked to kids all across the country as part of the @NORADSanta program: http:\/\/t.co\/ThKJgcFK",
  "id" : 283408003154186240,
  "created_at" : "2012-12-25 03:05:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 26, 33 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/9f52GSNI",
      "expanded_url" : "http:\/\/at.wh.gov\/gl9h1",
      "display_url" : "at.wh.gov\/gl9h1"
    } ]
  },
  "geo" : { },
  "id_str" : "283376547082170368",
  "text" : "Where is Santa Claus now? @Energy's Los Alamos National Lab tracks his progress around the globe on Christmas Eve: http:\/\/t.co\/9f52GSNI",
  "id" : 283376547082170368,
  "created_at" : "2012-12-25 01:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/bo9BSzev",
      "expanded_url" : "http:\/\/at.wh.gov\/glbAW",
      "display_url" : "at.wh.gov\/glbAW"
    } ]
  },
  "geo" : { },
  "id_str" : "283347594745348096",
  "text" : "\"Joy to All\": A behind-the-scenes look at the White House during the holidays: http:\/\/t.co\/bo9BSzev",
  "id" : 283347594745348096,
  "created_at" : "2012-12-24 23:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/bsboIyee",
      "expanded_url" : "http:\/\/at.wh.gov\/gl8tg",
      "display_url" : "at.wh.gov\/gl8tg"
    } ]
  },
  "geo" : { },
  "id_str" : "283293970199613440",
  "text" : "'Twas the night before Christmas: The First Lady, with Bo, reads to kids at the Children's National Medical Center: http:\/\/t.co\/bsboIyee",
  "id" : 283293970199613440,
  "created_at" : "2012-12-24 19:32:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/283023702256414720\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/3r9vvsVm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-2AjsSCcAA4te1.jpg",
      "id_str" : "283023702264803328",
      "id" : 283023702264803328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-2AjsSCcAA4te1.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3r9vvsVm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/0ZLesnxu",
      "expanded_url" : "http:\/\/on.wh.gov\/krboe0n",
      "display_url" : "on.wh.gov\/krboe0n"
    } ]
  },
  "geo" : { },
  "id_str" : "283023702256414720",
  "text" : "Photo: President Obama and the First Lady tape a holiday address in the Roosevelt Room: http:\/\/t.co\/0ZLesnxu http:\/\/t.co\/3r9vvsVm",
  "id" : 283023702256414720,
  "created_at" : "2012-12-24 01:38:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/IAML6hYp",
      "expanded_url" : "http:\/\/at.wh.gov\/gjn92",
      "display_url" : "at.wh.gov\/gjn92"
    } ]
  },
  "geo" : { },
  "id_str" : "282984081367638017",
  "text" : "A holiday greeting from the President &amp; First Lady: \"This week let\u2019s give thanks for our veterans and their families\" http:\/\/t.co\/IAML6hYp",
  "id" : 282984081367638017,
  "created_at" : "2012-12-23 23:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/AKJDNp9v",
      "expanded_url" : "http:\/\/at.wh.gov\/gk9UE",
      "display_url" : "at.wh.gov\/gk9UE"
    } ]
  },
  "geo" : { },
  "id_str" : "282946235093102592",
  "text" : "Watch a time-lapse video: Creating the 2012 Gingerbread White House: http:\/\/t.co\/AKJDNp9v",
  "id" : 282946235093102592,
  "created_at" : "2012-12-23 20:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/QBcTRpYX",
      "expanded_url" : "http:\/\/at.wh.gov\/gjn3d",
      "display_url" : "at.wh.gov\/gjn3d"
    } ]
  },
  "geo" : { },
  "id_str" : "282885895860932608",
  "text" : "\"Michelle and I want to wish you a Merry Christmas &amp; a Happy Holidays\" -President Obama: http:\/\/t.co\/QBcTRpYX",
  "id" : 282885895860932608,
  "created_at" : "2012-12-23 16:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/1tl2ZSex",
      "expanded_url" : "http:\/\/at.wh.gov\/gjn1G",
      "display_url" : "at.wh.gov\/gjn1G"
    } ]
  },
  "geo" : { },
  "id_str" : "282606554774110209",
  "text" : "\"That\u2019s what makes this season so special, getting to spend time with the people we love most.\" -The First Lady: http:\/\/t.co\/1tl2ZSex",
  "id" : 282606554774110209,
  "created_at" : "2012-12-22 22:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/SbroeSRR",
      "expanded_url" : "http:\/\/at.wh.gov\/gjmOT",
      "display_url" : "at.wh.gov\/gjmOT"
    } ]
  },
  "geo" : { },
  "id_str" : "282524058195734529",
  "text" : "In this week's address, the President &amp; First Lady extend a holiday greeting &amp; thank our troops for their service: http:\/\/t.co\/SbroeSRR",
  "id" : 282524058195734529,
  "created_at" : "2012-12-22 16:32:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 18, 21 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/282327876714520576\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/OphYKI2Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-sHtUICYAIoUA4.jpg",
      "id_str" : "282327876718714882",
      "id" : 282327876718714882,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-sHtUICYAIoUA4.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/OphYKI2Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282327876714520576",
  "text" : "Photo of the Day: @VP Biden meets with stakeholders, staff &amp; Cabinet on policy proposals following the Newton tragedy http:\/\/t.co\/OphYKI2Q",
  "id" : 282327876714520576,
  "created_at" : "2012-12-22 03:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/282296944720760832\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/tHBLobr9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-rrk1fCUAABlpc.jpg",
      "id_str" : "282296944729149440",
      "id" : 282296944729149440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-rrk1fCUAABlpc.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tHBLobr9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/b2ed7cYy",
      "expanded_url" : "http:\/\/on.wh.gov\/Hq3j4JC",
      "display_url" : "on.wh.gov\/Hq3j4JC"
    } ]
  },
  "geo" : { },
  "id_str" : "282296944720760832",
  "text" : "\"We remember a man who inspired all of us with his courage\" -President Obama on Senator Inouye: http:\/\/t.co\/b2ed7cYy http:\/\/t.co\/tHBLobr9",
  "id" : 282296944720760832,
  "created_at" : "2012-12-22 01:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiscalCliff",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/up9zgyWH",
      "expanded_url" : "http:\/\/at.wh.gov\/giOyx",
      "display_url" : "at.wh.gov\/giOyx"
    } ]
  },
  "geo" : { },
  "id_str" : "282279046354702336",
  "text" : "\"We move forward together, or we don't move forward at all\"-President Obama today on the #FiscalCliff. Watch: http:\/\/t.co\/up9zgyWH",
  "id" : 282279046354702336,
  "created_at" : "2012-12-22 00:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/Ll53G2wM",
      "expanded_url" : "http:\/\/at.wh.gov\/giISl",
      "display_url" : "at.wh.gov\/giISl"
    } ]
  },
  "geo" : { },
  "id_str" : "282252976201035776",
  "text" : "Happening now: President Obama delivers a statement on the fiscal cliff from the Press Briefing Room. Watch live: http:\/\/t.co\/Ll53G2wM",
  "id" : 282252976201035776,
  "created_at" : "2012-12-21 22:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/vrg5Id91",
      "expanded_url" : "http:\/\/at.wh.gov\/giD7U",
      "display_url" : "at.wh.gov\/giD7U"
    } ]
  },
  "geo" : { },
  "id_str" : "282235160391471104",
  "text" : "At 5:00 p.m. ET, President Obama will deliver a statement on the fiscal cliff from the Press Briefing Room. Watch: http:\/\/t.co\/vrg5Id91",
  "id" : 282235160391471104,
  "created_at" : "2012-12-21 21:24:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/282229113438212096\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/I1yx6j51",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-qt4iRCEAE56GV.jpg",
      "id_str" : "282229113446600705",
      "id" : 282229113446600705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-qt4iRCEAE56GV.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/I1yx6j51"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/Vb3LjNNS",
      "expanded_url" : "http:\/\/on.wh.gov\/IIjWWxH",
      "display_url" : "on.wh.gov\/IIjWWxH"
    } ]
  },
  "geo" : { },
  "id_str" : "282229113438212096",
  "text" : "An open letter to parents from First Lady Michelle Obama: \"Talking to Our Kids about Newtown\" http:\/\/t.co\/Vb3LjNNS http:\/\/t.co\/I1yx6j51",
  "id" : 282229113438212096,
  "created_at" : "2012-12-21 21:00:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282208450124054528",
  "text" : "RT @VP: After #Newtown, people are calling for action to reduce gun violence. The President &amp; VP are listening &amp; taking action:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Newtown",
        "indices" : [ 6, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 128, 148 ],
        "url" : "http:\/\/t.co\/ghWHlxmj",
        "expanded_url" : "http:\/\/at.wh.gov\/gifk2",
        "display_url" : "at.wh.gov\/gifk2"
      } ]
    },
    "geo" : { },
    "id_str" : "282198113291231233",
    "text" : "After #Newtown, people are calling for action to reduce gun violence. The President &amp; VP are listening &amp; taking action: http:\/\/t.co\/ghWHlxmj",
    "id" : 282198113291231233,
    "created_at" : "2012-12-21 18:57:27 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 282208450124054528,
  "created_at" : "2012-12-21 19:38:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282192460514484224",
  "text" : "RT @WHLive: At 1:30 p.m. ET, President Obama will make a personnel announcement in the Roosevelt Room of the White House. Watch: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/fV7TVC6N",
        "expanded_url" : "http:\/\/at.wh.gov\/gii9F",
        "display_url" : "at.wh.gov\/gii9F"
      } ]
    },
    "geo" : { },
    "id_str" : "282183551980544000",
    "text" : "At 1:30 p.m. ET, President Obama will make a personnel announcement in the Roosevelt Room of the White House. Watch: http:\/\/t.co\/fV7TVC6N",
    "id" : 282183551980544000,
    "created_at" : "2012-12-21 17:59:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 282192460514484224,
  "created_at" : "2012-12-21 18:35:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 39, 51 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/cmtj69Sb",
      "expanded_url" : "http:\/\/at.wh.gov\/gilBu",
      "display_url" : "at.wh.gov\/gilBu"
    } ]
  },
  "geo" : { },
  "id_str" : "282191072023699456",
  "text" : "Hundreds of thousands of people signed @wethepeople petitions on reducing gun violence. President Obama responds: http:\/\/t.co\/cmtj69Sb",
  "id" : 282191072023699456,
  "created_at" : "2012-12-21 18:29:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/282163238261633024\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/WFP78mG3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-px-GGCMAACbnr.jpg",
      "id_str" : "282163238265827328",
      "id" : 282163238265827328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-px-GGCMAACbnr.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WFP78mG3"
    } ],
    "hashtags" : [ {
      "text" : "MomentForSandyHook",
      "indices" : [ 45, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282163238261633024",
  "text" : "Photo: President Obama &amp; staff observe a #MomentForSandyHook in the Oval Office today at 9:30 a.m. ET: http:\/\/t.co\/WFP78mG3",
  "id" : 282163238261633024,
  "created_at" : "2012-12-21 16:38:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MomentForSandyHook",
      "indices" : [ 127, 146 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282127519157719041",
  "text" : "20 beautiful children &amp; 6 remarkable adults. Together, we will carry on &amp; make our country worthy of their memory. -bo #MomentForSandyHook",
  "id" : 282127519157719041,
  "created_at" : "2012-12-21 14:16:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MomentforSandyHook",
      "indices" : [ 59, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282121970026434560",
  "text" : "Join us today at 9:30 a.m ET as the White House observes a #MomentforSandyHook victims.",
  "id" : 282121970026434560,
  "created_at" : "2012-12-21 13:54:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 84, 96 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282101755788001281",
  "text" : "RT @JonCarson44: \"We hear you\u2026Here's what I think we should do\" -President Obama on @WeThePeople petitions about reducing gun violence:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 67, 79 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/UrZPfHLI",
        "expanded_url" : "http:\/\/wh.gov\/nG6Z",
        "display_url" : "wh.gov\/nG6Z"
      } ]
    },
    "geo" : { },
    "id_str" : "282100085666492416",
    "text" : "\"We hear you\u2026Here's what I think we should do\" -President Obama on @WeThePeople petitions about reducing gun violence: http:\/\/t.co\/UrZPfHLI",
    "id" : 282100085666492416,
    "created_at" : "2012-12-21 12:27:56 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 282101755788001281,
  "created_at" : "2012-12-21 12:34:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281952641922260993",
  "text" : "RT @PressSec: The President\u2019s priority is to ensure taxes don\u2019t go up on 98% of Americans; will work w\/ Congress to get it done http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/HYmStdWS",
        "expanded_url" : "http:\/\/wh.gov\/nAln",
        "display_url" : "wh.gov\/nAln"
      } ]
    },
    "geo" : { },
    "id_str" : "281952146595917824",
    "text" : "The President\u2019s priority is to ensure taxes don\u2019t go up on 98% of Americans; will work w\/ Congress to get it done http:\/\/t.co\/HYmStdWS #My2k",
    "id" : 281952146595917824,
    "created_at" : "2012-12-21 02:40:04 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 281952641922260993,
  "created_at" : "2012-12-21 02:42:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281928578839482368",
  "text" : "RT @pfeiffer44: Obama won the debate: A year ago the GOP wouldn't close a loophole for corprate jets, today they break arms to raise tax ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281925477394960385",
    "text" : "Obama won the debate: A year ago the GOP wouldn't close a loophole for corprate jets, today they break arms to raise taxes on millionaires.",
    "id" : 281925477394960385,
    "created_at" : "2012-12-21 00:54:06 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 281928578839482368,
  "created_at" : "2012-12-21 01:06:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/281818789828505600\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/9YtKXwU7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-k4sjuCMAEFztZ.jpg",
      "id_str" : "281818789841088513",
      "id" : 281818789841088513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-k4sjuCMAEFztZ.jpg",
      "sizes" : [ {
        "h" : 658,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/9YtKXwU7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281885251377180672",
  "text" : "The facts about Republicans' \"Plan B\": 25 million working middle-class families would pay $1,000 more in taxes: http:\/\/t.co\/9YtKXwU7",
  "id" : 281885251377180672,
  "created_at" : "2012-12-20 22:14:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281863381403713536",
  "text" : "RT @VP: Today, VP Biden convened the first of many meetings w\/ stakeholders, staff &amp; Cabinet to develop policy proposals following N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281854432243757056",
    "text" : "Today, VP Biden convened the first of many meetings w\/ stakeholders, staff &amp; Cabinet to develop policy proposals following Newtown tragedy.",
    "id" : 281854432243757056,
    "created_at" : "2012-12-20 20:11:47 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 281863381403713536,
  "created_at" : "2012-12-20 20:47:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/281818789828505600\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/9YtKXwU7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-k4sjuCMAEFztZ.jpg",
      "id_str" : "281818789841088513",
      "id" : 281818789841088513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-k4sjuCMAEFztZ.jpg",
      "sizes" : [ {
        "h" : 658,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/9YtKXwU7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281818789828505600",
  "text" : "The facts about Republicans' \"Plan B\": The wealthy get tax cuts, while the middle class foots the bill: http:\/\/t.co\/9YtKXwU7",
  "id" : 281818789828505600,
  "created_at" : "2012-12-20 17:50:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281610115449241600",
  "text" : "\"If there is even one thing that we can do to prevent any of these events, we have a deep obligation\u2014all of us\u2014to try.\" \u2014President Obama",
  "id" : 281610115449241600,
  "created_at" : "2012-12-20 04:00:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/GrE8F2We",
      "expanded_url" : "http:\/\/at.wh.gov\/gf5bm",
      "display_url" : "at.wh.gov\/gf5bm"
    } ]
  },
  "geo" : { },
  "id_str" : "281572340930850816",
  "text" : "\"The fact that this problem is complex can no longer be an excuse for doing nothing.\" \u2014President Obama: http:\/\/t.co\/GrE8F2We",
  "id" : 281572340930850816,
  "created_at" : "2012-12-20 01:30:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/UYyDM7QE",
      "expanded_url" : "http:\/\/wh.gov\/nkxC",
      "display_url" : "wh.gov\/nkxC"
    } ]
  },
  "geo" : { },
  "id_str" : "281558406853165057",
  "text" : "RT @pfeiffer44: Infographic: Republican's Plan B cuts taxes for the wealthy, while the middle class foots the bill http:\/\/t.co\/UYyDM7QE  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pfeiffer44\/status\/281558246987292672\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/gd1IA9QH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A-hLu9_CYAAnXH8.jpg",
        "id_str" : "281558246995681280",
        "id" : 281558246995681280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-hLu9_CYAAnXH8.jpg",
        "sizes" : [ {
          "h" : 728,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 728,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 728,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/gd1IA9QH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/UYyDM7QE",
        "expanded_url" : "http:\/\/wh.gov\/nkxC",
        "display_url" : "wh.gov\/nkxC"
      } ]
    },
    "geo" : { },
    "id_str" : "281558246987292672",
    "text" : "Infographic: Republican's Plan B cuts taxes for the wealthy, while the middle class foots the bill http:\/\/t.co\/UYyDM7QE http:\/\/t.co\/gd1IA9QH",
    "id" : 281558246987292672,
    "created_at" : "2012-12-20 00:34:52 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 281558406853165057,
  "created_at" : "2012-12-20 00:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/281535657145425921\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/RUV4MCMx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-g3MERCYAA3IzF.jpg",
      "id_str" : "281535657153814528",
      "id" : 281535657153814528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-g3MERCYAA3IzF.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/RUV4MCMx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281535657145425921",
  "text" : "\"If we're going to change things, it's going to take a wave of Americans.\"-President Obama on preventing gun violence: http:\/\/t.co\/RUV4MCMx",
  "id" : 281535657145425921,
  "created_at" : "2012-12-19 23:05:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/eZF6gvSx",
      "expanded_url" : "http:\/\/at.wh.gov\/geDcD",
      "display_url" : "at.wh.gov\/geDcD"
    } ]
  },
  "geo" : { },
  "id_str" : "281476879515525120",
  "text" : "Full video: President Obama speaks on Administration steps to prevent gun violence. Watch: http:\/\/t.co\/eZF6gvSx",
  "id" : 281476879515525120,
  "created_at" : "2012-12-19 19:11:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281446317434236928",
  "text" : "\"It will take commitment, and compromise, and most of all, courage.\" \u2014President Obama",
  "id" : 281446317434236928,
  "created_at" : "2012-12-19 17:10:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281446081219407872",
  "text" : "\"If this effort is to succeed, it\u2019s going to require the help of the American people. It\u2019s going to require you.\" \u2014President Obama",
  "id" : 281446081219407872,
  "created_at" : "2012-12-19 17:09:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281445810510643201",
  "text" : "\u201CI will use all the powers of this office to help advance efforts aimed at preventing more tragedies like this.\u201D \u2014President Obama",
  "id" : 281445810510643201,
  "created_at" : "2012-12-19 17:08:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281444846701535233",
  "text" : "\u201CThe fact that we can\u2019t prevent every act of violence doesn\u2019t mean we can\u2019t steadily reduce the violence\u201D \u2014President Obama",
  "id" : 281444846701535233,
  "created_at" : "2012-12-19 17:04:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281444604480483328",
  "text" : "RT @WHLive: President Obama: \"We need to work on making access to mental health care at least as easy as access to a gun.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281444552567566337",
    "text" : "President Obama: \"We need to work on making access to mental health care at least as easy as access to a gun.\"",
    "id" : 281444552567566337,
    "created_at" : "2012-12-19 17:03:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 281444604480483328,
  "created_at" : "2012-12-19 17:03:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281444370371207169",
  "text" : "\u201CIf there is even one thing we can do to prevent any of these events, we have a deep obligation \u2013 all of us \u2013 to try.\u201D \u2014President Obama",
  "id" : 281444370371207169,
  "created_at" : "2012-12-19 17:02:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "281444170621677568",
  "text" : "Happening Now: The President speaks on policy process the Administration will pursue in wake of #Newtown tragedy. Watch http:\/\/t.co\/u95tzH8r",
  "id" : 281444170621677568,
  "created_at" : "2012-12-19 17:01:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "281409972955394048",
  "text" : "At 11:45ET, the President speaks on the policy process the Admin will pursue in the wake of the Newtown tragedy. Watch: http:\/\/t.co\/u95tzH8r",
  "id" : 281409972955394048,
  "created_at" : "2012-12-19 14:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/281241448681197568\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Cg6LR8aS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-crm4WCUAEu3gX.jpg",
      "id_str" : "281241448693780481",
      "id" : 281241448693780481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-crm4WCUAEu3gX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Cg6LR8aS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281241448681197568",
  "text" : "Photo of the Day: President Obama listens to Cecilia Mu\u00F1oz, Domestic Policy Council Director, in the Roosevelt Room: http:\/\/t.co\/Cg6LR8aS",
  "id" : 281241448681197568,
  "created_at" : "2012-12-19 03:36:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 78, 86 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281147296425574400",
  "text" : "RT @arneduncan: As we reflect on last week's tragedy, here are resources from @usedgov that may be helpful to schools\/districts http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 62, 70 ],
        "id_str" : "20437286",
        "id" : 20437286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/ZnwRwE3m",
        "expanded_url" : "http:\/\/go.usa.gov\/gdcA",
        "display_url" : "go.usa.gov\/gdcA"
      } ]
    },
    "geo" : { },
    "id_str" : "280775869281206272",
    "text" : "As we reflect on last week's tragedy, here are resources from @usedgov that may be helpful to schools\/districts http:\/\/t.co\/ZnwRwE3m",
    "id" : 280775869281206272,
    "created_at" : "2012-12-17 20:45:58 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 281147296425574400,
  "created_at" : "2012-12-18 21:21:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 27, 38 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 39, 47 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/iom9jQd3",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse",
      "display_url" : "youtube.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "281118077226196993",
  "text" : "RT @macon44: Worth noting, @whitehouse @youtube videos have garnered over 100,000,000 views  http:\/\/t.co\/iom9jQd3 What's your favorite?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 26, 34 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/iom9jQd3",
        "expanded_url" : "http:\/\/www.youtube.com\/whitehouse",
        "display_url" : "youtube.com\/whitehouse"
      } ]
    },
    "geo" : { },
    "id_str" : "281114160866152448",
    "text" : "Worth noting, @whitehouse @youtube videos have garnered over 100,000,000 views  http:\/\/t.co\/iom9jQd3 What's your favorite?",
    "id" : 281114160866152448,
    "created_at" : "2012-12-18 19:10:13 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 281118077226196993,
  "created_at" : "2012-12-18 19:25:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/281104765386108928\/photo\/1",
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/t53oqOZA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-avS3XCMAANaZ2.jpg",
      "id_str" : "281104765390303232",
      "id" : 281104765390303232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-avS3XCMAANaZ2.jpg",
      "sizes" : [ {
        "h" : 1344,
        "resize" : "fit",
        "w" : 2017
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/t53oqOZA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281104765386108928",
  "text" : "Photo of the Day: President Obama works with senior advisors in the Oval Office: http:\/\/t.co\/t53oqOZA",
  "id" : 281104765386108928,
  "created_at" : "2012-12-18 18:32:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Sen. Patrick Leahy",
      "screen_name" : "SenatorLeahy",
      "indices" : [ 25, 38 ],
      "id_str" : "242836537",
      "id" : 242836537
    }, {
      "name" : "U.S. Capitol",
      "screen_name" : "uscapitol",
      "indices" : [ 95, 105 ],
      "id_str" : "17539497",
      "id" : 17539497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281055583593959425",
  "text" : "RT @VP: VP will swear in @SenatorLeahy as President Pro Tempore of the Senate today at 11:30am @uscapitol",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sen. Patrick Leahy",
        "screen_name" : "SenatorLeahy",
        "indices" : [ 17, 30 ],
        "id_str" : "242836537",
        "id" : 242836537
      }, {
        "name" : "U.S. Capitol",
        "screen_name" : "uscapitol",
        "indices" : [ 87, 97 ],
        "id_str" : "17539497",
        "id" : 17539497
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281046922662391808",
    "text" : "VP will swear in @SenatorLeahy as President Pro Tempore of the Senate today at 11:30am @uscapitol",
    "id" : 281046922662391808,
    "created_at" : "2012-12-18 14:43:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 281055583593959425,
  "created_at" : "2012-12-18 15:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280873881810636801",
  "text" : "\"For those of us who remain, let us find the strength to carry on, and make our country worthy of their memory.\" \u2014President Obama",
  "id" : 280873881810636801,
  "created_at" : "2012-12-18 03:15:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/U79VOSe9",
      "expanded_url" : "http:\/\/at.wh.gov\/gb0Qn",
      "display_url" : "at.wh.gov\/gb0Qn"
    } ]
  },
  "geo" : { },
  "id_str" : "280843679684517889",
  "text" : "\"We can\u2019t tolerate this anymore. These tragedies must end. And to end them, we must change.\" \u2014President Obama: http:\/\/t.co\/U79VOSe9",
  "id" : 280843679684517889,
  "created_at" : "2012-12-18 01:15:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/kPtgpPfR",
      "expanded_url" : "http:\/\/at.wh.gov\/gb5iO",
      "display_url" : "at.wh.gov\/gb5iO"
    } ]
  },
  "geo" : { },
  "id_str" : "280822768835125249",
  "text" : "\"Tonight, our country has lost a true American hero\" -President Obama on the passing of Senator Daniel Inouye: http:\/\/t.co\/kPtgpPfR",
  "id" : 280822768835125249,
  "created_at" : "2012-12-17 23:52:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/280773419782504448\/photo\/1",
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/HzSP6y9P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-WB8AzCAAE_99A.jpg",
      "id_str" : "280773419786698753",
      "id" : 280773419786698753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-WB8AzCAAE_99A.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HzSP6y9P"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/MiFu2QQF",
      "expanded_url" : "http:\/\/on.wh.gov\/QBRgtRq",
      "display_url" : "on.wh.gov\/QBRgtRq"
    } ]
  },
  "geo" : { },
  "id_str" : "280773419782504448",
  "text" : "\"As a community, you've inspired us, Newtown.\" -President Obama http:\/\/t.co\/MiFu2QQF http:\/\/t.co\/HzSP6y9P",
  "id" : 280773419782504448,
  "created_at" : "2012-12-17 20:36:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/c7a4GsOE",
      "expanded_url" : "http:\/\/at.wh.gov\/gaiIL",
      "display_url" : "at.wh.gov\/gaiIL"
    } ]
  },
  "geo" : { },
  "id_str" : "280718422113935360",
  "text" : "Full video: President Obama speaks at a prayer vigil for victims &amp; families in Newtown, Connecticut. Watch: http:\/\/t.co\/c7a4GsOE",
  "id" : 280718422113935360,
  "created_at" : "2012-12-17 16:57:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/v4QKKHVA",
      "expanded_url" : "http:\/\/at.wh.gov\/g9btc",
      "display_url" : "at.wh.gov\/g9btc"
    } ]
  },
  "geo" : { },
  "id_str" : "280529969287946240",
  "text" : "\"Newtown, you are not alone.\" \u2014President Obama at prayer vigil tonight. Read the full remarks: http:\/\/t.co\/v4QKKHVA",
  "id" : 280529969287946240,
  "created_at" : "2012-12-17 04:28:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280508308790575106",
  "text" : "RT @PressSec: POTUS tonight (2 of 2): \"...James. Grace. Emilie. Jack. Noah. Caroline. Jessica. Avielle. Benjamin. Allison.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280499684286537728",
    "text" : "POTUS tonight (2 of 2): \"...James. Grace. Emilie. Jack. Noah. Caroline. Jessica. Avielle. Benjamin. Allison.\"",
    "id" : 280499684286537728,
    "created_at" : "2012-12-17 02:28:30 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 280508308790575106,
  "created_at" : "2012-12-17 03:02:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280508284316839938",
  "text" : "RT @PressSec: POTUS tonight (1 of 2): \"Charlotte. Daniel. Olivia. Josephine. Ana. Dylan. Madeleine. Catherine. Chase. Jesse...\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "280499455436935168",
    "text" : "POTUS tonight (1 of 2): \"Charlotte. Daniel. Olivia. Josephine. Ana. Dylan. Madeleine. Catherine. Chase. Jesse...\"",
    "id" : 280499455436935168,
    "created_at" : "2012-12-17 02:27:36 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 280508284316839938,
  "created_at" : "2012-12-17 03:02:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280489631210934273",
  "text" : "\u201CWe cannot tolerate this anymore. These tragedies must end, and to end them, we must change.\u201D \u2014President Obama",
  "id" : 280489631210934273,
  "created_at" : "2012-12-17 01:48:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280487121201004544",
  "text" : "\u201CHere in Newtown, I come to offer the love and prayers of a nation.\u201D \u2014President Obama",
  "id" : 280487121201004544,
  "created_at" : "2012-12-17 01:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/1RWZ08PJ",
      "expanded_url" : "http:\/\/at.wh.gov\/g95xn",
      "display_url" : "at.wh.gov\/g95xn"
    } ]
  },
  "geo" : { },
  "id_str" : "280486654794424322",
  "text" : "Watch live: President Obama is speaking now at a vigil for victims &amp; families in Newtown, CT: http:\/\/t.co\/1RWZ08PJ",
  "id" : 280486654794424322,
  "created_at" : "2012-12-17 01:36:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/EpPlbgva",
      "expanded_url" : "http:\/\/at.wh.gov\/g92qo",
      "display_url" : "at.wh.gov\/g92qo"
    } ]
  },
  "geo" : { },
  "id_str" : "280474741939257345",
  "text" : "Happening now: President Obama speaks at a vigil for victims &amp; families in Newtown, Connecticut. Watch live: http:\/\/t.co\/EpPlbgva",
  "id" : 280474741939257345,
  "created_at" : "2012-12-17 00:49:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/XoRYMWOQ",
      "expanded_url" : "http:\/\/at.wh.gov\/g8X0M",
      "display_url" : "at.wh.gov\/g8X0M"
    } ]
  },
  "geo" : { },
  "id_str" : "280439106541068290",
  "text" : "Tonight, President Obama will speak at a vigil for victims &amp; families in Newtown, CT. Watch live at 7pm ET: http:\/\/t.co\/XoRYMWOQ",
  "id" : 280439106541068290,
  "created_at" : "2012-12-16 22:27:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280418337849237505",
  "text" : "Today, President Obama travels to Newtown, CT to meet with the families of those who were lost and thank first responders.",
  "id" : 280418337849237505,
  "created_at" : "2012-12-16 21:05:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/T4Q3sKLq",
      "expanded_url" : "http:\/\/at.wh.gov\/g8Mys",
      "display_url" : "at.wh.gov\/g8Mys"
    } ]
  },
  "geo" : { },
  "id_str" : "280381156946481152",
  "text" : "In this week's address, President Obama speaks on the tragic shooting in Newtown, CT. Watch: http:\/\/t.co\/T4Q3sKLq",
  "id" : 280381156946481152,
  "created_at" : "2012-12-16 18:37:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/GqoNbm1f",
      "expanded_url" : "http:\/\/at.wh.gov\/g7X9H",
      "display_url" : "at.wh.gov\/g7X9H"
    } ]
  },
  "geo" : { },
  "id_str" : "279994301369425922",
  "text" : "\"Our hearts are broken today. We grieve for the families of those we lost.\" -President Obama in his Weekly Address: http:\/\/t.co\/GqoNbm1f",
  "id" : 279994301369425922,
  "created_at" : "2012-12-15 17:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/KpulpuQQ",
      "expanded_url" : "http:\/\/at.wh.gov\/g7kP2",
      "display_url" : "at.wh.gov\/g7kP2"
    } ]
  },
  "geo" : { },
  "id_str" : "279792957903749120",
  "text" : "Presidential Proclamation: Honoring the Victims of the Shooting in Newtown, Connecticut: http:\/\/t.co\/KpulpuQQ",
  "id" : 279792957903749120,
  "created_at" : "2012-12-15 03:40:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279760509237080064",
  "text" : "President Obama: \"This evening, Michelle &amp; I will do what I know every parent in America will do which is hug our children a little tighter\"",
  "id" : 279760509237080064,
  "created_at" : "2012-12-15 01:31:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/RPjzFQQO",
      "expanded_url" : "http:\/\/at.wh.gov\/g7ki7",
      "display_url" : "at.wh.gov\/g7ki7"
    } ]
  },
  "geo" : { },
  "id_str" : "279731946949599232",
  "text" : "\"I know there is not a parent in America who doesn\u2019t feel the same overwhelming grief that I do.\" \u2014President Obama: http:\/\/t.co\/RPjzFQQO",
  "id" : 279731946949599232,
  "created_at" : "2012-12-14 23:37:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "CTShooting",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/TJwaykOe",
      "expanded_url" : "http:\/\/at.wh.gov\/g74NZ",
      "display_url" : "at.wh.gov\/g74NZ"
    } ]
  },
  "geo" : { },
  "id_str" : "279687725391675393",
  "text" : "Full video: President Obama addresses the school shooting in #Newtown, Connecticut. Watch: http:\/\/t.co\/TJwaykOe #CTShooting",
  "id" : 279687725391675393,
  "created_at" : "2012-12-14 20:42:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CTshooting",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279685675132018688",
  "text" : "\"While nothing can fill the space of a lost child or loved one, all of us can extend a hand to those in need\" \u2014President Obama #CTshooting",
  "id" : 279685675132018688,
  "created_at" : "2012-12-14 20:33:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/RT7APGZv",
      "expanded_url" : "http:\/\/at.wh.gov\/g73wF",
      "display_url" : "at.wh.gov\/g73wF"
    } ]
  },
  "geo" : { },
  "id_str" : "279683695907074049",
  "text" : "President Obama orders US flags to be flown at half-staff in honor of the victims of the shooting in #Newtown, CT: http:\/\/t.co\/RT7APGZv",
  "id" : 279683695907074049,
  "created_at" : "2012-12-14 20:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CTShooting",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/2c7prTb3",
      "expanded_url" : "http:\/\/at.wh.gov\/g72X4",
      "display_url" : "at.wh.gov\/g72X4"
    } ]
  },
  "geo" : { },
  "id_str" : "279681281418219521",
  "text" : "Happening now: President Obama addresses the Connecticut school shooting from the Briefing Room. Watch: http:\/\/t.co\/2c7prTb3 #CTShooting",
  "id" : 279681281418219521,
  "created_at" : "2012-12-14 20:16:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CTshooting",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/a3fDCZ1F",
      "expanded_url" : "http:\/\/at.wh.gov\/g71dy",
      "display_url" : "at.wh.gov\/g71dy"
    } ]
  },
  "geo" : { },
  "id_str" : "279677311404621826",
  "text" : "At 3:15 ET, President Obama will address the Connecticut school shooting from the Briefing Room. Watch: http:\/\/t.co\/a3fDCZ1F #CTshooting",
  "id" : 279677311404621826,
  "created_at" : "2012-12-14 20:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/279616668450295808\/photo\/1",
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/Szg9l1N9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-Fl4OSCEAArCJC.jpg",
      "id_str" : "279616668454490112",
      "id" : 279616668454490112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-Fl4OSCEAArCJC.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Szg9l1N9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279616668450295808",
  "text" : "Photo of the Day: President Obama meets with senior advisors in the Oval Office: http:\/\/t.co\/Szg9l1N9",
  "id" : 279616668450295808,
  "created_at" : "2012-12-14 15:59:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "279385288105676801",
  "text" : "Starting at 7:40 pm ET: President Obama speaks at a Hanukkah Reception at the White House. Watch: http:\/\/t.co\/u95tzH8r",
  "id" : 279385288105676801,
  "created_at" : "2012-12-14 00:40:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "National Guard",
      "screen_name" : "USNationalGuard",
      "indices" : [ 36, 52 ],
      "id_str" : "31310158",
      "id" : 31310158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279323836598603776",
  "text" : "RT @VP: Happy 376th birthday to the @USNationalGuard! Thank you for your continued service both here at home and abroad. --VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Guard",
        "screen_name" : "USNationalGuard",
        "indices" : [ 28, 44 ],
        "id_str" : "31310158",
        "id" : 31310158
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279314286021582848",
    "text" : "Happy 376th birthday to the @USNationalGuard! Thank you for your continued service both here at home and abroad. --VP",
    "id" : 279314286021582848,
    "created_at" : "2012-12-13 19:58:09 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 279323836598603776,
  "created_at" : "2012-12-13 20:36:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/279265543096266752\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/la8lval0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-AmiCaCcAAqGJv.jpg",
      "id_str" : "279265543100461056",
      "id" : 279265543100461056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-AmiCaCcAAqGJv.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/la8lval0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/Rs234lVS",
      "expanded_url" : "http:\/\/on.wh.gov\/FEgWkYN",
      "display_url" : "on.wh.gov\/FEgWkYN"
    } ]
  },
  "geo" : { },
  "id_str" : "279265543096266752",
  "text" : "Photo of the Day: President Obama talks with Natoma Canfield whose letter hangs outside the Oval: http:\/\/t.co\/Rs234lVS http:\/\/t.co\/la8lval0",
  "id" : 279265543096266752,
  "created_at" : "2012-12-13 16:44:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "121212Concert",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/vQfCjx0X",
      "expanded_url" : "http:\/\/wh.gov\/sandy",
      "display_url" : "wh.gov\/sandy"
    }, {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/TlJSRlXE",
      "expanded_url" : "http:\/\/at.wh.gov\/g3ykE",
      "display_url" : "at.wh.gov\/g3ykE"
    } ]
  },
  "geo" : { },
  "id_str" : "279065759190224896",
  "text" : "President Obama: \"You can still help, right now.\" More on #Sandy recovery efforts: http:\/\/t.co\/vQfCjx0X http:\/\/t.co\/TlJSRlXE #121212Concert",
  "id" : 279065759190224896,
  "created_at" : "2012-12-13 03:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "121212Concert",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/GmKHnF49",
      "expanded_url" : "http:\/\/at.wh.gov\/g3xN9",
      "display_url" : "at.wh.gov\/g3xN9"
    } ]
  },
  "geo" : { },
  "id_str" : "279025869392076800",
  "text" : "\"We will recover, we will rebuild, we will come back stronger, together.\" -President Obama http:\/\/t.co\/GmKHnF49 #121212Concert",
  "id" : 279025869392076800,
  "created_at" : "2012-12-13 00:52:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279015127037145088",
  "text" : "RT @DavidAgnew44: Today, President Obama got on a call with local officials &amp; constituents to discuss #My2k. See their pics &amp; tw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/Twe3X50r",
        "expanded_url" : "http:\/\/wh.gov\/RBLd",
        "display_url" : "wh.gov\/RBLd"
      } ]
    },
    "geo" : { },
    "id_str" : "279014301853962241",
    "text" : "Today, President Obama got on a call with local officials &amp; constituents to discuss #My2k. See their pics &amp; tweets: http:\/\/t.co\/Twe3X50r",
    "id" : 279014301853962241,
    "created_at" : "2012-12-13 00:06:08 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 279015127037145088,
  "created_at" : "2012-12-13 00:09:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/278977417643700224\/photo\/1",
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/rJ1ngQhH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A98ge7eCMAAP8qK.jpg",
      "id_str" : "278977417652088832",
      "id" : 278977417652088832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A98ge7eCMAAP8qK.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rJ1ngQhH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278977417643700224",
  "text" : "Behind-the-Scenes Photo: President Obama high fives a child in Williamsburg, Va., Oct. 14, 2012: http:\/\/t.co\/rJ1ngQhH",
  "id" : 278977417643700224,
  "created_at" : "2012-12-12 21:39:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 3, 19 ],
      "id_str" : "17961886",
      "id" : 17961886
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DidYouKnow",
      "indices" : [ 21, 32 ]
    }, {
      "text" : "volunteering",
      "indices" : [ 107, 120 ]
    }, {
      "text" : "VCLA",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278938424336060418",
  "text" : "RT @nationalservice: #DidYouKnow that Americans volunteered 7.9 million hours last year? Find out more abt #volunteering w\/ #VCLA. http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DidYouKnow",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "volunteering",
        "indices" : [ 86, 99 ]
      }, {
        "text" : "VCLA",
        "indices" : [ 103, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/ulRrXht6",
        "expanded_url" : "http:\/\/go.usa.gov\/gNSY",
        "display_url" : "go.usa.gov\/gNSY"
      } ]
    },
    "geo" : { },
    "id_str" : "278878156700651520",
    "text" : "#DidYouKnow that Americans volunteered 7.9 million hours last year? Find out more abt #volunteering w\/ #VCLA. http:\/\/t.co\/ulRrXht6",
    "id" : 278878156700651520,
    "created_at" : "2012-12-12 15:05:08 +0000",
    "user" : {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "protected" : false,
      "id_str" : "17961886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695658719045160961\/04v_MrsK_normal.jpg",
      "id" : 17961886,
      "verified" : false
    }
  },
  "id" : 278938424336060418,
  "created_at" : "2012-12-12 19:04:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/278893403343831040\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ncZXZEeW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A97UEp0CQAAeuUg.jpg",
      "id_str" : "278893403352219648",
      "id" : 278893403352219648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A97UEp0CQAAeuUg.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ncZXZEeW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/b09y9PHV",
      "expanded_url" : "http:\/\/on.wh.gov\/KlHxsqa",
      "display_url" : "on.wh.gov\/KlHxsqa"
    } ]
  },
  "geo" : { },
  "id_str" : "278893403343831040",
  "text" : "Photo of the Day: President Obama talks on the phone in the Oval Office, Dec. 11, 2012. More pics: http:\/\/t.co\/b09y9PHV http:\/\/t.co\/ncZXZEeW",
  "id" : 278893403343831040,
  "created_at" : "2012-12-12 16:05:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 7, 10 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/278693415762403328\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/0MCdYYIj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A94eL2BCIAEGjer.jpg",
      "id_str" : "278693415770791937",
      "id" : 278693415770791937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A94eL2BCIAEGjer.jpg",
      "sizes" : [ {
        "h" : 374,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/0MCdYYIj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/Lo0jZkI3",
      "expanded_url" : "http:\/\/on.wh.gov\/39SozEK",
      "display_url" : "on.wh.gov\/39SozEK"
    } ]
  },
  "geo" : { },
  "id_str" : "278693415762403328",
  "text" : "Photo: @VP and Dr. Jill Biden attend the 113th Army-Navy football game in Philadelphia, PA: http:\/\/t.co\/Lo0jZkI3 http:\/\/t.co\/0MCdYYIj",
  "id" : 278693415762403328,
  "created_at" : "2012-12-12 02:51:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/yUIkDoaS",
      "expanded_url" : "http:\/\/on.wh.gov\/ApbnXnH",
      "display_url" : "on.wh.gov\/ApbnXnH"
    } ]
  },
  "geo" : { },
  "id_str" : "278670264437465088",
  "text" : "Fact: Under President Obama's watch spending grew at the slowest pace since President Eisenhower: http:\/\/t.co\/yUIkDoaS",
  "id" : 278670264437465088,
  "created_at" : "2012-12-12 01:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/278650824534667265\/photo\/1",
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/XS9Q5acr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A933ctVCMAEDBaQ.jpg",
      "id_str" : "278650824543055873",
      "id" : 278650824543055873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A933ctVCMAEDBaQ.jpg",
      "sizes" : [ {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/XS9Q5acr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/oSHfafnM",
      "expanded_url" : "http:\/\/on.wh.gov\/BcDgW8n",
      "display_url" : "on.wh.gov\/BcDgW8n"
    } ]
  },
  "geo" : { },
  "id_str" : "278650824534667265",
  "text" : "Meet \"Pretty Willie\" Carter: http:\/\/t.co\/oSHfafnM http:\/\/t.co\/XS9Q5acr",
  "id" : 278650824534667265,
  "created_at" : "2012-12-12 00:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/278599337691455488\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/dIPwTRRJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A93Inx5CIAAzSgf.jpg",
      "id_str" : "278599337699844096",
      "id" : 278599337699844096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A93Inx5CIAAzSgf.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/dIPwTRRJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278599337691455488",
  "text" : "The word is out: if you want to find the best workers in the world \u2013 you better bet on the United States of America. http:\/\/t.co\/dIPwTRRJ",
  "id" : 278599337691455488,
  "created_at" : "2012-12-11 20:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 37, 47 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gov20",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/GsizcjzK",
      "expanded_url" : "http:\/\/go.usa.gov\/gNh5",
      "display_url" : "go.usa.gov\/gNh5"
    } ]
  },
  "geo" : { },
  "id_str" : "278572001134800896",
  "text" : "RT @StateDept: Public voting for the @StateDept's blog name is underway! Make your voice heard and vote now: http:\/\/t.co\/GsizcjzK. #gov20",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 22, 32 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gov20",
        "indices" : [ 116, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/GsizcjzK",
        "expanded_url" : "http:\/\/go.usa.gov\/gNh5",
        "display_url" : "go.usa.gov\/gNh5"
      } ]
    },
    "geo" : { },
    "id_str" : "278554478561607680",
    "text" : "Public voting for the @StateDept's blog name is underway! Make your voice heard and vote now: http:\/\/t.co\/GsizcjzK. #gov20",
    "id" : 278554478561607680,
    "created_at" : "2012-12-11 17:38:57 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 278572001134800896,
  "created_at" : "2012-12-11 18:48:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/rjwIE6C7",
      "expanded_url" : "http:\/\/at.wh.gov\/g0Iv8",
      "display_url" : "at.wh.gov\/g0Iv8"
    } ]
  },
  "geo" : { },
  "id_str" : "278551468359970816",
  "text" : "Every person who has written in on #My2k will have their story read by someone at the White House. We're listening: http:\/\/t.co\/rjwIE6C7",
  "id" : 278551468359970816,
  "created_at" : "2012-12-11 17:26:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/278307111568547840\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/e2N42662",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9y-1-vCIAA736b.jpg",
      "id_str" : "278307111572742144",
      "id" : 278307111572742144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9y-1-vCIAA736b.jpg",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/e2N42662"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/57nNQjo2",
      "expanded_url" : "http:\/\/on.wh.gov\/gy9tW1z",
      "display_url" : "on.wh.gov\/gy9tW1z"
    } ]
  },
  "geo" : { },
  "id_str" : "278307111568547840",
  "text" : "Yesterday, the First Family attended the \"Christmas in Washington\" concert taping in DC: http:\/\/t.co\/57nNQjo2 Photo: http:\/\/t.co\/e2N42662",
  "id" : 278307111568547840,
  "created_at" : "2012-12-11 01:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 137, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/VsLzhR6m",
      "expanded_url" : "http:\/\/at.wh.gov\/fZjJP",
      "display_url" : "at.wh.gov\/fZjJP"
    } ]
  },
  "geo" : { },
  "id_str" : "278286952460079104",
  "text" : "Tiffany &amp; Ann Marie shared what $2,000 means to them. Watch what happened next: http:\/\/t.co\/VsLzhR6m Tell us what it means to you w\/ #My2k",
  "id" : 278286952460079104,
  "created_at" : "2012-12-10 23:55:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 3, 14 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278228208384614400",
  "text" : "RT @USTreasury: CHART: POTUS visiting MI auto plant today. Since rescue, auto industry has added more than a quarter million new jobs ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTreasury\/status\/278226206376206337\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/N9kk32jl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A9x1QrbCIAAvgkW.jpg",
        "id_str" : "278226206384594944",
        "id" : 278226206384594944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9x1QrbCIAAvgkW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 262,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 790,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 815,
          "resize" : "fit",
          "w" : 1056
        } ],
        "display_url" : "pic.twitter.com\/N9kk32jl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278226206376206337",
    "text" : "CHART: POTUS visiting MI auto plant today. Since rescue, auto industry has added more than a quarter million new jobs http:\/\/t.co\/N9kk32jl",
    "id" : 278226206376206337,
    "created_at" : "2012-12-10 19:54:31 +0000",
    "user" : {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "protected" : false,
      "id_str" : "120176950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461250108441370624\/-9PNMlfp_normal.jpeg",
      "id" : 120176950,
      "verified" : true
    }
  },
  "id" : 278228208384614400,
  "created_at" : "2012-12-10 20:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278225603923161089",
  "text" : "\"As long as I have the privilege of serving as your President, I\u2019m going to keep fighting for you.\" \u2014President Obama at Detroit Diesel today",
  "id" : 278225603923161089,
  "created_at" : "2012-12-10 19:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278224944666652674",
  "text" : "\"Our economic success has never come from the top-down; it comes from the middle-out.\" \u2014President Obama at Detroit Diesel in Redford, MI",
  "id" : 278224944666652674,
  "created_at" : "2012-12-10 19:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278221534684905473",
  "text" : "RT @WHLive: President Obama: Today, Daimler is announcing a new $120 million investment...creating 115 good, new union jobs...right here ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278221251380666368",
    "text" : "President Obama: Today, Daimler is announcing a new $120 million investment...creating 115 good, new union jobs...right here in Redford.",
    "id" : 278221251380666368,
    "created_at" : "2012-12-10 19:34:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 278221534684905473,
  "created_at" : "2012-12-10 19:35:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278220687599079424",
  "text" : "\"I believe America only succeeds and thrives when we have a strong and growing middle class.\" \u2014President Obama",
  "id" : 278220687599079424,
  "created_at" : "2012-12-10 19:32:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 127, 134 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/lG8YEVbQ",
      "expanded_url" : "http:\/\/at.wh.gov\/fYNi4",
      "display_url" : "at.wh.gov\/fYNi4"
    } ]
  },
  "geo" : { },
  "id_str" : "278219326346113024",
  "text" : "Happening now: President Obama speaks on the economy from a Detroit Diesel Facility in MI. Watch: http:\/\/t.co\/lG8YEVbQ Follow: @WHLive",
  "id" : 278219326346113024,
  "created_at" : "2012-12-10 19:27:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/p0FmWAZI",
      "expanded_url" : "http:\/\/at.wh.gov\/fYCkV",
      "display_url" : "at.wh.gov\/fYCkV"
    } ]
  },
  "geo" : { },
  "id_str" : "278200071491825664",
  "text" : "Today, President Obama tours the Daimler Detroit Diesel plant in MI &amp; delivers remarks on the economy. Watch at 2ET: http:\/\/t.co\/p0FmWAZI",
  "id" : 278200071491825664,
  "created_at" : "2012-12-10 18:10:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Axelrod",
      "screen_name" : "davidaxelrod",
      "indices" : [ 53, 66 ],
      "id_str" : "244655353",
      "id" : 244655353
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/278189321033502721\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/GNENSgOx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9xTtq0CUAA8vh1.jpg",
      "id_str" : "278189321041891328",
      "id" : 278189321041891328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9xTtq0CUAA8vh1.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GNENSgOx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278189321033502721",
  "text" : "Photo of the Day: President Obama watches a video of @DavidAxelrod shaving off his mustache in support of epilepsy: http:\/\/t.co\/GNENSgOx",
  "id" : 278189321033502721,
  "created_at" : "2012-12-10 17:27:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/bXxEwaSj",
      "expanded_url" : "http:\/\/on.wh.gov\/aASsf7u",
      "display_url" : "on.wh.gov\/aASsf7u"
    } ]
  },
  "geo" : { },
  "id_str" : "277541882354102272",
  "text" : "\"Michelle and I send our warmest wishes to all those celebrating Hanukkah around the world.\" -President Obama: http:\/\/t.co\/bXxEwaSj",
  "id" : 277541882354102272,
  "created_at" : "2012-12-08 22:35:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinterest",
      "screen_name" : "Pinterest",
      "indices" : [ 3, 13 ],
      "id_str" : "106837463",
      "id" : 106837463
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277468113950363648",
  "text" : "RT @Pinterest: The @WhiteHouse is on Pinterest! AND pinners are invited to a Holiday Social to tour the decor &amp; make a craft! Apply: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/6DG6KPZ1",
        "expanded_url" : "http:\/\/on.wh.gov\/1kw1vqb",
        "display_url" : "on.wh.gov\/1kw1vqb"
      } ]
    },
    "geo" : { },
    "id_str" : "277467670549495808",
    "text" : "The @WhiteHouse is on Pinterest! AND pinners are invited to a Holiday Social to tour the decor &amp; make a craft! Apply: http:\/\/t.co\/6DG6KPZ1",
    "id" : 277467670549495808,
    "created_at" : "2012-12-08 17:40:22 +0000",
    "user" : {
      "name" : "Pinterest",
      "screen_name" : "Pinterest",
      "protected" : false,
      "id_str" : "106837463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622086313764745216\/T3KEBemO_normal.png",
      "id" : 106837463,
      "verified" : true
    }
  },
  "id" : 277468113950363648,
  "created_at" : "2012-12-08 17:42:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinterest",
      "screen_name" : "Pinterest",
      "indices" : [ 29, 39 ],
      "id_str" : "106837463",
      "id" : 106837463
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/277465090834440192\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/ulKxWVQC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9nBB7FCIAAID57.jpg",
      "id_str" : "277465090842828800",
      "id" : 277465090842828800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9nBB7FCIAAID57.jpg",
      "sizes" : [ {
        "h" : 685,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 554
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ulKxWVQC"
    } ],
    "hashtags" : [ {
      "text" : "WHSocial",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/L83XcYbz",
      "expanded_url" : "http:\/\/on.wh.gov\/1kw1vqb",
      "display_url" : "on.wh.gov\/1kw1vqb"
    } ]
  },
  "geo" : { },
  "id_str" : "277465090834440192",
  "text" : "Today, the White House joins @Pinterest &amp; invites followers to attend a Holiday #WHSocial. Apply: http:\/\/t.co\/L83XcYbz http:\/\/t.co\/ulKxWVQC",
  "id" : 277465090834440192,
  "created_at" : "2012-12-08 17:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/qMfMU465",
      "expanded_url" : "http:\/\/on.wh.gov\/dmGMnNK",
      "display_url" : "on.wh.gov\/dmGMnNK"
    } ]
  },
  "geo" : { },
  "id_str" : "277436595819380737",
  "text" : "In this week's address, President Obama urged Congress to extend the middle class tax cuts for 98% of Americans: http:\/\/t.co\/qMfMU465 #My2k",
  "id" : 277436595819380737,
  "created_at" : "2012-12-08 15:36:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/277403432942436352\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/2MtrkQWs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9mI89iCAAEa0OG.jpg",
      "id_str" : "277403432950824961",
      "id" : 277403432950824961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9mI89iCAAEa0OG.jpg",
      "sizes" : [ {
        "h" : 419,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/2MtrkQWs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/1P5B2wRa",
      "expanded_url" : "http:\/\/on.wh.gov\/RB1tjSx",
      "display_url" : "on.wh.gov\/RB1tjSx"
    } ]
  },
  "geo" : { },
  "id_str" : "277403432942436352",
  "text" : "Here's a sneak peek at the 2012 White House holiday card featuring First Dog Bo: http:\/\/t.co\/1P5B2wRa http:\/\/t.co\/2MtrkQWs",
  "id" : 277403432942436352,
  "created_at" : "2012-12-08 13:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/277386297084096513\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/dtzJ2C5U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9l5XheCMAEiLkw.jpg",
      "id_str" : "277386297088290817",
      "id" : 277386297088290817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9l5XheCMAEiLkw.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dtzJ2C5U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277386297084096513",
  "text" : "Behind-the-Scenes Photo: President Obama kisses a baby at Denver International Airport, Nov. 1, 2012: http:\/\/t.co\/dtzJ2C5U",
  "id" : 277386297084096513,
  "created_at" : "2012-12-08 12:17:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/277345423658721280\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/UxrdDrtm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9lUMYHCIAA1Z5Q.jpg",
      "id_str" : "277345423667109888",
      "id" : 277345423667109888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9lUMYHCIAA1Z5Q.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/UxrdDrtm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/Up6t4J9W",
      "expanded_url" : "http:\/\/on.wh.gov\/7uhWbbA",
      "display_url" : "on.wh.gov\/7uhWbbA"
    } ]
  },
  "geo" : { },
  "id_str" : "277345423658721280",
  "text" : "This week, the First Family flipped the switch on the National Christmas Tree in Washington, DC http:\/\/t.co\/Up6t4J9W http:\/\/t.co\/UxrdDrtm",
  "id" : 277345423658721280,
  "created_at" : "2012-12-08 09:34:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/mePwO10Y",
      "expanded_url" : "http:\/\/on.wh.gov\/myFc9YK",
      "display_url" : "on.wh.gov\/myFc9YK"
    } ]
  },
  "geo" : { },
  "id_str" : "277277427678461954",
  "text" : "Find out why taking tax rates off the table threatens non-profits &amp; charitable giving: http:\/\/t.co\/mePwO10Y",
  "id" : 277277427678461954,
  "created_at" : "2012-12-08 05:04:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/277226833429291008\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/AdJ7MHhO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9joVhECYAEteqZ.jpg",
      "id_str" : "277226833433485313",
      "id" : 277226833433485313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9joVhECYAEteqZ.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AdJ7MHhO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/rFADUZw8",
      "expanded_url" : "http:\/\/on.wh.gov\/9TCgo4d",
      "display_url" : "on.wh.gov\/9TCgo4d"
    } ]
  },
  "geo" : { },
  "id_str" : "277226833429291008",
  "text" : "Photo gallery: Behind the scenes in Nov: http:\/\/t.co\/rFADUZw8 Pic: President Obama rings a big bell in Burma http:\/\/t.co\/AdJ7MHhO",
  "id" : 277226833429291008,
  "created_at" : "2012-12-08 01:43:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/Thir2JTE",
      "expanded_url" : "http:\/\/on.wh.gov\/GY3N1kI",
      "display_url" : "on.wh.gov\/GY3N1kI"
    } ]
  },
  "geo" : { },
  "id_str" : "277208074199117824",
  "text" : "This week, the President answered Qs on Twitter, visited a family who spoke out on #My2k &amp; lit the Natl Christmas Tree: http:\/\/t.co\/Thir2JTE",
  "id" : 277208074199117824,
  "created_at" : "2012-12-08 00:28:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/277196420937809920\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/4HdQ6Qqf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9jMrRtCAAAaYHw.png",
      "id_str" : "277196420942004224",
      "id" : 277196420942004224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9jMrRtCAAAaYHw.png",
      "sizes" : [ {
        "h" : 910,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 922,
        "resize" : "fit",
        "w" : 1037
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4HdQ6Qqf"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/lOQBX0nN",
      "expanded_url" : "http:\/\/on.wh.gov\/AU6PWkb",
      "display_url" : "on.wh.gov\/AU6PWkb"
    } ]
  },
  "geo" : { },
  "id_str" : "277196420937809920",
  "text" : "Want to know what Americans are saying about #My2k? Find out &amp; join the conversation:  http:\/\/t.co\/lOQBX0nN http:\/\/t.co\/4HdQ6Qqf",
  "id" : 277196420937809920,
  "created_at" : "2012-12-07 23:42:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277192170673405952",
  "text" : "RT @VP: PHOTO: VP discusses #My2K &amp; importance of middle class tax cuts with folks at Metro 29 diner in Arlington, VA today. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/277182548969402368\/photo\/1",
        "indices" : [ 121, 141 ],
        "url" : "http:\/\/t.co\/7rQP7Yih",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A9jAD0mCMAAMPem.jpg",
        "id_str" : "277182548973596672",
        "id" : 277182548973596672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9jAD0mCMAAMPem.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/7rQP7Yih"
      } ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 20, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277182548969402368",
    "text" : "PHOTO: VP discusses #My2K &amp; importance of middle class tax cuts with folks at Metro 29 diner in Arlington, VA today. http:\/\/t.co\/7rQP7Yih",
    "id" : 277182548969402368,
    "created_at" : "2012-12-07 22:47:24 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 277192170673405952,
  "created_at" : "2012-12-07 23:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/277137316353540097\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/qLIgZG4N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9iW67_CAAAXcTZ.jpg",
      "id_str" : "277137316361928704",
      "id" : 277137316361928704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9iW67_CAAAXcTZ.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qLIgZG4N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277137316353540097",
  "text" : "Photo of the Day: President and First Lady Michelle Obama walk along the Colonnade of the White House, Dec. 6, 2012: http:\/\/t.co\/qLIgZG4N",
  "id" : 277137316353540097,
  "created_at" : "2012-12-07 19:47:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277105950865891328",
  "text" : "RT @VP: Today, I'm having lunch w\/ folks who would see their taxes go up if Congress doesn't act. Looking forward to hearing from them o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 130, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "277092474894307328",
    "text" : "Today, I'm having lunch w\/ folks who would see their taxes go up if Congress doesn't act. Looking forward to hearing from them on #My2k \u2014VP",
    "id" : 277092474894307328,
    "created_at" : "2012-12-07 16:49:28 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 277105950865891328,
  "created_at" : "2012-12-07 17:43:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/277087607861673985\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/JVkWLhDl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9hpthaCAAADtJ9.jpg",
      "id_str" : "277087607865868288",
      "id" : 277087607865868288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9hpthaCAAADtJ9.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JVkWLhDl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/Bs8EkqnS",
      "expanded_url" : "http:\/\/on.wh.gov\/ItcmEBb",
      "display_url" : "on.wh.gov\/ItcmEBb"
    } ]
  },
  "geo" : { },
  "id_str" : "277087607861673985",
  "text" : "Proclamation: Natl Pearl Harbor Remembrance Day 2012: http:\/\/t.co\/Bs8EkqnS Pic: President Obama @ Pearl Harbor in 2011: http:\/\/t.co\/JVkWLhDl",
  "id" : 277087607861673985,
  "created_at" : "2012-12-07 16:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/277074086201532416\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/gToue55U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9hdadTCIAAEHui.jpg",
      "id_str" : "277074086205726720",
      "id" : 277074086205726720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9hdadTCIAAEHui.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/gToue55U"
    } ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 9, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/nLwyveyo",
      "expanded_url" : "http:\/\/on.wh.gov\/P5J1MW7",
      "display_url" : "on.wh.gov\/P5J1MW7"
    } ]
  },
  "geo" : { },
  "id_str" : "277074086201532416",
  "text" : "New jobs #s: US economy adds 147k private sector jobs in Nov, 5.6M jobs over 33 months: http:\/\/t.co\/nLwyveyo More to do http:\/\/t.co\/gToue55U",
  "id" : 277074086201532416,
  "created_at" : "2012-12-07 15:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/276857825433632769\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/wtzvBLVZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9eYubLCQAAFffk.jpg",
      "id_str" : "276857825442021376",
      "id" : 276857825442021376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9eYubLCQAAFffk.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wtzvBLVZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276857825433632769",
  "text" : "Photo: Audience members listen to President Obama's remarks during the Tribal Nations Conference in Washington, D.C. http:\/\/t.co\/wtzvBLVZ",
  "id" : 276857825433632769,
  "created_at" : "2012-12-07 01:17:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/276825710809735169\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/yxLfzKno",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9d7hG4CYAEh8pe.jpg",
      "id_str" : "276825710818123777",
      "id" : 276825710818123777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9d7hG4CYAEh8pe.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yxLfzKno"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/d5sswKzf",
      "expanded_url" : "http:\/\/on.wh.gov\/RFUeXtd",
      "display_url" : "on.wh.gov\/RFUeXtd"
    } ]
  },
  "geo" : { },
  "id_str" : "276825710809735169",
  "text" : "Tiffany shared what $2,000 meant to her...&amp; the President stopped by to talk about it http:\/\/t.co\/d5sswKzf #My2k Photo: http:\/\/t.co\/yxLfzKno",
  "id" : 276825710809735169,
  "created_at" : "2012-12-06 23:09:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/Om5knytn",
      "expanded_url" : "http:\/\/on.wh.gov\/yxZkiqW",
      "display_url" : "on.wh.gov\/yxZkiqW"
    } ]
  },
  "geo" : { },
  "id_str" : "276808264610635776",
  "text" : "Starting now: President Obama &amp; the First Lady attend the 2012 National Christmas Tree Lighting. Watch live: http:\/\/t.co\/Om5knytn",
  "id" : 276808264610635776,
  "created_at" : "2012-12-06 22:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Patrick Harris",
      "screen_name" : "ActuallyNPH",
      "indices" : [ 67, 79 ],
      "id_str" : "90420314",
      "id" : 90420314
    }, {
      "name" : "Jason Mraz",
      "screen_name" : "jason_mraz",
      "indices" : [ 80, 91 ],
      "id_str" : "19018401",
      "id" : 19018401
    }, {
      "name" : "The Fray",
      "screen_name" : "TheFray",
      "indices" : [ 92, 100 ],
      "id_str" : "21891735",
      "id" : 21891735
    }, {
      "name" : "Phillip Phillips",
      "screen_name" : "Phillips",
      "indices" : [ 101, 110 ],
      "id_str" : "462495192",
      "id" : 462495192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/tZiXI45i",
      "expanded_url" : "http:\/\/on.wh.gov\/oekZWpJ",
      "display_url" : "on.wh.gov\/oekZWpJ"
    } ]
  },
  "geo" : { },
  "id_str" : "276799440398999552",
  "text" : "Tune in at 4:30ET for the 2012 National Christmas Tree Lighting w\/ @ActuallyNPH @jason_mraz @TheFray @Phillips &amp; more: http:\/\/t.co\/tZiXI45i",
  "id" : 276799440398999552,
  "created_at" : "2012-12-06 21:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/Z9tAseha",
      "expanded_url" : "http:\/\/on.wh.gov\/BabtZEW",
      "display_url" : "on.wh.gov\/BabtZEW"
    } ]
  },
  "geo" : { },
  "id_str" : "276748413025005568",
  "text" : "President Obama is on his way to visit Tiffany, one of the 375,000+ Americans who have spoken out on #My2k. Her story: http:\/\/t.co\/Z9tAseha",
  "id" : 276748413025005568,
  "created_at" : "2012-12-06 18:02:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 101, 110 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/276717197970243584\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/j1BK60oK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9cY01DCAAApveQ.jpg",
      "id_str" : "276717197978632192",
      "id" : 276717197978632192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9cY01DCAAApveQ.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/j1BK60oK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276717197970243584",
  "text" : "Photo of the Day: President Obama returns to the White House following the Tribal Nations Conference @Interior: http:\/\/t.co\/j1BK60oK",
  "id" : 276717197970243584,
  "created_at" : "2012-12-06 15:58:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/276492799808008192\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/AsAnX80i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9ZMvIwCcAALhSa.jpg",
      "id_str" : "276492799816396800",
      "id" : 276492799816396800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9ZMvIwCcAALhSa.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AsAnX80i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276492799808008192",
  "text" : "Photo of the Day: President Obama &amp; the First Lady walk down the stairs before a holiday reception at the White House: http:\/\/t.co\/AsAnX80i",
  "id" : 276492799808008192,
  "created_at" : "2012-12-06 01:06:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/4j64H2NK",
      "expanded_url" : "http:\/\/on.wh.gov\/jEOUJqG",
      "display_url" : "on.wh.gov\/jEOUJqG"
    } ]
  },
  "geo" : { },
  "id_str" : "276434371911766016",
  "text" : "Watch a behind-the-scenes video from President Obama's Twitter Q&amp;A on #My2k: http:\/\/t.co\/4j64H2NK",
  "id" : 276434371911766016,
  "created_at" : "2012-12-05 21:14:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/myGFkRoe",
      "expanded_url" : "http:\/\/on.wh.gov\/fHrooIN",
      "display_url" : "on.wh.gov\/fHrooIN"
    } ]
  },
  "geo" : { },
  "id_str" : "276415940500025344",
  "text" : "Starting soon: President Obama delivers closing remarks at the 2012 #TribalNations Conference. Watch live: http:\/\/t.co\/myGFkRoe",
  "id" : 276415940500025344,
  "created_at" : "2012-12-05 20:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/276350176032071681\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/2k1C6Evn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9XLBVyCIAAdh_l.jpg",
      "id_str" : "276350176040460288",
      "id" : 276350176040460288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9XLBVyCIAAdh_l.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/2k1C6Evn"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276350176032071681",
  "text" : "To Sher, $2,000 means gas in the car for her husband's drive to work. What does $2,000 mean to you? Tell us w\/ #My2k http:\/\/t.co\/2k1C6Evn",
  "id" : 276350176032071681,
  "created_at" : "2012-12-05 15:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/276165517616754689\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/MjqYiAjD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9UjEzlCMAAielu.jpg",
      "id_str" : "276165517625143296",
      "id" : 276165517625143296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9UjEzlCMAAielu.jpg",
      "sizes" : [ {
        "h" : 655,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 655,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/MjqYiAjD"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276165517616754689",
  "text" : "Over 350,000 Americans have spoken out on extending middle-class tax cuts. Keep the #My2k stories coming: http:\/\/t.co\/MjqYiAjD",
  "id" : 276165517616754689,
  "created_at" : "2012-12-05 03:26:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/276126511461969922\/photo\/1",
      "indices" : [ 125, 145 ],
      "url" : "http:\/\/t.co\/xlOk3NsJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9T_mWVCMAAtMWB.jpg",
      "id_str" : "276126511470358528",
      "id" : 276126511470358528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9T_mWVCMAAtMWB.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/xlOk3NsJ"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276126511461969922",
  "text" : "To Martella &amp; Eugene $2,000 means paying the bills &amp; Christmas gifts for the grandkids. What does #My2k mean to you? http:\/\/t.co\/xlOk3NsJ",
  "id" : 276126511461969922,
  "created_at" : "2012-12-05 00:51:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/zWpFCMc1",
      "expanded_url" : "http:\/\/on.wh.gov\/cT8fJnz",
      "display_url" : "on.wh.gov\/cT8fJnz"
    } ]
  },
  "geo" : { },
  "id_str" : "276057421061955585",
  "text" : "You don't have to be an economist to understand what $2,000 means to middle-class families: http:\/\/t.co\/zWpFCMc1 #My2k",
  "id" : 276057421061955585,
  "created_at" : "2012-12-04 20:16:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/iMzmF4cJ",
      "expanded_url" : "http:\/\/go.usa.gov\/gkz4",
      "display_url" : "go.usa.gov\/gkz4"
    } ]
  },
  "geo" : { },
  "id_str" : "276042362084540416",
  "text" : "RT @StateDept: Latest on the @WhiteHouse Blog: President Obama Pushes for Nonproliferation http:\/\/t.co\/iMzmF4cJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/iMzmF4cJ",
        "expanded_url" : "http:\/\/go.usa.gov\/gkz4",
        "display_url" : "go.usa.gov\/gkz4"
      } ]
    },
    "geo" : { },
    "id_str" : "276041094729441280",
    "text" : "Latest on the @WhiteHouse Blog: President Obama Pushes for Nonproliferation http:\/\/t.co\/iMzmF4cJ",
    "id" : 276041094729441280,
    "created_at" : "2012-12-04 19:11:40 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 276042362084540416,
  "created_at" : "2012-12-04 19:16:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 88, 93 ]
    }, {
      "text" : "My2k",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/p3ZVAHvt",
      "expanded_url" : "http:\/\/wh.gov\/my2k",
      "display_url" : "wh.gov\/my2k"
    } ]
  },
  "geo" : { },
  "id_str" : "276003408861859841",
  "text" : "\"Make your voice heard. I promise, it makes a difference.\" \u2014President Obama. Share your #My2k story: http:\/\/t.co\/p3ZVAHvt &amp; use #My2k",
  "id" : 276003408861859841,
  "created_at" : "2012-12-04 16:41:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/275804785947574272\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/ppY9aVCY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9Pa_dYCAAA9gVi.jpg",
      "id_str" : "275804785951768576",
      "id" : 275804785951768576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9Pa_dYCAAA9gVi.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ppY9aVCY"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/sBLlaxE2",
      "expanded_url" : "http:\/\/on.wh.gov\/WjDzdwl",
      "display_url" : "on.wh.gov\/WjDzdwl"
    } ]
  },
  "geo" : { },
  "id_str" : "275804785947574272",
  "text" : "Photo of the Day: President Obama answers #My2k questions on Twitter live from the White House: http:\/\/t.co\/sBLlaxE2 http:\/\/t.co\/ppY9aVCY",
  "id" : 275804785947574272,
  "created_at" : "2012-12-04 03:32:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 56, 64 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/275758411189198850\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/V2gofTcr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9Ow0F9CIAAAe7V.jpg",
      "id_str" : "275758411197587456",
      "id" : 275758411197587456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9Ow0F9CIAAAe7V.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/V2gofTcr"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/QhQuPeys",
      "expanded_url" : "http:\/\/on.wh.gov\/GdYaBcA",
      "display_url" : "on.wh.gov\/GdYaBcA"
    } ]
  },
  "geo" : { },
  "id_str" : "275758411189198850",
  "text" : "Today, President Obama answered your #My2k questions on @twitter. See the full chat: http:\/\/t.co\/QhQuPeys Photo: http:\/\/t.co\/V2gofTcr",
  "id" : 275758411189198850,
  "created_at" : "2012-12-04 00:28:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miranda A. Walker",
      "screen_name" : "Exec_Asst",
      "indices" : [ 3, 13 ],
      "id_str" : "305810968",
      "id" : 305810968
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275746786520477696",
  "text" : "RT @Exec_Asst: @whitehouse #my2k means xtra $ for my kids' school trips, books and transportation to work.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275746082917580800",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #my2k means xtra $ for my kids' school trips, books and transportation to work.",
    "id" : 275746082917580800,
    "created_at" : "2012-12-03 23:39:23 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Miranda A. Walker",
      "screen_name" : "Exec_Asst",
      "protected" : false,
      "id_str" : "305810968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755723517207932928\/v6M_LEe2_normal.jpg",
      "id" : 305810968,
      "verified" : false
    }
  },
  "id" : 275746786520477696,
  "created_at" : "2012-12-03 23:42:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaan",
      "screen_name" : "caitlinhaan",
      "indices" : [ 3, 15 ],
      "id_str" : "280781601",
      "id" : 280781601
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275742534335078401",
  "text" : "RT @caitlinhaan: @whitehouse #My2k will go to paying for my mother's nursing home costs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275742116397846529",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #My2k will go to paying for my mother's nursing home costs.",
    "id" : 275742116397846529,
    "created_at" : "2012-12-03 23:23:38 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Chaan",
      "screen_name" : "caitlinhaan",
      "protected" : false,
      "id_str" : "280781601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758036491335380992\/rSXkxtuh_normal.jpg",
      "id" : 280781601,
      "verified" : false
    }
  },
  "id" : 275742534335078401,
  "created_at" : "2012-12-03 23:25:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Collins",
      "screen_name" : "lisabella964",
      "indices" : [ 3, 16 ],
      "id_str" : "387284264",
      "id" : 387284264
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275741217143271424",
  "text" : "RT @lisabella964: @whitehouse #My2k We are two public school teachers trying to put two boys through college. It's already difficult, do ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275740580884144128",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #My2k We are two public school teachers trying to put two boys through college. It's already difficult, don't make it harder!",
    "id" : 275740580884144128,
    "created_at" : "2012-12-03 23:17:32 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Lisa Collins",
      "screen_name" : "lisabella964",
      "protected" : false,
      "id_str" : "387284264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/457906467027566593\/JRoyqVd7_normal.jpeg",
      "id" : 387284264,
      "verified" : false
    }
  },
  "id" : 275741217143271424,
  "created_at" : "2012-12-03 23:20:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mrs. Odewale",
      "screen_name" : "tewale",
      "indices" : [ 3, 10 ],
      "id_str" : "68141473",
      "id" : 68141473
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 24, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275728279095349248",
  "text" : "RT @tewale: @whitehouse #my2k means extracurricular activities for my 3 beautiful daughters - tutoring,  swimming, piano or dance lessons",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "275708912097968128",
    "geo" : { },
    "id_str" : "275723721073913856",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #my2k means extracurricular activities for my 3 beautiful daughters - tutoring,  swimming, piano or dance lessons",
    "id" : 275723721073913856,
    "in_reply_to_status_id" : 275708912097968128,
    "created_at" : "2012-12-03 22:10:32 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Mrs. Odewale",
      "screen_name" : "tewale",
      "protected" : false,
      "id_str" : "68141473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623681304391843841\/1c4vLB9N_normal.jpg",
      "id" : 68141473,
      "verified" : false
    }
  },
  "id" : 275728279095349248,
  "created_at" : "2012-12-03 22:28:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Steven Young",
      "screen_name" : "RickyStevenYoun",
      "indices" : [ 3, 19 ],
      "id_str" : "781317079",
      "id" : 781317079
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275726832022720513",
  "text" : "RT @RickyStevenYoun: @whitehouse #My2k I'm a small business owner and a college grad facing a ton of debt. That money means some breathi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275724659268415488",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #My2k I'm a small business owner and a college grad facing a ton of debt. That money means some breathing room for my budget.",
    "id" : 275724659268415488,
    "created_at" : "2012-12-03 22:14:16 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Ricky Steven Young",
      "screen_name" : "RickyStevenYoun",
      "protected" : false,
      "id_str" : "781317079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461901648541917184\/4FmpD_8U_normal.jpeg",
      "id" : 781317079,
      "verified" : false
    }
  },
  "id" : 275726832022720513,
  "created_at" : "2012-12-03 22:22:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/275708912097968128\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/kZdjg6eA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9ODy3fCQAAPkbg.png",
      "id_str" : "275708912110551040",
      "id" : 275708912110551040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9ODy3fCQAAPkbg.png",
      "sizes" : [ {
        "h" : 755,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1038
      } ],
      "display_url" : "pic.twitter.com\/kZdjg6eA"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/LfTWIjyH",
      "expanded_url" : "http:\/\/WhiteHouse.gov",
      "display_url" : "WhiteHouse.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "275708912097968128",
  "text" : "What does $2,000 mean to you? Let us know with #My2k &amp; you just might see your story on http:\/\/t.co\/LfTWIjyH: http:\/\/t.co\/kZdjg6eA",
  "id" : 275708912097968128,
  "created_at" : "2012-12-03 21:11:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/275689740446081025\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/V4JjkVIO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9NyW7hCIAAQwtZ.jpg",
      "id_str" : "275689740458663936",
      "id" : 275689740458663936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9NyW7hCIAAQwtZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 663
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 663
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/V4JjkVIO"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/gxeTnVnT",
      "expanded_url" : "http:\/\/storify.com\/whitehouse\/president-obama-answers-my2k-questions-on-twitter",
      "display_url" : "storify.com\/whitehouse\/pre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "275689740446081025",
  "text" : "President Obama just answered your #My2k questions on Twitter. See full Q&amp;A: http:\/\/t.co\/gxeTnVnT Photo: http:\/\/t.co\/V4JjkVIO",
  "id" : 275689740446081025,
  "created_at" : "2012-12-03 19:55:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/275681410822586370\/photo\/1",
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/DhsfAN1b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9NqyFOCQAE4ql5.jpg",
      "id_str" : "275681410826780673",
      "id" : 275681410826780673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9NqyFOCQAE4ql5.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/DhsfAN1b"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275688944195227648",
  "text" : "RT @petesouza: Photo of Pres Obama's hands typing #My2k answers @ whitehouse: http:\/\/t.co\/DhsfAN1b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/275681410822586370\/photo\/1",
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/DhsfAN1b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A9NqyFOCQAE4ql5.jpg",
        "id_str" : "275681410826780673",
        "id" : 275681410826780673,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9NqyFOCQAE4ql5.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/DhsfAN1b"
      } ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 35, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275681410822586370",
    "text" : "Photo of Pres Obama's hands typing #My2k answers @ whitehouse: http:\/\/t.co\/DhsfAN1b",
    "id" : 275681410822586370,
    "created_at" : "2012-12-03 19:22:25 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 275688944195227648,
  "created_at" : "2012-12-03 19:52:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275687893626912770",
  "text" : "Gotta go.  Thx.  Keep pressure on Congress. Call, email, tweet your Member &amp; tell them what 2k means to you. Lets get it done. #my2k -bo",
  "id" : 275687893626912770,
  "created_at" : "2012-12-03 19:48:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mica Powers",
      "screen_name" : "Mica4Life",
      "indices" : [ 1, 11 ],
      "id_str" : "16172862",
      "id" : 16172862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275687472455901184",
  "text" : ".@Mica4Life da bears still gotta shot, despite sad loss this weekend! plus rose will return for playoffs!!! -bo",
  "id" : 275687472455901184,
  "created_at" : "2012-12-03 19:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mica Powers",
      "screen_name" : "Mica4Life",
      "indices" : [ 3, 13 ],
      "id_str" : "16172862",
      "id" : 16172862
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 105, 117 ],
      "id_str" : "813286",
      "id" : 813286
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 118, 129 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhiteSox",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "Bulls",
      "indices" : [ 61, 67 ]
    }, {
      "text" : "Bears",
      "indices" : [ 72, 78 ]
    }, {
      "text" : "NFL",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "NBA",
      "indices" : [ 85, 89 ]
    }, {
      "text" : "MLB",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "My2k",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275687178493898752",
  "text" : "RT @Mica4Life: Who will win it all first: Chicago #WhiteSox, #Bulls, or #Bears? #NFL #NBA #MLB cc: #My2k @BarackObama @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 90, 102 ],
        "id_str" : "813286",
        "id" : 813286
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 103, 114 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhiteSox",
        "indices" : [ 35, 44 ]
      }, {
        "text" : "Bulls",
        "indices" : [ 46, 52 ]
      }, {
        "text" : "Bears",
        "indices" : [ 57, 63 ]
      }, {
        "text" : "NFL",
        "indices" : [ 65, 69 ]
      }, {
        "text" : "NBA",
        "indices" : [ 70, 74 ]
      }, {
        "text" : "MLB",
        "indices" : [ 75, 79 ]
      }, {
        "text" : "My2k",
        "indices" : [ 84, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275672164039020544",
    "text" : "Who will win it all first: Chicago #WhiteSox, #Bulls, or #Bears? #NFL #NBA #MLB cc: #My2k @BarackObama @whitehouse",
    "id" : 275672164039020544,
    "created_at" : "2012-12-03 18:45:40 +0000",
    "user" : {
      "name" : "Mica Powers",
      "screen_name" : "Mica4Life",
      "protected" : false,
      "id_str" : "16172862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797600606525517824\/3VtJup33_normal.jpg",
      "id" : 16172862,
      "verified" : false
    }
  },
  "id" : 275687178493898752,
  "created_at" : "2012-12-03 19:45:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Feinman",
      "screen_name" : "jjfein",
      "indices" : [ 1, 8 ],
      "id_str" : "340441606",
      "id" : 340441606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275687076480032768",
  "text" : ".@jjfein don't expect 100% my budget; room to negotiate. if you incl $1T+ in cuts already made, rough balance b\/w rev &amp; cuts does trick -bo",
  "id" : 275687076480032768,
  "created_at" : "2012-12-03 19:44:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Feinman",
      "screen_name" : "jjfein",
      "indices" : [ 3, 10 ],
      "id_str" : "340441606",
      "id" : 340441606
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275686070060994560",
  "text" : "RT @jjfein: @whitehouse Is there a minimum ratio of revenue increases to spending cuts that you're looking for, or simply a balanced app ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275685087222304768",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Is there a minimum ratio of revenue increases to spending cuts that you're looking for, or simply a balanced approach? #my2k",
    "id" : 275685087222304768,
    "created_at" : "2012-12-03 19:37:01 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Jason Feinman",
      "screen_name" : "jjfein",
      "protected" : false,
      "id_str" : "340441606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000211674135\/25b0b7b2fbf24954246a1e71c1ddeaa1_normal.jpeg",
      "id" : 340441606,
      "verified" : false
    }
  },
  "id" : 275686070060994560,
  "created_at" : "2012-12-03 19:40:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Robertson",
      "screen_name" : "soitgoesem",
      "indices" : [ 1, 12 ],
      "id_str" : "898752162",
      "id" : 898752162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275685798249119744",
  "text" : ".@soitgoesem breaks for middle class impt for families &amp; econ. if top rates don't go up, danger that middle class deductions get hit - bo",
  "id" : 275685798249119744,
  "created_at" : "2012-12-03 19:39:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Robertson",
      "screen_name" : "soitgoesem",
      "indices" : [ 3, 14 ],
      "id_str" : "898752162",
      "id" : 898752162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275684678768398337",
  "text" : "RT @soitgoesem: As a home owner, I worry deductions for home owners are at risk. Is that the case? #My2k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 83, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275684081637928960",
    "text" : "As a home owner, I worry deductions for home owners are at risk. Is that the case? #My2k",
    "id" : 275684081637928960,
    "created_at" : "2012-12-03 19:33:01 +0000",
    "user" : {
      "name" : "Emma Robertson",
      "screen_name" : "soitgoesem",
      "protected" : false,
      "id_str" : "898752162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2752983228\/d42bf2fec2f35062d29193be5ae6845b_normal.jpeg",
      "id" : 898752162,
      "verified" : false
    }
  },
  "id" : 275684678768398337,
  "created_at" : "2012-12-03 19:35:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Osteen",
      "screen_name" : "davidosteen",
      "indices" : [ 1, 13 ],
      "id_str" : "50391990",
      "id" : 50391990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275684295438381057",
  "text" : ".@davidosteen (part 2) Open to more smart cuts but not in areas like R&amp;D, edu that help growth &amp; jobs, or hurt vulnerable (eg disabled) - bo",
  "id" : 275684295438381057,
  "created_at" : "2012-12-03 19:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Osteen",
      "screen_name" : "davidosteen",
      "indices" : [ 1, 13 ],
      "id_str" : "50391990",
      "id" : 50391990
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275683674148728832",
  "text" : ".@davidosteen (part 1) already cut $1T+ in gov spending last yr. Discretionary spending lowest as % of GDP since ike. #my2k",
  "id" : 275683674148728832,
  "created_at" : "2012-12-03 19:31:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Osteen",
      "screen_name" : "davidosteen",
      "indices" : [ 3, 15 ],
      "id_str" : "50391990",
      "id" : 50391990
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 17, 29 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275682251029770240",
  "text" : "RT @davidosteen: @BarackObama Mr. President, Why not place more emphasis on reducing government spending, than on raising revenues? #My2 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 0, 12 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 115, 120 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275681765492940801",
    "in_reply_to_user_id" : 813286,
    "text" : "@BarackObama Mr. President, Why not place more emphasis on reducing government spending, than on raising revenues? #My2K #WHChat",
    "id" : 275681765492940801,
    "created_at" : "2012-12-03 19:23:49 +0000",
    "in_reply_to_screen_name" : "BarackObama",
    "in_reply_to_user_id_str" : "813286",
    "user" : {
      "name" : "David Osteen",
      "screen_name" : "davidosteen",
      "protected" : false,
      "id_str" : "50391990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1212865829\/41370_1507543274_8002_n_normal.jpg",
      "id" : 50391990,
      "verified" : false
    }
  },
  "id" : 275682251029770240,
  "created_at" : "2012-12-03 19:25:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/uc9V9Y7e",
      "expanded_url" : "http:\/\/wh.gov\/5rTh",
      "display_url" : "wh.gov\/5rTh"
    } ]
  },
  "geo" : { },
  "id_str" : "275682154548170752",
  "text" : ".@huntertred not enough revenue, unless you end charitable deductions, etc. less revenue=more cuts in education etc http:\/\/t.co\/uc9V9Y7e -bo",
  "id" : 275682154548170752,
  "created_at" : "2012-12-03 19:25:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Roberts",
      "screen_name" : "dontbeaprat",
      "indices" : [ 1, 13 ],
      "id_str" : "30605763",
      "id" : 30605763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275680810223419392",
  "text" : ".@dontbeaprat cuts w\/out revenue = reductions in student loans; work\/study &amp; college tax credits expire. Bad for growth. like your hair! -bo",
  "id" : 275680810223419392,
  "created_at" : "2012-12-03 19:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandi Roberts",
      "screen_name" : "dontbeaprat",
      "indices" : [ 1, 13 ],
      "id_str" : "30605763",
      "id" : 30605763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275673753403412481",
  "geo" : { },
  "id_str" : "275680617075712000",
  "in_reply_to_user_id" : 30605763,
  "text" : ".@dontbeaprat cuts w\/out revenue=reductions in student loans; work\/study &amp; college tax credits expire.  Bad for growth.  like your hair! -bo",
  "id" : 275680617075712000,
  "in_reply_to_status_id" : 275673753403412481,
  "created_at" : "2012-12-03 19:19:15 +0000",
  "in_reply_to_screen_name" : "dontbeaprat",
  "in_reply_to_user_id_str" : "30605763",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Vanderwyst",
      "screen_name" : "mike5673",
      "indices" : [ 1, 10 ],
      "id_str" : "41455648",
      "id" : 41455648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275679235253874688",
  "text" : ".@mike5673 high end tax cuts do least for economic growth &amp; cost almost $1T. extending middle class cuts boosts consumer demand &amp; growth -bo",
  "id" : 275679235253874688,
  "created_at" : "2012-12-03 19:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Vanderwyst",
      "screen_name" : "mike5673",
      "indices" : [ 3, 12 ],
      "id_str" : "41455648",
      "id" : 41455648
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275678663557652480",
  "text" : "RT @mike5673: Mr. President, why won't keeping tax rates low across the board encourage more hires and therefore more tax revenue? #my2k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 117, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275675554550784000",
    "text" : "Mr. President, why won't keeping tax rates low across the board encourage more hires and therefore more tax revenue? #my2k",
    "id" : 275675554550784000,
    "created_at" : "2012-12-03 18:59:08 +0000",
    "user" : {
      "name" : "Mike Vanderwyst",
      "screen_name" : "mike5673",
      "protected" : false,
      "id_str" : "41455648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1891909143\/Mike_Profile_Pic_normal.png",
      "id" : 41455648,
      "verified" : false
    }
  },
  "id" : 275678663557652480,
  "created_at" : "2012-12-03 19:11:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "geodynamicsdependent",
      "screen_name" : "pmmckenzie",
      "indices" : [ 1, 12 ],
      "id_str" : "1698103268",
      "id" : 1698103268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275678516677328896",
  "text" : ".@pmmckenzie we can reduce deficit in balanced way by ending tax cuts for top 2% + reforms that strengthen safety net &amp; invest in future -bo",
  "id" : 275678516677328896,
  "created_at" : "2012-12-03 19:10:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275677020028018688",
  "text" : "hey guys - this is barack.  ready to answer your questions on fiscal cliff &amp; #my2k.  Let's get started. -bo",
  "id" : 275677020028018688,
  "created_at" : "2012-12-03 19:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275653161765699585",
  "text" : "Good to see lots of folks on twitter speaking out on extending middle class tax cuts. I'll answer some Qs on that at 2ET. Ask w\/ #My2k \u2013bo",
  "id" : 275653161765699585,
  "created_at" : "2012-12-03 17:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/6zW7JVXO",
      "expanded_url" : "http:\/\/on.wh.gov\/9sC0QwG",
      "display_url" : "on.wh.gov\/9sC0QwG"
    } ]
  },
  "geo" : { },
  "id_str" : "275632949959987200",
  "text" : "Over 300,000 Americans have spoken out on extending middle-class tax cuts. What does $2k mean to you? Tell us w\/ #My2k: http:\/\/t.co\/6zW7JVXO",
  "id" : 275632949959987200,
  "created_at" : "2012-12-03 16:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/93g7Qkrn",
      "expanded_url" : "http:\/\/on.wh.gov\/VeYlIGb",
      "display_url" : "on.wh.gov\/VeYlIGb"
    } ]
  },
  "geo" : { },
  "id_str" : "275348475435155456",
  "text" : "Starting at 5:20ET: President Obama speaks at the Kennedy Center Honors Reception from the White House. Watch live: http:\/\/t.co\/93g7Qkrn",
  "id" : 275348475435155456,
  "created_at" : "2012-12-02 21:19:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/275043266116857856\/photo\/1",
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/18FO5tx6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9EmZK9CMAAmf44.jpg",
      "id_str" : "275043266125246464",
      "id" : 275043266125246464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9EmZK9CMAAmf44.jpg",
      "sizes" : [ {
        "h" : 154,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/18FO5tx6"
    } ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/teW6waWz",
      "expanded_url" : "http:\/\/on.wh.gov\/8wAZeHy",
      "display_url" : "on.wh.gov\/8wAZeHy"
    } ]
  },
  "geo" : { },
  "id_str" : "275043266116857856",
  "text" : "Statement from President Obama on #WorldAIDSDay 2012: http:\/\/t.co\/teW6waWz http:\/\/t.co\/18FO5tx6",
  "id" : 275043266116857856,
  "created_at" : "2012-12-02 01:06:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/m9XKuZnl",
      "expanded_url" : "http:\/\/on.wh.gov\/VJ9n8CW",
      "display_url" : "on.wh.gov\/VJ9n8CW"
    } ]
  },
  "geo" : { },
  "id_str" : "275028018144096256",
  "text" : "Watch a time-lapse video: To mark #WorldAIDSDay, a red ribbon is hung from the North Portico of the White House: http:\/\/t.co\/m9XKuZnl",
  "id" : 275028018144096256,
  "created_at" : "2012-12-02 00:06:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/274999871432454144\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/cFaKOYDt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9D-7RKCcAEvB0q.jpg",
      "id_str" : "274999871440842753",
      "id" : 274999871440842753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9D-7RKCcAEvB0q.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cFaKOYDt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274999871432454144",
  "text" : "Today is the 57th Anniversary of the day Rosa Parks refused to give up her seat. Pic: President Obama on Rosa Parks bus http:\/\/t.co\/cFaKOYDt",
  "id" : 274999871432454144,
  "created_at" : "2012-12-01 22:14:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/FLcrUFSz",
      "expanded_url" : "http:\/\/on.wh.gov\/30dliwL",
      "display_url" : "on.wh.gov\/30dliwL"
    } ]
  },
  "geo" : { },
  "id_str" : "274982904487096320",
  "text" : "President Obama: \"It's unacceptable for some Republicans in Congress to hold middle class tax cuts hostage\" Watch http:\/\/t.co\/FLcrUFSz #My2k",
  "id" : 274982904487096320,
  "created_at" : "2012-12-01 21:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/3XtwfHjp",
      "expanded_url" : "http:\/\/on.wh.gov\/i6df4IL",
      "display_url" : "on.wh.gov\/i6df4IL"
    } ]
  },
  "geo" : { },
  "id_str" : "274957548073926656",
  "text" : "\"Make your voice heard. I promise, it makes a difference.\" -President Obama in his Weekly Address on #My2k Watch: http:\/\/t.co\/3XtwfHjp",
  "id" : 274957548073926656,
  "created_at" : "2012-12-01 19:26:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/274941468005785600\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/nALpxoiz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A9DJzvcCYAATNye.jpg",
      "id_str" : "274941468014174208",
      "id" : 274941468014174208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A9DJzvcCYAATNye.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1273,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nALpxoiz"
    } ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/VIgJY0U9",
      "expanded_url" : "http:\/\/on.wh.gov\/WUJ19Xp",
      "display_url" : "on.wh.gov\/WUJ19Xp"
    } ]
  },
  "geo" : { },
  "id_str" : "274941468005785600",
  "text" : "Photo: A red ribbon is displayed on the North Portico of the White House in honor of #WorldAIDSDay http:\/\/t.co\/VIgJY0U9 http:\/\/t.co\/nALpxoiz",
  "id" : 274941468005785600,
  "created_at" : "2012-12-01 18:22:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/r1YGp75g",
      "expanded_url" : "http:\/\/on.wh.gov\/ugyw6zo",
      "display_url" : "on.wh.gov\/ugyw6zo"
    } ]
  },
  "geo" : { },
  "id_str" : "274905493225476096",
  "text" : "\"Let your congressman know what $2,000 means to you....tweet them using #My2k\" -President Obama in his Weekly Address: http:\/\/t.co\/r1YGp75g",
  "id" : 274905493225476096,
  "created_at" : "2012-12-01 15:59:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]