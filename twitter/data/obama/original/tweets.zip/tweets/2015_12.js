Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/682667664284585984\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/yIqhvNljVk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXkpjO9WsAUN9I1.jpg",
      "id_str" : "682622503810936837",
      "id" : 682622503810936837,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXkpjO9WsAUN9I1.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yIqhvNljVk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/bBd1oC3jcA",
      "expanded_url" : "http:\/\/go.wh.gov\/YearInPhotos",
      "display_url" : "go.wh.gov\/YearInPhotos"
    } ]
  },
  "geo" : { },
  "id_str" : "682667664284585984",
  "text" : "As 2015 comes to a close, look back at some of our most memorable photos of the year: https:\/\/t.co\/bBd1oC3jcA https:\/\/t.co\/yIqhvNljVk",
  "id" : 682667664284585984,
  "created_at" : "2015-12-31 21:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Jerry Seinfeld",
      "screen_name" : "JerrySeinfeld",
      "indices" : [ 62, 76 ],
      "id_str" : "336116660",
      "id" : 336116660
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/682653479005851648\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/26ATCi3dNf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXk4F5YWkAAWYAs.jpg",
      "id_str" : "682638492476805120",
      "id" : 682638492476805120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXk4F5YWkAAWYAs.jpg",
      "sizes" : [ {
        "h" : 730,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2852,
        "resize" : "fit",
        "w" : 4000
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/26ATCi3dNf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/7uhkSg47oj",
      "expanded_url" : "http:\/\/go.wh.gov\/ComediansInCars",
      "display_url" : "go.wh.gov\/ComediansInCars"
    } ]
  },
  "geo" : { },
  "id_str" : "682653479005851648",
  "text" : "Watch as @POTUS hops behind the wheel of a 1963 Corvette with @JerrySeinfeld: https:\/\/t.co\/7uhkSg47oj https:\/\/t.co\/26ATCi3dNf",
  "id" : 682653479005851648,
  "created_at" : "2015-12-31 20:04:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Seinfeld",
      "screen_name" : "JerrySeinfeld",
      "indices" : [ 24, 38 ],
      "id_str" : "336116660",
      "id" : 336116660
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/7uhkSg47oj",
      "expanded_url" : "http:\/\/go.wh.gov\/ComediansInCars",
      "display_url" : "go.wh.gov\/ComediansInCars"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/RIJqFqB0f4",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/b3ee66a3-bac9-4b68-8e2b-836993bb95d2",
      "display_url" : "amp.twimg.com\/v\/b3ee66a3-bac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682637856427253760",
  "text" : "\"Shave, then workout?\" \u2014@JerrySeinfeld \n\"That's how I do it\" \u2014@POTUS \n\nWatch the episode: https:\/\/t.co\/7uhkSg47oj https:\/\/t.co\/RIJqFqB0f4",
  "id" : 682637856427253760,
  "created_at" : "2015-12-31 19:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Seinfeld",
      "screen_name" : "JerrySeinfeld",
      "indices" : [ 10, 24 ],
      "id_str" : "336116660",
      "id" : 336116660
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/682632344260325376\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/H8F3X7c9lJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXkwKKVWAAAtYHx.jpg",
      "id_str" : "682629769654042624",
      "id" : 682629769654042624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXkwKKVWAAAtYHx.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/H8F3X7c9lJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/7uhkSg47oj",
      "expanded_url" : "http:\/\/go.wh.gov\/ComediansInCars",
      "display_url" : "go.wh.gov\/ComediansInCars"
    } ]
  },
  "geo" : { },
  "id_str" : "682632344260325376",
  "text" : "That time @JerrySeinfeld stopped by the White House (somewhat unannounced): https:\/\/t.co\/7uhkSg47oj https:\/\/t.co\/H8F3X7c9lJ",
  "id" : 682632344260325376,
  "created_at" : "2015-12-31 18:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/682626058445692928\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/aNUcAWH4ey",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXko6maWkAADGQe.jpg",
      "id_str" : "682621805731942400",
      "id" : 682621805731942400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXko6maWkAADGQe.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aNUcAWH4ey"
    } ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/bBd1oC3jcA",
      "expanded_url" : "http:\/\/go.wh.gov\/YearInPhotos",
      "display_url" : "go.wh.gov\/YearInPhotos"
    } ]
  },
  "geo" : { },
  "id_str" : "682626058445692928",
  "text" : "Check out these must-see behind-the-scenes moments of @POTUS from 2015: https:\/\/t.co\/bBd1oC3jcA #YearInReview https:\/\/t.co\/aNUcAWH4ey",
  "id" : 682626058445692928,
  "created_at" : "2015-12-31 18:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/682617231008649220\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/TkXIizfcpC",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CXkXK0kWMAA5oPo.png",
      "id_str" : "682602293200564224",
      "id" : 682602293200564224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CXkXK0kWMAA5oPo.png",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/TkXIizfcpC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/oPwq0PRSs1",
      "expanded_url" : "http:\/\/go.wh.gov\/2015inGIFs",
      "display_url" : "go.wh.gov\/2015inGIFs"
    } ]
  },
  "geo" : { },
  "id_str" : "682617231008649220",
  "text" : "Can't get enough GIFs? Here's our top 10 favorite GIF moments from 2015: https:\/\/t.co\/oPwq0PRSs1 https:\/\/t.co\/TkXIizfcpC",
  "id" : 682617231008649220,
  "created_at" : "2015-12-31 17:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 22, 29 ],
      "id_str" : "52484614",
      "id" : 52484614
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 45, 51 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/682601610455859200\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/emO49BAkhB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXkWd79WQAEvPI_.jpg",
      "id_str" : "682601522090360833",
      "id" : 682601522090360833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXkWd79WQAEvPI_.jpg",
      "sizes" : [ {
        "h" : 699,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/emO49BAkhB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/GTvXxjcASU",
      "expanded_url" : "http:\/\/go.wh.gov\/2015inLetters",
      "display_url" : "go.wh.gov\/2015inLetters"
    } ]
  },
  "geo" : { },
  "id_str" : "682601610455859200",
  "text" : "Are you following our @Tumblr for letters to @POTUS? See our 10 favorite letters from 2015: https:\/\/t.co\/GTvXxjcASU https:\/\/t.co\/emO49BAkhB",
  "id" : 682601610455859200,
  "created_at" : "2015-12-31 16:38:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Seinfeld",
      "screen_name" : "JerrySeinfeld",
      "indices" : [ 1, 15 ],
      "id_str" : "336116660",
      "id" : 336116660
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/RIJqFqB0f4",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/b3ee66a3-bac9-4b68-8e2b-836993bb95d2",
      "display_url" : "amp.twimg.com\/v\/b3ee66a3-bac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682429745473040384",
  "text" : ".@JerrySeinfeld \u2713\n@POTUS \u2713\n1963 Corvette Stingray \u2713\nAnd a cup of coffee \u2713\n\nHere's what happened next. https:\/\/t.co\/RIJqFqB0f4",
  "id" : 682429745473040384,
  "created_at" : "2015-12-31 05:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Seinfeld",
      "screen_name" : "JerrySeinfeld",
      "indices" : [ 28, 42 ],
      "id_str" : "336116660",
      "id" : 336116660
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/RIJqFqB0f4",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/b3ee66a3-bac9-4b68-8e2b-836993bb95d2",
      "display_url" : "amp.twimg.com\/v\/b3ee66a3-bac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682423451747880960",
  "text" : "Hop in a 1963 Corvette with @JerrySeinfeld &amp; @POTUS in the latest episode of Comedians in Cars Getting Coffee. https:\/\/t.co\/RIJqFqB0f4",
  "id" : 682423451747880960,
  "created_at" : "2015-12-31 04:50:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Seinfeld",
      "screen_name" : "JerrySeinfeld",
      "indices" : [ 24, 38 ],
      "id_str" : "336116660",
      "id" : 336116660
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/RIJqFqB0f4",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/b3ee66a3-bac9-4b68-8e2b-836993bb95d2",
      "display_url" : "amp.twimg.com\/v\/b3ee66a3-bac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682419755341361152",
  "text" : "Go behind the scenes of @JerrySeinfeld's Comedians in Cars Getting Coffee with special guest, @POTUS!\nhttps:\/\/t.co\/RIJqFqB0f4",
  "id" : 682419755341361152,
  "created_at" : "2015-12-31 04:35:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 15, 25 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/fK0Wjw8MAk",
      "expanded_url" : "http:\/\/go.wh.gov\/YearInPhotos",
      "display_url" : "go.wh.gov\/YearInPhotos"
    } ]
  },
  "geo" : { },
  "id_str" : "682335900500496384",
  "text" : "RT @rhodes44: .@petesouza will definitely get a photo credit or two in Ella's wedding slideshow... https:\/\/t.co\/fK0Wjw8MAk https:\/\/t.co\/n1l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "petesouza",
        "screen_name" : "petesouza",
        "indices" : [ 1, 11 ],
        "id_str" : "18215973",
        "id" : 18215973
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rhodes44\/status\/682333728941576192\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/n1lg3Wo0t6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXgi6RwUQAA_UqQ.jpg",
        "id_str" : "682333728140443648",
        "id" : 682333728140443648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXgi6RwUQAA_UqQ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/n1lg3Wo0t6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/fK0Wjw8MAk",
        "expanded_url" : "http:\/\/go.wh.gov\/YearInPhotos",
        "display_url" : "go.wh.gov\/YearInPhotos"
      } ]
    },
    "geo" : { },
    "id_str" : "682333728941576192",
    "text" : ".@petesouza will definitely get a photo credit or two in Ella's wedding slideshow... https:\/\/t.co\/fK0Wjw8MAk https:\/\/t.co\/n1lg3Wo0t6",
    "id" : 682333728941576192,
    "created_at" : "2015-12-30 22:53:32 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 682335900500496384,
  "created_at" : "2015-12-30 23:02:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS Evening News",
      "screen_name" : "CBSEveningNews",
      "indices" : [ 3, 18 ],
      "id_str" : "42958829",
      "id" : 42958829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/QpR6aPVraq",
      "expanded_url" : "http:\/\/cbsn.ws\/1OZZJUd",
      "display_url" : "cbsn.ws\/1OZZJUd"
    } ]
  },
  "geo" : { },
  "id_str" : "682332049563254784",
  "text" : "RT @CBSEveningNews: In Case You Missed It: Aretha Franklin sings tribute to Carole King at Kennedy Center Honors https:\/\/t.co\/QpR6aPVraq\nht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/QpR6aPVraq",
        "expanded_url" : "http:\/\/cbsn.ws\/1OZZJUd",
        "display_url" : "cbsn.ws\/1OZZJUd"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Yv7mH6ZK3V",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/c33325c0-8719-4ca0-9a22-1a4caed256c9",
        "display_url" : "amp.twimg.com\/v\/c33325c0-871\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "682249936021266432",
    "text" : "In Case You Missed It: Aretha Franklin sings tribute to Carole King at Kennedy Center Honors https:\/\/t.co\/QpR6aPVraq\nhttps:\/\/t.co\/Yv7mH6ZK3V",
    "id" : 682249936021266432,
    "created_at" : "2015-12-30 17:20:34 +0000",
    "user" : {
      "name" : "CBS Evening News",
      "screen_name" : "CBSEveningNews",
      "protected" : false,
      "id_str" : "42958829",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580141032781651968\/uuoFtXVP_normal.png",
      "id" : 42958829,
      "verified" : true
    }
  },
  "id" : 682332049563254784,
  "created_at" : "2015-12-30 22:46:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/MbAJlEZd2F",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d6f170fd-d1ee-4e21-a1e1-693386715e8c",
      "display_url" : "amp.twimg.com\/v\/d6f170fd-d1e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682327861496156160",
  "text" : "\"What I'm going to remember is me holding my daughter's hand and walking her to the park.\" \u2014@POTUS on being a parent https:\/\/t.co\/MbAJlEZd2F",
  "id" : 682327861496156160,
  "created_at" : "2015-12-30 22:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 55, 66 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 100, 109 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/n8ZlRrRo3d",
      "expanded_url" : "http:\/\/go.wh.gov\/YearInPhotos",
      "display_url" : "go.wh.gov\/YearInPhotos"
    } ]
  },
  "geo" : { },
  "id_str" : "682325132967280640",
  "text" : "RT @PressSec: Easily the most memorable &amp; powerful @WhiteHouse event of 2015 was the visit from @Pontifex https:\/\/t.co\/n8ZlRrRo3d https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 41, 52 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Pope Francis",
        "screen_name" : "Pontifex",
        "indices" : [ 86, 95 ],
        "id_str" : "500704345",
        "id" : 500704345
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/682313593757560834\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/8KvPRpIsNE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXgQhGnWQAUoG-x.jpg",
        "id_str" : "682313504444006405",
        "id" : 682313504444006405,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXgQhGnWQAUoG-x.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8KvPRpIsNE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/n8ZlRrRo3d",
        "expanded_url" : "http:\/\/go.wh.gov\/YearInPhotos",
        "display_url" : "go.wh.gov\/YearInPhotos"
      } ]
    },
    "geo" : { },
    "id_str" : "682313593757560834",
    "text" : "Easily the most memorable &amp; powerful @WhiteHouse event of 2015 was the visit from @Pontifex https:\/\/t.co\/n8ZlRrRo3d https:\/\/t.co\/8KvPRpIsNE",
    "id" : 682313593757560834,
    "created_at" : "2015-12-30 21:33:32 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 682325132967280640,
  "created_at" : "2015-12-30 22:19:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 10, 20 ],
      "id_str" : "18215973",
      "id" : 18215973
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/682298988402491393\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/qgNixDfG3T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXgDQifWEAUg5Nn.jpg",
      "id_str" : "682298926217695237",
      "id" : 682298926217695237,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXgDQifWEAUg5Nn.jpg",
      "sizes" : [ {
        "h" : 1332,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qgNixDfG3T"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/bBd1oCkUBa",
      "expanded_url" : "http:\/\/go.wh.gov\/YearInPhotos",
      "display_url" : "go.wh.gov\/YearInPhotos"
    } ]
  },
  "geo" : { },
  "id_str" : "682298988402491393",
  "text" : "Check out @PeteSouza's 2015 year in photos\u2014including some gems of @POTUS with babies: https:\/\/t.co\/bBd1oCkUBa https:\/\/t.co\/qgNixDfG3T",
  "id" : 682298988402491393,
  "created_at" : "2015-12-30 20:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/682290051431182336\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/x363MxmyOT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXf7IY0UAAAI81F.jpg",
      "id_str" : "682289990089310208",
      "id" : 682289990089310208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXf7IY0UAAAI81F.jpg",
      "sizes" : [ {
        "h" : 702,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 702,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/x363MxmyOT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/z11al4LUeZ",
      "expanded_url" : "http:\/\/go.wh.gov\/YearInPhotos",
      "display_url" : "go.wh.gov\/YearInPhotos"
    } ]
  },
  "geo" : { },
  "id_str" : "682290611173462017",
  "text" : "RT @petesouza: Check out my 2015 Year in Photos: https:\/\/t.co\/z11al4LUeZ https:\/\/t.co\/x363MxmyOT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/682290051431182336\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/x363MxmyOT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXf7IY0UAAAI81F.jpg",
        "id_str" : "682289990089310208",
        "id" : 682289990089310208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXf7IY0UAAAI81F.jpg",
        "sizes" : [ {
          "h" : 702,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 702,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/x363MxmyOT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 57 ],
        "url" : "https:\/\/t.co\/z11al4LUeZ",
        "expanded_url" : "http:\/\/go.wh.gov\/YearInPhotos",
        "display_url" : "go.wh.gov\/YearInPhotos"
      } ]
    },
    "geo" : { },
    "id_str" : "682290051431182336",
    "text" : "Check out my 2015 Year in Photos: https:\/\/t.co\/z11al4LUeZ https:\/\/t.co\/x363MxmyOT",
    "id" : 682290051431182336,
    "created_at" : "2015-12-30 19:59:59 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 682290611173462017,
  "created_at" : "2015-12-30 20:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/MbAJlEZd2F",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d6f170fd-d1ee-4e21-a1e1-693386715e8c",
      "display_url" : "amp.twimg.com\/v\/d6f170fd-d1e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682286327069462536",
  "text" : "\"It is the great joy of my life, and Michelle's life: Our daughters.\" \u2014@POTUS on family and parenting https:\/\/t.co\/MbAJlEZd2F",
  "id" : 682286327069462536,
  "created_at" : "2015-12-30 19:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/MbAJlEZd2F",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d6f170fd-d1ee-4e21-a1e1-693386715e8c",
      "display_url" : "amp.twimg.com\/v\/d6f170fd-d1e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682278775967514628",
  "text" : "Life lessons from @POTUS on being a parent. https:\/\/t.co\/MbAJlEZd2F",
  "id" : 682278775967514628,
  "created_at" : "2015-12-30 19:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/MbAJlEZd2F",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d6f170fd-d1ee-4e21-a1e1-693386715e8c",
      "display_url" : "amp.twimg.com\/v\/d6f170fd-d1e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682269236849278978",
  "text" : "Watch as @POTUS answers questions from White House interns\u2014including one on family and parenting.\nhttps:\/\/t.co\/MbAJlEZd2F",
  "id" : 682269236849278978,
  "created_at" : "2015-12-30 18:37:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/682262267371520001\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/8mMqqsGbpD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXfhxcXUEAEXEmY.png",
      "id_str" : "682262108113735681",
      "id" : 682262108113735681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXfhxcXUEAEXEmY.png",
      "sizes" : [ {
        "h" : 677,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 677,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 677,
        "resize" : "fit",
        "w" : 476
      } ],
      "display_url" : "pic.twitter.com\/8mMqqsGbpD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/gQszVDAsWT",
      "expanded_url" : "http:\/\/go.wh.gov\/2015inTweets",
      "display_url" : "go.wh.gov\/2015inTweets"
    } ]
  },
  "geo" : { },
  "id_str" : "682262267371520001",
  "text" : "RT if you agree: Community college should be free for anyone willing to work for it \u2192 https:\/\/t.co\/gQszVDAsWT https:\/\/t.co\/8mMqqsGbpD",
  "id" : 682262267371520001,
  "created_at" : "2015-12-30 18:09:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 20, 35 ]
    }, {
      "text" : "ParisAgreement",
      "indices" : [ 38, 53 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/U6SbNR0sZT",
      "expanded_url" : "http:\/\/go.wh.gov\/2015inTweets",
      "display_url" : "go.wh.gov\/2015inTweets"
    } ]
  },
  "geo" : { },
  "id_str" : "682252114374991872",
  "text" : "RT @FactsOnClimate: #CleanPowerPlan \u2713\n#ParisAgreement \u2713\nWe took our biggest steps yet to #ActOnClimate in 2015: https:\/\/t.co\/U6SbNR0sZT htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 0, 15 ]
      }, {
        "text" : "ParisAgreement",
        "indices" : [ 18, 33 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 69, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/U6SbNR0sZT",
        "expanded_url" : "http:\/\/go.wh.gov\/2015inTweets",
        "display_url" : "go.wh.gov\/2015inTweets"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/Gv5lYFKAOQ",
        "expanded_url" : "http:\/\/snpy.tv\/1STbXjG",
        "display_url" : "snpy.tv\/1STbXjG"
      } ]
    },
    "geo" : { },
    "id_str" : "682250203554959361",
    "text" : "#CleanPowerPlan \u2713\n#ParisAgreement \u2713\nWe took our biggest steps yet to #ActOnClimate in 2015: https:\/\/t.co\/U6SbNR0sZT https:\/\/t.co\/Gv5lYFKAOQ",
    "id" : 682250203554959361,
    "created_at" : "2015-12-30 17:21:38 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 682252114374991872,
  "created_at" : "2015-12-30 17:29:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/682248051910508544\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/pNUOy5m2u1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXfUz7RWYAA8opT.png",
      "id_str" : "682247857118797824",
      "id" : 682247857118797824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXfUz7RWYAA8opT.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 157,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 293,
        "resize" : "fit",
        "w" : 635
      } ],
      "display_url" : "pic.twitter.com\/pNUOy5m2u1"
    } ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/gQszVDAsWT",
      "expanded_url" : "http:\/\/go.wh.gov\/2015inTweets",
      "display_url" : "go.wh.gov\/2015inTweets"
    } ]
  },
  "geo" : { },
  "id_str" : "682248051910508544",
  "text" : "\"Gay and lesbian couples now have the right to marry, just like anyone else.\" https:\/\/t.co\/gQszVDAsWT #YearInReview https:\/\/t.co\/pNUOy5m2u1",
  "id" : 682248051910508544,
  "created_at" : "2015-12-30 17:13:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/682229758793363457\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/j6VNq2EFvA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXfENsZUkAQdSfQ.png",
      "id_str" : "682229608104628228",
      "id" : 682229608104628228,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXfENsZUkAQdSfQ.png",
      "sizes" : [ {
        "h" : 670,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/j6VNq2EFvA"
    } ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/gQszVDAsWT",
      "expanded_url" : "http:\/\/go.wh.gov\/2015inTweets",
      "display_url" : "go.wh.gov\/2015inTweets"
    } ]
  },
  "geo" : { },
  "id_str" : "682229758793363457",
  "text" : "Take a look back at some of the top White House tweets of 2015 \u2192 https:\/\/t.co\/gQszVDAsWT #YearInReview https:\/\/t.co\/j6VNq2EFvA",
  "id" : 682229758793363457,
  "created_at" : "2015-12-30 16:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esperanza Spalding",
      "screen_name" : "EspeSpalding",
      "indices" : [ 61, 74 ],
      "id_str" : "143754070",
      "id" : 143754070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/IhLy4VFPYy",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/3e3a5554-859d-48e2-a8b2-c7c88a822542",
      "display_url" : "amp.twimg.com\/v\/3e3a5554-859\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682038425248071680",
  "text" : "\"Creativity is the power to create something from nothing.\" \u2014@EspeSpalding https:\/\/t.co\/IhLy4VFPYy",
  "id" : 682038425248071680,
  "created_at" : "2015-12-30 03:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 75, 82 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 96, 100 ],
      "id_str" : "12133382",
      "id" : 12133382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/IhLy4VFPYy",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/3e3a5554-859d-48e2-a8b2-c7c88a822542",
      "display_url" : "amp.twimg.com\/v\/3e3a5554-859\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682028345840685058",
  "text" : "Celebrate American creativity in the arts and humanities with @POTUS &amp; @FLOTUS January 8 on @PBS.  https:\/\/t.co\/IhLy4VFPYy",
  "id" : 682028345840685058,
  "created_at" : "2015-12-30 02:40:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/682020794621296643\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/0suzickXSi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXb-S1rUAAAOvnY.jpg",
      "id_str" : "682011993193054208",
      "id" : 682011993193054208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXb-S1rUAAAOvnY.jpg",
      "sizes" : [ {
        "h" : 695,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0suzickXSi"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9zegvTI0jV",
      "expanded_url" : "http:\/\/go.wh.gov\/2015InReview",
      "display_url" : "go.wh.gov\/2015InReview"
    } ]
  },
  "geo" : { },
  "id_str" : "682020794621296643",
  "text" : "2015 was a busy year. Here's some of the important progress we made together: https:\/\/t.co\/9zegvTI0jV #LoveWins https:\/\/t.co\/0suzickXSi",
  "id" : 682020794621296643,
  "created_at" : "2015-12-30 02:10:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esperanza Spalding",
      "screen_name" : "EspeSpalding",
      "indices" : [ 18, 31 ],
      "id_str" : "143754070",
      "id" : 143754070
    }, {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 107, 111 ],
      "id_str" : "12133382",
      "id" : 12133382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/IhLy4VFPYy",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/3e3a5554-859d-48e2-a8b2-c7c88a822542",
      "display_url" : "amp.twimg.com\/v\/3e3a5554-859\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "682012679041486848",
  "text" : "Go backstage with @EspeSpalding ahead of the White House's Celebration of American Creativity January 8 on @PBS.\nhttps:\/\/t.co\/IhLy4VFPYy",
  "id" : 682012679041486848,
  "created_at" : "2015-12-30 01:37:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 50, 60 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/681975512764317696\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/YEm9hI0pqV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXbYgn9W8AMnLpj.jpg",
      "id_str" : "681970448586960899",
      "id" : 681970448586960899,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXbYgn9W8AMnLpj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/YEm9hI0pqV"
    } ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/6vRVgrfbD2",
      "expanded_url" : "http:\/\/go.wh.gov\/2015onInsta",
      "display_url" : "go.wh.gov\/2015onInsta"
    } ]
  },
  "geo" : { },
  "id_str" : "681975512764317696",
  "text" : "Take a look back at the 12 major moments from our @Instagram account in 2015: https:\/\/t.co\/6vRVgrfbD2 #YearInReview https:\/\/t.co\/YEm9hI0pqV",
  "id" : 681975512764317696,
  "created_at" : "2015-12-29 23:10:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 81, 90 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/681946212048760832\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fNWGERmW1e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXbCHLGWQAAb6sv.jpg",
      "id_str" : "681945822087495680",
      "id" : 681945822087495680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXbCHLGWQAAb6sv.jpg",
      "sizes" : [ {
        "h" : 1620,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fNWGERmW1e"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/KIacq67aqj",
      "expanded_url" : "http:\/\/go.wh.gov\/2015onFB",
      "display_url" : "go.wh.gov\/2015onFB"
    } ]
  },
  "geo" : { },
  "id_str" : "681946212048760832",
  "text" : "2015 is coming to a close and that means we're taking a look back at the year on @Facebook: https:\/\/t.co\/KIacq67aqj https:\/\/t.co\/fNWGERmW1e",
  "id" : 681946212048760832,
  "created_at" : "2015-12-29 21:13:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681899323395862528",
  "text" : "RT @TheIranDeal: Here are the steps that Iran has already taken under the #IranDeal to ensure it cannot obtain a nuclear weapon. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/681894969611685888\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/C684ECn704",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXaS83kUkAA5Evk.jpg",
        "id_str" : "681893967999307776",
        "id" : 681893967999307776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXaS83kUkAA5Evk.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/C684ECn704"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 57, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681894969611685888",
    "text" : "Here are the steps that Iran has already taken under the #IranDeal to ensure it cannot obtain a nuclear weapon. https:\/\/t.co\/C684ECn704",
    "id" : 681894969611685888,
    "created_at" : "2015-12-29 17:50:04 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 681899323395862528,
  "created_at" : "2015-12-29 18:07:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/vrjRtOWe7a",
      "expanded_url" : "http:\/\/go.wh.gov\/PX5dvx",
      "display_url" : "go.wh.gov\/PX5dvx"
    } ]
  },
  "geo" : { },
  "id_str" : "681893811186962432",
  "text" : "RT @rhodes44: Thanks to the #IranDeal, Iran no longer has enough enriched uranium for a nuclear weapon \u2192 https:\/\/t.co\/vrjRtOWe7a https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rhodes44\/status\/681893689531174912\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/SHTDmSL7dE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXaSaZWUMAAXqX_.jpg",
        "id_str" : "681893375771947008",
        "id" : 681893375771947008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXaSaZWUMAAXqX_.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SHTDmSL7dE"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 14, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/vrjRtOWe7a",
        "expanded_url" : "http:\/\/go.wh.gov\/PX5dvx",
        "display_url" : "go.wh.gov\/PX5dvx"
      } ]
    },
    "geo" : { },
    "id_str" : "681893689531174912",
    "text" : "Thanks to the #IranDeal, Iran no longer has enough enriched uranium for a nuclear weapon \u2192 https:\/\/t.co\/vrjRtOWe7a https:\/\/t.co\/SHTDmSL7dE",
    "id" : 681893689531174912,
    "created_at" : "2015-12-29 17:44:59 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 681893811186962432,
  "created_at" : "2015-12-29 17:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 72, 82 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/681621913316110336\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/wsLv8f3iZH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVXBmeUwAA3nae.jpg",
      "id_str" : "681546603635720192",
      "id" : 681546603635720192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVXBmeUwAA3nae.jpg",
      "sizes" : [ {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 1332
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wsLv8f3iZH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/qNLETToEa6",
      "expanded_url" : "http:\/\/go.wh.gov\/BehindTheLens",
      "display_url" : "go.wh.gov\/BehindTheLens"
    } ]
  },
  "geo" : { },
  "id_str" : "681621913316110336",
  "text" : "From Air Force One to Bo and Sunny close-ups, go behind the scenes with @PeteSouza: https:\/\/t.co\/qNLETToEa6 https:\/\/t.co\/wsLv8f3iZH",
  "id" : 681621913316110336,
  "created_at" : "2015-12-28 23:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681612663571480576",
  "text" : "RT @WhiteHouseCEQ: .@POTUS just signed a bipartisan bill to ban microbeads in cosmetics \u2192 a big step to protect our nation's waterways! htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/qEIQO1XFjo",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/12\/28\/statement-press-secretary-hr-1321-s-2425",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "681595563616280576",
    "text" : ".@POTUS just signed a bipartisan bill to ban microbeads in cosmetics \u2192 a big step to protect our nation's waterways! https:\/\/t.co\/qEIQO1XFjo",
    "id" : 681595563616280576,
    "created_at" : "2015-12-28 22:00:20 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 681612663571480576,
  "created_at" : "2015-12-28 23:08:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681609064007254016",
  "text" : "RT @VP: Congratulations to Prime Minister Abe and President Park on today's historic agreement. Our shared future will be better because of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "681592724252946432",
    "text" : "Congratulations to Prime Minister Abe and President Park on today's historic agreement. Our shared future will be better because of it.",
    "id" : 681592724252946432,
    "created_at" : "2015-12-28 21:49:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 681609064007254016,
  "created_at" : "2015-12-28 22:53:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 28, 38 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/681580457184501760\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/hnOi3eyRaX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVWW-2UEAABKHJ.jpg",
      "id_str" : "681545871444414464",
      "id" : 681545871444414464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVWW-2UEAABKHJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 1332
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hnOi3eyRaX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/qNLETToEa6",
      "expanded_url" : "http:\/\/go.wh.gov\/BehindTheLens",
      "display_url" : "go.wh.gov\/BehindTheLens"
    } ]
  },
  "geo" : { },
  "id_str" : "681580457184501760",
  "text" : "Chief Official Photographer @PeteSouza takes a look back through his Year on Instagram: https:\/\/t.co\/qNLETToEa6 https:\/\/t.co\/hnOi3eyRaX",
  "id" : 681580457184501760,
  "created_at" : "2015-12-28 21:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 1, 10 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "CanadianPM",
      "screen_name" : "CanadianPM",
      "indices" : [ 36, 47 ],
      "id_str" : "14713787",
      "id" : 14713787
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/681572629963214848\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/OKriGFUcNk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVuhYkWYAEpSxX.jpg",
      "id_str" : "681572438426148865",
      "id" : 681572438426148865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVuhYkWYAEpSxX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OKriGFUcNk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "681572629963214848",
  "text" : ".@PressSec on the Official Visit of @CanadianPM Justin Trudeau to the White House: https:\/\/t.co\/OKriGFUcNk",
  "id" : 681572629963214848,
  "created_at" : "2015-12-28 20:29:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 26, 36 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/681545412591939584\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/j1drlKkIlA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXVVxLaWMAEZ49E.jpg",
      "id_str" : "681545221981745153",
      "id" : 681545221981745153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXVVxLaWMAEZ49E.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1332,
        "resize" : "fit",
        "w" : 1332
      } ],
      "display_url" : "pic.twitter.com\/j1drlKkIlA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/qNLETT73iy",
      "expanded_url" : "http:\/\/go.wh.gov\/BehindTheLens",
      "display_url" : "go.wh.gov\/BehindTheLens"
    } ]
  },
  "geo" : { },
  "id_str" : "681545412591939584",
  "text" : "Go behind the scenes with @PeteSouza's 2015 Year on Instagram: https:\/\/t.co\/qNLETT73iy https:\/\/t.co\/j1drlKkIlA",
  "id" : 681545412591939584,
  "created_at" : "2015-12-28 18:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/680861045569753089\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/g3FnFBfXoc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXLnYrhWMAAzJ88.jpg",
      "id_str" : "680860904871833600",
      "id" : 680860904871833600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXLnYrhWMAAzJ88.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g3FnFBfXoc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680861045569753089",
  "text" : "\"Michelle and I extend our warmest wishes to families across the country celebrating Kwanzaa\" \u2014@POTUS: https:\/\/t.co\/g3FnFBfXoc",
  "id" : 680861045569753089,
  "created_at" : "2015-12-26 21:21:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/MHKBl4iVnA",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d3fae924-f465-45ba-b30e-e3f2b0aa8446",
      "display_url" : "amp.twimg.com\/v\/d3fae924-f46\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680478214314053632",
  "text" : "\"On behalf of Malia, Sasha, Bo, Sunny, Grandma and everyone here at the White House, Merry Christmas!\"  \u2014@POTUS https:\/\/t.co\/MHKBl4iVnA",
  "id" : 680478214314053632,
  "created_at" : "2015-12-25 20:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680467653841010688",
  "text" : "RT @VP: Happy holidays, from our family to yours. May they be full of warmth, laughter, and those you love -- no matter how near or far.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680464228378132480",
    "text" : "Happy holidays, from our family to yours. May they be full of warmth, laughter, and those you love -- no matter how near or far.",
    "id" : 680464228378132480,
    "created_at" : "2015-12-25 19:04:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 680467653841010688,
  "created_at" : "2015-12-25 19:18:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/680434810721038336\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/NCAfV2TbJW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXFj2DbWYAAlNHY.jpg",
      "id_str" : "680434798993760256",
      "id" : 680434798993760256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXFj2DbWYAAlNHY.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 751,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/NCAfV2TbJW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680466990264414208",
  "text" : "RT @FLOTUS: Wishing you and all your loved ones a very Merry Christmas! https:\/\/t.co\/NCAfV2TbJW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/680434810721038336\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/NCAfV2TbJW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXFj2DbWYAAlNHY.jpg",
        "id_str" : "680434798993760256",
        "id" : 680434798993760256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXFj2DbWYAAlNHY.jpg",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 751,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 639
        } ],
        "display_url" : "pic.twitter.com\/NCAfV2TbJW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680434810721038336",
    "text" : "Wishing you and all your loved ones a very Merry Christmas! https:\/\/t.co\/NCAfV2TbJW",
    "id" : 680434810721038336,
    "created_at" : "2015-12-25 17:07:55 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 680466990264414208,
  "created_at" : "2015-12-25 19:15:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680466612730904576",
  "text" : "RT @POTUS: From the Obama family to yours, Merry Christmas! And a special thank you to all our men and women in uniform this holiday season.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680464195993911296",
    "text" : "From the Obama family to yours, Merry Christmas! And a special thank you to all our men and women in uniform this holiday season.",
    "id" : 680464195993911296,
    "created_at" : "2015-12-25 19:04:41 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 680466612730904576,
  "created_at" : "2015-12-25 19:14:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 55, 62 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/MHKBl41kw2",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d3fae924-f465-45ba-b30e-e3f2b0aa8446",
      "display_url" : "amp.twimg.com\/v\/d3fae924-f46\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680446549181206529",
  "text" : "Wishing you all a very Merry Christmas from @POTUS and @FLOTUS! \uD83C\uDF84\uD83C\uDF81 https:\/\/t.co\/MHKBl41kw2",
  "id" : 680446549181206529,
  "created_at" : "2015-12-25 17:54:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/680432930066333697\/photo\/1",
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/ReJlVBacmg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXFFTGwWcAAZpnu.jpg",
      "id_str" : "680401213242896384",
      "id" : 680401213242896384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXFFTGwWcAAZpnu.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ReJlVBacmg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680432930066333697",
  "text" : "Merry Christmas! https:\/\/t.co\/ReJlVBacmg",
  "id" : 680432930066333697,
  "created_at" : "2015-12-25 17:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/MHKBl4iVnA",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d3fae924-f465-45ba-b30e-e3f2b0aa8446",
      "display_url" : "amp.twimg.com\/v\/d3fae924-f46\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680403984595587072",
  "text" : "\"Merry Christmas, everybody!\" \u2014@POTUS\nhttps:\/\/t.co\/MHKBl4iVnA",
  "id" : 680403984595587072,
  "created_at" : "2015-12-25 15:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/680213914617909248\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/FHGmJdxqED",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXCATvbWYAU-0ni.jpg",
      "id_str" : "680184620369993733",
      "id" : 680184620369993733,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXCATvbWYAU-0ni.jpg",
      "sizes" : [ {
        "h" : 599,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1023,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1079,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/FHGmJdxqED"
    } ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680213914617909248",
  "text" : "While visions of milk bones and tennis balls danced in their heads\u2026 #WHHolidays https:\/\/t.co\/FHGmJdxqED",
  "id" : 680213914617909248,
  "created_at" : "2015-12-25 02:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/680191298561638401\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/jYnjotd5JK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXCADegWkAAUuUS.jpg",
      "id_str" : "680184340949667840",
      "id" : 680184340949667840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXCADegWkAAUuUS.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/jYnjotd5JK"
    } ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680191298561638401",
  "text" : "Dreaming of a white Christmas.\u2744 #WHHolidays https:\/\/t.co\/jYnjotd5JK",
  "id" : 680191298561638401,
  "created_at" : "2015-12-25 01:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/680161148084158464\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/p7ycCL3Eat",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXBY4xYUwAAFhv9.jpg",
      "id_str" : "680141276084224000",
      "id" : 680141276084224000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXBY4xYUwAAFhv9.jpg",
      "sizes" : [ {
        "h" : 378,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1138,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/p7ycCL3Eat"
    } ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680161148084158464",
  "text" : "\u2744Let it snow, let it snow, let it snow!\u2744 #WHHolidays https:\/\/t.co\/p7ycCL3Eat",
  "id" : 680161148084158464,
  "created_at" : "2015-12-24 23:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/680135682589855745\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/lxWaNEMhbz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXBTuybWkAAW3OJ.jpg",
      "id_str" : "680135607008530432",
      "id" : 680135607008530432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXBTuybWkAAW3OJ.jpg",
      "sizes" : [ {
        "h" : 719,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lxWaNEMhbz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680135682589855745",
  "text" : "\"A lot of love goes into this 500 pound gingerbread house!\" \u2014Susie Morrison, head pastry chef at the White House https:\/\/t.co\/lxWaNEMhbz",
  "id" : 680135682589855745,
  "created_at" : "2015-12-24 21:19:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "BeringLandBridgeNP",
      "screen_name" : "BeringLandNPS",
      "indices" : [ 71, 85 ],
      "id_str" : "65670121",
      "id" : 65670121
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/680061143864356864\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/vn3zFVN7Om",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CXAQASgUwAAubI8.jpg",
      "id_str" : "680061140886405120",
      "id" : 680061140886405120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXAQASgUwAAubI8.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 599
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 599
      } ],
      "display_url" : "pic.twitter.com\/vn3zFVN7Om"
    } ],
    "hashtags" : [ {
      "text" : "Alaska",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "680125593023844354",
  "text" : "RT @Interior: Looks like this reindeer is getting ready for tonight! \uD83C\uDF85 @BeringLandNPS #Alaska https:\/\/t.co\/vn3zFVN7Om",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BeringLandBridgeNP",
        "screen_name" : "BeringLandNPS",
        "indices" : [ 57, 71 ],
        "id_str" : "65670121",
        "id" : 65670121
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/680061143864356864\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/vn3zFVN7Om",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CXAQASgUwAAubI8.jpg",
        "id_str" : "680061140886405120",
        "id" : 680061140886405120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CXAQASgUwAAubI8.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/vn3zFVN7Om"
      } ],
      "hashtags" : [ {
        "text" : "Alaska",
        "indices" : [ 72, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "680061143864356864",
    "text" : "Looks like this reindeer is getting ready for tonight! \uD83C\uDF85 @BeringLandNPS #Alaska https:\/\/t.co\/vn3zFVN7Om",
    "id" : 680061143864356864,
    "created_at" : "2015-12-24 16:23:06 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 680125593023844354,
  "created_at" : "2015-12-24 20:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boyz II Men",
      "screen_name" : "BoyzIIMen",
      "indices" : [ 5, 15 ],
      "id_str" : "44204341",
      "id" : 44204341
    }, {
      "name" : "Mariah Carey",
      "screen_name" : "MariahCarey",
      "indices" : [ 19, 31 ],
      "id_str" : "19248106",
      "id" : 19248106
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 56, 63 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 86, 94 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/679762353316061185\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/Dj9WGgufGF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW8ABSoW8AEV4Qc.jpg",
      "id_str" : "679762090937217025",
      "id" : 679762090937217025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW8ABSoW8AEV4Qc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 833
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 833
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Dj9WGgufGF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/tQcHwsZVHL",
      "expanded_url" : "http:\/\/go.wh.gov\/ObamaHoliday",
      "display_url" : "go.wh.gov\/ObamaHoliday"
    } ]
  },
  "geo" : { },
  "id_str" : "680097589388292096",
  "text" : "From @BoyzIIMen to @MariahCarey, check out @POTUS &amp; @FLOTUS's holiday playlist on @Spotify: https:\/\/t.co\/tQcHwsZVHL https:\/\/t.co\/Dj9WGgufGF",
  "id" : 680097589388292096,
  "created_at" : "2015-12-24 18:47:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "xoxo, Joanne",
      "screen_name" : "ladygaga",
      "indices" : [ 66, 75 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/Cx2iHuCxi4",
      "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/679768730663006208",
      "display_url" : "twitter.com\/DrBiden\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "680082201598423041",
  "text" : "RT @VP: Alright, the Celtic carol is mine. And a few others. (cc: @LadyGaga) https:\/\/t.co\/Cx2iHuCxi4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "xoxo, Joanne",
        "screen_name" : "ladygaga",
        "indices" : [ 58, 67 ],
        "id_str" : "14230524",
        "id" : 14230524
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/Cx2iHuCxi4",
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/679768730663006208",
        "display_url" : "twitter.com\/DrBiden\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679772842569891840",
    "text" : "Alright, the Celtic carol is mine. And a few others. (cc: @LadyGaga) https:\/\/t.co\/Cx2iHuCxi4",
    "id" : 679772842569891840,
    "created_at" : "2015-12-23 21:17:29 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 680082201598423041,
  "created_at" : "2015-12-24 17:46:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 14, 17 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 39, 47 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Y2gQpmIu0M",
      "expanded_url" : "http:\/\/go.wh.gov\/BidenHoliday",
      "display_url" : "go.wh.gov\/BidenHoliday"
    } ]
  },
  "geo" : { },
  "id_str" : "679796034080477184",
  "text" : "RT @DrBiden: .@VP and I put together a @Spotify holiday playlist: https:\/\/t.co\/Y2gQpmIu0M Can you guess whose songs are whose? (Cc: @spring\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 1, 4 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "Spotify",
        "screen_name" : "Spotify",
        "indices" : [ 26, 34 ],
        "id_str" : "17230018",
        "id" : 17230018
      }, {
        "name" : "Bruce Springsteen",
        "screen_name" : "springsteen",
        "indices" : [ 119, 131 ],
        "id_str" : "43383705",
        "id" : 43383705
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/Y2gQpmIu0M",
        "expanded_url" : "http:\/\/go.wh.gov\/BidenHoliday",
        "display_url" : "go.wh.gov\/BidenHoliday"
      } ]
    },
    "geo" : { },
    "id_str" : "679768730663006208",
    "text" : ".@VP and I put together a @Spotify holiday playlist: https:\/\/t.co\/Y2gQpmIu0M Can you guess whose songs are whose? (Cc: @springsteen) \u2014Jill",
    "id" : 679768730663006208,
    "created_at" : "2015-12-23 21:01:09 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 679796034080477184,
  "created_at" : "2015-12-23 22:49:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/679785915871444992\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/2WTQHbsLxF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW8VsClUsAAR-c8.jpg",
      "id_str" : "679785915108077568",
      "id" : 679785915108077568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW8VsClUsAAR-c8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2WTQHbsLxF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/hOdAWPXZCc",
      "expanded_url" : "http:\/\/go.wh.gov\/KoBKv2",
      "display_url" : "go.wh.gov\/KoBKv2"
    } ]
  },
  "geo" : { },
  "id_str" : "679785915871444992",
  "text" : ".@POTUS on persecuted Christians at Christmas. https:\/\/t.co\/hOdAWPXZCc https:\/\/t.co\/2WTQHbsLxF",
  "id" : 679785915871444992,
  "created_at" : "2015-12-23 22:09:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 28, 32 ],
      "id_str" : "19923144",
      "id" : 19923144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679774668128186370",
  "text" : "RT @POTUS: I'm proud of the @NBA for taking a stand against gun violence. Sympathy for victims isn't enough \u2013 change requires all of us spe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NBA",
        "screen_name" : "NBA",
        "indices" : [ 17, 21 ],
        "id_str" : "19923144",
        "id" : 19923144
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679773729749078016",
    "text" : "I'm proud of the @NBA for taking a stand against gun violence. Sympathy for victims isn't enough \u2013 change requires all of us speaking up.",
    "id" : 679773729749078016,
    "created_at" : "2015-12-23 21:21:01 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 679774668128186370,
  "created_at" : "2015-12-23 21:24:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 12, 19 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 66, 74 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/679762353316061185\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Dj9WGgufGF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW8ABSoW8AEV4Qc.jpg",
      "id_str" : "679762090937217025",
      "id" : 679762090937217025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW8ABSoW8AEV4Qc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 833
      }, {
        "h" : 584,
        "resize" : "fit",
        "w" : 833
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Dj9WGgufGF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/tQcHwsZVHL",
      "expanded_url" : "http:\/\/go.wh.gov\/ObamaHoliday",
      "display_url" : "go.wh.gov\/ObamaHoliday"
    } ]
  },
  "geo" : { },
  "id_str" : "679762353316061185",
  "text" : ".@POTUS and @FLOTUS just released their favorite holiday tunes on @Spotify.\nListen now: https:\/\/t.co\/tQcHwsZVHL https:\/\/t.co\/Dj9WGgufGF",
  "id" : 679762353316061185,
  "created_at" : "2015-12-23 20:35:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679732968886288384",
  "text" : "RT @whitehouseostp: Cleaner air.\nCleaner water.\nA sustainable planet.\n\"What could be more important than that?\"\n#ParisAgreement https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 92, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/uauzT2hvi7",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/8e5e2209-a35d-4cb7-9d03-6fa822b2633e",
        "display_url" : "amp.twimg.com\/v\/8e5e2209-a35\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679726306297286657",
    "text" : "Cleaner air.\nCleaner water.\nA sustainable planet.\n\"What could be more important than that?\"\n#ParisAgreement https:\/\/t.co\/uauzT2hvi7",
    "id" : 679726306297286657,
    "created_at" : "2015-12-23 18:12:34 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 679732968886288384,
  "created_at" : "2015-12-23 18:39:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 45, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ae6aW85cto",
      "expanded_url" : "http:\/\/go.wh.gov\/EnviroRecord",
      "display_url" : "go.wh.gov\/EnviroRecord"
    } ]
  },
  "geo" : { },
  "id_str" : "679726155235241990",
  "text" : "RT @FactsOnClimate: .@POTUS has done more to #ActOnClimate than any other president. Check out his record \u2192 https:\/\/t.co\/ae6aW85cto https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FactsOnClimate\/status\/679725447308029952\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/gFschMVrRu",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CW7eaItWMAAQAG8.png",
        "id_str" : "679725134375170048",
        "id" : 679725134375170048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CW7eaItWMAAQAG8.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gFschMVrRu"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 25, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/ae6aW85cto",
        "expanded_url" : "http:\/\/go.wh.gov\/EnviroRecord",
        "display_url" : "go.wh.gov\/EnviroRecord"
      } ]
    },
    "geo" : { },
    "id_str" : "679725447308029952",
    "text" : ".@POTUS has done more to #ActOnClimate than any other president. Check out his record \u2192 https:\/\/t.co\/ae6aW85cto https:\/\/t.co\/gFschMVrRu",
    "id" : 679725447308029952,
    "created_at" : "2015-12-23 18:09:09 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 679726155235241990,
  "created_at" : "2015-12-23 18:11:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 33, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/CeKOgwPJxP",
      "expanded_url" : "http:\/\/go.wh.gov\/w8p8mS",
      "display_url" : "go.wh.gov\/w8p8mS"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/7sH5Fyk9R7",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/8e5e2209-a35d-4cb7-9d03-6fa822b2633e",
      "display_url" : "amp.twimg.com\/v\/8e5e2209-a35\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679706693941346304",
  "text" : "Watch the world come together to #ActOnClimate and protect the one planet we've got \u2192 https:\/\/t.co\/CeKOgwPJxP\nhttps:\/\/t.co\/7sH5Fyk9R7",
  "id" : 679706693941346304,
  "created_at" : "2015-12-23 16:54:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/679466530518614016\/photo\/1",
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/TnqBnuALY3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3wYnmWAAEJ2BA.jpg",
      "id_str" : "679463424540147713",
      "id" : 679463424540147713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3wYnmWAAEJ2BA.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TnqBnuALY3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/qNLETToEa6",
      "expanded_url" : "http:\/\/go.wh.gov\/BehindTheLens",
      "display_url" : "go.wh.gov\/BehindTheLens"
    } ]
  },
  "geo" : { },
  "id_str" : "679466530518614016",
  "text" : "\uD83C\uDFB6 Let it Bo! \u2744 https:\/\/t.co\/qNLETToEa6 https:\/\/t.co\/TnqBnuALY3",
  "id" : 679466530518614016,
  "created_at" : "2015-12-23 01:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Bill de Blasio",
      "screen_name" : "BilldeBlasio",
      "indices" : [ 19, 32 ],
      "id_str" : "476193064",
      "id" : 476193064
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679453567145529344",
  "text" : "RT @vj44: Congrats @BilldeBlasio on leading the way &amp; expanding paid leave for NYC employees\nTime for Congress to #LeadOnLeave https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill de Blasio",
        "screen_name" : "BilldeBlasio",
        "indices" : [ 9, 22 ],
        "id_str" : "476193064",
        "id" : 476193064
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 108, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/wLdOmjeehv",
        "expanded_url" : "https:\/\/twitter.com\/BilldeBlasio\/status\/679355513268805636",
        "display_url" : "twitter.com\/BilldeBlasio\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "679451431309475841",
    "text" : "Congrats @BilldeBlasio on leading the way &amp; expanding paid leave for NYC employees\nTime for Congress to #LeadOnLeave https:\/\/t.co\/wLdOmjeehv",
    "id" : 679451431309475841,
    "created_at" : "2015-12-23 00:00:19 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 679453567145529344,
  "created_at" : "2015-12-23 00:08:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679425455812943872",
  "text" : "RT @VP: 5 years ago, Don't Ask, Don't Tell ended. Our military and country are stronger and more true to the values of freedom &amp; equality w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679424704885751809",
    "text" : "5 years ago, Don't Ask, Don't Tell ended. Our military and country are stronger and more true to the values of freedom &amp; equality we defend.",
    "id" : 679424704885751809,
    "created_at" : "2015-12-22 22:14:07 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 679425455812943872,
  "created_at" : "2015-12-22 22:17:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/679422018530492416\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/AbBsBeuGRq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW3KmetWoAAEI0L.jpg",
      "id_str" : "679421881229942784",
      "id" : 679421881229942784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW3KmetWoAAEI0L.jpg",
      "sizes" : [ {
        "h" : 1237,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2398,
        "resize" : "fit",
        "w" : 1985
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AbBsBeuGRq"
    } ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/7pmWI4FL0t",
      "expanded_url" : "http:\/\/tmblr.co\/ZcYUnj1_Q5cCm",
      "display_url" : "tmblr.co\/ZcYUnj1_Q5cCm"
    } ]
  },
  "geo" : { },
  "id_str" : "679422018530492416",
  "text" : "\"You have literally changed our lives.\"\nRead letters from service members on #DADT's repeal https:\/\/t.co\/7pmWI4FL0t https:\/\/t.co\/AbBsBeuGRq",
  "id" : 679422018530492416,
  "created_at" : "2015-12-22 22:03:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 54, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679408008682696704",
  "text" : "RT @vj44: Five years ago, @POTUS signed the repeal of #DADT, extending America\u2019s promise of equality to those who protect it: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 16, 22 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DADT",
        "indices" : [ 44, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/e6XLRbT4Xi",
        "expanded_url" : "http:\/\/on.fb.me\/1V3SyPy",
        "display_url" : "on.fb.me\/1V3SyPy"
      } ]
    },
    "geo" : { },
    "id_str" : "679399723485237248",
    "text" : "Five years ago, @POTUS signed the repeal of #DADT, extending America\u2019s promise of equality to those who protect it: https:\/\/t.co\/e6XLRbT4Xi",
    "id" : 679399723485237248,
    "created_at" : "2015-12-22 20:34:51 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 679408008682696704,
  "created_at" : "2015-12-22 21:07:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/679403682295906304\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/XwCcIM2f0c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW25zzTWcAEZWbf.jpg",
      "id_str" : "679403418398650369",
      "id" : 679403418398650369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW25zzTWcAEZWbf.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XwCcIM2f0c"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/7ieg6YWCcj",
      "expanded_url" : "http:\/\/on.fb.me\/1V3SyPy",
      "display_url" : "on.fb.me\/1V3SyPy"
    } ]
  },
  "geo" : { },
  "id_str" : "679403682295906304",
  "text" : "\"Five years ago today, I signed a bipartisan bill repealing Don\u2019t Ask, Don\u2019t Tell\" \u2014@POTUS: https:\/\/t.co\/7ieg6YWCcj https:\/\/t.co\/XwCcIM2f0c",
  "id" : 679403682295906304,
  "created_at" : "2015-12-22 20:50:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/679400698346369024\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/6Q7NMEBOeQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW23HFVWcAQCQKd.jpg",
      "id_str" : "679400451121508356",
      "id" : 679400451121508356,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW23HFVWcAQCQKd.jpg",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 651
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 651
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 551,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6Q7NMEBOeQ"
    } ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/TC4ue6uX59",
      "expanded_url" : "http:\/\/on.fb.me\/1JsCZKA",
      "display_url" : "on.fb.me\/1JsCZKA"
    } ]
  },
  "geo" : { },
  "id_str" : "679400698346369024",
  "text" : ".@POTUS just posted on Facebook about the 5th anniversary of repealing #DADT: https:\/\/t.co\/TC4ue6uX59 https:\/\/t.co\/6Q7NMEBOeQ",
  "id" : 679400698346369024,
  "created_at" : "2015-12-22 20:38:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bear Grylls",
      "screen_name" : "BearGrylls",
      "indices" : [ 61, 72 ],
      "id_str" : "41692369",
      "id" : 41692369
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/7KilpI0HfO",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/a797fa2d-dad9-40c7-92d7-b4609d69aa62",
      "display_url" : "amp.twimg.com\/v\/a797fa2d-dad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679394446031478784",
  "text" : "\"You're really making a mark on saving their future planet\" \u2014@BearGrylls to @POTUS #ActOnClimate https:\/\/t.co\/7KilpI0HfO",
  "id" : 679394446031478784,
  "created_at" : "2015-12-22 20:13:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/679371018897457152\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9ZA6bNthlo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CW2cVU7VEAQldE8.jpg",
      "id_str" : "679371009011552260",
      "id" : 679371009011552260,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW2cVU7VEAQldE8.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9ZA6bNthlo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/Nz7YkuP0WG",
      "expanded_url" : "http:\/\/go.wh.gov\/BehindTheLens",
      "display_url" : "go.wh.gov\/BehindTheLens"
    } ]
  },
  "geo" : { },
  "id_str" : "679373638320148480",
  "text" : "RT @petesouza: Check out my Instagram photos of 2015: https:\/\/t.co\/Nz7YkuP0WG https:\/\/t.co\/9ZA6bNthlo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/679371018897457152\/photo\/1",
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/9ZA6bNthlo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW2cVU7VEAQldE8.jpg",
        "id_str" : "679371009011552260",
        "id" : 679371009011552260,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW2cVU7VEAQldE8.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9ZA6bNthlo"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/Nz7YkuP0WG",
        "expanded_url" : "http:\/\/go.wh.gov\/BehindTheLens",
        "display_url" : "go.wh.gov\/BehindTheLens"
      } ]
    },
    "geo" : { },
    "id_str" : "679371018897457152",
    "text" : "Check out my Instagram photos of 2015: https:\/\/t.co\/Nz7YkuP0WG https:\/\/t.co\/9ZA6bNthlo",
    "id" : 679371018897457152,
    "created_at" : "2015-12-22 18:40:47 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 679373638320148480,
  "created_at" : "2015-12-22 18:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Bear Grylls",
      "screen_name" : "BearGrylls",
      "indices" : [ 17, 28 ],
      "id_str" : "41692369",
      "id" : 41692369
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/eAVC9RAQbv",
      "expanded_url" : "http:\/\/go.wh.gov\/Alaska",
      "display_url" : "go.wh.gov\/Alaska"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/7KilpHJ6og",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/a797fa2d-dad9-40c7-92d7-b4609d69aa62",
      "display_url" : "amp.twimg.com\/v\/a797fa2d-dad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679366434636619776",
  "text" : "Watch @POTUS and @BearGrylls take a hike around Exit Glacier in Alaska. https:\/\/t.co\/eAVC9RAQbv #ActOnClimate https:\/\/t.co\/7KilpHJ6og",
  "id" : 679366434636619776,
  "created_at" : "2015-12-22 18:22:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 85, 88 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/mq7v8oadHV",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "679335476134862849",
  "text" : "RT @DrBiden: I\u2019m taking over the @WhiteHouse's Instagram to show you the decorations @VP's house \u2192 https:\/\/t.co\/mq7v8oadHV \u2014Jill https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 20, 31 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 72, 75 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/679328890897235969\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/vZXJ3AkLPw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW12BpPUYAEh8aQ.jpg",
        "id_str" : "679328889424863233",
        "id" : 679328889424863233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW12BpPUYAEh8aQ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 3000
        } ],
        "display_url" : "pic.twitter.com\/vZXJ3AkLPw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/mq7v8oadHV",
        "expanded_url" : "http:\/\/instagram.com\/whitehouse",
        "display_url" : "instagram.com\/whitehouse"
      } ]
    },
    "geo" : { },
    "id_str" : "679328890897235969",
    "text" : "I\u2019m taking over the @WhiteHouse's Instagram to show you the decorations @VP's house \u2192 https:\/\/t.co\/mq7v8oadHV \u2014Jill https:\/\/t.co\/vZXJ3AkLPw",
    "id" : 679328890897235969,
    "created_at" : "2015-12-22 15:53:23 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 679335476134862849,
  "created_at" : "2015-12-22 16:19:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679321851454205953",
  "text" : "RT @CEAChair: GDP grew 2% in Q3 \u2013 revised down 0.1 pp due to inventories. Consumer spending &amp; investment remain strong. https:\/\/t.co\/Z9BNn9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/679313944176013312\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/Z9BNn9AzpA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CW1obqfWwAAwHqL.png",
        "id_str" : "679313943274373120",
        "id" : 679313943274373120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CW1obqfWwAAwHqL.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 824,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 743,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Z9BNn9AzpA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679313944176013312",
    "text" : "GDP grew 2% in Q3 \u2013 revised down 0.1 pp due to inventories. Consumer spending &amp; investment remain strong. https:\/\/t.co\/Z9BNn9AzpA",
    "id" : 679313944176013312,
    "created_at" : "2015-12-22 14:53:59 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 679321851454205953,
  "created_at" : "2015-12-22 15:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/679119224812388352\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/469mcPCYhc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWyuXikUwAA6lkP.jpg",
      "id_str" : "679109363265486848",
      "id" : 679109363265486848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWyuXikUwAA6lkP.jpg",
      "sizes" : [ {
        "h" : 434,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 781,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/469mcPCYhc"
    } ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679119224812388352",
  "text" : "On the longest night of the year, lights are all aglow at the White House. #WHHolidays https:\/\/t.co\/469mcPCYhc",
  "id" : 679119224812388352,
  "created_at" : "2015-12-22 02:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/nOflpv2f8S",
      "expanded_url" : "http:\/\/nyti.ms\/1Zkut9L",
      "display_url" : "nyti.ms\/1Zkut9L"
    } ]
  },
  "geo" : { },
  "id_str" : "679111365420646400",
  "text" : "RT @nytimes: Months after Cecil the lion died, the U.S. has acted to heighten protection of the animals https:\/\/t.co\/nOflpv2f8S https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/678903370791452672\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/aWHl01nTMU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWvzBIwUsAEZPXc.png",
        "id_str" : "678903369704976385",
        "id" : 678903369704976385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWvzBIwUsAEZPXc.png",
        "sizes" : [ {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/aWHl01nTMU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/nOflpv2f8S",
        "expanded_url" : "http:\/\/nyti.ms\/1Zkut9L",
        "display_url" : "nyti.ms\/1Zkut9L"
      } ]
    },
    "geo" : { },
    "id_str" : "678903370791452672",
    "text" : "Months after Cecil the lion died, the U.S. has acted to heighten protection of the animals https:\/\/t.co\/nOflpv2f8S https:\/\/t.co\/aWHl01nTMU",
    "id" : 678903370791452672,
    "created_at" : "2015-12-21 11:42:31 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 679111365420646400,
  "created_at" : "2015-12-22 01:29:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Bear Grylls",
      "screen_name" : "BearGrylls",
      "indices" : [ 20, 31 ],
      "id_str" : "41692369",
      "id" : 41692369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/7KilpI0HfO",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/a797fa2d-dad9-40c7-92d7-b4609d69aa62",
      "display_url" : "amp.twimg.com\/v\/a797fa2d-dad\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679098285810823168",
  "text" : "Watch as @POTUS and @BearGrylls take you to Alaska on the frontlines of our fight against climate change.\nhttps:\/\/t.co\/7KilpI0HfO",
  "id" : 679098285810823168,
  "created_at" : "2015-12-22 00:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/HR8IejIBwH",
      "expanded_url" : "http:\/\/snpy.tv\/1IZ4nou",
      "display_url" : "snpy.tv\/1IZ4nou"
    } ]
  },
  "geo" : { },
  "id_str" : "679089057490599936",
  "text" : "\"On climate, our early investment in clean energy ignited a clean energy industry boom.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/HR8IejIBwH",
  "id" : 679089057490599936,
  "created_at" : "2015-12-22 00:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/679079970103160833\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/fL3fGKCeXT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWyTol7U4AE1VkS.jpg",
      "id_str" : "679079969411096577",
      "id" : 679079969411096577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWyTol7U4AE1VkS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fL3fGKCeXT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679080053372665856",
  "text" : "RT @PressSec: Our thoughts and prayers are with the families of the 6 service members killed in Afghanistan today. https:\/\/t.co\/fL3fGKCeXT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/679079970103160833\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/fL3fGKCeXT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWyTol7U4AE1VkS.jpg",
        "id_str" : "679079969411096577",
        "id" : 679079969411096577,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWyTol7U4AE1VkS.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fL3fGKCeXT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "679079970103160833",
    "text" : "Our thoughts and prayers are with the families of the 6 service members killed in Afghanistan today. https:\/\/t.co\/fL3fGKCeXT",
    "id" : 679079970103160833,
    "created_at" : "2015-12-21 23:24:16 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 679080053372665856,
  "created_at" : "2015-12-21 23:24:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/HR8IejIBwH",
      "expanded_url" : "http:\/\/snpy.tv\/1IZ4nou",
      "display_url" : "snpy.tv\/1IZ4nou"
    } ]
  },
  "geo" : { },
  "id_str" : "679056543367610369",
  "text" : "Watch as @POTUS takes a look back at 2015 in his end-of-year press conference. https:\/\/t.co\/HR8IejIBwH",
  "id" : 679056543367610369,
  "created_at" : "2015-12-21 21:51:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/679026023833276416\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Av1NYB6vbI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWxieEyWEAEaRAd.jpg",
      "id_str" : "679025912646602753",
      "id" : 679025912646602753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWxieEyWEAEaRAd.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 649,
        "resize" : "fit",
        "w" : 976
      } ],
      "display_url" : "pic.twitter.com\/Av1NYB6vbI"
    } ],
    "hashtags" : [ {
      "text" : "WHSocial",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/UpvxhDTBgs",
      "expanded_url" : "http:\/\/go.wh.gov\/SOTUSocial",
      "display_url" : "go.wh.gov\/SOTUSocial"
    } ]
  },
  "geo" : { },
  "id_str" : "679026023833276416",
  "text" : "Apply to watch @POTUS's last State of the Union from the White House by Dec. 28: https:\/\/t.co\/UpvxhDTBgs #WHSocial https:\/\/t.co\/Av1NYB6vbI",
  "id" : 679026023833276416,
  "created_at" : "2015-12-21 19:49:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/HR8IejIBwH",
      "expanded_url" : "http:\/\/snpy.tv\/1IZ4nou",
      "display_url" : "snpy.tv\/1IZ4nou"
    } ]
  },
  "geo" : { },
  "id_str" : "679017959059140611",
  "text" : "\"Interesting stuff happens in the fourth quarter\u2014and we are only halfway through.\" \u2014@POTUS looking back on 2015 https:\/\/t.co\/HR8IejIBwH",
  "id" : 679017959059140611,
  "created_at" : "2015-12-21 19:17:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/HR8IejIBwH",
      "expanded_url" : "http:\/\/snpy.tv\/1IZ4nou",
      "display_url" : "snpy.tv\/1IZ4nou"
    } ]
  },
  "geo" : { },
  "id_str" : "679006560945758208",
  "text" : "In 2015, our businesses extended the longest streak of job growth on record. #YearInReview https:\/\/t.co\/HR8IejIBwH",
  "id" : 679006560945758208,
  "created_at" : "2015-12-21 18:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/MJj1Oan6fx",
      "expanded_url" : "http:\/\/go.wh.gov\/iBw9Wv",
      "display_url" : "go.wh.gov\/iBw9Wv"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/44tdv8R3Pc",
      "expanded_url" : "http:\/\/go.wh.gov\/JJw4U3",
      "display_url" : "go.wh.gov\/JJw4U3"
    } ]
  },
  "geo" : { },
  "id_str" : "678978871132164096",
  "text" : "10 things that happened in 2015 that should make every American optimistic about 2016 \u2192 https:\/\/t.co\/MJj1Oan6fx https:\/\/t.co\/44tdv8R3Pc",
  "id" : 678978871132164096,
  "created_at" : "2015-12-21 16:42:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/678020525679992832\/video\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/VmKW1wpDlm",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/678020445615087616\/pu\/img\/5mRphuL2HDOKA84q.jpg",
      "id_str" : "678020445615087616",
      "id" : 678020445615087616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/678020445615087616\/pu\/img\/5mRphuL2HDOKA84q.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VmKW1wpDlm"
    } ],
    "hashtags" : [ {
      "text" : "TheForceAwakens",
      "indices" : [ 57, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678739167585558528",
  "text" : "These aren't the West Wing visitors we were looking for\u2026 #TheForceAwakens https:\/\/t.co\/VmKW1wpDlm",
  "id" : 678739167585558528,
  "created_at" : "2015-12-21 00:50:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 60, 73 ]
    }, {
      "text" : "WestWingWeek",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/E8sQeqxVww",
      "expanded_url" : "http:\/\/snpy.tv\/1k8HNhv",
      "display_url" : "snpy.tv\/1k8HNhv"
    } ]
  },
  "geo" : { },
  "id_str" : "678717782607851520",
  "text" : "\"They're going to make America that much better\" \u2014@POTUS to #NewAmericans  \n\nGo behind the scenes in #WestWingWeek. https:\/\/t.co\/E8sQeqxVww",
  "id" : 678717782607851520,
  "created_at" : "2015-12-20 23:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 86, 101 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/E8sQeqxVww",
      "expanded_url" : "http:\/\/snpy.tv\/1k8HNhv",
      "display_url" : "snpy.tv\/1k8HNhv"
    } ]
  },
  "geo" : { },
  "id_str" : "678673788536356864",
  "text" : "\"Our work here and now gave future generations cleaner air and cleaner water\" \u2014@POTUS #ParisAgreement #ActOnClimate  https:\/\/t.co\/E8sQeqxVww",
  "id" : 678673788536356864,
  "created_at" : "2015-12-20 20:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678657864890626048",
  "text" : "RT @POTUS: Zaevion Dobson died saving three friends from getting shot. He was a hero at 15. What's our excuse for not acting? https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/hn98uGsjKZ",
        "expanded_url" : "http:\/\/wpo.st\/05Vy0",
        "display_url" : "wpo.st\/05Vy0"
      } ]
    },
    "geo" : { },
    "id_str" : "678656661024858112",
    "text" : "Zaevion Dobson died saving three friends from getting shot. He was a hero at 15. What's our excuse for not acting? https:\/\/t.co\/hn98uGsjKZ",
    "id" : 678656661024858112,
    "created_at" : "2015-12-20 19:22:11 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 678657864890626048,
  "created_at" : "2015-12-20 19:26:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/44tdv8R3Pc",
      "expanded_url" : "http:\/\/go.wh.gov\/JJw4U3",
      "display_url" : "go.wh.gov\/JJw4U3"
    } ]
  },
  "geo" : { },
  "id_str" : "678651190251380738",
  "text" : "\"ISIL is losing territory, and we\u2019re not going to stop until we destroy this terrorist organization.\" \u2014@POTUS https:\/\/t.co\/44tdv8R3Pc",
  "id" : 678651190251380738,
  "created_at" : "2015-12-20 19:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 54, 69 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/5uZW8NNcvU",
      "expanded_url" : "http:\/\/go.wh.gov\/ApDH9m",
      "display_url" : "go.wh.gov\/ApDH9m"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/E8sQeqxVww",
      "expanded_url" : "http:\/\/snpy.tv\/1k8HNhv",
      "display_url" : "snpy.tv\/1k8HNhv"
    } ]
  },
  "geo" : { },
  "id_str" : "678637255368425475",
  "text" : "Go behind the scenes as @POTUS announced the historic #ParisAgreement to #ActOnClimate: https:\/\/t.co\/5uZW8NNcvU https:\/\/t.co\/E8sQeqxVww",
  "id" : 678637255368425475,
  "created_at" : "2015-12-20 18:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/MJj1Oan6fx",
      "expanded_url" : "http:\/\/go.wh.gov\/iBw9Wv",
      "display_url" : "go.wh.gov\/iBw9Wv"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/44tdv8R3Pc",
      "expanded_url" : "http:\/\/go.wh.gov\/JJw4U3",
      "display_url" : "go.wh.gov\/JJw4U3"
    } ]
  },
  "geo" : { },
  "id_str" : "678618965329838080",
  "text" : "Here's what we've accomplished in 2015 and what we have to look forward to in 2016: https:\/\/t.co\/MJj1Oan6fx  https:\/\/t.co\/44tdv8R3Pc",
  "id" : 678618965329838080,
  "created_at" : "2015-12-20 16:52:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 91, 100 ]
    }, {
      "text" : "YearInReview",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/44tdv8R3Pc",
      "expanded_url" : "http:\/\/go.wh.gov\/JJw4U3",
      "display_url" : "go.wh.gov\/JJw4U3"
    } ]
  },
  "geo" : { },
  "id_str" : "678326488131702784",
  "text" : "\"No matter who you are, here in America, you\u2019re free to marry the person you love\" \u2014@POTUS #LoveWins #YearInReview https:\/\/t.co\/44tdv8R3Pc",
  "id" : 678326488131702784,
  "created_at" : "2015-12-19 21:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/678315137074249729\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/IzJgrB5AMX",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWnGVB6XIAA3Q5Y.png",
      "id_str" : "678291283488743424",
      "id" : 678291283488743424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWnGVB6XIAA3Q5Y.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IzJgrB5AMX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/MJj1Oan6fx",
      "expanded_url" : "http:\/\/go.wh.gov\/iBw9Wv",
      "display_url" : "go.wh.gov\/iBw9Wv"
    } ]
  },
  "geo" : { },
  "id_str" : "678315137074249729",
  "text" : "\"Nearly 200 countries came together to set the course for a low-carbon future.\"\u2014@POTUS: https:\/\/t.co\/MJj1Oan6fx https:\/\/t.co\/IzJgrB5AMX",
  "id" : 678315137074249729,
  "created_at" : "2015-12-19 20:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/678293477076152321\/photo\/1",
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/zJuEyQoi2i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWnIRMzWoAAdj3A.jpg",
      "id_str" : "678293416715919360",
      "id" : 678293416715919360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWnIRMzWoAAdj3A.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zJuEyQoi2i"
    } ],
    "hashtags" : [ {
      "text" : "TheForceAwakens",
      "indices" : [ 30, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678293477076152321",
  "text" : "DJ R2-D2's White House debut. #TheForceAwakens https:\/\/t.co\/zJuEyQoi2i",
  "id" : 678293477076152321,
  "created_at" : "2015-12-19 19:19:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/44tdv8R3Pc",
      "expanded_url" : "http:\/\/go.wh.gov\/JJw4U3",
      "display_url" : "go.wh.gov\/JJw4U3"
    } ]
  },
  "geo" : { },
  "id_str" : "678287458996383744",
  "text" : "Here's how we've turned the page on outdated policies and built greater ties between Americans and Cubans. https:\/\/t.co\/44tdv8R3Pc",
  "id" : 678287458996383744,
  "created_at" : "2015-12-19 18:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/MJj1Oan6fx",
      "expanded_url" : "http:\/\/go.wh.gov\/iBw9Wv",
      "display_url" : "go.wh.gov\/iBw9Wv"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/44tdv8R3Pc",
      "expanded_url" : "http:\/\/go.wh.gov\/JJw4U3",
      "display_url" : "go.wh.gov\/JJw4U3"
    } ]
  },
  "geo" : { },
  "id_str" : "678278653336092672",
  "text" : "\"When we\u2019re united as Americans, there\u2019s nothing that we cannot do.\" \u2014@POTUS: https:\/\/t.co\/MJj1Oan6fx #YearInReview https:\/\/t.co\/44tdv8R3Pc",
  "id" : 678278653336092672,
  "created_at" : "2015-12-19 18:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/44tdv8R3Pc",
      "expanded_url" : "http:\/\/go.wh.gov\/JJw4U3",
      "display_url" : "go.wh.gov\/JJw4U3"
    } ]
  },
  "geo" : { },
  "id_str" : "678272359363567617",
  "text" : "\"This week, Congress passed a bipartisan budget that invests in middle-class priorities\" \u2014@POTUS #YearInReview https:\/\/t.co\/44tdv8R3Pc",
  "id" : 678272359363567617,
  "created_at" : "2015-12-19 17:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Top10",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/44tdv8R3Pc",
      "expanded_url" : "http:\/\/go.wh.gov\/JJw4U3",
      "display_url" : "go.wh.gov\/JJw4U3"
    } ]
  },
  "geo" : { },
  "id_str" : "678263541015572480",
  "text" : "\"Number 10: The economy. Over the past 12 months, our businesses have created 2.5 million new jobs.\" \u2014@POTUS #Top10 https:\/\/t.co\/44tdv8R3Pc",
  "id" : 678263541015572480,
  "created_at" : "2015-12-19 17:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/678248453072224256\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/CtEJ5atgYT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWmcOECXAAATwid.jpg",
      "id_str" : "678244984311709696",
      "id" : 678244984311709696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWmcOECXAAATwid.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CtEJ5atgYT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/MJj1Oan6fx",
      "expanded_url" : "http:\/\/go.wh.gov\/iBw9Wv",
      "display_url" : "go.wh.gov\/iBw9Wv"
    } ]
  },
  "geo" : { },
  "id_str" : "678248453072224256",
  "text" : "\"The rate of the uninsured in America dropped below 10% for the first time ever.\" \u2014@POTUS: https:\/\/t.co\/MJj1Oan6fx https:\/\/t.co\/CtEJ5atgYT",
  "id" : 678248453072224256,
  "created_at" : "2015-12-19 16:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/44tdv98FdM",
      "expanded_url" : "http:\/\/go.wh.gov\/JJw4U3",
      "display_url" : "go.wh.gov\/JJw4U3"
    } ]
  },
  "geo" : { },
  "id_str" : "678239510187102209",
  "text" : "This past year has been one of unprecedented progress. Check out @POTUS's Top 10 of 2015. #YearInReview https:\/\/t.co\/44tdv98FdM",
  "id" : 678239510187102209,
  "created_at" : "2015-12-19 15:44:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 27, 38 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/678020525679992832\/video\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/LVJZereiUh",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/678020445615087616\/pu\/img\/5mRphuL2HDOKA84q.jpg",
      "id_str" : "678020445615087616",
      "id" : 678020445615087616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/678020445615087616\/pu\/img\/5mRphuL2HDOKA84q.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LVJZereiUh"
    } ],
    "hashtags" : [ {
      "text" : "StarWars",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678021038979043328",
  "text" : "RT @FLOTUS: Welcome to the @WhiteHouse, R2-D2. #StarWars https:\/\/t.co\/LVJZereiUh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 15, 26 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/678020525679992832\/video\/1",
        "indices" : [ 45, 68 ],
        "url" : "https:\/\/t.co\/LVJZereiUh",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/678020445615087616\/pu\/img\/5mRphuL2HDOKA84q.jpg",
        "id_str" : "678020445615087616",
        "id" : 678020445615087616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/678020445615087616\/pu\/img\/5mRphuL2HDOKA84q.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LVJZereiUh"
      } ],
      "hashtags" : [ {
        "text" : "StarWars",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "678020525679992832",
    "text" : "Welcome to the @WhiteHouse, R2-D2. #StarWars https:\/\/t.co\/LVJZereiUh",
    "id" : 678020525679992832,
    "created_at" : "2015-12-19 01:14:24 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 678021038979043328,
  "created_at" : "2015-12-19 01:16:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/HsMIDd27MN",
      "expanded_url" : "http:\/\/snpy.tv\/1QybZRq",
      "display_url" : "snpy.tv\/1QybZRq"
    } ]
  },
  "geo" : { },
  "id_str" : "678014398502334464",
  "text" : "\"Our early investments in clean energy ignited a clean energy industry.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/HsMIDd27MN",
  "id" : 678014398502334464,
  "created_at" : "2015-12-19 00:50:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/HsMIDd27MN",
      "expanded_url" : "http:\/\/snpy.tv\/1QybZRq",
      "display_url" : "snpy.tv\/1QybZRq"
    } ]
  },
  "geo" : { },
  "id_str" : "678003428807733248",
  "text" : ".@POTUS in his end-of-year press conference on how the U.S. is leading the world to #ActOnClimate. https:\/\/t.co\/HsMIDd27MN",
  "id" : 678003428807733248,
  "created_at" : "2015-12-19 00:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/HR8Iek0cVh",
      "expanded_url" : "http:\/\/snpy.tv\/1IZ4nou",
      "display_url" : "snpy.tv\/1IZ4nou"
    } ]
  },
  "geo" : { },
  "id_str" : "677995161973096449",
  "text" : "\"After decades of dedicated advocacy, marriage equality became a reality in all 50 states.\" \u2014@POTUS #LoveWins https:\/\/t.co\/HR8Iek0cVh",
  "id" : 677995161973096449,
  "created_at" : "2015-12-18 23:33:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Detroit Pistons",
      "screen_name" : "DetroitPistons",
      "indices" : [ 3, 18 ],
      "id_str" : "16727749",
      "id" : 16727749
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/ip1vnRe1vr",
      "expanded_url" : "https:\/\/www.healthcare.gov\/",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "677986664841547776",
  "text" : "RT @DetroitPistons: Detroit! We're in 2nd to win a @POTUS visit w\/ the Healthy Community Challenge! #GetCovered https:\/\/t.co\/ip1vnRe1vr htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 31, 37 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DetroitPistons\/status\/677913485376794626\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/3P0lWALRkg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhh8EFXIAAmI2v.jpg",
        "id_str" : "677899428435533824",
        "id" : 677899428435533824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhh8EFXIAAmI2v.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3P0lWALRkg"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/ip1vnRe1vr",
        "expanded_url" : "https:\/\/www.healthcare.gov\/",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "677913485376794626",
    "text" : "Detroit! We're in 2nd to win a @POTUS visit w\/ the Healthy Community Challenge! #GetCovered https:\/\/t.co\/ip1vnRe1vr https:\/\/t.co\/3P0lWALRkg",
    "id" : 677913485376794626,
    "created_at" : "2015-12-18 18:09:04 +0000",
    "user" : {
      "name" : "Detroit Pistons",
      "screen_name" : "DetroitPistons",
      "protected" : false,
      "id_str" : "16727749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797788437424308225\/fo8NWCjk_normal.jpg",
      "id" : 16727749,
      "verified" : true
    }
  },
  "id" : 677986664841547776,
  "created_at" : "2015-12-18 22:59:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677974047397949442",
  "text" : "RT @SecBurwell: Thru Dec 17, about 6M people signed up for Marketplace coverage. 2.4M who signed up thru Dec 17 were new Marketplace custom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "677970464078196737",
    "geo" : { },
    "id_str" : "677970843029368832",
    "in_reply_to_user_id" : 2458567464,
    "text" : "Thru Dec 17, about 6M people signed up for Marketplace coverage. 2.4M who signed up thru Dec 17 were new Marketplace customers. #GetCovered",
    "id" : 677970843029368832,
    "in_reply_to_status_id" : 677970464078196737,
    "created_at" : "2015-12-18 21:56:59 +0000",
    "in_reply_to_screen_name" : "SecBurwell",
    "in_reply_to_user_id_str" : "2458567464",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 677974047397949442,
  "created_at" : "2015-12-18 22:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Disney",
      "screen_name" : "Disney",
      "indices" : [ 69, 76 ],
      "id_str" : "67418441",
      "id" : 67418441
    }, {
      "name" : "Star Wars",
      "screen_name" : "starwars",
      "indices" : [ 89, 98 ],
      "id_str" : "20106852",
      "id" : 20106852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677958509766549504",
  "text" : "RT @PressSec: It can be useful to bring friends along sometimes. Thx @Disney 4 hosting a @StarWars event for Gold Star families. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Disney",
        "screen_name" : "Disney",
        "indices" : [ 55, 62 ],
        "id_str" : "67418441",
        "id" : 67418441
      }, {
        "name" : "Star Wars",
        "screen_name" : "starwars",
        "indices" : [ 75, 84 ],
        "id_str" : "20106852",
        "id" : 20106852
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/677957666807939072\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/mdbP76V5QV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWiWYQsXIAEA8MK.jpg",
        "id_str" : "677957087461318657",
        "id" : 677957087461318657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWiWYQsXIAEA8MK.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/mdbP76V5QV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677957666807939072",
    "text" : "It can be useful to bring friends along sometimes. Thx @Disney 4 hosting a @StarWars event for Gold Star families. https:\/\/t.co\/mdbP76V5QV",
    "id" : 677957666807939072,
    "created_at" : "2015-12-18 21:04:38 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 677958509766549504,
  "created_at" : "2015-12-18 21:07:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 75, 90 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/5zgsS4nGIJ",
      "expanded_url" : "http:\/\/snpy.tv\/1RXtvhp",
      "display_url" : "snpy.tv\/1RXtvhp"
    } ]
  },
  "geo" : { },
  "id_str" : "677947947150110720",
  "text" : "\"This would not have happened without American leadership.\" \u2014@POTUS on the #ParisAgreement to #ActOnClimate https:\/\/t.co\/5zgsS4nGIJ",
  "id" : 677947947150110720,
  "created_at" : "2015-12-18 20:26:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 43, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/g0TFoPxJDC",
      "expanded_url" : "http:\/\/snpy.tv\/1Qy9DC5",
      "display_url" : "snpy.tv\/1Qy9DC5"
    } ]
  },
  "geo" : { },
  "id_str" : "677941630507343872",
  "text" : "RT if you agree with @POTUS: It's time for #CriminalJusticeReform. https:\/\/t.co\/g0TFoPxJDC",
  "id" : 677941630507343872,
  "created_at" : "2015-12-18 20:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Froman",
      "screen_name" : "MikeFroman",
      "indices" : [ 3, 14 ],
      "id_str" : "2328937074",
      "id" : 2328937074
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 110, 114 ]
    }, {
      "text" : "MadeInAmerica",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677941307466190848",
  "text" : "RT @MikeFroman: \u201CThe most pro-labor, pro-environment, progressive trade agreement in history.\u201D -@POTUS on the #TPP #MadeInAmerica https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 80, 86 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 94, 98 ]
      }, {
        "text" : "MadeInAmerica",
        "indices" : [ 99, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/81V7A8DddJ",
        "expanded_url" : "http:\/\/snpy.tv\/1k6XTrW",
        "display_url" : "snpy.tv\/1k6XTrW"
      } ]
    },
    "geo" : { },
    "id_str" : "677940626550349825",
    "text" : "\u201CThe most pro-labor, pro-environment, progressive trade agreement in history.\u201D -@POTUS on the #TPP #MadeInAmerica https:\/\/t.co\/81V7A8DddJ",
    "id" : 677940626550349825,
    "created_at" : "2015-12-18 19:56:55 +0000",
    "user" : {
      "name" : "Michael Froman",
      "screen_name" : "MikeFroman",
      "protected" : false,
      "id_str" : "2328937074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446358877714382849\/5OKDFPXt_normal.jpeg",
      "id" : 2328937074,
      "verified" : true
    }
  },
  "id" : 677941307466190848,
  "created_at" : "2015-12-18 19:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677933090698825728",
  "text" : "RT @jesseclee44: Past year'd be good record for an entire presidency:\n5% Unemp.\nClimate pact\nMarriage Equality\nIran\nNet neutrality\nCuba\nOve\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677929099634073600",
    "text" : "Past year'd be good record for an entire presidency:\n5% Unemp.\nClimate pact\nMarriage Equality\nIran\nNet neutrality\nCuba\nOvertime\n6M in ACA",
    "id" : 677929099634073600,
    "created_at" : "2015-12-18 19:11:07 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 677933090698825728,
  "created_at" : "2015-12-18 19:26:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/HR8IejIBwH",
      "expanded_url" : "http:\/\/snpy.tv\/1IZ4nou",
      "display_url" : "snpy.tv\/1IZ4nou"
    } ]
  },
  "geo" : { },
  "id_str" : "677930852005707776",
  "text" : "\"I've never been more optimistic about a year ahead than I am right now\" \u2014@POTUS in his end-of-year press conference https:\/\/t.co\/HR8IejIBwH",
  "id" : 677930852005707776,
  "created_at" : "2015-12-18 19:18:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677930001493180416",
  "text" : "\"I\u2019ve never been more optimistic about a year ahead than I am right now...in 2016, I'm going to leave it all out on the field.\" \u2014@POTUS",
  "id" : 677930001493180416,
  "created_at" : "2015-12-18 19:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677929420812849152\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/PgKjwoX6uF",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWh9MCYWIAARu1K.png",
      "id_str" : "677929389670146048",
      "id" : 677929389670146048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWh9MCYWIAARu1K.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/PgKjwoX6uF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677929420812849152",
  "text" : "\"The United States continues to lead a global coalition in our mission to destroy ISIL.\" \u2014@POTUS https:\/\/t.co\/PgKjwoX6uF",
  "id" : 677929420812849152,
  "created_at" : "2015-12-18 19:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677929088011493376\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/COyCD1hZjR",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWh85CCUkAAoB7s.png",
      "id_str" : "677929063160254464",
      "id" : 677929063160254464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWh85CCUkAAoB7s.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/COyCD1hZjR"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677929088011493376",
  "text" : "\"After decades of dedicated advocacy, marriage equality became a reality in all 50 states.\" \u2014@POTUS #LoveWins https:\/\/t.co\/COyCD1hZjR",
  "id" : 677929088011493376,
  "created_at" : "2015-12-18 19:11:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/677928836886065152\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/8tm5omUCcf",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWh8q_RWEAAa53k.png",
      "id_str" : "677928821899792384",
      "id" : 677928821899792384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWh8q_RWEAAa53k.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8tm5omUCcf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677928836886065152",
  "text" : "\"Nearly 200 nations forged an historic climate agreement that was only possible with American leadership.\" \u2014@POTUS https:\/\/t.co\/8tm5omUCcf",
  "id" : 677928836886065152,
  "created_at" : "2015-12-18 19:10:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/677928696104140800\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/CROMkxkdwi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWh8jGzU8AAjDUp.jpg",
      "id_str" : "677928686482419712",
      "id" : 677928686482419712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWh8jGzU8AAjDUp.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/CROMkxkdwi"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677928724805718016",
  "text" : "RT @FactsOnClimate: \"Our early investments in clean energy ignited a clean energy industry.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/CROMkxkdwi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 74, 80 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/677928696104140800\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/CROMkxkdwi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWh8jGzU8AAjDUp.jpg",
        "id_str" : "677928686482419712",
        "id" : 677928686482419712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWh8jGzU8AAjDUp.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/CROMkxkdwi"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 81, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677928696104140800",
    "text" : "\"Our early investments in clean energy ignited a clean energy industry.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/CROMkxkdwi",
    "id" : 677928696104140800,
    "created_at" : "2015-12-18 19:09:31 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 677928724805718016,
  "created_at" : "2015-12-18 19:09:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/677928443032510464\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/lmX9iMsN1G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWh8UBXXAAAkFnL.jpg",
      "id_str" : "677928427324899328",
      "id" : 677928427324899328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWh8UBXXAAAkFnL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lmX9iMsN1G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677928443032510464",
  "text" : "\"The Affordable Care Act helped drive the rate of the uninsured in America below 10% for the first time\" \u2014@POTUS https:\/\/t.co\/lmX9iMsN1G",
  "id" : 677928443032510464,
  "created_at" : "2015-12-18 19:08:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677928346949451780\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/c90hMZrL2g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWh8OlgW4AU5x82.jpg",
      "id_str" : "677928333947101189",
      "id" : 677928333947101189,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWh8OlgW4AU5x82.jpg",
      "sizes" : [ {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2501
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/c90hMZrL2g"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/7gyqH6z6gy",
      "expanded_url" : "http:\/\/go.wh.gov\/POTUSLive",
      "display_url" : "go.wh.gov\/POTUSLive"
    } ]
  },
  "geo" : { },
  "id_str" : "677928346949451780",
  "text" : "\"The unemployment rate has been cut in half\u2014down to 5%.\" \u2014@POTUS: https:\/\/t.co\/7gyqH6z6gy https:\/\/t.co\/c90hMZrL2g",
  "id" : 677928346949451780,
  "created_at" : "2015-12-18 19:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677928266875973632\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/7Wix2k7cFi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWh8KRJWIAANzcS.jpg",
      "id_str" : "677928259762397184",
      "id" : 677928259762397184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWh8KRJWIAANzcS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7Wix2k7cFi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677928266875973632",
  "text" : "\"Our...actions to rescue the economy set the stage for the longest streak of private-sector job creation on record\" https:\/\/t.co\/7Wix2k7cFi",
  "id" : 677928266875973632,
  "created_at" : "2015-12-18 19:07:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/7gyqH6z6gy",
      "expanded_url" : "http:\/\/go.wh.gov\/POTUSLive",
      "display_url" : "go.wh.gov\/POTUSLive"
    } ]
  },
  "geo" : { },
  "id_str" : "677928082355953664",
  "text" : "Watch live: @POTUS holds his end-of-year press conference \u2192 https:\/\/t.co\/7gyqH6z6gy",
  "id" : 677928082355953664,
  "created_at" : "2015-12-18 19:07:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677927041086398464\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/tdgBtncHvS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWh6w6iWwAA8zmB.jpg",
      "id_str" : "677926724684922880",
      "id" : 677926724684922880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWh6w6iWwAA8zmB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tdgBtncHvS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/PCAhu3vRpn",
      "expanded_url" : "http:\/\/go.wh.gov\/USiRhG",
      "display_url" : "go.wh.gov\/USiRhG"
    } ]
  },
  "geo" : { },
  "id_str" : "677927041086398464",
  "text" : ".@POTUS has commuted prison sentences for more people than the last 5 presidents combined: https:\/\/t.co\/PCAhu3vRpn https:\/\/t.co\/tdgBtncHvS",
  "id" : 677927041086398464,
  "created_at" : "2015-12-18 19:02:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/677916363386589184\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/Zg0nDg39ia",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhxVuYUAAArtev.jpg",
      "id_str" : "677916361960456192",
      "id" : 677916361960456192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhxVuYUAAArtev.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Zg0nDg39ia"
    } ],
    "hashtags" : [ {
      "text" : "2015In5Words",
      "indices" : [ 41, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677923084871925760",
  "text" : "RT @VP: I've never been more optimistic. #2015In5Words https:\/\/t.co\/Zg0nDg39ia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/677916363386589184\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/Zg0nDg39ia",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhxVuYUAAArtev.jpg",
        "id_str" : "677916361960456192",
        "id" : 677916361960456192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhxVuYUAAArtev.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Zg0nDg39ia"
      } ],
      "hashtags" : [ {
        "text" : "2015In5Words",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677916363386589184",
    "text" : "I've never been more optimistic. #2015In5Words https:\/\/t.co\/Zg0nDg39ia",
    "id" : 677916363386589184,
    "created_at" : "2015-12-18 18:20:30 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 677923084871925760,
  "created_at" : "2015-12-18 18:47:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/677918849593794560\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/a44sHA2irr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhzbu9UYAAUZUw.jpg",
      "id_str" : "677918664218140672",
      "id" : 677918664218140672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhzbu9UYAAUZUw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/a44sHA2irr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/PCAhu3eg0N",
      "expanded_url" : "http:\/\/go.wh.gov\/USiRhG",
      "display_url" : "go.wh.gov\/USiRhG"
    } ]
  },
  "geo" : { },
  "id_str" : "677918849593794560",
  "text" : ".@POTUS just commuted the sentences of 95 men and women who committed nonviolent offenses: https:\/\/t.co\/PCAhu3eg0N https:\/\/t.co\/a44sHA2irr",
  "id" : 677918849593794560,
  "created_at" : "2015-12-18 18:30:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/677911701988184064\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/Bwuv7tcps7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhtGbqUsAIe4eZ.jpg",
      "id_str" : "677911701191176194",
      "id" : 677911701191176194,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhtGbqUsAIe4eZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Bwuv7tcps7"
    } ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 30, 51 ]
    }, {
      "text" : "2015In5Words",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677911940660727809",
  "text" : "RT @DrBiden: .@POTUS proposed #FreeCommunityCollege! #2015In5Words https:\/\/t.co\/Bwuv7tcps7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/677911701988184064\/photo\/1",
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/Bwuv7tcps7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhtGbqUsAIe4eZ.jpg",
        "id_str" : "677911701191176194",
        "id" : 677911701191176194,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhtGbqUsAIe4eZ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Bwuv7tcps7"
      } ],
      "hashtags" : [ {
        "text" : "FreeCommunityCollege",
        "indices" : [ 17, 38 ]
      }, {
        "text" : "2015In5Words",
        "indices" : [ 40, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677911701988184064",
    "text" : ".@POTUS proposed #FreeCommunityCollege! #2015In5Words https:\/\/t.co\/Bwuv7tcps7",
    "id" : 677911701988184064,
    "created_at" : "2015-12-18 18:01:59 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 677911940660727809,
  "created_at" : "2015-12-18 18:02:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2015In5Words",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/6JqTMyEEos",
      "expanded_url" : "http:\/\/www.snappytv.com\/tc\/747844",
      "display_url" : "snappytv.com\/tc\/747844"
    } ]
  },
  "geo" : { },
  "id_str" : "677910178990325760",
  "text" : "RT @rhodes44: Opened diplomatic relations with Cuba #2015In5Words https:\/\/t.co\/6JqTMyEEos",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "2015In5Words",
        "indices" : [ 38, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/6JqTMyEEos",
        "expanded_url" : "http:\/\/www.snappytv.com\/tc\/747844",
        "display_url" : "snappytv.com\/tc\/747844"
      } ]
    },
    "geo" : { },
    "id_str" : "677908210473304064",
    "text" : "Opened diplomatic relations with Cuba #2015In5Words https:\/\/t.co\/6JqTMyEEos",
    "id" : 677908210473304064,
    "created_at" : "2015-12-18 17:48:06 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 677910178990325760,
  "created_at" : "2015-12-18 17:55:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/677904020275597313\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/SbHKMb1iq2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhmAGsVAAA_3L4.jpg",
      "id_str" : "677903895901831168",
      "id" : 677903895901831168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhmAGsVAAA_3L4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SbHKMb1iq2"
    } ],
    "hashtags" : [ {
      "text" : "2015in5words",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677907884710170625",
  "text" : "RT @PressSec: Longest streak of job growth. #2015in5words https:\/\/t.co\/SbHKMb1iq2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/677904020275597313\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/SbHKMb1iq2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhmAGsVAAA_3L4.jpg",
        "id_str" : "677903895901831168",
        "id" : 677903895901831168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhmAGsVAAA_3L4.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SbHKMb1iq2"
      } ],
      "hashtags" : [ {
        "text" : "2015in5words",
        "indices" : [ 30, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677904020275597313",
    "text" : "Longest streak of job growth. #2015in5words https:\/\/t.co\/SbHKMb1iq2",
    "id" : 677904020275597313,
    "created_at" : "2015-12-18 17:31:27 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 677907884710170625,
  "created_at" : "2015-12-18 17:46:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677905749826248704\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/b2AARdZetZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWhnHO3WEAEAgz6.jpg",
      "id_str" : "677905117866233857",
      "id" : 677905117866233857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWhnHO3WEAEAgz6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/b2AARdZetZ"
    } ],
    "hashtags" : [ {
      "text" : "2015In5Words",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677905749826248704",
  "text" : "Lowest uninsured rate in history. #2015In5Words https:\/\/t.co\/b2AARdZetZ",
  "id" : 677905749826248704,
  "created_at" : "2015-12-18 17:38:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FactsOnClimate\/status\/677902680589737984\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/2KxtEZaGb3",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWhk3mdXAAERD5W.png",
      "id_str" : "677902650298531841",
      "id" : 677902650298531841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWhk3mdXAAERD5W.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2KxtEZaGb3"
    } ],
    "hashtags" : [ {
      "text" : "2015In5Words",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/uLtVMN2A7C",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "677902954276474880",
  "text" : "RT @FactsOnClimate: Global agreement on climate change. https:\/\/t.co\/uLtVMN2A7C #2015In5Words https:\/\/t.co\/2KxtEZaGb3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FactsOnClimate\/status\/677902680589737984\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/2KxtEZaGb3",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWhk3mdXAAERD5W.png",
        "id_str" : "677902650298531841",
        "id" : 677902650298531841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWhk3mdXAAERD5W.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2KxtEZaGb3"
      } ],
      "hashtags" : [ {
        "text" : "2015In5Words",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/uLtVMN2A7C",
        "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
        "display_url" : "go.wh.gov\/ClimateTalks"
      } ]
    },
    "geo" : { },
    "id_str" : "677902680589737984",
    "text" : "Global agreement on climate change. https:\/\/t.co\/uLtVMN2A7C #2015In5Words https:\/\/t.co\/2KxtEZaGb3",
    "id" : 677902680589737984,
    "created_at" : "2015-12-18 17:26:08 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 677902954276474880,
  "created_at" : "2015-12-18 17:27:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2015In5Words",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/9kUvR7bY69",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/ef722fcf-47cc-42a4-98de-40460a870e4f",
      "display_url" : "amp.twimg.com\/v\/ef722fcf-47c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677900213781004288",
  "text" : "Love is love in America. #2015In5Words\nhttps:\/\/t.co\/9kUvR7bY69",
  "id" : 677900213781004288,
  "created_at" : "2015-12-18 17:16:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/xWx35OULS1",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/ae3081fe-2d75-4b84-87a1-374207f01c0d",
      "display_url" : "amp.twimg.com\/v\/ae3081fe-2d7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "677889324902412288",
  "text" : "RT @VP: Jump behind the scenes with the Vice President and see what 36 hours in Kyiv, Ukraine looks like:\nhttps:\/\/t.co\/xWx35OULS1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/xWx35OULS1",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/ae3081fe-2d75-4b84-87a1-374207f01c0d",
        "display_url" : "amp.twimg.com\/v\/ae3081fe-2d7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677884365045534720",
    "text" : "Jump behind the scenes with the Vice President and see what 36 hours in Kyiv, Ukraine looks like:\nhttps:\/\/t.co\/xWx35OULS1",
    "id" : 677884365045534720,
    "created_at" : "2015-12-18 16:13:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 677889324902412288,
  "created_at" : "2015-12-18 16:33:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Running Wild",
      "screen_name" : "NBCRunningWild",
      "indices" : [ 3, 18 ],
      "id_str" : "872085986",
      "id" : 872085986
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NBCRunningWild\/status\/677699752524439552\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/eyuT3yiDHt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWesVWCWUAAlArw.jpg",
      "id_str" : "677699751635210240",
      "id" : 677699751635210240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWesVWCWUAAlArw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eyuT3yiDHt"
    } ],
    "hashtags" : [ {
      "text" : "RunningWild",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677848515842736129",
  "text" : "RT @NBCRunningWild: We only have one planet, let's make it last. #RunningWild https:\/\/t.co\/eyuT3yiDHt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NBCRunningWild\/status\/677699752524439552\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/eyuT3yiDHt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWesVWCWUAAlArw.jpg",
        "id_str" : "677699751635210240",
        "id" : 677699751635210240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWesVWCWUAAlArw.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eyuT3yiDHt"
      } ],
      "hashtags" : [ {
        "text" : "RunningWild",
        "indices" : [ 45, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677699752524439552",
    "text" : "We only have one planet, let's make it last. #RunningWild https:\/\/t.co\/eyuT3yiDHt",
    "id" : 677699752524439552,
    "created_at" : "2015-12-18 03:59:46 +0000",
    "user" : {
      "name" : "Running Wild",
      "screen_name" : "NBCRunningWild",
      "protected" : false,
      "id_str" : "872085986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739915168767823872\/q1tRiEJj_normal.jpg",
      "id" : 872085986,
      "verified" : true
    }
  },
  "id" : 677848515842736129,
  "created_at" : "2015-12-18 13:50:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Running Wild",
      "screen_name" : "NBCRunningWild",
      "indices" : [ 11, 26 ],
      "id_str" : "872085986",
      "id" : 872085986
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Bear Grylls",
      "screen_name" : "BearGrylls",
      "indices" : [ 63, 74 ],
      "id_str" : "41692369",
      "id" : 41692369
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/I29simcZa5",
      "expanded_url" : "http:\/\/nyti.ms\/1MjAs5q",
      "display_url" : "nyti.ms\/1MjAs5q"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/o1BRq4axtE",
      "expanded_url" : "http:\/\/snpy.tv\/1OaqTac",
      "display_url" : "snpy.tv\/1OaqTac"
    } ]
  },
  "geo" : { },
  "id_str" : "677663697096060933",
  "text" : "Tonight on @NBCRunningWild: @POTUS in Alaska's wilderness with @BearGrylls. https:\/\/t.co\/I29simcZa5 #ActOnClimate https:\/\/t.co\/o1BRq4axtE",
  "id" : 677663697096060933,
  "created_at" : "2015-12-18 01:36:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677656088104329217",
  "text" : "RT @rhodes44: After 5 years in a Cuban prison, Alan Gross came home last year. This is why we fight for change. #CubaPolicy https:\/\/t.co\/v8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/677655872919740417\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/v8O3L7VHlI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWeEbNwWIAACuUB.jpg",
        "id_str" : "677655872026320896",
        "id" : 677655872026320896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWeEbNwWIAACuUB.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/v8O3L7VHlI"
      } ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677655872919740417",
    "text" : "After 5 years in a Cuban prison, Alan Gross came home last year. This is why we fight for change. #CubaPolicy https:\/\/t.co\/v8O3L7VHlI",
    "id" : 677655872919740417,
    "created_at" : "2015-12-18 01:05:24 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 677656088104329217,
  "created_at" : "2015-12-18 01:06:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677625036564508672\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/gBKHssgKRY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWdoWtsWsAA89IF.jpg",
      "id_str" : "677625008374591488",
      "id" : 677625008374591488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWdoWtsWsAA89IF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gBKHssgKRY"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677625036564508672",
  "text" : "Here's how @POTUS has improved America's relationship with Cuba over the past year. #CubaPolicy https:\/\/t.co\/gBKHssgKRY",
  "id" : 677625036564508672,
  "created_at" : "2015-12-17 23:02:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677619505988771842",
  "text" : "RT @PressSec: Last press briefing of 2015! @POTUS got a lot done this year, despite some heavy GOP opposition. Here's a rundown. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 29, 35 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/whcKtCPeyC",
        "expanded_url" : "http:\/\/snpy.tv\/1IX0CAa",
        "display_url" : "snpy.tv\/1IX0CAa"
      } ]
    },
    "geo" : { },
    "id_str" : "677619377013841921",
    "text" : "Last press briefing of 2015! @POTUS got a lot done this year, despite some heavy GOP opposition. Here's a rundown. https:\/\/t.co\/whcKtCPeyC",
    "id" : 677619377013841921,
    "created_at" : "2015-12-17 22:40:23 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 677619505988771842,
  "created_at" : "2015-12-17 22:40:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677571500921266176\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/h29JupJKGs",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWc3kJ-XIAQ_XXV.png",
      "id_str" : "677571363234848772",
      "id" : 677571363234848772,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWc3kJ-XIAQ_XXV.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/h29JupJKGs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "677571500921266176",
  "text" : "The U.S. is leading more than 65 partners in an international effort to counter ISIL: https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/h29JupJKGs",
  "id" : 677571500921266176,
  "created_at" : "2015-12-17 19:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/U2DBgHBN4u",
      "expanded_url" : "http:\/\/snpy.tv\/1O9tvoz",
      "display_url" : "snpy.tv\/1O9tvoz"
    } ]
  },
  "geo" : { },
  "id_str" : "677556791086030849",
  "text" : "\"Our greatest allies in this fight are each other, Americans of all faiths\" \u2014@POTUS on countering ISIL https:\/\/t.co\/U2DBgHBN4u",
  "id" : 677556791086030849,
  "created_at" : "2015-12-17 18:31:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677551510524444672",
  "text" : "\"We cannot give in to fear or change how we live our lives\u2014because that\u2019s what terrorists want\" \u2014@POTUS on our fight against ISIL",
  "id" : 677551510524444672,
  "created_at" : "2015-12-17 18:10:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677551195758698496",
  "text" : "\"Our greatest allies in this fight are each other, Americans of all faiths and all backgrounds.\" \u2014@POTUS on combating terrorism here at home",
  "id" : 677551195758698496,
  "created_at" : "2015-12-17 18:09:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677550978124660736",
  "text" : "\"One of our greatest weapons against terrorism is our own strength and resilience as a people.\" \u2014@POTUS on combating terrorism here at home",
  "id" : 677550978124660736,
  "created_at" : "2015-12-17 18:08:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677550831458234369",
  "text" : "RT @NSCPress: \u201CAny refugee coming to America\u2026will continue to get the most intensive scrutiny of any new arrival\u201D-@POTUS https:\/\/t.co\/F4jWU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 100, 106 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/677550762050920452\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/F4jWUPZypr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWckz48UEAAnCLs.jpg",
        "id_str" : "677550742819835904",
        "id" : 677550742819835904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWckz48UEAAnCLs.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/F4jWUPZypr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677550762050920452",
    "text" : "\u201CAny refugee coming to America\u2026will continue to get the most intensive scrutiny of any new arrival\u201D-@POTUS https:\/\/t.co\/F4jWUPZypr",
    "id" : 677550762050920452,
    "created_at" : "2015-12-17 18:07:44 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 677550831458234369,
  "created_at" : "2015-12-17 18:08:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677550641875689472",
  "text" : "\"Across the country, more than 100 joint terrorism task forces are the action arm in this fight\" \u2014@POTUS on U.S. counterterrorism efforts",
  "id" : 677550641875689472,
  "created_at" : "2015-12-17 18:07:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677550166107361281\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/EaI8WeUa3A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWckQXfWoAA6EYp.jpg",
      "id_str" : "677550132544577536",
      "id" : 677550132544577536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWckQXfWoAA6EYp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EaI8WeUa3A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677550166107361281",
  "text" : "\u201CWe\u2019re hitting ISIL harder than ever in Syria and Iraq. We\u2019re taking out their leaders.\" \u2014@POTUS https:\/\/t.co\/EaI8WeUa3A",
  "id" : 677550166107361281,
  "created_at" : "2015-12-17 18:05:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677549183155478528",
  "text" : "\"What matters most\u2014to all of us\u2014is the safety of our families and friends and communities.\" \u2014@POTUS on keeping the American people safe",
  "id" : 677549183155478528,
  "created_at" : "2015-12-17 18:01:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677548440667234304\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/VWkSwv3OoA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWchEsmUkAAdaSa.jpg",
      "id_str" : "677546633517633536",
      "id" : 677546633517633536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWchEsmUkAAdaSa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VWkSwv3OoA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "677548440667234304",
  "text" : "Tune in as @POTUS gives an update on counterterrorism efforts and our fight against ISIL \u2192 https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/VWkSwv3OoA",
  "id" : 677548440667234304,
  "created_at" : "2015-12-17 17:58:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/677535937396625408\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/ucB4zZsjST",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWcXUdwXIAAZhYc.jpg",
      "id_str" : "677535909294841856",
      "id" : 677535909294841856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWcXUdwXIAAZhYc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ucB4zZsjST"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677535937396625408",
  "text" : "Today, we announced that we're restoring scheduled flights between the U.S. and Cuba. #CubaPolicy https:\/\/t.co\/ucB4zZsjST",
  "id" : 677535937396625408,
  "created_at" : "2015-12-17 17:08:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677524863460859904\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/NH6e5NCq3F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWcNM_EXIAA5swd.jpg",
      "id_str" : "677524785681866752",
      "id" : 677524785681866752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWcNM_EXIAA5swd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NH6e5NCq3F"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677524863460859904",
  "text" : "\"Today, the Stars &amp; Stripes again fly over our Embassy in Havana\" \u2014@POTUS on the anniversary of #CubaPolicy changes https:\/\/t.co\/NH6e5NCq3F",
  "id" : 677524863460859904,
  "created_at" : "2015-12-17 16:24:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA Technology",
      "screen_name" : "NASA_Technology",
      "indices" : [ 3, 19 ],
      "id_str" : "159588456",
      "id" : 159588456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NASAtech",
      "indices" : [ 21, 30 ]
    }, {
      "text" : "StarWars",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/l5udEHujH5",
      "expanded_url" : "http:\/\/go.nasa.gov\/1UA6Nva",
      "display_url" : "go.nasa.gov\/1UA6Nva"
    } ]
  },
  "geo" : { },
  "id_str" : "677519121244946432",
  "text" : "RT @NASA_Technology: #NASAtech &amp; #StarWars - from 'TIE'-ins to the droids you're looking for: https:\/\/t.co\/l5udEHujH5 https:\/\/t.co\/enX77xfZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA_Technology\/status\/677189268889018368\/photo\/1",
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/enX77xfZ2P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWXcDTSW4AAcJB4.jpg",
        "id_str" : "677189268264116224",
        "id" : 677189268264116224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWXcDTSW4AAcJB4.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 142,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 858,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/enX77xfZ2P"
      } ],
      "hashtags" : [ {
        "text" : "NASAtech",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "StarWars",
        "indices" : [ 16, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/l5udEHujH5",
        "expanded_url" : "http:\/\/go.nasa.gov\/1UA6Nva",
        "display_url" : "go.nasa.gov\/1UA6Nva"
      } ]
    },
    "geo" : { },
    "id_str" : "677189268889018368",
    "text" : "#NASAtech &amp; #StarWars - from 'TIE'-ins to the droids you're looking for: https:\/\/t.co\/l5udEHujH5 https:\/\/t.co\/enX77xfZ2P",
    "id" : 677189268889018368,
    "created_at" : "2015-12-16 18:11:17 +0000",
    "user" : {
      "name" : "NASA Technology",
      "screen_name" : "NASA_Technology",
      "protected" : false,
      "id_str" : "159588456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1074223648\/nasalogo_twitter_normal.jpg",
      "id" : 159588456,
      "verified" : true
    }
  },
  "id" : 677519121244946432,
  "created_at" : "2015-12-17 16:02:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC Newsnight",
      "screen_name" : "BBCNewsnight",
      "indices" : [ 3, 16 ],
      "id_str" : "20543416",
      "id" : 20543416
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/PW9lUDzywq",
      "expanded_url" : "http:\/\/snpy.tv\/1k13bFf",
      "display_url" : "snpy.tv\/1k13bFf"
    } ]
  },
  "geo" : { },
  "id_str" : "677509660241321985",
  "text" : "RT @BBCNewsnight: Is ISIS rational? President Obama's Special Envoy Brett McGurk says no. https:\/\/t.co\/PW9lUDzywq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/PW9lUDzywq",
        "expanded_url" : "http:\/\/snpy.tv\/1k13bFf",
        "display_url" : "snpy.tv\/1k13bFf"
      } ]
    },
    "geo" : { },
    "id_str" : "676901691850162176",
    "text" : "Is ISIS rational? President Obama's Special Envoy Brett McGurk says no. https:\/\/t.co\/PW9lUDzywq",
    "id" : 676901691850162176,
    "created_at" : "2015-12-15 23:08:34 +0000",
    "user" : {
      "name" : "BBC Newsnight",
      "screen_name" : "BBCNewsnight",
      "protected" : false,
      "id_str" : "20543416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637357895907155968\/vOmgZVsm_normal.jpg",
      "id" : 20543416,
      "verified" : true
    }
  },
  "id" : 677509660241321985,
  "created_at" : "2015-12-17 15:24:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 96, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677503660788707328",
  "text" : "RT @vj44: Join my weekly office hours at 2pm ET. Send in your q's &amp; ideas on re-entry &amp; #CriminalJusticeReform on Facebook\u2192 https:\/\/t.co\/8T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 86, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 145 ],
        "url" : "https:\/\/t.co\/8TWfIN9vZq",
        "expanded_url" : "https:\/\/www.facebook.com\/WhiteHouse\/posts\/10153965293689238",
        "display_url" : "facebook.com\/WhiteHouse\/pos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "677503435751743489",
    "text" : "Join my weekly office hours at 2pm ET. Send in your q's &amp; ideas on re-entry &amp; #CriminalJusticeReform on Facebook\u2192 https:\/\/t.co\/8TWfIN9vZq",
    "id" : 677503435751743489,
    "created_at" : "2015-12-17 14:59:41 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 677503660788707328,
  "created_at" : "2015-12-17 15:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677496057689960448",
  "text" : "RT @rhodes44: Big news: Exactly one year since @POTUS changed course in Cuba, we've now agreed to restore scheduled flights between the U.S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 33, 39 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677496025687285760",
    "text" : "Big news: Exactly one year since @POTUS changed course in Cuba, we've now agreed to restore scheduled flights between the U.S. &amp; Cuba.",
    "id" : 677496025687285760,
    "created_at" : "2015-12-17 14:30:14 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 677496057689960448,
  "created_at" : "2015-12-17 14:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Itzhak Perlman",
      "screen_name" : "PerlmanOfficial",
      "indices" : [ 73, 89 ],
      "id_str" : "858628634",
      "id" : 858628634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/68ayDdRN4Y",
      "expanded_url" : "http:\/\/go.wh.gov\/NewCitizens",
      "display_url" : "go.wh.gov\/NewCitizens"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/5QsDvSZF6c",
      "expanded_url" : "http:\/\/snpy.tv\/1IUTS5I",
      "display_url" : "snpy.tv\/1IUTS5I"
    } ]
  },
  "geo" : { },
  "id_str" : "677303985368399872",
  "text" : "\"This land is full of immigrants. That's how this land is interesting.\" \u2014@PerlmanOfficial: https:\/\/t.co\/68ayDdRN4Y https:\/\/t.co\/5QsDvSZF6c",
  "id" : 677303985368399872,
  "created_at" : "2015-12-17 01:47:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 17, 31 ],
      "id_str" : "16581604",
      "id" : 16581604
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677280064988446721\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/MsojTNA7Rd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWYuQXbXAAEq6NS.jpg",
      "id_str" : "677279652667392001",
      "id" : 677279652667392001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWYuQXbXAAEq6NS.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MsojTNA7Rd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/vIMwdGY0us",
      "expanded_url" : "http:\/\/go.wh.gov\/fXCMm6",
      "display_url" : "go.wh.gov\/fXCMm6"
    } ]
  },
  "geo" : { },
  "id_str" : "677280064988446721",
  "text" : ".@POTUS met with @MikeBloomberg today to discuss reducing gun violence and climate change \u2192 https:\/\/t.co\/vIMwdGY0us https:\/\/t.co\/MsojTNA7Rd",
  "id" : 677280064988446721,
  "created_at" : "2015-12-17 00:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677242822920151045\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/RBwxJSkfSI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWYMnTEVAAE9JW_.jpg",
      "id_str" : "677242663238696961",
      "id" : 677242663238696961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWYMnTEVAAE9JW_.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RBwxJSkfSI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677242822920151045",
  "text" : "FACT: 82% of high school students are earning their diploma\u2014the highest rate ever. https:\/\/t.co\/RBwxJSkfSI",
  "id" : 677242822920151045,
  "created_at" : "2015-12-16 21:44:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677224759483097088",
  "text" : "RT @POTUS: Congrats on a great career, Abby Wambach. For the goals you\u2019ve scored &amp; the kids you\u2019ve inspired, you\u2019re the GOAT! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/677222716303364098\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/Kud56ChsBO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWX6eMYU4AEljDq.jpg",
        "id_str" : "677222715615404033",
        "id" : 677222715615404033,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWX6eMYU4AEljDq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Kud56ChsBO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "677222716303364098",
    "text" : "Congrats on a great career, Abby Wambach. For the goals you\u2019ve scored &amp; the kids you\u2019ve inspired, you\u2019re the GOAT! https:\/\/t.co\/Kud56ChsBO",
    "id" : 677222716303364098,
    "created_at" : "2015-12-16 20:24:12 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 677224759483097088,
  "created_at" : "2015-12-16 20:32:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gloria Estefan",
      "screen_name" : "GloriaEstefan",
      "indices" : [ 63, 77 ],
      "id_str" : "270005881",
      "id" : 270005881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/b0OyhbqTCX",
      "expanded_url" : "http:\/\/snpy.tv\/1k3dyZm",
      "display_url" : "snpy.tv\/1k3dyZm"
    } ]
  },
  "geo" : { },
  "id_str" : "677215796444180480",
  "text" : "\"We have to be the nation that continues to open their arms.\" \u2014@GloriaEstefan on welcoming #NewAmericans https:\/\/t.co\/b0OyhbqTCX",
  "id" : 677215796444180480,
  "created_at" : "2015-12-16 19:56:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677195795150557185",
  "text" : "RT @arneduncan: Proud of the educators, parents, counselors, &amp; students for the hard work to raise the HS grad rate to 82%!\nhttps:\/\/t.co\/X4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/X4LzL7sG41",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/3bcddbfb-0542-4fd6-a2a7-2adc7aa49d73",
        "display_url" : "amp.twimg.com\/v\/3bcddbfb-054\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "676939163350904832",
    "text" : "Proud of the educators, parents, counselors, &amp; students for the hard work to raise the HS grad rate to 82%!\nhttps:\/\/t.co\/X4LzL7sG41",
    "id" : 676939163350904832,
    "created_at" : "2015-12-16 01:37:28 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 677195795150557185,
  "created_at" : "2015-12-16 18:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677189256834609152\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/C4h5JdIvwQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWXb5CRWwAEKaiB.jpg",
      "id_str" : "677189091897819137",
      "id" : 677189091897819137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWXb5CRWwAEKaiB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C4h5JdIvwQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Ih564hAo2u",
      "expanded_url" : "http:\/\/wapo.st\/1m40Mei",
      "display_url" : "wapo.st\/1m40Mei"
    } ]
  },
  "geo" : { },
  "id_str" : "677189256834609152",
  "text" : "Good news: America's high school graduation rate has increased to an all-time high.\uD83C\uDF93 https:\/\/t.co\/Ih564hAo2u https:\/\/t.co\/C4h5JdIvwQ",
  "id" : 677189256834609152,
  "created_at" : "2015-12-16 18:11:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/677172889104359424\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/SQY8DQJJqo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWXMtuJWcAENpoH.jpg",
      "id_str" : "677172404842557441",
      "id" : 677172404842557441,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWXMtuJWcAENpoH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SQY8DQJJqo"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/5zeR2S7xZe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "677172889104359424",
  "text" : "Deadline extended: #GetCovered by December 17 for health coverage starting January 1 at https:\/\/t.co\/5zeR2S7xZe. https:\/\/t.co\/SQY8DQJJqo",
  "id" : 677172889104359424,
  "created_at" : "2015-12-16 17:06:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/67QOOuDNuA",
      "expanded_url" : "http:\/\/snpy.tv\/1QqJGo2",
      "display_url" : "snpy.tv\/1QqJGo2"
    } ]
  },
  "geo" : { },
  "id_str" : "676901899690471425",
  "text" : "\"We can never say it often or loudly enough: Immigrants, and refugees, revitalize and renew America.\" \u2014@POTUS https:\/\/t.co\/67QOOuDNuA",
  "id" : 676901899690471425,
  "created_at" : "2015-12-15 23:09:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Estefan",
      "screen_name" : "EmilioEstefanJr",
      "indices" : [ 24, 40 ],
      "id_str" : "718762573",
      "id" : 718762573
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/VzlInelb7i",
      "expanded_url" : "http:\/\/go.wh.gov\/6BEUS8",
      "display_url" : "go.wh.gov\/6BEUS8"
    } ]
  },
  "geo" : { },
  "id_str" : "676875640130301954",
  "text" : "\"We come for freedom.\" \u2014@EmilioEstefanJr on what it's like to become #NewAmericans: https:\/\/t.co\/VzlInelb7i",
  "id" : 676875640130301954,
  "created_at" : "2015-12-15 21:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Andr\u00E9s",
      "screen_name" : "chefjoseandres",
      "indices" : [ 6, 21 ],
      "id_str" : "73206956",
      "id" : 73206956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/qoqoIyD5CU",
      "expanded_url" : "http:\/\/go.wh.gov\/i3p72J",
      "display_url" : "go.wh.gov\/i3p72J"
    } ]
  },
  "geo" : { },
  "id_str" : "676869433235664896",
  "text" : "Watch @ChefJoseAndres tell his story about becoming an American citizen, and encourage others to take the next step: https:\/\/t.co\/qoqoIyD5CU",
  "id" : 676869433235664896,
  "created_at" : "2015-12-15 21:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Estefan",
      "screen_name" : "EmilioEstefanJr",
      "indices" : [ 6, 22 ],
      "id_str" : "718762573",
      "id" : 718762573
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/VzlInelb7i",
      "expanded_url" : "http:\/\/go.wh.gov\/6BEUS8",
      "display_url" : "go.wh.gov\/6BEUS8"
    } ]
  },
  "geo" : { },
  "id_str" : "676853013256900611",
  "text" : "Watch @EmilioEstefanJr share what it means to become an American citizen. #NewAmericans https:\/\/t.co\/VzlInelb7i",
  "id" : 676853013256900611,
  "created_at" : "2015-12-15 19:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Andr\u00E9s",
      "screen_name" : "chefjoseandres",
      "indices" : [ 82, 97 ],
      "id_str" : "73206956",
      "id" : 73206956
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/qoqoIyD5CU",
      "expanded_url" : "http:\/\/go.wh.gov\/i3p72J",
      "display_url" : "go.wh.gov\/i3p72J"
    } ]
  },
  "geo" : { },
  "id_str" : "676846791489282048",
  "text" : "\"I am the type of guy that believes that the American Dream still exists today.\" \u2014@ChefJoseAndres #NewAmericans https:\/\/t.co\/qoqoIyD5CU",
  "id" : 676846791489282048,
  "created_at" : "2015-12-15 19:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/676836542799736832\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/4XCD2KmDaj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWSbNvxUsAAEfNA.jpg",
      "id_str" : "676836504476364800",
      "id" : 676836504476364800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWSbNvxUsAAEfNA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4XCD2KmDaj"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 16, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/5zeR2RPWAE",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "676836542799736832",
  "text" : "DEADLINE TODAY: #GetCovered now for health coverage that starts on January 1 \u2192 https:\/\/t.co\/5zeR2RPWAE https:\/\/t.co\/4XCD2KmDaj",
  "id" : 676836542799736832,
  "created_at" : "2015-12-15 18:49:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/anwSjXh4J8",
      "expanded_url" : "http:\/\/snpy.tv\/1O3dOiG",
      "display_url" : "snpy.tv\/1O3dOiG"
    } ]
  },
  "geo" : { },
  "id_str" : "676820547121098752",
  "text" : "\u201CWe must resolve to always speak out against hatred and bigotry in all of its forms\u201D \u2014@POTUS #NewAmericans https:\/\/t.co\/anwSjXh4J8",
  "id" : 676820547121098752,
  "created_at" : "2015-12-15 17:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676813157554372608",
  "text" : "\"No matter who we are or what we look like, or who we love, or what we believe, we can make of our lives what we will\" \u2014@POTUS #NewAmericans",
  "id" : 676813157554372608,
  "created_at" : "2015-12-15 17:16:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676812000241049600",
  "text" : "\"America. A place where we can be a part of something bigger\u2014a place where we can contribute our talents and fulfill our ambitions\" \u2014@POTUS",
  "id" : 676812000241049600,
  "created_at" : "2015-12-15 17:12:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676810990030311425",
  "text" : "\u201CWe must resolve to always speak out against hatred and bigotry in all its forms\u201D \u2014@POTUS #NewAmericans",
  "id" : 676810990030311425,
  "created_at" : "2015-12-15 17:08:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/68ayDdRN4Y",
      "expanded_url" : "http:\/\/go.wh.gov\/NewCitizens",
      "display_url" : "go.wh.gov\/NewCitizens"
    } ]
  },
  "geo" : { },
  "id_str" : "676809876367122432",
  "text" : "\"We can never say it often or loudly enough: Immigrants, and refugees, revitalize and renew America.\" \u2014@POTUS: https:\/\/t.co\/68ayDdRN4Y",
  "id" : 676809876367122432,
  "created_at" : "2015-12-15 17:03:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "US National Archives",
      "screen_name" : "USNatArchives",
      "indices" : [ 117, 131 ],
      "id_str" : "101802390",
      "id" : 101802390
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676809059736113152",
  "text" : "\"After all, unless your family is Native American, our families...come from someplace else\" \u2014@POTUS to #NewAmericans @USNatArchives",
  "id" : 676809059736113152,
  "created_at" : "2015-12-15 17:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676808871353131011",
  "text" : "\u201CWe don\u2019t simply welcome new arrivals, we are born of immigrants. That is who we are.\u201D \u2014@POTUS to #NewAmericans",
  "id" : 676808871353131011,
  "created_at" : "2015-12-15 16:59:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/68ayDdRN4Y",
      "expanded_url" : "http:\/\/go.wh.gov\/NewCitizens",
      "display_url" : "go.wh.gov\/NewCitizens"
    } ]
  },
  "geo" : { },
  "id_str" : "676808317260447744",
  "text" : "\"I am proud to be among the first to greet you as \u2018my fellow Americans.\u2019\u201D\u2014@POTUS welcomes #NewAmericans: https:\/\/t.co\/68ayDdRN4Y",
  "id" : 676808317260447744,
  "created_at" : "2015-12-15 16:57:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/676802333066399744\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/AUuUreCIg7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWR7vmnUwAEiLef.png",
      "id_str" : "676801901761970177",
      "id" : 676801901761970177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWR7vmnUwAEiLef.png",
      "sizes" : [ {
        "h" : 469,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AUuUreCIg7"
    } ],
    "hashtags" : [ {
      "text" : "NewAmericans",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/HT71cVwF9L",
      "expanded_url" : "http:\/\/go.wh.gov\/pkzu97",
      "display_url" : "go.wh.gov\/pkzu97"
    } ]
  },
  "geo" : { },
  "id_str" : "676802333066399744",
  "text" : "Tune in: @POTUS welcomes #NewAmericans during a Naturalization Ceremony.  https:\/\/t.co\/HT71cVwF9L https:\/\/t.co\/AUuUreCIg7",
  "id" : 676802333066399744,
  "created_at" : "2015-12-15 16:33:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Politics",
      "screen_name" : "YahooPolitics",
      "indices" : [ 3, 17 ],
      "id_str" : "3015101849",
      "id" : 3015101849
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Olivier Knox",
      "screen_name" : "OKnox",
      "indices" : [ 48, 54 ],
      "id_str" : "11771512",
      "id" : 11771512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ycuba",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/zqHAKxRK9r",
      "expanded_url" : "http:\/\/yhoo.it\/1P1YGYg",
      "display_url" : "yhoo.it\/1P1YGYg"
    } ]
  },
  "geo" : { },
  "id_str" : "676568745641246722",
  "text" : "RT @YahooPolitics: Exclusive: @POTUS spoke with @OKnox about conditions for a potential visit to Cuba https:\/\/t.co\/zqHAKxRK9r #ycuba https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Olivier Knox",
        "screen_name" : "OKnox",
        "indices" : [ 29, 35 ],
        "id_str" : "11771512",
        "id" : 11771512
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/YahooPolitics\/status\/676374451710246912\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/nJBCmTEQ7i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWL2-tQXIAAqsvC.jpg",
        "id_str" : "676374451219537920",
        "id" : 676374451219537920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWL2-tQXIAAqsvC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 540
        } ],
        "display_url" : "pic.twitter.com\/nJBCmTEQ7i"
      } ],
      "hashtags" : [ {
        "text" : "ycuba",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/zqHAKxRK9r",
        "expanded_url" : "http:\/\/yhoo.it\/1P1YGYg",
        "display_url" : "yhoo.it\/1P1YGYg"
      } ]
    },
    "geo" : { },
    "id_str" : "676374451710246912",
    "text" : "Exclusive: @POTUS spoke with @OKnox about conditions for a potential visit to Cuba https:\/\/t.co\/zqHAKxRK9r #ycuba https:\/\/t.co\/nJBCmTEQ7i",
    "id" : 676374451710246912,
    "created_at" : "2015-12-14 12:13:30 +0000",
    "user" : {
      "name" : "Yahoo Politics",
      "screen_name" : "YahooPolitics",
      "protected" : false,
      "id_str" : "3015101849",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562995632118329344\/8DA2Us8W_normal.png",
      "id" : 3015101849,
      "verified" : true
    }
  },
  "id" : 676568745641246722,
  "created_at" : "2015-12-15 01:05:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Mayor Tom Barrett",
      "screen_name" : "MayorOfMKE",
      "indices" : [ 16, 27 ],
      "id_str" : "1022863572",
      "id" : 1022863572
    }, {
      "name" : "Mayor Mike Duggan",
      "screen_name" : "MayorMikeDuggan",
      "indices" : [ 28, 44 ],
      "id_str" : "822713107",
      "id" : 822713107
    }, {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "indices" : [ 45, 60 ],
      "id_str" : "202790178",
      "id" : 202790178
    }, {
      "name" : "Jim Kenney",
      "screen_name" : "JimFKenney",
      "indices" : [ 67, 78 ],
      "id_str" : "376874694",
      "id" : 376874694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676564866908442624",
  "text" : "RT @vj44: Kudos @MayorofMKE @MayorMikeDuggan @Michael_Nutter &amp; @JimFKenney for leading the Healthy Communities Challenge pack! https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mayor Tom Barrett",
        "screen_name" : "MayorOfMKE",
        "indices" : [ 6, 17 ],
        "id_str" : "1022863572",
        "id" : 1022863572
      }, {
        "name" : "Mayor Mike Duggan",
        "screen_name" : "MayorMikeDuggan",
        "indices" : [ 18, 34 ],
        "id_str" : "822713107",
        "id" : 822713107
      }, {
        "name" : "Michael A. Nutter",
        "screen_name" : "Michael_Nutter",
        "indices" : [ 35, 50 ],
        "id_str" : "202790178",
        "id" : 202790178
      }, {
        "name" : "Jim Kenney",
        "screen_name" : "JimFKenney",
        "indices" : [ 57, 68 ],
        "id_str" : "376874694",
        "id" : 376874694
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/676547282746122240\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/k1Eqom3g9t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWOUKygVEAA4-VF.jpg",
        "id_str" : "676547282112679936",
        "id" : 676547282112679936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWOUKygVEAA4-VF.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/k1Eqom3g9t"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676547282746122240",
    "text" : "Kudos @MayorofMKE @MayorMikeDuggan @Michael_Nutter &amp; @JimFKenney for leading the Healthy Communities Challenge pack! https:\/\/t.co\/k1Eqom3g9t",
    "id" : 676547282746122240,
    "created_at" : "2015-12-14 23:40:16 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 676564866908442624,
  "created_at" : "2015-12-15 00:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/676561410277666816\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/roblPY1dlY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWOgewlWsAESbiD.jpg",
      "id_str" : "676560819333804033",
      "id" : 676560819333804033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWOgewlWsAESbiD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/roblPY1dlY"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/5r9E9h6WeU",
      "expanded_url" : "http:\/\/go.wh.gov\/GetCovered",
      "display_url" : "go.wh.gov\/GetCovered"
    } ]
  },
  "geo" : { },
  "id_str" : "676561410277666816",
  "text" : "RT to spread the word: #GetCovered by Dec. 15 for health coverage beginning Jan. 1 \u2192 https:\/\/t.co\/5r9E9h6WeU https:\/\/t.co\/roblPY1dlY",
  "id" : 676561410277666816,
  "created_at" : "2015-12-15 00:36:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Serena Williams",
      "screen_name" : "serenawilliams",
      "indices" : [ 21, 36 ],
      "id_str" : "26589987",
      "id" : 26589987
    }, {
      "name" : "Sports Illustrated",
      "screen_name" : "SInow",
      "indices" : [ 52, 58 ],
      "id_str" : "28370738",
      "id" : 28370738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676560129504989185",
  "text" : "RT @FLOTUS: Congrats @SerenaWilliams on being named @SInow Sportsperson of the Year! Girls everywhere are dreaming bigger because of you. -\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Serena Williams",
        "screen_name" : "serenawilliams",
        "indices" : [ 9, 24 ],
        "id_str" : "26589987",
        "id" : 26589987
      }, {
        "name" : "Sports Illustrated",
        "screen_name" : "SInow",
        "indices" : [ 40, 46 ],
        "id_str" : "28370738",
        "id" : 28370738
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676470878666940417",
    "text" : "Congrats @SerenaWilliams on being named @SInow Sportsperson of the Year! Girls everywhere are dreaming bigger because of you. -mo",
    "id" : 676470878666940417,
    "created_at" : "2015-12-14 18:36:40 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 676560129504989185,
  "created_at" : "2015-12-15 00:31:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/676552548065648640\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/LwaXhHIgNT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWOY6IgWwAALMAh.png",
      "id_str" : "676552493518733312",
      "id" : 676552493518733312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWOY6IgWwAALMAh.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LwaXhHIgNT"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 4, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/QscCX2jF76",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "676552548065648640",
  "text" : "The #ParisAgreement lays the foundation for keeping global temperature rise below 2\u00B0 C. https:\/\/t.co\/QscCX2jF76 https:\/\/t.co\/LwaXhHIgNT",
  "id" : 676552548065648640,
  "created_at" : "2015-12-15 00:01:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 4, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Bm56JgiQjT",
      "expanded_url" : "http:\/\/snpy.tv\/1RKLLKN",
      "display_url" : "snpy.tv\/1RKLLKN"
    } ]
  },
  "geo" : { },
  "id_str" : "676541339987673088",
  "text" : "The #ParisAgreement will help ensure that this planet will be in better shape for the next generation. https:\/\/t.co\/Bm56JgiQjT",
  "id" : 676541339987673088,
  "created_at" : "2015-12-14 23:16:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Malley",
      "screen_name" : "robmalley44",
      "indices" : [ 25, 37 ],
      "id_str" : "4418090668",
      "id" : 4418090668
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676528852542365703",
  "text" : "RT @NSCPress: At 6pm ET, @RobMalley44 \u2013 Senior Advisor to @POTUS for the Counter-ISIL Campaign \u2013 will answer your questions. Ask here: #Nat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rob Malley",
        "screen_name" : "robmalley44",
        "indices" : [ 11, 23 ],
        "id_str" : "4418090668",
        "id" : 4418090668
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 44, 50 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NatlSecurityChat",
        "indices" : [ 121, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676527816171610113",
    "text" : "At 6pm ET, @RobMalley44 \u2013 Senior Advisor to @POTUS for the Counter-ISIL Campaign \u2013 will answer your questions. Ask here: #NatlSecurityChat",
    "id" : 676527816171610113,
    "created_at" : "2015-12-14 22:22:55 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 676528852542365703,
  "created_at" : "2015-12-14 22:27:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676526280850997249",
  "text" : "RT @VP: We said \"now is the time\" then. Folks, yesterday was the time. How many more children have to be gunned down before we act? #SandyH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SandyHook",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "676524102199476225",
    "geo" : { },
    "id_str" : "676525964218793988",
    "in_reply_to_user_id" : 325830217,
    "text" : "We said \"now is the time\" then. Folks, yesterday was the time. How many more children have to be gunned down before we act? #SandyHook",
    "id" : 676525964218793988,
    "in_reply_to_status_id" : 676524102199476225,
    "created_at" : "2015-12-14 22:15:33 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 676526280850997249,
  "created_at" : "2015-12-14 22:16:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676525753870209029",
  "text" : "RT @VP: Since that nightmare, an estimated 555 children have been killed by guns in America. It is shameful that Congress hasn't acted.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "676522716623724549",
    "geo" : { },
    "id_str" : "676524102199476225",
    "in_reply_to_user_id" : 325830217,
    "text" : "Since that nightmare, an estimated 555 children have been killed by guns in America. It is shameful that Congress hasn't acted.",
    "id" : 676524102199476225,
    "in_reply_to_status_id" : 676522716623724549,
    "created_at" : "2015-12-14 22:08:09 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 676525753870209029,
  "created_at" : "2015-12-14 22:14:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676523413343744000",
  "text" : "RT @VP: 26 angels in Heaven, taken from us three years ago in Newtown. Their families will never be the same.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676522716623724549",
    "text" : "26 angels in Heaven, taken from us three years ago in Newtown. Their families will never be the same.",
    "id" : 676522716623724549,
    "created_at" : "2015-12-14 22:02:39 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 676523413343744000,
  "created_at" : "2015-12-14 22:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Malley",
      "screen_name" : "robmalley44",
      "indices" : [ 3, 15 ],
      "id_str" : "4418090668",
      "id" : 4418090668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NatlSecurityChat",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676518670781272064",
  "text" : "RT @robmalley44: At 6pm ET, I will be answering questions on the U.S. campaign against ISIL. Ask &amp; follow along \u2192 #NatlSecurityChat https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NatlSecurityChat",
        "indices" : [ 101, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/poQOBI1NLh",
        "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
        "display_url" : "go.wh.gov\/ISIL"
      } ]
    },
    "geo" : { },
    "id_str" : "676516953779867648",
    "text" : "At 6pm ET, I will be answering questions on the U.S. campaign against ISIL. Ask &amp; follow along \u2192 #NatlSecurityChat https:\/\/t.co\/poQOBI1NLh",
    "id" : 676516953779867648,
    "created_at" : "2015-12-14 21:39:45 +0000",
    "user" : {
      "name" : "Rob Malley",
      "screen_name" : "robmalley44",
      "protected" : false,
      "id_str" : "4418090668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675032549035520000\/-fp_kyrD_normal.jpg",
      "id" : 4418090668,
      "verified" : true
    }
  },
  "id" : 676518670781272064,
  "created_at" : "2015-12-14 21:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/676493469687377922\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/2XSAZTwpeu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWNjEKDXIAEOhj-.png",
      "id_str" : "676493292104785921",
      "id" : 676493292104785921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWNjEKDXIAEOhj-.png",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2XSAZTwpeu"
    } ],
    "hashtags" : [ {
      "text" : "SandyHook",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/KF5QTtffcJ",
      "expanded_url" : "http:\/\/on.fb.me\/1RNWEvn",
      "display_url" : "on.fb.me\/1RNWEvn"
    } ]
  },
  "geo" : { },
  "id_str" : "676493469687377922",
  "text" : "Three years later: @POTUS on the tragic #SandyHook shooting in Newtown https:\/\/t.co\/KF5QTtffcJ https:\/\/t.co\/2XSAZTwpeu",
  "id" : 676493469687377922,
  "created_at" : "2015-12-14 20:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/676485720475885568\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/MN7RjAENab",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWNcEQkWsAAeFRj.jpg",
      "id_str" : "676485597272387584",
      "id" : 676485597272387584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWNcEQkWsAAeFRj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MN7RjAENab"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "676485720475885568",
  "text" : "\"We\u2019re taking out ISIL leaders, commanders and killers, one by one.\" \u2014@POTUS: https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/MN7RjAENab",
  "id" : 676485720475885568,
  "created_at" : "2015-12-14 19:35:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    }, {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Hc1uNP9SyP",
      "expanded_url" : "http:\/\/snpy.tv\/1O05CzT",
      "display_url" : "snpy.tv\/1O05CzT"
    } ]
  },
  "geo" : { },
  "id_str" : "676462512414572545",
  "text" : "Watch @POTUS give an update on our fight against ISIL from the Pentagon: https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/Hc1uNP9SyP",
  "id" : 676462512414572545,
  "created_at" : "2015-12-14 18:03:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676460240993280000",
  "text" : "\"The Department of Homeland Security is updating its alert system to help the American people stay vigilant and safe.\" \u2014@POTUS",
  "id" : 676460240993280000,
  "created_at" : "2015-12-14 17:54:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/676459434328084485\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/bdctz8g7JA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWNELPnWIAAlgRL.jpg",
      "id_str" : "676459328996515840",
      "id" : 676459328996515840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWNELPnWIAAlgRL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bdctz8g7JA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "676459434328084485",
  "text" : "\"ISIL\u2019s leaders cannot hide.\" \u2014@POTUS: https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/bdctz8g7JA",
  "id" : 676459434328084485,
  "created_at" : "2015-12-14 17:51:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/676459170862907393\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/C0Ey4tqdUo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWNEB-VWcAAo2sT.jpg",
      "id_str" : "676459169738813440",
      "id" : 676459169738813440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWNEB-VWcAAo2sT.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C0Ey4tqdUo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676459170862907393",
  "text" : "\"In November, we dropped more bombs on ISIL targets than in any other month since this campaign started.\" \u2014@POTUS https:\/\/t.co\/C0Ey4tqdUo",
  "id" : 676459170862907393,
  "created_at" : "2015-12-14 17:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/676459051727851520\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/LLO7M4IJJt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWND2ouWoAEV2Kv.jpg",
      "id_str" : "676458974959542273",
      "id" : 676458974959542273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWND2ouWoAEV2Kv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LLO7M4IJJt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676459051727851520",
  "text" : "\"Coalition aircraft\u2014our fighters, bombers and drones\u2014have been increasing the pace of airstrikes\" \u2014@POTUS https:\/\/t.co\/LLO7M4IJJt",
  "id" : 676459051727851520,
  "created_at" : "2015-12-14 17:49:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676458557445926913",
  "text" : "\"The United States and our armed forces continue to lead the global coalition in our mission to destroy the terrorist group ISIL.\" \u2014@POTUS",
  "id" : 676458557445926913,
  "created_at" : "2015-12-14 17:47:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "676458436637388800",
  "text" : "Tune in now as @POTUS gives an update on our fight against ISIL from the Pentagon \u2192 https:\/\/t.co\/oDIQ2UMleK",
  "id" : 676458436637388800,
  "created_at" : "2015-12-14 17:47:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Malley",
      "screen_name" : "robmalley44",
      "indices" : [ 3, 15 ],
      "id_str" : "4418090668",
      "id" : 4418090668
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/poQOBI1NLh",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "676445663677317121",
  "text" : "RT @robmalley44: \"We will destroy ISIL and any other organization that tries to harm us.\" \u2014@POTUS: https:\/\/t.co\/poQOBI1NLh https:\/\/t.co\/oSL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 74, 80 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/robmalley44\/status\/676445322013376513\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/oSLN4ZBVtQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWM3bf9WEAAl8pF.jpg",
        "id_str" : "676445314610499584",
        "id" : 676445314610499584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWM3bf9WEAAl8pF.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oSLN4ZBVtQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/poQOBI1NLh",
        "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
        "display_url" : "go.wh.gov\/ISIL"
      } ]
    },
    "geo" : { },
    "id_str" : "676445322013376513",
    "text" : "\"We will destroy ISIL and any other organization that tries to harm us.\" \u2014@POTUS: https:\/\/t.co\/poQOBI1NLh https:\/\/t.co\/oSLN4ZBVtQ",
    "id" : 676445322013376513,
    "created_at" : "2015-12-14 16:55:07 +0000",
    "user" : {
      "name" : "Rob Malley",
      "screen_name" : "robmalley44",
      "protected" : false,
      "id_str" : "4418090668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675032549035520000\/-fp_kyrD_normal.jpg",
      "id" : 4418090668,
      "verified" : true
    }
  },
  "id" : 676445663677317121,
  "created_at" : "2015-12-14 16:56:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/676443087820951552\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/okB9BU57pN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWM1Q91WEAEoIpV.jpg",
      "id_str" : "676442934628192257",
      "id" : 676442934628192257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWM1Q91WEAEoIpV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/okB9BU57pN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "676443087820951552",
  "text" : "Watch @POTUS give an update on our fight against ISIL at 12:25pm ET from the Pentagon \u2192 https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/okB9BU57pN",
  "id" : 676443087820951552,
  "created_at" : "2015-12-14 16:46:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "Daily Intelligencer",
      "screen_name" : "intelligencer",
      "indices" : [ 90, 104 ],
      "id_str" : "45565185",
      "id" : 45565185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/V6jL0ksjRV",
      "expanded_url" : "http:\/\/nym.ag\/1TL4KUc",
      "display_url" : "nym.ag\/1TL4KUc"
    } ]
  },
  "geo" : { },
  "id_str" : "676424479166308352",
  "text" : "RT @FactsOnClimate: \"The Paris climate deal is President Obama\u2019s biggest accomplishment\" \u2014@Intelligencer: https:\/\/t.co\/V6jL0ksjRV https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daily Intelligencer",
        "screen_name" : "intelligencer",
        "indices" : [ 70, 84 ],
        "id_str" : "45565185",
        "id" : 45565185
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/676424214203772928\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/OOwh8KGTDu",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWMj2KVWwAEOhnX.png",
        "id_str" : "676423782429540353",
        "id" : 676423782429540353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWMj2KVWwAEOhnX.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OOwh8KGTDu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/V6jL0ksjRV",
        "expanded_url" : "http:\/\/nym.ag\/1TL4KUc",
        "display_url" : "nym.ag\/1TL4KUc"
      } ]
    },
    "geo" : { },
    "id_str" : "676424214203772928",
    "text" : "\"The Paris climate deal is President Obama\u2019s biggest accomplishment\" \u2014@Intelligencer: https:\/\/t.co\/V6jL0ksjRV https:\/\/t.co\/OOwh8KGTDu",
    "id" : 676424214203772928,
    "created_at" : "2015-12-14 15:31:14 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 676424479166308352,
  "created_at" : "2015-12-14 15:32:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/Kgb9s847bx",
      "expanded_url" : "http:\/\/snpy.tv\/1IOEYxG",
      "display_url" : "snpy.tv\/1IOEYxG"
    } ]
  },
  "geo" : { },
  "id_str" : "676217939666837505",
  "text" : "Go behind the scenes with @POTUS during Hanukkah at the White House. https:\/\/t.co\/Kgb9s847bx",
  "id" : 676217939666837505,
  "created_at" : "2015-12-14 01:51:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Bm56JgArIt",
      "expanded_url" : "http:\/\/snpy.tv\/1RKLLKN",
      "display_url" : "snpy.tv\/1RKLLKN"
    } ]
  },
  "geo" : { },
  "id_str" : "676134527371227136",
  "text" : "Here's how the #ParisAgreement will make sure our planet will be in better shape for the next generation. https:\/\/t.co\/Bm56JgArIt",
  "id" : 676134527371227136,
  "created_at" : "2015-12-13 20:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/YRlT3QQEIa",
      "expanded_url" : "http:\/\/snpy.tv\/1jUlRGH",
      "display_url" : "snpy.tv\/1jUlRGH"
    } ]
  },
  "geo" : { },
  "id_str" : "676123944420777985",
  "text" : "\"That\u2019s the message I hope every Muslim American hears\u2014that we\u2019re all part of the same American family.\" \u2014@POTUS https:\/\/t.co\/YRlT3QQEIa",
  "id" : 676123944420777985,
  "created_at" : "2015-12-13 19:38:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "National Guard",
      "screen_name" : "USNationalGuard",
      "indices" : [ 41, 57 ],
      "id_str" : "31310158",
      "id" : 31310158
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DeptofDefense\/status\/676008697752088576\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/J5TyFdzLd4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV4OMJ8UwAEoO4O.jpg",
      "id_str" : "674992596142309377",
      "id" : 674992596142309377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV4OMJ8UwAEoO4O.jpg",
      "sizes" : [ {
        "h" : 620,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/J5TyFdzLd4"
    } ],
    "hashtags" : [ {
      "text" : "Guard379",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676120351215099905",
  "text" : "RT @DeptofDefense: Happy Birthday to the @USNationalGuard!!! #Guard379 https:\/\/t.co\/J5TyFdzLd4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Guard",
        "screen_name" : "USNationalGuard",
        "indices" : [ 22, 38 ],
        "id_str" : "31310158",
        "id" : 31310158
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptofDefense\/status\/676008697752088576\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/J5TyFdzLd4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV4OMJ8UwAEoO4O.jpg",
        "id_str" : "674992596142309377",
        "id" : 674992596142309377,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV4OMJ8UwAEoO4O.jpg",
        "sizes" : [ {
          "h" : 620,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/J5TyFdzLd4"
      } ],
      "hashtags" : [ {
        "text" : "Guard379",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "676008697752088576",
    "text" : "Happy Birthday to the @USNationalGuard!!! #Guard379 https:\/\/t.co\/J5TyFdzLd4",
    "id" : 676008697752088576,
    "created_at" : "2015-12-13 12:00:07 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 676120351215099905,
  "created_at" : "2015-12-13 19:23:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/YRlT3QQEIa",
      "expanded_url" : "http:\/\/snpy.tv\/1jUlRGH",
      "display_url" : "snpy.tv\/1jUlRGH"
    } ]
  },
  "geo" : { },
  "id_str" : "676099446858457088",
  "text" : "\"One of the most important things we can do is to stay true to who we are as Americans.\" \u2014@POTUS https:\/\/t.co\/YRlT3QQEIa",
  "id" : 676099446858457088,
  "created_at" : "2015-12-13 18:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/YRlT3QQEIa",
      "expanded_url" : "http:\/\/snpy.tv\/1jUlRGH",
      "display_url" : "snpy.tv\/1jUlRGH"
    } ]
  },
  "geo" : { },
  "id_str" : "676087983725010944",
  "text" : "\"Democrats &amp; Republicans, liberals &amp; conservatives are standing up, forcefully, for freedom of religion.\" \u2014@POTUS https:\/\/t.co\/YRlT3QQEIa",
  "id" : 676087983725010944,
  "created_at" : "2015-12-13 17:15:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/676082922391273472\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Kk7EdNkHAt",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWHkN7rWUAEHkpw.png",
      "id_str" : "676072347091226625",
      "id" : 676072347091226625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWHkN7rWUAEHkpw.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Kk7EdNkHAt"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676082922391273472",
  "text" : "FACT: Nearly 200 countries, including China and India, have committed to reduce carbon pollution. #ParisAgreement https:\/\/t.co\/Kk7EdNkHAt",
  "id" : 676082922391273472,
  "created_at" : "2015-12-13 16:55:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/uLtVMN2A7C",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "676075754384420864",
  "text" : "RT @FactsOnClimate: \"We\u2019ve shown what\u2019s possible when the world stands as one.\" \u2014@POTUS: https:\/\/t.co\/uLtVMN2A7C #ParisAgreement https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 61, 67 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/676069801333284864\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/tQ7K53EXQi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWHhn9-WoAAfwZD.jpg",
        "id_str" : "676069495849525248",
        "id" : 676069495849525248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWHhn9-WoAAfwZD.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tQ7K53EXQi"
      } ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 93, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/uLtVMN2A7C",
        "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
        "display_url" : "go.wh.gov\/ClimateTalks"
      } ]
    },
    "geo" : { },
    "id_str" : "676069801333284864",
    "text" : "\"We\u2019ve shown what\u2019s possible when the world stands as one.\" \u2014@POTUS: https:\/\/t.co\/uLtVMN2A7C #ParisAgreement https:\/\/t.co\/tQ7K53EXQi",
    "id" : 676069801333284864,
    "created_at" : "2015-12-13 16:02:56 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 676075754384420864,
  "created_at" : "2015-12-13 16:26:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/wOVY8FzDuO",
      "expanded_url" : "http:\/\/snpy.tv\/1TIttbC",
      "display_url" : "snpy.tv\/1TIttbC"
    } ]
  },
  "geo" : { },
  "id_str" : "676071702363807744",
  "text" : "\"This agreement will mean less of the carbon pollution that threatens our planet.\" \u2014@POTUS on the #ParisAgreement https:\/\/t.co\/wOVY8FzDuO",
  "id" : 676071702363807744,
  "created_at" : "2015-12-13 16:10:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "12DaysOfTakeovers",
      "indices" : [ 30, 48 ]
    }, {
      "text" : "WHHolidays",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/pkdXSXeOqW",
      "expanded_url" : "http:\/\/Instagram.com\/michelleobama",
      "display_url" : "Instagram.com\/michelleobama"
    } ]
  },
  "geo" : { },
  "id_str" : "676069121155588097",
  "text" : "RT @FLOTUS: Today we kick off #12DaysOfTakeovers to give you a behind-the-scenes look at #WHHolidays\u2192 https:\/\/t.co\/pkdXSXeOqW https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/676057067854106625\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/P36ECdSqVr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWHWTwOWoAAby_Z.jpg",
        "id_str" : "676057053933248512",
        "id" : 676057053933248512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWHWTwOWoAAby_Z.jpg",
        "sizes" : [ {
          "h" : 950,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 950,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/P36ECdSqVr"
      } ],
      "hashtags" : [ {
        "text" : "12DaysOfTakeovers",
        "indices" : [ 18, 36 ]
      }, {
        "text" : "WHHolidays",
        "indices" : [ 77, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/pkdXSXeOqW",
        "expanded_url" : "http:\/\/Instagram.com\/michelleobama",
        "display_url" : "Instagram.com\/michelleobama"
      } ]
    },
    "geo" : { },
    "id_str" : "676057067854106625",
    "text" : "Today we kick off #12DaysOfTakeovers to give you a behind-the-scenes look at #WHHolidays\u2192 https:\/\/t.co\/pkdXSXeOqW https:\/\/t.co\/P36ECdSqVr",
    "id" : 676057067854106625,
    "created_at" : "2015-12-13 15:12:20 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 676069121155588097,
  "created_at" : "2015-12-13 16:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/675854498259161089\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/x9xVkchnYM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CWEeDNPW4AAwoEv.jpg",
      "id_str" : "675854459524800512",
      "id" : 675854459524800512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWEeDNPW4AAwoEv.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/x9xVkchnYM"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 62, 77 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/P2ZeFl5nfG",
      "expanded_url" : "http:\/\/go.wh.gov\/gV7fNK",
      "display_url" : "go.wh.gov\/gV7fNK"
    } ]
  },
  "geo" : { },
  "id_str" : "675854498259161089",
  "text" : "Today was a good day for the planet \u2192 https:\/\/t.co\/P2ZeFl5nfG #ParisAgreement #ActOnClimate https:\/\/t.co\/x9xVkchnYM",
  "id" : 675854498259161089,
  "created_at" : "2015-12-13 01:47:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675831851504807937",
  "text" : "RT @FactsOnClimate: \"We came together around the strong agreement the world needed. We met the moment.\" \u2014@POTUS #ParisAgreement https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 85, 91 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 92, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/u8y1IG2SjA",
        "expanded_url" : "http:\/\/snpy.tv\/1TItUmq",
        "display_url" : "snpy.tv\/1TItUmq"
      } ]
    },
    "geo" : { },
    "id_str" : "675829634672537600",
    "text" : "\"We came together around the strong agreement the world needed. We met the moment.\" \u2014@POTUS #ParisAgreement https:\/\/t.co\/u8y1IG2SjA",
    "id" : 675829634672537600,
    "created_at" : "2015-12-13 00:08:35 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 675831851504807937,
  "created_at" : "2015-12-13 00:17:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Bm56JgArIt",
      "expanded_url" : "http:\/\/snpy.tv\/1RKLLKN",
      "display_url" : "snpy.tv\/1RKLLKN"
    } ]
  },
  "geo" : { },
  "id_str" : "675827817507082241",
  "text" : "\"Today, we can be more confident that this planet is going to be in better shape for the next generation.\" \u2014@POTUS https:\/\/t.co\/Bm56JgArIt",
  "id" : 675827817507082241,
  "created_at" : "2015-12-13 00:01:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/wOVY8FzDuO",
      "expanded_url" : "http:\/\/snpy.tv\/1TIttbC",
      "display_url" : "snpy.tv\/1TIttbC"
    } ]
  },
  "geo" : { },
  "id_str" : "675825017612083200",
  "text" : "\"This agreement represents the best chance we\u2019ve had to save the one planet that we\u2019ve got.\" \u2014@POTUS #ParisAgreement https:\/\/t.co\/wOVY8FzDuO",
  "id" : 675825017612083200,
  "created_at" : "2015-12-12 23:50:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675812630280470528",
  "text" : "RT @POTUS: The strong Paris agreement on climate means a safer, more secure world for our kids. A perfect example of what American leadersh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675812094902714369",
    "text" : "The strong Paris agreement on climate means a safer, more secure world for our kids. A perfect example of what American leadership can do.",
    "id" : 675812094902714369,
    "created_at" : "2015-12-12 22:58:54 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 675812630280470528,
  "created_at" : "2015-12-12 23:01:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/675810614984310784\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/kDbSj5pShM",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWD2JEqUkAEreeb.png",
      "id_str" : "675810579836080129",
      "id" : 675810579836080129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWD2JEqUkAEreeb.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kDbSj5pShM"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675810614984310784",
  "text" : "\"We came together around the strong agreement the world needed. We met the moment.\" \u2014@POTUS #ParisAgreement https:\/\/t.co\/kDbSj5pShM",
  "id" : 675810614984310784,
  "created_at" : "2015-12-12 22:53:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675806542923350016",
  "text" : "\"What matters is that today, we can be more confident that this planet is going to be in better shape for the next generation.\" \u2014@POTUS",
  "id" : 675806542923350016,
  "created_at" : "2015-12-12 22:36:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675806194372640768",
  "text" : "\"This agreement will mean less of the carbon pollution that threatens our planet.\" \u2014@POTUS on the #ParisAgreement",
  "id" : 675806194372640768,
  "created_at" : "2015-12-12 22:35:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675805459174064128",
  "text" : "\"Together, we\u2019ve shown what\u2019s possible when the world stands as one.\" \u2014@POTUS on the #ParisAgreement",
  "id" : 675805459174064128,
  "created_at" : "2015-12-12 22:32:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65707359",
      "id" : 65707359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675791055422386176",
  "text" : "RT @ShuttleCDRKelly: Seeing the Earth from 250 miles up gives you a new appreciation for why we need to take care of it. #ParisAgreement ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ShuttleCDRKelly\/status\/675788540324646912\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/mGPdUKRRi7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CWDhWcYWoAEhkLW.jpg",
        "id_str" : "675787719797284865",
        "id" : 675787719797284865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CWDhWcYWoAEhkLW.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/mGPdUKRRi7"
      } ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675788540324646912",
    "text" : "Seeing the Earth from 250 miles up gives you a new appreciation for why we need to take care of it. #ParisAgreement https:\/\/t.co\/mGPdUKRRi7",
    "id" : 675788540324646912,
    "created_at" : "2015-12-12 21:25:18 +0000",
    "user" : {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "protected" : false,
      "id_str" : "65707359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738724057177325568\/QrZIaw99_normal.jpg",
      "id" : 65707359,
      "verified" : true
    }
  },
  "id" : 675791055422386176,
  "created_at" : "2015-12-12 21:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 12, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675781133863288832",
  "text" : "RT @VP: The #ParisAgreement will improve the world our kids and grandkids will grow old in. We are witnessing history today. And we should \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 4, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675781019102932992",
    "text" : "The #ParisAgreement will improve the world our kids and grandkids will grow old in. We are witnessing history today. And we should be proud.",
    "id" : 675781019102932992,
    "created_at" : "2015-12-12 20:55:25 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 675781133863288832,
  "created_at" : "2015-12-12 20:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675779925639479297",
  "text" : "RT @JohnKerry: World has chosen a smart, responsible path fwd. #COP21 agreement is the strongest, most ambitious global climate agreement e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 48, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675771547102003201",
    "text" : "World has chosen a smart, responsible path fwd. #COP21 agreement is the strongest, most ambitious global climate agreement ever negotiated.",
    "id" : 675771547102003201,
    "created_at" : "2015-12-12 20:17:46 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 675779925639479297,
  "created_at" : "2015-12-12 20:51:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/675777720710639616\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/fLXTiZwBOT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWDX0etU8AA32oh.png",
      "id_str" : "675777240701923328",
      "id" : 675777240701923328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWDX0etU8AA32oh.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fLXTiZwBOT"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 52, 65 ]
    }, {
      "text" : "ParisAgreement",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675777720710639616",
  "text" : "Here's what nearly 200 countries coming together to #ActOnClimate looks like. #ParisAgreement https:\/\/t.co\/fLXTiZwBOT",
  "id" : 675777720710639616,
  "created_at" : "2015-12-12 20:42:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675769945620422660",
  "text" : "RT @Deese44: World's most historic climate deal ever just reached in Paris, thanks to efforts of @POTUS &amp; many more at #COP21 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 84, 90 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XleFdRpVkH",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/12\/12\/us-leadership-and-historic-paris-agreement-combat-climate-change",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675756189616111617",
    "text" : "World's most historic climate deal ever just reached in Paris, thanks to efforts of @POTUS &amp; many more at #COP21 https:\/\/t.co\/XleFdRpVkH",
    "id" : 675756189616111617,
    "created_at" : "2015-12-12 19:16:45 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 675769945620422660,
  "created_at" : "2015-12-12 20:11:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675769695610515456",
  "text" : "RT @SenatorReid: I applaud President Obama's leadership and commend every country that committed to the #ParisAgreement for their responsib\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 87, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675765071415525376",
    "text" : "I applaud President Obama's leadership and commend every country that committed to the #ParisAgreement for their responsible action.",
    "id" : 675765071415525376,
    "created_at" : "2015-12-12 19:52:02 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 675769695610515456,
  "created_at" : "2015-12-12 20:10:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/675764497987014660\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/MUXVqAVcul",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWDMMyHWIAY_mko.png",
      "id_str" : "675764464088653830",
      "id" : 675764464088653830,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWDMMyHWIAY_mko.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MUXVqAVcul"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 4, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/QscCX2jF76",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "675764497987014660",
  "text" : "The #ParisAgreement lays the foundation for keeping global temperature rise below 2\u00B0 C. https:\/\/t.co\/QscCX2jF76 https:\/\/t.co\/MUXVqAVcul",
  "id" : 675764497987014660,
  "created_at" : "2015-12-12 19:49:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/675759029239586818\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/nPCE7s15ZI",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWDGAwaWcAAtwPo.png",
      "id_str" : "675757660403298304",
      "id" : 675757660403298304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWDGAwaWcAAtwPo.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nPCE7s15ZI"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 48, 63 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/QscCX2jF76",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "675759029239586818",
  "text" : "Watch @POTUS speak at 5:30pm ET on the historic #ParisAgreement \u2192 https:\/\/t.co\/QscCX2jF76 #ActOnClimate https:\/\/t.co\/nPCE7s15ZI",
  "id" : 675759029239586818,
  "created_at" : "2015-12-12 19:28:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/675754011966857216\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/fXJbH8H6tX",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CWDBdvQVEAAz9Bl.png",
      "id_str" : "675752660750897152",
      "id" : 675752660750897152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CWDBdvQVEAAz9Bl.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fXJbH8H6tX"
    } ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 61, 76 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Jk7lUZAIDH",
      "expanded_url" : "http:\/\/go.wh.gov\/tb88pi",
      "display_url" : "go.wh.gov\/tb88pi"
    } ]
  },
  "geo" : { },
  "id_str" : "675754011966857216",
  "text" : "BREAKING: @POTUS &amp; world leaders just secured a historic #ParisAgreement to #ActOnClimate. https:\/\/t.co\/Jk7lUZAIDH https:\/\/t.co\/fXJbH8H6tX",
  "id" : 675754011966857216,
  "created_at" : "2015-12-12 19:08:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/E0vdf1kH78",
      "expanded_url" : "http:\/\/go.wh.gov\/m5YNxa",
      "display_url" : "go.wh.gov\/m5YNxa"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/BGUkpqdb65",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/ab5c5ef4-ba6c-4abc-8bcc-f12288602583",
      "display_url" : "amp.twimg.com\/v\/ab5c5ef4-ba6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675745493163487232",
  "text" : "Watch President Obama's weekly address on standing strong in the face of terrorism: https:\/\/t.co\/E0vdf1kH78\nhttps:\/\/t.co\/BGUkpqdb65",
  "id" : 675745493163487232,
  "created_at" : "2015-12-12 18:34:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/vicVvABgoD",
      "expanded_url" : "http:\/\/snpy.tv\/1jQx4Z5",
      "display_url" : "snpy.tv\/1jQx4Z5"
    } ]
  },
  "geo" : { },
  "id_str" : "675441169157885952",
  "text" : "Here's how we're building on the progress made to help ensure every student gets a fair shot at success. #ESSA https:\/\/t.co\/vicVvABgoD",
  "id" : 675441169157885952,
  "created_at" : "2015-12-11 22:24:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/675428300844503044\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/RgtA5PaJH1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV-aWW5WcAAmc90.jpg",
      "id_str" : "675428178022789120",
      "id" : 675428178022789120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV-aWW5WcAAmc90.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/RgtA5PaJH1"
    } ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 90, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/1641Tv3taV",
      "expanded_url" : "http:\/\/go.wh.gov\/ESSA",
      "display_url" : "go.wh.gov\/ESSA"
    } ]
  },
  "geo" : { },
  "id_str" : "675428300844503044",
  "text" : "FACT: High school graduation rates have reached an all-time high. https:\/\/t.co\/1641Tv3taV #ESSA https:\/\/t.co\/RgtA5PaJH1",
  "id" : 675428300844503044,
  "created_at" : "2015-12-11 21:33:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/fUBAWtkkbv",
      "expanded_url" : "http:\/\/snpy.tv\/1jQwGcR",
      "display_url" : "snpy.tv\/1jQwGcR"
    } ]
  },
  "geo" : { },
  "id_str" : "675420858106662912",
  "text" : "The number of schools with high levels of dropouts has been cut almost in half over the last several years. #ESSA  https:\/\/t.co\/fUBAWtkkbv",
  "id" : 675420858106662912,
  "created_at" : "2015-12-11 21:04:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 76, 84 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 87, 95 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/iiDuV2tIf7",
      "expanded_url" : "https:\/\/youtu.be\/HecZGinK340?list=PLRJNAhZxtqH9fDDplzMqH-KzOzLwDc1sm",
      "display_url" : "youtu.be\/HecZGinK340?li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675409240111112193",
  "text" : "RT @DrBiden: Celebrate military-connected children this holiday season with @DrBiden\u2019s @YouTube Kids playlist! https:\/\/t.co\/iiDuV2tIf7 #Kid\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 63, 71 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      }, {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 74, 82 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsServeToo",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/iiDuV2tIf7",
        "expanded_url" : "https:\/\/youtu.be\/HecZGinK340?list=PLRJNAhZxtqH9fDDplzMqH-KzOzLwDc1sm",
        "display_url" : "youtu.be\/HecZGinK340?li\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675379321398272000",
    "text" : "Celebrate military-connected children this holiday season with @DrBiden\u2019s @YouTube Kids playlist! https:\/\/t.co\/iiDuV2tIf7 #KidsServeToo",
    "id" : 675379321398272000,
    "created_at" : "2015-12-11 18:19:12 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 675409240111112193,
  "created_at" : "2015-12-11 20:18:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/1641Tvl4zv",
      "expanded_url" : "http:\/\/go.wh.gov\/ESSA",
      "display_url" : "go.wh.gov\/ESSA"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/fUBAWtkkbv",
      "expanded_url" : "http:\/\/snpy.tv\/1jQwGcR",
      "display_url" : "snpy.tv\/1jQwGcR"
    } ]
  },
  "geo" : { },
  "id_str" : "675364170112610304",
  "text" : "Here's why we're in a better position to out-compete other nations on education \u2192  https:\/\/t.co\/1641Tvl4zv #ESSA https:\/\/t.co\/fUBAWtkkbv",
  "id" : 675364170112610304,
  "created_at" : "2015-12-11 17:19:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Malley",
      "screen_name" : "robmalley44",
      "indices" : [ 3, 15 ],
      "id_str" : "4418090668",
      "id" : 4418090668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675338784079273984",
  "text" : "RT @robmalley44: Hello! I will be tweeting about the United States and Coalition\u2019s efforts to degrade and destroy ISIL. Check out: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/poQOBI1NLh",
        "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
        "display_url" : "go.wh.gov\/ISIL"
      } ]
    },
    "geo" : { },
    "id_str" : "675338167063474176",
    "text" : "Hello! I will be tweeting about the United States and Coalition\u2019s efforts to degrade and destroy ISIL. Check out: https:\/\/t.co\/poQOBI1NLh",
    "id" : 675338167063474176,
    "created_at" : "2015-12-11 15:35:40 +0000",
    "user" : {
      "name" : "Rob Malley",
      "screen_name" : "robmalley44",
      "protected" : false,
      "id_str" : "4418090668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675032549035520000\/-fp_kyrD_normal.jpg",
      "id" : 4418090668,
      "verified" : true
    }
  },
  "id" : 675338784079273984,
  "created_at" : "2015-12-11 15:38:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 12, 17 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Alicia Menendez",
      "screen_name" : "AliciaMenendez",
      "indices" : [ 70, 85 ],
      "id_str" : "16104258",
      "id" : 16104258
    }, {
      "name" : "Fusion",
      "screen_name" : "ThisIsFusion",
      "indices" : [ 92, 105 ],
      "id_str" : "726088145180217345",
      "id" : 726088145180217345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 42, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/8GtCF5gU56",
      "expanded_url" : "http:\/\/on.fb.me\/21UM0HF",
      "display_url" : "on.fb.me\/21UM0HF"
    } ]
  },
  "geo" : { },
  "id_str" : "675330904919773184",
  "text" : "Watch live: @VJ44 takes your questions on #CriminalJusticeReform with @AliciaMenendez &amp; @ThisIsFusion \u2192 https:\/\/t.co\/8GtCF5gU56",
  "id" : 675330904919773184,
  "created_at" : "2015-12-11 15:06:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Alicia Menendez",
      "screen_name" : "AliciaMenendez",
      "indices" : [ 62, 77 ],
      "id_str" : "16104258",
      "id" : 16104258
    }, {
      "name" : "Fusion",
      "screen_name" : "ThisIsFusion",
      "indices" : [ 84, 97 ],
      "id_str" : "726088145180217345",
      "id" : 726088145180217345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 101, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675325742608158720",
  "text" : "RT @vj44: Join me for my weekly Office Hours at 10 AM ET with @AliciaMenendez &amp; @ThisIsFusion on #CriminalJusticeReform \u2192 https:\/\/t.co\/oQA5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alicia Menendez",
        "screen_name" : "AliciaMenendez",
        "indices" : [ 52, 67 ],
        "id_str" : "16104258",
        "id" : 16104258
      }, {
        "name" : "Fusion",
        "screen_name" : "ThisIsFusion",
        "indices" : [ 74, 87 ],
        "id_str" : "726088145180217345",
        "id" : 726088145180217345
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 91, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/oQA5f0wFMm",
        "expanded_url" : "http:\/\/Facebook.com\/FusionMediaNetwork",
        "display_url" : "Facebook.com\/FusionMediaNet\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "675325462692937729",
    "text" : "Join me for my weekly Office Hours at 10 AM ET with @AliciaMenendez &amp; @ThisIsFusion on #CriminalJusticeReform \u2192 https:\/\/t.co\/oQA5f0wFMm",
    "id" : 675325462692937729,
    "created_at" : "2015-12-11 14:45:11 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 675325742608158720,
  "created_at" : "2015-12-11 14:46:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maccabeats",
      "screen_name" : "Maccabeats",
      "indices" : [ 46, 57 ],
      "id_str" : "95123937",
      "id" : 95123937
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyHanukkah",
      "indices" : [ 1, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/cfXFO2CGhE",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/b07e2132-3d0d-4a1c-aedc-54de71d17236",
      "display_url" : "amp.twimg.com\/v\/b07e2132-3d0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675132173096095744",
  "text" : "\uD83C\uDFB5#HappyHanukkah from the White House, and the @Maccabeats!\uD83C\uDFB5\nhttps:\/\/t.co\/cfXFO2CGhE",
  "id" : 675132173096095744,
  "created_at" : "2015-12-11 01:57:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/675126525813985280\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/dXoIE1Ds9k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV6Hy41XIAAUVaC.jpg",
      "id_str" : "675126302471561216",
      "id" : 675126302471561216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV6Hy41XIAAUVaC.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 544
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 544
      } ],
      "display_url" : "pic.twitter.com\/dXoIE1Ds9k"
    } ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/jGzOUZeaAs",
      "expanded_url" : "http:\/\/on.fb.me\/1NlkY2l",
      "display_url" : "on.fb.me\/1NlkY2l"
    } ]
  },
  "geo" : { },
  "id_str" : "675126525813985280",
  "text" : "\"A Christmas miracle: A bipartisan bill signing right here.\" \u2014@POTUS: https:\/\/t.co\/jGzOUZeaAs #ESSA https:\/\/t.co\/dXoIE1Ds9k",
  "id" : 675126525813985280,
  "created_at" : "2015-12-11 01:34:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675113514495819781",
  "text" : "RT @JohnKerry: Past midnight in Paris for #COP21. Everyone working hard. A critical moment, an opportunity we can't afford to miss. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/675106452680347648\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/LoardSMd85",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV51vXRWUAEe53O.jpg",
        "id_str" : "675106450713235457",
        "id" : 675106450713235457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV51vXRWUAEe53O.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3199,
          "resize" : "fit",
          "w" : 4800
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/LoardSMd85"
      } ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 27, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675106452680347648",
    "text" : "Past midnight in Paris for #COP21. Everyone working hard. A critical moment, an opportunity we can't afford to miss. https:\/\/t.co\/LoardSMd85",
    "id" : 675106452680347648,
    "created_at" : "2015-12-11 00:14:55 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 675113514495819781,
  "created_at" : "2015-12-11 00:42:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675078689898553345",
  "text" : "RT @Cecilia44: Join us for a Facebook Q&amp;A at 5:45pm ET!  I'll be taking your questions on #ESSA, the new education bill: https:\/\/t.co\/nwm9H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ESSA",
        "indices" : [ 79, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/nwm9Hrt4hp",
        "expanded_url" : "http:\/\/go.wh.gov\/2UbpNM",
        "display_url" : "go.wh.gov\/2UbpNM"
      } ]
    },
    "geo" : { },
    "id_str" : "675041372559273984",
    "text" : "Join us for a Facebook Q&amp;A at 5:45pm ET!  I'll be taking your questions on #ESSA, the new education bill: https:\/\/t.co\/nwm9Hrt4hp",
    "id" : 675041372559273984,
    "created_at" : "2015-12-10 19:56:19 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 675078689898553345,
  "created_at" : "2015-12-10 22:24:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/675062773307588610\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/RJfKkield9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV5OAA9WoAMQk4O.jpg",
      "id_str" : "675062756316454915",
      "id" : 675062756316454915,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV5OAA9WoAMQk4O.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RJfKkield9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675065094846418951",
  "text" : "RT @POTUS: The opioid epidemic is destroying lives. We need to put treatment within reach of anyone who needs it. https:\/\/t.co\/RJfKkield9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/675062773307588610\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/RJfKkield9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CV5OAA9WoAMQk4O.jpg",
        "id_str" : "675062756316454915",
        "id" : 675062756316454915,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV5OAA9WoAMQk4O.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RJfKkield9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675062773307588610",
    "text" : "The opioid epidemic is destroying lives. We need to put treatment within reach of anyone who needs it. https:\/\/t.co\/RJfKkield9",
    "id" : 675062773307588610,
    "created_at" : "2015-12-10 21:21:21 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 675065094846418951,
  "created_at" : "2015-12-10 21:30:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opioid",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675051719068397568",
  "text" : "RT @SecBurwell: We lose too many Americans to drug overdoses. HHS is working to combat the #opioid epidemic &amp; change trends. https:\/\/t.co\/J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opioid",
        "indices" : [ 75, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/J2zDaSPXQe",
        "expanded_url" : "http:\/\/www.hhs.gov\/opioids",
        "display_url" : "hhs.gov\/opioids"
      } ]
    },
    "in_reply_to_status_id_str" : "675040803450920961",
    "geo" : { },
    "id_str" : "675041611802353664",
    "in_reply_to_user_id" : 2458567464,
    "text" : "We lose too many Americans to drug overdoses. HHS is working to combat the #opioid epidemic &amp; change trends. https:\/\/t.co\/J2zDaSPXQe",
    "id" : 675041611802353664,
    "in_reply_to_status_id" : 675040803450920961,
    "created_at" : "2015-12-10 19:57:16 +0000",
    "in_reply_to_screen_name" : "SecBurwell",
    "in_reply_to_user_id_str" : "2458567464",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 675051719068397568,
  "created_at" : "2015-12-10 20:37:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675046388049321984",
  "text" : "RT @VP: Any conversation about human rights must include the right of every woman on this planet to be free from violence and fear. #HumanR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HumanRightsDay",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "675040132643295232",
    "text" : "Any conversation about human rights must include the right of every woman on this planet to be free from violence and fear. #HumanRightsDay",
    "id" : 675040132643295232,
    "created_at" : "2015-12-10 19:51:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 675046388049321984,
  "created_at" : "2015-12-10 20:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/cqL6JVVCWC",
      "expanded_url" : "http:\/\/snpy.tv\/1TDe1xC",
      "display_url" : "snpy.tv\/1TDe1xC"
    } ]
  },
  "geo" : { },
  "id_str" : "675028674794663938",
  "text" : "Every student deserves a great education. 8th grader Antonio wants to be an engineer. Watch him introduce @POTUS. https:\/\/t.co\/cqL6JVVCWC",
  "id" : 675028674794663938,
  "created_at" : "2015-12-10 19:05:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fUBAWtkkbv",
      "expanded_url" : "http:\/\/snpy.tv\/1jQwGcR",
      "display_url" : "snpy.tv\/1jQwGcR"
    } ]
  },
  "geo" : { },
  "id_str" : "675008977852358657",
  "text" : "Since @POTUS took office: \nGraduation rates \u2191  \nStudent dropout rates \u2193 \n\nEvery student deserves a shot at success. https:\/\/t.co\/fUBAWtkkbv",
  "id" : 675008977852358657,
  "created_at" : "2015-12-10 17:47:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Jay Pharoah",
      "screen_name" : "JayPharoah",
      "indices" : [ 29, 40 ],
      "id_str" : "25343191",
      "id" : 25343191
    }, {
      "name" : "CollegeHumor",
      "screen_name" : "CollegeHumor",
      "indices" : [ 43, 56 ],
      "id_str" : "16825289",
      "id" : 16825289
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/674970624914157569\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/62pgWqcRio",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CV35m7hWoAA0hjn.png",
      "id_str" : "674969966383374336",
      "id" : 674969966383374336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CV35m7hWoAA0hjn.png",
      "sizes" : [ {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 405
      } ],
      "display_url" : "pic.twitter.com\/62pgWqcRio"
    } ],
    "hashtags" : [ {
      "text" : "BetterMakeRoom",
      "indices" : [ 59, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/DugYapIWzD",
      "expanded_url" : "https:\/\/youtu.be\/_1yAOK0nSb0",
      "display_url" : "youtu.be\/_1yAOK0nSb0"
    } ]
  },
  "geo" : { },
  "id_str" : "675001219522392064",
  "text" : "RT @FLOTUS: The First Lady \u2713\n@JayPharoah \u2713\n@CollegeHumor \u2713\n#BetterMakeRoom\nWatch \u2192 https:\/\/t.co\/DugYapIWzD https:\/\/t.co\/62pgWqcRio",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jay Pharoah",
        "screen_name" : "JayPharoah",
        "indices" : [ 17, 28 ],
        "id_str" : "25343191",
        "id" : 25343191
      }, {
        "name" : "CollegeHumor",
        "screen_name" : "CollegeHumor",
        "indices" : [ 31, 44 ],
        "id_str" : "16825289",
        "id" : 16825289
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/674970624914157569\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/62pgWqcRio",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CV35m7hWoAA0hjn.png",
        "id_str" : "674969966383374336",
        "id" : 674969966383374336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CV35m7hWoAA0hjn.png",
        "sizes" : [ {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 405
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 405
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 405
        } ],
        "display_url" : "pic.twitter.com\/62pgWqcRio"
      } ],
      "hashtags" : [ {
        "text" : "BetterMakeRoom",
        "indices" : [ 47, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/DugYapIWzD",
        "expanded_url" : "https:\/\/youtu.be\/_1yAOK0nSb0",
        "display_url" : "youtu.be\/_1yAOK0nSb0"
      } ]
    },
    "geo" : { },
    "id_str" : "674970624914157569",
    "text" : "The First Lady \u2713\n@JayPharoah \u2713\n@CollegeHumor \u2713\n#BetterMakeRoom\nWatch \u2192 https:\/\/t.co\/DugYapIWzD https:\/\/t.co\/62pgWqcRio",
    "id" : 674970624914157569,
    "created_at" : "2015-12-10 15:15:11 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 675001219522392064,
  "created_at" : "2015-12-10 17:16:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/vicVvASRNd",
      "expanded_url" : "http:\/\/snpy.tv\/1jQx4Z5",
      "display_url" : "snpy.tv\/1jQx4Z5"
    } ]
  },
  "geo" : { },
  "id_str" : "674995694441222144",
  "text" : "RT if you agree:\nEvery child,\nregardless of\nrace,\nincome,\nor zip code,\ndeserves a shot at a great education. #ESSA https:\/\/t.co\/vicVvASRNd",
  "id" : 674995694441222144,
  "created_at" : "2015-12-10 16:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/674988879699648512\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/b4iFzrhQqj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV4KuPZW4AA92kB.jpg",
      "id_str" : "674988783675301888",
      "id" : 674988783675301888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV4KuPZW4AA92kB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/b4iFzrhQqj"
    } ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674988879699648512",
  "text" : "\"This is a big step in the right direction. It was a true bipartisan effort\" \u2014@POTUS on the #ESSA https:\/\/t.co\/b4iFzrhQqj",
  "id" : 674988879699648512,
  "created_at" : "2015-12-10 16:27:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674988660350169088",
  "text" : "\"Every child, regardless of race, income, background, or zip code...deserves the chance to make of their lives what they will.\"\u2014@POTUS #ESSA",
  "id" : 674988660350169088,
  "created_at" : "2015-12-10 16:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674988535083098112",
  "text" : "\"This law lays the foundation to expand access to high-quality preschools.\"\u2014@POTUS on education bill that fixes No Child Left Behind #ESSA",
  "id" : 674988535083098112,
  "created_at" : "2015-12-10 16:26:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674988381747740672",
  "text" : "\"This bill makes long overdue fixes to the last education law. It replaces a one-size-fits-all approach to reform\" \u2014@POTUS on the #ESSA",
  "id" : 674988381747740672,
  "created_at" : "2015-12-10 16:25:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674988073780817920",
  "text" : "\"This law focuses on a national goal of ensuring that all of our students graduate prepared for college and future careers.\" \u2014@POTUS #ESSA",
  "id" : 674988073780817920,
  "created_at" : "2015-12-10 16:24:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674987969070133249",
  "text" : "\u201CIn today\u2019s economy, a high-quality education is a prerequisite for success.\" \u2014@POTUS on the Every Student Succeeds Act #ESSA",
  "id" : 674987969070133249,
  "created_at" : "2015-12-10 16:24:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/674987688764776448\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/fhUPAOcZRX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV4JsCkUsAAri5f.jpg",
      "id_str" : "674987646360268800",
      "id" : 674987646360268800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV4JsCkUsAAri5f.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fhUPAOcZRX"
    } ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674987688764776448",
  "text" : "\"High school graduation rates have reached all-time highs. Dropout rates have hit historic lows\" \u2014@POTUS #ESSA https:\/\/t.co\/fhUPAOcZRX",
  "id" : 674987688764776448,
  "created_at" : "2015-12-10 16:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/674986308960260096\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/72380X9wR3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV4IYfBU8AITjVf.jpg",
      "id_str" : "674986210889101314",
      "id" : 674986210889101314,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV4IYfBU8AITjVf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/72380X9wR3"
    } ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674986308960260096",
  "text" : "\"I\u2019m proud to sign a law that will make sure every student is prepared to succeed\" \u2014@POTUS on the #ESSA https:\/\/t.co\/72380X9wR3",
  "id" : 674986308960260096,
  "created_at" : "2015-12-10 16:17:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674986125602123776",
  "text" : "\"After more than 10 years, Members of Congress from both parties have come together to revise our national education law.\" \u2014@POTUS #ESSA",
  "id" : 674986125602123776,
  "created_at" : "2015-12-10 16:16:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/7xEoqCOW0Q",
      "expanded_url" : "http:\/\/go.wh.gov\/sDQvMp",
      "display_url" : "go.wh.gov\/sDQvMp"
    } ]
  },
  "geo" : { },
  "id_str" : "674985478660202496",
  "text" : "Tune in as @POTUS signs the bipartisan education bill to fix and replace No Child Left Behind \u2192 https:\/\/t.co\/7xEoqCOW0Q #ESSA",
  "id" : 674985478660202496,
  "created_at" : "2015-12-10 16:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    }, {
      "name" : "Caitlyn Jenner",
      "screen_name" : "Caitlyn_Jenner",
      "indices" : [ 37, 52 ],
      "id_str" : "3303293865",
      "id" : 3303293865
    }, {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 131, 134 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674978166197370880",
  "text" : "RT @AmbassadorPower: Good to talk to @Caitlyn_Jenner recently abt import of advocating for transgender rights, here at home and at @UN\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caitlyn Jenner",
        "screen_name" : "Caitlyn_Jenner",
        "indices" : [ 16, 31 ],
        "id_str" : "3303293865",
        "id" : 3303293865
      }, {
        "name" : "United Nations",
        "screen_name" : "UN",
        "indices" : [ 110, 113 ],
        "id_str" : "14159148",
        "id" : 14159148
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/KbdMjwCvBn",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/b4a6328d-e02a-4bbf-ba58-a34fd51a8ec4",
        "display_url" : "amp.twimg.com\/v\/b4a6328d-e02\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674971236779233280",
    "text" : "Good to talk to @Caitlyn_Jenner recently abt import of advocating for transgender rights, here at home and at @UN\nhttps:\/\/t.co\/KbdMjwCvBn",
    "id" : 674971236779233280,
    "created_at" : "2015-12-10 15:17:37 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 674978166197370880,
  "created_at" : "2015-12-10 15:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/674948829469409281\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/5ZdyQAqTZe",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CV3mM0RWUAAaISs.png",
      "id_str" : "674948627039670272",
      "id" : 674948627039670272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CV3mM0RWUAAaISs.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5ZdyQAqTZe"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 64, 77 ]
    }, {
      "text" : "COP21",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/uLtVMN2A7C",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "674951923171201025",
  "text" : "RT @FactsOnClimate: RT if you agree: It's time for the world to #ActOnClimate \u2192 https:\/\/t.co\/uLtVMN2A7C #COP21 https:\/\/t.co\/5ZdyQAqTZe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/674948829469409281\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/5ZdyQAqTZe",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CV3mM0RWUAAaISs.png",
        "id_str" : "674948627039670272",
        "id" : 674948627039670272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CV3mM0RWUAAaISs.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5ZdyQAqTZe"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 44, 57 ]
      }, {
        "text" : "COP21",
        "indices" : [ 84, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/uLtVMN2A7C",
        "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
        "display_url" : "go.wh.gov\/ClimateTalks"
      } ]
    },
    "geo" : { },
    "id_str" : "674948829469409281",
    "text" : "RT if you agree: It's time for the world to #ActOnClimate \u2192 https:\/\/t.co\/uLtVMN2A7C #COP21 https:\/\/t.co\/5ZdyQAqTZe",
    "id" : 674948829469409281,
    "created_at" : "2015-12-10 13:48:35 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 674951923171201025,
  "created_at" : "2015-12-10 14:00:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Brandon Stanton",
      "screen_name" : "humansofny",
      "indices" : [ 79, 90 ],
      "id_str" : "237548529",
      "id" : 237548529
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/674763989096730624\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/TiRy4kESJG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CV09ra6WIAETQI8.png",
      "id_str" : "674763335343153153",
      "id" : 674763335343153153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CV09ra6WIAETQI8.png",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 831,
        "resize" : "fit",
        "w" : 743
      }, {
        "h" : 831,
        "resize" : "fit",
        "w" : 743
      } ],
      "display_url" : "pic.twitter.com\/TiRy4kESJG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/FNQZCPe1JU",
      "expanded_url" : "http:\/\/on.fb.me\/1Rb3nAr",
      "display_url" : "on.fb.me\/1Rb3nAr"
    } ]
  },
  "geo" : { },
  "id_str" : "674763989096730624",
  "text" : "\"Welcome to your new home. You're part of what makes America great\" \u2014@POTUS on @HumansOfNY: https:\/\/t.co\/FNQZCPe1JU https:\/\/t.co\/TiRy4kESJG",
  "id" : 674763989096730624,
  "created_at" : "2015-12-10 01:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NowThis",
      "screen_name" : "nowthisnews",
      "indices" : [ 3, 15 ],
      "id_str" : "701725963",
      "id" : 701725963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674751173883228161",
  "text" : "RT @nowthisnews: The First Lady helped marines sort holiday toys as part of the corps' Toys For Tots program on Wednesday https:\/\/t.co\/TsJm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/TsJmgsilnh",
        "expanded_url" : "http:\/\/on.nowth.is\/j4o",
        "display_url" : "on.nowth.is\/j4o"
      } ]
    },
    "geo" : { },
    "id_str" : "674732825199820800",
    "text" : "The First Lady helped marines sort holiday toys as part of the corps' Toys For Tots program on Wednesday https:\/\/t.co\/TsJmgsilnh",
    "id" : 674732825199820800,
    "created_at" : "2015-12-09 23:30:16 +0000",
    "user" : {
      "name" : "NowThis",
      "screen_name" : "nowthisnews",
      "protected" : false,
      "id_str" : "701725963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783053831844298754\/p8H7pdtz_normal.jpg",
      "id" : 701725963,
      "verified" : true
    }
  },
  "id" : 674751173883228161,
  "created_at" : "2015-12-10 00:43:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674737313314971649",
  "text" : "RT @POTUS: Herzlichen Gl\u00FCckwunsch to my friend and Time's Person of the Year, Angela Merkel! Thanks for your moral leadership and strong pa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674735966830116864",
    "text" : "Herzlichen Gl\u00FCckwunsch to my friend and Time's Person of the Year, Angela Merkel! Thanks for your moral leadership and strong partnership.",
    "id" : 674735966830116864,
    "created_at" : "2015-12-09 23:42:45 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 674737313314971649,
  "created_at" : "2015-12-09 23:48:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askpresssec",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674732172423634944",
  "text" : "RT @PressSec: Good news. @POTUS will sign edu reform bill tmrw. Will reduce testing &amp; end one-size-fits-all mandates. #askpresssec https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askpresssec",
        "indices" : [ 108, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/MNfgwOCyUC",
        "expanded_url" : "https:\/\/twitter.com\/TinaVerde213\/status\/674724670038495233",
        "display_url" : "twitter.com\/TinaVerde213\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674726644829982720",
    "text" : "Good news. @POTUS will sign edu reform bill tmrw. Will reduce testing &amp; end one-size-fits-all mandates. #askpresssec https:\/\/t.co\/MNfgwOCyUC",
    "id" : 674726644829982720,
    "created_at" : "2015-12-09 23:05:42 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 674732172423634944,
  "created_at" : "2015-12-09 23:27:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674683362951471104",
  "text" : "RT @PressSec: Hey, everyone! I'll be answering your questions today at 5:15pm ET. Send them over using #AskPressSec. Looking forward to it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 89, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674682574262960128",
    "text" : "Hey, everyone! I'll be answering your questions today at 5:15pm ET. Send them over using #AskPressSec. Looking forward to it.",
    "id" : 674682574262960128,
    "created_at" : "2015-12-09 20:10:35 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 674683362951471104,
  "created_at" : "2015-12-09 20:13:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/DwaayXWIbu",
      "expanded_url" : "http:\/\/go.wh.gov\/Ukraine",
      "display_url" : "go.wh.gov\/Ukraine"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/h8CBK9dXir",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/89bbe06c-b85a-4a0b-9687-778e702eefe2",
      "display_url" : "amp.twimg.com\/v\/89bbe06c-b85\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "674666670250700800",
  "text" : "RT @VP: Folks, we're home from Ukraine. This was a good trip. Here are my parting thoughts. https:\/\/t.co\/DwaayXWIbu\nhttps:\/\/t.co\/h8CBK9dXir",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/DwaayXWIbu",
        "expanded_url" : "http:\/\/go.wh.gov\/Ukraine",
        "display_url" : "go.wh.gov\/Ukraine"
      }, {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/h8CBK9dXir",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/89bbe06c-b85a-4a0b-9687-778e702eefe2",
        "display_url" : "amp.twimg.com\/v\/89bbe06c-b85\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "674645596737638400",
    "text" : "Folks, we're home from Ukraine. This was a good trip. Here are my parting thoughts. https:\/\/t.co\/DwaayXWIbu\nhttps:\/\/t.co\/h8CBK9dXir",
    "id" : 674645596737638400,
    "created_at" : "2015-12-09 17:43:39 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 674666670250700800,
  "created_at" : "2015-12-09 19:07:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "13thAmendment",
      "indices" : [ 81, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/Bj3Fdd7d6v",
      "expanded_url" : "http:\/\/snpy.tv\/1NMq5I8",
      "display_url" : "snpy.tv\/1NMq5I8"
    } ]
  },
  "geo" : { },
  "id_str" : "674660251677933570",
  "text" : "\"We betray our most noble past\u2026when we deny the possibility of progress\" \u2014@POTUS #13thAmendment https:\/\/t.co\/Bj3Fdd7d6v",
  "id" : 674660251677933570,
  "created_at" : "2015-12-09 18:41:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "13thAmendment",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Bj3Fdd7d6v",
      "expanded_url" : "http:\/\/snpy.tv\/1NMq5I8",
      "display_url" : "snpy.tv\/1NMq5I8"
    } ]
  },
  "geo" : { },
  "id_str" : "674647390142513153",
  "text" : "Watch as @POTUS commemorates the 150th anniversary of the abolition of slavery. #13thAmendment https:\/\/t.co\/Bj3Fdd7d6v",
  "id" : 674647390142513153,
  "created_at" : "2015-12-09 17:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "13thAmendment",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JmxEHBBXwa",
      "expanded_url" : "http:\/\/snpy.tv\/1Qfqjy2",
      "display_url" : "snpy.tv\/1Qfqjy2"
    } ]
  },
  "geo" : { },
  "id_str" : "674642990954975233",
  "text" : "\"We betray the efforts of the past if we fail to push back against bigotry in all its forms.\" \u2014@POTUS #13thAmendment https:\/\/t.co\/JmxEHBBXwa",
  "id" : 674642990954975233,
  "created_at" : "2015-12-09 17:33:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "13thAmendment",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674639379944644608",
  "text" : "\"To nobly save, or meanly lose, the last best hope of Earth. That is our choice. Today we affirm hope.\" \u2014@POTUS #13thAmendment",
  "id" : 674639379944644608,
  "created_at" : "2015-12-09 17:18:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674638443201228800",
  "text" : "\u201CRemember that our freedom is bound up with the freedom of others\u2014regardless of what they look like...or what faith they practice.\u201D \u2014@POTUS",
  "id" : 674638443201228800,
  "created_at" : "2015-12-09 17:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674638219569426432",
  "text" : "\"All it requires is that our generation be as willing to do what all who came before us have done: to rise above cynicism and fear\" \u2014@POTUS",
  "id" : 674638219569426432,
  "created_at" : "2015-12-09 17:14:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674638026845249536",
  "text" : "\"We betray our most noble past as well if we were to deny the...possibility of progress\" \u2014@POTUS on the anniversary of the 13th Amendment",
  "id" : 674638026845249536,
  "created_at" : "2015-12-09 17:13:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674637811031654400",
  "text" : "\"We condemn ourselves to shackles once more if we fail to answer those who wonder if they\u2019re truly equals in their communities\" \u2014@POTUS",
  "id" : 674637811031654400,
  "created_at" : "2015-12-09 17:12:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674637561147494400",
  "text" : "\"That is what we celebrate today\u2014the long arc of progress.\" \u2014@POTUS commemorating the anniversary of the 13th Amendment",
  "id" : 674637561147494400,
  "created_at" : "2015-12-09 17:11:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674637497255636992",
  "text" : "\"Doors of opportunity swung open, not just for the black porter, but the white chambermaid, and the immigrant dishwasher\" \u2014@POTUS",
  "id" : 674637497255636992,
  "created_at" : "2015-12-09 17:11:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/674637393756946433\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/DFrvekWmYd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVzLE_eUkAArMYQ.jpg",
      "id_str" : "674637330817257472",
      "id" : 674637330817257472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVzLE_eUkAArMYQ.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1326,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/DFrvekWmYd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674637393756946433",
  "text" : "\"Because of them, a Civil Rights law was passed.\" \u2014@POTUS https:\/\/t.co\/DFrvekWmYd",
  "id" : 674637393756946433,
  "created_at" : "2015-12-09 17:11:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674637200038887424",
  "text" : "\"Hope\u2014often in the face of all evidence to the contrary, that something better lay around the bend.\" \u2014@POTUS",
  "id" : 674637200038887424,
  "created_at" : "2015-12-09 17:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674637136537063424",
  "text" : "\"Like their abolitionist predecessors, they were plain, humble, ordinary people armed with little but faith\" \u2014@POTUS",
  "id" : 674637136537063424,
  "created_at" : "2015-12-09 17:10:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/674636917837660160\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/ivfxkMcuyA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVzKY8oUwAAZAsd.jpg",
      "id_str" : "674636574139662336",
      "id" : 674636574139662336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVzKY8oUwAAZAsd.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ivfxkMcuyA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674636917837660160",
  "text" : "\"A new generation rose up, to march and organize and to stand up and sit in\" \u2014@POTUS https:\/\/t.co\/ivfxkMcuyA",
  "id" : 674636917837660160,
  "created_at" : "2015-12-09 17:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674636240566788096",
  "text" : "\"The question of slavery was never simply about civil rights. It was about...the kind of country we wanted to be\" \u2014@POTUS",
  "id" : 674636240566788096,
  "created_at" : "2015-12-09 17:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674636027366121472",
  "text" : "\"The reformers\u2019 passion only drove the protectors of the status quo to dig in.\" \u2014@POTUS commemorating the anniversary of the 13th Amendment",
  "id" : 674636027366121472,
  "created_at" : "2015-12-09 17:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674635439714803714",
  "text" : "\"We gather here to commemorate a century and a half of freedom\u2014not simply for former slaves, but for all of us.\" \u2014@POTUS",
  "id" : 674635439714803714,
  "created_at" : "2015-12-09 17:03:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/V30tk3WpHn",
      "expanded_url" : "http:\/\/go.wh.gov\/gyPmb2",
      "display_url" : "go.wh.gov\/gyPmb2"
    } ]
  },
  "geo" : { },
  "id_str" : "674635164929138688",
  "text" : "Tune in: @POTUS commemorates the 150th anniversary of the 13th Amendment \u2192 https:\/\/t.co\/V30tk3WpHn",
  "id" : 674635164929138688,
  "created_at" : "2015-12-09 17:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fixNCLB",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674626006930468864",
  "text" : "RT @Cecilia44: The bipartisan bill to #fixNCLB just passed the Senate. @POTUS will sign it tomorrow, helping ensure more students a shot at\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 56, 62 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fixNCLB",
        "indices" : [ 23, 31 ]
      }, {
        "text" : "ESSA",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674625696375902209",
    "text" : "The bipartisan bill to #fixNCLB just passed the Senate. @POTUS will sign it tomorrow, helping ensure more students a shot at success. #ESSA",
    "id" : 674625696375902209,
    "created_at" : "2015-12-09 16:24:34 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 674626006930468864,
  "created_at" : "2015-12-09 16:25:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674621032662220804",
  "text" : "RT @POTUS: 150 years since the abolition of slavery, a turning point in our history. Progress - that's our story.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "674620408642084865",
    "text" : "150 years since the abolition of slavery, a turning point in our history. Progress - that's our story.",
    "id" : 674620408642084865,
    "created_at" : "2015-12-09 16:03:33 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 674621032662220804,
  "created_at" : "2015-12-09 16:06:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/674394505324265472\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/T3clmbRRpV",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CVvuEywWUAALXVh.png",
      "id_str" : "674394335333470208",
      "id" : 674394335333470208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CVvuEywWUAALXVh.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/T3clmbRRpV"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 22, 35 ]
    }, {
      "text" : "COP21",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/onlKr0SxKV",
      "expanded_url" : "http:\/\/go.wh.gov\/RAbuYk",
      "display_url" : "go.wh.gov\/RAbuYk"
    } ]
  },
  "geo" : { },
  "id_str" : "674394505324265472",
  "text" : "Here's why we have to #ActOnClimate\u2014in one chart: https:\/\/t.co\/onlKr0SxKV #COP21 https:\/\/t.co\/T3clmbRRpV",
  "id" : 674394505324265472,
  "created_at" : "2015-12-09 01:05:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trade",
      "indices" : [ 41, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/DGVN8Zph8V",
      "expanded_url" : "http:\/\/go.usa.gov\/cBsb9",
      "display_url" : "go.usa.gov\/cBsb9"
    } ]
  },
  "geo" : { },
  "id_str" : "674385191951929345",
  "text" : "RT @USTradeRep: What They\u2019re Saying: How #trade levels the playing field for American workers &amp; businesses https:\/\/t.co\/DGVN8Zph8V https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USTradeRep\/status\/674383785916411905\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/s4XfR2Q5Ww",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVvkQ5wWwAAWPTl.png",
        "id_str" : "674383548254699520",
        "id" : 674383548254699520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVvkQ5wWwAAWPTl.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/s4XfR2Q5Ww"
      } ],
      "hashtags" : [ {
        "text" : "trade",
        "indices" : [ 25, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/DGVN8Zph8V",
        "expanded_url" : "http:\/\/go.usa.gov\/cBsb9",
        "display_url" : "go.usa.gov\/cBsb9"
      } ]
    },
    "geo" : { },
    "id_str" : "674383785916411905",
    "text" : "What They\u2019re Saying: How #trade levels the playing field for American workers &amp; businesses https:\/\/t.co\/DGVN8Zph8V https:\/\/t.co\/s4XfR2Q5Ww",
    "id" : 674383785916411905,
    "created_at" : "2015-12-09 00:23:18 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 674385191951929345,
  "created_at" : "2015-12-09 00:28:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/674378878748495872\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/sa06DYh61D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVvff5XWIAAhSc8.jpg",
      "id_str" : "674378308289699840",
      "id" : 674378308289699840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVvff5XWIAAhSc8.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sa06DYh61D"
    } ],
    "hashtags" : [ {
      "text" : "SnapWorks",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/vnslEK6D19",
      "expanded_url" : "http:\/\/go.wh.gov\/SnapWorks",
      "display_url" : "go.wh.gov\/SnapWorks"
    } ]
  },
  "geo" : { },
  "id_str" : "674378878748495872",
  "text" : "SNAP improves education and economic outcomes for millions of kids. Here's why #SnapWorks: https:\/\/t.co\/vnslEK6D19 https:\/\/t.co\/sa06DYh61D",
  "id" : 674378878748495872,
  "created_at" : "2015-12-09 00:03:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 3, 8 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SNAPworks",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/p1AYrpKvDd",
      "expanded_url" : "http:\/\/ow.ly\/VDv1I",
      "display_url" : "ow.ly\/VDv1I"
    } ]
  },
  "geo" : { },
  "id_str" : "674353081702850562",
  "text" : "RT @USDA: 1 in 5 homes with kids is food insecure. #SNAPworks to help families put food on the table https:\/\/t.co\/p1AYrpKvDd https:\/\/t.co\/d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDA\/status\/674345261561348096\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/drPrjzAlzj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVvBcQmVAAEWbF8.jpg",
        "id_str" : "674345260458246145",
        "id" : 674345260458246145,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVvBcQmVAAEWbF8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/drPrjzAlzj"
      } ],
      "hashtags" : [ {
        "text" : "SNAPworks",
        "indices" : [ 41, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/p1AYrpKvDd",
        "expanded_url" : "http:\/\/ow.ly\/VDv1I",
        "display_url" : "ow.ly\/VDv1I"
      } ]
    },
    "geo" : { },
    "id_str" : "674345261561348096",
    "text" : "1 in 5 homes with kids is food insecure. #SNAPworks to help families put food on the table https:\/\/t.co\/p1AYrpKvDd https:\/\/t.co\/drPrjzAlzj",
    "id" : 674345261561348096,
    "created_at" : "2015-12-08 21:50:13 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 674353081702850562,
  "created_at" : "2015-12-08 22:21:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/674340692139728896\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/jLkkiGaKSW",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CVu9Oq4XIAAotz4.png",
      "id_str" : "674340628948525056",
      "id" : 674340628948525056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CVu9Oq4XIAAotz4.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jLkkiGaKSW"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 87, 100 ]
    }, {
      "text" : "COP21",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674340692139728896",
  "text" : "FACT: Carbon pollution in our atmosphere is higher than at any point in human history. #ActOnClimate #COP21 https:\/\/t.co\/jLkkiGaKSW",
  "id" : 674340692139728896,
  "created_at" : "2015-12-08 21:32:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/674325263136739328\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/kA3Wlbmafh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVuutYfWoAAfjj3.jpg",
      "id_str" : "674324663913324544",
      "id" : 674324663913324544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVuutYfWoAAfjj3.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kA3Wlbmafh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "674325263136739328",
  "text" : "Here's how the U.S. &amp; the international community will defeat ISIL abroad: https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/kA3Wlbmafh",
  "id" : 674325263136739328,
  "created_at" : "2015-12-08 20:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/YFgbTTeYCx",
      "expanded_url" : "http:\/\/snpy.tv\/1jIYHDl",
      "display_url" : "snpy.tv\/1jIYHDl"
    } ]
  },
  "geo" : { },
  "id_str" : "674319318520348672",
  "text" : "\"Congress should act to make sure no one on a No-Fly List is able to buy a gun.\" \u2014@POTUS https:\/\/t.co\/YFgbTTeYCx",
  "id" : 674319318520348672,
  "created_at" : "2015-12-08 20:07:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/lg9ang4yEe",
      "expanded_url" : "http:\/\/go.wh.gov\/aYEGrv",
      "display_url" : "go.wh.gov\/aYEGrv"
    } ]
  },
  "geo" : { },
  "id_str" : "674281327584264193",
  "text" : "RT @Cecilia44: What's the deal w\/ #ESSA? Your questions answered on the fix to No Child Left Behind: https:\/\/t.co\/lg9ang4yEe https:\/\/t.co\/W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/674264218741268481\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/W9OG16BcS4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVt3u92VEAIYo1r.jpg",
        "id_str" : "674264217982144514",
        "id" : 674264217982144514,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVt3u92VEAIYo1r.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/W9OG16BcS4"
      } ],
      "hashtags" : [ {
        "text" : "ESSA",
        "indices" : [ 19, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/lg9ang4yEe",
        "expanded_url" : "http:\/\/go.wh.gov\/aYEGrv",
        "display_url" : "go.wh.gov\/aYEGrv"
      } ]
    },
    "geo" : { },
    "id_str" : "674264218741268481",
    "text" : "What's the deal w\/ #ESSA? Your questions answered on the fix to No Child Left Behind: https:\/\/t.co\/lg9ang4yEe https:\/\/t.co\/W9OG16BcS4",
    "id" : 674264218741268481,
    "created_at" : "2015-12-08 16:28:11 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 674281327584264193,
  "created_at" : "2015-12-08 17:36:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zocdoc",
      "screen_name" : "Zocdoc",
      "indices" : [ 30, 37 ],
      "id_str" : "19329324",
      "id" : 19329324
    }, {
      "name" : "Oscar",
      "screen_name" : "OscarHealth",
      "indices" : [ 44, 56 ],
      "id_str" : "1603882129",
      "id" : 1603882129
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/674272242101043200\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/AMnTuGvy41",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVt-4GkWoAABRWB.jpg",
      "id_str" : "674272071522885632",
      "id" : 674272071522885632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVt-4GkWoAABRWB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AMnTuGvy41"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/4kKBOTNMGo",
      "expanded_url" : "http:\/\/go.wh.gov\/psnc8m",
      "display_url" : "go.wh.gov\/psnc8m"
    } ]
  },
  "geo" : { },
  "id_str" : "674272242101043200",
  "text" : "Learn how tech companies like @ZocDoc &amp; @OscarHealth are helping Americans #GetCovered: https:\/\/t.co\/4kKBOTNMGo https:\/\/t.co\/AMnTuGvy41",
  "id" : 674272242101043200,
  "created_at" : "2015-12-08 17:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UN Foundation",
      "screen_name" : "unfoundation",
      "indices" : [ 3, 16 ],
      "id_str" : "39511166",
      "id" : 39511166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthToParis",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/QN0QLiTXqy",
      "expanded_url" : "http:\/\/on.fb.me\/1YUNYFM",
      "display_url" : "on.fb.me\/1YUNYFM"
    } ]
  },
  "geo" : { },
  "id_str" : "674232476739362820",
  "text" : "RT @unfoundation: \"Dear Paris,\" A Love Letter From #EarthToParis - Narrated by Morgan Freeman https:\/\/t.co\/QN0QLiTXqy https:\/\/t.co\/Tfg2MrJ3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/unfoundation\/status\/674006771804057601\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/Tfg2MrJ3oM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVqNlmNUkAAtrs6.jpg",
        "id_str" : "674006771296407552",
        "id" : 674006771296407552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVqNlmNUkAAtrs6.jpg",
        "sizes" : [ {
          "h" : 474,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 474,
          "resize" : "fit",
          "w" : 474
        } ],
        "display_url" : "pic.twitter.com\/Tfg2MrJ3oM"
      } ],
      "hashtags" : [ {
        "text" : "EarthToParis",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/QN0QLiTXqy",
        "expanded_url" : "http:\/\/on.fb.me\/1YUNYFM",
        "display_url" : "on.fb.me\/1YUNYFM"
      } ]
    },
    "geo" : { },
    "id_str" : "674006771804057601",
    "text" : "\"Dear Paris,\" A Love Letter From #EarthToParis - Narrated by Morgan Freeman https:\/\/t.co\/QN0QLiTXqy https:\/\/t.co\/Tfg2MrJ3oM",
    "id" : 674006771804057601,
    "created_at" : "2015-12-07 23:25:11 +0000",
    "user" : {
      "name" : "UN Foundation",
      "screen_name" : "unfoundation",
      "protected" : false,
      "id_str" : "39511166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743522714791583744\/m_39lcnC_normal.jpg",
      "id" : 39511166,
      "verified" : true
    }
  },
  "id" : 674232476739362820,
  "created_at" : "2015-12-08 14:22:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/ykHDGQryOv",
      "expanded_url" : "http:\/\/on.natgeo.com\/1QaSj60",
      "display_url" : "on.natgeo.com\/1QaSj60"
    } ]
  },
  "geo" : { },
  "id_str" : "674076179931004928",
  "text" : "RT @NatGeo: The world must act now to reverse climate change, says Obama's science advisor: https:\/\/t.co\/ykHDGQryOv #COP21",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 104, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/ykHDGQryOv",
        "expanded_url" : "http:\/\/on.natgeo.com\/1QaSj60",
        "display_url" : "on.natgeo.com\/1QaSj60"
      } ]
    },
    "geo" : { },
    "id_str" : "673920674575028227",
    "text" : "The world must act now to reverse climate change, says Obama's science advisor: https:\/\/t.co\/ykHDGQryOv #COP21",
    "id" : 673920674575028227,
    "created_at" : "2015-12-07 17:43:04 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798181194202566656\/U8QbCBdH_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 674076179931004928,
  "created_at" : "2015-12-08 04:00:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/674030718675120128\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/RJJvoIQtwt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVqY-3RUkAAwUI3.jpg",
      "id_str" : "674019300001222656",
      "id" : 674019300001222656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVqY-3RUkAAwUI3.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/RJJvoIQtwt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/tomOvxyqMC",
      "expanded_url" : "http:\/\/go.wh.gov\/bpYy9R",
      "display_url" : "go.wh.gov\/bpYy9R"
    } ]
  },
  "geo" : { },
  "id_str" : "674030718675120128",
  "text" : ".@POTUS on Pearl Harbor Remembrance Day: https:\/\/t.co\/tomOvxyqMC https:\/\/t.co\/RJJvoIQtwt",
  "id" : 674030718675120128,
  "created_at" : "2015-12-08 01:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/g3VxwSP7Fe",
      "expanded_url" : "http:\/\/snpy.tv\/1jJ1IUb",
      "display_url" : "snpy.tv\/1jJ1IUb"
    } ]
  },
  "geo" : { },
  "id_str" : "674018478014095360",
  "text" : "ISIL does not speak for Islam. We must reject proposals that claim Muslim Americans should be treated differently. https:\/\/t.co\/g3VxwSP7Fe",
  "id" : 674018478014095360,
  "created_at" : "2015-12-08 00:11:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673991244167569408\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/rUgsaBF2su",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVp_TLEWwAAwKwb.jpg",
      "id_str" : "673991061610610688",
      "id" : 673991061610610688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVp_TLEWwAAwKwb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rUgsaBF2su"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673991244167569408",
  "text" : "We cannot turn against one another by letting this fight be defined as a war between America and Islam. https:\/\/t.co\/rUgsaBF2su",
  "id" : 673991244167569408,
  "created_at" : "2015-12-07 22:23:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/g3VxwSP7Fe",
      "expanded_url" : "http:\/\/snpy.tv\/1jJ1IUb",
      "display_url" : "snpy.tv\/1jJ1IUb"
    } ]
  },
  "geo" : { },
  "id_str" : "673971974255718400",
  "text" : "\"It is our responsibility to reject religious tests on who we admit into this country.\" \u2014@POTUS https:\/\/t.co\/g3VxwSP7Fe",
  "id" : 673971974255718400,
  "created_at" : "2015-12-07 21:06:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673965839356289024\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/efL5eyoYxx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVpoTQfWIAEgssj.jpg",
      "id_str" : "673965774298554369",
      "id" : 673965774298554369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVpoTQfWIAEgssj.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/efL5eyoYxx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673965839356289024",
  "text" : "We will destroy ISIL and any other organization that tries to harm us.\" \u2014@POTUS: https:\/\/t.co\/oDIQ2V3W6i https:\/\/t.co\/efL5eyoYxx",
  "id" : 673965839356289024,
  "created_at" : "2015-12-07 20:42:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 43, 52 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/rw54EiaCmQ",
      "expanded_url" : "http:\/\/snpy.tv\/1IAkzfJ",
      "display_url" : "snpy.tv\/1IAkzfJ"
    } ]
  },
  "geo" : { },
  "id_str" : "673950397577302016",
  "text" : "\"Congress needs to pass a budget on time\" \u2014@PressSec on steps Congress should take to help combat terrorism: https:\/\/t.co\/rw54EiaCmQ",
  "id" : 673950397577302016,
  "created_at" : "2015-12-07 19:41:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/673932403598041089\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/crFkjlz4cT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVpJzEQWwAER-sA.jpg",
      "id_str" : "673932235909808129",
      "id" : 673932235909808129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVpJzEQWwAER-sA.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/crFkjlz4cT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673932403598041089",
  "text" : ".@POTUS on how we can defeat ISIL and keep Americans safe here at home: https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/crFkjlz4cT",
  "id" : 673932403598041089,
  "created_at" : "2015-12-07 18:29:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/673921908015038464\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ybZFp7frYe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVpAY4sUAAAXVOw.jpg",
      "id_str" : "673921890524594176",
      "id" : 673921890524594176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVpAY4sUAAAXVOw.jpg",
      "sizes" : [ {
        "h" : 1008,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 688,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ybZFp7frYe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/FdPysDjiqT",
      "expanded_url" : "https:\/\/medium.com\/@VPOTUS\/notes-from-ukraine-day-one-wheels-down-in-kyiv-4f7253f01d9a#.seus0top6",
      "display_url" : "medium.com\/@VPOTUS\/notes-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673926477050695680",
  "text" : "RT @VP: VP Biden touched down in Ukraine last night. Read his initial notes from the road: https:\/\/t.co\/FdPysDjiqT https:\/\/t.co\/ybZFp7frYe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/673921908015038464\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/ybZFp7frYe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVpAY4sUAAAXVOw.jpg",
        "id_str" : "673921890524594176",
        "id" : 673921890524594176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVpAY4sUAAAXVOw.jpg",
        "sizes" : [ {
          "h" : 1008,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 688,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ybZFp7frYe"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/FdPysDjiqT",
        "expanded_url" : "https:\/\/medium.com\/@VPOTUS\/notes-from-ukraine-day-one-wheels-down-in-kyiv-4f7253f01d9a#.seus0top6",
        "display_url" : "medium.com\/@VPOTUS\/notes-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "673921908015038464",
    "text" : "VP Biden touched down in Ukraine last night. Read his initial notes from the road: https:\/\/t.co\/FdPysDjiqT https:\/\/t.co\/ybZFp7frYe",
    "id" : 673921908015038464,
    "created_at" : "2015-12-07 17:47:58 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 673926477050695680,
  "created_at" : "2015-12-07 18:06:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673919056949317632\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/d706HggWl4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVo9rqhUsAA5bV1.jpg",
      "id_str" : "673918914603036672",
      "id" : 673918914603036672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVo9rqhUsAA5bV1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d706HggWl4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673919056949317632",
  "text" : "Congress should act to make sure no one on a No-Fly List is able to buy a gun. https:\/\/t.co\/oDIQ2V3W6i https:\/\/t.co\/d706HggWl4",
  "id" : 673919056949317632,
  "created_at" : "2015-12-07 17:36:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673908440218140673\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/4e9fe0AW6i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVoz-E3WsAU_dBj.jpg",
      "id_str" : "673908235796131845",
      "id" : 673908235796131845,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVoz-E3WsAU_dBj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4e9fe0AW6i"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673908440218140673",
  "text" : "We must reject proposals that Muslim Americans should somehow be treated differently. https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/4e9fe0AW6i",
  "id" : 673908440218140673,
  "created_at" : "2015-12-07 16:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673902499699564544\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/n2N2ppcinI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVouoqjWEAAaOxv.jpg",
      "id_str" : "673902370397491200",
      "id" : 673902370397491200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVouoqjWEAAaOxv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n2N2ppcinI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673902499699564544",
  "text" : "Here's what Congress should do  now to make it harder for people to buy assault weapons: https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/n2N2ppcinI",
  "id" : 673902499699564544,
  "created_at" : "2015-12-07 16:30:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/A16eYXkOWH",
      "expanded_url" : "http:\/\/snpy.tv\/1jIZ3tr",
      "display_url" : "snpy.tv\/1jIZ3tr"
    } ]
  },
  "geo" : { },
  "id_str" : "673890641257066496",
  "text" : "\"ISIL does not speak for Islam. They are thugs and killers\u2014part of a cult of death\" \u2014@POTUS: https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/A16eYXkOWH",
  "id" : 673890641257066496,
  "created_at" : "2015-12-07 15:43:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673710375125159937\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/EYuezQE4EE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVl_dAnWsAAZrLc.jpg",
      "id_str" : "673709755626598400",
      "id" : 673709755626598400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVl_dAnWsAAZrLc.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EYuezQE4EE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673710375125159937",
  "text" : "\"Freedom is more powerful than fear.\" \u2014@POTUS: https:\/\/t.co\/oDIQ2V3W6i https:\/\/t.co\/EYuezQE4EE",
  "id" : 673710375125159937,
  "created_at" : "2015-12-07 03:47:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673706426057945090\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/SRHaLhj8i4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVl8VumXAAAQoAU.jpg",
      "id_str" : "673706331996618752",
      "id" : 673706331996618752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVl8VumXAAAQoAU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SRHaLhj8i4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673706426057945090",
  "text" : "Here's what Congress can do right now to defeat ISIL here at home \u2192 https:\/\/t.co\/oDIQ2V3W6i https:\/\/t.co\/SRHaLhj8i4",
  "id" : 673706426057945090,
  "created_at" : "2015-12-07 03:31:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673702016456110080\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/n9gwrmYXPv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVl4RvAWIAA54aa.jpg",
      "id_str" : "673701865339625472",
      "id" : 673701865339625472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVl4RvAWIAA54aa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n9gwrmYXPv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673702016456110080",
  "text" : "We must reject religious tests on who we admit into the U.S. https:\/\/t.co\/oDIQ2V3W6i https:\/\/t.co\/n9gwrmYXPv",
  "id" : 673702016456110080,
  "created_at" : "2015-12-07 03:14:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673697248144822272\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/IwHfYn5Gh7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVlzyDnWEAADEzK.jpg",
      "id_str" : "673696923069583360",
      "id" : 673696923069583360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVlzyDnWEAADEzK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IwHfYn5Gh7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/qxWofDUPld",
      "expanded_url" : "http:\/\/go.wh.gov\/gVE6RN",
      "display_url" : "go.wh.gov\/gVE6RN"
    } ]
  },
  "geo" : { },
  "id_str" : "673697248144822272",
  "text" : "The United States and the international community will defeat ISIL.\nHere's how: https:\/\/t.co\/qxWofDUPld https:\/\/t.co\/IwHfYn5Gh7",
  "id" : 673697248144822272,
  "created_at" : "2015-12-07 02:55:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/g3VxwSP7Fe",
      "expanded_url" : "http:\/\/snpy.tv\/1jJ1IUb",
      "display_url" : "snpy.tv\/1jJ1IUb"
    } ]
  },
  "geo" : { },
  "id_str" : "673691464996552704",
  "text" : "\"It is our responsibility to reject proposals that Muslim Americans should somehow be treated differently.\" \u2014@POTUS https:\/\/t.co\/g3VxwSP7Fe",
  "id" : 673691464996552704,
  "created_at" : "2015-12-07 02:32:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/g3VxwSP7Fe",
      "expanded_url" : "http:\/\/snpy.tv\/1jJ1IUb",
      "display_url" : "snpy.tv\/1jJ1IUb"
    } ]
  },
  "geo" : { },
  "id_str" : "673685584951439360",
  "text" : "\"ISIL does not speak for Islam. They are thugs, and killers\u2014part of a cult of death\" \u2014@POTUS https:\/\/t.co\/g3VxwSP7Fe",
  "id" : 673685584951439360,
  "created_at" : "2015-12-07 02:08:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/8gvkcnCAml",
      "expanded_url" : "http:\/\/snpy.tv\/1TuFFg7",
      "display_url" : "snpy.tv\/1TuFFg7"
    } ]
  },
  "geo" : { },
  "id_str" : "673681393549860865",
  "text" : "\"The threat from terrorism is real, but we will overcome it. We will destroy ISIL\"  \u2014@POTUS: https:\/\/t.co\/oDIQ2V3W6i https:\/\/t.co\/8gvkcnCAml",
  "id" : 673681393549860865,
  "created_at" : "2015-12-07 01:52:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/YFgbTSXndX",
      "expanded_url" : "http:\/\/snpy.tv\/1jIYHDl",
      "display_url" : "snpy.tv\/1jIYHDl"
    } ]
  },
  "geo" : { },
  "id_str" : "673675721374482433",
  "text" : "Here are steps Congress can take right now to help defeat the terrorist threat from ISIL and keep Americans safe. https:\/\/t.co\/YFgbTSXndX",
  "id" : 673675721374482433,
  "created_at" : "2015-12-07 01:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/A16eYXCpOf",
      "expanded_url" : "http:\/\/snpy.tv\/1jIZ3tr",
      "display_url" : "snpy.tv\/1jIZ3tr"
    } ]
  },
  "geo" : { },
  "id_str" : "673672638628139008",
  "text" : "Watch President Obama's address to the nation on the threat of terrorism and keeping the American people safe. https:\/\/t.co\/A16eYXCpOf",
  "id" : 673672638628139008,
  "created_at" : "2015-12-07 01:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673671784764346368",
  "text" : "\"Let\u2019s make sure we never forget what makes us exceptional. Let\u2019s not forget that freedom is more powerful than fear\" \u2014@POTUS",
  "id" : 673671784764346368,
  "created_at" : "2015-12-07 01:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673671647904202752",
  "text" : "\"My fellow Americans, I am confident we will succeed in this mission because we are on the right side of history.\" \u2014@POTUS",
  "id" : 673671647904202752,
  "created_at" : "2015-12-07 01:13:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673671498146578432",
  "text" : "\"It is our responsibility to reject proposals that Muslim Americans should somehow be treated differently.\" \u2014@POTUS",
  "id" : 673671498146578432,
  "created_at" : "2015-12-07 01:12:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673671448989335552",
  "text" : "\"It is our responsibility to reject religious tests on who we admit into this country.\" \u2014@POTUS",
  "id" : 673671448989335552,
  "created_at" : "2015-12-07 01:12:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673671236577132545",
  "text" : "\"Moreover, the vast majority of terrorist victims around the world are Muslim.\" \u2014@POTUS: https:\/\/t.co\/oDIQ2V3W6i",
  "id" : 673671236577132545,
  "created_at" : "2015-12-07 01:11:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 141, 147 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673671116724953090",
  "text" : "\"ISIL does not speak for Islam; they are thugs &amp; killers, part of a cult of death; &amp; they account for a tiny fraction of...Muslims\" \u2014@POTUS",
  "id" : 673671116724953090,
  "created_at" : "2015-12-07 01:11:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673671038375366656",
  "text" : "\"We cannot turn against one another by letting this fight be defined as a war between America and Islam.\" \u2014@POTUS",
  "id" : 673671038375366656,
  "created_at" : "2015-12-07 01:11:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673670847178010625",
  "text" : "\"We should not be drawn once more into a long and costly ground war in Iraq or Syria.\" \u2014@POTUS: https:\/\/t.co\/oDIQ2V3W6i",
  "id" : 673670847178010625,
  "created_at" : "2015-12-07 01:10:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673670692982755329",
  "text" : "\"If Congress believes, as I do, that we are at war with ISIL, it should...vote to authorize the continued use of military force\" \u2014@POTUS",
  "id" : 673670692982755329,
  "created_at" : "2015-12-07 01:09:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673670583180136448",
  "text" : "\"We also need to make it harder for people to buy powerful assault weapons like the ones that were used in San Bernardino.\" \u2014@POTUS",
  "id" : 673670583180136448,
  "created_at" : "2015-12-07 01:09:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673670535725735936\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/sfmJiitjZd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVlbwdLWEAA0uHJ.jpg",
      "id_str" : "673670507292659712",
      "id" : 673670507292659712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVlbwdLWEAA0uHJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sfmJiitjZd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673670535725735936",
  "text" : "\"What could possibly be the argument for allowing a terrorist suspect to buy a semi-automatic weapon?\" \u2014@POTUS https:\/\/t.co\/sfmJiitjZd",
  "id" : 673670535725735936,
  "created_at" : "2015-12-07 01:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673670439541936129\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Z1Dh41oimV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVlbr9SWUAIBFX6.jpg",
      "id_str" : "673670430012624898",
      "id" : 673670430012624898,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVlbr9SWUAIBFX6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Z1Dh41oimV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673670439541936129",
  "text" : "\"Congress should act to make sure no one on a No Fly List is able to buy a gun.\" \u2014@POTUS: https:\/\/t.co\/oDIQ2V3W6i https:\/\/t.co\/Z1Dh41oimV",
  "id" : 673670439541936129,
  "created_at" : "2015-12-07 01:08:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673670336420810753",
  "text" : "\"Here at home, we have to work together to address the challenge.  There are several steps that Congress should take right away.\" \u2014@POTUS",
  "id" : 673670336420810753,
  "created_at" : "2015-12-07 01:08:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 137, 143 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673669958560186368",
  "text" : "\"We\u2019re working...to stop ISIL\u2019s operations\u2014to disrupt plots, cut off their financing, &amp; prevent them from recruiting more fighters\" \u2014@POTUS",
  "id" : 673669958560186368,
  "created_at" : "2015-12-07 01:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673669718742450176",
  "text" : "\"The threat from terrorism is real, we will overcome it. We will destroy ISIL and any other organization that tries to harm us.\" \u2014@POTUS",
  "id" : 673669718742450176,
  "created_at" : "2015-12-07 01:05:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673669435677257728",
  "text" : "\"As Commander-in-Chief, I have no greater responsibility than the security of the American people.\" \u2014@POTUS: https:\/\/t.co\/oDIQ2V3W6i",
  "id" : 673669435677257728,
  "created_at" : "2015-12-07 01:04:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673669390190010368",
  "text" : "\"I have authorized U.S. forces to take out terrorists abroad precisely because I know how real the danger is\" \u2014@POTUS",
  "id" : 673669390190010368,
  "created_at" : "2015-12-07 01:04:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673669040687067136",
  "text" : "\"Our nation has been at war with terrorists since al Qaeda killed nearly 3,000 Americans on 9\/11.\" \u2014@POTUS: https:\/\/t.co\/oDIQ2V3W6i",
  "id" : 673669040687067136,
  "created_at" : "2015-12-07 01:03:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673668979009806336",
  "text" : "\"This was an act of terrorism, designed to kill innocent people.\" \u2014@POTUS on the San Bernardino shootings",
  "id" : 673668979009806336,
  "created_at" : "2015-12-07 01:02:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673668813292875776",
  "text" : "\"Tonight, I want to talk with you about this tragedy; the broader threat of terrorism; and how we can keep our country safe.\" \u2014@POTUS",
  "id" : 673668813292875776,
  "created_at" : "2015-12-07 01:02:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673668718392553472\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/liHD3DSpE1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVlaHRRUkAAhUj8.jpg",
      "id_str" : "673668700210237440",
      "id" : 673668700210237440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVlaHRRUkAAhUj8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/liHD3DSpE1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673668718392553472",
  "text" : "Watch @POTUS address the nation on the threat of terrorism and keeping Americans safe \u2192 https:\/\/t.co\/oDIQ2V3W6i https:\/\/t.co\/liHD3DSpE1",
  "id" : 673668718392553472,
  "created_at" : "2015-12-07 01:01:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "673653727933296640",
  "text" : "At 8pm ET, @POTUS will address the nation on the threat of terrorism and steps being taken to keep Americans safe: https:\/\/t.co\/oDIQ2V3W6i",
  "id" : 673653727933296640,
  "created_at" : "2015-12-07 00:02:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The Kennedy Center",
      "screen_name" : "kencen",
      "indices" : [ 57, 64 ],
      "id_str" : "19936078",
      "id" : 19936078
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KCHonors",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/rpbr3h3bEC",
      "expanded_url" : "http:\/\/go.wh.gov\/BjjuQp",
      "display_url" : "go.wh.gov\/BjjuQp"
    } ]
  },
  "geo" : { },
  "id_str" : "673621700353789952",
  "text" : "Tune in at 5pm ET to watch @POTUS deliver remarks at the @KenCen Honors Reception: https:\/\/t.co\/rpbr3h3bEC #KCHonors",
  "id" : 673621700353789952,
  "created_at" : "2015-12-06 21:55:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673609106255577089\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/HAaTSQSxxF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVkj6GJUEAEpfef.jpg",
      "id_str" : "673609100257660929",
      "id" : 673609100257660929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVkj6GJUEAEpfef.jpg",
      "sizes" : [ {
        "h" : 345,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 588,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/HAaTSQSxxF"
    } ],
    "hashtags" : [ {
      "text" : "HappyHanukkah",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/MKyxK1Waw8",
      "expanded_url" : "http:\/\/go.wh.gov\/SekzY9",
      "display_url" : "go.wh.gov\/SekzY9"
    } ]
  },
  "geo" : { },
  "id_str" : "673609106255577089",
  "text" : "\"From my family to yours, Chag Sameach.\" \u2014@POTUS: https:\/\/t.co\/MKyxK1Waw8 #HappyHanukkah https:\/\/t.co\/HAaTSQSxxF",
  "id" : 673609106255577089,
  "created_at" : "2015-12-06 21:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/epXMBxdxsH",
      "expanded_url" : "http:\/\/go.wh.gov\/3MJ3qp",
      "display_url" : "go.wh.gov\/3MJ3qp"
    } ]
  },
  "geo" : { },
  "id_str" : "673589480884862976",
  "text" : "\"We are strong. And we are resilient. And we will not be terrorized.\" \u2014@POTUS: https:\/\/t.co\/epXMBxdxsH",
  "id" : 673589480884862976,
  "created_at" : "2015-12-06 19:47:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673574658617151488\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/lqHNxRnyeI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVjpKM3W4AAQjC7.jpg",
      "id_str" : "673544505753264128",
      "id" : 673544505753264128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVjpKM3W4AAQjC7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lqHNxRnyeI"
    } ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 20, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/LuDRIpMzDo",
      "expanded_url" : "http:\/\/go.wh.gov\/dD7dxA",
      "display_url" : "go.wh.gov\/dD7dxA"
    } ]
  },
  "geo" : { },
  "id_str" : "673574658617151488",
  "text" : "It's time to act to #StopGunViolence. Watch President Obama's weekly address: https:\/\/t.co\/LuDRIpMzDo https:\/\/t.co\/lqHNxRnyeI",
  "id" : 673574658617151488,
  "created_at" : "2015-12-06 18:48:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/rIKIpFteOC",
      "expanded_url" : "http:\/\/go.wh.gov\/2dk1jE",
      "display_url" : "go.wh.gov\/2dk1jE"
    } ]
  },
  "geo" : { },
  "id_str" : "673566349977751552",
  "text" : "We're the first generation to feel the impact of climate change, and the last that can do something about it. #COP21 https:\/\/t.co\/rIKIpFteOC",
  "id" : 673566349977751552,
  "created_at" : "2015-12-06 18:15:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/epXMBxdxsH",
      "expanded_url" : "http:\/\/go.wh.gov\/3MJ3qp",
      "display_url" : "go.wh.gov\/3MJ3qp"
    } ]
  },
  "geo" : { },
  "id_str" : "673559285368946688",
  "text" : "\"As President, my highest priority is the security and safety of the American people.\" \u2014@POTUS: https:\/\/t.co\/epXMBxdxsH",
  "id" : 673559285368946688,
  "created_at" : "2015-12-06 17:47:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673544143965061121\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/kNVMvItpwK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVjozR9WwAA-lQl.jpg",
      "id_str" : "673544111983607808",
      "id" : 673544111983607808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVjozR9WwAA-lQl.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kNVMvItpwK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/LuDRIpMzDo",
      "expanded_url" : "http:\/\/go.wh.gov\/dD7dxA",
      "display_url" : "go.wh.gov\/dD7dxA"
    } ]
  },
  "geo" : { },
  "id_str" : "673544143965061121",
  "text" : "If you're too dangerous to board a plane, you're too dangerous to buy a gun. https:\/\/t.co\/LuDRIpMzDo https:\/\/t.co\/kNVMvItpwK",
  "id" : 673544143965061121,
  "created_at" : "2015-12-06 16:46:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/epXMBxdxsH",
      "expanded_url" : "http:\/\/go.wh.gov\/3MJ3qp",
      "display_url" : "go.wh.gov\/3MJ3qp"
    } ]
  },
  "geo" : { },
  "id_str" : "673524841182453760",
  "text" : "\"If you\u2019re too dangerous to board a plane, you\u2019re too dangerous, by definition, to buy a gun.\" \u2014@POTUS: https:\/\/t.co\/epXMBxdxsH",
  "id" : 673524841182453760,
  "created_at" : "2015-12-06 15:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/b68B45RuKg",
      "expanded_url" : "http:\/\/go.wh.gov\/6N4ULN",
      "display_url" : "go.wh.gov\/6N4ULN"
    } ]
  },
  "geo" : { },
  "id_str" : "673288422648229889",
  "text" : "Tomorrow at 8pm ET, @POTUS will address the nation on the threat of terrorism and keeping the American people safe \u2192 https:\/\/t.co\/b68B45RuKg",
  "id" : 673288422648229889,
  "created_at" : "2015-12-05 23:50:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673259643171307520",
  "text" : "RT @NSCPress: Today, @POTUS received an update on the investigation into the San Bernardino shootings in the Situation Room. https:\/\/t.co\/Y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/673259195613978624\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/Yrk51JQ0Ad",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVflq44UEAAk6ag.jpg",
        "id_str" : "673259194301026304",
        "id" : 673259194301026304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVflq44UEAAk6ag.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Yrk51JQ0Ad"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "673259195613978624",
    "text" : "Today, @POTUS received an update on the investigation into the San Bernardino shootings in the Situation Room. https:\/\/t.co\/Yrk51JQ0Ad",
    "id" : 673259195613978624,
    "created_at" : "2015-12-05 21:54:35 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 673259643171307520,
  "created_at" : "2015-12-05 21:56:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/epXMBxdxsH",
      "expanded_url" : "http:\/\/go.wh.gov\/3MJ3qp",
      "display_url" : "go.wh.gov\/3MJ3qp"
    } ]
  },
  "geo" : { },
  "id_str" : "673252276098600960",
  "text" : "\"People on the No-Fly list can walk into a store and buy a gun...so I\u2019m calling on Congress to close this loophole.\" https:\/\/t.co\/epXMBxdxsH",
  "id" : 673252276098600960,
  "created_at" : "2015-12-05 21:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    }, {
      "text" : "COP21",
      "indices" : [ 100, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/RvB4DGqU2m",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/61f7f890-ba09-438e-9cc8-cc79d5b94a0f",
      "display_url" : "amp.twimg.com\/v\/61f7f890-ba0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673248012999614464",
  "text" : "Watch: @POTUS talks to @CBSThisMonring about our obligation to future generations to #ActOnClimate. #COP21 https:\/\/t.co\/RvB4DGqU2m",
  "id" : 673248012999614464,
  "created_at" : "2015-12-05 21:10:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/epXMBxdxsH",
      "expanded_url" : "http:\/\/go.wh.gov\/3MJ3qp",
      "display_url" : "go.wh.gov\/3MJ3qp"
    } ]
  },
  "geo" : { },
  "id_str" : "673236916314112000",
  "text" : "\"Right now, people on the No-Fly list can walk into a store and buy a gun. That is insane.\" \u2014@POTUS: https:\/\/t.co\/epXMBxdxsH",
  "id" : 673236916314112000,
  "created_at" : "2015-12-05 20:26:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/673230577835773952\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/k6jAT0CDmh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVfLhLtUAAAqdnC.jpg",
      "id_str" : "673230440254144512",
      "id" : 673230440254144512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVfLhLtUAAAqdnC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/k6jAT0CDmh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/LuDRIpMzDo",
      "expanded_url" : "http:\/\/go.wh.gov\/dD7dxA",
      "display_url" : "go.wh.gov\/dD7dxA"
    } ]
  },
  "geo" : { },
  "id_str" : "673230577835773952",
  "text" : "From 2004-2014, more than 2,000 people on the terror watch list were able to purchase guns: https:\/\/t.co\/LuDRIpMzDo https:\/\/t.co\/k6jAT0CDmh",
  "id" : 673230577835773952,
  "created_at" : "2015-12-05 20:00:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/epXMBxdxsH",
      "expanded_url" : "http:\/\/go.wh.gov\/3MJ3qp",
      "display_url" : "go.wh.gov\/3MJ3qp"
    } ]
  },
  "geo" : { },
  "id_str" : "673221808615657472",
  "text" : "\"Here in America, it\u2019s way too easy for dangerous people to get their hands on a gun.\" \u2014@POTUS: https:\/\/t.co\/epXMBxdxsH",
  "id" : 673221808615657472,
  "created_at" : "2015-12-05 19:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673220178402869249\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/4U7ocpsTim",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVfCJlZUAAAJAVy.png",
      "id_str" : "673220139228069888",
      "id" : 673220139228069888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVfCJlZUAAAJAVy.png",
      "sizes" : [ {
        "h" : 317,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 317,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4U7ocpsTim"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673220178402869249",
  "text" : ".@POTUS received an update on the investigation into the San Bernardino shootings. Here's the readout: https:\/\/t.co\/4U7ocpsTim",
  "id" : 673220178402869249,
  "created_at" : "2015-12-05 19:19:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/epXMBxdxsH",
      "expanded_url" : "http:\/\/go.wh.gov\/3MJ3qp",
      "display_url" : "go.wh.gov\/3MJ3qp"
    } ]
  },
  "geo" : { },
  "id_str" : "673206458389946368",
  "text" : "\"The killers in San Bernardino used military-style assault weapons\u2014weapons of war.\" \u2014@POTUS: https:\/\/t.co\/epXMBxdxsH",
  "id" : 673206458389946368,
  "created_at" : "2015-12-05 18:25:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/epXMBxdxsH",
      "expanded_url" : "http:\/\/go.wh.gov\/3MJ3qp",
      "display_url" : "go.wh.gov\/3MJ3qp"
    } ]
  },
  "geo" : { },
  "id_str" : "673191362846580736",
  "text" : "\"This tragedy reminds us of our obligation to do everything in our power, together, to keep our communities safe.\" https:\/\/t.co\/epXMBxdxsH",
  "id" : 673191362846580736,
  "created_at" : "2015-12-05 17:25:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "indices" : [ 77, 92 ],
      "id_str" : "17134268",
      "id" : 17134268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "COP21",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/RvB4DGqU2m",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/61f7f890-ba09-438e-9cc8-cc79d5b94a0f",
      "display_url" : "amp.twimg.com\/v\/61f7f890-ba0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "673187597930262529",
  "text" : "\"You can't build a border wall when it comes to carbon emissions\" \u2014@POTUS to @CBSThisMorning #ActOnClimate #COP21 https:\/\/t.co\/RvB4DGqU2m",
  "id" : 673187597930262529,
  "created_at" : "2015-12-05 17:10:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/673176020761968641\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/LOLTIcIO4F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVeMbR5XAAAHx5m.jpg",
      "id_str" : "673161069603520512",
      "id" : 673161069603520512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVeMbR5XAAAHx5m.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LOLTIcIO4F"
    } ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 48, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/LuDRIpMzDo",
      "expanded_url" : "http:\/\/go.wh.gov\/dD7dxA",
      "display_url" : "go.wh.gov\/dD7dxA"
    } ]
  },
  "geo" : { },
  "id_str" : "673176020761968641",
  "text" : "Sympathy isn't good enough: It's time to act to #StopGunViolence: https:\/\/t.co\/LuDRIpMzDo https:\/\/t.co\/LOLTIcIO4F",
  "id" : 673176020761968641,
  "created_at" : "2015-12-05 16:24:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/epXMBwVWB9",
      "expanded_url" : "http:\/\/go.wh.gov\/3MJ3qp",
      "display_url" : "go.wh.gov\/3MJ3qp"
    } ]
  },
  "geo" : { },
  "id_str" : "673160888006889472",
  "text" : "Watch President Obama's weekly address: \"We Will Not Be Terrorized.\" https:\/\/t.co\/epXMBwVWB9",
  "id" : 673160888006889472,
  "created_at" : "2015-12-05 15:23:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    }, {
      "text" : "COP21",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/RvB4DGqU2m",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/61f7f890-ba09-438e-9cc8-cc79d5b94a0f",
      "display_url" : "amp.twimg.com\/v\/61f7f890-ba0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672938582160478208",
  "text" : ".@POTUS reflects on his future grandkids and why it's so important for the world to #ActOnClimate. #COP21\nhttps:\/\/t.co\/RvB4DGqU2m",
  "id" : 672938582160478208,
  "created_at" : "2015-12-05 00:40:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672921511674671104",
  "text" : "RT @VP: Not a perfect bill, but it's the first certainty our roads and bridges have had in a decade. Glad to see it signed. https:\/\/t.co\/b2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/672920902066176001\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/b2T3zjPDeg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVax_ncWUAMZY6w.jpg",
        "id_str" : "672920900816228355",
        "id" : 672920900816228355,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVax_ncWUAMZY6w.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/b2T3zjPDeg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672920902066176001",
    "text" : "Not a perfect bill, but it's the first certainty our roads and bridges have had in a decade. Glad to see it signed. https:\/\/t.co\/b2T3zjPDeg",
    "id" : 672920902066176001,
    "created_at" : "2015-12-04 23:30:19 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 672921511674671104,
  "created_at" : "2015-12-04 23:32:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 22, 36 ],
      "id_str" : "44177383",
      "id" : 44177383
    }, {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 43, 59 ],
      "id_str" : "65707359",
      "id" : 65707359
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/672905177771429889\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/wUA2QFHGlH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVajYUNWoAEVHJh.jpg",
      "id_str" : "672904832475373569",
      "id" : 672904832475373569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVajYUNWoAEVHJh.jpg",
      "sizes" : [ {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wUA2QFHGlH"
    } ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 90, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672905177771429889",
  "text" : "Today @POTUS met with @GabbyGiffords &amp; @ShuttleCDRKelly to discuss the urgent need to #StopGunViolence. https:\/\/t.co\/wUA2QFHGlH",
  "id" : 672905177771429889,
  "created_at" : "2015-12-04 22:27:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/672877145899732992\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/fhFDDxj91p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVaJ75gWUAEMthf.jpg",
      "id_str" : "672876856480256001",
      "id" : 672876856480256001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVaJ75gWUAEMthf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fhFDDxj91p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672877145899732992",
  "text" : ".@POTUS on passage of the transportation bill and reauthorization of the Export-Import Bank. https:\/\/t.co\/fhFDDxj91p",
  "id" : 672877145899732992,
  "created_at" : "2015-12-04 20:36:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 110, 116 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672864690620358656",
  "text" : "RT @FactsOnClimate: \"Let that be our common purpose in Paris: A world that is worthy of our children\" \u2014@POTUS #COP21 #ActOnClimate https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 83, 89 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 90, 96 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 97, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/j3ac0FM0T6",
        "expanded_url" : "http:\/\/snpy.tv\/1lTUgXK",
        "display_url" : "snpy.tv\/1lTUgXK"
      } ]
    },
    "geo" : { },
    "id_str" : "672864164545560576",
    "text" : "\"Let that be our common purpose in Paris: A world that is worthy of our children\" \u2014@POTUS #COP21 #ActOnClimate https:\/\/t.co\/j3ac0FM0T6",
    "id" : 672864164545560576,
    "created_at" : "2015-12-04 19:44:52 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 672864690620358656,
  "created_at" : "2015-12-04 19:46:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672856210509578246",
  "text" : "RT @vj44: 1. @POTUS has called on Congress to fund quality pre-K for every child. For every $1 we invest in pre-K, we save $7. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 3, 9 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/yJSl8jGizF",
        "expanded_url" : "https:\/\/twitter.com\/blanip\/status\/672831829918007296",
        "display_url" : "twitter.com\/blanip\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672855124910448642",
    "text" : "1. @POTUS has called on Congress to fund quality pre-K for every child. For every $1 we invest in pre-K, we save $7. https:\/\/t.co\/yJSl8jGizF",
    "id" : 672855124910448642,
    "created_at" : "2015-12-04 19:08:57 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 672856210509578246,
  "created_at" : "2015-12-04 19:13:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 64, 69 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/672844099364495360\/photo\/1",
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/h2ZDWt6PGX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVZrVK-WIAE-ITs.jpg",
      "id_str" : "672843205805744129",
      "id" : 672843205805744129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVZrVK-WIAE-ITs.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/h2ZDWt6PGX"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 100, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672844099364495360",
  "text" : "Have questions on poverty &amp; incarceration in the U.S.? Join @VJ44 for a 1:30pm ET Q&amp;A using #CriminalJusticeReform. https:\/\/t.co\/h2ZDWt6PGX",
  "id" : 672844099364495360,
  "created_at" : "2015-12-04 18:25:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Chris Coons",
      "screen_name" : "ChrisCoons",
      "indices" : [ 3, 14 ],
      "id_str" : "15324851",
      "id" : 15324851
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 99, 106 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climatechange",
      "indices" : [ 25, 39 ]
    }, {
      "text" : "COP21",
      "indices" : [ 112, 118 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672842232416874496",
  "text" : "RT @ChrisCoons: Fighting #climatechange depends on government partnering w private sector\u2013 read my @Medium oped #COP21 #ActOnClimate https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 83, 90 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "climatechange",
        "indices" : [ 9, 23 ]
      }, {
        "text" : "COP21",
        "indices" : [ 96, 102 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/H7Odb1gOyy",
        "expanded_url" : "http:\/\/bit.ly\/1RtvrhF",
        "display_url" : "bit.ly\/1RtvrhF"
      } ]
    },
    "geo" : { },
    "id_str" : "672817658887315456",
    "text" : "Fighting #climatechange depends on government partnering w private sector\u2013 read my @Medium oped #COP21 #ActOnClimate https:\/\/t.co\/H7Odb1gOyy",
    "id" : 672817658887315456,
    "created_at" : "2015-12-04 16:40:04 +0000",
    "user" : {
      "name" : "Senator Chris Coons",
      "screen_name" : "ChrisCoons",
      "protected" : false,
      "id_str" : "15324851",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000054078611\/cece0b764e629a2ff53d2242969d9f3e_normal.jpeg",
      "id" : 15324851,
      "verified" : true
    }
  },
  "id" : 672842232416874496,
  "created_at" : "2015-12-04 18:17:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/672824056442437632\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Sh62e80jYj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVZZi65W4AE2RjN.jpg",
      "id_str" : "672823650798723073",
      "id" : 672823650798723073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVZZi65W4AE2RjN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Sh62e80jYj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/QbwHiSbi1Z",
      "expanded_url" : "http:\/\/go.wh.gov\/NovJobs",
      "display_url" : "go.wh.gov\/NovJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "672824056442437632",
  "text" : "Our businesses have added:\n8 million jobs over 3 years \u2713\n13.7 million over 69 months \u2713\n\nhttps:\/\/t.co\/QbwHiSbi1Z https:\/\/t.co\/Sh62e80jYj",
  "id" : 672824056442437632,
  "created_at" : "2015-12-04 17:05:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/672817195991322624\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Pr853nU6xR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVZTlxaWsAE7C-x.jpg",
      "id_str" : "672817102722609153",
      "id" : 672817102722609153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVZTlxaWsAE7C-x.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Pr853nU6xR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672817195991322624",
  "text" : "FACT: The unemployment rate has consistently fallen much faster than economists expected throughout this recovery. https:\/\/t.co\/Pr853nU6xR",
  "id" : 672817195991322624,
  "created_at" : "2015-12-04 16:38:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 103, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672808624855621632",
  "text" : "RT @vj44: Join me today for a Q &amp; A on poverty &amp; incarceration - send in Qs &amp; solutions to #CriminalJusticeReform and I'll answer at 1:30pm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 93, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "672808365576208384",
    "text" : "Join me today for a Q &amp; A on poverty &amp; incarceration - send in Qs &amp; solutions to #CriminalJusticeReform and I'll answer at 1:30pm ET",
    "id" : 672808365576208384,
    "created_at" : "2015-12-04 16:03:09 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 672808624855621632,
  "created_at" : "2015-12-04 16:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/672798691783258112\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/bJoXxqgIxJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVZCoFYWcAA79pv.jpg",
      "id_str" : "672798450744979456",
      "id" : 672798450744979456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVZCoFYWcAA79pv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bJoXxqgIxJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/QbwHiSbi1Z",
      "expanded_url" : "http:\/\/go.wh.gov\/NovJobs",
      "display_url" : "go.wh.gov\/NovJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "672798691783258112",
  "text" : "Worth a RT: Our businesses have now added 13.7 million jobs over the past 69 months. https:\/\/t.co\/QbwHiSbi1Z https:\/\/t.co\/bJoXxqgIxJ",
  "id" : 672798691783258112,
  "created_at" : "2015-12-04 15:24:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/672516321645494272\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/CiCo3qcHHr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVVB_lUW4AE0k-g.jpg",
      "id_str" : "672516279966818305",
      "id" : 672516279966818305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVVB_lUW4AE0k-g.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CiCo3qcHHr"
    } ],
    "hashtags" : [ {
      "text" : "ESSA",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/uyW1ajAsG2",
      "expanded_url" : "http:\/\/go.wh.gov\/nqVqDZ",
      "display_url" : "go.wh.gov\/nqVqDZ"
    } ]
  },
  "geo" : { },
  "id_str" : "672564556129026048",
  "text" : "RT @usedgov: The Every Student Succeeds Act #ESSA is good news for our nation\u2019s schools. https:\/\/t.co\/uyW1ajAsG2 https:\/\/t.co\/CiCo3qcHHr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/672516321645494272\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/CiCo3qcHHr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVVB_lUW4AE0k-g.jpg",
        "id_str" : "672516279966818305",
        "id" : 672516279966818305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVVB_lUW4AE0k-g.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CiCo3qcHHr"
      } ],
      "hashtags" : [ {
        "text" : "ESSA",
        "indices" : [ 31, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/uyW1ajAsG2",
        "expanded_url" : "http:\/\/go.wh.gov\/nqVqDZ",
        "display_url" : "go.wh.gov\/nqVqDZ"
      } ]
    },
    "geo" : { },
    "id_str" : "672516321645494272",
    "text" : "The Every Student Succeeds Act #ESSA is good news for our nation\u2019s schools. https:\/\/t.co\/uyW1ajAsG2 https:\/\/t.co\/CiCo3qcHHr",
    "id" : 672516321645494272,
    "created_at" : "2015-12-03 20:42:40 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 672564556129026048,
  "created_at" : "2015-12-03 23:54:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/vaMjObVqHS",
      "expanded_url" : "http:\/\/go.wh.gov\/Emk1fs",
      "display_url" : "go.wh.gov\/Emk1fs"
    } ]
  },
  "geo" : { },
  "id_str" : "672541426014691328",
  "text" : "RT @FLOTUS: We're ready to light the National Christmas Tree! Watch live: https:\/\/t.co\/vaMjObVqHS #WHHolidays",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHolidays",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/vaMjObVqHS",
        "expanded_url" : "http:\/\/go.wh.gov\/Emk1fs",
        "display_url" : "go.wh.gov\/Emk1fs"
      } ]
    },
    "geo" : { },
    "id_str" : "672540057425846273",
    "text" : "We're ready to light the National Christmas Tree! Watch live: https:\/\/t.co\/vaMjObVqHS #WHHolidays",
    "id" : 672540057425846273,
    "created_at" : "2015-12-03 22:16:59 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 672541426014691328,
  "created_at" : "2015-12-03 22:22:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 15, 29 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/672538957184376833\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/Tbh3Gi8neC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVVWXOzXIAEkioX.jpg",
      "id_str" : "672538676472258561",
      "id" : 672538676472258561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVVWXOzXIAEkioX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Tbh3Gi8neC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672538957184376833",
  "text" : ".@POTUS on the @DeptOfDefense opening up all military positions to women, including combat roles. https:\/\/t.co\/Tbh3Gi8neC",
  "id" : 672538957184376833,
  "created_at" : "2015-12-03 22:12:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/JixeyA8M2f",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/579cd15c-abb6-42d9-98e1-12aa5b55417c",
      "display_url" : "amp.twimg.com\/v\/579cd15c-abb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672487452292997122",
  "text" : "Watch @POTUS deliver a statement on the shooting in San Bernardino.\nhttps:\/\/t.co\/JixeyA8M2f",
  "id" : 672487452292997122,
  "created_at" : "2015-12-03 18:47:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "CBS News",
      "screen_name" : "CBSNews",
      "indices" : [ 24, 32 ],
      "id_str" : "15012486",
      "id" : 15012486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/pA56EzrzUW",
      "expanded_url" : "http:\/\/go.wh.gov\/dEA8yT",
      "display_url" : "go.wh.gov\/dEA8yT"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/SO0cE5nfCX",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/8214060a-516f-43d5-b7c3-cb6f1f1e4722",
      "display_url" : "amp.twimg.com\/v\/8214060a-516\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "672192171068383232",
  "text" : "Watch: @POTUS speaks to @CBSNews on the shooting in San Bernardino. https:\/\/t.co\/pA56EzrzUW\nhttps:\/\/t.co\/SO0cE5nfCX",
  "id" : 672192171068383232,
  "created_at" : "2015-12-02 23:14:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "indices" : [ 3, 18 ],
      "id_str" : "17134268",
      "id" : 17134268
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 29, 35 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Norah O'Donnell",
      "screen_name" : "NorahODonnell",
      "indices" : [ 87, 101 ],
      "id_str" : "21111896",
      "id" : 21111896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/vyA7XqpSB3",
      "expanded_url" : "http:\/\/cbsn.ws\/1IpFv9o",
      "display_url" : "cbsn.ws\/1IpFv9o"
    } ]
  },
  "geo" : { },
  "id_str" : "672181296261668866",
  "text" : "RT @CBSThisMorning: JUST IN: @POTUS responds to San Bernardino shooting, speaking with @NorahODonnell https:\/\/t.co\/vyA7XqpSB3\nhttps:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 9, 15 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Norah O'Donnell",
        "screen_name" : "NorahODonnell",
        "indices" : [ 67, 81 ],
        "id_str" : "21111896",
        "id" : 21111896
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/vyA7XqpSB3",
        "expanded_url" : "http:\/\/cbsn.ws\/1IpFv9o",
        "display_url" : "cbsn.ws\/1IpFv9o"
      }, {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/C3t6swG6gD",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/db41b55b-bac1-404a-b07a-5a438d2a15d2",
        "display_url" : "amp.twimg.com\/v\/db41b55b-bac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "672169400397520896",
    "text" : "JUST IN: @POTUS responds to San Bernardino shooting, speaking with @NorahODonnell https:\/\/t.co\/vyA7XqpSB3\nhttps:\/\/t.co\/C3t6swG6gD",
    "id" : 672169400397520896,
    "created_at" : "2015-12-02 21:44:08 +0000",
    "user" : {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "protected" : false,
      "id_str" : "17134268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651362377540112384\/eNioIfCp_normal.jpg",
      "id" : 17134268,
      "verified" : true
    }
  },
  "id" : 672181296261668866,
  "created_at" : "2015-12-02 22:31:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/N2bu15M3Pv",
      "expanded_url" : "http:\/\/snpy.tv\/1RjfWZi",
      "display_url" : "snpy.tv\/1RjfWZi"
    } ]
  },
  "geo" : { },
  "id_str" : "672127875106099200",
  "text" : "RT if you agree with @POTUS: Climate change is a massive problem, and the time to #ActOnClimate is now. https:\/\/t.co\/N2bu15M3Pv",
  "id" : 672127875106099200,
  "created_at" : "2015-12-02 18:59:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/QscCX2jF76",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/cpPAgQsuSi",
      "expanded_url" : "http:\/\/snpy.tv\/1IzKW09",
      "display_url" : "snpy.tv\/1IzKW09"
    } ]
  },
  "geo" : { },
  "id_str" : "672110657928589312",
  "text" : "\"This is an economic and a security imperative that we have to tackle now.\u201D \u2014@POTUS: https:\/\/t.co\/QscCX2jF76 #COP21  https:\/\/t.co\/cpPAgQsuSi",
  "id" : 672110657928589312,
  "created_at" : "2015-12-02 17:50:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/672093774177312768\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/xuhChs8wSu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVPBrV7WoAAV5dP.jpg",
      "id_str" : "672093719772962816",
      "id" : 672093719772962816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVPBrV7WoAAV5dP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xuhChs8wSu"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 64, 77 ]
    }, {
      "text" : "COP21",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/IU2TIZKAPI",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimatePledge",
      "display_url" : "go.wh.gov\/ClimatePledge"
    } ]
  },
  "geo" : { },
  "id_str" : "672093774177312768",
  "text" : "Spread the word: 154 major American companies are committing to #ActOnClimate \u2192 https:\/\/t.co\/IU2TIZKAPI #COP21 https:\/\/t.co\/xuhChs8wSu",
  "id" : 672093774177312768,
  "created_at" : "2015-12-02 16:43:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Glacier Bay NP",
      "screen_name" : "GlacierBayNPS",
      "indices" : [ 66, 80 ],
      "id_str" : "65670632",
      "id" : 65670632
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/671774577119379456\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/hGZ7mVPU19",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVKfaw6UsAAQ1OD.jpg",
      "id_str" : "671774576586567680",
      "id" : 671774576586567680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVKfaw6UsAAQ1OD.jpg",
      "sizes" : [ {
        "h" : 477,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/hGZ7mVPU19"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672083383703494656",
  "text" : "RT @Interior: McBride Glacier has retreated faster than any other @GlacierBayNPS in past 2 decades #ActOnClimate https:\/\/t.co\/hGZ7mVPU19",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glacier Bay NP",
        "screen_name" : "GlacierBayNPS",
        "indices" : [ 52, 66 ],
        "id_str" : "65670632",
        "id" : 65670632
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/671774577119379456\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/hGZ7mVPU19",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVKfaw6UsAAQ1OD.jpg",
        "id_str" : "671774576586567680",
        "id" : 671774576586567680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVKfaw6UsAAQ1OD.jpg",
        "sizes" : [ {
          "h" : 477,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/hGZ7mVPU19"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671774577119379456",
    "text" : "McBride Glacier has retreated faster than any other @GlacierBayNPS in past 2 decades #ActOnClimate https:\/\/t.co\/hGZ7mVPU19",
    "id" : 671774577119379456,
    "created_at" : "2015-12-01 19:35:14 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 672083383703494656,
  "created_at" : "2015-12-02 16:02:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671852100498903040\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/7dSNeoVOVU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVLlq2vWIAEjAAO.jpg",
      "id_str" : "671851818842988545",
      "id" : 671851818842988545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVLlq2vWIAEjAAO.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/7dSNeoVOVU"
    } ],
    "hashtags" : [ {
      "text" : "AIDSFreeGen",
      "indices" : [ 28, 40 ]
    }, {
      "text" : "WorldAIDSDay",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/m7m2ZK6pXQ",
      "expanded_url" : "http:\/\/go.wh.gov\/2jyiq6",
      "display_url" : "go.wh.gov\/2jyiq6"
    } ]
  },
  "geo" : { },
  "id_str" : "671852100498903040",
  "text" : "Together, we can achieve an #AIDSFreeGen and bring this epidemic to a halt. https:\/\/t.co\/m7m2ZK6pXQ #WorldAIDSDay https:\/\/t.co\/7dSNeoVOVU",
  "id" : 671852100498903040,
  "created_at" : "2015-12-02 00:43:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671822102564089860\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Z8gwzQuve8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVLKePxWcAIpFTM.jpg",
      "id_str" : "671821915410034690",
      "id" : 671821915410034690,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVLKePxWcAIpFTM.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 616,
        "resize" : "fit",
        "w" : 848
      }, {
        "h" : 616,
        "resize" : "fit",
        "w" : 848
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Z8gwzQuve8"
    } ],
    "hashtags" : [ {
      "text" : "GivingTuesday",
      "indices" : [ 5, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/1HwsI2MVd5",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "671822102564089860",
  "text" : "This #GivingTuesday, join Americans from across the country to help aid refugees in need \u2192 https:\/\/t.co\/1HwsI2MVd5 https:\/\/t.co\/Z8gwzQuve8",
  "id" : 671822102564089860,
  "created_at" : "2015-12-01 22:44:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/671800803758317568\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/4iJapwEy3L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVK3NrdWwAY9tmS.jpg",
      "id_str" : "671800740063657990",
      "id" : 671800740063657990,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVK3NrdWwAY9tmS.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/4iJapwEy3L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671800803758317568",
  "text" : "RT if you agree: It's time for Republicans in Congress to prevent terror suspects from being able to buy a gun. https:\/\/t.co\/4iJapwEy3L",
  "id" : 671800803758317568,
  "created_at" : "2015-12-01 21:19:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "indices" : [ 3, 13 ],
      "id_str" : "1707321486",
      "id" : 1707321486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 118, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/DkGPlkrPnW",
      "expanded_url" : "http:\/\/ow.ly\/Vlclu",
      "display_url" : "ow.ly\/Vlclu"
    } ]
  },
  "geo" : { },
  "id_str" : "671788971811323905",
  "text" : "RT @madeleine: 19 national security leaders agree: Congress must not make refugees the enemy. https:\/\/t.co\/DkGPlkrPnW #RefugeesWelcome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RefugeesWelcome",
        "indices" : [ 103, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/DkGPlkrPnW",
        "expanded_url" : "http:\/\/ow.ly\/Vlclu",
        "display_url" : "ow.ly\/Vlclu"
      } ]
    },
    "geo" : { },
    "id_str" : "671769455303761920",
    "text" : "19 national security leaders agree: Congress must not make refugees the enemy. https:\/\/t.co\/DkGPlkrPnW #RefugeesWelcome",
    "id" : 671769455303761920,
    "created_at" : "2015-12-01 19:14:53 +0000",
    "user" : {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "protected" : false,
      "id_str" : "1707321486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482147628650856448\/oTqqAjkX_normal.jpeg",
      "id" : 1707321486,
      "verified" : true
    }
  },
  "id" : 671788971811323905,
  "created_at" : "2015-12-01 20:32:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 81, 93 ]
    }, {
      "text" : "COP21",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671779113137520640",
  "text" : "RT @ErnestMoniz: Why governments &amp; the private sector need to invest more in #CleanEnergy (and how we plan to do it). #COP21 \n\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanEnergy",
        "indices" : [ 64, 76 ]
      }, {
        "text" : "COP21",
        "indices" : [ 105, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/aIvvZOTw5R",
        "expanded_url" : "https:\/\/www.bostonglobe.com\/opinion\/2015\/11\/30\/government-private-sector-need-invest-clean-energy\/nSjYWGp3iuxcrhNaegguvN\/story.html",
        "display_url" : "bostonglobe.com\/opinion\/2015\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671758868813381632",
    "text" : "Why governments &amp; the private sector need to invest more in #CleanEnergy (and how we plan to do it). #COP21 \n\nhttps:\/\/t.co\/aIvvZOTw5R",
    "id" : 671758868813381632,
    "created_at" : "2015-12-01 18:32:49 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 671779113137520640,
  "created_at" : "2015-12-01 19:53:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671746422946045952\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/ROh6S4pJOC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVKEx__WcAQRXQ9.jpg",
      "id_str" : "671745288957227012",
      "id" : 671745288957227012,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVKEx__WcAQRXQ9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ROh6S4pJOC"
    } ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/IU2TIZKAPI",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimatePledge",
      "display_url" : "go.wh.gov\/ClimatePledge"
    } ]
  },
  "geo" : { },
  "id_str" : "671746422946045952",
  "text" : "Big news: 154 companies are calling for strong global action on climate change \u2192 https:\/\/t.co\/IU2TIZKAPI #COP21 https:\/\/t.co\/ROh6S4pJOC",
  "id" : 671746422946045952,
  "created_at" : "2015-12-01 17:43:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 55, 61 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WAD2015",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "AIDSFreeGen",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/WL5W1ClItw",
      "expanded_url" : "http:\/\/go.wh.gov\/2jyiq6",
      "display_url" : "go.wh.gov\/2jyiq6"
    } ]
  },
  "geo" : { },
  "id_str" : "671742814087196672",
  "text" : "RT @NSCPress: On World Aids Day (#WAD2015), here's how @POTUS plans to put an #AIDSFreeGen within reach \u2192 https:\/\/t.co\/WL5W1ClItw https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 41, 47 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/671728969000067072\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/onTggZBs4v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVJ18ASVEAACdW8.jpg",
        "id_str" : "671728968161103872",
        "id" : 671728968161103872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVJ18ASVEAACdW8.jpg",
        "sizes" : [ {
          "h" : 501,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 751,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 751,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/onTggZBs4v"
      } ],
      "hashtags" : [ {
        "text" : "WAD2015",
        "indices" : [ 19, 27 ]
      }, {
        "text" : "AIDSFreeGen",
        "indices" : [ 64, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/WL5W1ClItw",
        "expanded_url" : "http:\/\/go.wh.gov\/2jyiq6",
        "display_url" : "go.wh.gov\/2jyiq6"
      } ]
    },
    "geo" : { },
    "id_str" : "671728969000067072",
    "text" : "On World Aids Day (#WAD2015), here's how @POTUS plans to put an #AIDSFreeGen within reach \u2192 https:\/\/t.co\/WL5W1ClItw https:\/\/t.co\/onTggZBs4v",
    "id" : 671728969000067072,
    "created_at" : "2015-12-01 16:34:00 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 671742814087196672,
  "created_at" : "2015-12-01 17:29:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodtrouble",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671720665225936897",
  "text" : "RT @repjohnlewis: The actions of Rosa Parks on this day 60 years ago ushered in a nonviolent revolution. #goodtrouble https:\/\/t.co\/t4wBqA03\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/671702086938177536\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/t4wBqA03uk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVJdfSGVAAMRVup.jpg",
        "id_str" : "671702086447333379",
        "id" : 671702086447333379,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVJdfSGVAAMRVup.jpg",
        "sizes" : [ {
          "h" : 387,
          "resize" : "fit",
          "w" : 290
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 290
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 290
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 290
        } ],
        "display_url" : "pic.twitter.com\/t4wBqA03uk"
      } ],
      "hashtags" : [ {
        "text" : "goodtrouble",
        "indices" : [ 87, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671702086938177536",
    "text" : "The actions of Rosa Parks on this day 60 years ago ushered in a nonviolent revolution. #goodtrouble https:\/\/t.co\/t4wBqA03uk",
    "id" : 671702086938177536,
    "created_at" : "2015-12-01 14:47:11 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 671720665225936897,
  "created_at" : "2015-12-01 16:01:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671711615830634496\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/wq66wazHbu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVJl-xYWoAEXA85.jpg",
      "id_str" : "671711423513403393",
      "id" : 671711423513403393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVJl-xYWoAEXA85.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/wq66wazHbu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/yAr1N1QzZ1",
      "expanded_url" : "http:\/\/go.wh.gov\/N6hqNM",
      "display_url" : "go.wh.gov\/N6hqNM"
    } ]
  },
  "geo" : { },
  "id_str" : "671711615830634496",
  "text" : "\"Sixty years ago today, Rosa Parks changed America.\" \u2014@POTUS: https:\/\/t.co\/yAr1N1QzZ1 https:\/\/t.co\/wq66wazHbu",
  "id" : 671711615830634496,
  "created_at" : "2015-12-01 15:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/BUhyI7reKb",
      "expanded_url" : "http:\/\/snpy.tv\/1Im2hPj",
      "display_url" : "snpy.tv\/1Im2hPj"
    } ]
  },
  "geo" : { },
  "id_str" : "671705466947375104",
  "text" : "Watch @POTUS lay out what a successful global climate agreement looks like at #COP21 in Paris. #ActOnClimate https:\/\/t.co\/BUhyI7reKb",
  "id" : 671705466947375104,
  "created_at" : "2015-12-01 15:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 120, 126 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671679049450856448",
  "text" : "\"A successful two weeks here could give the world the same kind of optimism that the future is ours to shape.\u201D  \u2014@POTUS #COP21 #ActOnClimate",
  "id" : 671679049450856448,
  "created_at" : "2015-12-01 13:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671678505424306176",
  "text" : "\"More than 180 countries have followed our lead in announcing their own targets.\u201D  \u2014@POTUS at #COP21 #ActOnClimate",
  "id" : 671678505424306176,
  "created_at" : "2015-12-01 13:13:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671678239299932161\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/X3OnXoPECS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVJHxD8UAAA2--n.jpg",
      "id_str" : "671678202629062656",
      "id" : 671678202629062656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVJHxD8UAAA2--n.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/X3OnXoPECS"
    } ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 89, 95 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671678239299932161",
  "text" : "\u201CWe\u2019ve increased production of clean energy, and worked to reduce emissions\u201D  \u2014@POTUS at #COP21 #ActOnClimate https:\/\/t.co\/X3OnXoPECS",
  "id" : 671678239299932161,
  "created_at" : "2015-12-01 13:12:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 88, 94 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671678128641609733",
  "text" : "\u201CThis is an economic and a security imperative that we have to tackle now.\u201D  \u2014@POTUS at #COP21 #ActOnClimate",
  "id" : 671678128641609733,
  "created_at" : "2015-12-01 13:11:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671678057556537345\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/i6MWMLSkoJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVJHnXYUkAAqEpv.jpg",
      "id_str" : "671678036048121856",
      "id" : 671678036048121856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVJHnXYUkAAqEpv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/i6MWMLSkoJ"
    } ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 69, 75 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 76, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671678057556537345",
  "text" : "\"This one trend\u2014climate change\u2014 will affect all trends.\u201D  \u2014@POTUS at #COP21 #ActOnClimate https:\/\/t.co\/i6MWMLSkoJ",
  "id" : 671678057556537345,
  "created_at" : "2015-12-01 13:11:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671677878572998657",
  "text" : "\u201CWe have accomplished a lot here, and I have high hopes that over the next two weeks, we\u2019ll accomplish even more.\u201D  \u2014@POTUS #COP21",
  "id" : 671677878572998657,
  "created_at" : "2015-12-01 13:11:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/CE6eQjSa0O",
      "expanded_url" : "http:\/\/go.wh.gov\/NpwLPg",
      "display_url" : "go.wh.gov\/NpwLPg"
    } ]
  },
  "geo" : { },
  "id_str" : "671677453371359232",
  "text" : "Watch live: @POTUS holds a press conference at the Paris climate conference \u2192 https:\/\/t.co\/CE6eQjSa0O #COP21",
  "id" : 671677453371359232,
  "created_at" : "2015-12-01 13:09:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]