Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/KpQrNkGDoG",
      "expanded_url" : "http:\/\/at.wh.gov\/orG7V",
      "display_url" : "at.wh.gov\/orG7V"
    } ]
  },
  "geo" : { },
  "id_str" : "373882783539920896",
  "text" : "Earlier today, President Obama delivered a statement on #Syria from the Rose Garden. Watch \u2014&gt; http:\/\/t.co\/KpQrNkGDoG",
  "id" : 373882783539920896,
  "created_at" : "2013-08-31 18:59:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "373865450457018368",
  "text" : "Happening now: President Obama delivers a statement on #Syria in the Rose Garden. Watch \u2014&gt; http:\/\/t.co\/b4tqL36eMn",
  "id" : 373865450457018368,
  "created_at" : "2013-08-31 17:50:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/L11exG7nZr",
      "expanded_url" : "http:\/\/at.wh.gov\/orhM6",
      "display_url" : "at.wh.gov\/orhM6"
    } ]
  },
  "geo" : { },
  "id_str" : "373845250697347072",
  "text" : "\"I hope you\u2019ll...take a moment to reflect on the many contributions of our working men and women.\" \u2014Obama: http:\/\/t.co\/L11exG7nZr #LaborDay",
  "id" : 373845250697347072,
  "created_at" : "2013-08-31 16:30:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "373843677300674560",
  "text" : "At 1:15 ET, President Obama will deliver a statement on #Syria in the Rose Garden. Watch: http:\/\/t.co\/b4tqL36eMn",
  "id" : 373843677300674560,
  "created_at" : "2013-08-31 16:24:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/XNFRRBFmpO",
      "expanded_url" : "http:\/\/at.wh.gov\/orhJs",
      "display_url" : "at.wh.gov\/orhJs"
    } ]
  },
  "geo" : { },
  "id_str" : "373807497930633216",
  "text" : "\"We\u2019ll pay tribute to the values working Americans embody\u2014hard work, responsibility, sacrifice.\" \u2014Obama on #LaborDay: http:\/\/t.co\/XNFRRBFmpO",
  "id" : 373807497930633216,
  "created_at" : "2013-08-31 14:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/SMvMKQdRiX",
      "expanded_url" : "http:\/\/at.wh.gov\/ormLj",
      "display_url" : "at.wh.gov\/ormLj"
    } ]
  },
  "geo" : { },
  "id_str" : "373791111112048640",
  "text" : "\"We\u2019ll pay tribute to the values working Americans embody\u2014hard work, responsibility, sacrifice.\" \u2014Obama on #LaborDay: http:\/\/t.co\/SMvMKQdRiX",
  "id" : 373791111112048640,
  "created_at" : "2013-08-31 12:55:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/373551078257606656\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/lPed1f2rjK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS8euf2CQAAMIDg.jpg",
      "id_str" : "373551078265995264",
      "id" : 373551078265995264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS8euf2CQAAMIDg.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lPed1f2rjK"
    } ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373551078257606656",
  "text" : "This morning, President Obama met with his National Security Council on #Syria: http:\/\/t.co\/lPed1f2rjK",
  "id" : 373551078257606656,
  "created_at" : "2013-08-30 21:01:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373542155718885376",
  "text" : "\"We cannot accept a world where women and children and innocent civilians are gassed on an incredible scale.\" \u2014President Obama on #Syria",
  "id" : 373542155718885376,
  "created_at" : "2013-08-30 20:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373541528062279681",
  "text" : "\"What we will do is consider options that meet the narrow concern around chemical weapons.\" \u2014President Obama on #Syria",
  "id" : 373541528062279681,
  "created_at" : "2013-08-30 20:23:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373541189120561152",
  "text" : "\"We're not considering any open-ended commitment. We're not considering any boots-on-the-ground approach.\" \u2014President Obama on #Syria",
  "id" : 373541189120561152,
  "created_at" : "2013-08-30 20:22:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 130, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/TzV0IZKiWa",
      "expanded_url" : "http:\/\/at.wh.gov\/oq62G",
      "display_url" : "at.wh.gov\/oq62G"
    } ]
  },
  "geo" : { },
  "id_str" : "373476223013236737",
  "text" : "FACT: Obama's new efficiency standards would save enough energy to power 50 million homes for a year \u2014&gt; http:\/\/t.co\/TzV0IZKiWa #ActOnClimate",
  "id" : 373476223013236737,
  "created_at" : "2013-08-30 16:04:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373462118302904320",
  "text" : "RT @Simas44: More good ACA news. 21% savings on premiums for Ohioans who buy their own health insurance because of the ACA.  http:\/\/t.co\/dA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/dAz1humOoX",
        "expanded_url" : "http:\/\/bit.ly\/171VJMf",
        "display_url" : "bit.ly\/171VJMf"
      } ]
    },
    "geo" : { },
    "id_str" : "373452984811659264",
    "text" : "More good ACA news. 21% savings on premiums for Ohioans who buy their own health insurance because of the ACA.  http:\/\/t.co\/dAz1humOoX",
    "id" : 373452984811659264,
    "created_at" : "2013-08-30 14:31:44 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 373462118302904320,
  "created_at" : "2013-08-30 15:08:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 77, 86 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/YC3znEuNDh",
      "expanded_url" : "http:\/\/huff.to\/12SQWPP",
      "display_url" : "huff.to\/12SQWPP"
    } ]
  },
  "geo" : { },
  "id_str" : "373454007873699841",
  "text" : "\"Let's create more opportunity for more working people in the years ahead.\" \u2014@LaborSec Tom Perez: http:\/\/t.co\/YC3znEuNDh #LaborDay",
  "id" : 373454007873699841,
  "created_at" : "2013-08-30 14:35:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earvin Magic Johnson",
      "screen_name" : "MagicJohnson",
      "indices" : [ 3, 16 ],
      "id_str" : "248900032",
      "id" : 248900032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373263686510469120",
  "text" : "RT @MagicJohnson: Don't forget that Obamacare officially starts on October 1st.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373231980772851712",
    "text" : "Don't forget that Obamacare officially starts on October 1st.",
    "id" : 373231980772851712,
    "created_at" : "2013-08-29 23:53:33 +0000",
    "user" : {
      "name" : "Earvin Magic Johnson",
      "screen_name" : "MagicJohnson",
      "protected" : false,
      "id_str" : "248900032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735621697642975232\/YznfoCzt_normal.jpg",
      "id" : 248900032,
      "verified" : true
    }
  },
  "id" : 373263686510469120,
  "created_at" : "2013-08-30 01:59:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373221068019757056",
  "text" : "RT @WhiteHouseCEQ: New energy efficiency rules would save American families and businesses money, and cut carbon pollution http:\/\/t.co\/a5Ry\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/a5RyzgPsvt",
        "expanded_url" : "http:\/\/at.wh.gov\/2zuxI6",
        "display_url" : "at.wh.gov\/2zuxI6"
      } ]
    },
    "geo" : { },
    "id_str" : "373215642217754624",
    "text" : "New energy efficiency rules would save American families and businesses money, and cut carbon pollution http:\/\/t.co\/a5RyzgPsvt #ActOnClimate",
    "id" : 373215642217754624,
    "created_at" : "2013-08-29 22:48:37 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 373221068019757056,
  "created_at" : "2013-08-29 23:10:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/373214417896210432\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/hyFWl3yhe3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS3siSQCAAEi8n0.jpg",
      "id_str" : "373214417900404737",
      "id" : 373214417900404737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS3siSQCAAEi8n0.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/hyFWl3yhe3"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 51, 55 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 56, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/HWj6vwrFma",
      "expanded_url" : "http:\/\/at.wh.gov\/oo4Vu",
      "display_url" : "at.wh.gov\/oo4Vu"
    } ]
  },
  "geo" : { },
  "id_str" : "373214417896210432",
  "text" : "Back to school, circa 1978: http:\/\/t.co\/HWj6vwrFma #TBT #ThrowbackThursday, http:\/\/t.co\/hyFWl3yhe3",
  "id" : 373214417896210432,
  "created_at" : "2013-08-29 22:43:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GIF",
      "indices" : [ 20, 24 ]
    }, {
      "text" : "TBT",
      "indices" : [ 102, 106 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 107, 125 ]
    }, {
      "text" : "WhitneyYoung",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NhRnpEfZQO",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21estd2VWT",
      "display_url" : "tmblr.co\/ZW21estd2VWT"
    } ]
  },
  "geo" : { },
  "id_str" : "373202674390278144",
  "text" : "RT @FLOTUS: Watch a #GIF of the First Lady through her high school years \u2014&gt; http:\/\/t.co\/NhRnpEfZQO #TBT #ThrowbackThursday #WhitneyYoung",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GIF",
        "indices" : [ 8, 12 ]
      }, {
        "text" : "TBT",
        "indices" : [ 90, 94 ]
      }, {
        "text" : "ThrowbackThursday",
        "indices" : [ 95, 113 ]
      }, {
        "text" : "WhitneyYoung",
        "indices" : [ 114, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/NhRnpEfZQO",
        "expanded_url" : "http:\/\/tmblr.co\/ZW21estd2VWT",
        "display_url" : "tmblr.co\/ZW21estd2VWT"
      } ]
    },
    "geo" : { },
    "id_str" : "373202272810844161",
    "text" : "Watch a #GIF of the First Lady through her high school years \u2014&gt; http:\/\/t.co\/NhRnpEfZQO #TBT #ThrowbackThursday #WhitneyYoung",
    "id" : 373202272810844161,
    "created_at" : "2013-08-29 21:55:30 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 373202674390278144,
  "created_at" : "2013-08-29 21:57:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/BsCpxSBQva",
      "expanded_url" : "http:\/\/at.wh.gov\/ookKf",
      "display_url" : "at.wh.gov\/ookKf"
    } ]
  },
  "geo" : { },
  "id_str" : "373179322606948352",
  "text" : "If you missed it yesterday, you should watch President Obama's #MLKDream50 speech \u2014&gt; http:\/\/t.co\/BsCpxSBQva",
  "id" : 373179322606948352,
  "created_at" : "2013-08-29 20:24:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarriageEquality",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/uK13ZjG4m7",
      "expanded_url" : "http:\/\/at.wh.gov\/ooelm",
      "display_url" : "at.wh.gov\/ooelm"
    } ]
  },
  "geo" : { },
  "id_str" : "373149556042924032",
  "text" : "Great news: All legal same-sex marriages will now be recognized for federal tax purposes \u2014&gt; http:\/\/t.co\/uK13ZjG4m7 #MarriageEquality",
  "id" : 373149556042924032,
  "created_at" : "2013-08-29 18:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 1, 12 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/caAEkHZhj4",
      "expanded_url" : "http:\/\/ow.ly\/oockP",
      "display_url" : "ow.ly\/oockP"
    } ]
  },
  "geo" : { },
  "id_str" : "373144988957147137",
  "text" : ".@ArneDuncan's top 9 things every college freshman needs to know\u2026in GIFs \u2014&gt; http:\/\/t.co\/caAEkHZhj4",
  "id" : 373144988957147137,
  "created_at" : "2013-08-29 18:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/373135521578762240\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/BY2kPQiuYF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BS2kx5uIEAArjVf.jpg",
      "id_str" : "373135521356451840",
      "id" : 373135521356451840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS2kx5uIEAArjVf.jpg",
      "sizes" : [ {
        "h" : 1323,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 775,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3193,
        "resize" : "fit",
        "w" : 2472
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BY2kPQiuYF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373135521578762240",
  "text" : "\"Freedom is not given. It must be won through struggle and discipline, persistence and faith.\" \u2014President Obama, http:\/\/t.co\/BY2kPQiuYF",
  "id" : 373135521578762240,
  "created_at" : "2013-08-29 17:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "ATF HQ",
      "screen_name" : "ATFHQ",
      "indices" : [ 20, 26 ],
      "id_str" : "459362054",
      "id" : 459362054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373128168770531329",
  "text" : "RT @VP: VP meets w\/ @ATFHQ Dir. Todd Jones, his family &amp; AG Holder in his office today before ceremonially swearing in Jones. http:\/\/t.co\/w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ATF HQ",
        "screen_name" : "ATFHQ",
        "indices" : [ 12, 18 ],
        "id_str" : "459362054",
        "id" : 459362054
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/373123798641295360\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/wSJAcXUcna",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BS2aHjOCQAEt2sJ.jpg",
        "id_str" : "373123798645489665",
        "id" : 373123798645489665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BS2aHjOCQAEt2sJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/wSJAcXUcna"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "373123798641295360",
    "text" : "VP meets w\/ @ATFHQ Dir. Todd Jones, his family &amp; AG Holder in his office today before ceremonially swearing in Jones. http:\/\/t.co\/wSJAcXUcna",
    "id" : 373123798641295360,
    "created_at" : "2013-08-29 16:43:40 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 373128168770531329,
  "created_at" : "2013-08-29 17:01:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373116667389550592",
  "text" : "RT if you agree: We owe it to our kids to act on reducing gun violence by closing background check loopholes for gun sales. #NowIsTheTime",
  "id" : 373116667389550592,
  "created_at" : "2013-08-29 16:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/WzD8dB3IlL",
      "expanded_url" : "http:\/\/at.wh.gov\/onCYC",
      "display_url" : "at.wh.gov\/onCYC"
    } ]
  },
  "geo" : { },
  "id_str" : "373106575260794880",
  "text" : "FACT: Obama just took steps to reduce gun violence by keeping surplus military weapons off our streets. http:\/\/t.co\/WzD8dB3IlL #NowIsTheTime",
  "id" : 373106575260794880,
  "created_at" : "2013-08-29 15:35:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373096213530157057",
  "text" : "FACT: Obama's new action will reduce gun violence by requiring background checks for guns registered to corporations &amp; trusts. #NowIsTheTime",
  "id" : 373096213530157057,
  "created_at" : "2013-08-29 14:54:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/SVFu4M87uJ",
      "expanded_url" : "http:\/\/at.wh.gov\/onCYC",
      "display_url" : "at.wh.gov\/onCYC"
    } ]
  },
  "geo" : { },
  "id_str" : "373088520446803971",
  "text" : "RT to spread the word: President Obama just took new steps to reduce gun violence \u2014&gt; http:\/\/t.co\/SVFu4M87uJ #NowIsTheTime",
  "id" : 373088520446803971,
  "created_at" : "2013-08-29 14:23:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "373077115890958338",
  "text" : "RT @Lehrich44: President Obama continuing to do everything in his power to reduce gun violence. Congress still needs to act. --&gt; http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/TGRICtijAY",
        "expanded_url" : "http:\/\/hosted.ap.org\/dynamic\/stories\/U\/US_GUN_CONTROL?SITE=AP&SECTION=HOME&TEMPLATE=DEFAULT#245acc75-ff76-4bc6-851f-e76c7dabf88d",
        "display_url" : "hosted.ap.org\/dynamic\/storie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "373074829181976577",
    "text" : "President Obama continuing to do everything in his power to reduce gun violence. Congress still needs to act. --&gt; http:\/\/t.co\/TGRICtijAY",
    "id" : 373074829181976577,
    "created_at" : "2013-08-29 13:29:05 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 373077115890958338,
  "created_at" : "2013-08-29 13:38:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/372878820208295936\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/TolR18Z7qG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSy7T6ZIAAAVy89.jpg",
      "id_str" : "372878819931455488",
      "id" : 372878819931455488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSy7T6ZIAAAVy89.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/TolR18Z7qG"
    } ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372878820208295936",
  "text" : "Let's keep marching until every American has the opportunity to realize their dreams. #MLKDream50, http:\/\/t.co\/TolR18Z7qG",
  "id" : 372878820208295936,
  "created_at" : "2013-08-29 00:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/SmdfjU67cT",
      "expanded_url" : "http:\/\/at.wh.gov\/omAeN",
      "display_url" : "at.wh.gov\/omAeN"
    } ]
  },
  "geo" : { },
  "id_str" : "372870967602601984",
  "text" : "The moment you don't want to miss from President Obama's #MLKDream50 speech \u2014&gt; http:\/\/t.co\/SmdfjU67cT",
  "id" : 372870967602601984,
  "created_at" : "2013-08-28 23:59:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Z0rnsptnrU",
      "expanded_url" : "http:\/\/at.wh.gov\/omwyS",
      "display_url" : "at.wh.gov\/omwyS"
    } ]
  },
  "geo" : { },
  "id_str" : "372858665989980161",
  "text" : "Our favorite moments of President Obama with icons of the Civil Rights Movement \u2014&gt; http:\/\/t.co\/Z0rnsptnrU #MLKDream50",
  "id" : 372858665989980161,
  "created_at" : "2013-08-28 23:10:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/372835627789606912\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/JAHMnls9mg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSyUBzJCYAAtY2H.jpg",
      "id_str" : "372835627793801216",
      "id" : 372835627793801216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSyUBzJCYAAtY2H.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JAHMnls9mg"
    } ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372835627789606912",
  "text" : "Obama: \"The arc of the moral universe may bend towards justice, but it does not bend on its own.\" #MLKDream50, http:\/\/t.co\/JAHMnls9mg",
  "id" : 372835627789606912,
  "created_at" : "2013-08-28 21:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372808371755180032",
  "text" : "Today, we're reminded that freedom is not given, but won\u2014through struggle and discipline and persistence and faith. Let's keep marching. \u2014bo",
  "id" : 372808371755180032,
  "created_at" : "2013-08-28 19:50:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372804383299629056",
  "text" : "President Obama: \"In the face of impossible odds, people who love their country can change it.\" #MLKDream50",
  "id" : 372804383299629056,
  "created_at" : "2013-08-28 19:34:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372804303876292608",
  "text" : "President Obama: \"The father who realizes the most important job he\u2019ll ever have is raising his boy right\u2014he\u2019s marching.\" #MLKDream50",
  "id" : 372804303876292608,
  "created_at" : "2013-08-28 19:34:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372804011113848832",
  "text" : "Obama: \"That tireless teacher who gets to class early and stays late and dips into her own pocket to buy supplies...she\u2019s marching.\"",
  "id" : 372804011113848832,
  "created_at" : "2013-08-28 19:32:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372803861490454528",
  "text" : "President Obama: \"The road will be long, but I know we can get there. Yes, we will stumble, but I know we\u2019ll get back up.\" #MLKDream50",
  "id" : 372803861490454528,
  "created_at" : "2013-08-28 19:32:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372803722113732608",
  "text" : "Obama: \"We can feed the hungry, and house the homeless, and transform bleak wastelands of poverty into fields of commerce and promise.\"",
  "id" : 372803722113732608,
  "created_at" : "2013-08-28 19:31:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372803505305964544",
  "text" : "President Obama: \"With that courage, we can stand together for good jobs and just wages.\" #MLKDream50",
  "id" : 372803505305964544,
  "created_at" : "2013-08-28 19:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372803315756965888",
  "text" : "President Obama: \"That\u2019s where courage comes from\u2014when we turn not from each other or on each other, but towards one another.\" #MLKDream50",
  "id" : 372803315756965888,
  "created_at" : "2013-08-28 19:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372803098148106240",
  "text" : "Obama: \"We will have to reignite the embers of empathy and fellow feeling...that found expression in this place 50 years ago.\" #MLKDream50",
  "id" : 372803098148106240,
  "created_at" : "2013-08-28 19:29:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372802953868247040",
  "text" : "Obama: \"The March on Washington teaches us that we are not trapped by the mistakes of history; that we are masters of our fate.\" #MLKDream50",
  "id" : 372802953868247040,
  "created_at" : "2013-08-28 19:28:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/372802629773959168\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/YiuHCWJ2bu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSx2BD9CIAAMcPo.png",
      "id_str" : "372802629778153472",
      "id" : 372802629778153472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSx2BD9CIAAMcPo.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/YiuHCWJ2bu"
    } ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372802629773959168",
  "text" : "The view from the Lincoln Memorial where Martin Luther King, Jr. stood 50 years ago today. #MLKDream50, http:\/\/t.co\/YiuHCWJ2bu",
  "id" : 372802629773959168,
  "created_at" : "2013-08-28 19:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372801905418063873",
  "text" : "RT @WHLive: Obama: \"In too many communities across this country in cities &amp; suburbs &amp; rural hamlets, the shadow of poverty casts a pall ove\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372801613834235904",
    "text" : "Obama: \"In too many communities across this country in cities &amp; suburbs &amp; rural hamlets, the shadow of poverty casts a pall over our youth.\"",
    "id" : 372801613834235904,
    "created_at" : "2013-08-28 19:23:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 372801905418063873,
  "created_at" : "2013-08-28 19:24:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/Ez7xDK4vfV",
      "expanded_url" : "http:\/\/instagram.com\/p\/dkWm7FQivG",
      "display_url" : "instagram.com\/p\/dkWm7FQivG"
    } ]
  },
  "geo" : { },
  "id_str" : "372801110651576320",
  "text" : "A look at the crowd gathered on the National Mall as President Obama takes the stage to honor #MLKDream50. Watch \u2014&gt; http:\/\/t.co\/Ez7xDK4vfV",
  "id" : 372801110651576320,
  "created_at" : "2013-08-28 19:21:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372800915767824384",
  "text" : "Obama: Those \"who gathered 50 years ago were not there in search of some abstract ideal. They were seeking jobs as well as justice.\"",
  "id" : 372800915767824384,
  "created_at" : "2013-08-28 19:20:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372800575207116800",
  "text" : "President Obama: \"To secure the gains this country has made requires continued vigilance, not complacency.\" #MLKDream50",
  "id" : 372800575207116800,
  "created_at" : "2013-08-28 19:19:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372800327017594880",
  "text" : "President Obama: \"The arc of the moral universe may bend towards justice, but it does not bend on its own.\" #MLKDream50",
  "id" : 372800327017594880,
  "created_at" : "2013-08-28 19:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 133, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372800077703958529",
  "text" : "Obama: \"To dismiss the magnitude of this progress...dishonors the courage &amp; the sacrifice of those who paid the price to march.\" #MLKDream50",
  "id" : 372800077703958529,
  "created_at" : "2013-08-28 19:17:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372799669862412289",
  "text" : "President Obama: \"Because they marched, America became more fair and more free.\" #MLKDream50",
  "id" : 372799669862412289,
  "created_at" : "2013-08-28 19:15:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372799414730903553",
  "text" : "President Obama: \"Because they marched, a Civil Rights law was passed. Because they marched, a Voting Rights law was signed.\" #MLKDream50",
  "id" : 372799414730903553,
  "created_at" : "2013-08-28 19:14:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372799246275469312",
  "text" : "RT @WHLive: President Obama: \"Through setbacks and heartbreaks and gnawing doubts, the flame of justice flickered. It never died.\" #MLKDrea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDream50",
        "indices" : [ 119, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372799188612177920",
    "text" : "President Obama: \"Through setbacks and heartbreaks and gnawing doubts, the flame of justice flickered. It never died.\" #MLKDream50",
    "id" : 372799188612177920,
    "created_at" : "2013-08-28 19:13:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 372799246275469312,
  "created_at" : "2013-08-28 19:14:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372799026267439105",
  "text" : "President Obama: \"Freedom is not given. It must be won, through struggle and discipline, persistence and faith.\" #MLKDream50",
  "id" : 372799026267439105,
  "created_at" : "2013-08-28 19:13:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372798825536454656",
  "text" : "\"A lifetime of indignities had taught them that no man can take away the dignity and grace God grants us.\" \u2014President Obama on #MLKDream50",
  "id" : 372798825536454656,
  "created_at" : "2013-08-28 19:12:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372798725003173888",
  "text" : "President Obama: \"They went to jail to protest unjust laws, their cells swelling with the sound of freedom songs.\" #MLKDream50",
  "id" : 372798725003173888,
  "created_at" : "2013-08-28 19:11:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372798585341222912",
  "text" : "President Obama: \"In the face of hatred, they prayed for their tormentors. In the face of violence, they stood up and sat in.\" #MLKDream50",
  "id" : 372798585341222912,
  "created_at" : "2013-08-28 19:11:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372798200643862528",
  "text" : "President Obama: \"We best remember Dr. King\u2019s soaring oratory that day\u2014how he gave mighty voice to the quiet hopes of millions.\" #MLKDream50",
  "id" : 372798200643862528,
  "created_at" : "2013-08-28 19:09:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372798098575470592",
  "text" : "Obama on the March: \"On a hot summer day, they assembled here, in our nation\u2019s capital...to awaken America\u2019s long-slumbering conscience.\"",
  "id" : 372798098575470592,
  "created_at" : "2013-08-28 19:09:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372797585775661056",
  "text" : "President Obama: \"Five decades ago today, Americans came\u2014to this honored place\u2014to lay claim to a promise made at our founding.\" #MLKDream50",
  "id" : 372797585775661056,
  "created_at" : "2013-08-28 19:07:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "372797165422538752",
  "text" : "Happening now: President Obama speaks on the 50th anniversary of the March on Washington. Watch \u2014&gt; http:\/\/t.co\/b4tqL36eMn #MLKDream50",
  "id" : 372797165422538752,
  "created_at" : "2013-08-28 19:05:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372797064452648961",
  "text" : "RT @vj44: RT and show some love if you are singing in the rain at the Lincoln Memorial\u2014so honored to be at this special place #MLKDream50",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDream50",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372796602982744064",
    "text" : "RT and show some love if you are singing in the rain at the Lincoln Memorial\u2014so honored to be at this special place #MLKDream50",
    "id" : 372796602982744064,
    "created_at" : "2013-08-28 19:03:31 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 372797064452648961,
  "created_at" : "2013-08-28 19:05:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 10, 22 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372790998864121856",
  "text" : "President @BillClinton: \"A great democracy does not make it harder to vote than to buy an assault weapon.\" #MLKDream50",
  "id" : 372790998864121856,
  "created_at" : "2013-08-28 18:41:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Library of Congress",
      "screen_name" : "librarycongress",
      "indices" : [ 3, 19 ],
      "id_str" : "7152572",
      "id" : 7152572
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 26, 39 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOnWashington",
      "indices" : [ 84, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372788719775776768",
  "text" : "RT @librarycongress: Here @repjohnlewis identifies himself in a photo from the 1963 #MarchOnWashington in the new Library exhibition http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Lewis",
        "screen_name" : "repjohnlewis",
        "indices" : [ 5, 18 ],
        "id_str" : "29450962",
        "id" : 29450962
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/librarycongress\/status\/372780843585925121\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/bSKl8AZY3T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSxiM8LCQAAem2k.jpg",
        "id_str" : "372780843615272960",
        "id" : 372780843615272960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSxiM8LCQAAem2k.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bSKl8AZY3T"
      } ],
      "hashtags" : [ {
        "text" : "MarchOnWashington",
        "indices" : [ 63, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372780843585925121",
    "text" : "Here @repjohnlewis identifies himself in a photo from the 1963 #MarchOnWashington in the new Library exhibition http:\/\/t.co\/bSKl8AZY3T",
    "id" : 372780843585925121,
    "created_at" : "2013-08-28 18:00:53 +0000",
    "user" : {
      "name" : "Library of Congress",
      "screen_name" : "librarycongress",
      "protected" : false,
      "id_str" : "7152572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463771973139447808\/Gv1mSKiG_normal.jpeg",
      "id" : 7152572,
      "verified" : true
    }
  },
  "id" : 372788719775776768,
  "created_at" : "2013-08-28 18:32:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "372782746579394560",
  "text" : "At 2:45pm, President Obama speaks at the 50th anniversary of the March on Washington ceremony \u2014&gt; http:\/\/t.co\/KvadYk9atb #MLKDream50",
  "id" : 372782746579394560,
  "created_at" : "2013-08-28 18:08:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372778454812356608",
  "text" : "RT @vj44: On my way to Lincoln Memorial. Crowds are amazing!  Everyone enjoying the rain. #MLKDream50",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDream50",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372777066598379520",
    "text" : "On my way to Lincoln Memorial. Crowds are amazing!  Everyone enjoying the rain. #MLKDream50",
    "id" : 372777066598379520,
    "created_at" : "2013-08-28 17:45:53 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 372778454812356608,
  "created_at" : "2013-08-28 17:51:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/rea1XithMZ",
      "expanded_url" : "http:\/\/on.freep.com\/14B7mh2",
      "display_url" : "on.freep.com\/14B7mh2"
    } ]
  },
  "geo" : { },
  "id_str" : "372775368760909825",
  "text" : "RT @Simas44: Great news for 470k people in Michigan as state moves one step closer to expanding health coverage. http:\/\/t.co\/rea1XithMZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/rea1XithMZ",
        "expanded_url" : "http:\/\/on.freep.com\/14B7mh2",
        "display_url" : "on.freep.com\/14B7mh2"
      } ]
    },
    "geo" : { },
    "id_str" : "372773713487204352",
    "text" : "Great news for 470k people in Michigan as state moves one step closer to expanding health coverage. http:\/\/t.co\/rea1XithMZ",
    "id" : 372773713487204352,
    "created_at" : "2013-08-28 17:32:33 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 372775368760909825,
  "created_at" : "2013-08-28 17:39:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372768034663845888",
  "text" : "RT @FLOTUS: Today, we honor all who held fast to their dream for America. Let\u2019s continue that march and do our part to change history. #MLK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDream50",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372767670577266688",
    "text" : "Today, we honor all who held fast to their dream for America. Let\u2019s continue that march and do our part to change history. #MLKDream50 \u2013mo",
    "id" : 372767670577266688,
    "created_at" : "2013-08-28 17:08:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 372768034663845888,
  "created_at" : "2013-08-28 17:09:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/372755975943360512\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/ErhzIrraT3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSxLlc6CEAAGBJ_.png",
      "id_str" : "372755975951749120",
      "id" : 372755975951749120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSxLlc6CEAAGBJ_.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/ErhzIrraT3"
    } ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372755975943360512",
  "text" : "President Lincoln and Dr. King in the Oval Office. #MLKDream50, http:\/\/t.co\/ErhzIrraT3",
  "id" : 372755975943360512,
  "created_at" : "2013-08-28 16:22:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "372742783699652608",
  "text" : "Tune in for the Let Freedom Ring ceremony commemorating the 50th anniversary of the March on Washington: http:\/\/t.co\/KvadYk9atb #MLKDream50",
  "id" : 372742783699652608,
  "created_at" : "2013-08-28 15:29:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/372730864926339072\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/LDoVTUwQhF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSw0vzECMAA870O.png",
      "id_str" : "372730864930533376",
      "id" : 372730864930533376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSw0vzECMAA870O.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/LDoVTUwQhF"
    } ],
    "hashtags" : [ {
      "text" : "MLKDream50",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372730864926339072",
  "text" : "President Obama's framed copy of the original March on Washington program in the Oval Office. #MLKDream50, http:\/\/t.co\/LDoVTUwQhF",
  "id" : 372730864926339072,
  "created_at" : "2013-08-28 14:42:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 31, 43 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372713965542842368",
  "text" : "Mark your calendars: President @BillClinton will talk about how #Obamacare is helping millions of Americans on 9\/4 in Little Rock.",
  "id" : 372713965542842368,
  "created_at" : "2013-08-28 13:35:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 42, 54 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372709022245212161",
  "text" : "RT @pfeiffer44: Excited to have President @BillClinton, once dubbed Secretary of Explaining Stuff, talk about the health reform law on 9\/4 \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Clinton",
        "screen_name" : "billclinton",
        "indices" : [ 26, 38 ],
        "id_str" : "1330457336",
        "id" : 1330457336
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372707536639512576",
    "text" : "Excited to have President @BillClinton, once dubbed Secretary of Explaining Stuff, talk about the health reform law on 9\/4 in Little Rock",
    "id" : 372707536639512576,
    "created_at" : "2013-08-28 13:09:35 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 372709022245212161,
  "created_at" : "2013-08-28 13:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372472272046399489",
  "text" : "RT @NancyPelosi: 35 days left until the health care marketplaces open. Learn how you can get covered if you don't have insurance:   http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/FaOw9BBGFD",
        "expanded_url" : "http:\/\/www.healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "372471400679759872",
    "text" : "35 days left until the health care marketplaces open. Learn how you can get covered if you don't have insurance:   http:\/\/t.co\/FaOw9BBGFD",
    "id" : 372471400679759872,
    "created_at" : "2013-08-27 21:31:16 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 372472272046399489,
  "created_at" : "2013-08-27 21:34:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372457337144881152",
  "text" : "RT @FLOTUS: \u201CBarack Obama at your age didn\u2019t know he was going to be President of the United States.\u201D \u2014FLOTUS to students on the importance\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372456634779705344",
    "text" : "\u201CBarack Obama at your age didn\u2019t know he was going to be President of the United States.\u201D \u2014FLOTUS to students on the importance of education",
    "id" : 372456634779705344,
    "created_at" : "2013-08-27 20:32:36 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 372457337144881152,
  "created_at" : "2013-08-27 20:35:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    }, {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 16, 24 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 29, 40 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/k5e58EetoU",
      "expanded_url" : "http:\/\/www.ed.gov\/news\/press-releases\/more-28-million-grants-awarded-42-states-cover-fees-charged-low-income-students-",
      "display_url" : "ed.gov\/news\/press-rel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "372446222583201792",
  "text" : "RT @Lehrich44: .@usedgov and @arneduncan helping low-income students take AP tests: http:\/\/t.co\/k5e58EetoU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 1, 9 ],
        "id_str" : "20437286",
        "id" : 20437286
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 14, 25 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/k5e58EetoU",
        "expanded_url" : "http:\/\/www.ed.gov\/news\/press-releases\/more-28-million-grants-awarded-42-states-cover-fees-charged-low-income-students-",
        "display_url" : "ed.gov\/news\/press-rel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372406076752134145",
    "text" : ".@usedgov and @arneduncan helping low-income students take AP tests: http:\/\/t.co\/k5e58EetoU",
    "id" : 372406076752134145,
    "created_at" : "2013-08-27 17:11:42 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 372446222583201792,
  "created_at" : "2013-08-27 19:51:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 21, 24 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The American Legion",
      "screen_name" : "AmericanLegion",
      "indices" : [ 47, 62 ],
      "id_str" : "27048645",
      "id" : 27048645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Veterans",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/R4gj9lPica",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "372437002412490752",
  "text" : "RT @VP: LISTEN LIVE: @VP Biden speaking to the @AmericanLegion in Houston momentarily: http:\/\/t.co\/R4gj9lPica #Veterans",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 13, 16 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "The American Legion",
        "screen_name" : "AmericanLegion",
        "indices" : [ 39, 54 ],
        "id_str" : "27048645",
        "id" : 27048645
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Veterans",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/R4gj9lPica",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "372435345310105601",
    "text" : "LISTEN LIVE: @VP Biden speaking to the @AmericanLegion in Houston momentarily: http:\/\/t.co\/R4gj9lPica #Veterans",
    "id" : 372435345310105601,
    "created_at" : "2013-08-27 19:08:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 372437002412490752,
  "created_at" : "2013-08-27 19:14:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 76, 86 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 111, 129 ]
    }, {
      "text" : "MOW50",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/jCfpMcvJ3S",
      "expanded_url" : "http:\/\/huff.to\/1fgQP31",
      "display_url" : "huff.to\/1fgQP31"
    } ]
  },
  "geo" : { },
  "id_str" : "372425338451537920",
  "text" : "\"We have come too far to give up now. Adelante. Or together, Si Se Puede!\" \u2014@Cecilia44: http:\/\/t.co\/jCfpMcvJ3S #ImmigrationReform #MOW50",
  "id" : 372425338451537920,
  "created_at" : "2013-08-27 18:28:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372414949802246145",
  "text" : "RT @NSCPress: Earlier today, POTUS spoke with @PMHarper about the situation in #Syria: http:\/\/t.co\/SHO9z1wvap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/SHO9z1wvap",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/08\/27\/readout-president-s-call-prime-minister-harper-canada",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372403218526900225",
    "text" : "Earlier today, POTUS spoke with @PMHarper about the situation in #Syria: http:\/\/t.co\/SHO9z1wvap",
    "id" : 372403218526900225,
    "created_at" : "2013-08-27 17:00:20 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 372414949802246145,
  "created_at" : "2013-08-27 17:46:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/372399248672714752\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GRsdgpy5RM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSsHJMQCcAAnGxg.jpg",
      "id_str" : "372399248676909056",
      "id" : 372399248676909056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSsHJMQCcAAnGxg.jpg",
      "sizes" : [ {
        "h" : 1335,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GRsdgpy5RM"
    } ],
    "hashtags" : [ {
      "text" : "MOW50",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/RQmn0rvSUg",
      "expanded_url" : "http:\/\/huff.to\/17aY37E",
      "display_url" : "huff.to\/17aY37E"
    } ]
  },
  "geo" : { },
  "id_str" : "372399248672714752",
  "text" : "\"This struggle must...go on in the cause of our nation\u2019s quest for justice.\" \u2014Holder: http:\/\/t.co\/RQmn0rvSUg #MOW50, http:\/\/t.co\/GRsdgpy5RM",
  "id" : 372399248672714752,
  "created_at" : "2013-08-27 16:44:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 12, 17 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "theGrio.com",
      "screen_name" : "theGrio",
      "indices" : [ 22, 30 ],
      "id_str" : "38228095",
      "id" : 38228095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOW50",
      "indices" : [ 141, 147 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "372390958501224448",
  "text" : "Watch live: @VJ44 and @TheGrio's Joy-Ann Reid discuss building ladders of opportunity &amp; reducing inequality \u2014&gt; http:\/\/t.co\/b4tqL36eMn #MOW50",
  "id" : 372390958501224448,
  "created_at" : "2013-08-27 16:11:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOnWashington",
      "indices" : [ 75, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372383354277998592",
  "text" : "RT @vj44: Come witness history as POTUS honors the 50th anniversary of the #MarchOnWashington\u2014Weds at the Lincoln Memorial http:\/\/t.co\/XQCq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarchOnWashington",
        "indices" : [ 65, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/XQCqWNeanQ",
        "expanded_url" : "http:\/\/ow.ly\/ogZx8",
        "display_url" : "ow.ly\/ogZx8"
      } ]
    },
    "geo" : { },
    "id_str" : "372362806852472833",
    "text" : "Come witness history as POTUS honors the 50th anniversary of the #MarchOnWashington\u2014Weds at the Lincoln Memorial http:\/\/t.co\/XQCqWNeanQ",
    "id" : 372362806852472833,
    "created_at" : "2013-08-27 14:19:45 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 372383354277998592,
  "created_at" : "2013-08-27 15:41:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/372373693189459969\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/98sZ562hH9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSrv5qrCEAAHOYe.jpg",
      "id_str" : "372373693197848576",
      "id" : 372373693197848576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSrv5qrCEAAHOYe.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/98sZ562hH9"
    } ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 89, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/B2CcM9sxm5",
      "expanded_url" : "http:\/\/at.wh.gov\/ojd7w",
      "display_url" : "at.wh.gov\/ojd7w"
    } ]
  },
  "geo" : { },
  "id_str" : "372373693189459969",
  "text" : "Let's keep working to make sure every student can afford college: http:\/\/t.co\/B2CcM9sxm5 #MakeCollegeAffordable, http:\/\/t.co\/98sZ562hH9",
  "id" : 372373693189459969,
  "created_at" : "2013-08-27 15:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372361096448839680",
  "text" : "RT @Lehrich44: \"So does college raise incomes? Is it an investment good enough to make widely accessible? Yes, it is. Period\" http:\/\/t.co\/Y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/YFcXeb8YVk",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/wonkblog\/wp\/2013\/08\/27\/the-tuition-is-too-damn-high-part-ii-why-college-is-still-worth-it\/",
        "display_url" : "washingtonpost.com\/blogs\/wonkblog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "372357127076986880",
    "text" : "\"So does college raise incomes? Is it an investment good enough to make widely accessible? Yes, it is. Period\" http:\/\/t.co\/YFcXeb8YVk",
    "id" : 372357127076986880,
    "created_at" : "2013-08-27 13:57:11 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 372361096448839680,
  "created_at" : "2013-08-27 14:12:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "ShenandoahNPS",
      "screen_name" : "ShenandoahNPS",
      "indices" : [ 104, 118 ],
      "id_str" : "45854335",
      "id" : 45854335
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DC",
      "indices" : [ 100, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372353028768030720",
  "text" : "RT @Interior: It might be hard to believe, but this stunning view is only 75 miles from Washington, #DC @ShenandoahNPS. http:\/\/t.co\/tLqfTCM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShenandoahNPS",
        "screen_name" : "ShenandoahNPS",
        "indices" : [ 90, 104 ],
        "id_str" : "45854335",
        "id" : 45854335
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/372106932368457728\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/tLqfTCMfCw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSn9SH3IMAAbSDA.jpg",
        "id_str" : "372106932024520704",
        "id" : 372106932024520704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSn9SH3IMAAbSDA.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tLqfTCMfCw"
      } ],
      "hashtags" : [ {
        "text" : "DC",
        "indices" : [ 86, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372106932368457728",
    "text" : "It might be hard to believe, but this stunning view is only 75 miles from Washington, #DC @ShenandoahNPS. http:\/\/t.co\/tLqfTCMfCw",
    "id" : 372106932368457728,
    "created_at" : "2013-08-26 21:23:00 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 372353028768030720,
  "created_at" : "2013-08-27 13:40:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/372138979686354944\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/pmYQptyK2a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSoabhuIYAAKOCP.jpg",
      "id_str" : "372138979422134272",
      "id" : 372138979422134272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSoabhuIYAAKOCP.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/pmYQptyK2a"
    } ],
    "hashtags" : [ {
      "text" : "HappyWomensEqualityDay",
      "indices" : [ 83, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/84pUtDTrJJ",
      "expanded_url" : "http:\/\/at.wh.gov\/ohXfd",
      "display_url" : "at.wh.gov\/ohXfd"
    } ]
  },
  "geo" : { },
  "id_str" : "372138979686354944",
  "text" : "93 years ago, American women gained the right to vote \u2014&gt; http:\/\/t.co\/84pUtDTrJJ #HappyWomensEqualityDay, http:\/\/t.co\/pmYQptyK2a",
  "id" : 372138979686354944,
  "created_at" : "2013-08-26 23:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/372126600080265216\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/9EhU2N8yWO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSoPK9GCEAIf7x2.jpg",
      "id_str" : "372126600084459522",
      "id" : 372126600084459522,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSoPK9GCEAIf7x2.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9EhU2N8yWO"
    } ],
    "hashtags" : [ {
      "text" : "MOW50",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372126600080265216",
  "text" : "President Obama met with faith leaders this morning to discuss the anniversary of the March on Washington. #MOW50, http:\/\/t.co\/9EhU2N8yWO",
  "id" : 372126600080265216,
  "created_at" : "2013-08-26 22:41:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372110870676914176",
  "text" : "RT @vj44: Happy womens equality day! 93 yrs ago American women earned the right to vote\u2014RT this amazing inscription from POTUS http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/372096969839091713\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/UjwUBX85L8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSn0OP2CIAEgejR.jpg",
        "id_str" : "372096969843286017",
        "id" : 372096969843286017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSn0OP2CIAEgejR.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/UjwUBX85L8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372096969839091713",
    "text" : "Happy womens equality day! 93 yrs ago American women earned the right to vote\u2014RT this amazing inscription from POTUS http:\/\/t.co\/UjwUBX85L8",
    "id" : 372096969839091713,
    "created_at" : "2013-08-26 20:43:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 372110870676914176,
  "created_at" : "2013-08-26 21:38:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 103, 112 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/1ZK9tAtt0u",
      "expanded_url" : "http:\/\/at.wh.gov\/ohQVX",
      "display_url" : "at.wh.gov\/ohQVX"
    } ]
  },
  "geo" : { },
  "id_str" : "372109228082606080",
  "text" : "\"Without the opportunity to live a healthy life, there is no opportunity to live the American Dream.\" \u2014@Sebelius: http:\/\/t.co\/1ZK9tAtt0u",
  "id" : 372109228082606080,
  "created_at" : "2013-08-26 21:32:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 108, 126 ]
    }, {
      "text" : "ACA",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372099554365034496",
  "text" : "RT @Sebelius: RT &amp; share the good news! In 2014 being a woman will no longer be a preexisting condition #WomensEqualityDay #ACA http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Sebelius\/status\/372083402175807488\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/wePDGllakd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSnn4gYCAAABXri.jpg",
        "id_str" : "372083402184196096",
        "id" : 372083402184196096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSnn4gYCAAABXri.jpg",
        "sizes" : [ {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/wePDGllakd"
      } ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 94, 112 ]
      }, {
        "text" : "ACA",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372083402175807488",
    "text" : "RT &amp; share the good news! In 2014 being a woman will no longer be a preexisting condition #WomensEqualityDay #ACA http:\/\/t.co\/wePDGllakd",
    "id" : 372083402175807488,
    "created_at" : "2013-08-26 19:49:30 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 372099554365034496,
  "created_at" : "2013-08-26 20:53:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenVote",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/meP9ZJ2Hoz",
      "expanded_url" : "http:\/\/at.wh.gov\/ohGZv",
      "display_url" : "at.wh.gov\/ohGZv"
    } ]
  },
  "geo" : { },
  "id_str" : "372087941398405120",
  "text" : "\"On this Women\u2019s Equality Day, we honor those who fought tirelessly for a woman\u2019s right to vote.\" http:\/\/t.co\/meP9ZJ2Hoz #WomenVote",
  "id" : 372087941398405120,
  "created_at" : "2013-08-26 20:07:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372081994525454336",
  "text" : "RT @rhodes44: Sec. Kerry: There must be accountability for those who would use the world\u2019s most heinous weapons against the most vulnerable\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "372076223884562432",
    "text" : "Sec. Kerry: There must be accountability for those who would use the world\u2019s most heinous weapons against the most vulnerable people.",
    "id" : 372076223884562432,
    "created_at" : "2013-08-26 19:20:59 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 372081994525454336,
  "created_at" : "2013-08-26 19:43:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372064453594198017",
  "text" : "\"Ty stands before us today as a loving husband, a devoted father, and an exemplary soldier who even redeployed to Afghanistan.\" \u2014Obama",
  "id" : 372064453594198017,
  "created_at" : "2013-08-26 18:34:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372063596739837953",
  "text" : "\"Ty says 'this award is not mine alone.' The battle that day was 'one team in one fight.'\" \u2014President Obama presenting the Medal of Honor",
  "id" : 372063596739837953,
  "created_at" : "2013-08-26 18:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "372061690189611008",
  "text" : "\"As these soldiers and families will tell you, they're a family, forged in battle and loss and love.\" \u2014Obama presenting the Medal of Honor",
  "id" : 372061690189611008,
  "created_at" : "2013-08-26 18:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "372060843506434049",
  "text" : "Happening now: President Obama presents Staff Sergeant Ty M. Carter with the Medal of Honor \u2014&gt; http:\/\/t.co\/b4tqL36eMn",
  "id" : 372060843506434049,
  "created_at" : "2013-08-26 18:19:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenVote",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ca1Kpss0uv",
      "expanded_url" : "http:\/\/at.wh.gov\/ohnf3",
      "display_url" : "at.wh.gov\/ohnf3"
    } ]
  },
  "geo" : { },
  "id_str" : "372052539916570624",
  "text" : "Today, we \"renew our commitment to securing equal rights, freedoms &amp; opportunities for women everywhere.\" http:\/\/t.co\/ca1Kpss0uv #WomenVote",
  "id" : 372052539916570624,
  "created_at" : "2013-08-26 17:46:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "372042006018535424",
  "text" : "Watch President Obama award Staff Sergeant Ty M. Carter the Medal of Honor at 2:10pm ET \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 372042006018535424,
  "created_at" : "2013-08-26 17:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 119, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/BfREJL9CtB",
      "expanded_url" : "http:\/\/at.wh.gov\/ohbCz",
      "display_url" : "at.wh.gov\/ohbCz"
    } ]
  },
  "geo" : { },
  "id_str" : "372033530374545408",
  "text" : "RT to spread the word: Here's President Obama's plan to help more students afford college \u2014&gt; http:\/\/t.co\/BfREJL9CtB #MakeCollegeAffordable",
  "id" : 372033530374545408,
  "created_at" : "2013-08-26 16:31:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 32, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/NR8vOFB8E8",
      "expanded_url" : "http:\/\/bit.ly\/13DqxIp",
      "display_url" : "bit.ly\/13DqxIp"
    } ]
  },
  "geo" : { },
  "id_str" : "372025232787120128",
  "text" : "RT @Bobby44: How many jobs will #ImmigrationReform create in your area? Find out using AAN\u2019s tool: http:\/\/t.co\/NR8vOFB8E8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 19, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/NR8vOFB8E8",
        "expanded_url" : "http:\/\/bit.ly\/13DqxIp",
        "display_url" : "bit.ly\/13DqxIp"
      } ]
    },
    "geo" : { },
    "id_str" : "372017220655656960",
    "text" : "How many jobs will #ImmigrationReform create in your area? Find out using AAN\u2019s tool: http:\/\/t.co\/NR8vOFB8E8",
    "id" : 372017220655656960,
    "created_at" : "2013-08-26 15:26:31 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 372025232787120128,
  "created_at" : "2013-08-26 15:58:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 27, 39 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOnWashington",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/bNs1Ei5ygR",
      "expanded_url" : "http:\/\/at.wh.gov\/oh0bQ",
      "display_url" : "at.wh.gov\/oh0bQ"
    } ]
  },
  "geo" : { },
  "id_str" : "372018237032001536",
  "text" : "President Obama, President @BillClinton, &amp; President Carter to honor the 50th anniversary of the #MarchOnWashington: http:\/\/t.co\/bNs1Ei5ygR",
  "id" : 372018237032001536,
  "created_at" : "2013-08-26 15:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 119, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/j5DPozEppG",
      "expanded_url" : "http:\/\/at.wh.gov\/ogTcw",
      "display_url" : "at.wh.gov\/ogTcw"
    } ]
  },
  "geo" : { },
  "id_str" : "372007146067460096",
  "text" : "Here's what Americans are saying about why college affordability should be a top priority \u2014&gt; http:\/\/t.co\/j5DPozEppG #MakeCollegeAffordable",
  "id" : 372007146067460096,
  "created_at" : "2013-08-26 14:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/371668967053488129\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/KjshwdSExJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BShu9NOCcAAjiQt.png",
      "id_str" : "371668967057682432",
      "id" : 371668967057682432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BShu9NOCcAAjiQt.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KjshwdSExJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371668967053488129",
  "text" : "The First Dogs. http:\/\/t.co\/KjshwdSExJ",
  "id" : 371668967053488129,
  "created_at" : "2013-08-25 16:22:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Serena Williams",
      "screen_name" : "serenawilliams",
      "indices" : [ 70, 85 ],
      "id_str" : "26589987",
      "id" : 26589987
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USOpen",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "LetsMove",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371362829355343872",
  "text" : "RT @FLOTUS: A behind-the-scenes look just before the First Lady &amp; @SerenaWilliams kick off Kids' Day at the #USOpen. #LetsMove: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Serena Williams",
        "screen_name" : "serenawilliams",
        "indices" : [ 58, 73 ],
        "id_str" : "26589987",
        "id" : 26589987
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/371345735553282048\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/7vu5r3nrje",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSdI-qECcAAf5qp.png",
        "id_str" : "371345735561670656",
        "id" : 371345735561670656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSdI-qECcAAf5qp.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7vu5r3nrje"
      } ],
      "hashtags" : [ {
        "text" : "USOpen",
        "indices" : [ 100, 107 ]
      }, {
        "text" : "LetsMove",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "371345735553282048",
    "text" : "A behind-the-scenes look just before the First Lady &amp; @SerenaWilliams kick off Kids' Day at the #USOpen. #LetsMove: http:\/\/t.co\/7vu5r3nrje",
    "id" : 371345735553282048,
    "created_at" : "2013-08-24 18:58:17 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 371362829355343872,
  "created_at" : "2013-08-24 20:06:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 118, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/JVsoaQdyP5",
      "expanded_url" : "http:\/\/at.wh.gov\/odJVL",
      "display_url" : "at.wh.gov\/odJVL"
    } ]
  },
  "geo" : { },
  "id_str" : "371346300102393856",
  "text" : "\"Higher education has never been more important. It\u2019s also never been more expensive.\" \u2014Obama: http:\/\/t.co\/JVsoaQdyP5 #MakeCollegeAffordable",
  "id" : 371346300102393856,
  "created_at" : "2013-08-24 19:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOnWashington",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/uJYjGUxIWQ",
      "expanded_url" : "http:\/\/at.wh.gov\/oeuvx",
      "display_url" : "at.wh.gov\/oeuvx"
    } ]
  },
  "geo" : { },
  "id_str" : "371313797190799360",
  "text" : "\"As we gather today, 50 years later, their march\u2014now our march\u2014goes on.\" \u2014Sec. Eric Holder: http:\/\/t.co\/uJYjGUxIWQ #MarchOnWashington",
  "id" : 371313797190799360,
  "created_at" : "2013-08-24 16:51:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 116, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/JVsoaQdyP5",
      "expanded_url" : "http:\/\/at.wh.gov\/odJVL",
      "display_url" : "at.wh.gov\/odJVL"
    } ]
  },
  "geo" : { },
  "id_str" : "371278347466072064",
  "text" : "\"We cannot price the middle class out of a college education.\" \u2014Obama in his Weekly Address: http:\/\/t.co\/JVsoaQdyP5 #MakeCollegeAffordable",
  "id" : 371278347466072064,
  "created_at" : "2013-08-24 14:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 79, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/1Od8TOttxp",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/08\/23\/regional-roundup-college-affordability-bus-tour",
      "display_url" : "whitehouse.gov\/blog\/2013\/08\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371045506803183616",
  "text" : "RT @jesseclee44: Good reception, lots of regional coverage for Obama's call to #MakeCollegeAffordable: http:\/\/t.co\/1Od8TOttxp Huge issue fo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 62, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/1Od8TOttxp",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/08\/23\/regional-roundup-college-affordability-bus-tour",
        "display_url" : "whitehouse.gov\/blog\/2013\/08\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "371044102147940352",
    "text" : "Good reception, lots of regional coverage for Obama's call to #MakeCollegeAffordable: http:\/\/t.co\/1Od8TOttxp Huge issue for folks.",
    "id" : 371044102147940352,
    "created_at" : "2013-08-23 22:59:42 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 371045506803183616,
  "created_at" : "2013-08-23 23:05:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 27, 35 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/podnR4FoXo",
      "expanded_url" : "http:\/\/nyti.ms\/154lKK6",
      "display_url" : "nyti.ms\/154lKK6"
    } ]
  },
  "geo" : { },
  "id_str" : "371039530200997888",
  "text" : "RT @arneduncan: Thoughtful @nytimes editorial on the President's plan to make college more affordable for families. http:\/\/t.co\/podnR4FoXo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 11, 19 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/podnR4FoXo",
        "expanded_url" : "http:\/\/nyti.ms\/154lKK6",
        "display_url" : "nyti.ms\/154lKK6"
      } ]
    },
    "geo" : { },
    "id_str" : "371036871616253953",
    "text" : "Thoughtful @nytimes editorial on the President's plan to make college more affordable for families. http:\/\/t.co\/podnR4FoXo",
    "id" : 371036871616253953,
    "created_at" : "2013-08-23 22:30:58 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 371039530200997888,
  "created_at" : "2013-08-23 22:41:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Zoo",
      "screen_name" : "NationalZoo",
      "indices" : [ 3, 15 ],
      "id_str" : "17045060",
      "id" : 17045060
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cubwatch",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/R88TEAQKzv",
      "expanded_url" : "http:\/\/nationalzoo.si.edu\/Animals\/GiantPandas\/",
      "display_url" : "nationalzoo.si.edu\/Animals\/GiantP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "371029012434268160",
  "text" : "RT @NationalZoo: WE HAVE A CUB!! Born at 5:32 p.m. this evening. More details to follow. http:\/\/t.co\/R88TEAQKzv #cubwatch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cubwatch",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/R88TEAQKzv",
        "expanded_url" : "http:\/\/nationalzoo.si.edu\/Animals\/GiantPandas\/",
        "display_url" : "nationalzoo.si.edu\/Animals\/GiantP\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "371022765131702272",
    "text" : "WE HAVE A CUB!! Born at 5:32 p.m. this evening. More details to follow. http:\/\/t.co\/R88TEAQKzv #cubwatch",
    "id" : 371022765131702272,
    "created_at" : "2013-08-23 21:34:55 +0000",
    "user" : {
      "name" : "National Zoo",
      "screen_name" : "NationalZoo",
      "protected" : false,
      "id_str" : "17045060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671384071294070784\/HCjIdoN9_normal.jpg",
      "id" : 17045060,
      "verified" : true
    }
  },
  "id" : 371029012434268160,
  "created_at" : "2013-08-23 21:59:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371020397371990016",
  "text" : "President Obama in Scranton: \u201CJust because something\u2019s hard doesn\u2019t mean we can\u2019t do it\u2026we can make college more affordable.\u201D",
  "id" : 371020397371990016,
  "created_at" : "2013-08-23 21:25:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 116, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371019566845296641",
  "text" : "Obama: \"I capped loan repayments at 10% of a student\u2019s income...so far it's helped more than 2.5 million students.\" #MakeCollegeAffordable",
  "id" : 371019566845296641,
  "created_at" : "2013-08-23 21:22:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 118, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371018116744364032",
  "text" : "Obama: \"We can't price the middle class and everyone working to get into the middle class out of a higher education.\" #MakeCollegeAffordable",
  "id" : 371018116744364032,
  "created_at" : "2013-08-23 21:16:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371016631079940096",
  "text" : "President Obama: \"Michelle and I\u2014we're only who we are today because scholarships and student loans gave us a shot at a great education.\"",
  "id" : 371016631079940096,
  "created_at" : "2013-08-23 21:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 112, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371015359039807488",
  "text" : "President Obama: \"More than ever before, some form of higher education is the surest path to the middle class.\" #MakeCollegeAffordable",
  "id" : 371015359039807488,
  "created_at" : "2013-08-23 21:05:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 130, 145 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371014942914510848",
  "text" : "President Obama: \"We can\u2019t afford the usual Washington circus of distractions &amp; political posturing &amp; special interests.\" #ABetterBargain",
  "id" : 371014942914510848,
  "created_at" : "2013-08-23 21:03:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 118, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371013287238176768",
  "text" : "President Obama: \"Getting a higher education is one of the best things you can do for yourself and for your country.\" #MakeCollegeAffordable",
  "id" : 371013287238176768,
  "created_at" : "2013-08-23 20:57:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371012147759038464",
  "text" : "President Obama: \"Five years ago today, on August 23, 2008, I announced\u2026that Joe Biden was going to be my running mate.\"",
  "id" : 371012147759038464,
  "created_at" : "2013-08-23 20:52:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 35, 38 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 120, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ArrTWsjtge",
      "expanded_url" : "http:\/\/at.wh.gov\/odAgB",
      "display_url" : "at.wh.gov\/odAgB"
    } ]
  },
  "geo" : { },
  "id_str" : "371009129978286081",
  "text" : "Happening now: President Obama and @VP Biden speak in Scranton about college affordability \u2014&gt; http:\/\/t.co\/ArrTWsjtge #MakeCollegeAffordable",
  "id" : 371009129978286081,
  "created_at" : "2013-08-23 20:40:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 67, 83 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370999474744619008",
  "text" : "RT @Interior: All National Parks are free this Sunday to celebrate @NatlParkService 97th birthday. RT to spread the word! http:\/\/t.co\/1iE9W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 53, 69 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/1iE9W5DmyV",
        "expanded_url" : "http:\/\/on.doi.gov\/179wk5x",
        "display_url" : "on.doi.gov\/179wk5x"
      } ]
    },
    "geo" : { },
    "id_str" : "370993019006500864",
    "text" : "All National Parks are free this Sunday to celebrate @NatlParkService 97th birthday. RT to spread the word! http:\/\/t.co\/1iE9W5DmyV",
    "id" : 370993019006500864,
    "created_at" : "2013-08-23 19:36:43 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 370999474744619008,
  "created_at" : "2013-08-23 20:02:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/yQNL5m4wUo",
      "expanded_url" : "http:\/\/at.wh.gov\/odsca",
      "display_url" : "at.wh.gov\/odsca"
    } ]
  },
  "geo" : { },
  "id_str" : "370993355959701504",
  "text" : "Go behind-the-scenes with the Obamas' new puppy, Sunny (plus a recap of President Obama's week) \u2014&gt; http:\/\/t.co\/yQNL5m4wUo #WestWingWeek",
  "id" : 370993355959701504,
  "created_at" : "2013-08-23 19:38:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/370983917127356417\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/mlsJduLENW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSX_6DZCUAACAHB.jpg",
      "id_str" : "370983917135745024",
      "id" : 370983917135745024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSX_6DZCUAACAHB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/mlsJduLENW"
    } ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 52, 74 ]
    }, {
      "text" : "SoccerSeasonIsComing",
      "indices" : [ 86, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370983917127356417",
  "text" : "President Obama visits Tully High School before his #MakeCollegeAffordable town hall. #SoccerSeasonIsComing, http:\/\/t.co\/mlsJduLENW",
  "id" : 370983917127356417,
  "created_at" : "2013-08-23 19:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/apuVnhu6I8",
      "expanded_url" : "http:\/\/StudentAid.gov",
      "display_url" : "StudentAid.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "370968336357928961",
  "text" : "Obama to high school students figuring out how to pay for college: \u201CWe have a website http:\/\/t.co\/apuVnhu6I8 that can be very helpful.\u201D",
  "id" : 370968336357928961,
  "created_at" : "2013-08-23 17:58:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreKForAll",
      "indices" : [ 111, 122 ]
    }, {
      "text" : "ABetterBargain",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/tRoHx6jknC",
      "expanded_url" : "http:\/\/wh.gov\/a-better-bargain",
      "display_url" : "wh.gov\/a-better-barga\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370962966679928833",
  "text" : "President Obama: \"Early childhood education works. We know that can make a difference.\" http:\/\/t.co\/tRoHx6jknC #PreKForAll #ABetterBargain",
  "id" : 370962966679928833,
  "created_at" : "2013-08-23 17:37:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BinghamtonUniversity",
      "screen_name" : "binghamtonu",
      "indices" : [ 51, 63 ],
      "id_str" : "23790666",
      "id" : 23790666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/370961031746433024\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WGxUFGeVSE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSXrF8sCMAAshZ4.png",
      "id_str" : "370961031750627328",
      "id" : 370961031750627328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSXrF8sCMAAshZ4.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      } ],
      "display_url" : "pic.twitter.com\/WGxUFGeVSE"
    } ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 93, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "370961031746433024",
  "text" : "Obama discusses ways we can lower college costs at @BinghamtonU \u2014&gt; http:\/\/t.co\/KvadYk9atb #MakeCollegeAffordable, http:\/\/t.co\/WGxUFGeVSE",
  "id" : 370961031746433024,
  "created_at" : "2013-08-23 17:29:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 116, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370959278515171328",
  "text" : "\u201CThere are ways we can save money that would not diminish quality.\u201D \u2014Obama on schools finding ways to lower tuition #MakeCollegeAffordable",
  "id" : 370959278515171328,
  "created_at" : "2013-08-23 17:22:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370958219998289920",
  "text" : "RT @HealthCareTara: POTUS: \"I love nurses\" raises importance of nurses at town hall \u2013  my Mom and all the nation\u2019s great nurses deserve a s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370957449580134400",
    "text" : "POTUS: \"I love nurses\" raises importance of nurses at town hall \u2013  my Mom and all the nation\u2019s great nurses deserve a shoutout.",
    "id" : 370957449580134400,
    "created_at" : "2013-08-23 17:15:22 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 370958219998289920,
  "created_at" : "2013-08-23 17:18:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreKForAll",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/R1mujpHddq",
      "expanded_url" : "http:\/\/at.wh.gov\/od98L",
      "display_url" : "at.wh.gov\/od98L"
    } ]
  },
  "geo" : { },
  "id_str" : "370956982012108800",
  "text" : "Obama: \u201CI want to expand early childhood education so it\u2019s accessible to every child in America.\u201D http:\/\/t.co\/R1mujpHddq #PreKForAll",
  "id" : 370956982012108800,
  "created_at" : "2013-08-23 17:13:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 118, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370956498861838336",
  "text" : "Obama: \"We're going to make sure that all young people get the support they need...so they're able to go to college.\" #MakeCollegeAffordable",
  "id" : 370956498861838336,
  "created_at" : "2013-08-23 17:11:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370954094745513984",
  "text" : "President Obama: \"Higher education shouldn't be a luxury. It's an economic necessity...we want to make sure every family can afford it.\"",
  "id" : 370954094745513984,
  "created_at" : "2013-08-23 17:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370953608235589632",
  "text" : "President Obama: \"We\u2019re going to work with states &amp; schools\u2026to see what\u2019s working &amp; what\u2019s not &amp; spread best practices across the country.\"",
  "id" : 370953608235589632,
  "created_at" : "2013-08-23 17:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 118, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370951340945838080",
  "text" : "Obama: \"I\u2019m excited about the great work SUNY campuses like Binghamton are doing to...keep down the cost of college.\" #MakeCollegeAffordable",
  "id" : 370951340945838080,
  "created_at" : "2013-08-23 16:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BinghamtonUniversity",
      "screen_name" : "binghamtonu",
      "indices" : [ 43, 55 ],
      "id_str" : "23790666",
      "id" : 23790666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 120, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "370950826090835968",
  "text" : "Happening now: President Obama speaks at a @BinghamtonU town hall on college affordability \u2014&gt; http:\/\/t.co\/b4tqL36eMn #MakeCollegeAffordable",
  "id" : 370950826090835968,
  "created_at" : "2013-08-23 16:49:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BinghamtonUniversity",
      "screen_name" : "binghamtonu",
      "indices" : [ 37, 49 ],
      "id_str" : "23790666",
      "id" : 23790666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 118, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "370948173516140544",
  "text" : "Watch President Obama's town hall at @BinghamtonU on college affordability at 12:45pm ET \u2014&gt; http:\/\/t.co\/KvadYk9atb #MakeCollegeAffordable",
  "id" : 370948173516140544,
  "created_at" : "2013-08-23 16:38:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 22, 33 ]
    }, {
      "text" : "ImmigrationReform",
      "indices" : [ 105, 123 ]
    }, {
      "text" : "STEM",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/qWjcwkjJEW",
      "expanded_url" : "http:\/\/wh.gov\/we-the-geeks",
      "display_url" : "wh.gov\/we-the-geeks"
    } ]
  },
  "geo" : { },
  "id_str" : "370940231161090048",
  "text" : "Starting now: Watch a #WeTheGeeks Hangout on making America a \"geek magnet\" \u2014&gt; http:\/\/t.co\/qWjcwkjJEW #ImmigrationReform #STEM",
  "id" : 370940231161090048,
  "created_at" : "2013-08-23 16:06:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/UfSUnVeWOT",
      "expanded_url" : "http:\/\/WH.gov\/WeTheGeeks",
      "display_url" : "WH.gov\/WeTheGeeks"
    } ]
  },
  "geo" : { },
  "id_str" : "370930550963331072",
  "text" : "RT @whitehouseostp: TODAY AT NOON: Don't miss a live #WeTheGeeks Hangout on \"Making the US a Geek Magnet\"! Watch at http:\/\/t.co\/UfSUnVeWOT \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 33, 44 ]
      }, {
        "text" : "Immigration",
        "indices" : [ 119, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/UfSUnVeWOT",
        "expanded_url" : "http:\/\/WH.gov\/WeTheGeeks",
        "display_url" : "WH.gov\/WeTheGeeks"
      } ]
    },
    "geo" : { },
    "id_str" : "370884994517848065",
    "text" : "TODAY AT NOON: Don't miss a live #WeTheGeeks Hangout on \"Making the US a Geek Magnet\"! Watch at http:\/\/t.co\/UfSUnVeWOT #Immigration",
    "id" : 370884994517848065,
    "created_at" : "2013-08-23 12:27:28 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 370930550963331072,
  "created_at" : "2013-08-23 15:28:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/370923205252239360\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/mVv3RDAcpB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSXIsKFCMAAwDEo.jpg",
      "id_str" : "370923205273202688",
      "id" : 370923205273202688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSXIsKFCMAAwDEo.jpg",
      "sizes" : [ {
        "h" : 840,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/mVv3RDAcpB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/MG8Q1LOVk4",
      "expanded_url" : "http:\/\/at.wh.gov\/ocKgF",
      "display_url" : "at.wh.gov\/ocKgF"
    } ]
  },
  "geo" : { },
  "id_str" : "370923205252239360",
  "text" : "\"Education must be affordable.\" \u2014Obama on his plan to help more students afford college: http:\/\/t.co\/MG8Q1LOVk4, http:\/\/t.co\/mVv3RDAcpB",
  "id" : 370923205252239360,
  "created_at" : "2013-08-23 14:59:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Buffalo News",
      "screen_name" : "TheBuffaloNews",
      "indices" : [ 1, 16 ],
      "id_str" : "43805270",
      "id" : 43805270
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/370920856546852864\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/lzuqLhRX2O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSXGjcbCQAAk96o.jpg",
      "id_str" : "370920856555241472",
      "id" : 370920856555241472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSXGjcbCQAAk96o.jpg",
      "sizes" : [ {
        "h" : 834,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 834,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lzuqLhRX2O"
    } ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 46, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/iAx6Z4wbAZ",
      "expanded_url" : "http:\/\/at.wh.gov\/ocGoD",
      "display_url" : "at.wh.gov\/ocGoD"
    } ]
  },
  "geo" : { },
  "id_str" : "370920856546852864",
  "text" : ".@TheBuffaloNews on President Obama's plan to #MakeCollegeAffordable \u2014&gt; http:\/\/t.co\/iAx6Z4wbAZ, http:\/\/t.co\/lzuqLhRX2O",
  "id" : 370920856546852864,
  "created_at" : "2013-08-23 14:49:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 32, 43 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DuncanKhan",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/qRJmN5qPGf",
      "expanded_url" : "http:\/\/at.wh.gov\/ocCCD",
      "display_url" : "at.wh.gov\/ocCCD"
    } ]
  },
  "geo" : { },
  "id_str" : "370911609205432320",
  "text" : "Watch live: Sal Khan interviews @ArneDuncan about the President's plan to help more kids afford college: http:\/\/t.co\/qRJmN5qPGf #DuncanKhan",
  "id" : 370911609205432320,
  "created_at" : "2013-08-23 14:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 117, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/RLzsadxH8R",
      "expanded_url" : "http:\/\/at.wh.gov\/obweu",
      "display_url" : "at.wh.gov\/obweu"
    } ]
  },
  "geo" : { },
  "id_str" : "370899840017780737",
  "text" : "RT @arneduncan: RT to share President Obama's plan to help more students afford college \u2014&gt; http:\/\/t.co\/RLzsadxH8R #MakeCollegeAffordable",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 101, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/RLzsadxH8R",
        "expanded_url" : "http:\/\/at.wh.gov\/obweu",
        "display_url" : "at.wh.gov\/obweu"
      } ]
    },
    "geo" : { },
    "id_str" : "370893408077770752",
    "text" : "RT to share President Obama's plan to help more students afford college \u2014&gt; http:\/\/t.co\/RLzsadxH8R #MakeCollegeAffordable",
    "id" : 370893408077770752,
    "created_at" : "2013-08-23 13:00:54 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 370899840017780737,
  "created_at" : "2013-08-23 13:26:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/370705097723887616\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/oHdoYQbpTN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSUCUoLCQAAk2jJ.jpg",
      "id_str" : "370705097732276224",
      "id" : 370705097732276224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSUCUoLCQAAk2jJ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/oHdoYQbpTN"
    } ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 83, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370705097723887616",
  "text" : "RT if you agree: Every kid in America should be able to afford a higher education. #MakeCollegeAffordable, http:\/\/t.co\/oHdoYQbpTN",
  "id" : 370705097723887616,
  "created_at" : "2013-08-23 00:32:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 82, 104 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370698697471848448",
  "text" : "RT @FLOTUS: Let's make sure every kid in America has a shot at a great education. #MakeCollegeAffordable #ThrowbackThursday, http:\/\/t.co\/Ln\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/370697962071945216\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/LnSdZnpqcn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BST71RzCcAAZ-u7.jpg",
        "id_str" : "370697962080333824",
        "id" : 370697962080333824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BST71RzCcAAZ-u7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 561
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 561
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 561
        } ],
        "display_url" : "pic.twitter.com\/LnSdZnpqcn"
      } ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 70, 92 ]
      }, {
        "text" : "ThrowbackThursday",
        "indices" : [ 93, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370697962071945216",
    "text" : "Let's make sure every kid in America has a shot at a great education. #MakeCollegeAffordable #ThrowbackThursday, http:\/\/t.co\/LnSdZnpqcn",
    "id" : 370697962071945216,
    "created_at" : "2013-08-23 00:04:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 370698697471848448,
  "created_at" : "2013-08-23 00:07:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 80, 88 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 41, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/MG8EWbCmTT",
      "expanded_url" : "http:\/\/wh.gov\/lgHWb",
      "display_url" : "wh.gov\/lgHWb"
    } ]
  },
  "geo" : { },
  "id_str" : "370691674508242944",
  "text" : "RT @ks44: Here's why President Obama and #MakeCollegeAffordable are trending on @twitter right now --&gt; http:\/\/t.co\/MG8EWbCmTT http:\/\/t.co\/h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 70, 78 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/370685613101432832\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/hhqdYRdlyG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSTwmeTCQAAUt00.jpg",
        "id_str" : "370685613109821440",
        "id" : 370685613109821440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSTwmeTCQAAUt00.jpg",
        "sizes" : [ {
          "h" : 259,
          "resize" : "fit",
          "w" : 311
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 311
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 311
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 311
        } ],
        "display_url" : "pic.twitter.com\/hhqdYRdlyG"
      } ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 31, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/MG8EWbCmTT",
        "expanded_url" : "http:\/\/wh.gov\/lgHWb",
        "display_url" : "wh.gov\/lgHWb"
      } ]
    },
    "geo" : { },
    "id_str" : "370685613101432832",
    "text" : "Here's why President Obama and #MakeCollegeAffordable are trending on @twitter right now --&gt; http:\/\/t.co\/MG8EWbCmTT http:\/\/t.co\/hhqdYRdlyG",
    "id" : 370685613101432832,
    "created_at" : "2013-08-22 23:15:11 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 370691674508242944,
  "created_at" : "2013-08-22 23:39:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370679080800108544",
  "text" : "President Obama: \"We want every student to be able to pay back their loans in a way that doesn\u2019t stop them from pursuing their dreams.\"",
  "id" : 370679080800108544,
  "created_at" : "2013-08-22 22:49:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370678474849009665",
  "text" : "Obama: \"We\u2019ve got to stop subsidizing schools that aren\u2019t getting good results &amp; start rewarding schools that deliver for their students.\"",
  "id" : 370678474849009665,
  "created_at" : "2013-08-22 22:46:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370677838539550720",
  "text" : "Obama: \"We need to work with colleges to keep costs down. States will need to make higher education a higher priority in their budgets.\"",
  "id" : 370677838539550720,
  "created_at" : "2013-08-22 22:44:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 121, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370677528223961088",
  "text" : "Obama: \"We can't price the middle class &amp; everyone working to get into the middle class out of a college education.\" #MakeCollegeAffordable",
  "id" : 370677528223961088,
  "created_at" : "2013-08-22 22:43:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370676958360641536",
  "text" : "Obama: \"We took action to cap loan repayments at 10% of monthly income for...borrowers trying to responsibly manage...student loan debt.\"",
  "id" : 370676958360641536,
  "created_at" : "2013-08-22 22:40:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 116, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370676175896473600",
  "text" : "Obama on rising college costs: \"The average student who borrows for college now graduates owing more than $26,000.\" #MakeCollegeAffordable",
  "id" : 370676175896473600,
  "created_at" : "2013-08-22 22:37:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 110, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370675807472988160",
  "text" : "Obama: \"Over the past 3 decades, the average tuition at a public 4-year college has risen by more than 250%.\" #MakeCollegeAffordable",
  "id" : 370675807472988160,
  "created_at" : "2013-08-22 22:36:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 101, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370675529063493633",
  "text" : "President Obama: \"In the face of global competition, a great education is more important than ever.\" #MakeCollegeAffordable",
  "id" : 370675529063493633,
  "created_at" : "2013-08-22 22:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370675084400144384",
  "text" : "President Obama: \u201CThis has to be Washington\u2019s highest priority\u2014making sure everyone gets a fair shake.\u201D #ABetterBargain",
  "id" : 370675084400144384,
  "created_at" : "2013-08-22 22:33:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 117, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "370672537958883328",
  "text" : "Watch live: President Obama speaks in Syracuse, NY about his college affordability plan \u2014&gt; http:\/\/t.co\/b4tqL36eMn #MakeCollegeAffordable",
  "id" : 370672537958883328,
  "created_at" : "2013-08-22 22:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/370645693951537152\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/DnvZRvfkEI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSTMS34CcAA3Rrl.png",
      "id_str" : "370645693959925760",
      "id" : 370645693959925760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSTMS34CcAA3Rrl.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      } ],
      "display_url" : "pic.twitter.com\/DnvZRvfkEI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370645693951537152",
  "text" : "I wave you back! http:\/\/t.co\/DnvZRvfkEI",
  "id" : 370645693951537152,
  "created_at" : "2013-08-22 20:36:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/370636292410724352\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/FVqmKS5oVQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSTDvoZCUAAIQf8.jpg",
      "id_str" : "370636292414918656",
      "id" : 370636292414918656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSTDvoZCUAAIQf8.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/FVqmKS5oVQ"
    } ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 31, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370636292410724352",
  "text" : "President Obama is fighting to #MakeCollegeAffordable for people like Dan and his sons: http:\/\/t.co\/FVqmKS5oVQ",
  "id" : 370636292410724352,
  "created_at" : "2013-08-22 19:59:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Lauren - Tweet Limit",
      "screen_name" : "MovesLikeBiden",
      "indices" : [ 9, 24 ],
      "id_str" : "2273810948",
      "id" : 2273810948
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 29, 32 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 86, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370627411429171200",
  "text" : "RT @VP: .@MovesLikeBiden For @VP\u2019s #1 fan? How about 2 tix to see POTUS &amp; VP talk #MakeCollegeAffordable tmw? A big issue for young people \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lauren - Tweet Limit",
        "screen_name" : "MovesLikeBiden",
        "indices" : [ 1, 16 ],
        "id_str" : "2273810948",
        "id" : 2273810948
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 21, 24 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 78, 100 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "370525864821522432",
    "geo" : { },
    "id_str" : "370580318907944961",
    "in_reply_to_user_id" : 117974827,
    "text" : ".@MovesLikeBiden For @VP\u2019s #1 fan? How about 2 tix to see POTUS &amp; VP talk #MakeCollegeAffordable tmw? A big issue for young people like you.",
    "id" : 370580318907944961,
    "in_reply_to_status_id" : 370525864821522432,
    "created_at" : "2013-08-22 16:16:47 +0000",
    "in_reply_to_screen_name" : "LaurenWaksman",
    "in_reply_to_user_id_str" : "117974827",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 370627411429171200,
  "created_at" : "2013-08-22 19:23:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal",
      "screen_name" : "Crystal_CCC",
      "indices" : [ 3, 15 ],
      "id_str" : "25278344",
      "id" : 25278344
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 29, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370623960045477888",
  "text" : "RT @Crystal_CCC: @whitehouse #MakeCollegeAffordable because, as a public school teacher, my two required degrees cost more than 3 years sal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 12, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370621690407288832",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #MakeCollegeAffordable because, as a public school teacher, my two required degrees cost more than 3 years salary.",
    "id" : 370621690407288832,
    "created_at" : "2013-08-22 19:01:11 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Crystal",
      "screen_name" : "Crystal_CCC",
      "protected" : false,
      "id_str" : "25278344",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789929770855362560\/pbT1ZWHO_normal.jpg",
      "id" : 25278344,
      "verified" : false
    }
  },
  "id" : 370623960045477888,
  "created_at" : "2013-08-22 19:10:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 31, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370620336150024192",
  "text" : "RT @MaloriePastor: @whitehouse #MakeCollegeAffordable because I will still be paying my school debt when my 2 year old hits college",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 12, 34 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "370589343598907392",
    "geo" : { },
    "id_str" : "370590054348898305",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #MakeCollegeAffordable because I will still be paying my school debt when my 2 year old hits college",
    "id" : 370590054348898305,
    "in_reply_to_status_id" : 370589343598907392,
    "created_at" : "2013-08-22 16:55:28 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Malorie Pastor",
      "screen_name" : "notwthoutmyprls",
      "protected" : false,
      "id_str" : "462513532",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/485619426595991552\/_0XTyNrZ_normal.jpeg",
      "id" : 462513532,
      "verified" : false
    }
  },
  "id" : 370620336150024192,
  "created_at" : "2013-08-22 18:55:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert K Hoggard",
      "screen_name" : "mindofRKH",
      "indices" : [ 3, 13 ],
      "id_str" : "270676499",
      "id" : 270676499
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370615869144973313",
  "text" : "RT @mindofRKH: @whitehouse I know personally over 50 students who have outstanding balances with their colleges b\/c of lack of aid. #MakeCo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 117, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "370589343598907392",
    "geo" : { },
    "id_str" : "370595698284060673",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse I know personally over 50 students who have outstanding balances with their colleges b\/c of lack of aid. #MakeCollegeAffordable",
    "id" : 370595698284060673,
    "in_reply_to_status_id" : 370589343598907392,
    "created_at" : "2013-08-22 17:17:54 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Robert K Hoggard",
      "screen_name" : "mindofRKH",
      "protected" : false,
      "id_str" : "270676499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784610841584922624\/2lJIbWRW_normal.jpg",
      "id" : 270676499,
      "verified" : false
    }
  },
  "id" : 370615869144973313,
  "created_at" : "2013-08-22 18:38:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Zieno",
      "screen_name" : "jzieno",
      "indices" : [ 3, 10 ],
      "id_str" : "115807443",
      "id" : 115807443
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370611716066770944",
  "text" : "RT @jzieno: @whitehouse I need an affordable education because I don't qualify for much financial aid and can't pay outright #MakeCollegeAf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 113, 135 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "370589343598907392",
    "geo" : { },
    "id_str" : "370589957254950912",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse I need an affordable education because I don't qualify for much financial aid and can't pay outright #MakeCollegeAffordable",
    "id" : 370589957254950912,
    "in_reply_to_status_id" : 370589343598907392,
    "created_at" : "2013-08-22 16:55:05 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Jamie Zieno",
      "screen_name" : "jzieno",
      "protected" : false,
      "id_str" : "115807443",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744715921495822336\/SbOIQ4IT_normal.jpg",
      "id" : 115807443,
      "verified" : false
    }
  },
  "id" : 370611716066770944,
  "created_at" : "2013-08-22 18:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Staley",
      "screen_name" : "gettingthere123",
      "indices" : [ 3, 19 ],
      "id_str" : "274704311",
      "id" : 274704311
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 80, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370608271322656769",
  "text" : "RT @gettingthere123: We need to keep the doors of higher education open to all! #MakeCollegeAffordable",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 59, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370604013353697280",
    "text" : "We need to keep the doors of higher education open to all! #MakeCollegeAffordable",
    "id" : 370604013353697280,
    "created_at" : "2013-08-22 17:50:56 +0000",
    "user" : {
      "name" : "Susan Staley",
      "screen_name" : "gettingthere123",
      "protected" : false,
      "id_str" : "274704311",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3243862894\/df8cc0f3398d81336c1b24f5ae309c74_normal.png",
      "id" : 274704311,
      "verified" : false
    }
  },
  "id" : 370608271322656769,
  "created_at" : "2013-08-22 18:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "indices" : [ 3, 11 ],
      "id_str" : "1603381488",
      "id" : 1603381488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 115, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370606410603560960",
  "text" : "RT @Katie44: Thanks for all of your thoughtful questions.  This has been a lot of fun!  Keep sharing your ideas on #MakeCollegeAffordable #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 102, 124 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370604097260376064",
    "text" : "Thanks for all of your thoughtful questions.  This has been a lot of fun!  Keep sharing your ideas on #MakeCollegeAffordable #WHChat",
    "id" : 370604097260376064,
    "created_at" : "2013-08-22 17:51:16 +0000",
    "user" : {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "protected" : false,
      "id_str" : "1603381488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000171840264\/4f11a05d0664eefddc3806b77bfd2b99_normal.jpeg",
      "id" : 1603381488,
      "verified" : true
    }
  },
  "id" : 370606410603560960,
  "created_at" : "2013-08-22 18:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 67, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370589343598907392",
  "text" : "Just spoke about my plan to help more students afford college. Use #MakeCollegeAffordable to share why it's important to you. \u2014bo",
  "id" : 370589343598907392,
  "created_at" : "2013-08-22 16:52:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "indices" : [ 23, 31 ],
      "id_str" : "1603381488",
      "id" : 1603381488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370588059760590848",
  "text" : "RT @WHLive: At 1pm ET, @Katie44 and James Kvaal will answer some of your Q's on the President's plan to make college more affordable. Ask u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Katie Beirne Fallon",
        "screen_name" : "Katie44",
        "indices" : [ 11, 19 ],
        "id_str" : "1603381488",
        "id" : 1603381488
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370587996464349184",
    "text" : "At 1pm ET, @Katie44 and James Kvaal will answer some of your Q's on the President's plan to make college more affordable. Ask using #WHChat.",
    "id" : 370587996464349184,
    "created_at" : "2013-08-22 16:47:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 370588059760590848,
  "created_at" : "2013-08-22 16:47:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370575253321580544",
  "text" : "Obama: \"We\u2019re going to keep fighting to make sure that this remains a country where hard work &amp; studying &amp; responsibility are rewarded.\"",
  "id" : 370575253321580544,
  "created_at" : "2013-08-22 15:56:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/o7TstLg5Te",
      "expanded_url" : "http:\/\/wh.gov\/uc1",
      "display_url" : "wh.gov\/uc1"
    } ]
  },
  "geo" : { },
  "id_str" : "370574783328837632",
  "text" : "Obama: \"I capped loan repayments at 10% of a student\u2019s post-college income. We call it 'Pay-As-You-Earn.'\" http:\/\/t.co\/o7TstLg5Te",
  "id" : 370574783328837632,
  "created_at" : "2013-08-22 15:54:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 113, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370574097014464512",
  "text" : "Obama: \"The government shouldn\u2019t see student loans as a way to make money. It should be a way to help students.\" #MakeCollegeAffordable",
  "id" : 370574097014464512,
  "created_at" : "2013-08-22 15:52:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 116, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370573875769520128",
  "text" : "Obama: \"As we work to bring down costs...we\u2019ve got to offer students who already have debt the chance to repay it.\" #MakeCollegeAffordable",
  "id" : 370573875769520128,
  "created_at" : "2013-08-22 15:51:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370573343705300993",
  "text" : "Obama: We need to \"encourage more colleges to embrace innovative new ways to...maintain a high level of quality without breaking the bank.\"",
  "id" : 370573343705300993,
  "created_at" : "2013-08-22 15:49:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 116, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370572759094423553",
  "text" : "President Obama: \"Colleges that keep their tuition down...are the ones that will see their taxpayer funding go up.\" #MakeCollegeAffordable",
  "id" : 370572759094423553,
  "created_at" : "2013-08-22 15:46:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370571825170100224",
  "text" : "Obama: \"First, we\u2019re going to start rating colleges not just by which are the most selective...but which offer the best value.\"",
  "id" : 370571825170100224,
  "created_at" : "2013-08-22 15:43:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370571557074370561",
  "text" : "Obama: \"Higher education should not be a luxury. It is an economic imperative that every family in America should be able to afford.\"",
  "id" : 370571557074370561,
  "created_at" : "2013-08-22 15:41:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/370571202483331072\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/gIj9wsHdUK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSSIi5hCIAAxODl.jpg",
      "id_str" : "370571202487525376",
      "id" : 370571202487525376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSSIi5hCIAAxODl.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/gIj9wsHdUK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370571202483331072",
  "text" : "Obama: \"We cannot price the middle class &amp; everyone working to get into the middle class out of a college education\" http:\/\/t.co\/gIj9wsHdUK",
  "id" : 370571202483331072,
  "created_at" : "2013-08-22 15:40:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370570877664264193",
  "text" : "RT @WHLive: Obama: \"State legislatures can\u2019t just keep cutting support for public...universities, and colleges can\u2019t just keep jacking up p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370570845883998208",
    "text" : "Obama: \"State legislatures can\u2019t just keep cutting support for public...universities, and colleges can\u2019t just keep jacking up prices.\"",
    "id" : 370570845883998208,
    "created_at" : "2013-08-22 15:39:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 370570877664264193,
  "created_at" : "2013-08-22 15:39:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 32, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370570696919093248",
  "text" : "RT @WHLive: Obama on efforts to #MakeCollegeAffordable: \"That\u2019s all a good start\u2014but it\u2019s not enough. The system\u2019s current trajectory is un\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 20, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370570641239724032",
    "text" : "Obama on efforts to #MakeCollegeAffordable: \"That\u2019s all a good start\u2014but it\u2019s not enough. The system\u2019s current trajectory is unsustainable.\"",
    "id" : 370570641239724032,
    "created_at" : "2013-08-22 15:38:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 370570696919093248,
  "created_at" : "2013-08-22 15:38:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370570550940151809",
  "text" : "Obama: \"We took action to cap loan repayments at 10% of monthly income for many borrowers trying to responsibly manage...student loan debt.\"",
  "id" : 370570550940151809,
  "created_at" : "2013-08-22 15:37:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 145 ],
      "url" : "http:\/\/t.co\/QieaYdNzoe",
      "expanded_url" : "http:\/\/StudentAid.gov",
      "display_url" : "StudentAid.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "370570416927956992",
  "text" : "Obama: \"We\u2019re providing more tools &amp; resources for students &amp; families trying to finance college...check it out at http:\/\/t.co\/QieaYdNzoe.\"",
  "id" : 370570416927956992,
  "created_at" : "2013-08-22 15:37:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370569973351333888",
  "text" : "RT @WHLive: Obama: \"We enacted...reforms...so taxpayer dollars stopped padding the pockets of big banks &amp; instead helped more kids afford c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370569945681526784",
    "text" : "Obama: \"We enacted...reforms...so taxpayer dollars stopped padding the pockets of big banks &amp; instead helped more kids afford college.\"",
    "id" : 370569945681526784,
    "created_at" : "2013-08-22 15:35:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 370569973351333888,
  "created_at" : "2013-08-22 15:35:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370569668769378305",
  "text" : "President Obama: \"Michelle and I, we're only who we are today because scholarships and student loans gave us a shot at a great education.\"",
  "id" : 370569668769378305,
  "created_at" : "2013-08-22 15:34:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370569387398688768",
  "text" : "Obama: \"This is a country that early on made a commitment to put a good education within reach of all who are willing to work for it.\"",
  "id" : 370569387398688768,
  "created_at" : "2013-08-22 15:33:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 114, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370568963874619392",
  "text" : "RT @WHLive: President Obama: \"The average student who borrows for college now graduates owing more than $26,000.\" #MakeCollegeAffordable",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 102, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370568925236690945",
    "text" : "President Obama: \"The average student who borrows for college now graduates owing more than $26,000.\" #MakeCollegeAffordable",
    "id" : 370568925236690945,
    "created_at" : "2013-08-22 15:31:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 370568963874619392,
  "created_at" : "2013-08-22 15:31:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 110, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370568829694664704",
  "text" : "Obama: \"Over the past 3 decades, the average tuition at a public 4-year college has risen by more than 250%.\" #MakeCollegeAffordable",
  "id" : 370568829694664704,
  "created_at" : "2013-08-22 15:31:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 114, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370568574693543936",
  "text" : "President Obama: \"More than ever before, some form of higher education is the surest path into the middle class.\" #MakeCollegeAffordable",
  "id" : 370568574693543936,
  "created_at" : "2013-08-22 15:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370568434784174080",
  "text" : "President Obama: \"The unemployment rate for Americans with at least a college degree is about one-third lower than the national average.\"",
  "id" : 370568434784174080,
  "created_at" : "2013-08-22 15:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 97, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370568123663286272",
  "text" : "President Obama: \"A higher education is the single best investment you can make in your future.\" #MakeCollegeAffordable",
  "id" : 370568123663286272,
  "created_at" : "2013-08-22 15:28:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/18DatKAT2l",
      "expanded_url" : "http:\/\/ow.ly\/i\/2WIUZ",
      "display_url" : "ow.ly\/i\/2WIUZ"
    } ]
  },
  "geo" : { },
  "id_str" : "370567425605271552",
  "text" : "President Obama: \"Our businesses have created 7.3 million new jobs over the last 41 months.\" http:\/\/t.co\/18DatKAT2l",
  "id" : 370567425605271552,
  "created_at" : "2013-08-22 15:25:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370567076945338368",
  "text" : "President Obama: We need \"a national strategy to make sure everyone who works hard has a chance to succeed in the 21st century economy.\"",
  "id" : 370567076945338368,
  "created_at" : "2013-08-22 15:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 109, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "370566143846932480",
  "text" : "\"Hello, Buffalo! Hello, Bulls!\" \u2014Obama kicks off his speech on college affordability: http:\/\/t.co\/b4tqL36eMn #MakeCollegeAffordable",
  "id" : 370566143846932480,
  "created_at" : "2013-08-22 15:20:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 113, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/81w47Cdott",
      "expanded_url" : "http:\/\/at.wh.gov\/oaq6K",
      "display_url" : "at.wh.gov\/oaq6K"
    } ]
  },
  "geo" : { },
  "id_str" : "370564991382204416",
  "text" : "Watch live: President Obama speaks on his plan to help more students afford college \u2014&gt; http:\/\/t.co\/81w47Cdott #MakeCollegeAffordable",
  "id" : 370564991382204416,
  "created_at" : "2013-08-22 15:15:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 19, 27 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 120, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/mLOADL1tz0",
      "expanded_url" : "http:\/\/nyti.ms\/19KLMe1",
      "display_url" : "nyti.ms\/19KLMe1"
    } ]
  },
  "geo" : { },
  "id_str" : "370556710038945793",
  "text" : "Worth sharing: The @NYTimes on President Obama's plan to help more students afford college \u2014&gt; http:\/\/t.co\/mLOADL1tz0 #MakeCollegeAffordable",
  "id" : 370556710038945793,
  "created_at" : "2013-08-22 14:42:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 67, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "370548955492261888",
  "text" : "Watch at 11am ET: President Obama speaks in Buffalo on his plan to #MakeCollegeAffordable for more students \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 370548955492261888,
  "created_at" : "2013-08-22 14:12:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "indices" : [ 3, 11 ],
      "id_str" : "1603381488",
      "id" : 1603381488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370537413493288960",
  "text" : "RT @Katie44: The President is talking college affordability today &amp; I'll be answering some of your Qs at 1ET. Ask with #WHChat: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/C9mCO9hMDS",
        "expanded_url" : "http:\/\/wh.gov\/lgA1Y",
        "display_url" : "wh.gov\/lgA1Y"
      } ]
    },
    "geo" : { },
    "id_str" : "370530859482222592",
    "text" : "The President is talking college affordability today &amp; I'll be answering some of your Qs at 1ET. Ask with #WHChat: http:\/\/t.co\/C9mCO9hMDS",
    "id" : 370530859482222592,
    "created_at" : "2013-08-22 13:00:15 +0000",
    "user" : {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "protected" : false,
      "id_str" : "1603381488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000171840264\/4f11a05d0664eefddc3806b77bfd2b99_normal.jpeg",
      "id" : 1603381488,
      "verified" : true
    }
  },
  "id" : 370537413493288960,
  "created_at" : "2013-08-22 13:26:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Khan Academy",
      "screen_name" : "khanacademy",
      "indices" : [ 3, 15 ],
      "id_str" : "16689804",
      "id" : 16689804
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 55, 66 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "duncankhan",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370342109397544960",
  "text" : "RT @khanacademy: Sal will be interviewing Ed Secretary @arneduncan. Tweet your Qs tagged #duncankhan by 8\/22! Video available after.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 38, 49 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "duncankhan",
        "indices" : [ 72, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370305994091274240",
    "text" : "Sal will be interviewing Ed Secretary @arneduncan. Tweet your Qs tagged #duncankhan by 8\/22! Video available after.",
    "id" : 370305994091274240,
    "created_at" : "2013-08-21 22:06:43 +0000",
    "user" : {
      "name" : "Khan Academy",
      "screen_name" : "khanacademy",
      "protected" : false,
      "id_str" : "16689804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576480569028009984\/YWq8EwXd_normal.png",
      "id" : 16689804,
      "verified" : true
    }
  },
  "id" : 370342109397544960,
  "created_at" : "2013-08-22 00:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/370331592490614784\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/dwRkOf70Hq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSOunwxCAAA6jkI.jpg",
      "id_str" : "370331592503197696",
      "id" : 370331592503197696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSOunwxCAAA6jkI.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/dwRkOf70Hq"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370331592490614784",
  "text" : "FACT: Thanks to #Obamacare, 14 million Latinos can now receive free preventive services like cancer screenings. http:\/\/t.co\/dwRkOf70Hq",
  "id" : 370331592490614784,
  "created_at" : "2013-08-21 23:48:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 59, 71 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climatechange",
      "indices" : [ 75, 89 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/KO4wTRUey1",
      "expanded_url" : "http:\/\/go.usa.gov\/jzQQ",
      "display_url" : "go.usa.gov\/jzQQ"
    } ]
  },
  "geo" : { },
  "id_str" : "370311058247782400",
  "text" : "RT @ENERGY: \"I'm not here to debate what's not debatable.\" @ErnestMoniz on #climatechange http:\/\/t.co\/KO4wTRUey1 #ActOnClimate http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ernest Moniz",
        "screen_name" : "ErnestMoniz",
        "indices" : [ 47, 59 ],
        "id_str" : "1393155566",
        "id" : 1393155566
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/370265826169225216\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ldgxEwOCYb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSNyzpgIcAA8O-2.jpg",
        "id_str" : "370265826014031872",
        "id" : 370265826014031872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSNyzpgIcAA8O-2.jpg",
        "sizes" : [ {
          "h" : 491,
          "resize" : "fit",
          "w" : 491
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 491
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 491
        } ],
        "display_url" : "pic.twitter.com\/ldgxEwOCYb"
      } ],
      "hashtags" : [ {
        "text" : "climatechange",
        "indices" : [ 63, 77 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/KO4wTRUey1",
        "expanded_url" : "http:\/\/go.usa.gov\/jzQQ",
        "display_url" : "go.usa.gov\/jzQQ"
      } ]
    },
    "geo" : { },
    "id_str" : "370265826169225216",
    "text" : "\"I'm not here to debate what's not debatable.\" @ErnestMoniz on #climatechange http:\/\/t.co\/KO4wTRUey1 #ActOnClimate http:\/\/t.co\/ldgxEwOCYb",
    "id" : 370265826169225216,
    "created_at" : "2013-08-21 19:27:06 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 370311058247782400,
  "created_at" : "2013-08-21 22:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/nyIrZYBq3N",
      "expanded_url" : "http:\/\/at.wh.gov\/o94aW",
      "display_url" : "at.wh.gov\/o94aW"
    } ]
  },
  "geo" : { },
  "id_str" : "370305042760208385",
  "text" : "Starting in Jan, you can't be denied coverage due to pre-existing conditions\u2014including mental illnesses: http:\/\/t.co\/nyIrZYBq3N #Obamacare",
  "id" : 370305042760208385,
  "created_at" : "2013-08-21 22:02:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/e98ZgooXlU",
      "expanded_url" : "http:\/\/wh.gov\/lgGZT",
      "display_url" : "wh.gov\/lgGZT"
    } ]
  },
  "geo" : { },
  "id_str" : "370278233779892224",
  "text" : "RT @whitehouseostp: THIS FRIDAY: Tune in for a live #WeTheGeeks hangout on \"Making the US a Geek Magnet\" --&gt; http:\/\/t.co\/e98ZgooXlU #Immigr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 32, 43 ]
      }, {
        "text" : "Immigration",
        "indices" : [ 115, 127 ]
      }, {
        "text" : "STEM",
        "indices" : [ 128, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/e98ZgooXlU",
        "expanded_url" : "http:\/\/wh.gov\/lgGZT",
        "display_url" : "wh.gov\/lgGZT"
      } ]
    },
    "geo" : { },
    "id_str" : "370257778960379905",
    "text" : "THIS FRIDAY: Tune in for a live #WeTheGeeks hangout on \"Making the US a Geek Magnet\" --&gt; http:\/\/t.co\/e98ZgooXlU #Immigration #STEM",
    "id" : 370257778960379905,
    "created_at" : "2013-08-21 18:55:08 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 370278233779892224,
  "created_at" : "2013-08-21 20:16:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370269895704846336",
  "text" : "RT @NSCPress: On August 9, POTUS announced a new website for information on key NSA programs. Here it is, launched just now: http:\/\/t.co\/zS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/zSMPcHgonh",
        "expanded_url" : "http:\/\/icontherecord.tumblr.com\/",
        "display_url" : "icontherecord.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "370262028079726593",
    "text" : "On August 9, POTUS announced a new website for information on key NSA programs. Here it is, launched just now: http:\/\/t.co\/zSMPcHgonh",
    "id" : 370262028079726593,
    "created_at" : "2013-08-21 19:12:01 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 370269895704846336,
  "created_at" : "2013-08-21 19:43:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/4Zue6QnhLC",
      "expanded_url" : "http:\/\/at.wh.gov\/o8LDw",
      "display_url" : "at.wh.gov\/o8LDw"
    } ]
  },
  "geo" : { },
  "id_str" : "370264494544388096",
  "text" : "FACT: Thanks to #Obamacare, more than 500,000 formerly uninsured African American young adults have health insurance. http:\/\/t.co\/4Zue6QnhLC",
  "id" : 370264494544388096,
  "created_at" : "2013-08-21 19:21:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370246492780392450",
  "text" : "RT @letsmove: Tip of the Day: If you exercise at least 60 minutes a day, you are more likely to sleep better at night. #LetsMove",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370215149946544128",
    "text" : "Tip of the Day: If you exercise at least 60 minutes a day, you are more likely to sleep better at night. #LetsMove",
    "id" : 370215149946544128,
    "created_at" : "2013-08-21 16:05:44 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 370246492780392450,
  "created_at" : "2013-08-21 18:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/370232757185572864\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/lXFAsCJhFZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSNUuyjCcAA3WVv.jpg",
      "id_str" : "370232757193961472",
      "id" : 370232757193961472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSNUuyjCcAA3WVv.jpg",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lXFAsCJhFZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/SVyXPbnJ9C",
      "expanded_url" : "http:\/\/at.wh.gov\/o8tXd",
      "display_url" : "at.wh.gov\/o8tXd"
    } ]
  },
  "geo" : { },
  "id_str" : "370232757185572864",
  "text" : "We need to keep fighting until every kid in America can afford higher education \u2014&gt; http:\/\/t.co\/SVyXPbnJ9C, http:\/\/t.co\/lXFAsCJhFZ",
  "id" : 370232757185572864,
  "created_at" : "2013-08-21 17:15:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370226667769184257",
  "text" : "RT @HealthCareTara: This headline speaks for itself - NBC: Even Republican young adults want health insurance, poll finds: http:\/\/t.co\/TReF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/TReF46L8l3",
        "expanded_url" : "http:\/\/nbcnews.to\/19wCUoQ",
        "display_url" : "nbcnews.to\/19wCUoQ"
      } ]
    },
    "geo" : { },
    "id_str" : "370217674074124288",
    "text" : "This headline speaks for itself - NBC: Even Republican young adults want health insurance, poll finds: http:\/\/t.co\/TReF46L8l3",
    "id" : 370217674074124288,
    "created_at" : "2013-08-21 16:15:46 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 370226667769184257,
  "created_at" : "2013-08-21 16:51:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/lfcD3jEP6h",
      "expanded_url" : "http:\/\/usat.ly\/12nypuP",
      "display_url" : "usat.ly\/12nypuP"
    } ]
  },
  "geo" : { },
  "id_str" : "370220347057922049",
  "text" : "RT the news: Small businesses are hiring more, while concerns about #Obamacare are diminishing \u2014&gt; http:\/\/t.co\/lfcD3jEP6h",
  "id" : 370220347057922049,
  "created_at" : "2013-08-21 16:26:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/XAXnmTtyut",
      "expanded_url" : "http:\/\/at.wh.gov\/o87oQ",
      "display_url" : "at.wh.gov\/o87oQ"
    } ]
  },
  "geo" : { },
  "id_str" : "370197666652639232",
  "text" : "FACT: Thanks to #Obamacare, 121,000 Asian Americans and Pacific Islanders ages 19-25 have gained health insurance \u2014&gt; http:\/\/t.co\/XAXnmTtyut",
  "id" : 370197666652639232,
  "created_at" : "2013-08-21 14:56:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 109, 120 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/BAkYpPFG61",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/issues\/foreign-policy",
      "display_url" : "whitehouse.gov\/issues\/foreign\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "370183026002509824",
  "text" : "RT @AmbassadorRice: Just launched our new NSC websites--check out here: http:\/\/t.co\/BAkYpPFG61 Thanks to the @whitehouse digital team for y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 89, 100 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/BAkYpPFG61",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/issues\/foreign-policy",
        "display_url" : "whitehouse.gov\/issues\/foreign\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "370131128671567872",
    "text" : "Just launched our new NSC websites--check out here: http:\/\/t.co\/BAkYpPFG61 Thanks to the @whitehouse digital team for your hard work!",
    "id" : 370131128671567872,
    "created_at" : "2013-08-21 10:31:52 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 370183026002509824,
  "created_at" : "2013-08-21 13:58:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "Molly Ball",
      "screen_name" : "mollyesque",
      "indices" : [ 73, 84 ],
      "id_str" : "130945778",
      "id" : 130945778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/CU8yVqxGhT",
      "expanded_url" : "http:\/\/goo.gl\/aZGxuQ",
      "display_url" : "goo.gl\/aZGxuQ"
    } ]
  },
  "geo" : { },
  "id_str" : "370178067114627073",
  "text" : "RT @Cecilia44: The Atlantic:  Immigration Reformers are Winning August.  @mollyesque http:\/\/t.co\/CU8yVqxGhT.  The House's return is just ar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Molly Ball",
        "screen_name" : "mollyesque",
        "indices" : [ 58, 69 ],
        "id_str" : "130945778",
        "id" : 130945778
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/CU8yVqxGhT",
        "expanded_url" : "http:\/\/goo.gl\/aZGxuQ",
        "display_url" : "goo.gl\/aZGxuQ"
      } ]
    },
    "geo" : { },
    "id_str" : "370175960705794048",
    "text" : "The Atlantic:  Immigration Reformers are Winning August.  @mollyesque http:\/\/t.co\/CU8yVqxGhT.  The House's return is just around the corner",
    "id" : 370175960705794048,
    "created_at" : "2013-08-21 13:30:01 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 370178067114627073,
  "created_at" : "2013-08-21 13:38:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/369966956331294721\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Ak8uaKJwcz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSJi_JNCYAAR8qm.jpg",
      "id_str" : "369966956339683328",
      "id" : 369966956339683328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSJi_JNCYAAR8qm.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Ak8uaKJwcz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369966956331294721",
  "text" : "RT if you agree: It's time for fundamental reforms that help every family in America afford higher education. http:\/\/t.co\/Ak8uaKJwcz",
  "id" : 369966956331294721,
  "created_at" : "2013-08-20 23:39:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369961224470941697",
  "text" : "RT @lacasablanca: Learn more about the economic benefits of #immigration reform to travel and tourism from our new WH blog post --&gt; http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 42, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/66XtM0HUfY",
        "expanded_url" : "http:\/\/at.wh.gov\/o6QOJ",
        "display_url" : "at.wh.gov\/o6QOJ"
      } ]
    },
    "geo" : { },
    "id_str" : "369947245510017026",
    "text" : "Learn more about the economic benefits of #immigration reform to travel and tourism from our new WH blog post --&gt; http:\/\/t.co\/66XtM0HUfY",
    "id" : 369947245510017026,
    "created_at" : "2013-08-20 22:21:11 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 369961224470941697,
  "created_at" : "2013-08-20 23:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Miami Dolphins",
      "screen_name" : "MiamiDolphins",
      "indices" : [ 52, 66 ],
      "id_str" : "19853312",
      "id" : 19853312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369949835383681024",
  "text" : "RT @vj44: POTUS honored the Super Bowl Champion '72 @MiamiDolphins today\u2014the only team in NFL history to go undefeated! http:\/\/t.co\/u0Ogit3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Miami Dolphins",
        "screen_name" : "MiamiDolphins",
        "indices" : [ 42, 56 ],
        "id_str" : "19853312",
        "id" : 19853312
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/369948080226840576\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/u0Ogit3yov",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSJR0aQCMAEb8WI.jpg",
        "id_str" : "369948080239423489",
        "id" : 369948080239423489,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSJR0aQCMAEb8WI.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1050
        } ],
        "display_url" : "pic.twitter.com\/u0Ogit3yov"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369948080226840576",
    "text" : "POTUS honored the Super Bowl Champion '72 @MiamiDolphins today\u2014the only team in NFL history to go undefeated! http:\/\/t.co\/u0Ogit3yov",
    "id" : 369948080226840576,
    "created_at" : "2013-08-20 22:24:30 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 369949835383681024,
  "created_at" : "2013-08-20 22:31:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/X75fEFzzTg",
      "expanded_url" : "http:\/\/at.wh.gov\/o6HF5",
      "display_url" : "at.wh.gov\/o6HF5"
    } ]
  },
  "geo" : { },
  "id_str" : "369922754205605888",
  "text" : "If you have insurance, #Obamacare strengthens it. If you don't, it helps you afford a plan that's right for you \u2014&gt; http:\/\/t.co\/X75fEFzzTg",
  "id" : 369922754205605888,
  "created_at" : "2013-08-20 20:43:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 111, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369904353156403200",
  "text" : "RT @PAniskoff44: POTUS paid off his student loans just 9 years ago. I'm still paying mine. RT if you are too!  #MakeCollegeAffordable More \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakeCollegeAffordable",
        "indices" : [ 94, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "369896948175626240",
    "text" : "POTUS paid off his student loans just 9 years ago. I'm still paying mine. RT if you are too!  #MakeCollegeAffordable More to come Thurs...",
    "id" : 369896948175626240,
    "created_at" : "2013-08-20 19:01:19 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 369904353156403200,
  "created_at" : "2013-08-20 19:30:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 69, 79 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369898051239813121",
  "text" : "RT @Bobby44: hey @whitehouse, looks like Sunny made fetch happen. MT @petesouza Bo and Sunny playing today on the South Lawn. http:\/\/t.co\/m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "petesouza",
        "screen_name" : "petesouza",
        "indices" : [ 56, 66 ],
        "id_str" : "18215973",
        "id" : 18215973
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/369611893637275648\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/mnbKfyUBOD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSEgDwKCQAEQYEW.jpg",
        "id_str" : "369611893259780097",
        "id" : 369611893259780097,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSEgDwKCQAEQYEW.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mnbKfyUBOD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "369611893637275648",
    "geo" : { },
    "id_str" : "369865294451208192",
    "in_reply_to_user_id" : 18215973,
    "text" : "hey @whitehouse, looks like Sunny made fetch happen. MT @petesouza Bo and Sunny playing today on the South Lawn. http:\/\/t.co\/mnbKfyUBOD",
    "id" : 369865294451208192,
    "in_reply_to_status_id" : 369611893637275648,
    "created_at" : "2013-08-20 16:55:32 +0000",
    "in_reply_to_screen_name" : "petesouza",
    "in_reply_to_user_id_str" : "18215973",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 369898051239813121,
  "created_at" : "2013-08-20 19:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369883085909032960",
  "text" : "RT @WHLive: Happening now: President Obama honors the Super Bowl Champion Miami Dolphins and their undefeated 1972 season \u2014&gt; http:\/\/t.co\/dw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/dwJMbO6u0Q",
        "expanded_url" : "http:\/\/at.wh.gov\/o6nSY",
        "display_url" : "at.wh.gov\/o6nSY"
      } ]
    },
    "geo" : { },
    "id_str" : "369883035719962624",
    "text" : "Happening now: President Obama honors the Super Bowl Champion Miami Dolphins and their undefeated 1972 season \u2014&gt; http:\/\/t.co\/dwJMbO6u0Q",
    "id" : 369883035719962624,
    "created_at" : "2013-08-20 18:06:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 369883085909032960,
  "created_at" : "2013-08-20 18:06:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/369876115424149504\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/iUXjk0Ifpu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSIQXgdCAAARRDW.jpg",
      "id_str" : "369876115432538112",
      "id" : 369876115432538112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSIQXgdCAAARRDW.jpg",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 628,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iUXjk0Ifpu"
    } ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 87, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369876115424149504",
  "text" : "FACT: Americans with a college education earn more and are more likely to be employed. #MakeCollegeAffordable, http:\/\/t.co\/iUXjk0Ifpu",
  "id" : 369876115424149504,
  "created_at" : "2013-08-20 17:38:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/369870807809265664\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FlFgSV45OC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSILikDCEAATxNV.jpg",
      "id_str" : "369870807817654272",
      "id" : 369870807817654272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSILikDCEAATxNV.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/FlFgSV45OC"
    } ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 92, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369870807809265664",
  "text" : "FACT: Over the last 3 decades, average tuition at public 4-year colleges more than tripled. #MakeCollegeAffordable, http:\/\/t.co\/FlFgSV45OC",
  "id" : 369870807809265664,
  "created_at" : "2013-08-20 17:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 115, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369862463820279808",
  "text" : "FACT: While college remains a strong investment, the average student now graduates with more than $26,000 in debt. #MakeCollegeAffordable",
  "id" : 369862463820279808,
  "created_at" : "2013-08-20 16:44:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 117, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369855538932097024",
  "text" : "Michelle &amp; I finally repaid our student loans 9 yrs ago\u2014so we know paying for college is tough. More Thursday to #MakeCollegeAffordable. \u2013bo",
  "id" : 369855538932097024,
  "created_at" : "2013-08-20 16:16:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369847430394548224",
  "text" : "RT @vj44: RT to get the word out\u2014Immigration bill would add nearly 14K new jobs on average in each congressional district http:\/\/t.co\/wknQt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/wknQtlXVRg",
        "expanded_url" : "http:\/\/goo.gl\/q762sy",
        "display_url" : "goo.gl\/q762sy"
      } ]
    },
    "geo" : { },
    "id_str" : "369835065909321729",
    "text" : "RT to get the word out\u2014Immigration bill would add nearly 14K new jobs on average in each congressional district http:\/\/t.co\/wknQtlXVRg",
    "id" : 369835065909321729,
    "created_at" : "2013-08-20 14:55:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 369847430394548224,
  "created_at" : "2013-08-20 15:44:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AffordableCare",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369841786857857024",
  "text" : "RT @Simas44: Great ACA news from Montana. \"Pleasantly surprised\" w\/ prices &amp; they don't factor tax credits yet. #AffordableCare  http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AffordableCare",
        "indices" : [ 103, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/mR6vVc85UO",
        "expanded_url" : "http:\/\/bit.ly\/14g5yty",
        "display_url" : "bit.ly\/14g5yty"
      } ]
    },
    "geo" : { },
    "id_str" : "369839196208263168",
    "text" : "Great ACA news from Montana. \"Pleasantly surprised\" w\/ prices &amp; they don't factor tax credits yet. #AffordableCare  http:\/\/t.co\/mR6vVc85UO",
    "id" : 369839196208263168,
    "created_at" : "2013-08-20 15:11:50 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 369841786857857024,
  "created_at" : "2013-08-20 15:22:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MeetSunny",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/0pzQlBtjwX",
      "expanded_url" : "http:\/\/at.wh.gov\/o5V14",
      "display_url" : "at.wh.gov\/o5V14"
    } ]
  },
  "geo" : { },
  "id_str" : "369836306156638208",
  "text" : "In which Sunny and Bo chase each other around the South Lawn of the White House \u2014&gt; http:\/\/t.co\/0pzQlBtjwX #MeetSunny",
  "id" : 369836306156638208,
  "created_at" : "2013-08-20 15:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/3lsNwsOTCn",
      "expanded_url" : "http:\/\/at.wh.gov\/o4DkW",
      "display_url" : "at.wh.gov\/o4DkW"
    } ]
  },
  "geo" : { },
  "id_str" : "369610448041021440",
  "text" : "RT @FLOTUS: So excited to introduce the newest member of the Obama family\u2014our puppy, Sunny! http:\/\/t.co\/3lsNwsOTCn \u2014mo http:\/\/t.co\/KKO9NTmg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/369606071599374336\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/KKO9NTmgha",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSEaw40CIAAb9JR.jpg",
        "id_str" : "369606071607762944",
        "id" : 369606071607762944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSEaw40CIAAb9JR.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1050
        } ],
        "display_url" : "pic.twitter.com\/KKO9NTmgha"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/3lsNwsOTCn",
        "expanded_url" : "http:\/\/at.wh.gov\/o4DkW",
        "display_url" : "at.wh.gov\/o4DkW"
      } ]
    },
    "geo" : { },
    "id_str" : "369606071599374336",
    "text" : "So excited to introduce the newest member of the Obama family\u2014our puppy, Sunny! http:\/\/t.co\/3lsNwsOTCn \u2014mo http:\/\/t.co\/KKO9NTmgha",
    "id" : 369606071599374336,
    "created_at" : "2013-08-19 23:45:29 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 369610448041021440,
  "created_at" : "2013-08-20 00:02:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/369607058334576640\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/poen5pP7Cv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSEbqUrCcAAOtQA.jpg",
      "id_str" : "369607058338770944",
      "id" : 369607058338770944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSEbqUrCcAAOtQA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/poen5pP7Cv"
    } ],
    "hashtags" : [ {
      "text" : "MeetSunny",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/QRDoYqAekL",
      "expanded_url" : "http:\/\/at.wh.gov\/o4DkW",
      "display_url" : "at.wh.gov\/o4DkW"
    } ]
  },
  "geo" : { },
  "id_str" : "369607058334576640",
  "text" : "There's a new puppy at the White House\u2026 http:\/\/t.co\/QRDoYqAekL #MeetSunny, http:\/\/t.co\/poen5pP7Cv",
  "id" : 369607058334576640,
  "created_at" : "2013-08-19 23:49:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/At4JdEmoXj",
      "expanded_url" : "http:\/\/at.wh.gov\/o4CPq",
      "display_url" : "at.wh.gov\/o4CPq"
    } ]
  },
  "geo" : { },
  "id_str" : "369582848367284224",
  "text" : "RT to spread the news: Here are 7 ways #Obamacare is helping families save money on health insurance \u2014&gt; http:\/\/t.co\/At4JdEmoXj",
  "id" : 369582848367284224,
  "created_at" : "2013-08-19 22:13:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 98, 108 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369575899554791425",
  "text" : "RT @Cecilia44: Obamacare is good for young people.  Wearing my Policy hat AND my mom hat, I'd say @ezraklein is right. http:\/\/t.co\/04CwQdjq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ezra Klein",
        "screen_name" : "ezraklein",
        "indices" : [ 83, 93 ],
        "id_str" : "18622869",
        "id" : 18622869
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/04CwQdjq0I",
        "expanded_url" : "http:\/\/goo.gl\/rdPPRC",
        "display_url" : "goo.gl\/rdPPRC"
      } ]
    },
    "geo" : { },
    "id_str" : "369531783177457665",
    "text" : "Obamacare is good for young people.  Wearing my Policy hat AND my mom hat, I'd say @ezraklein is right. http:\/\/t.co\/04CwQdjq0I",
    "id" : 369531783177457665,
    "created_at" : "2013-08-19 18:50:17 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 369575899554791425,
  "created_at" : "2013-08-19 21:45:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/QuQPiE2JxE",
      "expanded_url" : "http:\/\/wapo.st\/16qhfxg",
      "display_url" : "wapo.st\/16qhfxg"
    } ]
  },
  "geo" : { },
  "id_str" : "369565238745509889",
  "text" : "RT @jesseclee44: \"Why...oppose ACA at every turn? Why would you oppose something that\u2019s helping me now?\" http:\/\/t.co\/QuQPiE2JxE Gonna hear \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/QuQPiE2JxE",
        "expanded_url" : "http:\/\/wapo.st\/16qhfxg",
        "display_url" : "wapo.st\/16qhfxg"
      } ]
    },
    "geo" : { },
    "id_str" : "369561252869074944",
    "text" : "\"Why...oppose ACA at every turn? Why would you oppose something that\u2019s helping me now?\" http:\/\/t.co\/QuQPiE2JxE Gonna hear lots more of that.",
    "id" : 369561252869074944,
    "created_at" : "2013-08-19 20:47:23 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 369565238745509889,
  "created_at" : "2013-08-19 21:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    }, {
      "name" : "YI",
      "screen_name" : "YI_Care",
      "indices" : [ 62, 70 ],
      "id_str" : "2510807636",
      "id" : 2510807636
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Sebelius\/status\/369544219972468736\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/pSnhiSpe08",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSDigooCIAAa6_W.jpg",
      "id_str" : "369544219733401600",
      "id" : 369544219733401600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSDigooCIAAa6_W.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pSnhiSpe08"
    } ],
    "hashtags" : [ {
      "text" : "Houston",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/KxKpGDkgrj",
      "expanded_url" : "http:\/\/www.healthyyoungamerica.org\/",
      "display_url" : "healthyyoungamerica.org"
    } ]
  },
  "geo" : { },
  "id_str" : "369547273060884480",
  "text" : "RT @Sebelius: Very excited to announce our video contest with @YI_Care in #Houston today! http:\/\/t.co\/KxKpGDkgrj http:\/\/t.co\/pSnhiSpe08",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YI",
        "screen_name" : "YI_Care",
        "indices" : [ 48, 56 ],
        "id_str" : "2510807636",
        "id" : 2510807636
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Sebelius\/status\/369544219972468736\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/pSnhiSpe08",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSDigooCIAAa6_W.jpg",
        "id_str" : "369544219733401600",
        "id" : 369544219733401600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSDigooCIAAa6_W.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pSnhiSpe08"
      } ],
      "hashtags" : [ {
        "text" : "Houston",
        "indices" : [ 60, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/KxKpGDkgrj",
        "expanded_url" : "http:\/\/www.healthyyoungamerica.org\/",
        "display_url" : "healthyyoungamerica.org"
      } ]
    },
    "geo" : { },
    "id_str" : "369544219972468736",
    "text" : "Very excited to announce our video contest with @YI_Care in #Houston today! http:\/\/t.co\/KxKpGDkgrj http:\/\/t.co\/pSnhiSpe08",
    "id" : 369544219972468736,
    "created_at" : "2013-08-19 19:39:42 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 369547273060884480,
  "created_at" : "2013-08-19 19:51:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    }, {
      "name" : "NPR",
      "screen_name" : "NPR",
      "indices" : [ 86, 90 ],
      "id_str" : "5392522",
      "id" : 5392522
    }, {
      "name" : "julie rovner",
      "screen_name" : "jrovner",
      "indices" : [ 95, 103 ],
      "id_str" : "16149614",
      "id" : 16149614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCare",
      "indices" : [ 42, 52 ]
    }, {
      "text" : "ACA",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/1MSivbdnJQ",
      "expanded_url" : "http:\/\/www.npr.org\/blogs\/health\/2013\/08\/19\/207902395\/you-ask-we-answer-more-of-your-questions-about-the-affordable-care-act",
      "display_url" : "npr.org\/blogs\/health\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369531765213241345",
  "text" : "RT @Sebelius: Do you have questions about #ObamaCare? Check out this great story from @NPR and @jrovner: http:\/\/t.co\/1MSivbdnJQ #ACA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NPR",
        "screen_name" : "NPR",
        "indices" : [ 72, 76 ],
        "id_str" : "5392522",
        "id" : 5392522
      }, {
        "name" : "julie rovner",
        "screen_name" : "jrovner",
        "indices" : [ 81, 89 ],
        "id_str" : "16149614",
        "id" : 16149614
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCare",
        "indices" : [ 28, 38 ]
      }, {
        "text" : "ACA",
        "indices" : [ 114, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/1MSivbdnJQ",
        "expanded_url" : "http:\/\/www.npr.org\/blogs\/health\/2013\/08\/19\/207902395\/you-ask-we-answer-more-of-your-questions-about-the-affordable-care-act",
        "display_url" : "npr.org\/blogs\/health\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "369450401537331200",
    "text" : "Do you have questions about #ObamaCare? Check out this great story from @NPR and @jrovner: http:\/\/t.co\/1MSivbdnJQ #ACA",
    "id" : 369450401537331200,
    "created_at" : "2013-08-19 13:26:54 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 369531765213241345,
  "created_at" : "2013-08-19 18:50:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 26, 38 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/369489984845135874\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/jGOZAIfd9W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BSCxLv9CQAAz6Th.jpg",
      "id_str" : "369489984853524480",
      "id" : 369489984853524480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSCxLv9CQAAz6Th.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/jGOZAIfd9W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369489984845135874",
  "text" : "Happy birthday, President @BillClinton! http:\/\/t.co\/jGOZAIfd9W",
  "id" : 369489984845135874,
  "created_at" : "2013-08-19 16:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildingStrategy",
      "indices" : [ 35, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "369480242689105922",
  "text" : "RT @WhiteHouseCEQ: Hurricane Sandy #RebuildingStrategy: A model for communities across the country as they prepare for climate change http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildingStrategy",
        "indices" : [ 16, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ehd8oGJfkl",
        "expanded_url" : "http:\/\/bit.ly\/12i6CM4",
        "display_url" : "bit.ly\/12i6CM4"
      } ]
    },
    "geo" : { },
    "id_str" : "369469713635504128",
    "text" : "Hurricane Sandy #RebuildingStrategy: A model for communities across the country as they prepare for climate change http:\/\/t.co\/ehd8oGJfkl",
    "id" : 369469713635504128,
    "created_at" : "2013-08-19 14:43:38 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 369480242689105922,
  "created_at" : "2013-08-19 15:25:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/h7mn7QG93F",
      "expanded_url" : "http:\/\/at.wh.gov\/o3AYY",
      "display_url" : "at.wh.gov\/o3AYY"
    } ]
  },
  "geo" : { },
  "id_str" : "369471133315121155",
  "text" : "Worth a read and a RT: New White House report on why U.S. coasts should prepare for rising seas \u2014&gt; http:\/\/t.co\/h7mn7QG93F #ActOnClimate",
  "id" : 369471133315121155,
  "created_at" : "2013-08-19 14:49:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Parade Magazine",
      "screen_name" : "ParadeMagazine",
      "indices" : [ 43, 58 ],
      "id_str" : "18682378",
      "id" : 18682378
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 68, 77 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 96, 107 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/7I5nBAfHqt",
      "expanded_url" : "http:\/\/at.wh.gov\/o1Z1V",
      "display_url" : "at.wh.gov\/o1Z1V"
    } ]
  },
  "geo" : { },
  "id_str" : "369112822975717376",
  "text" : "RT @FLOTUS: Worth a read: The First Lady's @ParadeMagazine piece on @LetsMove &amp; life at the @WhiteHouse: http:\/\/t.co\/7I5nBAfHqt, http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Parade Magazine",
        "screen_name" : "ParadeMagazine",
        "indices" : [ 31, 46 ],
        "id_str" : "18682378",
        "id" : 18682378
      }, {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 56, 65 ],
        "id_str" : "36719281",
        "id" : 36719281
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 84, 95 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/369103431350226945\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/SRBRN51QEd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BR9RnX-CEAAhoG6.jpg",
        "id_str" : "369103431358615552",
        "id" : 369103431358615552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BR9RnX-CEAAhoG6.jpg",
        "sizes" : [ {
          "h" : 466,
          "resize" : "fit",
          "w" : 434
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 434
        }, {
          "h" : 365,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 434
        } ],
        "display_url" : "pic.twitter.com\/SRBRN51QEd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/7I5nBAfHqt",
        "expanded_url" : "http:\/\/at.wh.gov\/o1Z1V",
        "display_url" : "at.wh.gov\/o1Z1V"
      } ]
    },
    "geo" : { },
    "id_str" : "369103431350226945",
    "text" : "Worth a read: The First Lady's @ParadeMagazine piece on @LetsMove &amp; life at the @WhiteHouse: http:\/\/t.co\/7I5nBAfHqt, http:\/\/t.co\/SRBRN51QEd",
    "id" : 369103431350226945,
    "created_at" : "2013-08-18 14:28:10 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 369112822975717376,
  "created_at" : "2013-08-18 15:05:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DgTWkrwDY5",
      "expanded_url" : "http:\/\/at.wh.gov\/o04GG",
      "display_url" : "at.wh.gov\/o04GG"
    } ]
  },
  "geo" : { },
  "id_str" : "368764622309818369",
  "text" : "Obama: \"If you don\u2019t have insurance\u2014beginning on October 1st\u2014private plans will actually compete for your business.\" http:\/\/t.co\/DgTWkrwDY5",
  "id" : 368764622309818369,
  "created_at" : "2013-08-17 16:01:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/NTsJspNw2c",
      "expanded_url" : "http:\/\/at.wh.gov\/o02A2",
      "display_url" : "at.wh.gov\/o02A2"
    } ]
  },
  "geo" : { },
  "id_str" : "368741784802693122",
  "text" : "\"Health insurance isn\u2019t a privilege\u2014it is your right. And we\u2019re going to keep it that way.\" \u2014President Obama: http:\/\/t.co\/NTsJspNw2c",
  "id" : 368741784802693122,
  "created_at" : "2013-08-17 14:31:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "UniversityofMichigan",
      "screen_name" : "UMich",
      "indices" : [ 16, 22 ],
      "id_str" : "88836132",
      "id" : 88836132
    }, {
      "name" : "Michigan Alumni",
      "screen_name" : "michiganalumni",
      "indices" : [ 23, 38 ],
      "id_str" : "25422900",
      "id" : 25422900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "umalumni",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "GoBlue",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368475510428282880",
  "text" : "RT @Cecilia44: \u201C@umich @michiganalumni: Do you bring Blue to work? Show us with #umalumni \/\/  I bring the Blue to the WH! #GoBlue http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UniversityofMichigan",
        "screen_name" : "UMich",
        "indices" : [ 1, 7 ],
        "id_str" : "88836132",
        "id" : 88836132
      }, {
        "name" : "Michigan Alumni",
        "screen_name" : "michiganalumni",
        "indices" : [ 8, 23 ],
        "id_str" : "25422900",
        "id" : 25422900
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/368465995993604096\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/JMSYnf9phX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BR0N3wOCYAEQ4vQ.jpg",
        "id_str" : "368465996001992705",
        "id" : 368465996001992705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BR0N3wOCYAEQ4vQ.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/JMSYnf9phX"
      } ],
      "hashtags" : [ {
        "text" : "umalumni",
        "indices" : [ 65, 74 ]
      }, {
        "text" : "GoBlue",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "368458729056129025",
    "geo" : { },
    "id_str" : "368465995993604096",
    "in_reply_to_user_id" : 88836132,
    "text" : "\u201C@umich @michiganalumni: Do you bring Blue to work? Show us with #umalumni \/\/  I bring the Blue to the WH! #GoBlue http:\/\/t.co\/JMSYnf9phX",
    "id" : 368465995993604096,
    "in_reply_to_status_id" : 368458729056129025,
    "created_at" : "2013-08-16 20:15:13 +0000",
    "in_reply_to_screen_name" : "UMich",
    "in_reply_to_user_id_str" : "88836132",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 368475510428282880,
  "created_at" : "2013-08-16 20:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 33, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sFeDU108Wn",
      "expanded_url" : "http:\/\/at.wh.gov\/o0f2V",
      "display_url" : "at.wh.gov\/o0f2V"
    } ]
  },
  "geo" : { },
  "id_str" : "368463752917577728",
  "text" : "You asked and we answered: Watch #WestWingWeek to hear answers to your questions about life at the White House \u2014&gt; http:\/\/t.co\/sFeDU108Wn",
  "id" : 368463752917577728,
  "created_at" : "2013-08-16 20:06:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368426306599272448",
  "text" : "RT @letsmove: Tip of the Day: Drinking more water helps you have more energy and stamina. #LetsMove",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368410103294480384",
    "text" : "Tip of the Day: Drinking more water helps you have more energy and stamina. #LetsMove",
    "id" : 368410103294480384,
    "created_at" : "2013-08-16 16:33:08 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 368426306599272448,
  "created_at" : "2013-08-16 17:37:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/8axTqyjJ18",
      "expanded_url" : "http:\/\/at.wh.gov\/nZLV3",
      "display_url" : "at.wh.gov\/nZLV3"
    } ]
  },
  "geo" : { },
  "id_str" : "368407932045504512",
  "text" : "\"College is not a partisan issue. It's something that's beneficial to society.\" \u2014&gt; http:\/\/t.co\/8axTqyjJ18",
  "id" : 368407932045504512,
  "created_at" : "2013-08-16 16:24:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaOpinionla",
      "indices" : [ 77, 89 ]
    }, {
      "text" : "DACA",
      "indices" : [ 93, 98 ]
    }, {
      "text" : "DREAMers",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "immigrationreform",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368386357430738944",
  "text" : "RT @Cecilia44: \"The Dreamers put a face to..the injustices of the...system.\" #LaOpinionla on #DACA, #DREAMers &amp; #immigrationreform \nhttp:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LaOpinionla",
        "indices" : [ 62, 74 ]
      }, {
        "text" : "DACA",
        "indices" : [ 78, 83 ]
      }, {
        "text" : "DREAMers",
        "indices" : [ 85, 94 ]
      }, {
        "text" : "immigrationreform",
        "indices" : [ 101, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/rjYDpG9UI7",
        "expanded_url" : "http:\/\/goo.gl\/SDN7dW",
        "display_url" : "goo.gl\/SDN7dW"
      } ]
    },
    "geo" : { },
    "id_str" : "368374820217421824",
    "text" : "\"The Dreamers put a face to..the injustices of the...system.\" #LaOpinionla on #DACA, #DREAMers &amp; #immigrationreform \nhttp:\/\/t.co\/rjYDpG9UI7",
    "id" : 368374820217421824,
    "created_at" : "2013-08-16 14:12:55 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 368386357430738944,
  "created_at" : "2013-08-16 14:58:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/368375746386874368\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/1ZwDA8hLZL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRy7yiPCUAAwJto.jpg",
      "id_str" : "368375746395262976",
      "id" : 368375746395262976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRy7yiPCUAAwJto.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/1ZwDA8hLZL"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/bkX6lifmsA",
      "expanded_url" : "http:\/\/at.wh.gov\/nZpKu",
      "display_url" : "at.wh.gov\/nZpKu"
    } ]
  },
  "geo" : { },
  "id_str" : "368375746386874368",
  "text" : "RT to spread the word: Here's how #Obamacare helps small businesses afford health insurance: http:\/\/t.co\/bkX6lifmsA, http:\/\/t.co\/1ZwDA8hLZL",
  "id" : 368375746386874368,
  "created_at" : "2013-08-16 14:16:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/368135083514806272\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/XStplcHzMq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRvg6HLCQAA0exp.jpg",
      "id_str" : "368135083523194880",
      "id" : 368135083523194880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRvg6HLCQAA0exp.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/XStplcHzMq"
    } ],
    "hashtags" : [ {
      "text" : "DREAMers",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/L9P0vTEG0Q",
      "expanded_url" : "http:\/\/at.wh.gov\/nYm0b",
      "display_url" : "at.wh.gov\/nYm0b"
    } ]
  },
  "geo" : { },
  "id_str" : "368135083514806272",
  "text" : "We are a better nation than one that deports innocent kids: http:\/\/t.co\/L9P0vTEG0Q #DREAMers, http:\/\/t.co\/XStplcHzMq",
  "id" : 368135083514806272,
  "created_at" : "2013-08-15 22:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cal\uD83D\uDC3B",
      "screen_name" : "Cal",
      "indices" : [ 43, 47 ],
      "id_str" : "17445752",
      "id" : 17445752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 72, 90 ]
    }, {
      "text" : "DREAMers",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/xA6X9WAuNW",
      "expanded_url" : "http:\/\/at.wh.gov\/nYcww",
      "display_url" : "at.wh.gov\/nYcww"
    } ]
  },
  "geo" : { },
  "id_str" : "368125049926336512",
  "text" : "Kevin Lee, a deferred action recipient and @Cal graduate on why passing #ImmigrationReform is so important: http:\/\/t.co\/xA6X9WAuNW #DREAMers",
  "id" : 368125049926336512,
  "created_at" : "2013-08-15 21:40:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DREAMers",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368119948021088256",
  "text" : "\u201CI felt the fear vanish. I felt accepted.\u201D \u2014Alan A., a student at the College of Southern Nevada who received deferred action #DREAMers",
  "id" : 368119948021088256,
  "created_at" : "2013-08-15 21:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DREAMers",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368104825461809152",
  "text" : "FACT: Through July, more than 430,000 young people have received deferred action\u2014freeing them from the fear of deportation. #DREAMers",
  "id" : 368104825461809152,
  "created_at" : "2013-08-15 20:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 14, 21 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DREAMers",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Zwe7wcrSIF",
      "expanded_url" : "http:\/\/at.wh.gov\/nY615",
      "display_url" : "at.wh.gov\/nY615"
    } ]
  },
  "geo" : { },
  "id_str" : "368097329665933312",
  "text" : "One year ago, @DHSgov began removing the threat of deportation for young people brought to America as kids: http:\/\/t.co\/Zwe7wcrSIF #DREAMers",
  "id" : 368097329665933312,
  "created_at" : "2013-08-15 19:50:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigrationreform",
      "indices" : [ 112, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368083536915349504",
  "text" : "RT @Cecilia44: On the first anniversary of the implementation of DACA: what it means to us, to DREAMers, and to #immigrationreform: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigrationreform",
        "indices" : [ 97, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/GbazF2DVQC",
        "expanded_url" : "http:\/\/goo.gl\/DYThfh",
        "display_url" : "goo.gl\/DYThfh"
      } ]
    },
    "geo" : { },
    "id_str" : "368077125854568448",
    "text" : "On the first anniversary of the implementation of DACA: what it means to us, to DREAMers, and to #immigrationreform: http:\/\/t.co\/GbazF2DVQC",
    "id" : 368077125854568448,
    "created_at" : "2013-08-15 18:30:00 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 368083536915349504,
  "created_at" : "2013-08-15 18:55:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/368058567783243776\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/6QzbBRQvHX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRubUT2CYAIsPr-.jpg",
      "id_str" : "368058567787438082",
      "id" : 368058567787438082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRubUT2CYAIsPr-.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6QzbBRQvHX"
    } ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 36, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/GDgh3L4mWI",
      "expanded_url" : "http:\/\/at.wh.gov\/nXMum",
      "display_url" : "at.wh.gov\/nXMum"
    } ]
  },
  "geo" : { },
  "id_str" : "368058567783243776",
  "text" : "President Obama on the situation in #Egypt \u2014&gt; http:\/\/t.co\/GDgh3L4mWI, http:\/\/t.co\/6QzbBRQvHX",
  "id" : 368058567783243776,
  "created_at" : "2013-08-15 17:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 44, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368018932155703297",
  "text" : "Obama: \"America will work with all those in #Egypt...who support a future of stability that rests on the foundation of justice and peace\"",
  "id" : 368018932155703297,
  "created_at" : "2013-08-15 14:38:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368017774083182592",
  "text" : "Obama: \"We call on the Egyptian authorities to respect the universal rights of the people. We call on those who protest to do so peacefully\"",
  "id" : 368017774083182592,
  "created_at" : "2013-08-15 14:34:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368017532826812416",
  "text" : "Obama: \"We deplore violence against civilians. We support universal rights essential to human dignity\u2014including...peaceful protest.\" #Egypt",
  "id" : 368017532826812416,
  "created_at" : "2013-08-15 14:33:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368017191918006274",
  "text" : "President Obama: \"The United States strongly condemns the steps that have been taken by Egypt\u2019s interim government and security forces.\"",
  "id" : 368017191918006274,
  "created_at" : "2013-08-15 14:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "368016339987734528",
  "text" : "Happening now: President Obama delivers a statement on Egypt. Listen live \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 368016339987734528,
  "created_at" : "2013-08-15 14:28:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 61, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "368004835980767233",
  "text" : "Tune in at 10:15am ET to hear President Obama's statement on #Egypt \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 368004835980767233,
  "created_at" : "2013-08-15 13:42:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Social Security",
      "screen_name" : "SocialSecurity",
      "indices" : [ 23, 38 ],
      "id_str" : "39580052",
      "id" : 39580052
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/367774970031529984\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/ZSBjfN7LAf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRqZYv5CYAEKzvN.jpg",
      "id_str" : "367774970035724289",
      "id" : 367774970035724289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRqZYv5CYAEKzvN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/ZSBjfN7LAf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/i4Cvmm6JcN",
      "expanded_url" : "http:\/\/at.wh.gov\/nWgEB",
      "display_url" : "at.wh.gov\/nWgEB"
    } ]
  },
  "geo" : { },
  "id_str" : "367774970031529984",
  "text" : "Happy 78th birthday to @SocialSecurity! http:\/\/t.co\/i4Cvmm6JcN, http:\/\/t.co\/ZSBjfN7LAf",
  "id" : 367774970031529984,
  "created_at" : "2013-08-14 22:29:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/DSwZEauG0k",
      "expanded_url" : "http:\/\/at.wh.gov\/nW6OG",
      "display_url" : "at.wh.gov\/nW6OG"
    } ]
  },
  "geo" : { },
  "id_str" : "367757423395618818",
  "text" : "FACT: U.S. wind energy can now power more than 15 million homes every year \u2014&gt; http:\/\/t.co\/DSwZEauG0k #ActOnClimate",
  "id" : 367757423395618818,
  "created_at" : "2013-08-14 21:19:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/TszuUyBzuY",
      "expanded_url" : "http:\/\/on.tnr.com\/18uSZdu",
      "display_url" : "on.tnr.com\/18uSZdu"
    } ]
  },
  "geo" : { },
  "id_str" : "367748342047965184",
  "text" : "RT @Simas44: New study shows typical family buying insurance on their own saving thousands because of ACA.  http:\/\/t.co\/TszuUyBzuY http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/367669307880124416\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/wyVN8zxuN6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRo5SZtCMAAbkYP.jpg",
        "id_str" : "367669307884318720",
        "id" : 367669307884318720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRo5SZtCMAAbkYP.jpg",
        "sizes" : [ {
          "h" : 211,
          "resize" : "fit",
          "w" : 298
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 298
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 298
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 298
        } ],
        "display_url" : "pic.twitter.com\/wyVN8zxuN6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/TszuUyBzuY",
        "expanded_url" : "http:\/\/on.tnr.com\/18uSZdu",
        "display_url" : "on.tnr.com\/18uSZdu"
      } ]
    },
    "geo" : { },
    "id_str" : "367669307880124416",
    "text" : "New study shows typical family buying insurance on their own saving thousands because of ACA.  http:\/\/t.co\/TszuUyBzuY http:\/\/t.co\/wyVN8zxuN6",
    "id" : 367669307880124416,
    "created_at" : "2013-08-14 15:29:28 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 367748342047965184,
  "created_at" : "2013-08-14 20:43:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/367684754717425664\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/UwGlUU52BJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRpHVhrCQAAysg3.png",
      "id_str" : "367684754725814272",
      "id" : 367684754725814272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRpHVhrCQAAysg3.png",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 566
      } ],
      "display_url" : "pic.twitter.com\/UwGlUU52BJ"
    } ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/BsUC9mud8U",
      "expanded_url" : "http:\/\/at.wh.gov\/nVza6",
      "display_url" : "at.wh.gov\/nVza6"
    } ]
  },
  "geo" : { },
  "id_str" : "367684754717425664",
  "text" : "\"The United States strongly condemns the use of violence against protesters in #Egypt.\" http:\/\/t.co\/BsUC9mud8U, http:\/\/t.co\/UwGlUU52BJ",
  "id" : 367684754717425664,
  "created_at" : "2013-08-14 16:30:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/367681124241117184\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/84lQeMkH90",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRpECNFCEAEc6yw.jpg",
      "id_str" : "367681124245311489",
      "id" : 367681124245311489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRpECNFCEAEc6yw.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/84lQeMkH90"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367681124241117184",
  "text" : "RT so your friends know how #Obamacare is helping millions of Americans afford quality health insurance: http:\/\/t.co\/84lQeMkH90",
  "id" : 367681124241117184,
  "created_at" : "2013-08-14 16:16:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/PgIWqMez8Y",
      "expanded_url" : "http:\/\/at.wh.gov\/nVrbl",
      "display_url" : "at.wh.gov\/nVrbl"
    } ]
  },
  "geo" : { },
  "id_str" : "367672540153405441",
  "text" : "\"Interest rates are actually going down for 11 million students.\" Watch \u2014&gt; http:\/\/t.co\/PgIWqMez8Y",
  "id" : 367672540153405441,
  "created_at" : "2013-08-14 15:42:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367669889168711680",
  "text" : "RT @Lehrich44: On bus tour through NY and PA next week, President Obama will discuss importance of keeping college costs down for middle cl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "367669461710409728",
    "text" : "On bus tour through NY and PA next week, President Obama will discuss importance of keeping college costs down for middle class families",
    "id" : 367669461710409728,
    "created_at" : "2013-08-14 15:30:05 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 367669889168711680,
  "created_at" : "2013-08-14 15:31:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/367658172091097089\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/YG8o5fIN4m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRovKNqCYAEPd9h.png",
      "id_str" : "367658172095291393",
      "id" : 367658172095291393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRovKNqCYAEPd9h.png",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YG8o5fIN4m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367658172091097089",
  "text" : "Guess what day it is\u2026 http:\/\/t.co\/YG8o5fIN4m",
  "id" : 367658172091097089,
  "created_at" : "2013-08-14 14:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/367429058444808192\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/fYZNcC5hxd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRleyC0CUAADtLt.jpg",
      "id_str" : "367429058449002496",
      "id" : 367429058449002496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRleyC0CUAADtLt.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fYZNcC5hxd"
    } ],
    "hashtags" : [ {
      "text" : "LeftHandersDay",
      "indices" : [ 6, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367429058444808192",
  "text" : "Happy #LeftHandersDay! http:\/\/t.co\/fYZNcC5hxd",
  "id" : 367429058444808192,
  "created_at" : "2013-08-13 23:34:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 112, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367420202046091264",
  "text" : "FACT: Health insurance companies can no longer place lifetime limits on the amount of coverage you can receive. #ThanksObamacare",
  "id" : 367420202046091264,
  "created_at" : "2013-08-13 22:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Allison Janney",
      "screen_name" : "AllisonBJanney",
      "indices" : [ 33, 48 ],
      "id_str" : "123015364",
      "id" : 123015364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/ZcT9a14noc",
      "expanded_url" : "http:\/\/youtu.be\/Q7H_L5cYkg8",
      "display_url" : "youtu.be\/Q7H_L5cYkg8"
    } ]
  },
  "geo" : { },
  "id_str" : "367409152273821696",
  "text" : "RT @PressSec: Welcome to Twitter @AllisonBJanney! Can you teach me how to do the Jackal?\u00A0http:\/\/t.co\/ZcT9a14noc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allison Janney",
        "screen_name" : "AllisonBJanney",
        "indices" : [ 19, 34 ],
        "id_str" : "123015364",
        "id" : 123015364
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/ZcT9a14noc",
        "expanded_url" : "http:\/\/youtu.be\/Q7H_L5cYkg8",
        "display_url" : "youtu.be\/Q7H_L5cYkg8"
      } ]
    },
    "geo" : { },
    "id_str" : "367409059688751105",
    "text" : "Welcome to Twitter @AllisonBJanney! Can you teach me how to do the Jackal?\u00A0http:\/\/t.co\/ZcT9a14noc",
    "id" : 367409059688751105,
    "created_at" : "2013-08-13 22:15:20 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 367409152273821696,
  "created_at" : "2013-08-13 22:15:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 115, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367403099205271552",
  "text" : "FACT: Next year, health insurance companies won't be able to deny Americans coverage for a pre-existing condition. #ThanksObamacare",
  "id" : 367403099205271552,
  "created_at" : "2013-08-13 21:51:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/REpULet0uf",
      "expanded_url" : "http:\/\/at.wh.gov\/nTW0L",
      "display_url" : "at.wh.gov\/nTW0L"
    } ]
  },
  "geo" : { },
  "id_str" : "367396456472133632",
  "text" : "FACT: Consumer protections from #Obamacare\u2014including caps on out-of-pocket major medical costs\u2014go into effect in Jan. http:\/\/t.co\/REpULet0uf",
  "id" : 367396456472133632,
  "created_at" : "2013-08-13 21:25:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AJ9DcS4zSH",
      "expanded_url" : "http:\/\/at.wh.gov\/nTFyk",
      "display_url" : "at.wh.gov\/nTFyk"
    } ]
  },
  "geo" : { },
  "id_str" : "367363016288772096",
  "text" : "Worth sharing: Creating a path to earned citizenship for undocumented immigrants would strengthen our economy \u2014&gt; http:\/\/t.co\/AJ9DcS4zSH",
  "id" : 367363016288772096,
  "created_at" : "2013-08-13 19:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367356695946592256",
  "text" : "RT @Cecilia44: Here's how fixing our broken immigration system would benefit America's farmers &amp; the entire agricultural industry \u2014&gt; http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 125, 147 ],
        "url" : "http:\/\/t.co\/aWDcHUl4Br",
        "expanded_url" : "http:\/\/at.wh.gov\/nTzSi",
        "display_url" : "at.wh.gov\/nTzSi"
      } ]
    },
    "geo" : { },
    "id_str" : "367353151239634946",
    "text" : "Here's how fixing our broken immigration system would benefit America's farmers &amp; the entire agricultural industry \u2014&gt; http:\/\/t.co\/aWDcHUl4Br",
    "id" : 367353151239634946,
    "created_at" : "2013-08-13 18:33:11 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 367356695946592256,
  "created_at" : "2013-08-13 18:47:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/367315040359026688\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/4n0erVuJY6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRj3FUYCEAA0l7e.jpg",
      "id_str" : "367315040371609600",
      "id" : 367315040371609600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRj3FUYCEAA0l7e.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 792
      } ],
      "display_url" : "pic.twitter.com\/4n0erVuJY6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/IDSzx9tEWk",
      "expanded_url" : "http:\/\/at.wh.gov\/nT7uS",
      "display_url" : "at.wh.gov\/nT7uS"
    } ]
  },
  "geo" : { },
  "id_str" : "367315040359026688",
  "text" : "FACT: Our deficit is down 37.6% through July\u2014and on track to be the lowest in 5 years. http:\/\/t.co\/IDSzx9tEWk, http:\/\/t.co\/4n0erVuJY6",
  "id" : 367315040359026688,
  "created_at" : "2013-08-13 16:01:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/367301180910624768\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Ez6hWGFpFc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRjqel4CYAAcoZk.jpg",
      "id_str" : "367301180914819072",
      "id" : 367301180914819072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRjqel4CYAAcoZk.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ez6hWGFpFc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367301180910624768",
  "text" : "Bo, stop trying to make fetch happen. http:\/\/t.co\/Ez6hWGFpFc",
  "id" : 367301180910624768,
  "created_at" : "2013-08-13 15:06:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367062335308828672",
  "text" : "Got questions about President Obama's agenda\u2014or about life at the WH? Ask using #WestWingWeek and we'll answer some in this week's episode.",
  "id" : 367062335308828672,
  "created_at" : "2013-08-12 23:17:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 80, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367054137763962880",
  "text" : "RT @Bobby44: Today in Ohio, Sec. Napolitano met with biz leaders to discuss how #ImmigrationReform would grow the economy \u2014&gt; http:\/\/t.co\/wI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 67, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/wI1AnbC3vP",
        "expanded_url" : "http:\/\/1.usa.gov\/1cIyvD4",
        "display_url" : "1.usa.gov\/1cIyvD4"
      } ]
    },
    "geo" : { },
    "id_str" : "367050535318208512",
    "text" : "Today in Ohio, Sec. Napolitano met with biz leaders to discuss how #ImmigrationReform would grow the economy \u2014&gt; http:\/\/t.co\/wI1AnbC3vP",
    "id" : 367050535318208512,
    "created_at" : "2013-08-12 22:30:41 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 367054137763962880,
  "created_at" : "2013-08-12 22:45:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/367028428840525824\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/fBqUwGdUld",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRfyaVPCYAAl944.jpg",
      "id_str" : "367028428844720128",
      "id" : 367028428844720128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRfyaVPCYAAl944.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/fBqUwGdUld"
    } ],
    "hashtags" : [ {
      "text" : "ScienceSaysSo",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367028428840525824",
  "text" : "RT if you agree: Climate change is one of the biggest threats we face\u2014and it's time to act. #ScienceSaysSo, http:\/\/t.co\/fBqUwGdUld",
  "id" : 367028428840525824,
  "created_at" : "2013-08-12 21:02:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABA",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367022681025028098",
  "text" : "RT @Cecilia44: AG Holder gave a very important speech today at #ABA: announced smart on crime approach to criminal justice reform http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABA",
        "indices" : [ 48, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/LyfGZ7I46a",
        "expanded_url" : "http:\/\/goo.gl\/6wUuIL",
        "display_url" : "goo.gl\/6wUuIL"
      } ]
    },
    "geo" : { },
    "id_str" : "367021714711916544",
    "text" : "AG Holder gave a very important speech today at #ABA: announced smart on crime approach to criminal justice reform http:\/\/t.co\/LyfGZ7I46a",
    "id" : 367021714711916544,
    "created_at" : "2013-08-12 20:36:10 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 367022681025028098,
  "created_at" : "2013-08-12 20:40:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 31, 39 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366999074198663168",
  "text" : "RT @ErnestMoniz: Worth a read: @nytimes editorial \u201CA Clean-Car Boom\u201D says govt support pays big dividends for economy &amp; environment. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 14, 22 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/Cvggika9vv",
        "expanded_url" : "http:\/\/nyti.ms\/11ZsPyy",
        "display_url" : "nyti.ms\/11ZsPyy"
      } ]
    },
    "geo" : { },
    "id_str" : "366992199927341057",
    "text" : "Worth a read: @nytimes editorial \u201CA Clean-Car Boom\u201D says govt support pays big dividends for economy &amp; environment. http:\/\/t.co\/Cvggika9vv",
    "id" : 366992199927341057,
    "created_at" : "2013-08-12 18:38:53 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 366999074198663168,
  "created_at" : "2013-08-12 19:06:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 73, 88 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/366986054034681856\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Ztm5CdFXYB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRfL3yyCcAA_BEy.jpg",
      "id_str" : "366986054038876160",
      "id" : 366986054038876160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRfL3yyCcAA_BEy.jpg",
      "sizes" : [ {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 632,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ztm5CdFXYB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366986054034681856",
  "text" : "This morning, President Obama received a national security briefing from @AmbassadorRice: http:\/\/t.co\/Ztm5CdFXYB",
  "id" : 366986054034681856,
  "created_at" : "2013-08-12 18:14:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Arches National Park",
      "screen_name" : "ArchesNPS",
      "indices" : [ 112, 122 ],
      "id_str" : "271060845",
      "id" : 271060845
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Perseids",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366954233230139394",
  "text" : "RT @Interior: Want to see the #Perseids meteor shower? There's no better place than America's public lands like @ArchesNPS. http:\/\/t.co\/xgx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arches National Park",
        "screen_name" : "ArchesNPS",
        "indices" : [ 98, 108 ],
        "id_str" : "271060845",
        "id" : 271060845
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/366937099900948481\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/xgx9DSR62O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRefWSbCEAAlR8S.jpg",
        "id_str" : "366937099905142784",
        "id" : 366937099905142784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRefWSbCEAAlR8S.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/xgx9DSR62O"
      } ],
      "hashtags" : [ {
        "text" : "Perseids",
        "indices" : [ 16, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "366937099900948481",
    "text" : "Want to see the #Perseids meteor shower? There's no better place than America's public lands like @ArchesNPS. http:\/\/t.co\/xgx9DSR62O",
    "id" : 366937099900948481,
    "created_at" : "2013-08-12 14:59:56 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 366954233230139394,
  "created_at" : "2013-08-12 16:08:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "366943152143204352",
  "text" : "RT @WhiteHouseCEQ: New report on benefits of preparing for climate change by protecting our electric grid from bad weather http:\/\/t.co\/eO6y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/eO6ylG0C40",
        "expanded_url" : "http:\/\/1.usa.gov\/16G1Fwy",
        "display_url" : "1.usa.gov\/16G1Fwy"
      } ]
    },
    "geo" : { },
    "id_str" : "366937933414006785",
    "text" : "New report on benefits of preparing for climate change by protecting our electric grid from bad weather http:\/\/t.co\/eO6ylG0C40 #ActOnClimate",
    "id" : 366937933414006785,
    "created_at" : "2013-08-12 15:03:15 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 366943152143204352,
  "created_at" : "2013-08-12 15:23:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/366935347185213440\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/r9iSgi98CF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRedwRDCYAECz7s.png",
      "id_str" : "366935347189407745",
      "id" : 366935347189407745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRedwRDCYAECz7s.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/r9iSgi98CF"
    } ],
    "hashtags" : [ {
      "text" : "GreatNature",
      "indices" : [ 52, 64 ]
    }, {
      "text" : "BoMG",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/amj2T3voxf",
      "expanded_url" : "http:\/\/www.GreatNatureProject.org",
      "display_url" : "GreatNatureProject.org"
    } ]
  },
  "geo" : { },
  "id_str" : "366935347185213440",
  "text" : "Hanging out in the backyard: http:\/\/t.co\/amj2T3voxf #GreatNature #BoMG, http:\/\/t.co\/r9iSgi98CF",
  "id" : 366935347185213440,
  "created_at" : "2013-08-12 14:52:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/1ZJps9BcB3",
      "expanded_url" : "http:\/\/at.wh.gov\/nO6sb",
      "display_url" : "at.wh.gov\/nO6sb"
    } ]
  },
  "geo" : { },
  "id_str" : "366280557916725248",
  "text" : "Obama: \"If we work together, we can make a home a source of pride &amp; middle-class security again.\" Weekly Address: http:\/\/t.co\/1ZJps9BcB3",
  "id" : 366280557916725248,
  "created_at" : "2013-08-10 19:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "366226297736798208",
  "text" : "Starting soon: President Obama delivers remarks at the Disabled American Veterans National Convention. Watch--&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 366226297736798208,
  "created_at" : "2013-08-10 15:55:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "366212673018396674",
  "text" : "Today at 12ET, President Obama delivers remarks at the Disabled American Veterans National Convention in FL. Watch--&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 366212673018396674,
  "created_at" : "2013-08-10 15:01:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/JzaDHci7ZB",
      "expanded_url" : "http:\/\/at.wh.gov\/nNHJB",
      "display_url" : "at.wh.gov\/nNHJB"
    } ]
  },
  "geo" : { },
  "id_str" : "366187152574390272",
  "text" : "President Obama's Weekly Address: Responsible homeowners deserve #ABetterBargain --&gt; http:\/\/t.co\/JzaDHci7ZB",
  "id" : 366187152574390272,
  "created_at" : "2013-08-10 13:19:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/u6oWpC1bHn",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hMk9Gd3AHxA&feature=c4-overview&list=UUYxRlFDqcWM4y7FfpiAN3KQ",
      "display_url" : "youtube.com\/watch?v=hMk9Gd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "366017416897118208",
  "text" : "RT @whitehouseostp: Miss today's #WeTheGeeks on Robots? Check it out here http:\/\/t.co\/u6oWpC1bHn You can find all past WTG hangouts at http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 13, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/u6oWpC1bHn",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hMk9Gd3AHxA&feature=c4-overview&list=UUYxRlFDqcWM4y7FfpiAN3KQ",
        "display_url" : "youtube.com\/watch?v=hMk9Gd\u2026"
      }, {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/vmmo6g2FF9",
        "expanded_url" : "http:\/\/wh.gov\/wethegeeks",
        "display_url" : "wh.gov\/wethegeeks"
      } ]
    },
    "geo" : { },
    "id_str" : "365984741809324032",
    "text" : "Miss today's #WeTheGeeks on Robots? Check it out here http:\/\/t.co\/u6oWpC1bHn You can find all past WTG hangouts at http:\/\/t.co\/vmmo6g2FF9",
    "id" : 365984741809324032,
    "created_at" : "2013-08-09 23:55:36 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 366017416897118208,
  "created_at" : "2013-08-10 02:05:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 54, 66 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    }, {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 73, 79 ],
      "id_str" : "19397785",
      "id" : 19397785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 146 ],
      "url" : "http:\/\/t.co\/dawEkRroud",
      "expanded_url" : "http:\/\/at.wh.gov\/nNx5o",
      "display_url" : "at.wh.gov\/nNx5o"
    } ]
  },
  "geo" : { },
  "id_str" : "365965846784376832",
  "text" : "What do baseball player Ernie Banks, former President @BillClinton &amp; @Oprah Winfrey all have in common? Find out --&gt; http:\/\/t.co\/dawEkRroud",
  "id" : 365965846784376832,
  "created_at" : "2013-08-09 22:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    }, {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 51, 58 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/xLhyKiXwIs",
      "expanded_url" : "http:\/\/youtu.be\/PmiTAT-YpRs",
      "display_url" : "youtu.be\/PmiTAT-YpRs"
    } ]
  },
  "geo" : { },
  "id_str" : "365956437207711744",
  "text" : "RT @WHVideo: Missed the President's interview with @Zillow this week?  See the highlights here --&gt; http:\/\/t.co\/xLhyKiXwIs #ABetterBargain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zillow",
        "screen_name" : "zillow",
        "indices" : [ 38, 45 ],
        "id_str" : "19262500",
        "id" : 19262500
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 112, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/xLhyKiXwIs",
        "expanded_url" : "http:\/\/youtu.be\/PmiTAT-YpRs",
        "display_url" : "youtu.be\/PmiTAT-YpRs"
      } ]
    },
    "geo" : { },
    "id_str" : "365955869877354496",
    "text" : "Missed the President's interview with @Zillow this week?  See the highlights here --&gt; http:\/\/t.co\/xLhyKiXwIs #ABetterBargain",
    "id" : 365955869877354496,
    "created_at" : "2013-08-09 22:00:53 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 365956437207711744,
  "created_at" : "2013-08-09 22:03:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/FrLJhfjIpQ",
      "expanded_url" : "http:\/\/instagram.com\/p\/cza_uzQiqc",
      "display_url" : "instagram.com\/p\/cza_uzQiqc"
    } ]
  },
  "geo" : { },
  "id_str" : "365946839255621632",
  "text" : "\"It feels good signing bills.\" \u2014Pres. Obama at today's bill signing to keep student loan interest rates low. Watch \u2014&gt; http:\/\/t.co\/FrLJhfjIpQ",
  "id" : 365946839255621632,
  "created_at" : "2013-08-09 21:25:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 37, 46 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 48, 59 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 61, 71 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "Jamie Smith",
      "screen_name" : "JSmith44",
      "indices" : [ 91, 100 ],
      "id_str" : "2821610174",
      "id" : 2821610174
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "FF",
      "indices" : [ 101, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365936076860309504",
  "text" : "#FollowFriday: WH Press Sec edition: @PressSec, @JEarnest44, @Schultz44, @Brundage44 &amp; @JSmith44 #FF",
  "id" : 365936076860309504,
  "created_at" : "2013-08-09 20:42:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 87, 97 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/lE6aHCHB5W",
      "expanded_url" : "http:\/\/at.wh.gov\/nN8FJ",
      "display_url" : "at.wh.gov\/nN8FJ"
    } ]
  },
  "geo" : { },
  "id_str" : "365926766008733698",
  "text" : "\"We can\u2019t let high borrowing costs prohibit students from accessing higher education\" \u2014@Cecilia44: http:\/\/t.co\/lE6aHCHB5W",
  "id" : 365926766008733698,
  "created_at" : "2013-08-09 20:05:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigrationreform",
      "indices" : [ 60, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365924424521756672",
  "text" : "\"Our economy would be a trillion dollars stronger if we got #immigrationreform done.\" \u2014President Obama",
  "id" : 365924424521756672,
  "created_at" : "2013-08-09 19:55:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365922757889892353",
  "text" : "\"Millions of Americans, for the first time, are going to be able to get affordable health care.\" \u2014President Obama on #Obamacare",
  "id" : 365922757889892353,
  "created_at" : "2013-08-09 19:49:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365921321667936256",
  "text" : "\"We've got to continue to be vigilant.\" \u2014President Obama on recent terror threats",
  "id" : 365921321667936256,
  "created_at" : "2013-08-09 19:43:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365917974114213888",
  "text" : "\"It's one of the most important economic decisions I'll make.\u201D \u2014President Obama on the next Chairman of the Federal Reserve",
  "id" : 365917974114213888,
  "created_at" : "2013-08-09 19:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "365913428461748224",
  "text" : "\"We can and must be more transparent.\" \u2014President Obama in his press conference. Happening now: http:\/\/t.co\/KvadYk9atb",
  "id" : 365913428461748224,
  "created_at" : "2013-08-09 19:12:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Af4GCqlUZH",
      "expanded_url" : "http:\/\/at.wh.gov\/nN8g1",
      "display_url" : "at.wh.gov\/nN8g1"
    } ]
  },
  "geo" : { },
  "id_str" : "365912034065399808",
  "text" : "Happening now: President Obama holds a press conference from the East Room of the White House. Watch: http:\/\/t.co\/Af4GCqlUZH",
  "id" : 365912034065399808,
  "created_at" : "2013-08-09 19:06:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/qWjcwkjJEW",
      "expanded_url" : "http:\/\/wh.gov\/we-the-geeks",
      "display_url" : "wh.gov\/we-the-geeks"
    } ]
  },
  "geo" : { },
  "id_str" : "365895940302831617",
  "text" : "Happening now: #WeTheGeeks Hangout to discuss the state of American robotics. Watch live: http:\/\/t.co\/qWjcwkjJEW",
  "id" : 365895940302831617,
  "created_at" : "2013-08-09 18:02:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/365863272865480704\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qVuHyPi6LX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRPOtU_CQAECTxH.jpg",
      "id_str" : "365863272869675009",
      "id" : 365863272869675009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRPOtU_CQAECTxH.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/qVuHyPi6LX"
    } ],
    "hashtags" : [ {
      "text" : "WetheGeeks",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/qWjcwkjJEW",
      "expanded_url" : "http:\/\/wh.gov\/we-the-geeks",
      "display_url" : "wh.gov\/we-the-geeks"
    } ]
  },
  "geo" : { },
  "id_str" : "365863272865480704",
  "text" : "Tune in today at 2:00 p.m. ET for a special #WetheGeeks Google+ Hangout on robots --&gt; http:\/\/t.co\/qWjcwkjJEW http:\/\/t.co\/qVuHyPi6LX",
  "id" : 365863272865480704,
  "created_at" : "2013-08-09 15:52:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not John Green",
      "screen_name" : "realjohngreen",
      "indices" : [ 3, 17 ],
      "id_str" : "2796445679",
      "id" : 2796445679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365853251347812355",
  "text" : "RT @realjohngreen: At 2 pm today, I'll be part of a White House hangout on robots and education. Tweet me questions! You can watch at http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/t8BOhu06TN",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/wethegeeks",
        "display_url" : "whitehouse.gov\/wethegeeks"
      } ]
    },
    "geo" : { },
    "id_str" : "365852309357461505",
    "text" : "At 2 pm today, I'll be part of a White House hangout on robots and education. Tweet me questions! You can watch at http:\/\/t.co\/t8BOhu06TN",
    "id" : 365852309357461505,
    "created_at" : "2013-08-09 15:09:22 +0000",
    "user" : {
      "name" : "John Green",
      "screen_name" : "johngreen",
      "protected" : false,
      "id_str" : "18055737",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000665706398\/7c29cea2c338c6f5b45d7bcb0af0b79c_normal.png",
      "id" : 18055737,
      "verified" : true
    }
  },
  "id" : 365853251347812355,
  "created_at" : "2013-08-09 15:13:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/e1g6zZXF8x",
      "expanded_url" : "http:\/\/at.wh.gov\/nMx50",
      "display_url" : "at.wh.gov\/nMx50"
    } ]
  },
  "geo" : { },
  "id_str" : "365846295132377090",
  "text" : "At 3pm ET, President Obama will hold a press conference from the East Room. Watch live: http:\/\/t.co\/e1g6zZXF8x",
  "id" : 365846295132377090,
  "created_at" : "2013-08-09 14:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Leno",
      "screen_name" : "jayleno",
      "indices" : [ 48, 56 ],
      "id_str" : "35859588",
      "id" : 35859588
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/365623035736236032\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ckFZULpted",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRL0Nr9CIAAuSfG.jpg",
      "id_str" : "365623035744624640",
      "id" : 365623035744624640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRL0Nr9CIAAuSfG.jpg",
      "sizes" : [ {
        "h" : 391,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 668,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ckFZULpted"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Tzp2vDKxtQ",
      "expanded_url" : "http:\/\/at.wh.gov\/nLt9b",
      "display_url" : "at.wh.gov\/nLt9b"
    } ]
  },
  "geo" : { },
  "id_str" : "365623035736236032",
  "text" : "ICYMI: This week, President Obama sat down with @JayLeno for a taping of \"The Tonight Show.\" http:\/\/t.co\/Tzp2vDKxtQ, http:\/\/t.co\/ckFZULpted",
  "id" : 365623035736236032,
  "created_at" : "2013-08-08 23:58:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 17, 24 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/78uJQGA0jC",
      "expanded_url" : "http:\/\/at.wh.gov\/nL7p0",
      "display_url" : "at.wh.gov\/nL7p0"
    } ]
  },
  "geo" : { },
  "id_str" : "365561794443481088",
  "text" : "Worth a retweet: @SBAgov\u2019s Karen Mills explains how immigrant entrepreneurs are helping to grow our economy --&gt; http:\/\/t.co\/78uJQGA0jC",
  "id" : 365561794443481088,
  "created_at" : "2013-08-08 19:54:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/wMunt9iNpw",
      "expanded_url" : "http:\/\/at.wh.gov\/nKVmU",
      "display_url" : "at.wh.gov\/nKVmU"
    } ]
  },
  "geo" : { },
  "id_str" : "365538668699590656",
  "text" : "Join us tomorrow for a #WeTheGeeks Hangout to help us keep an eye on the ROBOTS! Submit your questions now --&gt; http:\/\/t.co\/wMunt9iNpw",
  "id" : 365538668699590656,
  "created_at" : "2013-08-08 18:23:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365516810629554176",
  "text" : "RT @Simas44: This clip tells it all. No more abstract debates about the ACA  Repeal takes away coverage from millions who need it. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/pkW73nCvSb",
        "expanded_url" : "http:\/\/bit.ly\/14ouoqu",
        "display_url" : "bit.ly\/14ouoqu"
      } ]
    },
    "geo" : { },
    "id_str" : "365510291724828674",
    "text" : "This clip tells it all. No more abstract debates about the ACA  Repeal takes away coverage from millions who need it. http:\/\/t.co\/pkW73nCvSb",
    "id" : 365510291724828674,
    "created_at" : "2013-08-08 16:30:19 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 365516810629554176,
  "created_at" : "2013-08-08 16:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "windenergy",
      "indices" : [ 71, 82 ]
    }, {
      "text" : "askenergy",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/MopacWE8kz",
      "expanded_url" : "http:\/\/go.usa.gov\/jEX9",
      "display_url" : "go.usa.gov\/jEX9"
    } ]
  },
  "geo" : { },
  "id_str" : "365500764493332480",
  "text" : "MT @Energy: YOU'RE INVITED: Today at 3pm we\u2019re hosting a G+ Hangout on #windenergy. Join in: http:\/\/t.co\/MopacWE8kz #askenergy",
  "id" : 365500764493332480,
  "created_at" : "2013-08-08 15:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365497682560688128",
  "text" : "RT @pfeiffer44: August Recess is giving momentum to Immigration Reform,the passion is on the side of the advocates this time\nhttp:\/\/t.co\/vE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC News",
        "screen_name" : "ABC",
        "indices" : [ 136, 140 ],
        "id_str" : "28785486",
        "id" : 28785486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/vEo0FM3jRN",
        "expanded_url" : "http:\/\/abcnews.go.com\/blogs\/politics\/2013\/08\/republicans-may-be-changing-minds-on-immigration-reform\/#.UgOErbi_e0w.twitter",
        "display_url" : "abcnews.go.com\/blogs\/politics\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "365438909548724224",
    "text" : "August Recess is giving momentum to Immigration Reform,the passion is on the side of the advocates this time\nhttp:\/\/t.co\/vEo0FM3jRN via @abc",
    "id" : 365438909548724224,
    "created_at" : "2013-08-08 11:46:40 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 365497682560688128,
  "created_at" : "2013-08-08 15:40:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/K7fk0R2Hek",
      "expanded_url" : "http:\/\/at.wh.gov\/nKn7z",
      "display_url" : "at.wh.gov\/nKn7z"
    } ]
  },
  "geo" : { },
  "id_str" : "365481492668891137",
  "text" : "\"Warmest greetings to Muslims celebrating Eid al-Fitr here in the United States &amp; around the world\" \u2014President Obama: http:\/\/t.co\/K7fk0R2Hek",
  "id" : 365481492668891137,
  "created_at" : "2013-08-08 14:35:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 146 ],
      "url" : "http:\/\/t.co\/mWpwrLh4yz",
      "expanded_url" : "http:\/\/youtu.be\/L-XbETvNBv0",
      "display_url" : "youtu.be\/L-XbETvNBv0"
    } ]
  },
  "geo" : { },
  "id_str" : "365258029832216577",
  "text" : "\u201CHomeownership is the quintessential element of the American dream.\u201D \u2014Obama during a Q&amp;A on housing today. Watch --&gt; http:\/\/t.co\/mWpwrLh4yz",
  "id" : 365258029832216577,
  "created_at" : "2013-08-07 23:47:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/mWpwrLh4yz",
      "expanded_url" : "http:\/\/youtu.be\/L-XbETvNBv0",
      "display_url" : "youtu.be\/L-XbETvNBv0"
    } ]
  },
  "geo" : { },
  "id_str" : "365236917240999937",
  "text" : "Watch the President answer questions on his plan to help responsible homeowners, then RT so your friends can, too \u2014&gt; http:\/\/t.co\/mWpwrLh4yz",
  "id" : 365236917240999937,
  "created_at" : "2013-08-07 22:24:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "365179433776185344",
  "text" : "Today at 3:50ET, President Obama speaks from Marine Corps Base Camp Pendleton. Watch live \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 365179433776185344,
  "created_at" : "2013-08-07 18:35:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 3, 10 ],
      "id_str" : "19262500",
      "id" : 19262500
    }, {
      "name" : "Spencer Rascoff",
      "screen_name" : "spencerrascoff",
      "indices" : [ 68, 83 ],
      "id_str" : "19046875",
      "id" : 19046875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/l1wWZHnDCV",
      "expanded_url" : "http:\/\/zlw.re\/6011ZxxR",
      "display_url" : "zlw.re\/6011ZxxR"
    } ]
  },
  "geo" : { },
  "id_str" : "365152467153338368",
  "text" : "RT @zillow: RT if you'll be watching President Obama &amp; Zillow\u2019s @SpencerRascoff discuss housing at 10 am PT! http:\/\/t.co\/l1wWZHnDCV #AskOba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Spencer Rascoff",
        "screen_name" : "spencerrascoff",
        "indices" : [ 56, 71 ],
        "id_str" : "19046875",
        "id" : 19046875
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskObamaHousing",
        "indices" : [ 124, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/l1wWZHnDCV",
        "expanded_url" : "http:\/\/zlw.re\/6011ZxxR",
        "display_url" : "zlw.re\/6011ZxxR"
      } ]
    },
    "geo" : { },
    "id_str" : "365141543671177216",
    "text" : "RT if you'll be watching President Obama &amp; Zillow\u2019s @SpencerRascoff discuss housing at 10 am PT! http:\/\/t.co\/l1wWZHnDCV #AskObamaHousing",
    "id" : 365141543671177216,
    "created_at" : "2013-08-07 16:05:02 +0000",
    "user" : {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "protected" : false,
      "id_str" : "19262500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732338824936751104\/vJX0_tQy_normal.jpg",
      "id" : 19262500,
      "verified" : true
    }
  },
  "id" : 365152467153338368,
  "created_at" : "2013-08-07 16:48:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObamaHousing",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 146 ],
      "url" : "http:\/\/t.co\/yBbHL80leY",
      "expanded_url" : "http:\/\/wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "365148858809987072",
  "text" : "Tune in at 1ET: President Obama will be answering your housing questions. \n\nAsk w\/ #AskObamaHousing &amp; watch live --&gt; http:\/\/t.co\/yBbHL80leY",
  "id" : 365148858809987072,
  "created_at" : "2013-08-07 16:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/365123994749399040\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/anCyHYnaXT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BREuVraCcAA7HKp.jpg",
      "id_str" : "365123994757787648",
      "id" : 365123994757787648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BREuVraCcAA7HKp.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/anCyHYnaXT"
    } ],
    "hashtags" : [ {
      "text" : "AskObamaHousing",
      "indices" : [ 97, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "365123994749399040",
  "text" : "Yesterday, POTUS laid out his plan to help homeowners. Today at 1ET, he's answering your Qs. Use #AskObamaHousing --&gt; http:\/\/t.co\/anCyHYnaXT",
  "id" : 365123994749399040,
  "created_at" : "2013-08-07 14:55:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 3, 10 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObamaHousing",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/PlVJ2Hfmk8",
      "expanded_url" : "http:\/\/zlw.re\/6010Zx6k",
      "display_url" : "zlw.re\/6010Zx6k"
    } ]
  },
  "geo" : { },
  "id_str" : "365113226369196032",
  "text" : "RT @zillow: Hurry! Time is running out to ask your #AskObamaHousing questions to President Obama! http:\/\/t.co\/PlVJ2Hfmk8 http:\/\/t.co\/50sMsw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zillow\/status\/364921848540057600\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/50sMswF0vE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRB2fOGCUAAgQs6.jpg",
        "id_str" : "364921848548446208",
        "id" : 364921848548446208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRB2fOGCUAAgQs6.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/50sMswF0vE"
      } ],
      "hashtags" : [ {
        "text" : "AskObamaHousing",
        "indices" : [ 39, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/PlVJ2Hfmk8",
        "expanded_url" : "http:\/\/zlw.re\/6010Zx6k",
        "display_url" : "zlw.re\/6010Zx6k"
      } ]
    },
    "geo" : { },
    "id_str" : "364921848540057600",
    "text" : "Hurry! Time is running out to ask your #AskObamaHousing questions to President Obama! http:\/\/t.co\/PlVJ2Hfmk8 http:\/\/t.co\/50sMswF0vE",
    "id" : 364921848540057600,
    "created_at" : "2013-08-07 01:32:03 +0000",
    "user" : {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "protected" : false,
      "id_str" : "19262500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732338824936751104\/vJX0_tQy_normal.jpg",
      "id" : 19262500,
      "verified" : true
    }
  },
  "id" : 365113226369196032,
  "created_at" : "2013-08-07 14:12:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/aH3bOJSGZO",
      "expanded_url" : "http:\/\/at.wh.gov\/nH1zD",
      "display_url" : "at.wh.gov\/nH1zD"
    } ]
  },
  "geo" : { },
  "id_str" : "364912675110666240",
  "text" : "\"A home is the ultimate evidence that in here America, hard work pays off, that responsibility is rewarded.\" \u2014Obama: http:\/\/t.co\/aH3bOJSGZO",
  "id" : 364912675110666240,
  "created_at" : "2013-08-07 00:55:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364895191460610048",
  "text" : "FACT: Under President Obama's plan responsible families could save $3,000 a year by refinancing at today's low mortgage rates.",
  "id" : 364895191460610048,
  "created_at" : "2013-08-06 23:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/364878771137945600\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/GXUx08eddj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRBPTyRCIAAd3uZ.jpg",
      "id_str" : "364878771146334208",
      "id" : 364878771146334208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRBPTyRCIAAd3uZ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/GXUx08eddj"
    } ],
    "hashtags" : [ {
      "text" : "AskObamaHousing",
      "indices" : [ 98, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364878771137945600",
  "text" : "Today, the President laid out his plan to help homeowners. Tomorrow, he'll answer your Qs. Ask w\/ #AskObamaHousing -&gt; http:\/\/t.co\/GXUx08eddj",
  "id" : 364878771137945600,
  "created_at" : "2013-08-06 22:40:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 33, 43 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 80, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/B3jmZ5oygp",
      "expanded_url" : "http:\/\/instagram.com\/p\/crv4vewitO\/",
      "display_url" : "instagram.com\/p\/crv4vewitO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "364849354793693184",
  "text" : "President Obama recorded a quick @Instagram video message before speaking about #ABetterBargain in Phoenix. Watch --&gt; http:\/\/t.co\/B3jmZ5oygp",
  "id" : 364849354793693184,
  "created_at" : "2013-08-06 20:43:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364845531337457665",
  "text" : "President Obama: \"If we take a few bold steps...our economy will grow stronger a year from now. Five years from now and 10 years from now.\"",
  "id" : 364845531337457665,
  "created_at" : "2013-08-06 20:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364845071180369922",
  "text" : "President Obama: \"If we take the steps I talked about today, then I know we will restore not just our home values, but our common values.\"",
  "id" : 364845071180369922,
  "created_at" : "2013-08-06 20:26:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 9, 14 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364844705135067138",
  "text" : "Obama on @CFPB: \"They\u2019re designing a new, simple mortgage form in plain English, so you'll be able to read it...you can know before you owe\"",
  "id" : 364844705135067138,
  "created_at" : "2013-08-06 20:25:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364844419804971009",
  "text" : "President Obama: \"We have to keep going, because nobody in America, and certainly no veteran, should be left to live on the street.\"",
  "id" : 364844419804971009,
  "created_at" : "2013-08-06 20:24:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364844081052000256",
  "text" : "\"We have to keep housing affordable for first-time homebuyers and families working to climb into the middle class.\" \u2014President Obama",
  "id" : 364844081052000256,
  "created_at" : "2013-08-06 20:23:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364843935190888448",
  "text" : "President Obama: \"Third, we should preserve access to safe &amp; simple mortgage products like the 30-year, fixed-rate mortgage\" #ABetterBargain",
  "id" : 364843935190888448,
  "created_at" : "2013-08-06 20:22:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364842860786360320",
  "text" : "Obama: \"Step 5: we should make sure families that don\u2019t want to buy a home, or can\u2019t yet afford to buy one, have a decent place to rent.\"",
  "id" : 364842860786360320,
  "created_at" : "2013-08-06 20:18:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364842802531680256",
  "text" : "President Obama: \"Step four: we should address the uneven recovery by rebuilding the communities hit hardest by the housing crisis.\"",
  "id" : 364842802531680256,
  "created_at" : "2013-08-06 20:17:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364842272682016769",
  "text" : "Obama: \"Step 3 is something you don\u2019t always hear about when it comes to the housing market \u2013 that\u2019s fixing a broken immigration system.\"",
  "id" : 364842272682016769,
  "created_at" : "2013-08-06 20:15:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364841625987461120",
  "text" : "\"We have to build a housing system that\u2019s durable and fair and rewards responsibility for generations to come.\" -Pres. Obama #ABetterBargain",
  "id" : 364841625987461120,
  "created_at" : "2013-08-06 20:13:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364841494986764289",
  "text" : "\"We need to give to more hard-working Americans the chance to buy their first home.\" \u2014President Obama #ABetterBargain",
  "id" : 364841494986764289,
  "created_at" : "2013-08-06 20:12:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/364536447962869760\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/AODfZc56cb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ8X99ECcAA4BCV.jpg",
      "id_str" : "364536447971258368",
      "id" : 364536447971258368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ8X99ECcAA4BCV.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/AODfZc56cb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364841038663266306",
  "text" : "\"Our housing market is healing. Home prices are rising at the fastest pace in 7 years.\" \u2014Obama: http:\/\/t.co\/AODfZc56cb",
  "id" : 364841038663266306,
  "created_at" : "2013-08-06 20:10:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364840344476581891",
  "text" : "Obama: \"When the housing bubble burst...millions of Americans who had done everything right were hurt badly by the actions of others.\"",
  "id" : 364840344476581891,
  "created_at" : "2013-08-06 20:08:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364840069846155264",
  "text" : "President Obama: \"To generations of Americans...a home was more than just a house. It was a source of pride &amp; security.\" #ABetterBargain",
  "id" : 364840069846155264,
  "created_at" : "2013-08-06 20:07:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 120, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364839952112029696",
  "text" : "President Obama: \"A home is the ultimate evidence that in America, hard work pays off, and responsibility is rewarded.\" #ABetterBargain",
  "id" : 364839952112029696,
  "created_at" : "2013-08-06 20:06:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364839563404914692",
  "text" : "President Obama: \"I\u2019m laying out my ideas for how we must build on the cornerstones of what it means to be middle class.\" #ABetterBargain",
  "id" : 364839563404914692,
  "created_at" : "2013-08-06 20:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364839244042207232",
  "text" : "President Obama: \"But as any middle-class family will tell you, we\u2019re not yet where we need to be.\" #ABetterBargain",
  "id" : 364839244042207232,
  "created_at" : "2013-08-06 20:03:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/363304220759298049\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/oVUjXdzuAp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQq3Q5BCEAAQgwR.jpg",
      "id_str" : "363304220767686656",
      "id" : 363304220767686656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQq3Q5BCEAAQgwR.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/oVUjXdzuAp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364839025326039040",
  "text" : "\u201COur businesses have created 7.3 million new jobs over the last 41 months.\u201D \u2013President Obama: http:\/\/t.co\/oVUjXdzuAp",
  "id" : 364839025326039040,
  "created_at" : "2013-08-06 20:02:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364838692508016640",
  "text" : "Obama: \"I\u2019ve been visiting towns like this talking about what we need to do as a country to secure #ABetterBargain for the middle class.\"",
  "id" : 364838692508016640,
  "created_at" : "2013-08-06 20:01:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 70, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/SHA9Na26QC",
      "expanded_url" : "http:\/\/at.wh.gov\/nGric",
      "display_url" : "at.wh.gov\/nGric"
    } ]
  },
  "geo" : { },
  "id_str" : "364838021096411137",
  "text" : "Happening now: President Obama speaks from AZ on his plan that offers #ABetterBargain for responsible homeowners: http:\/\/t.co\/SHA9Na26QC",
  "id" : 364838021096411137,
  "created_at" : "2013-08-06 19:58:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364823971486642176",
  "text" : "In Phoenix speaking on the most tangible cornerstone of middle-class life: owning a home. Responsible homeowners deserve #ABetterBargain -bo",
  "id" : 364823971486642176,
  "created_at" : "2013-08-06 19:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 3, 10 ],
      "id_str" : "19262500",
      "id" : 19262500
    }, {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 99, 106 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObamaHousing",
      "indices" : [ 111, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364776138100719616",
  "text" : "RT @zillow: Want to ask President Obama a question about housing? Today you can! Send questions to @Zillow via #AskObamaHousing http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zillow",
        "screen_name" : "zillow",
        "indices" : [ 87, 94 ],
        "id_str" : "19262500",
        "id" : 19262500
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskObamaHousing",
        "indices" : [ 99, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/BRxqCGZ8Ec",
        "expanded_url" : "http:\/\/zlw.re\/6016Zv8i",
        "display_url" : "zlw.re\/6016Zv8i"
      } ]
    },
    "geo" : { },
    "id_str" : "364475928564748288",
    "text" : "Want to ask President Obama a question about housing? Today you can! Send questions to @Zillow via #AskObamaHousing http:\/\/t.co\/BRxqCGZ8Ec",
    "id" : 364475928564748288,
    "created_at" : "2013-08-05 20:00:07 +0000",
    "user" : {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "protected" : false,
      "id_str" : "19262500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732338824936751104\/vJX0_tQy_normal.jpg",
      "id" : 19262500,
      "verified" : true
    }
  },
  "id" : 364776138100719616,
  "created_at" : "2013-08-06 15:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 42, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/idvz6akhrA",
      "expanded_url" : "http:\/\/at.wh.gov\/nFKAW",
      "display_url" : "at.wh.gov\/nFKAW"
    } ]
  },
  "geo" : { },
  "id_str" : "364768933897056256",
  "text" : "RT @Simas44: Obama has a plan that offers #ABetterBargain for responsible homeowners. Watch @ 4ET: http:\/\/t.co\/idvz6akhrA Plan: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/364737873867587584\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Tfl9jjBJmF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ_PKfBCQAIA6qH.jpg",
        "id_str" : "364737873871781890",
        "id" : 364737873871781890,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ_PKfBCQAIA6qH.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/Tfl9jjBJmF"
      } ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 29, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/idvz6akhrA",
        "expanded_url" : "http:\/\/at.wh.gov\/nFKAW",
        "display_url" : "at.wh.gov\/nFKAW"
      } ]
    },
    "geo" : { },
    "id_str" : "364745604028575746",
    "text" : "Obama has a plan that offers #ABetterBargain for responsible homeowners. Watch @ 4ET: http:\/\/t.co\/idvz6akhrA Plan: http:\/\/t.co\/Tfl9jjBJmF",
    "id" : 364745604028575746,
    "created_at" : "2013-08-06 13:51:43 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 364768933897056256,
  "created_at" : "2013-08-06 15:24:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QtSHWfCikK",
      "expanded_url" : "http:\/\/at.wh.gov\/nFKAW",
      "display_url" : "at.wh.gov\/nFKAW"
    } ]
  },
  "geo" : { },
  "id_str" : "364764025399152640",
  "text" : "Today, POTUS travels to AZ to lay out his plan to restore security to middle class homeownership. Watch live at 4ET: http:\/\/t.co\/QtSHWfCikK",
  "id" : 364764025399152640,
  "created_at" : "2013-08-06 15:04:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/364737873867587584\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zAFqlgqtwl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ_PKfBCQAIA6qH.jpg",
      "id_str" : "364737873871781890",
      "id" : 364737873871781890,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ_PKfBCQAIA6qH.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/zAFqlgqtwl"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 62, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364737873867587584",
  "text" : "RT to spread the word: President Obama has a plan that offers #ABetterBargain for responsible homeowners \u2014&gt; http:\/\/t.co\/zAFqlgqtwl",
  "id" : 364737873867587584,
  "created_at" : "2013-08-06 13:21:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/364536447962869760\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/AODfZc56cb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ8X99ECcAA4BCV.jpg",
      "id_str" : "364536447971258368",
      "id" : 364536447971258368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ8X99ECcAA4BCV.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/AODfZc56cb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/l2C7h7emn0",
      "expanded_url" : "http:\/\/at.wh.gov\/nEOY9",
      "display_url" : "at.wh.gov\/nEOY9"
    } ]
  },
  "geo" : { },
  "id_str" : "364536447962869760",
  "text" : "RT if you agree: The housing market is coming back, but there\u2019s still more to do --&gt; http:\/\/t.co\/l2C7h7emn0, http:\/\/t.co\/AODfZc56cb",
  "id" : 364536447962869760,
  "created_at" : "2013-08-06 00:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/364517069502423040\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/PcKv0EzevS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ8GV-rCIAAg9kM.jpg",
      "id_str" : "364517069510811648",
      "id" : 364517069510811648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ8GV-rCIAAg9kM.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/PcKv0EzevS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/ikzoMYYr2M",
      "expanded_url" : "http:\/\/at.wh.gov\/nEK4h",
      "display_url" : "at.wh.gov\/nEK4h"
    } ]
  },
  "geo" : { },
  "id_str" : "364517069502423040",
  "text" : "Home prices are rising at the fastest pace in 7 years, but there's still more work to do --&gt; http:\/\/t.co\/ikzoMYYr2M, http:\/\/t.co\/PcKv0EzevS",
  "id" : 364517069502423040,
  "created_at" : "2013-08-05 22:43:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/24vXvMQZkL",
      "expanded_url" : "http:\/\/youtu.be\/o87SEVbnbeg",
      "display_url" : "youtu.be\/o87SEVbnbeg"
    } ]
  },
  "geo" : { },
  "id_str" : "364448413750145024",
  "text" : "President Obama has a plan to build a better foundation for middle class homeownership. Preview tomorrow's speech --&gt; http:\/\/t.co\/24vXvMQZkL",
  "id" : 364448413750145024,
  "created_at" : "2013-08-05 18:10:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 3, 9 ],
      "id_str" : "19380829",
      "id" : 19380829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/D8nihHwOjW",
      "expanded_url" : "http:\/\/yhoo.it\/1c3affq",
      "display_url" : "yhoo.it\/1c3affq"
    } ]
  },
  "geo" : { },
  "id_str" : "364410466497724416",
  "text" : "RT @Yahoo: Obama taking housing questions in Zillow roundtable, to be livestreamed on Yahoo! at 1 pm ET on Wed: http:\/\/t.co\/D8nihHwOjW #Ask\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskObamaHousing",
        "indices" : [ 124, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/D8nihHwOjW",
        "expanded_url" : "http:\/\/yhoo.it\/1c3affq",
        "display_url" : "yhoo.it\/1c3affq"
      } ]
    },
    "geo" : { },
    "id_str" : "364399300400263168",
    "text" : "Obama taking housing questions in Zillow roundtable, to be livestreamed on Yahoo! at 1 pm ET on Wed: http:\/\/t.co\/D8nihHwOjW #AskObamaHousing",
    "id" : 364399300400263168,
    "created_at" : "2013-08-05 14:55:38 +0000",
    "user" : {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "protected" : false,
      "id_str" : "19380829",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747326716746444800\/IRfRHRaE_normal.jpg",
      "id" : 19380829,
      "verified" : true
    }
  },
  "id" : 364410466497724416,
  "created_at" : "2013-08-05 15:40:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObamaHousing",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/aGqi5cctIp",
      "expanded_url" : "http:\/\/at.wh.gov\/nDJYl",
      "display_url" : "at.wh.gov\/nDJYl"
    } ]
  },
  "geo" : { },
  "id_str" : "364403010115338242",
  "text" : "Tomorrow in Phoenix, POTUS will lay out his plan to help homeowners. On Wed. he'll answer your ?s: http:\/\/t.co\/aGqi5cctIp #AskObamaHousing",
  "id" : 364403010115338242,
  "created_at" : "2013-08-05 15:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 22, 38 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364391296137707520",
  "text" : "RT @rhodes44: Welcome @AmbassadorPower to twitter and to the UN - a fresh, powerful and always interesting voice for American values",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Samantha Power",
        "screen_name" : "AmbassadorPower",
        "indices" : [ 8, 24 ],
        "id_str" : "1615463502",
        "id" : 1615463502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364351197748015104",
    "text" : "Welcome @AmbassadorPower to twitter and to the UN - a fresh, powerful and always interesting voice for American values",
    "id" : 364351197748015104,
    "created_at" : "2013-08-05 11:44:29 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 364391296137707520,
  "created_at" : "2013-08-05 14:23:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364388212212781056",
  "text" : "RT @AmbassadorPower: Honored to sit behind the sign that says \"United States\" and stand up for American values and interests at the UN.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364340256167825408",
    "text" : "Honored to sit behind the sign that says \"United States\" and stand up for American values and interests at the UN.",
    "id" : 364340256167825408,
    "created_at" : "2013-08-05 11:01:00 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 364388212212781056,
  "created_at" : "2013-08-05 14:11:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/364068862662152192\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/xxYTA9cMK7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ1us6ECEAA1UEg.jpg",
      "id_str" : "364068862666346496",
      "id" : 364068862666346496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ1us6ECEAA1UEg.jpg",
      "sizes" : [ {
        "h" : 457,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 465
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xxYTA9cMK7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364139942496043008",
  "text" : "RT @FLOTUS: Happy birthday, Barack! Your hair's a little grayer, but I love you more than ever. \n\u2013mo http:\/\/t.co\/xxYTA9cMK7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/364068862662152192\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/xxYTA9cMK7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ1us6ECEAA1UEg.jpg",
        "id_str" : "364068862666346496",
        "id" : 364068862666346496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ1us6ECEAA1UEg.jpg",
        "sizes" : [ {
          "h" : 457,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 465
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xxYTA9cMK7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "364068862662152192",
    "text" : "Happy birthday, Barack! Your hair's a little grayer, but I love you more than ever. \n\u2013mo http:\/\/t.co\/xxYTA9cMK7",
    "id" : 364068862662152192,
    "created_at" : "2013-08-04 17:02:35 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 364139942496043008,
  "created_at" : "2013-08-04 21:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/364063037751189504\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/9POsvcXWPs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQ1pZ2lCYAADzEf.jpg",
      "id_str" : "364063037755383808",
      "id" : 364063037755383808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQ1pZ2lCYAADzEf.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 663,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 869
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 869
      } ],
      "display_url" : "pic.twitter.com\/9POsvcXWPs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "364063037751189504",
  "text" : "Happy birthday, President Obama! http:\/\/t.co\/9POsvcXWPs",
  "id" : 364063037751189504,
  "created_at" : "2013-08-04 16:39:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/tlAuXk2CjA",
      "expanded_url" : "http:\/\/nyti.ms\/17pBh8W",
      "display_url" : "nyti.ms\/17pBh8W"
    } ]
  },
  "geo" : { },
  "id_str" : "363707354606354433",
  "text" : "RT @Simas44: On ACA, CO getting people info they need http:\/\/t.co\/tlAuXk2CjA  while MO plays politics &amp; refuses to help people. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/tlAuXk2CjA",
        "expanded_url" : "http:\/\/nyti.ms\/17pBh8W",
        "display_url" : "nyti.ms\/17pBh8W"
      }, {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/WM1K6buCwA",
        "expanded_url" : "http:\/\/nyti.ms\/17pAF2W",
        "display_url" : "nyti.ms\/17pAF2W"
      } ]
    },
    "geo" : { },
    "id_str" : "363706472338698240",
    "text" : "On ACA, CO getting people info they need http:\/\/t.co\/tlAuXk2CjA  while MO plays politics &amp; refuses to help people. http:\/\/t.co\/WM1K6buCwA",
    "id" : 363706472338698240,
    "created_at" : "2013-08-03 17:02:35 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 363707354606354433,
  "created_at" : "2013-08-03 17:06:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/363695897344888832\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KTHAfkN93h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQwbfeACUAAedqo.jpg",
      "id_str" : "363695897353277440",
      "id" : 363695897353277440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQwbfeACUAAedqo.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/KTHAfkN93h"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 34, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/5pbbXoEsoB",
      "expanded_url" : "http:\/\/at.wh.gov\/nAIxv",
      "display_url" : "at.wh.gov\/nAIxv"
    } ]
  },
  "geo" : { },
  "id_str" : "363695897344888832",
  "text" : "President Obama's Weekly Address: #ABetterBargain for the middle class \u2014&gt; http:\/\/t.co\/5pbbXoEsoB, http:\/\/t.co\/KTHAfkN93h",
  "id" : 363695897344888832,
  "created_at" : "2013-08-03 16:20:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/363434179393880066\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/eSZPTfrt37",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQstdeqCAAEDdm1.jpg",
      "id_str" : "363434179402268673",
      "id" : 363434179402268673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQstdeqCAAEDdm1.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eSZPTfrt37"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363434179393880066",
  "text" : "Happy Friday! http:\/\/t.co\/eSZPTfrt37",
  "id" : 363434179393880066,
  "created_at" : "2013-08-02 23:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363425725216329728",
  "text" : "RT @HealthCareTara: Another day another ACA repeal vote -  - 1 pic shows all you need to know about what repeal looks like: http:\/\/t.co\/If2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/363376234488545281\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/If2b2x67R4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQr4wpECQAANhx6.jpg",
        "id_str" : "363376234496933888",
        "id" : 363376234496933888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQr4wpECQAANhx6.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/If2b2x67R4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363377330434998274",
    "text" : "Another day another ACA repeal vote -  - 1 pic shows all you need to know about what repeal looks like: http:\/\/t.co\/If2b2x67R4",
    "id" : 363377330434998274,
    "created_at" : "2013-08-02 19:14:41 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 363425725216329728,
  "created_at" : "2013-08-02 22:26:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/363376234488545281\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WGM7noHmZM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQr4wpECQAANhx6.jpg",
      "id_str" : "363376234496933888",
      "id" : 363376234496933888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQr4wpECQAANhx6.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/WGM7noHmZM"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363385174379081729",
  "text" : "FACT: Repealing #Obamacare could force individuals &amp; families to pay $1,000 to $8,000 more for health insurance: http:\/\/t.co\/WGM7noHmZM",
  "id" : 363385174379081729,
  "created_at" : "2013-08-02 19:45:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/363376234488545281\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/WGM7noHmZM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQr4wpECQAANhx6.jpg",
      "id_str" : "363376234496933888",
      "id" : 363376234496933888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQr4wpECQAANhx6.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/WGM7noHmZM"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363376234488545281",
  "text" : "RT to spread the word: Repealing #Obamacare could force millions of Americans to pay higher insurance premiums. http:\/\/t.co\/WGM7noHmZM",
  "id" : 363376234488545281,
  "created_at" : "2013-08-02 19:10:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "BLM Idaho",
      "screen_name" : "BLMIdaho",
      "indices" : [ 108, 117 ],
      "id_str" : "1444322420",
      "id" : 1444322420
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/363327931042369536\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/TbMez0FKUP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQrM1AtCEAEl0VY.jpg",
      "id_str" : "363327931050758145",
      "id" : 363327931050758145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQrM1AtCEAEl0VY.jpg",
      "sizes" : [ {
        "h" : 834,
        "resize" : "fit",
        "w" : 834
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 834,
        "resize" : "fit",
        "w" : 834
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TbMez0FKUP"
    } ],
    "hashtags" : [ {
      "text" : "Idaho",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363347614999117824",
  "text" : "RT @Interior: If you haven't been to #Idaho, you really need to visit the Snake River. Beauty beyond words. @BLMIdaho http:\/\/t.co\/TbMez0FKUP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BLM Idaho",
        "screen_name" : "BLMIdaho",
        "indices" : [ 94, 103 ],
        "id_str" : "1444322420",
        "id" : 1444322420
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/363327931042369536\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/TbMez0FKUP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQrM1AtCEAEl0VY.jpg",
        "id_str" : "363327931050758145",
        "id" : 363327931050758145,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQrM1AtCEAEl0VY.jpg",
        "sizes" : [ {
          "h" : 834,
          "resize" : "fit",
          "w" : 834
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 834,
          "resize" : "fit",
          "w" : 834
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TbMez0FKUP"
      } ],
      "hashtags" : [ {
        "text" : "Idaho",
        "indices" : [ 23, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363327931042369536",
    "text" : "If you haven't been to #Idaho, you really need to visit the Snake River. Beauty beyond words. @BLMIdaho http:\/\/t.co\/TbMez0FKUP",
    "id" : 363327931042369536,
    "created_at" : "2013-08-02 15:58:23 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 363347614999117824,
  "created_at" : "2013-08-02 17:16:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 90, 101 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/HHxvumEqNb",
      "expanded_url" : "http:\/\/www.ustr.gov\/US-Wins-Trade-Enforcement-Case-AmericanFarmers-Proves-Export-Blocking-Chinese-Duties-Unjustified-Under-WTO-Rule",
      "display_url" : "ustr.gov\/US-Wins-Trade-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363340826815893506",
  "text" : "RT @Brundage44: US wins major WTO case against China - big win for American farmers - via @USTradeRep here: http:\/\/t.co\/HHxvumEqNb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USTR",
        "screen_name" : "USTradeRep",
        "indices" : [ 74, 85 ],
        "id_str" : "44615672",
        "id" : 44615672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/HHxvumEqNb",
        "expanded_url" : "http:\/\/www.ustr.gov\/US-Wins-Trade-Enforcement-Case-AmericanFarmers-Proves-Export-Blocking-Chinese-Duties-Unjustified-Under-WTO-Rule",
        "display_url" : "ustr.gov\/US-Wins-Trade-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "363332048385093632",
    "text" : "US wins major WTO case against China - big win for American farmers - via @USTradeRep here: http:\/\/t.co\/HHxvumEqNb",
    "id" : 363332048385093632,
    "created_at" : "2013-08-02 16:14:45 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 363340826815893506,
  "created_at" : "2013-08-02 16:49:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    }, {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 29, 37 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climate",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "AskGinaEPA",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363334091430572032",
  "text" : "RT @EPA: Have a question for @GinaEPA on #climate change? Join her for a Twitter chat today at 12:30pm EDT. Use #AskGinaEPA. http:\/\/t.co\/aj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina McCarthy",
        "screen_name" : "GinaEPA",
        "indices" : [ 20, 28 ],
        "id_str" : "1530850933",
        "id" : 1530850933
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "climate",
        "indices" : [ 32, 40 ]
      }, {
        "text" : "AskGinaEPA",
        "indices" : [ 103, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ajyLGt3QAl",
        "expanded_url" : "http:\/\/go.usa.gov\/jP8R",
        "display_url" : "go.usa.gov\/jP8R"
      } ]
    },
    "geo" : { },
    "id_str" : "363306269371031552",
    "text" : "Have a question for @GinaEPA on #climate change? Join her for a Twitter chat today at 12:30pm EDT. Use #AskGinaEPA. http:\/\/t.co\/ajyLGt3QAl",
    "id" : 363306269371031552,
    "created_at" : "2013-08-02 14:32:19 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 363334091430572032,
  "created_at" : "2013-08-02 16:22:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 39, 49 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/363330524892246016\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/WSpo410rbG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQrPL_iCMAAS5E0.png",
      "id_str" : "363330524896440320",
      "id" : 363330524896440320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQrPL_iCMAAS5E0.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/WSpo410rbG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363330524892246016",
  "text" : "The Washington Monument at sunset (h\/t @PeteSouza): http:\/\/t.co\/WSpo410rbG",
  "id" : 363330524892246016,
  "created_at" : "2013-08-02 16:08:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 68, 71 ],
      "id_str" : "14159148",
      "id" : 14159148
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 85, 96 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "indices" : [ 98, 103 ],
      "id_str" : "249677516",
      "id" : 249677516
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/363310379079716864\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/muVmlO1PI3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQq83WjCUAAkuQQ.jpg",
      "id_str" : "363310379088105472",
      "id" : 363310379088105472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQq83WjCUAAkuQQ.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/muVmlO1PI3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363325489399599104",
  "text" : "RT @VP: VP Biden swears in Samantha Power as U.S. Ambassador to the @UN today at the @whitehouse. @USUN http:\/\/t.co\/muVmlO1PI3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "United Nations",
        "screen_name" : "UN",
        "indices" : [ 60, 63 ],
        "id_str" : "14159148",
        "id" : 14159148
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 77, 88 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "US Mission to the UN",
        "screen_name" : "USUN",
        "indices" : [ 90, 95 ],
        "id_str" : "249677516",
        "id" : 249677516
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/363310379079716864\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/muVmlO1PI3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQq83WjCUAAkuQQ.jpg",
        "id_str" : "363310379088105472",
        "id" : 363310379088105472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQq83WjCUAAkuQQ.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/muVmlO1PI3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363310379079716864",
    "text" : "VP Biden swears in Samantha Power as U.S. Ambassador to the @UN today at the @whitehouse. @USUN http:\/\/t.co\/muVmlO1PI3",
    "id" : 363310379079716864,
    "created_at" : "2013-08-02 14:48:39 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 363325489399599104,
  "created_at" : "2013-08-02 15:48:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "indices" : [ 3, 11 ],
      "id_str" : "1603381488",
      "id" : 1603381488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/sonOSfEPI8",
      "expanded_url" : "http:\/\/bit.ly\/14nrDsx",
      "display_url" : "bit.ly\/14nrDsx"
    } ]
  },
  "geo" : { },
  "id_str" : "363318918724591616",
  "text" : "RT @Katie44: Columbus Dispatch \"Claim of high rates under Obamacare called misleading\": http:\/\/t.co\/sonOSfEPI8 #ACA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 98, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/sonOSfEPI8",
        "expanded_url" : "http:\/\/bit.ly\/14nrDsx",
        "display_url" : "bit.ly\/14nrDsx"
      } ]
    },
    "geo" : { },
    "id_str" : "363302021463416832",
    "text" : "Columbus Dispatch \"Claim of high rates under Obamacare called misleading\": http:\/\/t.co\/sonOSfEPI8 #ACA",
    "id" : 363302021463416832,
    "created_at" : "2013-08-02 14:15:26 +0000",
    "user" : {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "protected" : false,
      "id_str" : "1603381488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000171840264\/4f11a05d0664eefddc3806b77bfd2b99_normal.jpeg",
      "id" : 1603381488,
      "verified" : true
    }
  },
  "id" : 363318918724591616,
  "created_at" : "2013-08-02 15:22:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/SfkLThXfwR",
      "expanded_url" : "http:\/\/at.wh.gov\/nzt21",
      "display_url" : "at.wh.gov\/nzt21"
    } ]
  },
  "geo" : { },
  "id_str" : "363313455341633536",
  "text" : "Our businesses added 161,000 private-sector jobs in July and unemployment dropped to its lowest level since Dec. '08: http:\/\/t.co\/SfkLThXfwR",
  "id" : 363313455341633536,
  "created_at" : "2013-08-02 15:00:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/363304220759298049\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/oVUjXdzuAp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQq3Q5BCEAAQgwR.jpg",
      "id_str" : "363304220767686656",
      "id" : 363304220767686656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQq3Q5BCEAAQgwR.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/oVUjXdzuAp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363304220759298049",
  "text" : "Share the news: Our economy has added 7.3 million private-sector jobs over the last 41 months. More work to do. http:\/\/t.co\/oVUjXdzuAp",
  "id" : 363304220759298049,
  "created_at" : "2013-08-02 14:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/363089927476506624\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/IyEFed4tPg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQn0XYUCcAAEHV4.png",
      "id_str" : "363089927480700928",
      "id" : 363089927480700928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQn0XYUCcAAEHV4.png",
      "sizes" : [ {
        "h" : 613,
        "resize" : "fit",
        "w" : 613
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 613
      } ],
      "display_url" : "pic.twitter.com\/IyEFed4tPg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363089927476506624",
  "text" : "Presidential staring contest: http:\/\/t.co\/IyEFed4tPg",
  "id" : 363089927476506624,
  "created_at" : "2013-08-02 00:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/gAgVk7Trbr",
      "expanded_url" : "http:\/\/at.wh.gov\/nynkj",
      "display_url" : "at.wh.gov\/nynkj"
    } ]
  },
  "geo" : { },
  "id_str" : "363084665722126337",
  "text" : "RT @Schultz44: \"..but the media quickly loses interest after the most sensational charges are not substantiated.\" http:\/\/t.co\/gAgVk7Trbr #P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PhonyScandal",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/gAgVk7Trbr",
        "expanded_url" : "http:\/\/at.wh.gov\/nynkj",
        "display_url" : "at.wh.gov\/nynkj"
      } ]
    },
    "geo" : { },
    "id_str" : "363066908678950912",
    "text" : "\"..but the media quickly loses interest after the most sensational charges are not substantiated.\" http:\/\/t.co\/gAgVk7Trbr #PhonyScandal",
    "id" : 363066908678950912,
    "created_at" : "2013-08-01 22:41:11 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 363084665722126337,
  "created_at" : "2013-08-01 23:51:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/CCmc3k9Lvc",
      "expanded_url" : "http:\/\/wh.gov\/lrZOI",
      "display_url" : "wh.gov\/lrZOI"
    }, {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/tMxBJufyBx",
      "expanded_url" : "http:\/\/at.wh.gov\/nymU1",
      "display_url" : "at.wh.gov\/nymU1"
    } ]
  },
  "geo" : { },
  "id_str" : "363077917841965056",
  "text" : "President Obama called PM Netanyahu &amp; President Abbas to reaffirm U.S. support of peace talks: http:\/\/t.co\/CCmc3k9Lvc http:\/\/t.co\/tMxBJufyBx",
  "id" : 363077917841965056,
  "created_at" : "2013-08-01 23:24:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 110, 113 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363071737652453376",
  "text" : "RT @AmbassadorRice: Warmest congrats to my friend Samantha Power \u2013 she will be a powerful force for the US at @UN and great leader of team \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "United Nations",
        "screen_name" : "UN",
        "indices" : [ 90, 93 ],
        "id_str" : "14159148",
        "id" : 14159148
      }, {
        "name" : "US Mission to the UN",
        "screen_name" : "USUN",
        "indices" : [ 119, 124 ],
        "id_str" : "249677516",
        "id" : 249677516
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363043970428841985",
    "text" : "Warmest congrats to my friend Samantha Power \u2013 she will be a powerful force for the US at @UN and great leader of team @USUN. Miss you guys!",
    "id" : 363043970428841985,
    "created_at" : "2013-08-01 21:10:02 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 363071737652453376,
  "created_at" : "2013-08-01 23:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 95, 98 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/2Y6Et09Qdj",
      "expanded_url" : "http:\/\/at.wh.gov\/nymQd",
      "display_url" : "at.wh.gov\/nymQd"
    } ]
  },
  "geo" : { },
  "id_str" : "363065639935549440",
  "text" : "Statement from President Obama on the confirmation of Samantha Power as U.S. Ambassador to the @UN: http:\/\/t.co\/2Y6Et09Qdj",
  "id" : 363065639935549440,
  "created_at" : "2013-08-01 22:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363058117430362114",
  "text" : "RT @AmbassadorRice: POTUS to PM Netanyahu + President Abbas:  You have an important opportunity to forge lasting peace. Let's do it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363057337151401985",
    "text" : "POTUS to PM Netanyahu + President Abbas:  You have an important opportunity to forge lasting peace. Let's do it.",
    "id" : 363057337151401985,
    "created_at" : "2013-08-01 22:03:09 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 363058117430362114,
  "created_at" : "2013-08-01 22:06:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climate",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363041514177298432",
  "text" : "RT @GinaEPA: Looking forward to my first Twitter chat tomorrow. I want to hear your thoughts and Q's on #climate change http:\/\/t.co\/gQOvHjY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "climate",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/gQOvHjYfQc",
        "expanded_url" : "http:\/\/blog.epa.gov\/blog\/2013\/08\/askginaepa-about-climate-change\/",
        "display_url" : "blog.epa.gov\/blog\/2013\/08\/a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "362978849488773120",
    "text" : "Looking forward to my first Twitter chat tomorrow. I want to hear your thoughts and Q's on #climate change http:\/\/t.co\/gQOvHjYfQc",
    "id" : 362978849488773120,
    "created_at" : "2013-08-01 16:51:16 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 363041514177298432,
  "created_at" : "2013-08-01 21:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/363029011112292352\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/ViP3YE2QoU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQm89lLCcAAPTPH.jpg",
      "id_str" : "363029011116486656",
      "id" : 363029011116486656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQm89lLCcAAPTPH.jpg",
      "sizes" : [ {
        "h" : 411,
        "resize" : "fit",
        "w" : 397
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 397
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 397
      } ],
      "display_url" : "pic.twitter.com\/ViP3YE2QoU"
    } ],
    "hashtags" : [ {
      "text" : "ThrowbackThursday",
      "indices" : [ 22, 40 ]
    }, {
      "text" : "TBT",
      "indices" : [ 41, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363030062683004931",
  "text" : "RT @FLOTUS: Fab four. #ThrowbackThursday #TBT http:\/\/t.co\/ViP3YE2QoU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/363029011112292352\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/ViP3YE2QoU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQm89lLCcAAPTPH.jpg",
        "id_str" : "363029011116486656",
        "id" : 363029011116486656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQm89lLCcAAPTPH.jpg",
        "sizes" : [ {
          "h" : 411,
          "resize" : "fit",
          "w" : 397
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 397
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 397
        } ],
        "display_url" : "pic.twitter.com\/ViP3YE2QoU"
      } ],
      "hashtags" : [ {
        "text" : "ThrowbackThursday",
        "indices" : [ 10, 28 ]
      }, {
        "text" : "TBT",
        "indices" : [ 29, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363029011112292352",
    "text" : "Fab four. #ThrowbackThursday #TBT http:\/\/t.co\/ViP3YE2QoU",
    "id" : 363029011112292352,
    "created_at" : "2013-08-01 20:10:35 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 363030062683004931,
  "created_at" : "2013-08-01 20:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/362997321270697984\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/BVYiN26Eoi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQmgI_UCIAEJ3UB.jpg",
      "id_str" : "362997321274892289",
      "id" : 362997321274892289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQmgI_UCIAEJ3UB.jpg",
      "sizes" : [ {
        "h" : 792,
        "resize" : "fit",
        "w" : 792
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 792
      } ],
      "display_url" : "pic.twitter.com\/BVYiN26Eoi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362997321270697984",
  "text" : "RT if you agree: It's time to raise the minimum wage because nobody who works full-time should live in poverty. http:\/\/t.co\/BVYiN26Eoi",
  "id" : 362997321270697984,
  "created_at" : "2013-08-01 18:04:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/zDzJwsAJLL",
      "expanded_url" : "http:\/\/at.wh.gov\/nxBKU",
      "display_url" : "at.wh.gov\/nxBKU"
    } ]
  },
  "geo" : { },
  "id_str" : "362991323441139712",
  "text" : "RT if you agree with Jeff and Karen from Arizona: \u201CWhen the middle class grows, the country grows.\u201D http:\/\/t.co\/zDzJwsAJLL #ABetterBargain",
  "id" : 362991323441139712,
  "created_at" : "2013-08-01 17:40:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362986289554923520",
  "text" : "\u201CAs an educator &amp; a mother I know firsthand what a difference an education &amp; good health mean to the individual &amp; to America.\u201D \u2014Kathleen, IL",
  "id" : 362986289554923520,
  "created_at" : "2013-08-01 17:20:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362981264418013185",
  "text" : "\u201CEverybody in America deserves and needs a good education, a good job, and a nice place to live.\" \u2014Margaret, MO #ABetterBargain",
  "id" : 362981264418013185,
  "created_at" : "2013-08-01 17:00:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362976222612946946",
  "text" : "\u201CHaving a good-paying job is the gateway to having housing, being able to afford an education, reducing poverty.\u201D \u2014Gerald #ABetterBargain",
  "id" : 362976222612946946,
  "created_at" : "2013-08-01 16:40:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/e6sQwaqlgN",
      "expanded_url" : "http:\/\/at.wh.gov\/nxA6R",
      "display_url" : "at.wh.gov\/nxA6R"
    } ]
  },
  "geo" : { },
  "id_str" : "362971189913722880",
  "text" : "Share why you agree with President Obama that rebuilding middle-class security should be Washington's top priority \u2014&gt; http:\/\/t.co\/e6sQwaqlgN",
  "id" : 362971189913722880,
  "created_at" : "2013-08-01 16:20:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biz",
      "indices" : [ 62, 66 ]
    }, {
      "text" : "ACA",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/CYmquFW9TH",
      "expanded_url" : "http:\/\/owl.li\/nxvEc",
      "display_url" : "owl.li\/nxvEc"
    } ]
  },
  "geo" : { },
  "id_str" : "362964176651550720",
  "text" : "RT @SBAgov: Not sure how the health care law will impact your #biz? Get customized results w\/ this new tool http:\/\/t.co\/CYmquFW9TH #ACA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "biz",
        "indices" : [ 50, 54 ]
      }, {
        "text" : "ACA",
        "indices" : [ 119, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/CYmquFW9TH",
        "expanded_url" : "http:\/\/owl.li\/nxvEc",
        "display_url" : "owl.li\/nxvEc"
      } ]
    },
    "geo" : { },
    "id_str" : "362962432152449024",
    "text" : "Not sure how the health care law will impact your #biz? Get customized results w\/ this new tool http:\/\/t.co\/CYmquFW9TH #ACA",
    "id" : 362962432152449024,
    "created_at" : "2013-08-01 15:46:02 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 362964176651550720,
  "created_at" : "2013-08-01 15:52:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362957144334663681",
  "text" : "RT @lacasablanca: Bienvenida! RT @vargas44: Hola tweeps! Get ready for some bilingual musings on @lacasablanca and all things #politics and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "La Casa Blanca",
        "screen_name" : "lacasablanca",
        "indices" : [ 79, 92 ],
        "id_str" : "78138151",
        "id" : 78138151
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "politics",
        "indices" : [ 108, 117 ]
      }, {
        "text" : "Latinos",
        "indices" : [ 122, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362952804924522499",
    "text" : "Bienvenida! RT @vargas44: Hola tweeps! Get ready for some bilingual musings on @lacasablanca and all things #politics and #Latinos",
    "id" : 362952804924522499,
    "created_at" : "2013-08-01 15:07:46 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 362957144334663681,
  "created_at" : "2013-08-01 15:25:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362947081154990080",
  "text" : "RT @vj44: Congrats to Todd Jones on his confirmation as ATF Director\u2014a true leader in protecting our communities against gun violence.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362733228295073792",
    "text" : "Congrats to Todd Jones on his confirmation as ATF Director\u2014a true leader in protecting our communities against gun violence.",
    "id" : 362733228295073792,
    "created_at" : "2013-08-01 00:35:15 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 362947081154990080,
  "created_at" : "2013-08-01 14:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 26, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/uqVLn5h2jl",
      "expanded_url" : "http:\/\/at.wh.gov\/nxfuG",
      "display_url" : "at.wh.gov\/nxfuG"
    } ]
  },
  "geo" : { },
  "id_str" : "362941749225734145",
  "text" : "No matter where you live, #ImmigrationReform will strengthen the economy in your state. Here's how \u2014&gt; http:\/\/t.co\/uqVLn5h2jl",
  "id" : 362941749225734145,
  "created_at" : "2013-08-01 14:23:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]