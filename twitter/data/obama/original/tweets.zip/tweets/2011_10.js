Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/131133782446190592\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/1xckYeyZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AdHhevkCMAAfrco.jpg",
      "id_str" : "131133782450384896",
      "id" : 131133782450384896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdHhevkCMAAfrco.jpg",
      "sizes" : [ {
        "h" : 369,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/1xckYeyZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/m7o0OxOQ",
      "expanded_url" : "http:\/\/1.usa.gov\/uynt28",
      "display_url" : "1.usa.gov\/uynt28"
    } ]
  },
  "geo" : { },
  "id_str" : "131133782446190592",
  "text" : "By the numbers: 650%: Ave markup by price-gouging vendors on prescription drugs in short supply: http:\/\/t.co\/m7o0OxOQ http:\/\/t.co\/1xckYeyZ",
  "id" : 131133782446190592,
  "created_at" : "2011-10-31 22:21:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 62, 73 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/tLWdpT5U",
      "expanded_url" : "http:\/\/ow.ly\/7eKYg",
      "display_url" : "ow.ly\/7eKYg"
    } ]
  },
  "geo" : { },
  "id_str" : "131130309956734978",
  "text" : "Happy Halloween Everyone! Take a look inside Halloween at the @WhiteHouse: http:\/\/t.co\/tLWdpT5U",
  "id" : 131130309956734978,
  "created_at" : "2011-10-31 22:07:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/AC1QtLSY",
      "expanded_url" : "http:\/\/ow.ly\/7evUk",
      "display_url" : "ow.ly\/7evUk"
    } ]
  },
  "geo" : { },
  "id_str" : "131076763693494272",
  "text" : "\"This is a problem we can\u2019t wait to fix\" Obama on prescription drug shortages & price gouging. Today's executive order: http:\/\/t.co\/AC1QtLSY",
  "id" : 131076763693494272,
  "created_at" : "2011-10-31 18:35:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ng5nZHMH",
      "expanded_url" : "http:\/\/ow.ly\/7emd3",
      "display_url" : "ow.ly\/7emd3"
    } ]
  },
  "geo" : { },
  "id_str" : "131048207332552704",
  "text" : "Today, President Obama will issue an Executive Order to reduce prescription drug shortages in the U.S. FACT SHEET: http:\/\/t.co\/ng5nZHMH",
  "id" : 131048207332552704,
  "created_at" : "2011-10-31 16:41:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/TA2Kt4Jo",
      "expanded_url" : "http:\/\/ow.ly\/7efL0",
      "display_url" : "ow.ly\/7efL0"
    } ]
  },
  "geo" : { },
  "id_str" : "131032347981266944",
  "text" : "\"The truth is, we can no longer wait for Congress to do its job\" -President Obama in his Weekly Address. Video: http:\/\/t.co\/TA2Kt4Jo",
  "id" : 131032347981266944,
  "created_at" : "2011-10-31 15:38:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/eGhEyieO",
      "expanded_url" : "http:\/\/nyti.ms\/t1GVbo",
      "display_url" : "nyti.ms\/t1GVbo"
    } ]
  },
  "geo" : { },
  "id_str" : "131003851267518465",
  "text" : "RT @jesseclee44: Today\u2019s \"We Can\u2019t Wait\"\u2026 NYT: Obama Tries to Speed Response to Shortages in Vital Medicines http:\/\/t.co\/eGhEyieO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/eGhEyieO",
        "expanded_url" : "http:\/\/nyti.ms\/t1GVbo",
        "display_url" : "nyti.ms\/t1GVbo"
      } ]
    },
    "geo" : { },
    "id_str" : "130996696351113216",
    "text" : "Today\u2019s \"We Can\u2019t Wait\"\u2026 NYT: Obama Tries to Speed Response to Shortages in Vital Medicines http:\/\/t.co\/eGhEyieO",
    "id" : 130996696351113216,
    "created_at" : "2011-10-31 13:17:00 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 131003851267518465,
  "created_at" : "2011-10-31 13:45:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130739781486387200",
  "text" : "RT @pfeiffer44: We Can't Wait Effort continues tomorrow, when the President signs an executive order in the oval office. More details in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130732864206675968",
    "text" : "We Can't Wait Effort continues tomorrow, when the President signs an executive order in the oval office. More details in the morning.",
    "id" : 130732864206675968,
    "created_at" : "2011-10-30 19:48:38 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 130739781486387200,
  "created_at" : "2011-10-30 20:16:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130425942828003328",
  "text" : "RT @JoiningForces: Happy halloween! Spending it w\/ military kids & families - so proud of them & honored to say thanks. -mo http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/ZzLR3r3m",
        "expanded_url" : "http:\/\/yfrog.com\/esah0gj",
        "display_url" : "yfrog.com\/esah0gj"
      } ]
    },
    "geo" : { },
    "id_str" : "130425159667564544",
    "text" : "Happy halloween! Spending it w\/ military kids & families - so proud of them & honored to say thanks. -mo http:\/\/t.co\/ZzLR3r3m",
    "id" : 130425159667564544,
    "created_at" : "2011-10-29 23:25:55 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 130425942828003328,
  "created_at" : "2011-10-29 23:29:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/ytaa50GT",
      "expanded_url" : "http:\/\/youtu.be\/Ywgtctz2Jqg",
      "display_url" : "youtu.be\/Ywgtctz2Jqg"
    } ]
  },
  "geo" : { },
  "id_str" : "130301132538003456",
  "text" : "President Obama's Weekly Address: We Can\u2019t Wait to Create Jobs. Video: http:\/\/t.co\/ytaa50GT",
  "id" : 130301132538003456,
  "created_at" : "2011-10-29 15:13:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "CodeNowOrg",
      "screen_name" : "CodeNowOrg",
      "indices" : [ 42, 53 ],
      "id_str" : "3124233461",
      "id" : 3124233461
    }, {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 54, 70 ],
      "id_str" : "17961886",
      "id" : 17961886
    }, {
      "name" : "PublicAllies",
      "screen_name" : "PublicAllies",
      "indices" : [ 71, 84 ],
      "id_str" : "20487659",
      "id" : 20487659
    }, {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 85, 97 ],
      "id_str" : "59204932",
      "id" : 59204932
    }, {
      "name" : "Sierra Student Co.",
      "screen_name" : "Sierrastudent",
      "indices" : [ 98, 112 ],
      "id_str" : "123955880",
      "id" : 123955880
    }, {
      "name" : "Energy Action",
      "screen_name" : "energyaction",
      "indices" : [ 113, 126 ],
      "id_str" : "756125669264719873",
      "id" : 756125669264719873
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 26, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130066390009913346",
  "text" : "RT @JonCarson44: My first #FollowFriday !\n@CodeNowOrg @nationalservice @PublicAllies @ServeDotGov @Sierrastudent @energyaction!  @PaulRi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CodeNowOrg",
        "screen_name" : "CodeNowOrg",
        "indices" : [ 25, 36 ],
        "id_str" : "3124233461",
        "id" : 3124233461
      }, {
        "name" : "CNCS",
        "screen_name" : "NationalService",
        "indices" : [ 37, 53 ],
        "id_str" : "17961886",
        "id" : 17961886
      }, {
        "name" : "PublicAllies",
        "screen_name" : "PublicAllies",
        "indices" : [ 54, 67 ],
        "id_str" : "20487659",
        "id" : 20487659
      }, {
        "name" : "United We Serve",
        "screen_name" : "ServeDotGov",
        "indices" : [ 68, 80 ],
        "id_str" : "59204932",
        "id" : 59204932
      }, {
        "name" : "Sierra Student Co.",
        "screen_name" : "Sierrastudent",
        "indices" : [ 81, 95 ],
        "id_str" : "123955880",
        "id" : 123955880
      }, {
        "name" : "Energy Action",
        "screen_name" : "energyaction",
        "indices" : [ 96, 109 ],
        "id_str" : "756125669264719873",
        "id" : 756125669264719873
      }, {
        "name" : "Paul (PJ) Rieckhoff",
        "screen_name" : "PaulRieckhoff",
        "indices" : [ 112, 126 ],
        "id_str" : "21542518",
        "id" : 21542518
      }, {
        "name" : "IAVA",
        "screen_name" : "iava",
        "indices" : [ 127, 132 ],
        "id_str" : "12296312",
        "id" : 12296312
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FollowFriday",
        "indices" : [ 9, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129993405274144768",
    "in_reply_to_user_id" : 253207175,
    "text" : "My first #FollowFriday !\n@CodeNowOrg @nationalservice @PublicAllies @ServeDotGov @Sierrastudent @energyaction!  @PaulRieckhoff @IAVA",
    "id" : 129993405274144768,
    "created_at" : "2011-10-28 18:50:17 +0000",
    "in_reply_to_screen_name" : "CodeNow",
    "in_reply_to_user_id_str" : "253207175",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 130066390009913346,
  "created_at" : "2011-10-28 23:40:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 56, 67 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyHalloween",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/mUuVcYjS",
      "expanded_url" : "http:\/\/youtu.be\/wQoEjgctY2o",
      "display_url" : "youtu.be\/wQoEjgctY2o"
    } ]
  },
  "geo" : { },
  "id_str" : "130059917905231875",
  "text" : "Video: Get a behind-the-scenes look at Halloween at the @WhiteHouse: http:\/\/t.co\/mUuVcYjS #HappyHalloween",
  "id" : 130059917905231875,
  "created_at" : "2011-10-28 23:14:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/jqJb4xyL",
      "expanded_url" : "http:\/\/youtu.be\/ij2K8WHMo1w",
      "display_url" : "youtu.be\/ij2K8WHMo1w"
    } ]
  },
  "geo" : { },
  "id_str" : "130042454488518657",
  "text" : "\"We can\u2019t wait for Congress to do its job. So where they won\u2019t act, I will\" -President Obama. West Wing Week: http:\/\/t.co\/jqJb4xyL",
  "id" : 130042454488518657,
  "created_at" : "2011-10-28 22:05:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130003819387035649",
  "text" : "RT @WHLive: .@lilypolaris POTUS increased the maximum Pell grants by $800 since taking office to help families pay for college #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130000846313373696",
    "text" : ".@lilypolaris POTUS increased the maximum Pell grants by $800 since taking office to help families pay for college #whchat",
    "id" : 130000846313373696,
    "created_at" : "2011-10-28 19:19:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 130003819387035649,
  "created_at" : "2011-10-28 19:31:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129999706494472192",
  "text" : "RT @WHLive: .@JLombard207 You may qualify for help now.  See IBR calculator:  http:\/\/t.co\/YD0G3xU9 Might reduce payment to 15% of your i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/YD0G3xU9",
        "expanded_url" : "http:\/\/studentaid.ed.gov\/PORTALSWebApp\/students\/english\/IBRPlan.jsp",
        "display_url" : "studentaid.ed.gov\/PORTALSWebApp\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "129999563577753601",
    "text" : ".@JLombard207 You may qualify for help now.  See IBR calculator:  http:\/\/t.co\/YD0G3xU9 Might reduce payment to 15% of your income. #whchat",
    "id" : 129999563577753601,
    "created_at" : "2011-10-28 19:14:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 129999706494472192,
  "created_at" : "2011-10-28 19:15:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129999688798715904",
  "text" : "RT @JLombard207: Mark, I finished my undergrad in 2006 and have been struggling with my student loans. Will this new program help me as  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129997769028022273",
    "text" : "Mark, I finished my undergrad in 2006 and have been struggling with my student loans. Will this new program help me as well? #whchat",
    "id" : 129997769028022273,
    "created_at" : "2011-10-28 19:07:38 +0000",
    "user" : {
      "name" : "SwedishCar850",
      "screen_name" : "SwedishCar850",
      "protected" : false,
      "id_str" : "41219559",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798010240826572800\/YBedJYMo_normal.jpg",
      "id" : 41219559,
      "verified" : false
    }
  },
  "id" : 129999688798715904,
  "created_at" : "2011-10-28 19:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129994637321568256",
  "text" : "RT @WHLive: Hey this is mark, I am ready to answer your questions on making college more affordable.  Ask with #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129994517855215617",
    "text" : "Hey this is mark, I am ready to answer your questions on making college more affordable.  Ask with #whchat",
    "id" : 129994517855215617,
    "created_at" : "2011-10-28 18:54:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 129994637321568256,
  "created_at" : "2011-10-28 18:55:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/WP2STzhJ",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/engage",
      "display_url" : "whitehouse.gov\/engage"
    } ]
  },
  "geo" : { },
  "id_str" : "129974864630136832",
  "text" : "RT @JonCarson44: check out our new Engage page: http:\/\/t.co\/WP2STzhJ\n\nmy favorite video of the President is on the front...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/WP2STzhJ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/engage",
        "display_url" : "whitehouse.gov\/engage"
      } ]
    },
    "geo" : { },
    "id_str" : "129971275593555970",
    "text" : "check out our new Engage page: http:\/\/t.co\/WP2STzhJ\n\nmy favorite video of the President is on the front...",
    "id" : 129971275593555970,
    "created_at" : "2011-10-28 17:22:21 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 129974864630136832,
  "created_at" : "2011-10-28 17:36:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/rawLzu9a",
      "expanded_url" : "http:\/\/ow.ly\/7bY4y",
      "display_url" : "ow.ly\/7bY4y"
    } ]
  },
  "geo" : { },
  "id_str" : "129927476280442881",
  "text" : "WH Office Hours: Helping Americans manage their student debt. Join Twitter Q&A @ 3ET. Use #WHChat to ask your Qs now: http:\/\/t.co\/rawLzu9a",
  "id" : 129927476280442881,
  "created_at" : "2011-10-28 14:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129925411093221376",
  "text" : "RT @pfeiffer44: More We Can't Wait executive actions coming today to help small business and grow the economy. AP has the story http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/YydZRBDI",
        "expanded_url" : "http:\/\/bit.ly\/u94Qww",
        "display_url" : "bit.ly\/u94Qww"
      } ]
    },
    "geo" : { },
    "id_str" : "129912851031789568",
    "text" : "More We Can't Wait executive actions coming today to help small business and grow the economy. AP has the story http:\/\/t.co\/YydZRBDI",
    "id" : 129912851031789568,
    "created_at" : "2011-10-28 13:30:12 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 129925411093221376,
  "created_at" : "2011-10-28 14:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/129682349939109888\/photo\/1",
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/UfXIVBgB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Acy5aQJCMAATK_l.jpg",
      "id_str" : "129682349947498496",
      "id" : 129682349947498496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Acy5aQJCMAATK_l.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/UfXIVBgB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/FZqVbTIR",
      "expanded_url" : "http:\/\/ow.ly\/7bkYn",
      "display_url" : "ow.ly\/7bkYn"
    } ]
  },
  "geo" : { },
  "id_str" : "129682349939109888",
  "text" : "How President Obama is helping lower monthly student loan payments: http:\/\/t.co\/FZqVbTIR http:\/\/t.co\/UfXIVBgB",
  "id" : 129682349939109888,
  "created_at" : "2011-10-27 22:14:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeCantWait",
      "indices" : [ 10, 21 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129669875957374976",
  "text" : "RT @ks44: #WeCantWait for WH Office Hrs on steps the President is taking to make college more affordable. Got Qs? Ask: #WHChat http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeCantWait",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/QdJaKFQv",
        "expanded_url" : "http:\/\/ow.ly\/7bi2Q",
        "display_url" : "ow.ly\/7bi2Q"
      } ]
    },
    "geo" : { },
    "id_str" : "129669698500575232",
    "text" : "#WeCantWait for WH Office Hrs on steps the President is taking to make college more affordable. Got Qs? Ask: #WHChat http:\/\/t.co\/QdJaKFQv",
    "id" : 129669698500575232,
    "created_at" : "2011-10-27 21:23:59 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 129669875957374976,
  "created_at" : "2011-10-27 21:24:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129632473981267968",
  "text" : "RT @GovernorOMalley: Obama's infrastructure plan will create jobs, rebuild America & give our kids a stronger future. http:\/\/t.co\/k1Qk5S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 118, 129 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobsnow",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/k1Qk5Sf6",
        "expanded_url" : "http:\/\/bit.ly\/t4Zhjh",
        "display_url" : "bit.ly\/t4Zhjh"
      } ]
    },
    "geo" : { },
    "id_str" : "129619603562307584",
    "text" : "Obama's infrastructure plan will create jobs, rebuild America & give our kids a stronger future. http:\/\/t.co\/k1Qk5Sf6 @WhiteHouse #jobsnow",
    "id" : 129619603562307584,
    "created_at" : "2011-10-27 18:04:56 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 129632473981267968,
  "created_at" : "2011-10-27 18:56:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Fretwell",
      "screen_name" : "lukefretwell",
      "indices" : [ 3, 16 ],
      "id_str" : "1980171",
      "id" : 1980171
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 53, 64 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 67, 79 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/lBggqzND",
      "expanded_url" : "http:\/\/1.usa.gov\/sErtcG",
      "display_url" : "1.usa.gov\/sErtcG"
    } ]
  },
  "geo" : { },
  "id_str" : "129612251710767105",
  "text" : "RT @lukefretwell: Infographic of citizen activity on @whitehouse's @wethepeople petition platform: http:\/\/t.co\/lBggqzND",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 35, 46 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 49, 61 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/lBggqzND",
        "expanded_url" : "http:\/\/1.usa.gov\/sErtcG",
        "display_url" : "1.usa.gov\/sErtcG"
      } ]
    },
    "geo" : { },
    "id_str" : "129611384110579712",
    "text" : "Infographic of citizen activity on @whitehouse's @wethepeople petition platform: http:\/\/t.co\/lBggqzND",
    "id" : 129611384110579712,
    "created_at" : "2011-10-27 17:32:16 +0000",
    "user" : {
      "name" : "Luke Fretwell",
      "screen_name" : "lukefretwell",
      "protected" : false,
      "id_str" : "1980171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502213695686983680\/LmKBjvRv_normal.jpeg",
      "id" : 1980171,
      "verified" : false
    }
  },
  "id" : 129612251710767105,
  "created_at" : "2011-10-27 17:35:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/129594913045229568\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/wcwYV9B4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Acxp4wVCMAEc_JS.jpg",
      "id_str" : "129594913053618177",
      "id" : 129594913053618177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Acxp4wVCMAEc_JS.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wcwYV9B4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/yieiZoyP",
      "expanded_url" : "http:\/\/1.usa.gov\/v3XL61",
      "display_url" : "1.usa.gov\/v3XL61"
    } ]
  },
  "geo" : { },
  "id_str" : "129594913045229568",
  "text" : "Economy posts 9th straight quarter of positive growth, still need Jobs Act to speed recovery http:\/\/t.co\/yieiZoyP Chart http:\/\/t.co\/wcwYV9B4",
  "id" : 129594913045229568,
  "created_at" : "2011-10-27 16:26:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129588384212594688",
  "text" : "RT @wethepeople: NEW RESPONSE: The Fair Tax \u2013 A National Sales Tax That Increases Tax Burdens for Middle-Class Families: http:\/\/t.co\/2OE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/2OEgOBEu",
        "expanded_url" : "http:\/\/ow.ly\/7aTq8",
        "display_url" : "ow.ly\/7aTq8"
      } ]
    },
    "geo" : { },
    "id_str" : "129588266121961472",
    "text" : "NEW RESPONSE: The Fair Tax \u2013 A National Sales Tax That Increases Tax Burdens for Middle-Class Families: http:\/\/t.co\/2OEgOBEu",
    "id" : 129588266121961472,
    "created_at" : "2011-10-27 16:00:24 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 129588384212594688,
  "created_at" : "2011-10-27 16:00:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 42, 54 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/tw6YqgDC",
      "expanded_url" : "http:\/\/ow.ly\/79WGa",
      "display_url" : "ow.ly\/79WGa"
    } ]
  },
  "geo" : { },
  "id_str" : "129582142584922113",
  "text" : "RT @macon44: Every minute, 15 people join @WeThePeople. What are you waiting for? Latest stats & more: http:\/\/t.co\/tw6YqgDC http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 29, 41 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/129285330149978113\/photo\/1",
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/2L7P22BK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ActQUqLCMAAVlxO.jpg",
        "id_str" : "129285330158366720",
        "id" : 129285330158366720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ActQUqLCMAAVlxO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1010,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 1010,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 1010,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 613,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2L7P22BK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/tw6YqgDC",
        "expanded_url" : "http:\/\/ow.ly\/79WGa",
        "display_url" : "ow.ly\/79WGa"
      } ]
    },
    "geo" : { },
    "id_str" : "129285330149978113",
    "text" : "Every minute, 15 people join @WeThePeople. What are you waiting for? Latest stats & more: http:\/\/t.co\/tw6YqgDC http:\/\/t.co\/2L7P22BK",
    "id" : 129285330149978113,
    "created_at" : "2011-10-26 19:56:39 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 129582142584922113,
  "created_at" : "2011-10-27 15:36:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "SAMHSA",
      "screen_name" : "samhsagov",
      "indices" : [ 17, 27 ],
      "id_str" : "24959108",
      "id" : 24959108
    }, {
      "name" : "What's Trending",
      "screen_name" : "WhatsTrending",
      "indices" : [ 28, 42 ],
      "id_str" : "16249938",
      "id" : 16249938
    }, {
      "name" : "MTV",
      "screen_name" : "MTV",
      "indices" : [ 43, 47 ],
      "id_str" : "2367911",
      "id" : 2367911
    }, {
      "name" : "The Trevor Project",
      "screen_name" : "TrevorProject",
      "indices" : [ 48, 62 ],
      "id_str" : "18916728",
      "id" : 18916728
    }, {
      "name" : "DoSomething.org",
      "screen_name" : "dosomething",
      "indices" : [ 63, 75 ],
      "id_str" : "14165865",
      "id" : 14165865
    }, {
      "name" : "Kind Campaign",
      "screen_name" : "kindcampaign",
      "indices" : [ 77, 90 ],
      "id_str" : "28595577",
      "id" : 28595577
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Stopbullying",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129558797634117632",
  "text" : "RT @HHSGov: Join @samhsagov @WhatsTrending @MTV @TrevorProject @dosomething  @Kindcampaign in a LIVE #Stopbullying Townhall TODAY http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SAMHSA",
        "screen_name" : "samhsagov",
        "indices" : [ 5, 15 ],
        "id_str" : "24959108",
        "id" : 24959108
      }, {
        "name" : "What's Trending",
        "screen_name" : "WhatsTrending",
        "indices" : [ 16, 30 ],
        "id_str" : "16249938",
        "id" : 16249938
      }, {
        "name" : "MTV",
        "screen_name" : "MTV",
        "indices" : [ 31, 35 ],
        "id_str" : "2367911",
        "id" : 2367911
      }, {
        "name" : "The Trevor Project",
        "screen_name" : "TrevorProject",
        "indices" : [ 36, 50 ],
        "id_str" : "18916728",
        "id" : 18916728
      }, {
        "name" : "DoSomething.org",
        "screen_name" : "dosomething",
        "indices" : [ 51, 63 ],
        "id_str" : "14165865",
        "id" : 14165865
      }, {
        "name" : "Kind Campaign",
        "screen_name" : "kindcampaign",
        "indices" : [ 65, 78 ],
        "id_str" : "28595577",
        "id" : 28595577
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Stopbullying",
        "indices" : [ 89, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/8XHhrnuN",
        "expanded_url" : "http:\/\/bit.ly\/rDrLQB",
        "display_url" : "bit.ly\/rDrLQB"
      } ]
    },
    "geo" : { },
    "id_str" : "129545880666771456",
    "text" : "Join @samhsagov @WhatsTrending @MTV @TrevorProject @dosomething  @Kindcampaign in a LIVE #Stopbullying Townhall TODAY http:\/\/t.co\/8XHhrnuN",
    "id" : 129545880666771456,
    "created_at" : "2011-10-27 13:11:59 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 129558797634117632,
  "created_at" : "2011-10-27 14:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/129335224642441217\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/7euwmglP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Act9s5oCEAAWq8S.jpg",
      "id_str" : "129335224646635520",
      "id" : 129335224646635520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Act9s5oCEAAWq8S.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7euwmglP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/jz81amYN",
      "expanded_url" : "http:\/\/1.usa.gov\/s5FyH1",
      "display_url" : "1.usa.gov\/s5FyH1"
    } ]
  },
  "geo" : { },
  "id_str" : "129335224642441217",
  "text" : "\"Happy Diwali & Saal Mubarak\" -President Obama: http:\/\/t.co\/jz81amYN Photo: Obamas celebrate in India last year: http:\/\/t.co\/7euwmglP",
  "id" : 129335224642441217,
  "created_at" : "2011-10-26 23:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "HelloGiggles.com",
      "screen_name" : "hellogiggles",
      "indices" : [ 23, 36 ],
      "id_str" : "219682445",
      "id" : 219682445
    }, {
      "name" : "826 National",
      "screen_name" : "826National",
      "indices" : [ 68, 80 ],
      "id_str" : "36194365",
      "id" : 36194365
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 81, 92 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "kellEY lonergan",
      "screen_name" : "EwhY",
      "indices" : [ 93, 98 ],
      "id_str" : "14081898",
      "id" : 14081898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/LSKG6TrV",
      "expanded_url" : "http:\/\/1.usa.gov\/vNqKRl",
      "display_url" : "1.usa.gov\/vNqKRl"
    } ]
  },
  "geo" : { },
  "id_str" : "129307543175573504",
  "text" : "RT @JonCarson44: A new @hellogiggles Women Working to Do Good blog! @826national @whitehouse @eWhy http:\/\/t.co\/LSKG6TrV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HelloGiggles.com",
        "screen_name" : "hellogiggles",
        "indices" : [ 6, 19 ],
        "id_str" : "219682445",
        "id" : 219682445
      }, {
        "name" : "826 National",
        "screen_name" : "826National",
        "indices" : [ 51, 63 ],
        "id_str" : "36194365",
        "id" : 36194365
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 64, 75 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "kellEY lonergan",
        "screen_name" : "EwhY",
        "indices" : [ 76, 81 ],
        "id_str" : "14081898",
        "id" : 14081898
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/LSKG6TrV",
        "expanded_url" : "http:\/\/1.usa.gov\/vNqKRl",
        "display_url" : "1.usa.gov\/vNqKRl"
      } ]
    },
    "geo" : { },
    "id_str" : "129299036942503937",
    "text" : "A new @hellogiggles Women Working to Do Good blog! @826national @whitehouse @eWhy http:\/\/t.co\/LSKG6TrV",
    "id" : 129299036942503937,
    "created_at" : "2011-10-26 20:51:07 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 129307543175573504,
  "created_at" : "2011-10-26 21:24:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 18, 30 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/xzprXLo0",
      "expanded_url" : "http:\/\/ow.ly\/79ZUi",
      "display_url" : "ow.ly\/79ZUi"
    } ]
  },
  "geo" : { },
  "id_str" : "129296434804703233",
  "text" : "RT @wethepeople: .@WeThePeople takes the next step: Responding to your petitions: http:\/\/t.co\/xzprXLo0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 1, 13 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/xzprXLo0",
        "expanded_url" : "http:\/\/ow.ly\/79ZUi",
        "display_url" : "ow.ly\/79ZUi"
      } ]
    },
    "geo" : { },
    "id_str" : "129296352831221760",
    "text" : ".@WeThePeople takes the next step: Responding to your petitions: http:\/\/t.co\/xzprXLo0",
    "id" : 129296352831221760,
    "created_at" : "2011-10-26 20:40:27 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 129296434804703233,
  "created_at" : "2011-10-26 20:40:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/Zkr8bkwp",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/youngamericans",
      "display_url" : "whitehouse.gov\/youngamericans"
    } ]
  },
  "geo" : { },
  "id_str" : "129287086309257218",
  "text" : "RT @wearebiology: The White House blog for Young Americans. So awesome. http:\/\/t.co\/Zkr8bkwp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/Zkr8bkwp",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/youngamericans",
        "display_url" : "whitehouse.gov\/youngamericans"
      } ]
    },
    "geo" : { },
    "id_str" : "129286726249226240",
    "text" : "The White House blog for Young Americans. So awesome. http:\/\/t.co\/Zkr8bkwp",
    "id" : 129286726249226240,
    "created_at" : "2011-10-26 20:02:12 +0000",
    "user" : {
      "name" : "Karla Baldonado",
      "screen_name" : "karlabaldonado",
      "protected" : false,
      "id_str" : "48291339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/585636941401559040\/Rq_C5XsD_normal.jpg",
      "id" : 48291339,
      "verified" : false
    }
  },
  "id" : 129287086309257218,
  "created_at" : "2011-10-26 20:03:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Who?",
      "screen_name" : "dtschet",
      "indices" : [ 3, 11 ],
      "id_str" : "14745556",
      "id" : 14745556
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 128, 139 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/AssFbuR6",
      "expanded_url" : "http:\/\/1.usa.gov\/tJoDDB",
      "display_url" : "1.usa.gov\/tJoDDB"
    } ]
  },
  "geo" : { },
  "id_str" : "129279820923289600",
  "text" : "RT @dtschet: Great news from the White House! We Can't Wait to Help America's Graduates | The White House: http:\/\/t.co\/AssFbuR6 @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 115, 126 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/AssFbuR6",
        "expanded_url" : "http:\/\/1.usa.gov\/tJoDDB",
        "display_url" : "1.usa.gov\/tJoDDB"
      } ]
    },
    "geo" : { },
    "id_str" : "129279514609070081",
    "text" : "Great news from the White House! We Can't Wait to Help America's Graduates | The White House: http:\/\/t.co\/AssFbuR6 @whitehouse",
    "id" : 129279514609070081,
    "created_at" : "2011-10-26 19:33:32 +0000",
    "user" : {
      "name" : "Donna Who?",
      "screen_name" : "dtschet",
      "protected" : false,
      "id_str" : "14745556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/337731410\/Donnabug_normal.jpg",
      "id" : 14745556,
      "verified" : false
    }
  },
  "id" : 129279820923289600,
  "created_at" : "2011-10-26 19:34:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 28, 40 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129276457842249729",
  "text" : "RT @wethepeople: Announcing @WeThePeople - a new way to stay updated on the latest petition responses & other news about We the People:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 11, 23 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/n3a3M6Np",
        "expanded_url" : "http:\/\/ow.ly\/79Udx",
        "display_url" : "ow.ly\/79Udx"
      } ]
    },
    "geo" : { },
    "id_str" : "129275831360045056",
    "text" : "Announcing @WeThePeople - a new way to stay updated on the latest petition responses & other news about We the People: http:\/\/t.co\/n3a3M6Np",
    "id" : 129275831360045056,
    "created_at" : "2011-10-26 19:18:54 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 129276457842249729,
  "created_at" : "2011-10-26 19:21:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "payasyouearn",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/wDG8FFiI",
      "expanded_url" : "http:\/\/go.usa.gov\/XZl",
      "display_url" : "go.usa.gov\/XZl"
    } ]
  },
  "geo" : { },
  "id_str" : "129262562419277824",
  "text" : "RT @arneduncan: Burdened by student loan debt? We're hoping to help http:\/\/t.co\/wDG8FFiI #payasyouearn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "payasyouearn",
        "indices" : [ 73, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/wDG8FFiI",
        "expanded_url" : "http:\/\/go.usa.gov\/XZl",
        "display_url" : "go.usa.gov\/XZl"
      } ]
    },
    "geo" : { },
    "id_str" : "129262348476227584",
    "text" : "Burdened by student loan debt? We're hoping to help http:\/\/t.co\/wDG8FFiI #payasyouearn",
    "id" : 129262348476227584,
    "created_at" : "2011-10-26 18:25:20 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 129262562419277824,
  "created_at" : "2011-10-26 18:26:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/uT4WqL1k",
      "expanded_url" : "http:\/\/ow.ly\/79PlH",
      "display_url" : "ow.ly\/79PlH"
    } ]
  },
  "geo" : { },
  "id_str" : "129261317721817088",
  "text" : "We can't wait: President Obama announces new efforts to make college more affordable: http:\/\/t.co\/uT4WqL1k",
  "id" : 129261317721817088,
  "created_at" : "2011-10-26 18:21:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129240105188732928",
  "text" : "RT @jesseclee44: Obama on one way to get folks to support the American Jobs Act: \"Tweet 'em\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129238777255301120",
    "text" : "Obama on one way to get folks to support the American Jobs Act: \"Tweet 'em\"",
    "id" : 129238777255301120,
    "created_at" : "2011-10-26 16:51:40 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 129240105188732928,
  "created_at" : "2011-10-26 16:56:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 3, 11 ],
      "id_str" : "232193350",
      "id" : 232193350
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 45, 56 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FWD",
      "indices" : [ 31, 35 ]
    }, {
      "text" : "HornofAfrica",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129237147185192961",
  "text" : "RT @rajshah: About to kick off #FWD campaign @whitehouse and answer your Qs on the famine in the #HornofAfrica. Join me now: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 32, 43 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FWD",
        "indices" : [ 18, 22 ]
      }, {
        "text" : "HornofAfrica",
        "indices" : [ 84, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/yS8uqgbZ",
        "expanded_url" : "http:\/\/whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "129232807280128000",
    "text" : "About to kick off #FWD campaign @whitehouse and answer your Qs on the famine in the #HornofAfrica. Join me now: http:\/\/t.co\/yS8uqgbZ",
    "id" : 129232807280128000,
    "created_at" : "2011-10-26 16:27:56 +0000",
    "user" : {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "protected" : false,
      "id_str" : "232193350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486242763227152384\/vse4PX_j_normal.jpeg",
      "id" : 232193350,
      "verified" : true
    }
  },
  "id" : 129237147185192961,
  "created_at" : "2011-10-26 16:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "129236116950892544",
  "text" : "Happening now: President Obama speaks on college affordability. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 129236116950892544,
  "created_at" : "2011-10-26 16:41:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "Paul (PJ) Rieckhoff",
      "screen_name" : "PaulRieckhoff",
      "indices" : [ 18, 32 ],
      "id_str" : "21542518",
      "id" : 21542518
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsAct",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/ysQ05OL3",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/10\/19\/first-lady-michelle-obama-announces-major-private-sector-commitment-hire-veterans-an",
      "display_url" : "whitehouse.gov\/blog\/2011\/10\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129216090378211329",
  "text" : "RT @JonCarson44: .@PaulRieckhoff  We challenged private sector to hire 100k vets http:\/\/t.co\/ysQ05OL3 \nand #JobsAct would create tax cre ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul (PJ) Rieckhoff",
        "screen_name" : "PaulRieckhoff",
        "indices" : [ 1, 15 ],
        "id_str" : "21542518",
        "id" : 21542518
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsAct",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/ysQ05OL3",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/10\/19\/first-lady-michelle-obama-announces-major-private-sector-commitment-hire-veterans-an",
        "display_url" : "whitehouse.gov\/blog\/2011\/10\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "129213301207994368",
    "text" : ".@PaulRieckhoff  We challenged private sector to hire 100k vets http:\/\/t.co\/ysQ05OL3 \nand #JobsAct would create tax credits to hire vets",
    "id" : 129213301207994368,
    "created_at" : "2011-10-26 15:10:26 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 129216090378211329,
  "created_at" : "2011-10-26 15:21:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dean T.Carson II CPA",
      "screen_name" : "DCarsonCPA",
      "indices" : [ 3, 14 ],
      "id_str" : "185622716",
      "id" : 185622716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/lNTTfTJl",
      "expanded_url" : "http:\/\/wh.gov\/tax-receipt",
      "display_url" : "wh.gov\/tax-receipt"
    } ]
  },
  "geo" : { },
  "id_str" : "129204372843401217",
  "text" : "RT @DCarsonCPA: Understand where your federal tax dollars are being spent with the White House tax receipt tool: http:\/\/t.co\/lNTTfTJl vi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 122, 133 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/lNTTfTJl",
        "expanded_url" : "http:\/\/wh.gov\/tax-receipt",
        "display_url" : "wh.gov\/tax-receipt"
      } ]
    },
    "geo" : { },
    "id_str" : "129202793214001152",
    "text" : "Understand where your federal tax dollars are being spent with the White House tax receipt tool: http:\/\/t.co\/lNTTfTJl via @whitehouse",
    "id" : 129202793214001152,
    "created_at" : "2011-10-26 14:28:41 +0000",
    "user" : {
      "name" : "Dean T.Carson II CPA",
      "screen_name" : "DCarsonCPA",
      "protected" : false,
      "id_str" : "185622716",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747630423442853888\/J6u1Pc_-_normal.jpg",
      "id" : 185622716,
      "verified" : false
    }
  },
  "id" : 129204372843401217,
  "created_at" : "2011-10-26 14:34:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Startups",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/ylQJMyBy",
      "expanded_url" : "http:\/\/ar.gy\/gnZ",
      "display_url" : "ar.gy\/gnZ"
    } ]
  },
  "geo" : { },
  "id_str" : "129199150054129664",
  "text" : "RT @startupamerica: 877 startups approved! Bring it on 1,000. Apply here: http:\/\/t.co\/ylQJMyBy #Startups create jobs.",
  "id" : 129199150054129664,
  "created_at" : "2011-10-26 14:14:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shannon McDonald",
      "screen_name" : "shan_mcd",
      "indices" : [ 3, 12 ],
      "id_str" : "364810030",
      "id" : 364810030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/yA0t3Rcr",
      "expanded_url" : "http:\/\/tinyurl.com\/64smhyy",
      "display_url" : "tinyurl.com\/64smhyy"
    } ]
  },
  "geo" : { },
  "id_str" : "129198904834134016",
  "text" : "RT @shan_mcd: For those drowning in debt from student loans... The White House may be giving you a hand. http:\/\/t.co\/yA0t3Rcr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/yA0t3Rcr",
        "expanded_url" : "http:\/\/tinyurl.com\/64smhyy",
        "display_url" : "tinyurl.com\/64smhyy"
      } ]
    },
    "geo" : { },
    "id_str" : "129194206404153344",
    "text" : "For those drowning in debt from student loans... The White House may be giving you a hand. http:\/\/t.co\/yA0t3Rcr",
    "id" : 129194206404153344,
    "created_at" : "2011-10-26 13:54:33 +0000",
    "user" : {
      "name" : "Shannon McDonald",
      "screen_name" : "shan_mcd",
      "protected" : false,
      "id_str" : "364810030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673677873077755904\/vhXynfEj_normal.jpg",
      "id" : 364810030,
      "verified" : false
    }
  },
  "id" : 129198904834134016,
  "created_at" : "2011-10-26 14:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129192928919826432",
  "text" : "RT @macon44: @followtheforum Many don't know u can cap paymnts @ 15% of income now. Confirm eligibility & who services loan here: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/3Nf5vOEQ",
        "expanded_url" : "http:\/\/1.usa.gov\/stLrFc",
        "display_url" : "1.usa.gov\/stLrFc"
      } ]
    },
    "in_reply_to_status_id_str" : "129172825322954752",
    "geo" : { },
    "id_str" : "129188124575277057",
    "in_reply_to_user_id" : 298271687,
    "text" : "@followtheforum Many don't know u can cap paymnts @ 15% of income now. Confirm eligibility & who services loan here: http:\/\/t.co\/3Nf5vOEQ",
    "id" : 129188124575277057,
    "in_reply_to_status_id" : 129172825322954752,
    "created_at" : "2011-10-26 13:30:23 +0000",
    "in_reply_to_screen_name" : "TheFutureForum",
    "in_reply_to_user_id_str" : "298271687",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 129192928919826432,
  "created_at" : "2011-10-26 13:49:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 84, 92 ],
      "id_str" : "232193350",
      "id" : 232193350
    }, {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 93, 105 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FWD",
      "indices" : [ 67, 71 ]
    }, {
      "text" : "AskFWD",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/KSni4fBt",
      "expanded_url" : "http:\/\/ow.ly\/79oJY",
      "display_url" : "ow.ly\/79oJY"
    } ]
  },
  "geo" : { },
  "id_str" : "129182675822067712",
  "text" : "Happening @ 12:30ET: Open for Questions on Horn of Africa crisis & #FWD campaign w\/ @rajshah @joncarson44. Use #AskFWD http:\/\/t.co\/KSni4fBt",
  "id" : 129182675822067712,
  "created_at" : "2011-10-26 13:08:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Leno",
      "screen_name" : "jayleno",
      "indices" : [ 58, 66 ],
      "id_str" : "35859588",
      "id" : 35859588
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/128982775440211968\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/SWY1m2L3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aco9JqCCAAA1KRL.jpg",
      "id_str" : "128982775444406272",
      "id" : 128982775444406272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aco9JqCCAAA1KRL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SWY1m2L3"
    } ],
    "hashtags" : [ {
      "text" : "TonightShow",
      "indices" : [ 40, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128982775440211968",
  "text" : "Tonight, President Obama appears on the #TonightShow with @JayLeno. Photo: Obama & Leno joke backstage: http:\/\/t.co\/SWY1m2L3",
  "id" : 128982775440211968,
  "created_at" : "2011-10-25 23:54:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/128979334559043584\/photo\/1",
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/hLP9Od75",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aco6BXxCEAA90-T.jpg",
      "id_str" : "128979334567432192",
      "id" : 128979334567432192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aco6BXxCEAA90-T.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/hLP9Od75"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/16R7WJEF",
      "expanded_url" : "http:\/\/ow.ly\/78UPJ",
      "display_url" : "ow.ly\/78UPJ"
    } ]
  },
  "geo" : { },
  "id_str" : "128979334559043584",
  "text" : "1:1. American Jobs Act by the Numbers: http:\/\/t.co\/16R7WJEF http:\/\/t.co\/hLP9Od75",
  "id" : 128979334559043584,
  "created_at" : "2011-10-25 23:40:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wecantwait",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/xDSBSjSM",
      "expanded_url" : "http:\/\/storify.com\/whitehouse\/wh-office-hours",
      "display_url" : "storify.com\/whitehouse\/wh-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128942762853801984",
  "text" : "RT @WHLive: Thanks for all your questions. If you missed anything, here's the full Q&A http:\/\/t.co\/xDSBSjSM. #Wecantwait to do it again. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Wecantwait",
        "indices" : [ 97, 108 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/xDSBSjSM",
        "expanded_url" : "http:\/\/storify.com\/whitehouse\/wh-office-hours",
        "display_url" : "storify.com\/whitehouse\/wh-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "128942214901542914",
    "text" : "Thanks for all your questions. If you missed anything, here's the full Q&A http:\/\/t.co\/xDSBSjSM. #Wecantwait to do it again. -Brian #WHChat",
    "id" : 128942214901542914,
    "created_at" : "2011-10-25 21:13:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 128942762853801984,
  "created_at" : "2011-10-25 21:15:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128942722827550720",
  "text" : "RT @WHLive: I've answered a bunch of questions -- now one for you: thinking about our next White House whiteboard, what topics should we ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128942635070132225",
    "text" : "I've answered a bunch of questions -- now one for you: thinking about our next White House whiteboard, what topics should we cover? #WHChat",
    "id" : 128942635070132225,
    "created_at" : "2011-10-25 21:14:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 128942722827550720,
  "created_at" : "2011-10-25 21:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Naomi Price",
      "screen_name" : "NaomiP47",
      "indices" : [ 13, 22 ],
      "id_str" : "377953728",
      "id" : 377953728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/UDyRHsrs",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/10\/11\/obama-administration-announces-selection-14-infrastructure-projects-be-e",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128937741907005440",
  "text" : "RT @WHLive: .@NaomiP47 We just expedited 14 infra projects bc of their job potential. http:\/\/t.co\/UDyRHsrs Congress should act on infra  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Naomi Price",
        "screen_name" : "NaomiP47",
        "indices" : [ 1, 10 ],
        "id_str" : "377953728",
        "id" : 377953728
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/UDyRHsrs",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/10\/11\/obama-administration-announces-selection-14-infrastructure-projects-be-e",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "128935963538894850",
    "text" : ".@NaomiP47 We just expedited 14 infra projects bc of their job potential. http:\/\/t.co\/UDyRHsrs Congress should act on infra jobs next week",
    "id" : 128935963538894850,
    "created_at" : "2011-10-25 20:48:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 128937741907005440,
  "created_at" : "2011-10-25 20:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Price",
      "screen_name" : "NaomiP47",
      "indices" : [ 3, 12 ],
      "id_str" : "377953728",
      "id" : 377953728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128937724320292864",
  "text" : "RT @NaomiP47: #WHChat Why doesn't President issue Executive Order to push infrastructure jobs\/agenda? Plain to see mediation w\/GOP, Boeh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128934791214153728",
    "text" : "#WHChat Why doesn't President issue Executive Order to push infrastructure jobs\/agenda? Plain to see mediation w\/GOP, Boehner DOES NOT work.",
    "id" : 128934791214153728,
    "created_at" : "2011-10-25 20:43:44 +0000",
    "user" : {
      "name" : "Naomi Price",
      "screen_name" : "NaomiP47",
      "protected" : false,
      "id_str" : "377953728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1566567237\/pissed-off-woman_2_normal.jpg",
      "id" : 377953728,
      "verified" : false
    }
  },
  "id" : 128937724320292864,
  "created_at" : "2011-10-25 20:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "David Mansdoerfer",
      "screen_name" : "DPMansdoerfer",
      "indices" : [ 13, 27 ],
      "id_str" : "29468074",
      "id" : 29468074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128928193934659585",
  "text" : "RT @WHLive: .@DPMansdoerfer many small biz can't get credit. Cutting their payroll taxes next yr provides capital to spend on jobs, inve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Mansdoerfer",
        "screen_name" : "DPMansdoerfer",
        "indices" : [ 1, 15 ],
        "id_str" : "29468074",
        "id" : 29468074
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128928075328143360",
    "text" : ".@DPMansdoerfer many small biz can't get credit. Cutting their payroll taxes next yr provides capital to spend on jobs, investments #WHChat",
    "id" : 128928075328143360,
    "created_at" : "2011-10-25 20:17:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 128928193934659585,
  "created_at" : "2011-10-25 20:17:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Mansdoerfer",
      "screen_name" : "DPMansdoerfer",
      "indices" : [ 3, 17 ],
      "id_str" : "29468074",
      "id" : 29468074
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128927605532536832",
  "text" : "RT @DPMansdoerfer: #whchat Since businesses think in the long run, will short-term tax cuts on the employer side do anything to increase ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128927275986075648",
    "text" : "#whchat Since businesses think in the long run, will short-term tax cuts on the employer side do anything to increase hiring?",
    "id" : 128927275986075648,
    "created_at" : "2011-10-25 20:13:52 +0000",
    "user" : {
      "name" : "David Mansdoerfer",
      "screen_name" : "DPMansdoerfer",
      "protected" : false,
      "id_str" : "29468074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1411746323\/DM1-e1306537607110-145x150_normal.jpg",
      "id" : 29468074,
      "verified" : false
    }
  },
  "id" : 128927605532536832,
  "created_at" : "2011-10-25 20:15:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128926951518904320",
  "text" : "RT @whlive: It's Brian, I'm here and ready to go. #WHChat \/\/ Ask your questions on the Jobs Act now -- use #WHChat",
  "id" : 128926951518904320,
  "created_at" : "2011-10-25 20:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 118, 125 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeCantWait",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128915721504829440",
  "text" : "RT @WHLive: Happening @ 4ET: Brian Deese, Natl Economic Council Dep Director, answers your Qs on why #WeCantWait from @WHLive. Use #WHCh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 106, 113 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeCantWait",
        "indices" : [ 89, 100 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128915673089966080",
    "text" : "Happening @ 4ET: Brian Deese, Natl Economic Council Dep Director, answers your Qs on why #WeCantWait from @WHLive. Use #WHChat to ask now.",
    "id" : 128915673089966080,
    "created_at" : "2011-10-25 19:27:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 128915721504829440,
  "created_at" : "2011-10-25 19:27:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 85, 90 ]
    }, {
      "text" : "vets",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/khjE6mTW",
      "expanded_url" : "http:\/\/ow.ly\/78rOJ",
      "display_url" : "ow.ly\/78rOJ"
    } ]
  },
  "geo" : { },
  "id_str" : "128868475887300609",
  "text" : "\"We Can\u2019t Wait: Supporting Our Veterans\" Announcing 2 new initiatives to help create #jobs for #vets: http:\/\/t.co\/khjE6mTW",
  "id" : 128868475887300609,
  "created_at" : "2011-10-25 16:20:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeCantWait",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/qgswSeXO",
      "expanded_url" : "http:\/\/ow.ly\/78fm6",
      "display_url" : "ow.ly\/78fm6"
    } ]
  },
  "geo" : { },
  "id_str" : "128841357086310400",
  "text" : "#WeCantWait for today's Office Hours: Obama's econ advisor Brian Deese answers your ?s @ 4ET via Twitter. Ask w #WHChat http:\/\/t.co\/qgswSeXO",
  "id" : 128841357086310400,
  "created_at" : "2011-10-25 14:32:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/NQoumawd",
      "expanded_url" : "http:\/\/ow.ly\/77K1w",
      "display_url" : "ow.ly\/77K1w"
    } ]
  },
  "geo" : { },
  "id_str" : "128658157147926529",
  "text" : "\"We can\u2019t wait for an increasingly dysfunctional Congress to do its job. Where they won't act, I will\" -President Obama http:\/\/t.co\/NQoumawd",
  "id" : 128658157147926529,
  "created_at" : "2011-10-25 02:24:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/U1XwWYIw",
      "expanded_url" : "http:\/\/ow.ly\/77zC4",
      "display_url" : "ow.ly\/77zC4"
    } ]
  },
  "geo" : { },
  "id_str" : "128593189610336256",
  "text" : "We can't wait. Important executive actions to help stabilize the housing market & help struggling American homeowners: http:\/\/t.co\/U1XwWYIw",
  "id" : 128593189610336256,
  "created_at" : "2011-10-24 22:06:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "128581615935963136",
  "text" : "Happening now: President Obama Speaks on the American Jobs Act. Watch live: http:\/\/t.co\/QDIpMRKE",
  "id" : 128581615935963136,
  "created_at" : "2011-10-24 21:20:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/ph92ewbd",
      "expanded_url" : "http:\/\/ow.ly\/77moQ",
      "display_url" : "ow.ly\/77moQ"
    } ]
  },
  "geo" : { },
  "id_str" : "128543445693366272",
  "text" : "We can't wait to help homeowners refinance their mortgages: http:\/\/t.co\/ph92ewbd",
  "id" : 128543445693366272,
  "created_at" : "2011-10-24 18:48:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/lqHz0db8",
      "expanded_url" : "http:\/\/ow.ly\/77e73",
      "display_url" : "ow.ly\/77e73"
    } ]
  },
  "geo" : { },
  "id_str" : "128520642634059776",
  "text" : "We can't wait. http:\/\/t.co\/lqHz0db8",
  "id" : 128520642634059776,
  "created_at" : "2011-10-24 17:18:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/oDIrjzGh",
      "expanded_url" : "http:\/\/ow.ly\/773Si",
      "display_url" : "ow.ly\/773Si"
    } ]
  },
  "geo" : { },
  "id_str" : "128496486337093632",
  "text" : "\"We stand shoulder to shoulder with our Turkish ally in this difficult time\" -President Obama on the Turkey earthquake: http:\/\/t.co\/oDIrjzGh",
  "id" : 128496486337093632,
  "created_at" : "2011-10-24 15:42:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/128466434325102593\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/2bnFL4xl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AchnipfCQAEB19J.jpg",
      "id_str" : "128466434329296897",
      "id" : 128466434329296897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AchnipfCQAEB19J.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/2bnFL4xl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/AXoPLYdc",
      "expanded_url" : "http:\/\/1.usa.gov\/nIvRSZ",
      "display_url" : "1.usa.gov\/nIvRSZ"
    } ]
  },
  "geo" : { },
  "id_str" : "128466434325102593",
  "text" : "1,500. The American Jobs Act by the Numbers: http:\/\/t.co\/AXoPLYdc http:\/\/t.co\/2bnFL4xl",
  "id" : 128466434325102593,
  "created_at" : "2011-10-24 13:42:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/n5gZlQ7Q",
      "expanded_url" : "http:\/\/ow.ly\/76cP2",
      "display_url" : "ow.ly\/76cP2"
    } ]
  },
  "geo" : { },
  "id_str" : "128179429271801856",
  "text" : "\"I congratulate the people of Libya on today\u2019s historic declaration of liberation\" -President Obama: http:\/\/t.co\/n5gZlQ7Q",
  "id" : 128179429271801856,
  "created_at" : "2011-10-23 18:42:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/bMzPJ3DY",
      "expanded_url" : "http:\/\/youtu.be\/fUcB1bUBhwk",
      "display_url" : "youtu.be\/fUcB1bUBhwk"
    } ]
  },
  "geo" : { },
  "id_str" : "128122897641373696",
  "text" : "President Obama on Iraq & Libya: \"Powerful reminders of how we\u2019ve renewed American leadership in the world\" http:\/\/t.co\/bMzPJ3DY",
  "id" : 128122897641373696,
  "created_at" : "2011-10-23 14:57:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/tWWESUCJ",
      "expanded_url" : "http:\/\/ow.ly\/1z3p5p",
      "display_url" : "ow.ly\/1z3p5p"
    } ]
  },
  "geo" : { },
  "id_str" : "127807648904130560",
  "text" : "WEEKLY ADDRESS: President Obama on bringing our troops home: http:\/\/t.co\/tWWESUCJ",
  "id" : 127807648904130560,
  "created_at" : "2011-10-22 18:04:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judith Broder",
      "screen_name" : "soldiersproject",
      "indices" : [ 34, 50 ],
      "id_str" : "250440413",
      "id" : 250440413
    }, {
      "name" : "New Directions Inc.",
      "screen_name" : "NDVets",
      "indices" : [ 51, 58 ],
      "id_str" : "337922864",
      "id" : 337922864
    }, {
      "name" : "TAKE Foundation",
      "screen_name" : "TAKEFoundation",
      "indices" : [ 59, 74 ],
      "id_str" : "69593121",
      "id" : 69593121
    }, {
      "name" : "Janice Langbehn",
      "screen_name" : "janicelangbehn",
      "indices" : [ 75, 90 ],
      "id_str" : "70918627",
      "id" : 70918627
    }, {
      "name" : "Harmony Project",
      "screen_name" : "HarmonyProject",
      "indices" : [ 91, 106 ],
      "id_str" : "68910374",
      "id" : 68910374
    }, {
      "name" : "Alfalit Int'l",
      "screen_name" : "Alfalit",
      "indices" : [ 107, 115 ],
      "id_str" : "68330935",
      "id" : 68330935
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "FF",
      "indices" : [ 137, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/vz4bpeXu",
      "expanded_url" : "http:\/\/ow.ly\/75i6k",
      "display_url" : "ow.ly\/75i6k"
    } ]
  },
  "geo" : { },
  "id_str" : "127524327900983296",
  "text" : "#FollowFriday Citizens medalists: @soldiersproject @NDVets @TAKEFoundation @janicelangbehn @HarmonyProject @Alfalit http:\/\/t.co\/vz4bpeXu #FF",
  "id" : 127524327900983296,
  "created_at" : "2011-10-21 23:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/efdhcnwG",
      "expanded_url" : "http:\/\/bit.ly\/qLa1m8",
      "display_url" : "bit.ly\/qLa1m8"
    } ]
  },
  "geo" : { },
  "id_str" : "127513708506251265",
  "text" : "RT @petesouza: Photo of potus vtc w Maliki in Sit Room: http:\/\/t.co\/efdhcnwG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/efdhcnwG",
        "expanded_url" : "http:\/\/bit.ly\/qLa1m8",
        "display_url" : "bit.ly\/qLa1m8"
      } ]
    },
    "geo" : { },
    "id_str" : "127511885674319872",
    "text" : "Photo of potus vtc w Maliki in Sit Room: http:\/\/t.co\/efdhcnwG",
    "id" : 127511885674319872,
    "created_at" : "2011-10-21 22:29:37 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 127513708506251265,
  "created_at" : "2011-10-21 22:36:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/7yLgwZUi",
      "expanded_url" : "http:\/\/youtu.be\/eG00mM8QEGk",
      "display_url" : "youtu.be\/eG00mM8QEGk"
    } ]
  },
  "geo" : { },
  "id_str" : "127512445303537664",
  "text" : "Lots of folks are talking about the 10 letters that President Obama reads everyday. Look behind the scenes: http:\/\/t.co\/7yLgwZUi",
  "id" : 127512445303537664,
  "created_at" : "2011-10-21 22:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "JenniferHatcher",
      "screen_name" : "Daroswene",
      "indices" : [ 74, 84 ],
      "id_str" : "35395312",
      "id" : 35395312
    }, {
      "name" : "Aria Patrick",
      "screen_name" : "Practicality",
      "indices" : [ 85, 98 ],
      "id_str" : "522922308",
      "id" : 522922308
    }, {
      "name" : "whatsamattausa",
      "screen_name" : "whatsamattausa",
      "indices" : [ 99, 114 ],
      "id_str" : "292575921",
      "id" : 292575921
    }, {
      "name" : "\u5F71\u6B66\u8005X",
      "screen_name" : "TrastX",
      "indices" : [ 115, 122 ],
      "id_str" : "4538471477",
      "id" : 4538471477
    }, {
      "name" : "Rebecca  Vietzen",
      "screen_name" : "mrsv98",
      "indices" : [ 123, 130 ],
      "id_str" : "23790033",
      "id" : 23790033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127498683989233665",
  "text" : "RT @WHLive: WH Office Hours on ending the war in Iraq: incl As to Qs from @Daroswene @practicality @whatsamattausa @TrastX @mrsv98: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JenniferHatcher",
        "screen_name" : "Daroswene",
        "indices" : [ 62, 72 ],
        "id_str" : "35395312",
        "id" : 35395312
      }, {
        "name" : "Aria Patrick",
        "screen_name" : "Practicality",
        "indices" : [ 73, 86 ],
        "id_str" : "522922308",
        "id" : 522922308
      }, {
        "name" : "whatsamattausa",
        "screen_name" : "whatsamattausa",
        "indices" : [ 87, 102 ],
        "id_str" : "292575921",
        "id" : 292575921
      }, {
        "name" : "\u5F71\u6B66\u8005X",
        "screen_name" : "TrastX",
        "indices" : [ 103, 110 ],
        "id_str" : "4538471477",
        "id" : 4538471477
      }, {
        "name" : "Rebecca  Vietzen",
        "screen_name" : "mrsv98",
        "indices" : [ 111, 118 ],
        "id_str" : "23790033",
        "id" : 23790033
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/4KGyoiqw",
        "expanded_url" : "http:\/\/sfy.co\/Kih",
        "display_url" : "sfy.co\/Kih"
      } ]
    },
    "geo" : { },
    "id_str" : "127498624841158656",
    "text" : "WH Office Hours on ending the war in Iraq: incl As to Qs from @Daroswene @practicality @whatsamattausa @TrastX @mrsv98: http:\/\/t.co\/4KGyoiqw",
    "id" : 127498624841158656,
    "created_at" : "2011-10-21 21:36:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127498683989233665,
  "created_at" : "2011-10-21 21:37:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127496838252208129",
  "text" : "RT @VP: Terrell McSweeny, VP's Domestic Policy Advisor, on consequences of Thurs night's Senate vote for safety of Americans http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/0xPaGlM1",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/10\/21\/why-there-no-time-waste-putting-cops-back-beat",
        "display_url" : "whitehouse.gov\/blog\/2011\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "127496311598612480",
    "text" : "Terrell McSweeny, VP's Domestic Policy Advisor, on consequences of Thurs night's Senate vote for safety of Americans http:\/\/t.co\/0xPaGlM1",
    "id" : 127496311598612480,
    "created_at" : "2011-10-21 21:27:44 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 127496838252208129,
  "created_at" : "2011-10-21 21:29:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/9zjm1uIR",
      "expanded_url" : "http:\/\/youtu.be\/G9Z7tdukQuo",
      "display_url" : "youtu.be\/G9Z7tdukQuo"
    } ]
  },
  "geo" : { },
  "id_str" : "127466418957594624",
  "text" : "VIDEO: President Obama on ending the war in Iraq: http:\/\/t.co\/9zjm1uIR",
  "id" : 127466418957594624,
  "created_at" : "2011-10-21 19:28:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127461055734620160",
  "text" : "RT @WHLive: Have to run -- thanks everyone for your questions. Hope to answer more soon. -Ben #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127460640993456128",
    "text" : "Have to run -- thanks everyone for your questions. Hope to answer more soon. -Ben #WHChat",
    "id" : 127460640993456128,
    "created_at" : "2011-10-21 19:05:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127461055734620160,
  "created_at" : "2011-10-21 19:07:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127461022578642944",
  "text" : "RT @WHLive: .@littlefuter Reductions real. 180K troops in wars when POTUS took office. Will be 90K by end of year. And going down. #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127460196242038785",
    "text" : ".@littlefuter Reductions real. 180K troops in wars when POTUS took office. Will be 90K by end of year. And going down. #WHChat",
    "id" : 127460196242038785,
    "created_at" : "2011-10-21 19:04:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127461022578642944,
  "created_at" : "2011-10-21 19:07:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127461011027542016",
  "text" : "RT @littlefuter: the troops are coming home? anyone else getting deja vu? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 57, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127459486133796865",
    "text" : "the troops are coming home? anyone else getting deja vu? #WHChat",
    "id" : 127459486133796865,
    "created_at" : "2011-10-21 19:01:24 +0000",
    "user" : {
      "name" : "Ian F.",
      "screen_name" : "thesuperjew13",
      "protected" : false,
      "id_str" : "314303677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2312506938\/361B6826-F665-40BD-9FEF-52DDBA2A1233_normal",
      "id" : 314303677,
      "verified" : false
    }
  },
  "id" : 127461011027542016,
  "created_at" : "2011-10-21 19:07:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "\u5F71\u6B66\u8005X",
      "screen_name" : "TrastX",
      "indices" : [ 13, 20 ],
      "id_str" : "4538471477",
      "id" : 4538471477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127457081136644096",
  "text" : "RT @WHLive: .@TrastX We're committed to helping vets find opportunity. 21st Cent GI Bill covers education. Jobs Act boosts vets employme ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u5F71\u6B66\u8005X",
        "screen_name" : "TrastX",
        "indices" : [ 1, 8 ],
        "id_str" : "4538471477",
        "id" : 4538471477
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127456808334925824",
    "text" : ".@TrastX We're committed to helping vets find opportunity. 21st Cent GI Bill covers education. Jobs Act boosts vets employment. #WHChat",
    "id" : 127456808334925824,
    "created_at" : "2011-10-21 18:50:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127457081136644096,
  "created_at" : "2011-10-21 18:51:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5F71\u6B66\u8005X",
      "screen_name" : "TrastX",
      "indices" : [ 3, 10 ],
      "id_str" : "4538471477",
      "id" : 4538471477
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 12, 19 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127457064745316354",
  "text" : "RT @TrastX: @WHLive How are these soon2be jobless soldiers going to provide for their families? #jobs #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 0, 7 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 84, 89 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127456069227261952",
    "in_reply_to_user_id" : 369505837,
    "text" : "@WHLive How are these soon2be jobless soldiers going to provide for their families? #jobs #WHChat",
    "id" : 127456069227261952,
    "created_at" : "2011-10-21 18:47:49 +0000",
    "in_reply_to_screen_name" : "WHLive",
    "in_reply_to_user_id_str" : "369505837",
    "user" : {
      "name" : "Steven Tucker",
      "screen_name" : "sTevyHD",
      "protected" : false,
      "id_str" : "75876806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3747151260\/e9699fd9b1b4cb7bc330ffffc7e02708_normal.jpeg",
      "id" : 75876806,
      "verified" : false
    }
  },
  "id" : 127457064745316354,
  "created_at" : "2011-10-21 18:51:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "whatsamattausa",
      "screen_name" : "whatsamattausa",
      "indices" : [ 13, 28 ],
      "id_str" : "292575921",
      "id" : 292575921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127456031931514880",
  "text" : "RT @WHLive: .@whatsamattausa No. We won't have any U.S. bases in Iraq. Will have an Embassy and close partnership. #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "whatsamattausa",
        "screen_name" : "whatsamattausa",
        "indices" : [ 1, 16 ],
        "id_str" : "292575921",
        "id" : 292575921
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127455077878333443",
    "text" : ".@whatsamattausa No. We won't have any U.S. bases in Iraq. Will have an Embassy and close partnership. #WHChat",
    "id" : 127455077878333443,
    "created_at" : "2011-10-21 18:43:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127456031931514880,
  "created_at" : "2011-10-21 18:47:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whatsamattausa",
      "screen_name" : "whatsamattausa",
      "indices" : [ 3, 18 ],
      "id_str" : "292575921",
      "id" : 292575921
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 20, 27 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127456018786553856",
  "text" : "RT @whatsamattausa: @whlive will US still have operational bases in Iraq after withdraw? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 0, 7 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127454239625719808",
    "in_reply_to_user_id" : 369505837,
    "text" : "@whlive will US still have operational bases in Iraq after withdraw? #WHChat",
    "id" : 127454239625719808,
    "created_at" : "2011-10-21 18:40:33 +0000",
    "in_reply_to_screen_name" : "WHLive",
    "in_reply_to_user_id_str" : "369505837",
    "user" : {
      "name" : "whatsamattausa",
      "screen_name" : "whatsamattausa",
      "protected" : false,
      "id_str" : "292575921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1565644388\/whatsamattausa_normal.gif",
      "id" : 292575921,
      "verified" : false
    }
  },
  "id" : 127456018786553856,
  "created_at" : "2011-10-21 18:47:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "JenniferHatcher",
      "screen_name" : "Daroswene",
      "indices" : [ 13, 23 ],
      "id_str" : "35395312",
      "id" : 35395312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127454685488611328",
  "text" : "RT @WHLive: .@Daroswene At peak of war Iraq cost over $100 billion per year. Now we can invest that money at home. #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JenniferHatcher",
        "screen_name" : "Daroswene",
        "indices" : [ 1, 11 ],
        "id_str" : "35395312",
        "id" : 35395312
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127454443397578752",
    "text" : ".@Daroswene At peak of war Iraq cost over $100 billion per year. Now we can invest that money at home. #WHChat",
    "id" : 127454443397578752,
    "created_at" : "2011-10-21 18:41:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127454685488611328,
  "created_at" : "2011-10-21 18:42:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JenniferHatcher",
      "screen_name" : "Daroswene",
      "indices" : [ 3, 13 ],
      "id_str" : "35395312",
      "id" : 35395312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "jobs",
      "indices" : [ 68, 73 ]
    }, {
      "text" : "infrastructure",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127454669546065920",
  "text" : "RT @Daroswene: #whchat will $ for defense be shifted to assist with #jobs or #infrastructure since the war is essentially over?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "jobs",
        "indices" : [ 53, 58 ]
      }, {
        "text" : "infrastructure",
        "indices" : [ 62, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127453979834724352",
    "text" : "#whchat will $ for defense be shifted to assist with #jobs or #infrastructure since the war is essentially over?",
    "id" : 127453979834724352,
    "created_at" : "2011-10-21 18:39:31 +0000",
    "user" : {
      "name" : "JenniferHatcher",
      "screen_name" : "Daroswene",
      "protected" : false,
      "id_str" : "35395312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628311290012790784\/i96A6U24_normal.png",
      "id" : 35395312,
      "verified" : false
    }
  },
  "id" : 127454669546065920,
  "created_at" : "2011-10-21 18:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127453896149966849",
  "text" : "RT @WHLive: Hey everyone \u2013 Ben here, Dep Natl Security Advisor to Obama. Here to answer some Qs on today\u2019s announcement. Use #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 113, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127452761393602560",
    "text" : "Hey everyone \u2013 Ben here, Dep Natl Security Advisor to Obama. Here to answer some Qs on today\u2019s announcement. Use #WHChat",
    "id" : 127452761393602560,
    "created_at" : "2011-10-21 18:34:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127453896149966849,
  "created_at" : "2011-10-21 18:39:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 123, 130 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127448925094420481",
  "text" : "Obama announces US troops in Iraq will be home by the end of the year. Have Qs? Use #WHChat to ask now. Ben Rhodes answers @WHLive @ 2:30ET",
  "id" : 127448925094420481,
  "created_at" : "2011-10-21 18:19:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127430801775276032",
  "text" : "RT @WHLive: WH Office Hours: Natl Security Advisor Ben Rhodes will be here @ 2:30ET to answer your Qs about ending the war in Iraq. Ask  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127430667129733121",
    "text" : "WH Office Hours: Natl Security Advisor Ben Rhodes will be here @ 2:30ET to answer your Qs about ending the war in Iraq. Ask now: #WHChat",
    "id" : 127430667129733121,
    "created_at" : "2011-10-21 17:06:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127430801775276032,
  "created_at" : "2011-10-21 17:07:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127428787414630400",
  "text" : "Obama: the nation that we need to build\u2014that we will build\u2014is our own; an America that sees its economic strength restored",
  "id" : 127428787414630400,
  "created_at" : "2011-10-21 16:59:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127427517786226688",
  "text" : "Obama: The long war in Iraq will come to an end, the transition in Afghanistan is moving forward & our troops are coming home.",
  "id" : 127427517786226688,
  "created_at" : "2011-10-21 16:54:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127427063564079104",
  "text" : "\"Today, I can say to our troops in Iraq\u2014you\u2019re definitely coming home for the holidays.\" -President Barack Obama",
  "id" : 127427063564079104,
  "created_at" : "2011-10-21 16:52:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127426875571175424",
  "text" : "Obama: This will be a strong & enduring partnership...we\u2019ll help Iraqis strengthen institutions that are just, representative & accountable",
  "id" : 127426875571175424,
  "created_at" : "2011-10-21 16:51:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127426379913498624",
  "text" : "Obama: Today, I can report that, as promised, the rest of our troops in Iraq will come home by the end of this year.",
  "id" : 127426379913498624,
  "created_at" : "2011-10-21 16:49:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "127426174958845952",
  "text" : "Happening now: President Obama delivers remarks on ending the war in Iraq. Watch live: http:\/\/t.co\/QDIpMRKE",
  "id" : 127426174958845952,
  "created_at" : "2011-10-21 16:49:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 1, 12 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/4thXkgNW",
      "expanded_url" : "http:\/\/1.usa.gov\/qxMF2M",
      "display_url" : "1.usa.gov\/qxMF2M"
    } ]
  },
  "geo" : { },
  "id_str" : "127418106837614592",
  "text" : ".@USTradeRep Kirk: President Obama signs historic legislation signaling progress on trade & #jobsnow: http:\/\/t.co\/4thXkgNW",
  "id" : 127418106837614592,
  "created_at" : "2011-10-21 16:16:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/127374643395964930\/photo\/1",
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/OBJyo7kr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AcSGkDWCMAAkGok.jpg",
      "id_str" : "127374643404353536",
      "id" : 127374643404353536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AcSGkDWCMAAkGok.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/OBJyo7kr"
    } ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/9KBNedRG",
      "expanded_url" : "http:\/\/1.usa.gov\/rn1ndc",
      "display_url" : "1.usa.gov\/rn1ndc"
    } ]
  },
  "geo" : { },
  "id_str" : "127374643395964930",
  "text" : "Zero. American #JobsNow Act by the numbers: http:\/\/t.co\/9KBNedRG http:\/\/t.co\/OBJyo7kr",
  "id" : 127374643395964930,
  "created_at" : "2011-10-21 13:24:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127232907562594305",
  "text" : "RT @jesseclee44: Obama: \"every American deserves an explanation as to why Republicans refuse to step up to the plate and do what\u2019s neces ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127232797139156992",
    "text" : "Obama: \"every American deserves an explanation as to why Republicans refuse to step up to the plate and do what\u2019s necessary to create jobs\"",
    "id" : 127232797139156992,
    "created_at" : "2011-10-21 04:00:37 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 127232907562594305,
  "created_at" : "2011-10-21 04:01:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 109, 112 ]
    }, {
      "text" : "tcot",
      "indices" : [ 113, 118 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 119, 127 ]
    }, {
      "text" : "TrueStories",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/iv5ayqcf",
      "expanded_url" : "http:\/\/www.reuters.com\/article\/2011\/10\/21\/us-usa-jobs-teachers-idUSTRE79K0D120111021",
      "display_url" : "reuters.com\/article\/2011\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127218090634248192",
  "text" : "RT @jesseclee44: Correct... Reuters: Republicans block popular piece of Obama jobs bill http:\/\/t.co\/iv5ayqcf #p2 #tcot #JobsNow #TrueStories",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 92, 95 ]
      }, {
        "text" : "tcot",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "JobsNow",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "TrueStories",
        "indices" : [ 111, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/iv5ayqcf",
        "expanded_url" : "http:\/\/www.reuters.com\/article\/2011\/10\/21\/us-usa-jobs-teachers-idUSTRE79K0D120111021",
        "display_url" : "reuters.com\/article\/2011\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "127212705688981504",
    "text" : "Correct... Reuters: Republicans block popular piece of Obama jobs bill http:\/\/t.co\/iv5ayqcf #p2 #tcot #JobsNow #TrueStories",
    "id" : 127212705688981504,
    "created_at" : "2011-10-21 02:40:47 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 127218090634248192,
  "created_at" : "2011-10-21 03:02:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 43, 53 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/3hKNpei6",
      "expanded_url" : "http:\/\/ow.ly\/749Y8",
      "display_url" : "ow.ly\/749Y8"
    } ]
  },
  "geo" : { },
  "id_str" : "127203445479440384",
  "text" : "American Jobs Act bus tour in pictures via @petesouza: http:\/\/t.co\/3hKNpei6 #JobsNow",
  "id" : 127203445479440384,
  "created_at" : "2011-10-21 02:03:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/p5xp6loE",
      "expanded_url" : "http:\/\/youtu.be\/IzX-FWgxEpE",
      "display_url" : "youtu.be\/IzX-FWgxEpE"
    } ]
  },
  "geo" : { },
  "id_str" : "127189011356860416",
  "text" : "\"This is a momentous day in the history of #Libya\" Watch President Obama's remarks on the death of Qaddafi: http:\/\/t.co\/p5xp6loE",
  "id" : 127189011356860416,
  "created_at" : "2011-10-21 01:06:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/B39QtyOv",
      "expanded_url" : "http:\/\/youtu.be\/3Pze1f1x7yU",
      "display_url" : "youtu.be\/3Pze1f1x7yU"
    } ]
  },
  "geo" : { },
  "id_str" : "127177063470866432",
  "text" : "RT @JoiningForces: WATCH: The First Lady's first tweet: http:\/\/t.co\/B39QtyOv #JoiningForces",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 58, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/B39QtyOv",
        "expanded_url" : "http:\/\/youtu.be\/3Pze1f1x7yU",
        "display_url" : "youtu.be\/3Pze1f1x7yU"
      } ]
    },
    "geo" : { },
    "id_str" : "127173172469579776",
    "text" : "WATCH: The First Lady's first tweet: http:\/\/t.co\/B39QtyOv #JoiningForces",
    "id" : 127173172469579776,
    "created_at" : "2011-10-21 00:03:41 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 127177063470866432,
  "created_at" : "2011-10-21 00:19:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Root",
      "screen_name" : "theroot247",
      "indices" : [ 44, 55 ],
      "id_str" : "2293123297",
      "id" : 2293123297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheRootWH",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "127133894620356608",
  "text" : "Happening @ 5:30ET: Open for Questions with @TheRoot247 on the Jobs Act. Watch live: http:\/\/t.co\/hhNoX4fh Ask Qs: #TheRootWH",
  "id" : 127133894620356608,
  "created_at" : "2011-10-20 21:27:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 1, 12 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SpiritDay",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/OQGCPYDr",
      "expanded_url" : "http:\/\/1.usa.gov\/pVgDyP",
      "display_url" : "1.usa.gov\/pVgDyP"
    } ]
  },
  "geo" : { },
  "id_str" : "127126621726572544",
  "text" : ".@WhiteHouse goes purple for #SpiritDay: http:\/\/t.co\/OQGCPYDr",
  "id" : 127126621726572544,
  "created_at" : "2011-10-20 20:58:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/RC2GzYu7",
      "expanded_url" : "http:\/\/ow.ly\/73XNU",
      "display_url" : "ow.ly\/73XNU"
    } ]
  },
  "geo" : { },
  "id_str" : "127125246707896320",
  "text" : "President Obama's remarks on the death of Muammar el-Qaddafi: http:\/\/t.co\/RC2GzYu7",
  "id" : 127125246707896320,
  "created_at" : "2011-10-20 20:53:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Root",
      "screen_name" : "theroot247",
      "indices" : [ 3, 14 ],
      "id_str" : "2293123297",
      "id" : 2293123297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MelodyBarnes",
      "indices" : [ 96, 109 ]
    }, {
      "text" : "ValerieJarrett",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127117743798484992",
  "text" : "RT @TheRoot247: Headed to the White House, and we'd like you to tag along. Watch our convo with #MelodyBarnes and #ValerieJarrett at 5:3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MelodyBarnes",
        "indices" : [ 80, 93 ]
      }, {
        "text" : "ValerieJarrett",
        "indices" : [ 98, 113 ]
      }, {
        "text" : "TheRootWH",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127112391484915714",
    "text" : "Headed to the White House, and we'd like you to tag along. Watch our convo with #MelodyBarnes and #ValerieJarrett at 5:30 pm. #TheRootWH",
    "id" : 127112391484915714,
    "created_at" : "2011-10-20 20:02:10 +0000",
    "user" : {
      "name" : "The Root",
      "screen_name" : "TheRoot",
      "protected" : false,
      "id_str" : "23995748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743477811957071873\/o-MJ9LEk_normal.jpg",
      "id" : 23995748,
      "verified" : true
    }
  },
  "id" : 127117743798484992,
  "created_at" : "2011-10-20 20:23:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/tOVqQ5CT",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "127087451759058944",
  "text" : "RT @WHLive: Happening now: President Obama awards the 2011 Presidential Citizens Medal. Watch live: http:\/\/t.co\/tOVqQ5CT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/tOVqQ5CT",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "127087361254375424",
    "text" : "Happening now: President Obama awards the 2011 Presidential Citizens Medal. Watch live: http:\/\/t.co\/tOVqQ5CT",
    "id" : 127087361254375424,
    "created_at" : "2011-10-20 18:22:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127087451759058944,
  "created_at" : "2011-10-20 18:23:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127084133393498112",
  "text" : "RT @WHLive: Obama: There will be difficult days. But the United States \u2013 together with the international community \u2013 is committed to the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127084090657734657",
    "text" : "Obama: There will be difficult days. But the United States \u2013 together with the international community \u2013 is committed to the Libyan people.",
    "id" : 127084090657734657,
    "created_at" : "2011-10-20 18:09:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127084133393498112,
  "created_at" : "2011-10-20 18:09:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127083664625504257",
  "text" : "RT @WHLive: \"Today, we can definitively say that the Qadhafi regime has come to an end\" -President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127083585994899457",
    "text" : "\"Today, we can definitively say that the Qadhafi regime has come to an end\" -President Obama",
    "id" : 127083585994899457,
    "created_at" : "2011-10-20 18:07:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 127083664625504257,
  "created_at" : "2011-10-20 18:08:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "127083404373143552",
  "text" : "Happening now: President Obama speaks to the press from the Rose Garden of the White House. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 127083404373143552,
  "created_at" : "2011-10-20 18:06:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "127062482404642816",
  "text" : "2:00 ET: President Obama makes a statement in the Rose Garden. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 127062482404642816,
  "created_at" : "2011-10-20 16:43:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CuttingWaste",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/EZnPYt7H",
      "expanded_url" : "http:\/\/ow.ly\/73wLu",
      "display_url" : "ow.ly\/73wLu"
    } ]
  },
  "geo" : { },
  "id_str" : "127045117889626113",
  "text" : "#CuttingWaste by getting rid of buildings we don't need. Explore the interactive map: http:\/\/t.co\/EZnPYt7H",
  "id" : 127045117889626113,
  "created_at" : "2011-10-20 15:34:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/gxn0oKMg",
      "expanded_url" : "http:\/\/1.usa.gov\/o36MxR",
      "display_url" : "1.usa.gov\/o36MxR"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/r0BTsJcS",
      "expanded_url" : "http:\/\/youtu.be\/4lk9QOaOZ60",
      "display_url" : "youtu.be\/4lk9QOaOZ60"
    } ]
  },
  "geo" : { },
  "id_str" : "127028214462820352",
  "text" : "Today, Obama honors 2011 Citizens Medal recipients: http:\/\/t.co\/gxn0oKMg Video: Winners respond to the news: http:\/\/t.co\/r0BTsJcS",
  "id" : 127028214462820352,
  "created_at" : "2011-10-20 14:27:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLB",
      "screen_name" : "MLB",
      "indices" : [ 3, 7 ],
      "id_str" : "18479513",
      "id" : 18479513
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldSeries",
      "indices" : [ 70, 82 ]
    }, {
      "text" : "JoiningForces",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/pW9MUKPY",
      "expanded_url" : "http:\/\/atmlb.com\/qlzYkM",
      "display_url" : "atmlb.com\/qlzYkM"
    } ]
  },
  "geo" : { },
  "id_str" : "126838216941780992",
  "text" : "RT @MLB: First lady Michelle Obama honors veterans prior to Game 1 of #WorldSeries: http:\/\/t.co\/pW9MUKPY #JoiningForces",
  "id" : 126838216941780992,
  "created_at" : "2011-10-20 01:52:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126803932428238848",
  "text" : "RT @JoiningForces: Military families serve our nation too. Let's all show our appreciation by #JoiningForces with them. Get involved: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 75, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/YryjAhl5",
        "expanded_url" : "http:\/\/JoiningForces.gov",
        "display_url" : "JoiningForces.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "126802980115718144",
    "text" : "Military families serve our nation too. Let's all show our appreciation by #JoiningForces with them. Get involved: http:\/\/t.co\/YryjAhl5 \u2013mo",
    "id" : 126802980115718144,
    "created_at" : "2011-10-19 23:32:41 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 126803932428238848,
  "created_at" : "2011-10-19 23:36:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 9, 17 ]
    }, {
      "text" : "Chesterfield",
      "indices" : [ 75, 88 ]
    }, {
      "text" : "Virginia",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/y2dk7hcd",
      "expanded_url" : "http:\/\/ow.ly\/72OIk",
      "display_url" : "ow.ly\/72OIk"
    } ]
  },
  "geo" : { },
  "id_str" : "126791525693784064",
  "text" : "American #JobsNow Act Bus Tour: President Obama stops by Fire Station 9 in #Chesterfield #Virginia: http:\/\/t.co\/y2dk7hcd",
  "id" : 126791525693784064,
  "created_at" : "2011-10-19 22:47:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126768714858250240",
  "text" : "RT @jesseclee44: Obama at the Fire Station: \"dirtier air, dirtier water\u2026less accountability on Wall Street -- that is not a jobs plan\" h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/PUbjzt0d",
        "expanded_url" : "http:\/\/wh.gov\/Tcg",
        "display_url" : "wh.gov\/Tcg"
      } ]
    },
    "geo" : { },
    "id_str" : "126767539496820736",
    "text" : "Obama at the Fire Station: \"dirtier air, dirtier water\u2026less accountability on Wall Street -- that is not a jobs plan\" http:\/\/t.co\/PUbjzt0d",
    "id" : 126767539496820736,
    "created_at" : "2011-10-19 21:11:51 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 126768714858250240,
  "created_at" : "2011-10-19 21:16:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126741664902549504",
  "text" : "RT @PressSec: Oddly, GOP lawmakers get mad when POTUS meets with ordinary Americans & hears their demand that Washington do something on ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 123, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126728872208236544",
    "text" : "Oddly, GOP lawmakers get mad when POTUS meets with ordinary Americans & hears their demand that Washington do something on #jobs now.",
    "id" : 126728872208236544,
    "created_at" : "2011-10-19 18:38:12 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 126741664902549504,
  "created_at" : "2011-10-19 19:29:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 66, 75 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126736615908442112",
  "text" : "RT @JonCarson44: $5,600: the tax credit for businesses that hire  #veterans who have been unemployed six months or longer. #JobsNow  htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 49, 58 ]
      }, {
        "text" : "JobsNow",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/UHemjKUW",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/10\/19\/american-jobs-act-numbers-5600",
        "display_url" : "whitehouse.gov\/blog\/2011\/10\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "126733626888028160",
    "text" : "$5,600: the tax credit for businesses that hire  #veterans who have been unemployed six months or longer. #JobsNow  http:\/\/t.co\/UHemjKUW",
    "id" : 126733626888028160,
    "created_at" : "2011-10-19 18:57:05 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 126736615908442112,
  "created_at" : "2011-10-19 19:08:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126735580745842688",
  "text" : "5,600. The American #JobsNow Act by the Numbers: goo.gl\/fb\/oVI7",
  "id" : 126735580745842688,
  "created_at" : "2011-10-19 19:04:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 3, 15 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/0wguKp9q",
      "expanded_url" : "http:\/\/1.usa.gov\/o9BtW7",
      "display_url" : "1.usa.gov\/o9BtW7"
    } ]
  },
  "geo" : { },
  "id_str" : "126726960956178433",
  "text" : "RT @CommerceGov: Business and Civic Leaders Support John Bryson for Commerce Secretary. Read what folks say http:\/\/t.co\/0wguKp9q (via @w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 117, 128 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "The White House Blog",
        "screen_name" : "blog44",
        "indices" : [ 129, 136 ],
        "id_str" : "278776049",
        "id" : 278776049
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/0wguKp9q",
        "expanded_url" : "http:\/\/1.usa.gov\/o9BtW7",
        "display_url" : "1.usa.gov\/o9BtW7"
      } ]
    },
    "geo" : { },
    "id_str" : "126712447162781696",
    "text" : "Business and Civic Leaders Support John Bryson for Commerce Secretary. Read what folks say http:\/\/t.co\/0wguKp9q (via @whitehouse @blog44)",
    "id" : 126712447162781696,
    "created_at" : "2011-10-19 17:32:56 +0000",
    "user" : {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "protected" : false,
      "id_str" : "110541296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645983513712459776\/3Q0H2IVF_normal.jpg",
      "id" : 110541296,
      "verified" : true
    }
  },
  "id" : 126726960956178433,
  "created_at" : "2011-10-19 18:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 116, 127 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hampton",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126700081528315905",
  "text" : "RT @ks44: Photo: President & First Lady stop by Wood's Orchard in #Hampton & pick up some pumpkins to bring back to @whitehouse: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 106, 117 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hampton",
        "indices" : [ 56, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/Il5LD3vu",
        "expanded_url" : "http:\/\/yfrog.com\/ob4cullj",
        "display_url" : "yfrog.com\/ob4cullj"
      } ]
    },
    "geo" : { },
    "id_str" : "126699944915640320",
    "text" : "Photo: President & First Lady stop by Wood's Orchard in #Hampton & pick up some pumpkins to bring back to @whitehouse: http:\/\/t.co\/Il5LD3vu",
    "id" : 126699944915640320,
    "created_at" : "2011-10-19 16:43:15 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 126700081528315905,
  "created_at" : "2011-10-19 16:43:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "military",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126672059723038720",
  "text" : "RT @JoiningForces: The First Lady just announced major private sector commitment to hire 25,000 #veterans & #military spouses in support ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 77, 86 ]
      }, {
        "text" : "military",
        "indices" : [ 89, 98 ]
      }, {
        "text" : "JoiningForces",
        "indices" : [ 121, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126671558793101313",
    "text" : "The First Lady just announced major private sector commitment to hire 25,000 #veterans & #military spouses in support of #JoiningForces",
    "id" : 126671558793101313,
    "created_at" : "2011-10-19 14:50:27 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 126672059723038720,
  "created_at" : "2011-10-19 14:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VA",
      "indices" : [ 87, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "126668259272560640",
  "text" : "Starting soon: The President & First Lady speak @ Joint Base Langley-Eustis in Hampton #VA. Watch live: http:\/\/t.co\/QDIpMRKE",
  "id" : 126668259272560640,
  "created_at" : "2011-10-19 14:37:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "education",
      "indices" : [ 45, 55 ]
    }, {
      "text" : "Emporia",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/8Xa58ZOg",
      "expanded_url" : "http:\/\/1.usa.gov\/q4OcPG",
      "display_url" : "1.usa.gov\/q4OcPG"
    } ]
  },
  "geo" : { },
  "id_str" : "126649122282414080",
  "text" : "#JobsNow Act Bus Tour: President Obama talks #education in #Emporia: http:\/\/t.co\/8Xa58ZOg",
  "id" : 126649122282414080,
  "created_at" : "2011-10-19 13:21:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Root",
      "screen_name" : "theroot247",
      "indices" : [ 27, 38 ],
      "id_str" : "2293123297",
      "id" : 2293123297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/9nxaRT2w",
      "expanded_url" : "http:\/\/ow.ly\/71ICO",
      "display_url" : "ow.ly\/71ICO"
    } ]
  },
  "geo" : { },
  "id_str" : "126513864224423936",
  "text" : "WH Open for Questions with @TheRoot247: Submit your questions on the Jobs Act now & tune in live on Thurs: http:\/\/t.co\/9nxaRT2w",
  "id" : 126513864224423936,
  "created_at" : "2011-10-19 04:23:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/GLkjWmz0",
      "expanded_url" : "http:\/\/1.usa.gov\/riRDY1",
      "display_url" : "1.usa.gov\/riRDY1"
    } ]
  },
  "geo" : { },
  "id_str" : "126425109715103745",
  "text" : "Dismantling the myths around Wall St Reform: A Look at U.S. Competitiveness: http:\/\/t.co\/GLkjWmz0",
  "id" : 126425109715103745,
  "created_at" : "2011-10-18 22:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126418205198663680",
  "text" : "RT @WHLive: Obama: Teachers build the good parts of this economy. They give our kids a chance...our plan means nearly 11k education jobs ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VA",
        "indices" : [ 128, 131 ]
      }, {
        "text" : "jobsnow",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126418130187726849",
    "text" : "Obama: Teachers build the good parts of this economy. They give our kids a chance...our plan means nearly 11k education jobs in #VA #jobsnow",
    "id" : 126418130187726849,
    "created_at" : "2011-10-18 22:03:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 126418205198663680,
  "created_at" : "2011-10-18 22:03:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/xrOHuqTm",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "126414521928654848",
  "text" : "RT @WHLive: Obama: It will take time to rebuild an America where hard work is valued & responsibility is rewarded. http:\/\/t.co\/xrOHuqTm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/xrOHuqTm",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "126414434892644353",
    "text" : "Obama: It will take time to rebuild an America where hard work is valued & responsibility is rewarded. http:\/\/t.co\/xrOHuqTm",
    "id" : 126414434892644353,
    "created_at" : "2011-10-18 21:48:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 126414521928654848,
  "created_at" : "2011-10-18 21:49:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 123, 130 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Emporia",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "VA",
      "indices" : [ 39, 42 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "126413192338485248",
  "text" : "Just started: Obama speaks in #Emporia #VA on the American #JobsNow Act bus tour. Watch live: http:\/\/t.co\/hhNoX4fh Follow: @WHLive",
  "id" : 126413192338485248,
  "created_at" : "2011-10-18 21:43:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 43, 51 ]
    }, {
      "text" : "Emporia",
      "indices" : [ 88, 96 ]
    }, {
      "text" : "VA",
      "indices" : [ 97, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "126401162705518592",
  "text" : "Happening @ 5ET: President Obama speaks on #JobsNow @ Greensville County High School in #Emporia #VA. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 126401162705518592,
  "created_at" : "2011-10-18 20:56:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/126390353313021952\/photo\/1",
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/uJ1ayUbM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AcEHW1CCQAEri3a.jpg",
      "id_str" : "126390353317216257",
      "id" : 126390353317216257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AcEHW1CCQAEri3a.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/uJ1ayUbM"
    } ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/nVVoIjt4",
      "expanded_url" : "http:\/\/1.usa.gov\/mXIec6",
      "display_url" : "1.usa.gov\/mXIec6"
    } ]
  },
  "geo" : { },
  "id_str" : "126390353313021952",
  "text" : "40. American #JobsNow Act by the Numbers: http:\/\/t.co\/nVVoIjt4 http:\/\/t.co\/uJ1ayUbM",
  "id" : 126390353313021952,
  "created_at" : "2011-10-18 20:13:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126369593311768576",
  "text" : "RT @PressSec: Republicans sure seem upset about POTUS explaining to folks in NC & VA why Congress needs to pass the Jobs Act. Must be hi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126366097246126080",
    "text" : "Republicans sure seem upset about POTUS explaining to folks in NC & VA why Congress needs to pass the Jobs Act. Must be hitting a nerve.",
    "id" : 126366097246126080,
    "created_at" : "2011-10-18 18:36:40 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 126369593311768576,
  "created_at" : "2011-10-18 18:50:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 40, 54 ]
    }, {
      "text" : "WorldSeries",
      "indices" : [ 101, 113 ]
    }, {
      "text" : "AskMichelle",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126362579164610561",
  "text" : "RT @JoiningForces: Have questions about #JoiningForces? The First Lady & Dr. Biden answer some @ the #WorldSeries. Use #AskMichelle http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 21, 35 ]
      }, {
        "text" : "WorldSeries",
        "indices" : [ 82, 94 ]
      }, {
        "text" : "AskMichelle",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/WbAcGeAp",
        "expanded_url" : "http:\/\/1.usa.gov\/oQ957h",
        "display_url" : "1.usa.gov\/oQ957h"
      } ]
    },
    "geo" : { },
    "id_str" : "126362207192756225",
    "text" : "Have questions about #JoiningForces? The First Lady & Dr. Biden answer some @ the #WorldSeries. Use #AskMichelle http:\/\/t.co\/WbAcGeAp",
    "id" : 126362207192756225,
    "created_at" : "2011-10-18 18:21:12 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 126362579164610561,
  "created_at" : "2011-10-18 18:22:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/126322389503053824\/photo\/1",
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/rO7kwOwY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AcDJi0HCEAAQd9L.jpg",
      "id_str" : "126322389507248128",
      "id" : 126322389507248128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AcDJi0HCEAAQd9L.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1632
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rO7kwOwY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126326849256173568",
  "text" : "RT @VP: PHOTO: VP drops by a classroom @ Goode Elementary School in York, PA http:\/\/t.co\/rO7kwOwY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/126322389503053824\/photo\/1",
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/rO7kwOwY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AcDJi0HCEAAQd9L.jpg",
        "id_str" : "126322389507248128",
        "id" : 126322389507248128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AcDJi0HCEAAQd9L.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1224,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rO7kwOwY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126322389503053824",
    "text" : "PHOTO: VP drops by a classroom @ Goode Elementary School in York, PA http:\/\/t.co\/rO7kwOwY",
    "id" : 126322389503053824,
    "created_at" : "2011-10-18 15:43:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 126326849256173568,
  "created_at" : "2011-10-18 16:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "Jamestown",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "NC",
      "indices" : [ 98, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "126316407418925056",
  "text" : "Happening @ 11:20ET: Obama speaks on #JobsNow Act @ Guilford Tech Community College in #Jamestown #NC. Audio: http:\/\/t.co\/hhNoX4fh",
  "id" : 126316407418925056,
  "created_at" : "2011-10-18 15:19:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/126296534311636993\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/u9xoToCF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AcCyB2BCEAEEp-0.jpg",
      "id_str" : "126296534315831297",
      "id" : 126296534315831297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AcCyB2BCEAEEp-0.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/u9xoToCF"
    } ],
    "hashtags" : [ {
      "text" : "Boone",
      "indices" : [ 64, 70 ]
    }, {
      "text" : "NC",
      "indices" : [ 71, 74 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126296534311636993",
  "text" : "Photo of the Day: President Obama waves to folks on the road in #Boone #NC during his 3-day #JobsNow Act bus tour: http:\/\/t.co\/u9xoToCF",
  "id" : 126296534311636993,
  "created_at" : "2011-10-18 14:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/FPijBeWL",
      "expanded_url" : "http:\/\/go.ostp.gov\/rhFBAU",
      "display_url" : "go.ostp.gov\/rhFBAU"
    } ]
  },
  "geo" : { },
  "id_str" : "126084703395643393",
  "text" : "RT @whitehouseostp: President Obama Meets Nation's Cutting-Edge Researchers http:\/\/t.co\/FPijBeWL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/FPijBeWL",
        "expanded_url" : "http:\/\/go.ostp.gov\/rhFBAU",
        "display_url" : "go.ostp.gov\/rhFBAU"
      } ]
    },
    "geo" : { },
    "id_str" : "126072138225553409",
    "text" : "President Obama Meets Nation's Cutting-Edge Researchers http:\/\/t.co\/FPijBeWL",
    "id" : 126072138225553409,
    "created_at" : "2011-10-17 23:08:34 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 126084703395643393,
  "created_at" : "2011-10-17 23:58:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskMichelle",
      "indices" : [ 41, 53 ]
    }, {
      "text" : "LetsMove",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/KMVazuFT",
      "expanded_url" : "http:\/\/youtu.be\/mRDnHCsQ7mE",
      "display_url" : "youtu.be\/mRDnHCsQ7mE"
    } ]
  },
  "geo" : { },
  "id_str" : "126063216248897536",
  "text" : "RT @letsmove: Mrs. Obama answers the 1st #AskMichelle question. Your Q: How do I get involved in #LetsMove? Her A: http:\/\/t.co\/KMVazuFT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskMichelle",
        "indices" : [ 27, 39 ]
      }, {
        "text" : "LetsMove",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/KMVazuFT",
        "expanded_url" : "http:\/\/youtu.be\/mRDnHCsQ7mE",
        "display_url" : "youtu.be\/mRDnHCsQ7mE"
      } ]
    },
    "geo" : { },
    "id_str" : "126063089236975617",
    "text" : "Mrs. Obama answers the 1st #AskMichelle question. Your Q: How do I get involved in #LetsMove? Her A: http:\/\/t.co\/KMVazuFT",
    "id" : 126063089236975617,
    "created_at" : "2011-10-17 22:32:37 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 126063216248897536,
  "created_at" : "2011-10-17 22:33:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/126058438861144064\/photo\/1",
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/K6pOK19V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ab_Ze3WCQAAGagb.jpg",
      "id_str" : "126058438865338368",
      "id" : 126058438865338368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ab_Ze3WCQAAGagb.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/K6pOK19V"
    } ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/zNMj0Cde",
      "expanded_url" : "http:\/\/1.usa.gov\/pxsCN7",
      "display_url" : "1.usa.gov\/pxsCN7"
    } ]
  },
  "geo" : { },
  "id_str" : "126058438861144064",
  "text" : "#JobsNow Act by the Numbers: 150: http:\/\/t.co\/zNMj0Cde http:\/\/t.co\/K6pOK19V",
  "id" : 126058438861144064,
  "created_at" : "2011-10-17 22:14:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 97, 101 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/lQPAJQv3",
      "expanded_url" : "http:\/\/1.usa.gov\/ph3njL",
      "display_url" : "1.usa.gov\/ph3njL"
    } ]
  },
  "geo" : { },
  "id_str" : "126037487746416640",
  "text" : "Great news for smartphone users: Free text alerts before you hit your phone plan's limit, thx to @FCC. -bo http:\/\/t.co\/lQPAJQv3",
  "id" : 126037487746416640,
  "created_at" : "2011-10-17 20:50:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/HrNhJJ3u",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "126018197110530048",
  "text" : "RT @letsmove: Happening now: the First Lady honors participants in the HealthierUS School Challenge: Watch live: http:\/\/t.co\/HrNhJJ3u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/HrNhJJ3u",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "126018046283354112",
    "text" : "Happening now: the First Lady honors participants in the HealthierUS School Challenge: Watch live: http:\/\/t.co\/HrNhJJ3u",
    "id" : 126018046283354112,
    "created_at" : "2011-10-17 19:33:38 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 126018197110530048,
  "created_at" : "2011-10-17 19:34:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125992732698226688",
  "text" : "RT @PressSec: POTUS: 1 poll says 63% of Americans support the Jobs Act, but 100% of GOP senators voted no. \"That doesn't make any sense, ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125978878199087104",
    "text" : "POTUS: 1 poll says 63% of Americans support the Jobs Act, but 100% of GOP senators voted no. \"That doesn't make any sense, does it?\"",
    "id" : 125978878199087104,
    "created_at" : "2011-10-17 16:57:59 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 125992732698226688,
  "created_at" : "2011-10-17 17:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125956173718487041",
  "text" : "RT @pfeiffer44: President Obama called boxer Dewey Bozella to wish him luck in his first pro fight. Here's the video of the call http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/YpSYQLxn",
        "expanded_url" : "http:\/\/es.pn\/nrzjS5",
        "display_url" : "es.pn\/nrzjS5"
      } ]
    },
    "geo" : { },
    "id_str" : "125939884048384000",
    "text" : "President Obama called boxer Dewey Bozella to wish him luck in his first pro fight. Here's the video of the call http:\/\/t.co\/YpSYQLxn",
    "id" : 125939884048384000,
    "created_at" : "2011-10-17 14:23:02 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 125956173718487041,
  "created_at" : "2011-10-17 15:27:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 129, 136 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "Asheville",
      "indices" : [ 58, 68 ]
    }, {
      "text" : "NC",
      "indices" : [ 69, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "125943479649058816",
  "text" : "President Obama begins his 3-day #JobsNow Act bus tour in #Asheville #NC. Remarks @ 10:50ET: Audio: http:\/\/t.co\/hhNoX4fh Follow: @WHLive",
  "id" : 125943479649058816,
  "created_at" : "2011-10-17 14:37:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 42, 55 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DedicateMLK",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/OYItEEDt",
      "expanded_url" : "http:\/\/1.usa.gov\/rfSDqG",
      "display_url" : "1.usa.gov\/rfSDqG"
    } ]
  },
  "geo" : { },
  "id_str" : "125733983463014401",
  "text" : "\"Each of us must continue to do our part\" @RepJohnLewis on Martin Luther King Jr. Memorial: http:\/\/t.co\/OYItEEDt #DedicateMLK",
  "id" : 125733983463014401,
  "created_at" : "2011-10-17 00:44:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DedicateMLK",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/4ghDUgaH",
      "expanded_url" : "http:\/\/youtu.be\/QR8GEDjT-x4",
      "display_url" : "youtu.be\/QR8GEDjT-x4"
    } ]
  },
  "geo" : { },
  "id_str" : "125704901232836608",
  "text" : "\"Change can come if you don\u2019t give up\" -President Obama @MLKMemorial dedication. Video: http:\/\/t.co\/4ghDUgaH #DedicateMLK",
  "id" : 125704901232836608,
  "created_at" : "2011-10-16 22:49:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/125702324046921728\/photo\/1",
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/GUqcv4r2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ab6VmQTCAAAzggp.jpg",
      "id_str" : "125702324055310336",
      "id" : 125702324055310336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ab6VmQTCAAAzggp.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1294,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/GUqcv4r2"
    } ],
    "hashtags" : [ {
      "text" : "DedicateMLK",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125702324046921728",
  "text" : "Photo of the day: The First Family tours @MLKMemorial before #DedicateMLK ceremony: http:\/\/t.co\/GUqcv4r2",
  "id" : 125702324046921728,
  "created_at" : "2011-10-16 22:39:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125606114569101312",
  "text" : "RT @WHLive: Obama: Let us keep climbing towards...a world that is more fair, more equal & more just for every single child of God. #Dedi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DedicateMLK",
        "indices" : [ 119, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125605972889710592",
    "text" : "Obama: Let us keep climbing towards...a world that is more fair, more equal & more just for every single child of God. #DedicateMLK",
    "id" : 125605972889710592,
    "created_at" : "2011-10-16 16:16:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 125606114569101312,
  "created_at" : "2011-10-16 16:16:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DedicateMLK",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125604347714342912",
  "text" : "President Obama: His life, his story, tells us that change can come if you don\u2019t give up. #DedicateMLK",
  "id" : 125604347714342912,
  "created_at" : "2011-10-16 16:09:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125603158608199682",
  "text" : "RT @WHLive: Obama: We can\u2019t be discouraged by what is. We\u2019ve got to keep pushing for what ought to be, the America we ought to leave to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125603090656276480",
    "text" : "Obama: We can\u2019t be discouraged by what is. We\u2019ve got to keep pushing for what ought to be, the America we ought to leave to our children",
    "id" : 125603090656276480,
    "created_at" : "2011-10-16 16:04:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 125603158608199682,
  "created_at" : "2011-10-16 16:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DedicateMLK",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125601960094220288",
  "text" : "President Obama: Nearly 50 years after the March on Washington, our work, and Dr. King\u2019s work, is not yet complete. #DedicateMLK",
  "id" : 125601960094220288,
  "created_at" : "2011-10-16 16:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DedicateMLK",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "125599793144799232",
  "text" : "Happening now: President Obama delivers remarks @MLKMemorial. Watch live: http:\/\/t.co\/QDIpMRKE #DedicateMLK",
  "id" : 125599793144799232,
  "created_at" : "2011-10-16 15:51:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "125587351014604800",
  "text" : "Happening @ 11:05ET: President Obama speaks @ Martin Luther King memorial dedication. Watch live: http:\/\/t.co\/QDIpMRKE",
  "id" : 125587351014604800,
  "created_at" : "2011-10-16 15:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/UX0r7S7Q",
      "expanded_url" : "http:\/\/ow.ly\/6YIjW",
      "display_url" : "ow.ly\/6YIjW"
    } ]
  },
  "geo" : { },
  "id_str" : "125557837849038848",
  "text" : "Today, President Obama speaks at the Martin Luther King memorial dedication on the Natl Mall. Watch live @ 11ET: http:\/\/t.co\/UX0r7S7Q",
  "id" : 125557837849038848,
  "created_at" : "2011-10-16 13:04:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whtweetup",
      "indices" : [ 76, 86 ]
    }, {
      "text" : "NC",
      "indices" : [ 90, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/otB0048y",
      "expanded_url" : "http:\/\/www.wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "125282952690147328",
  "text" : "Calling all twitter & fbook fans: Don't miss your chance to attend the next #whtweetup in #NC. Register now: http:\/\/t.co\/otB0048y",
  "id" : 125282952690147328,
  "created_at" : "2011-10-15 18:52:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 55, 63 ]
    }, {
      "text" : "WHTweetup",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/yzzfeOR0",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/tweetup",
      "display_url" : "whitehouse.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "125247047979896833",
  "text" : "#WHTweetup hits the road! Announcing President Obama's #JobsNow Bus Tour #WHTweetup in North Carolina. Sign up: http:\/\/t.co\/yzzfeOR0",
  "id" : 125247047979896833,
  "created_at" : "2011-10-15 16:29:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/YEyxteio",
      "expanded_url" : "http:\/\/youtu.be\/4CgvaKnGV-g",
      "display_url" : "youtu.be\/4CgvaKnGV-g"
    } ]
  },
  "geo" : { },
  "id_str" : "125194546874294273",
  "text" : "President Obama continues to urge Congress to pass the Jobs Act so we can grow our economy & create #jobsnow: http:\/\/t.co\/YEyxteio",
  "id" : 125194546874294273,
  "created_at" : "2011-10-15 13:01:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/zH2UEbzE",
      "expanded_url" : "http:\/\/1.usa.gov\/pqR8ZG",
      "display_url" : "1.usa.gov\/pqR8ZG"
    } ]
  },
  "geo" : { },
  "id_str" : "124977043699019776",
  "text" : "RT @petesouza: Photos from State Arrival and State Dinner w President Obama and President Lee of South Korea: http:\/\/t.co\/zH2UEbzE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/zH2UEbzE",
        "expanded_url" : "http:\/\/1.usa.gov\/pqR8ZG",
        "display_url" : "1.usa.gov\/pqR8ZG"
      } ]
    },
    "geo" : { },
    "id_str" : "124969863180599297",
    "text" : "Photos from State Arrival and State Dinner w President Obama and President Lee of South Korea: http:\/\/t.co\/zH2UEbzE",
    "id" : 124969863180599297,
    "created_at" : "2011-10-14 22:08:31 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 124977043699019776,
  "created_at" : "2011-10-14 22:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    }, {
      "name" : "Nat'l Ctr. for PTSD",
      "screen_name" : "VA_PTSD_Info",
      "indices" : [ 49, 62 ],
      "id_str" : "112763422",
      "id" : 112763422
    }, {
      "name" : "VA OEF OIF",
      "screen_name" : "VA_OEF_OIF",
      "indices" : [ 63, 74 ],
      "id_str" : "124163000",
      "id" : 124163000
    }, {
      "name" : "VA Careers",
      "screen_name" : "vacareers",
      "indices" : [ 75, 85 ],
      "id_str" : "64808610",
      "id" : 64808610
    }, {
      "name" : "Veterans Health",
      "screen_name" : "VeteransHealth",
      "indices" : [ 86, 101 ],
      "id_str" : "17346287",
      "id" : 17346287
    }, {
      "name" : "Veterans Benefits",
      "screen_name" : "VAVetBenefits",
      "indices" : [ 102, 116 ],
      "id_str" : "83922884",
      "id" : 83922884
    }, {
      "name" : "National Cemeteries",
      "screen_name" : "VANatCemeteries",
      "indices" : [ 117, 133 ],
      "id_str" : "84318793",
      "id" : 84318793
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 134, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124923922897575937",
  "text" : "RT @DeptVetAffairs: Great VA resources to follow @VA_PTSD_Info @VA_OEF_OIF @VAcareers @veteranshealth @VAvetbenefits @VAnatcemeteries #ff",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nat'l Ctr. for PTSD",
        "screen_name" : "VA_PTSD_Info",
        "indices" : [ 29, 42 ],
        "id_str" : "112763422",
        "id" : 112763422
      }, {
        "name" : "VA OEF OIF",
        "screen_name" : "VA_OEF_OIF",
        "indices" : [ 43, 54 ],
        "id_str" : "124163000",
        "id" : 124163000
      }, {
        "name" : "VA Careers",
        "screen_name" : "vacareers",
        "indices" : [ 55, 65 ],
        "id_str" : "64808610",
        "id" : 64808610
      }, {
        "name" : "Veterans Health",
        "screen_name" : "VeteransHealth",
        "indices" : [ 66, 81 ],
        "id_str" : "17346287",
        "id" : 17346287
      }, {
        "name" : "Veterans Benefits",
        "screen_name" : "VAVetBenefits",
        "indices" : [ 82, 96 ],
        "id_str" : "83922884",
        "id" : 83922884
      }, {
        "name" : "National Cemeteries",
        "screen_name" : "VANatCemeteries",
        "indices" : [ 97, 113 ],
        "id_str" : "84318793",
        "id" : 84318793
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ff",
        "indices" : [ 114, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124921900777472001",
    "text" : "Great VA resources to follow @VA_PTSD_Info @VA_OEF_OIF @VAcareers @veteranshealth @VAvetbenefits @VAnatcemeteries #ff",
    "id" : 124921900777472001,
    "created_at" : "2011-10-14 18:57:56 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 124923922897575937,
  "created_at" : "2011-10-14 19:05:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "General Motors",
      "screen_name" : "GM",
      "indices" : [ 81, 84 ],
      "id_str" : "10850192",
      "id" : 10850192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Michigan",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "124909335875825664",
  "text" : "Starting soon: Pres Obama & Pres Lee speak on the trade agreement w\/ South Korea @GM plant in #Michigan. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 124909335875825664,
  "created_at" : "2011-10-14 18:08:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124908641622044673",
  "text" : "RT @jesseclee44: Moody's on Senate GOP \"jobs\" ideas: \"aren't going to address [current weakness]...could be harmful in the short run\" ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/n610jmgx",
        "expanded_url" : "http:\/\/is.gd\/p0BAJt",
        "display_url" : "is.gd\/p0BAJt"
      } ]
    },
    "geo" : { },
    "id_str" : "124901629588815873",
    "text" : "Moody's on Senate GOP \"jobs\" ideas: \"aren't going to address [current weakness]...could be harmful in the short run\" http:\/\/t.co\/n610jmgx",
    "id" : 124901629588815873,
    "created_at" : "2011-10-14 17:37:23 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 124908641622044673,
  "created_at" : "2011-10-14 18:05:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/rXP2iiyT",
      "expanded_url" : "http:\/\/wh.gov\/270",
      "display_url" : "wh.gov\/270"
    } ]
  },
  "geo" : { },
  "id_str" : "124900622171516928",
  "text" : "New report highlights Admin's work to reverse trends of poverty & create opportunity for all Americans: http:\/\/t.co\/rXP2iiyT #JobsNow",
  "id" : 124900622171516928,
  "created_at" : "2011-10-14 17:33:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChicagoBears.com",
      "screen_name" : "ChicagoBearsCom",
      "indices" : [ 38, 54 ],
      "id_str" : "359957532",
      "id" : 359957532
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 6, 19 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "ROK",
      "indices" : [ 90, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/ru8lIRNG",
      "expanded_url" : "http:\/\/youtu.be\/3Ko8Hfo6w6Q",
      "display_url" : "youtu.be\/3Ko8Hfo6w6Q"
    } ]
  },
  "geo" : { },
  "id_str" : "124864070787670016",
  "text" : "Watch #WestWingWeek: Obama honors '85 @ChicagoBearscom, fights for #JobsNow Act, welcomes #ROK for State Visit: http:\/\/t.co\/ru8lIRNG",
  "id" : 124864070787670016,
  "created_at" : "2011-10-14 15:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "124638858217398272",
  "text" : "Happening at 8:35 ET: President Obama & President Lee deliver a toast at the Korean State Dinner. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 124638858217398272,
  "created_at" : "2011-10-14 00:13:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 57, 65 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetUp",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124636695420346368",
  "text" : "RT @macon44: Take a few secs & scan through this awesome @storify thread of today's #WHTweetUp. It loads more as your scroll down http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Storify",
        "screen_name" : "Storify",
        "indices" : [ 44, 52 ],
        "id_str" : "17814938",
        "id" : 17814938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetUp",
        "indices" : [ 71, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/SAtRFhXw",
        "expanded_url" : "http:\/\/1.usa.gov\/r4ZmuC",
        "display_url" : "1.usa.gov\/r4ZmuC"
      } ]
    },
    "geo" : { },
    "id_str" : "124635378408894464",
    "text" : "Take a few secs & scan through this awesome @storify thread of today's #WHTweetUp. It loads more as your scroll down http:\/\/t.co\/SAtRFhXw",
    "id" : 124635378408894464,
    "created_at" : "2011-10-13 23:59:24 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 124636695420346368,
  "created_at" : "2011-10-14 00:04:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/okiM5Wb3",
      "expanded_url" : "http:\/\/youtu.be\/3R_H8mbPwzg",
      "display_url" : "youtu.be\/3R_H8mbPwzg"
    } ]
  },
  "geo" : { },
  "id_str" : "124595367768625152",
  "text" : "What\u2019s on the menu for the Korean State Dinner? Take a peek inside the White House kitchen: http:\/\/t.co\/okiM5Wb3",
  "id" : 124595367768625152,
  "created_at" : "2011-10-13 21:20:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 18, 27 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 28, 36 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/4swGnEwN",
      "expanded_url" : "http:\/\/youtu.be\/ZNdJDWp1DUo",
      "display_url" : "youtu.be\/ZNdJDWp1DUo"
    } ]
  },
  "geo" : { },
  "id_str" : "124591748520484864",
  "text" : "RT @letsmove: \"Hi @LetsMove @Twitter followers!\" First Lady Michelle Obama has a special message just for you: http:\/\/t.co\/4swGnEwN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 4, 13 ],
        "id_str" : "36719281",
        "id" : 36719281
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 14, 22 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/4swGnEwN",
        "expanded_url" : "http:\/\/youtu.be\/ZNdJDWp1DUo",
        "display_url" : "youtu.be\/ZNdJDWp1DUo"
      } ]
    },
    "geo" : { },
    "id_str" : "124591120394108928",
    "text" : "\"Hi @LetsMove @Twitter followers!\" First Lady Michelle Obama has a special message just for you: http:\/\/t.co\/4swGnEwN",
    "id" : 124591120394108928,
    "created_at" : "2011-10-13 21:03:32 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 124591748520484864,
  "created_at" : "2011-10-13 21:06:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HelloGiggles.com",
      "screen_name" : "hellogiggles",
      "indices" : [ 3, 16 ],
      "id_str" : "219682445",
      "id" : 219682445
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/Qa0QUZ3L",
      "expanded_url" : "http:\/\/tinyurl.com\/3cdm4na",
      "display_url" : "tinyurl.com\/3cdm4na"
    } ]
  },
  "geo" : { },
  "id_str" : "124587976398348288",
  "text" : "RT @hellogiggles: We are so happy and honored to be on the @whitehouse website today!! http:\/\/t.co\/Qa0QUZ3L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 41, 52 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/Qa0QUZ3L",
        "expanded_url" : "http:\/\/tinyurl.com\/3cdm4na",
        "display_url" : "tinyurl.com\/3cdm4na"
      } ]
    },
    "geo" : { },
    "id_str" : "124246237426888704",
    "text" : "We are so happy and honored to be on the @whitehouse website today!! http:\/\/t.co\/Qa0QUZ3L",
    "id" : 124246237426888704,
    "created_at" : "2011-10-12 22:13:06 +0000",
    "user" : {
      "name" : "HelloGiggles.com",
      "screen_name" : "hellogiggles",
      "protected" : false,
      "id_str" : "219682445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748229782958071808\/72mv_NAp_normal.jpg",
      "id" : 219682445,
      "verified" : true
    }
  },
  "id" : 124587976398348288,
  "created_at" : "2011-10-13 20:51:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "124520359906131968",
  "text" : "Happening now: President Obama & President Lee hold a joint press conference in the East Room. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 124520359906131968,
  "created_at" : "2011-10-13 16:22:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 106, 117 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124518447647432705",
  "text" : "RT @USTradeRep: Ambassador Kirk is joining President Obama in bilateral meeting with ROK President Lee cc @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 90, 101 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124503890824671232",
    "text" : "Ambassador Kirk is joining President Obama in bilateral meeting with ROK President Lee cc @whitehouse",
    "id" : 124503890824671232,
    "created_at" : "2011-10-13 15:16:55 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 124518447647432705,
  "created_at" : "2011-10-13 16:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/KmWawoM2",
      "expanded_url" : "http:\/\/www.wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "124487534951661568",
  "text" : "RT @WHLive: South Korea Arrival just concluded - video on http:\/\/t.co\/KmWawoM2 soon. Thanks for hanging in there Tweeple! #WHTweetup #Al ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 110, 120 ]
      }, {
        "text" : "AlmostRainedOut",
        "indices" : [ 121, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/KmWawoM2",
        "expanded_url" : "http:\/\/www.wh.gov",
        "display_url" : "wh.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "124487366428737537",
    "text" : "South Korea Arrival just concluded - video on http:\/\/t.co\/KmWawoM2 soon. Thanks for hanging in there Tweeple! #WHTweetup #AlmostRainedOut",
    "id" : 124487366428737537,
    "created_at" : "2011-10-13 14:11:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 124487534951661568,
  "created_at" : "2011-10-13 14:11:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 93, 100 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 101, 111 ]
    }, {
      "text" : "AtTheWH",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "124472943865638912",
  "text" : "Just started: Republic of Korea Arrival Ceremony: Watch live: http:\/\/t.co\/hhNoX4fh & Follow: @WHLive #WHTweetup #AtTheWH",
  "id" : 124472943865638912,
  "created_at" : "2011-10-13 13:13:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "124470501652447232",
  "text" : "Happening now: President Obama welcomes President Lee Myung-bak of the Republic of Korea. Watch live: http:\/\/t.co\/hhNoX4fh #WHTweetup",
  "id" : 124470501652447232,
  "created_at" : "2011-10-13 13:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/elSLb3mc",
      "expanded_url" : "http:\/\/ow.ly\/6VBYV",
      "display_url" : "ow.ly\/6VBYV"
    } ]
  },
  "geo" : { },
  "id_str" : "124248160708210688",
  "text" : "President Obama: Americans want Congress to do their job: http:\/\/t.co\/elSLb3mc #JobsNow",
  "id" : 124248160708210688,
  "created_at" : "2011-10-12 22:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Hanks",
      "screen_name" : "tomhanks",
      "indices" : [ 11, 20 ],
      "id_str" : "50374439",
      "id" : 50374439
    }, {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 23, 29 ],
      "id_str" : "19397785",
      "id" : 19397785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 30, 44 ]
    }, {
      "text" : "troops",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/etkvoKw6",
      "expanded_url" : "http:\/\/ow.ly\/6VBso",
      "display_url" : "ow.ly\/6VBso"
    } ]
  },
  "geo" : { },
  "id_str" : "124244997703864321",
  "text" : "Spielberg, @tomhanks & @Oprah #JoiningForces to support our #troops. Watch the videos & get involved: http:\/\/t.co\/etkvoKw6",
  "id" : 124244997703864321,
  "created_at" : "2011-10-12 22:08:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Carl Levin",
      "screen_name" : "SenCarlLevin",
      "indices" : [ 3, 16 ],
      "id_str" : "93761782",
      "id" : 93761782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124199362158010369",
  "text" : "RT @SenCarlLevin: WATCH Carl took to the floor earlier to call on the public to help break the filibuster of the American Jobs Act http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/9GlmQ0mk",
        "expanded_url" : "http:\/\/youtu.be\/Hoip3VF3zGk",
        "display_url" : "youtu.be\/Hoip3VF3zGk"
      } ]
    },
    "geo" : { },
    "id_str" : "124194783123079169",
    "text" : "WATCH Carl took to the floor earlier to call on the public to help break the filibuster of the American Jobs Act http:\/\/t.co\/9GlmQ0mk",
    "id" : 124194783123079169,
    "created_at" : "2011-10-12 18:48:38 +0000",
    "user" : {
      "name" : "Senator Carl Levin",
      "screen_name" : "SenCarlLevin",
      "protected" : false,
      "id_str" : "93761782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1246507828\/bio_pict_normal.gif",
      "id" : 93761782,
      "verified" : true
    }
  },
  "id" : 124199362158010369,
  "created_at" : "2011-10-12 19:06:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Tom Hanks",
      "screen_name" : "tomhanks",
      "indices" : [ 36, 45 ],
      "id_str" : "50374439",
      "id" : 50374439
    }, {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 48, 54 ],
      "id_str" : "19397785",
      "id" : 19397785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 59, 73 ]
    }, {
      "text" : "military",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124198170635935744",
  "text" : "RT @JoiningForces: Steven Spielberg @tomhanks & @Oprah are #JoiningForces w\/ the First Lady to support #military families. Watch: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Hanks",
        "screen_name" : "tomhanks",
        "indices" : [ 17, 26 ],
        "id_str" : "50374439",
        "id" : 50374439
      }, {
        "name" : "Oprah Winfrey",
        "screen_name" : "Oprah",
        "indices" : [ 29, 35 ],
        "id_str" : "19397785",
        "id" : 19397785
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 40, 54 ]
      }, {
        "text" : "military",
        "indices" : [ 84, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/xGKzH7y8",
        "expanded_url" : "http:\/\/ow.ly\/6Vgi6",
        "display_url" : "ow.ly\/6Vgi6"
      } ]
    },
    "geo" : { },
    "id_str" : "124197951722618880",
    "text" : "Steven Spielberg @tomhanks & @Oprah are #JoiningForces w\/ the First Lady to support #military families. Watch: http:\/\/t.co\/xGKzH7y8",
    "id" : 124197951722618880,
    "created_at" : "2011-10-12 19:01:13 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 124198170635935744,
  "created_at" : "2011-10-12 19:02:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 34, 45 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/JxkVCIZW",
      "expanded_url" : "http:\/\/ow.ly\/6Vjfk",
      "display_url" : "ow.ly\/6Vjfk"
    } ]
  },
  "geo" : { },
  "id_str" : "124174372528324608",
  "text" : "We can't take \"no\" for an answer: @pfeiffer44 on the consequences of Rs in the Senate blocking the #JobsNow Act: http:\/\/t.co\/JxkVCIZW",
  "id" : 124174372528324608,
  "created_at" : "2011-10-12 17:27:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Latino",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124145799167868930",
  "text" : "RT @Interior: President Obama will be taking the stage at the #Latino Heritage Summit momentarily. You can watch live here: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Latino",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/F3ZH4hKZ",
        "expanded_url" : "http:\/\/on.doi.gov\/dST8Od",
        "display_url" : "on.doi.gov\/dST8Od"
      } ]
    },
    "geo" : { },
    "id_str" : "124144179713540096",
    "text" : "President Obama will be taking the stage at the #Latino Heritage Summit momentarily. You can watch live here: http:\/\/t.co\/F3ZH4hKZ",
    "id" : 124144179713540096,
    "created_at" : "2011-10-12 15:27:33 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 124145799167868930,
  "created_at" : "2011-10-12 15:33:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Baltimore",
      "indices" : [ 83, 93 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/VX7X0lDK",
      "expanded_url" : "http:\/\/youtu.be\/RNCEpHjHd8Y",
      "display_url" : "youtu.be\/RNCEpHjHd8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "123972445811118082",
  "text" : "Hear from Mayor Stephanie Rawlings-Blake: http:\/\/t.co\/VX7X0lDK She\u2019ll tell you why #Baltimore needs the #JobsNow Act.",
  "id" : 123972445811118082,
  "created_at" : "2011-10-12 04:05:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/LyL6ZYkB",
      "expanded_url" : "http:\/\/1.usa.gov\/qg1H4R",
      "display_url" : "1.usa.gov\/qg1H4R"
    } ]
  },
  "geo" : { },
  "id_str" : "123959519909904384",
  "text" : "\"It\u2019s time for Congress to...put their party politics aside & take action on jobs right now\" -Obama on Jobs Act vote: http:\/\/t.co\/LyL6ZYkB",
  "id" : 123959519909904384,
  "created_at" : "2011-10-12 03:13:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/DDWDvjI6",
      "expanded_url" : "http:\/\/ow.ly\/6Uvte",
      "display_url" : "ow.ly\/6Uvte"
    } ]
  },
  "geo" : { },
  "id_str" : "123957346245419008",
  "text" : "Meet Tamara Washington: http:\/\/t.co\/DDWDvjI6 A California mom who says provisions in the #JobsNow Act can change people\u2019s lives.",
  "id" : 123957346245419008,
  "created_at" : "2011-10-12 03:05:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/jj9AMuub",
      "expanded_url" : "http:\/\/ow.ly\/6UvbU",
      "display_url" : "ow.ly\/6UvbU"
    } ]
  },
  "geo" : { },
  "id_str" : "123942231617970176",
  "text" : "Meet Alice Johnson: http:\/\/t.co\/jj9AMuub The #JobsNow Act will help create job opportunities for people looking for work.",
  "id" : 123942231617970176,
  "created_at" : "2011-10-12 02:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/XAcmHw9l",
      "expanded_url" : "http:\/\/ow.ly\/6UuO2",
      "display_url" : "ow.ly\/6UuO2"
    } ]
  },
  "geo" : { },
  "id_str" : "123927145214001152",
  "text" : "Meet Jamail Larkins: http:\/\/t.co\/XAcmHw9l He wants Congress to pass the #JobsNow Act so he can grow his aviation business.",
  "id" : 123927145214001152,
  "created_at" : "2011-10-12 01:05:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 40, 48 ]
    }, {
      "text" : "jobs",
      "indices" : [ 66, 71 ]
    }, {
      "text" : "veterans",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/ZbJr3xcf",
      "expanded_url" : "http:\/\/ow.ly\/6Ut4z",
      "display_url" : "ow.ly\/6Ut4z"
    } ]
  },
  "geo" : { },
  "id_str" : "123912054376628224",
  "text" : "Meet Joe Kidd: http:\/\/t.co\/ZbJr3xcf The #JobsNow Act will support #jobs for #veterans like Joe.",
  "id" : 123912054376628224,
  "created_at" : "2011-10-12 00:05:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/HrUKrkuG",
      "expanded_url" : "http:\/\/ow.ly\/6UsDa",
      "display_url" : "ow.ly\/6UsDa"
    } ]
  },
  "geo" : { },
  "id_str" : "123899462300078080",
  "text" : "Meet Wendy & Scott: http:\/\/t.co\/HrUKrkuG The #JobsNow Act will enable their company to concentrate on putting American innovation to work.",
  "id" : 123899462300078080,
  "created_at" : "2011-10-11 23:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "villaraigosa",
      "screen_name" : "villaraigosa",
      "indices" : [ 16, 29 ],
      "id_str" : "796800025749688322",
      "id" : 796800025749688322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "LosAngeles",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/hOHWEZcS",
      "expanded_url" : "http:\/\/youtu.be\/xcvn_LuQ1j0",
      "display_url" : "youtu.be\/xcvn_LuQ1j0"
    } ]
  },
  "geo" : { },
  "id_str" : "123885599647211520",
  "text" : "Hear from Mayor @villaraigosa: http:\/\/t.co\/hOHWEZcS He'll tell you why the #JobsNow Act matters for #LosAngeles residents.",
  "id" : 123885599647211520,
  "created_at" : "2011-10-11 22:20:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/rhOBquxk",
      "expanded_url" : "http:\/\/ow.ly\/6UlUI",
      "display_url" : "ow.ly\/6UlUI"
    } ]
  },
  "geo" : { },
  "id_str" : "123869264292745216",
  "text" : "Meet Jane Iredale: http:\/\/t.co\/rhOBquxk The #JobsNow Act will enable entrepreneurs like Jane to reinvest tax savings & grow faster.",
  "id" : 123869264292745216,
  "created_at" : "2011-10-11 21:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/FoM5i3Jd",
      "expanded_url" : "http:\/\/ow.ly\/6Ujl1",
      "display_url" : "ow.ly\/6Ujl1"
    } ]
  },
  "geo" : { },
  "id_str" : "123861718270083072",
  "text" : "Meet Marlena Clark: http:\/\/t.co\/FoM5i3Jd She says \"passing the #JobsNow bill is just common sense\"",
  "id" : 123861718270083072,
  "created_at" : "2011-10-11 20:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAP44",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123853269037625344",
  "text" : "RT @OMBPress: #SAP44: Admin strongly supports Amer. Jobs Act. Puts people back to work, $ in their pockets; doesn\u2019t add to deficit http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SAP44",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/D37mzAjf",
        "expanded_url" : "http:\/\/1.usa.gov\/mOWmzm",
        "display_url" : "1.usa.gov\/mOWmzm"
      } ]
    },
    "geo" : { },
    "id_str" : "123848153534439425",
    "text" : "#SAP44: Admin strongly supports Amer. Jobs Act. Puts people back to work, $ in their pockets; doesn\u2019t add to deficit http:\/\/t.co\/D37mzAjf",
    "id" : 123848153534439425,
    "created_at" : "2011-10-11 19:51:15 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 123853269037625344,
  "created_at" : "2011-10-11 20:11:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/W4ItKIfg",
      "expanded_url" : "http:\/\/ow.ly\/6UgQV",
      "display_url" : "ow.ly\/6UgQV"
    } ]
  },
  "geo" : { },
  "id_str" : "123850692518617088",
  "text" : "Meet Philip Maung: http:\/\/t.co\/W4ItKIfg Congress should pass the #JobsNow Act so that small businesses like his can fast track growth.",
  "id" : 123850692518617088,
  "created_at" : "2011-10-11 20:01:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 55, 63 ]
    }, {
      "text" : "teachers",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/PwOWXhMB",
      "expanded_url" : "http:\/\/ow.ly\/6UbXz",
      "display_url" : "ow.ly\/6UbXz"
    } ]
  },
  "geo" : { },
  "id_str" : "123834139756597248",
  "text" : "Meet Stephanie Harris Walter: http:\/\/t.co\/PwOWXhMB The #JobsNow Act will put #teachers like Stephanie back to work.",
  "id" : 123834139756597248,
  "created_at" : "2011-10-11 18:55:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123830598157602816",
  "text" : "Obama: Let\u2019s meet this moment. Let\u2019s get to work. Let\u2019s show the world once again why the USA remains the greatest nation on Earth. #JobsNow",
  "id" : 123830598157602816,
  "created_at" : "2011-10-11 18:41:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 84, 103 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123829839122796545",
  "text" : "Obama: The American people...want Congress to do what they were elected to do \u2013 put #countrybeforeparty & do what\u2019s right. #JobsNow",
  "id" : 123829839122796545,
  "created_at" : "2011-10-11 18:38:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "123825767799996417",
  "text" : "Obama: Today is the day when every American will find out exactly where their Senator stands on this #JobsNow bill. http:\/\/t.co\/hhNoX4fh",
  "id" : 123825767799996417,
  "created_at" : "2011-10-11 18:22:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123825500538929152",
  "text" : "Obama: Our economy needs a jolt right now. Today, the Senate has a chance to do something about it by voting for the #JobsNow Act.",
  "id" : 123825500538929152,
  "created_at" : "2011-10-11 18:21:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 100, 107 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "123823670425686017",
  "text" : "Happening Now: President Obama speaks on the American Jobs Act. Watch: http:\/\/t.co\/hhNoX4fh Follow: @WHLive Discuss: #JobsNow",
  "id" : 123823670425686017,
  "created_at" : "2011-10-11 18:13:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "Pittsburgh",
      "indices" : [ 73, 84 ]
    }, {
      "text" : "Pennsylvania",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/xrOHuqTm",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "123817099985555457",
  "text" : "RT @WHLive: Starting soon: President Obama speaks on the #JobsNow Act in #Pittsburgh #Pennsylvania. Watch live: http:\/\/t.co\/xrOHuqTm & f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 131, 138 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 45, 53 ]
      }, {
        "text" : "Pittsburgh",
        "indices" : [ 61, 72 ]
      }, {
        "text" : "Pennsylvania",
        "indices" : [ 73, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/xrOHuqTm",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "123816962584363008",
    "text" : "Starting soon: President Obama speaks on the #JobsNow Act in #Pittsburgh #Pennsylvania. Watch live: http:\/\/t.co\/xrOHuqTm & follow: @WHLive",
    "id" : 123816962584363008,
    "created_at" : "2011-10-11 17:47:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 123817099985555457,
  "created_at" : "2011-10-11 17:47:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Denver",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "Colorado",
      "indices" : [ 81, 90 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/B4G4d93i",
      "expanded_url" : "http:\/\/youtu.be\/XX_iLZNZEYM",
      "display_url" : "youtu.be\/XX_iLZNZEYM"
    } ]
  },
  "geo" : { },
  "id_str" : "123806834954993664",
  "text" : "Hear from Mayor Michael Hancock: http:\/\/t.co\/B4G4d93i He\u2019ll tell you why #Denver #Colorado needs the #JobsNow Act.",
  "id" : 123806834954993664,
  "created_at" : "2011-10-11 17:07:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/H2uwSe7z",
      "expanded_url" : "http:\/\/bit.ly\/q5KTuM",
      "display_url" : "bit.ly\/q5KTuM"
    } ]
  },
  "geo" : { },
  "id_str" : "123794742541688832",
  "text" : "RT @jesseclee44: Pittsburgh Post-Gazette: \"Pass the jobs plan: Washington must put Americans back to work\" http:\/\/t.co\/H2uwSe7z #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 111, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/H2uwSe7z",
        "expanded_url" : "http:\/\/bit.ly\/q5KTuM",
        "display_url" : "bit.ly\/q5KTuM"
      } ]
    },
    "geo" : { },
    "id_str" : "123766656982978560",
    "text" : "Pittsburgh Post-Gazette: \"Pass the jobs plan: Washington must put Americans back to work\" http:\/\/t.co\/H2uwSe7z #JobsNow",
    "id" : 123766656982978560,
    "created_at" : "2011-10-11 14:27:25 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 123794742541688832,
  "created_at" : "2011-10-11 16:19:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayor Greg Fischer",
      "screen_name" : "louisvillemayor",
      "indices" : [ 10, 26 ],
      "id_str" : "244123121",
      "id" : 244123121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Louisville",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "Kentucky",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/Fp72yA7q",
      "expanded_url" : "http:\/\/youtu.be\/nmlPu6KbYjo",
      "display_url" : "youtu.be\/nmlPu6KbYjo"
    } ]
  },
  "geo" : { },
  "id_str" : "123792731452620800",
  "text" : "Hear from @louisvillemayor Greg Fischer: http:\/\/t.co\/Fp72yA7q He'll tell you why #Louisville #Kentucky can\u2019t wait for the #JobsNow Act.",
  "id" : 123792731452620800,
  "created_at" : "2011-10-11 16:11:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "education",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/n9kzefGv",
      "expanded_url" : "http:\/\/1.usa.gov\/npjiRB",
      "display_url" : "1.usa.gov\/npjiRB"
    } ]
  },
  "geo" : { },
  "id_str" : "123777323362304000",
  "text" : "Meet the Mangrum family: http:\/\/t.co\/n9kzefGv The #JobsNow Act would help this hard working family pay for #education.",
  "id" : 123777323362304000,
  "created_at" : "2011-10-11 15:09:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cincinnati",
      "indices" : [ 70, 81 ]
    }, {
      "text" : "Ohio",
      "indices" : [ 82, 87 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/uVJ0yMxf",
      "expanded_url" : "http:\/\/youtu.be\/pSHYNC6Ufn4",
      "display_url" : "youtu.be\/pSHYNC6Ufn4"
    } ]
  },
  "geo" : { },
  "id_str" : "123762979773743104",
  "text" : "Hear from Mayor Mark Mallory: http:\/\/t.co\/uVJ0yMxf He\u2019ll tell you why #Cincinnati #Ohio needs the #JobsNow Act.",
  "id" : 123762979773743104,
  "created_at" : "2011-10-11 14:12:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/gQV1r36D",
      "expanded_url" : "http:\/\/1.usa.gov\/pURwsM",
      "display_url" : "1.usa.gov\/pURwsM"
    } ]
  },
  "geo" : { },
  "id_str" : "123747063237316608",
  "text" : "Remember Destiny Wheeler: http:\/\/t.co\/gQV1r36D This Georgia teen needs the #JobsNow Act to push forward and put her family in a better spot.",
  "id" : 123747063237316608,
  "created_at" : "2011-10-11 13:09:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/4P9IfyDE",
      "expanded_url" : "http:\/\/1.usa.gov\/r0fi8c",
      "display_url" : "1.usa.gov\/r0fi8c"
    } ]
  },
  "geo" : { },
  "id_str" : "123729821435047936",
  "text" : "Hear from Mayor Phil Gordon: http:\/\/t.co\/4P9IfyDE  He\u2019ll tell you why Phoenix, AZ needs the #JobsNow Act passed today.",
  "id" : 123729821435047936,
  "created_at" : "2011-10-11 12:01:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/TSPgMUB0",
      "expanded_url" : "http:\/\/1.usa.gov\/mPH4Qd",
      "display_url" : "1.usa.gov\/mPH4Qd"
    } ]
  },
  "geo" : { },
  "id_str" : "123715119871041536",
  "text" : "Meet Chris Yura: http:\/\/t.co\/TSPgMUB0  #JobsNow Act tax credits will help him hire the long term unemployed and grow his businesses.",
  "id" : 123715119871041536,
  "created_at" : "2011-10-11 11:02:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/MliMzpdM",
      "expanded_url" : "http:\/\/1.usa.gov\/ndJCgt",
      "display_url" : "1.usa.gov\/ndJCgt"
    } ]
  },
  "geo" : { },
  "id_str" : "123699775248941056",
  "text" : "Meet Kimberly Russell: http:\/\/t.co\/MliMzpdM  She needs the #JobsNow Act to pass so more teachers can get back to the classroom.",
  "id" : 123699775248941056,
  "created_at" : "2011-10-11 10:01:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/PqbpBvUB",
      "expanded_url" : "http:\/\/youtu.be\/QH2_8W9GuHc",
      "display_url" : "youtu.be\/QH2_8W9GuHc"
    } ]
  },
  "geo" : { },
  "id_str" : "122691049704538112",
  "text" : "\"I need you to keep making your voices heard in Washington\" -President Obama on the #JobsNow Act: http:\/\/t.co\/PqbpBvUB",
  "id" : 122691049704538112,
  "created_at" : "2011-10-08 15:13:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/122444498893668352\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/wTMT0gyV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AbMCn33CAAAw9rG.jpg",
      "id_str" : "122444498902056960",
      "id" : 122444498902056960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AbMCn33CAAAw9rG.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wTMT0gyV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/rkbwi65u",
      "expanded_url" : "http:\/\/wh.gov\/2kz",
      "display_url" : "wh.gov\/2kz"
    } ]
  },
  "geo" : { },
  "id_str" : "122444498893668352",
  "text" : "25 years later the '85 Chicago Bears finally made it to the White House to celebrate their victory http:\/\/t.co\/rkbwi65u http:\/\/t.co\/wTMT0gyV",
  "id" : 122444498893668352,
  "created_at" : "2011-10-07 22:53:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChicagoBears.com",
      "screen_name" : "ChicagoBearsCom",
      "indices" : [ 47, 63 ],
      "id_str" : "359957532",
      "id" : 359957532
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 111, 118 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "85BearsWH",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "122382703617249280",
  "text" : "Happening @ 3 ET: President Obama welcomes '85 @ChicagoBearscom to the WH. Watch: http:\/\/t.co\/hhNoX4fh Follow: @WHLive Discuss: #85BearsWH",
  "id" : 122382703617249280,
  "created_at" : "2011-10-07 18:48:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Otis Wilson",
      "screen_name" : "OtisWilson_55",
      "indices" : [ 3, 17 ],
      "id_str" : "58403390",
      "id" : 58403390
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PresidentObama",
      "indices" : [ 45, 60 ]
    }, {
      "text" : "TheFirstLady",
      "indices" : [ 65, 78 ]
    }, {
      "text" : "85BearsWH",
      "indices" : [ 109, 119 ]
    }, {
      "text" : "Chicago",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122380202373427200",
  "text" : "RT @OtisWilson_55: @whitehouse Going to meet #PresidentObama and #TheFirstLady. Im truly humbled and blessed #85BearsWH #Chicago Follow  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Otis Wilson",
        "screen_name" : "OtisWilson_55",
        "indices" : [ 117, 131 ],
        "id_str" : "58403390",
        "id" : 58403390
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PresidentObama",
        "indices" : [ 26, 41 ]
      }, {
        "text" : "TheFirstLady",
        "indices" : [ 46, 59 ]
      }, {
        "text" : "85BearsWH",
        "indices" : [ 90, 100 ]
      }, {
        "text" : "Chicago",
        "indices" : [ 101, 109 ]
      }, {
        "text" : "RT",
        "indices" : [ 132, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122342106634264577",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Going to meet #PresidentObama and #TheFirstLady. Im truly humbled and blessed #85BearsWH #Chicago Follow @OtisWilson_55 #RT",
    "id" : 122342106634264577,
    "created_at" : "2011-10-07 16:06:45 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Otis Wilson",
      "screen_name" : "OtisWilson_55",
      "protected" : false,
      "id_str" : "58403390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535246883187216384\/kzP26l8f_normal.jpeg",
      "id" : 58403390,
      "verified" : true
    }
  },
  "id" : 122380202373427200,
  "created_at" : "2011-10-07 18:38:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PassThisBill",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/LhCWoLty",
      "expanded_url" : "http:\/\/wh.gov\/2BW",
      "display_url" : "wh.gov\/2BW"
    } ]
  },
  "geo" : { },
  "id_str" : "122348735920476160",
  "text" : "RT @jesseclee44: Economists: The President's Plan Will Create Jobs Now, The GOP's Won't http:\/\/t.co\/LhCWoLty #PassThisBill",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PassThisBill",
        "indices" : [ 92, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/LhCWoLty",
        "expanded_url" : "http:\/\/wh.gov\/2BW",
        "display_url" : "wh.gov\/2BW"
      } ]
    },
    "geo" : { },
    "id_str" : "122348393862414336",
    "text" : "Economists: The President's Plan Will Create Jobs Now, The GOP's Won't http:\/\/t.co\/LhCWoLty #PassThisBill",
    "id" : 122348393862414336,
    "created_at" : "2011-10-07 16:31:44 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 122348735920476160,
  "created_at" : "2011-10-07 16:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HumanRightsCampaign",
      "screen_name" : "HRC",
      "indices" : [ 75, 79 ],
      "id_str" : "19608297",
      "id" : 19608297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 7, 20 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/jlMFwh30",
      "expanded_url" : "http:\/\/youtu.be\/1fAEvqE6J3Q",
      "display_url" : "youtu.be\/1fAEvqE6J3Q"
    } ]
  },
  "geo" : { },
  "id_str" : "122345639752368129",
  "text" : "WATCH: #WestWingWeek: Obama calls on Congress to pass #JobsNow Act, speaks @HRC dinner, holds news conf & more: http:\/\/t.co\/jlMFwh30",
  "id" : 122345639752368129,
  "created_at" : "2011-10-07 16:20:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "85BearsWH",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/0oSWswTF",
      "expanded_url" : "http:\/\/wh.gov\/2Ba",
      "display_url" : "wh.gov\/2Ba"
    } ]
  },
  "geo" : { },
  "id_str" : "122339076971036673",
  "text" : "Obama welcomes the '85 Chicago Bears to the WH. Have a Q for the team? Send it our way. Use #85BearsWH & watch @ 3ET: http:\/\/t.co\/0oSWswTF",
  "id" : 122339076971036673,
  "created_at" : "2011-10-07 15:54:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ChicagoBears.com",
      "screen_name" : "ChicagoBearsCom",
      "indices" : [ 3, 19 ],
      "id_str" : "359957532",
      "id" : 359957532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/EqljIuZP",
      "expanded_url" : "http:\/\/bit.ly\/nlaADv",
      "display_url" : "bit.ly\/nlaADv"
    } ]
  },
  "geo" : { },
  "id_str" : "122309917087506432",
  "text" : "RT @ChicagoBearscom: The '85 Bears are headed to the White House! We'll be streaming it here: http:\/\/t.co\/EqljIuZP. Share memories and d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "85BearsWH",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/EqljIuZP",
        "expanded_url" : "http:\/\/bit.ly\/nlaADv",
        "display_url" : "bit.ly\/nlaADv"
      } ]
    },
    "geo" : { },
    "id_str" : "122286395543928833",
    "text" : "The '85 Bears are headed to the White House! We'll be streaming it here: http:\/\/t.co\/EqljIuZP. Share memories and discuss using #85BearsWH.",
    "id" : 122286395543928833,
    "created_at" : "2011-10-07 12:25:23 +0000",
    "user" : {
      "name" : "Chicago Bears",
      "screen_name" : "ChicagoBears",
      "protected" : false,
      "id_str" : "47964412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794258369552977921\/XEa5g9FK_normal.jpg",
      "id" : 47964412,
      "verified" : true
    }
  },
  "id" : 122309917087506432,
  "created_at" : "2011-10-07 13:58:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 36, 44 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122305480101068800",
  "text" : "RT @pfeiffer44: Economists tell the @nytimes that the GOP jobs plan \"won\u2019t mean much for the economy and job market in the next year\" ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 20, 28 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/lHoHxWLh",
        "expanded_url" : "http:\/\/nyti.ms\/rdgYJJ",
        "display_url" : "nyti.ms\/rdgYJJ"
      } ]
    },
    "geo" : { },
    "id_str" : "122277788957945856",
    "text" : "Economists tell the @nytimes that the GOP jobs plan \"won\u2019t mean much for the economy and job market in the next year\" http:\/\/t.co\/lHoHxWLh",
    "id" : 122277788957945856,
    "created_at" : "2011-10-07 11:51:11 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 122305480101068800,
  "created_at" : "2011-10-07 13:41:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/BgfwJ8sB",
      "expanded_url" : "http:\/\/wh.gov\/2DM",
      "display_url" : "wh.gov\/2DM"
    } ]
  },
  "geo" : { },
  "id_str" : "122092660294033408",
  "text" : "\"We\u2019ve got a responsibility to the people who sent us here\" -President Obama on the Jobs Act. Video: http:\/\/t.co\/BgfwJ8sB #JobsNow",
  "id" : 122092660294033408,
  "created_at" : "2011-10-06 23:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "indices" : [ 3, 11 ],
      "id_str" : "44409004",
      "id" : 44409004
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/DdaASUZG",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/10\/06\/shakira-improving-latino-education-crucial-community-and-americas-economic-competiti",
      "display_url" : "whitehouse.gov\/blog\/2011\/10\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "122084449960726528",
  "text" : "RT @shakira: \"The only road out of poverty is education.\" Read Shakira's post for the White House Blog http:\/\/t.co\/DdaASUZG ShakiraHQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/DdaASUZG",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/10\/06\/shakira-improving-latino-education-crucial-community-and-americas-economic-competiti",
        "display_url" : "whitehouse.gov\/blog\/2011\/10\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "122055800561741824",
    "text" : "\"The only road out of poverty is education.\" Read Shakira's post for the White House Blog http:\/\/t.co\/DdaASUZG ShakiraHQ",
    "id" : 122055800561741824,
    "created_at" : "2011-10-06 21:09:05 +0000",
    "user" : {
      "name" : "Shakira",
      "screen_name" : "shakira",
      "protected" : false,
      "id_str" : "44409004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791639027246108676\/l1qDkkpi_normal.jpg",
      "id" : 44409004,
      "verified" : true
    }
  },
  "id" : 122084449960726528,
  "created_at" : "2011-10-06 23:02:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 82, 87 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/14gor4M0",
      "expanded_url" : "http:\/\/wh.gov\/2jX",
      "display_url" : "wh.gov\/2jX"
    } ]
  },
  "geo" : { },
  "id_str" : "122059045896073217",
  "text" : "FACT CHECK: The real reasons Republicans in Congress are blocking Richard Cordray @CFPB: http:\/\/t.co\/14gor4M0",
  "id" : 122059045896073217,
  "created_at" : "2011-10-06 21:21:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122030761846120448",
  "text" : "RT @pfeiffer44: Independent forecasters say the American Jobs Act will create up to 2 million jobs, I wonder what those forecasters wld  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122015533578199040",
    "text" : "Independent forecasters say the American Jobs Act will create up to 2 million jobs, I wonder what those forecasters wld say abt the GOP plan",
    "id" : 122015533578199040,
    "created_at" : "2011-10-06 18:29:04 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 122030761846120448,
  "created_at" : "2011-10-06 19:29:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "122004744108646401",
  "text" : "Starting soon: President Obama Honors the 2011 NCAA National Champions Texas A&M Women\u2019s Basketball Team. Watch live: http:\/\/t.co\/QDIpMRKE",
  "id" : 122004744108646401,
  "created_at" : "2011-10-06 17:46:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121976210262732800",
  "text" : "RT @WHLive: Obama: Here's a homework assignment for folks: Go ask the Rs what their jobs plan is, if they're opposed to the American Job ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121975510644428801",
    "text" : "Obama: Here's a homework assignment for folks: Go ask the Rs what their jobs plan is, if they're opposed to the American Jobs Act",
    "id" : 121975510644428801,
    "created_at" : "2011-10-06 15:50:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121976210262732800,
  "created_at" : "2011-10-06 15:52:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121974797356908544",
  "text" : "RT @WHLive: Obama: I am always open to negotiations. What is also true is they need to do something.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121974581501235200",
    "text" : "Obama: I am always open to negotiations. What is also true is they need to do something.",
    "id" : 121974581501235200,
    "created_at" : "2011-10-06 15:46:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121974797356908544,
  "created_at" : "2011-10-06 15:47:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupywallstreet",
      "indices" : [ 21, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121971005815144448",
  "text" : "RT @WHLive: Obama on #occupywallstreet: Protesters are giving voice to a more broad based frustration about how our financial system works.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "occupywallstreet",
        "indices" : [ 9, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121970722389245952",
    "text" : "Obama on #occupywallstreet: Protesters are giving voice to a more broad based frustration about how our financial system works.",
    "id" : 121970722389245952,
    "created_at" : "2011-10-06 15:31:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121971005815144448,
  "created_at" : "2011-10-06 15:32:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 110, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121968890875092992",
  "text" : "RT @WHLive: Obama: The American people haven't seen congress come together & act. This is a good opportunity. #countrybeforeparty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "countrybeforeparty",
        "indices" : [ 98, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121968283976089600",
    "text" : "Obama: The American people haven't seen congress come together & act. This is a good opportunity. #countrybeforeparty",
    "id" : 121968283976089600,
    "created_at" : "2011-10-06 15:21:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121968890875092992,
  "created_at" : "2011-10-06 15:23:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121966189336477696",
  "text" : "RT @WHLive: Obama: My expectation & hope is that everyone will vote for this jobs bill because it reflects ideas that have been supporte ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121966139835293696",
    "text" : "Obama: My expectation & hope is that everyone will vote for this jobs bill because it reflects ideas that have been supported by Ds & Rs",
    "id" : 121966139835293696,
    "created_at" : "2011-10-06 15:12:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121966189336477696,
  "created_at" : "2011-10-06 15:13:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 83, 90 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "121965236810022912",
  "text" : "President Obama is taking questions now. Watch live: http:\/\/t.co\/QDIpMRKE & follow @WHLive",
  "id" : 121965236810022912,
  "created_at" : "2011-10-06 15:09:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121964919934554113",
  "text" : "RT @WHLive: Obama: There are too many people hurting in this country for us to do nothing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121964557248892929",
    "text" : "Obama: There are too many people hurting in this country for us to do nothing.",
    "id" : 121964557248892929,
    "created_at" : "2011-10-06 15:06:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121964919934554113,
  "created_at" : "2011-10-06 15:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121964619702075392",
  "text" : "RT @WHLive: Obama: We can either keep taxes exactly as they are...or we can put teachers & construction workers & veterans back on the job.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121964480610566144",
    "text" : "Obama: We can either keep taxes exactly as they are...or we can put teachers & construction workers & veterans back on the job.",
    "id" : 121964480610566144,
    "created_at" : "2011-10-06 15:06:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121964619702075392,
  "created_at" : "2011-10-06 15:06:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121964604480958464",
  "text" : "RT @WHLive: Obama: Some see this as class warfare, but I see it as a simple choice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121964343763025920",
    "text" : "Obama: Some see this as class warfare, but I see it as a simple choice.",
    "id" : 121964343763025920,
    "created_at" : "2011-10-06 15:05:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121964604480958464,
  "created_at" : "2011-10-06 15:06:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121964590480375808",
  "text" : "RT @WHLive: Obama: Which is why this jobs bill is fully paid for by asking millionaires & billionaires to pay their fair share.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121964297193652225",
    "text" : "Obama: Which is why this jobs bill is fully paid for by asking millionaires & billionaires to pay their fair share.",
    "id" : 121964297193652225,
    "created_at" : "2011-10-06 15:05:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121964590480375808,
  "created_at" : "2011-10-06 15:06:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121963797744320512",
  "text" : "RT @WHLive: Obama: This jobs bill would cut taxes for virtually every worker & small business in America.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121963534115545088",
    "text" : "Obama: This jobs bill would cut taxes for virtually every worker & small business in America.",
    "id" : 121963534115545088,
    "created_at" : "2011-10-06 15:02:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121963797744320512,
  "created_at" : "2011-10-06 15:03:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121963479597973504",
  "text" : "RT @WHLive: Obama: Independent experts...have said this jobs bill will have a profound effect for our economy & middle-class families al ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121963250878390273",
    "text" : "Obama: Independent experts...have said this jobs bill will have a profound effect for our economy & middle-class families all across America",
    "id" : 121963250878390273,
    "created_at" : "2011-10-06 15:01:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121963479597973504,
  "created_at" : "2011-10-06 15:02:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/xrOHuqTm",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "121958056635543552",
  "text" : "RT @WHLive: 11:00 ET: President Obama holds a news conference @ the White House. Watch live: http:\/\/t.co\/xrOHuqTm Follow live tweeting:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 124, 131 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/xrOHuqTm",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "121957956383281152",
    "text" : "11:00 ET: President Obama holds a news conference @ the White House. Watch live: http:\/\/t.co\/xrOHuqTm Follow live tweeting: @WHLive",
    "id" : 121957956383281152,
    "created_at" : "2011-10-06 14:40:17 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121958056635543552,
  "created_at" : "2011-10-06 14:40:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "121925321820880898",
  "text" : "Happening @ 11:00 ET: President Obama will hold a news conference in the East Room. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 121925321820880898,
  "created_at" : "2011-10-06 12:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SteveJobs",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121816538822094848",
  "text" : "\"Brave enough to think differently, bold enough to believe he could change the world & talented enough to do it\" -Obama on #SteveJobs",
  "id" : 121816538822094848,
  "created_at" : "2011-10-06 05:18:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/cgd7KMp6",
      "expanded_url" : "http:\/\/wh.gov\/22W",
      "display_url" : "wh.gov\/22W"
    } ]
  },
  "geo" : { },
  "id_str" : "121765140902313985",
  "text" : "\"The world has lost a visionary\" -President Obama on the passing of Steve Jobs. Statement: http:\/\/t.co\/cgd7KMp6",
  "id" : 121765140902313985,
  "created_at" : "2011-10-06 01:54:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/cgd7KMp6",
      "expanded_url" : "http:\/\/wh.gov\/22W",
      "display_url" : "wh.gov\/22W"
    } ]
  },
  "geo" : { },
  "id_str" : "121760070013947904",
  "text" : "President Obama on Steve Jobs: \"Bold enough to believe he could change the world & talented enough to do it\" http:\/\/t.co\/cgd7KMp6",
  "id" : 121760070013947904,
  "created_at" : "2011-10-06 01:33:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/43Y0U1Kf",
      "expanded_url" : "http:\/\/1.usa.gov\/obyahI",
      "display_url" : "1.usa.gov\/obyahI"
    } ]
  },
  "geo" : { },
  "id_str" : "121756197773783040",
  "text" : "\"He changed the way each of us sees the world\" -President Obama on the on the passing of Steve Jobs: http:\/\/t.co\/43Y0U1Kf",
  "id" : 121756197773783040,
  "created_at" : "2011-10-06 01:18:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DOD Warrior Care",
      "screen_name" : "WarriorCare",
      "indices" : [ 104, 116 ],
      "id_str" : "128645212",
      "id" : 128645212
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "troops",
      "indices" : [ 29, 36 ]
    }, {
      "text" : "vets",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/0bgWGGFA",
      "expanded_url" : "http:\/\/1.usa.gov\/old93w",
      "display_url" : "1.usa.gov\/old93w"
    } ]
  },
  "geo" : { },
  "id_str" : "121731333788672000",
  "text" : "Important information on how #troops & #vets can still file for Stop Loss Pay: http:\/\/t.co\/0bgWGGFA cc: @warriorcare",
  "id" : 121731333788672000,
  "created_at" : "2011-10-05 23:39:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/121716268058411008\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/lyEnY7FB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AbBsTQmCAAAUTYG.jpg",
      "id_str" : "121716268066799616",
      "id" : 121716268066799616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AbBsTQmCAAAUTYG.jpg",
      "sizes" : [ {
        "h" : 705,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1322,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lyEnY7FB"
    } ],
    "hashtags" : [ {
      "text" : "Texas",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121716268058411008",
  "text" : "Photo of the Day: President Obama talks to kids @ the Lab School's early childhood education classroom in #Texas: http:\/\/t.co\/lyEnY7FB",
  "id" : 121716268058411008,
  "created_at" : "2011-10-05 22:39:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 120, 129 ]
    }, {
      "text" : "WHTweetup",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/8XnxCwQJ",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "121659277298499584",
  "text" : "RT @letsmove: Happening @ 3ET: Michelle Obama Harvests the White House Kitchen Garden. Watch live: http:\/\/t.co\/8XnxCwQJ #LetsMove #WHTweetup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 106, 115 ]
      }, {
        "text" : "WHTweetup",
        "indices" : [ 116, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/8XnxCwQJ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "121659079453179904",
    "text" : "Happening @ 3ET: Michelle Obama Harvests the White House Kitchen Garden. Watch live: http:\/\/t.co\/8XnxCwQJ #LetsMove #WHTweetup",
    "id" : 121659079453179904,
    "created_at" : "2011-10-05 18:52:39 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 121659277298499584,
  "created_at" : "2011-10-05 18:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericanJobsAct",
      "indices" : [ 42, 58 ]
    }, {
      "text" : "video",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/r01KKJYa",
      "expanded_url" : "http:\/\/bit.ly\/nCjFeL",
      "display_url" : "bit.ly\/nCjFeL"
    } ]
  },
  "geo" : { },
  "id_str" : "121614670883856385",
  "text" : "RT @RayLaHood: Why am I excited about the #AmericanJobsAct? Watch this #video: http:\/\/t.co\/r01KKJYa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmericanJobsAct",
        "indices" : [ 27, 43 ]
      }, {
        "text" : "video",
        "indices" : [ 56, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/r01KKJYa",
        "expanded_url" : "http:\/\/bit.ly\/nCjFeL",
        "display_url" : "bit.ly\/nCjFeL"
      } ]
    },
    "geo" : { },
    "id_str" : "121595367723765760",
    "text" : "Why am I excited about the #AmericanJobsAct? Watch this #video: http:\/\/t.co\/r01KKJYa",
    "id" : 121595367723765760,
    "created_at" : "2011-10-05 14:39:29 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 121614670883856385,
  "created_at" : "2011-10-05 15:56:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachers",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "jobs",
      "indices" : [ 77, 82 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/cjZG2Pb8",
      "expanded_url" : "http:\/\/1.usa.gov\/n8BMKX",
      "display_url" : "1.usa.gov\/n8BMKX"
    } ]
  },
  "geo" : { },
  "id_str" : "121590467983974401",
  "text" : "The American Jobs Act will prevent up to 280,000 #teachers from losing their #jobs: http:\/\/t.co\/cjZG2Pb8 #JobsNow",
  "id" : 121590467983974401,
  "created_at" : "2011-10-05 14:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 38, 45 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/121359846720286720\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/l0ZGmDIZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aa8oIzoCMAIbIQM.jpg",
      "id_str" : "121359846724481026",
      "id" : 121359846724481026,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aa8oIzoCMAIbIQM.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/l0ZGmDIZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121359846720286720",
  "text" : "Photo of the Day: Obama congratulates @Google Science Fair winners Naomi Shah, Shree Bose & Lauren Hodge in the Oval: http:\/\/t.co\/l0ZGmDIZ",
  "id" : 121359846720286720,
  "created_at" : "2011-10-04 23:03:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121354170145058816",
  "text" : "RT @jesseclee44: \"Mr. Cantor should come...look Kim Russell in the eye & tell her why she doesn't deserve to be back in the classroom\" h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/ZKkPHXLQ",
        "expanded_url" : "http:\/\/wh.gov\/2C8",
        "display_url" : "wh.gov\/2C8"
      } ]
    },
    "geo" : { },
    "id_str" : "121353872060067842",
    "text" : "\"Mr. Cantor should come...look Kim Russell in the eye & tell her why she doesn't deserve to be back in the classroom\" http:\/\/t.co\/ZKkPHXLQ",
    "id" : 121353872060067842,
    "created_at" : "2011-10-04 22:39:52 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 121354170145058816,
  "created_at" : "2011-10-04 22:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121317468340895745",
  "text" : "RT @WHLive: Obama: Well I\u2019d like Mr. Cantor to come down here to Dallas and explain what exactly in this jobs bill he doesn\u2019t believe in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121316902638325760",
    "text" : "Obama: Well I\u2019d like Mr. Cantor to come down here to Dallas and explain what exactly in this jobs bill he doesn\u2019t believe in.",
    "id" : 121316902638325760,
    "created_at" : "2011-10-04 20:12:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121317468340895745,
  "created_at" : "2011-10-04 20:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121316947076972544",
  "text" : "RT @WHLive: Obama: Yesterday, the Republican Majority Leader, Eric Cantor, said that he won\u2019t even let the jobs bill have a vote in the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121316696383426561",
    "text" : "Obama: Yesterday, the Republican Majority Leader, Eric Cantor, said that he won\u2019t even let the jobs bill have a vote in the House of Reps.",
    "id" : 121316696383426561,
    "created_at" : "2011-10-04 20:12:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121316947076972544,
  "created_at" : "2011-10-04 20:13:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121315197129457664",
  "text" : "RT @WHLive: Obama: It\u2019s time to reform our tax code based on a simple principle: Middle-class families shouldn\u2019t pay higher tax rates th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121314755959996416",
    "text" : "Obama: It\u2019s time to reform our tax code based on a simple principle: Middle-class families shouldn\u2019t pay higher tax rates than millionaires",
    "id" : 121314755959996416,
    "created_at" : "2011-10-04 20:04:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121315197129457664,
  "created_at" : "2011-10-04 20:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121315028124172288",
  "text" : "RT @WHLive: Obama: If the American Jobs Act passes, the typical working family in Texas will get a tax cut worth about fourteen hundred  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121313933729603585",
    "text" : "Obama: If the American Jobs Act passes, the typical working family in Texas will get a tax cut worth about fourteen hundred dollars.",
    "id" : 121313933729603585,
    "created_at" : "2011-10-04 20:01:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121315028124172288,
  "created_at" : "2011-10-04 20:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121312485952339968",
  "text" : "RT @WHLive: Obama: This bill will prevent up to 280,000 teachers from losing their jobs \u2013 and support almost 40,000 jobs right here in T ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121312372517371905",
    "text" : "Obama: This bill will prevent up to 280,000 teachers from losing their jobs \u2013 and support almost 40,000 jobs right here in Texas. #JobsNow",
    "id" : 121312372517371905,
    "created_at" : "2011-10-04 19:54:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121312485952339968,
  "created_at" : "2011-10-04 19:55:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121311211496288256",
  "text" : "RT @WHLive: Starting: President Obama speaks on the American Jobs Act live from Eastfield College in Mesquite, TX. Watch: http:\/\/t.co\/g5 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "121311076133502976",
    "text" : "Starting: President Obama speaks on the American Jobs Act live from Eastfield College in Mesquite, TX. Watch: http:\/\/t.co\/g5ih2w0F #JobsNow",
    "id" : 121311076133502976,
    "created_at" : "2011-10-04 19:49:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 121311211496288256,
  "created_at" : "2011-10-04 19:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 127, 134 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "121274423474003971",
  "text" : "Happening @ 3:55 pm EDT: President Obama speaks on the American Jobs Act from Mesquite, TX. Watch: http:\/\/t.co\/u95y7hhB Follow @WHLive",
  "id" : 121274423474003971,
  "created_at" : "2011-10-04 17:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 35, 44 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskMichelle",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121240769779609600",
  "text" : "RT @letsmove: Do you have Qs about @LetsMove, the First Lady's initiative to end childhood obesity? Use #AskMichelle on Twitter: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 21, 30 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskMichelle",
        "indices" : [ 90, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/EyhM0bK7",
        "expanded_url" : "http:\/\/1.usa.gov\/pktzwD",
        "display_url" : "1.usa.gov\/pktzwD"
      } ]
    },
    "geo" : { },
    "id_str" : "121240458784542720",
    "text" : "Do you have Qs about @LetsMove, the First Lady's initiative to end childhood obesity? Use #AskMichelle on Twitter: http:\/\/t.co\/EyhM0bK7",
    "id" : 121240458784542720,
    "created_at" : "2011-10-04 15:09:12 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 121240769779609600,
  "created_at" : "2011-10-04 15:10:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/HbGny73N",
      "expanded_url" : "http:\/\/n.pr\/qYTPKR",
      "display_url" : "n.pr\/qYTPKR"
    } ]
  },
  "geo" : { },
  "id_str" : "121229966724698112",
  "text" : "RT @pfeiffer44: GOP Rep Stearns on NPR \"We can't compete with China to make solar panels and wind turbines\" http:\/\/t.co\/HbGny73N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/HbGny73N",
        "expanded_url" : "http:\/\/n.pr\/qYTPKR",
        "display_url" : "n.pr\/qYTPKR"
      } ]
    },
    "geo" : { },
    "id_str" : "121228312877088768",
    "text" : "GOP Rep Stearns on NPR \"We can't compete with China to make solar panels and wind turbines\" http:\/\/t.co\/HbGny73N",
    "id" : 121228312877088768,
    "created_at" : "2011-10-04 14:20:56 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 121229966724698112,
  "created_at" : "2011-10-04 14:27:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAP44",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120979030257311746",
  "text" : "RT @OMBPress: Admin strongly opposes HRs 2250 + 2681; undermine Clean Air Act, hurt public health. Sr. Adv. would rec. veto. #SAP44 http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SAP44",
        "indices" : [ 111, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/IGTStOIh",
        "expanded_url" : "http:\/\/1.usa.gov\/qRtJwk",
        "display_url" : "1.usa.gov\/qRtJwk"
      } ]
    },
    "geo" : { },
    "id_str" : "120976428547317762",
    "text" : "Admin strongly opposes HRs 2250 + 2681; undermine Clean Air Act, hurt public health. Sr. Adv. would rec. veto. #SAP44 http:\/\/t.co\/IGTStOIh",
    "id" : 120976428547317762,
    "created_at" : "2011-10-03 21:40:02 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 120979030257311746,
  "created_at" : "2011-10-03 21:50:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 74, 82 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeThePeople",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/zrxeS5L9",
      "expanded_url" : "http:\/\/1.usa.gov\/pbPk6m",
      "display_url" : "1.usa.gov\/pbPk6m"
    } ]
  },
  "geo" : { },
  "id_str" : "120969088154607616",
  "text" : "We're raising the signature threshold for WH petitions tool #WeThePeople. @Macon44 on a good problem to have: http:\/\/t.co\/zrxeS5L9",
  "id" : 120969088154607616,
  "created_at" : "2011-10-03 21:10:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo News",
      "screen_name" : "YahooNews",
      "indices" : [ 3, 13 ],
      "id_str" : "7309052",
      "id" : 7309052
    }, {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 63, 69 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 71, 75 ],
      "id_str" : "28785486",
      "id" : 28785486
    }, {
      "name" : "GeorgeStephanopoulos",
      "screen_name" : "GStephanopoulos",
      "indices" : [ 89, 105 ],
      "id_str" : "17074440",
      "id" : 17074440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/V6JcY0al",
      "expanded_url" : "http:\/\/yhoo.it\/ozV8WY",
      "display_url" : "yhoo.it\/ozV8WY"
    } ]
  },
  "geo" : { },
  "id_str" : "120934122930716672",
  "text" : "RT @YahooNews: WATCH LIVE: Pres. #Obama answers questions from @Yahoo, @ABC readers with @GStephanopoulos: http:\/\/t.co\/V6JcY0al",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yahoo",
        "screen_name" : "Yahoo",
        "indices" : [ 48, 54 ],
        "id_str" : "19380829",
        "id" : 19380829
      }, {
        "name" : "ABC News",
        "screen_name" : "ABC",
        "indices" : [ 56, 60 ],
        "id_str" : "28785486",
        "id" : 28785486
      }, {
        "name" : "GeorgeStephanopoulos",
        "screen_name" : "GStephanopoulos",
        "indices" : [ 74, 90 ],
        "id_str" : "17074440",
        "id" : 17074440
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 18, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/V6JcY0al",
        "expanded_url" : "http:\/\/yhoo.it\/ozV8WY",
        "display_url" : "yhoo.it\/ozV8WY"
      } ]
    },
    "geo" : { },
    "id_str" : "120930387080912898",
    "text" : "WATCH LIVE: Pres. #Obama answers questions from @Yahoo, @ABC readers with @GStephanopoulos: http:\/\/t.co\/V6JcY0al",
    "id" : 120930387080912898,
    "created_at" : "2011-10-03 18:37:05 +0000",
    "user" : {
      "name" : "Yahoo News",
      "screen_name" : "YahooNews",
      "protected" : false,
      "id_str" : "7309052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461884598608080896\/-JRj7OdX_normal.jpeg",
      "id" : 7309052,
      "verified" : true
    }
  },
  "id" : 120934122930716672,
  "created_at" : "2011-10-03 18:51:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeorgeStephanopoulos",
      "screen_name" : "GStephanopoulos",
      "indices" : [ 15, 31 ],
      "id_str" : "17074440",
      "id" : 17074440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/z3vHWujC",
      "expanded_url" : "http:\/\/abcnews.com",
      "display_url" : "abcnews.com"
    }, {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/8zTKL6yE",
      "expanded_url" : "http:\/\/www.yahoo.com",
      "display_url" : "yahoo.com"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/3Pgjsgq8",
      "expanded_url" : "http:\/\/www.wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "120932639086620673",
  "text" : "Happening now: @GStephanopoulos interviews President Obama. Watch live: http:\/\/t.co\/z3vHWujC, http:\/\/t.co\/8zTKL6yE & http:\/\/t.co\/3Pgjsgq8",
  "id" : 120932639086620673,
  "created_at" : "2011-10-03 18:46:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ABC News Live",
      "screen_name" : "ABCNewsLive",
      "indices" : [ 3, 15 ],
      "id_str" : "384438102",
      "id" : 384438102
    }, {
      "name" : "GeorgeStephanopoulos",
      "screen_name" : "GStephanopoulos",
      "indices" : [ 28, 44 ],
      "id_str" : "17074440",
      "id" : 17074440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/wKzwkwVX",
      "expanded_url" : "http:\/\/ABCNews.com",
      "display_url" : "ABCNews.com"
    } ]
  },
  "geo" : { },
  "id_str" : "120929186591408128",
  "text" : "RT @ABCNewsLive: Stay tuned @GStephanopoulos exclusive interview with Pres Obama on http:\/\/t.co\/wKzwkwVX at 2:35 p.m. ET #AskObama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GeorgeStephanopoulos",
        "screen_name" : "GStephanopoulos",
        "indices" : [ 11, 27 ],
        "id_str" : "17074440",
        "id" : 17074440
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskObama",
        "indices" : [ 104, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/wKzwkwVX",
        "expanded_url" : "http:\/\/ABCNews.com",
        "display_url" : "ABCNews.com"
      } ]
    },
    "geo" : { },
    "id_str" : "120925994671554560",
    "text" : "Stay tuned @GStephanopoulos exclusive interview with Pres Obama on http:\/\/t.co\/wKzwkwVX at 2:35 p.m. ET #AskObama",
    "id" : 120925994671554560,
    "created_at" : "2011-10-03 18:19:38 +0000",
    "user" : {
      "name" : "ABC News Live",
      "screen_name" : "ABCNewsLive",
      "protected" : false,
      "id_str" : "384438102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716986323525984257\/V6PIe6uL_normal.jpg",
      "id" : 384438102,
      "verified" : true
    }
  },
  "id" : 120929186591408128,
  "created_at" : "2011-10-03 18:32:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Greg Sargent",
      "screen_name" : "ThePlumLineGS",
      "indices" : [ 117, 131 ],
      "id_str" : "20508720",
      "id" : 20508720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120913792254222336",
  "text" : "RT @jesseclee44: Reality Check: Chart on how Obama's plans make big impact on deficit w\/ small impact on wealthy via @ThePlumLineGS: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Greg Sargent",
        "screen_name" : "ThePlumLineGS",
        "indices" : [ 100, 114 ],
        "id_str" : "20508720",
        "id" : 20508720
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jesseclee44\/status\/120912824066248704\/photo\/1",
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/5SFilvPG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Aa2RkqeCEAA04Kj.jpg",
        "id_str" : "120912824070443008",
        "id" : 120912824070443008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aa2RkqeCEAA04Kj.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/5SFilvPG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120912824066248704",
    "text" : "Reality Check: Chart on how Obama's plans make big impact on deficit w\/ small impact on wealthy via @ThePlumLineGS: http:\/\/t.co\/5SFilvPG",
    "id" : 120912824066248704,
    "created_at" : "2011-10-03 17:27:18 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 120913792254222336,
  "created_at" : "2011-10-03 17:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HumanRightsCampaign",
      "screen_name" : "HRC",
      "indices" : [ 103, 107 ],
      "id_str" : "19608297",
      "id" : 19608297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/YHDo4rvG",
      "expanded_url" : "http:\/\/youtu.be\/ZB-4ZHmt82Y",
      "display_url" : "youtu.be\/ZB-4ZHmt82Y"
    } ]
  },
  "geo" : { },
  "id_str" : "120898727702577153",
  "text" : "\"We believe in a big America -- a tolerant America, a just America, an equal America\" -President Obama @HRC dinner: http:\/\/t.co\/YHDo4rvG",
  "id" : 120898727702577153,
  "created_at" : "2011-10-03 16:31:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/OHuqUqK1",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/10\/03\/honoring-hispanic-heritage",
      "display_url" : "whitehouse.gov\/blog\/2011\/10\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120895279326175234",
  "text" : "RT @VP: VP & Dr. B hosted a reception in honor of Hispanic Heritage Month @ the Naval Observatory last wk; BLOG POST http:\/\/t.co\/OHuqUqK1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/OHuqUqK1",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/10\/03\/honoring-hispanic-heritage",
        "display_url" : "whitehouse.gov\/blog\/2011\/10\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "120895016284602369",
    "text" : "VP & Dr. B hosted a reception in honor of Hispanic Heritage Month @ the Naval Observatory last wk; BLOG POST http:\/\/t.co\/OHuqUqK1",
    "id" : 120895016284602369,
    "created_at" : "2011-10-03 16:16:32 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 120895279326175234,
  "created_at" : "2011-10-03 16:17:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/6U3rW4sD",
      "expanded_url" : "http:\/\/bit.ly\/qpRTwE",
      "display_url" : "bit.ly\/qpRTwE"
    } ]
  },
  "geo" : { },
  "id_str" : "120875415203098624",
  "text" : "RT @jesseclee44: Reagan: \"Do you think the millionaire ought to pay more in taxes than the bus driver or less?\" http:\/\/t.co\/6U3rW4sD  #p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 117, 120 ]
      }, {
        "text" : "tcot",
        "indices" : [ 121, 126 ]
      }, {
        "text" : "goodquestion",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/6U3rW4sD",
        "expanded_url" : "http:\/\/bit.ly\/qpRTwE",
        "display_url" : "bit.ly\/qpRTwE"
      } ]
    },
    "geo" : { },
    "id_str" : "120858650481930240",
    "text" : "Reagan: \"Do you think the millionaire ought to pay more in taxes than the bus driver or less?\" http:\/\/t.co\/6U3rW4sD  #p2 #tcot #goodquestion",
    "id" : 120858650481930240,
    "created_at" : "2011-10-03 13:52:02 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 120875415203098624,
  "created_at" : "2011-10-03 14:58:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 53, 58 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/uNzzOgHN",
      "expanded_url" : "http:\/\/youtu.be\/R8-8pTldXUM",
      "display_url" : "youtu.be\/R8-8pTldXUM"
    } ]
  },
  "geo" : { },
  "id_str" : "120161080235393024",
  "text" : "\"It is time for the politics to end. Let\u2019s pass this #jobs bill.\" -President Barack Obama: http:\/\/t.co\/uNzzOgHN #JobsNow",
  "id" : 120161080235393024,
  "created_at" : "2011-10-01 15:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]