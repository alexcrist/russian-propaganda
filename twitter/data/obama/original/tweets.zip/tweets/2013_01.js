Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/297137502886707201\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/TMhxaCcM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BB-k_A2CQAAVSBL.jpg",
      "id_str" : "297137502895095808",
      "id" : 297137502895095808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB-k_A2CQAAVSBL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/TMhxaCcM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297143851305537536",
  "text" : "Photo of the Day: A view from outside the Oval Office, President Obama meets with outgoing Chief of Staff Jack Lew: http:\/\/t.co\/TMhxaCcM",
  "id" : 297143851305537536,
  "created_at" : "2013-02-01 00:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 37, 48 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiresideHangout",
      "indices" : [ 49, 65 ]
    }, {
      "text" : "ImmigrationReform",
      "indices" : [ 88, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/XinnGbw3",
      "expanded_url" : "http:\/\/at.wh.gov\/hjjAE",
      "display_url" : "at.wh.gov\/hjjAE"
    } ]
  },
  "geo" : { },
  "id_str" : "297096479795982336",
  "text" : "In case you missed it: Watch today's @Whitehouse #FiresideHangout with Cecilia Mu\u00F1oz on #ImmigrationReform: http:\/\/t.co\/XinnGbw3",
  "id" : 297096479795982336,
  "created_at" : "2013-01-31 21:38:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "indices" : [ 77, 91 ],
      "id_str" : "15956067",
      "id" : 15956067
    }, {
      "name" : "America Ferrera",
      "screen_name" : "AmericaFerrera",
      "indices" : [ 92, 107 ],
      "id_str" : "531561605",
      "id" : 531561605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 53, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/LvSBBvvI",
      "expanded_url" : "http:\/\/at.wh.gov\/hiUuz",
      "display_url" : "at.wh.gov\/hiUuz"
    } ]
  },
  "geo" : { },
  "id_str" : "297041729046061056",
  "text" : "Happening now: Cecilia Mu\u00F1oz joins a conversation on #ImmigrationReform with @joseiswriting @AmericaFerrera. Watch: http:\/\/t.co\/LvSBBvvI",
  "id" : 297041729046061056,
  "created_at" : "2013-01-31 18:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 76, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/u1ur1Jsb",
      "expanded_url" : "http:\/\/at.wh.gov\/hiR2m",
      "display_url" : "at.wh.gov\/hiR2m"
    } ]
  },
  "geo" : { },
  "id_str" : "297035785654398976",
  "text" : "Join Cecilia Mu\u00F1oz, Domestic Policy Council Director, for a conversation on #ImmigrationReform today at 1ET: http:\/\/t.co\/u1ur1Jsb",
  "id" : 297035785654398976,
  "created_at" : "2013-01-31 17:37:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "indices" : [ 38, 52 ],
      "id_str" : "15956067",
      "id" : 15956067
    }, {
      "name" : "America Ferrera",
      "screen_name" : "AmericaFerrera",
      "indices" : [ 53, 68 ],
      "id_str" : "531561605",
      "id" : 531561605
    }, {
      "name" : "Shervin",
      "screen_name" : "shervin",
      "indices" : [ 69, 77 ],
      "id_str" : "1159251",
      "id" : 1159251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/dgepCpoy",
      "expanded_url" : "http:\/\/on.wh.gov\/JPjt30N",
      "display_url" : "on.wh.gov\/JPjt30N"
    } ]
  },
  "geo" : { },
  "id_str" : "297009022421327874",
  "text" : "Watch live @ 1ET: Cecilia Mu\u00F1oz joins @joseiswriting @AmericaFerrera @shervin for a G+ hangout on #ImmigrationReform: http:\/\/t.co\/dgepCpoy",
  "id" : 297009022421327874,
  "created_at" : "2013-01-31 15:50:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 26, 40 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/296742559361933312\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/5pMOcWrH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BB49yRkCIAEveOD.jpg",
      "id_str" : "296742559370321921",
      "id" : 296742559370321921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB49yRkCIAEveOD.jpg",
      "sizes" : [ {
        "h" : 743,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 361,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 637,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 743,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/5pMOcWrH"
    } ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/jBWOchnp",
      "expanded_url" : "http:\/\/www.wh.gov\/now-is-the-time",
      "display_url" : "wh.gov\/now-is-the-time"
    } ]
  },
  "geo" : { },
  "id_str" : "296742559361933312",
  "text" : "\"Be bold, be courageous\" \u2014@GabbyGiffords to Congress on addressing gun violence: http:\/\/t.co\/jBWOchnp #NowIsTheTime http:\/\/t.co\/5pMOcWrH",
  "id" : 296742559361933312,
  "created_at" : "2013-01-30 22:11:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "indices" : [ 3, 17 ],
      "id_str" : "15956067",
      "id" : 15956067
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 103, 114 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296733294953906176",
  "text" : "RT @joseiswriting: Tomorrow at 1p, I'm moderating a live Google+ chat on #immigration reform featuring @whitehouse's Cecilia Munoz: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 84, 95 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 54, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/WdN0e91X",
        "expanded_url" : "http:\/\/wh.gov\/VEvY",
        "display_url" : "wh.gov\/VEvY"
      } ]
    },
    "geo" : { },
    "id_str" : "296723172819095552",
    "text" : "Tomorrow at 1p, I'm moderating a live Google+ chat on #immigration reform featuring @whitehouse's Cecilia Munoz: http:\/\/t.co\/WdN0e91X",
    "id" : 296723172819095552,
    "created_at" : "2013-01-30 20:54:51 +0000",
    "user" : {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "protected" : false,
      "id_str" : "15956067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757233757313048576\/1M_uZ0ss_normal.jpg",
      "id" : 15956067,
      "verified" : true
    }
  },
  "id" : 296733294953906176,
  "created_at" : "2013-01-30 21:35:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "indices" : [ 39, 53 ],
      "id_str" : "15956067",
      "id" : 15956067
    }, {
      "name" : "Jim Wallis",
      "screen_name" : "jimwallis",
      "indices" : [ 54, 64 ],
      "id_str" : "17322445",
      "id" : 17322445
    }, {
      "name" : "America Ferrera",
      "screen_name" : "AmericaFerrera",
      "indices" : [ 65, 80 ],
      "id_str" : "531561605",
      "id" : 531561605
    }, {
      "name" : "Shervin",
      "screen_name" : "shervin",
      "indices" : [ 81, 89 ],
      "id_str" : "1159251",
      "id" : 1159251
    }, {
      "name" : "Cristina Jimenez",
      "screen_name" : "UWDCristina",
      "indices" : [ 90, 102 ],
      "id_str" : "2811809778",
      "id" : 2811809778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 14, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/yqj7vWIM",
      "expanded_url" : "http:\/\/on.wh.gov\/N3y6wP7",
      "display_url" : "on.wh.gov\/N3y6wP7"
    } ]
  },
  "geo" : { },
  "id_str" : "296723774491983872",
  "text" : "WH Hangout on #ImmigrationReform: Join @joseiswriting @jimwallis @AmericaFerrera @shervin @UWDCristina on 1\/31 at 1ET: http:\/\/t.co\/yqj7vWIM",
  "id" : 296723774491983872,
  "created_at" : "2013-01-30 20:57:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/296669903698681857\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/JXfiY25D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BB37tKHCYAAKqVB.jpg",
      "id_str" : "296669903702876160",
      "id" : 296669903702876160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB37tKHCYAAKqVB.jpg",
      "sizes" : [ {
        "h" : 989,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 989,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 989,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JXfiY25D"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 86, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/lGkBaPvj",
      "expanded_url" : "http:\/\/on.wh.gov\/7cjw9gb",
      "display_url" : "on.wh.gov\/7cjw9gb"
    } ]
  },
  "geo" : { },
  "id_str" : "296669903698681857",
  "text" : "RT if you agree: It's time to fix our broken immigration system: http:\/\/t.co\/lGkBaPvj #ImmigrationReform http:\/\/t.co\/JXfiY25D",
  "id" : 296669903698681857,
  "created_at" : "2013-01-30 17:23:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 15, 31 ],
      "id_str" : "65707359",
      "id" : 65707359
    }, {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 38, 52 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/AMPtkY8O",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/now-is-the-time",
      "display_url" : "whitehouse.gov\/now-is-the-time"
    } ]
  },
  "geo" : { },
  "id_str" : "296647109317365760",
  "text" : "RT @VP: Today, @ShuttleCDRKelly &amp; @GabbyGiffords speak out at hearing on gun violence. Add your voice, too: http:\/\/t.co\/AMPtkY8O  #N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Kelly",
        "screen_name" : "ShuttleCDRKelly",
        "indices" : [ 7, 23 ],
        "id_str" : "65707359",
        "id" : 65707359
      }, {
        "name" : "Gabrielle Giffords",
        "screen_name" : "GabbyGiffords",
        "indices" : [ 30, 44 ],
        "id_str" : "44177383",
        "id" : 44177383
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/AMPtkY8O",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/now-is-the-time",
        "display_url" : "whitehouse.gov\/now-is-the-time"
      } ]
    },
    "geo" : { },
    "id_str" : "296637767495077889",
    "text" : "Today, @ShuttleCDRKelly &amp; @GabbyGiffords speak out at hearing on gun violence. Add your voice, too: http:\/\/t.co\/AMPtkY8O  #NowIsTheTime",
    "id" : 296637767495077889,
    "created_at" : "2013-01-30 15:15:29 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 296647109317365760,
  "created_at" : "2013-01-30 15:52:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Make-A-Wish America",
      "screen_name" : "MakeAWish",
      "indices" : [ 73, 83 ],
      "id_str" : "61903300",
      "id" : 61903300
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/296465236305801217\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/zXa72dqU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BB1Bj8rCcAMYX92.jpg",
      "id_str" : "296465236314189827",
      "id" : 296465236314189827,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB1Bj8rCcAMYX92.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zXa72dqU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296465236305801217",
  "text" : "Photo of the Day: President Obama listens to Khari Joyner, a 21-year-old @MakeAWish recipient, play the cello: http:\/\/t.co\/zXa72dqU",
  "id" : 296465236305801217,
  "created_at" : "2013-01-30 03:49:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "indices" : [ 36, 50 ],
      "id_str" : "15956067",
      "id" : 15956067
    }, {
      "name" : "America Ferrera",
      "screen_name" : "AmericaFerrera",
      "indices" : [ 51, 66 ],
      "id_str" : "531561605",
      "id" : 531561605
    }, {
      "name" : "Jim Wallis",
      "screen_name" : "jimwallis",
      "indices" : [ 67, 77 ],
      "id_str" : "17322445",
      "id" : 17322445
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/AFsoCnEa",
      "expanded_url" : "http:\/\/wh.gov\/VEvY",
      "display_url" : "wh.gov\/VEvY"
    } ]
  },
  "geo" : { },
  "id_str" : "296415690074750977",
  "text" : "On 1\/31 at 1ET: Cecilia Mu\u00F1oz joins @joseiswriting @AmericaFerrera @jimwallis for a G+ Hangout on #ImmigrationReform: http:\/\/t.co\/AFsoCnEa",
  "id" : 296415690074750977,
  "created_at" : "2013-01-30 00:33:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296412126736691200",
  "text" : "RT @VP: State is in good hands-the hands of my good friend John Kerry -VP on Senate confirming Sen Kerry as Sec State (WHphoto) http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/296410221365047297\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/Uab7OEWU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BB0PhqCCMAA7_-f.jpg",
        "id_str" : "296410221369241600",
        "id" : 296410221369241600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BB0PhqCCMAA7_-f.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Uab7OEWU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296410221365047297",
    "text" : "State is in good hands-the hands of my good friend John Kerry -VP on Senate confirming Sen Kerry as Sec State (WHphoto) http:\/\/t.co\/Uab7OEWU",
    "id" : 296410221365047297,
    "created_at" : "2013-01-30 00:11:18 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 296412126736691200,
  "created_at" : "2013-01-30 00:18:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/296387732098383873\/photo\/1",
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/y6CLUigb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBz7Em_CAAEmO8R.jpg",
      "id_str" : "296387732102578177",
      "id" : 296387732102578177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBz7Em_CAAEmO8R.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/y6CLUigb"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 81, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296387732098383873",
  "text" : "\"This is not just a debate about policy. It\u2019s about people.\" \u2014President Obama on #ImmigrationReform http:\/\/t.co\/y6CLUigb",
  "id" : 296387732098383873,
  "created_at" : "2013-01-29 22:41:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 52, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/lwsmH4RN",
      "expanded_url" : "http:\/\/at.wh.gov\/hf1Pt",
      "display_url" : "at.wh.gov\/hf1Pt"
    } ]
  },
  "geo" : { },
  "id_str" : "296380428678471680",
  "text" : "Full video: President Obama speaks on comprehensive #ImmigrationReform: http:\/\/t.co\/lwsmH4RN",
  "id" : 296380428678471680,
  "created_at" : "2013-01-29 22:12:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/296372141115457539\/photo\/1",
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/GFtSr6DH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBzs5GECQAMslIc.jpg",
      "id_str" : "296372141123846147",
      "id" : 296372141123846147,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBzs5GECQAMslIc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 850
      } ],
      "display_url" : "pic.twitter.com\/GFtSr6DH"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 67, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296372760693846016",
  "text" : "RT @petesouza: Photo of Pres Obama immigration speech in Las Vegas #ImmigrationReform http:\/\/t.co\/GFtSr6DH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/296372141115457539\/photo\/1",
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/GFtSr6DH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBzs5GECQAMslIc.jpg",
        "id_str" : "296372141123846147",
        "id" : 296372141123846147,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBzs5GECQAMslIc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 567,
          "resize" : "fit",
          "w" : 850
        } ],
        "display_url" : "pic.twitter.com\/GFtSr6DH"
      } ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 52, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "296372141115457539",
    "text" : "Photo of Pres Obama immigration speech in Las Vegas #ImmigrationReform http:\/\/t.co\/GFtSr6DH",
    "id" : 296372141115457539,
    "created_at" : "2013-01-29 21:39:59 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 296372760693846016,
  "created_at" : "2013-01-29 21:42:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 103, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/MTRLg2dY",
      "expanded_url" : "http:\/\/at.wh.gov\/heRem",
      "display_url" : "at.wh.gov\/heRem"
    } ]
  },
  "geo" : { },
  "id_str" : "296357003352231937",
  "text" : "FACT SHEET: Fixing our Broken Immigration System so Everyone Plays by the Rules:  http:\/\/t.co\/MTRLg2dY #ImmigrationReform",
  "id" : 296357003352231937,
  "created_at" : "2013-01-29 20:39:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/296350033849233408\/photo\/1",
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/ARJ2nhTX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBzYySECMAAOSGX.jpg",
      "id_str" : "296350033853427712",
      "id" : 296350033853427712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBzYySECMAAOSGX.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ARJ2nhTX"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 27, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296350033849233408",
  "text" : "This is what comprehensive #ImmigrationReform looks like: http:\/\/t.co\/ARJ2nhTX",
  "id" : 296350033849233408,
  "created_at" : "2013-01-29 20:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296348527158771713",
  "text" : "\"Remember that this is not just a debate about policy. It\u2019s about people.\" \u2014President Obama on #ImmigrationReform",
  "id" : 296348527158771713,
  "created_at" : "2013-01-29 20:06:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296347668207251457",
  "text" : "Obama: \"They all came here knowing that what makes someone American isn\u2019t just blood or birth but allegiance to our founding principles.\"",
  "id" : 296347668207251457,
  "created_at" : "2013-01-29 20:02:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 56, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296346909965185025",
  "text" : "\"I believe we\u2019re finally at a moment when comprehensive #ImmigrationReform is within our grasp.\" \u2014President Obama",
  "id" : 296346909965185025,
  "created_at" : "2013-01-29 19:59:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296346501712580608",
  "text" : "Obama: \"Third, we have to bring our legal immigration system into the 21st century because it no longer reflects the realities of our time\"",
  "id" : 296346501712580608,
  "created_at" : "2013-01-29 19:58:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296346186875551744",
  "text" : "\"Second, we have to deal with the 11 million individuals who are here illegally.\" \u2014President Obama #ImmigrationReform",
  "id" : 296346186875551744,
  "created_at" : "2013-01-29 19:56:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 76, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296346027651366913",
  "text" : "\"First, I believe we need to stay focused on enforcement.\" \u2014President Obama #ImmigrationReform",
  "id" : 296346027651366913,
  "created_at" : "2013-01-29 19:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 125, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296345304465281025",
  "text" : "President Obama: \"For the first time in many years \u2013 Republicans &amp; Democrats seem ready to tackle this problem together.\"#ImmigrationReform",
  "id" : 296345304465281025,
  "created_at" : "2013-01-29 19:53:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 1, 11 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 109, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296344769641193474",
  "text" : "\"@Instagram was started with the help of an immigrant who studied here and stayed here.\" \u2014President Obama on #ImmigrationReform",
  "id" : 296344769641193474,
  "created_at" : "2013-01-29 19:51:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 126, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296344258464608259",
  "text" : "President Obama: \"We have to make sure that every business &amp; every worker in America is playing by the same set of rules\" #ImmigrationReform",
  "id" : 296344258464608259,
  "created_at" : "2013-01-29 19:49:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296344020613992448",
  "text" : "Obama: \"Now is the time to find a better way to welcome the striving, hopeful immigrants who still see America as the land of opportunity.\"",
  "id" : 296344020613992448,
  "created_at" : "2013-01-29 19:48:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 88, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "296343819673288705",
  "text" : "\"We define ourselves as a nation of immigrants.\" \u2014President Obama, http:\/\/t.co\/u95tzH8r #ImmigrationReform",
  "id" : 296343819673288705,
  "created_at" : "2013-01-29 19:47:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296343255321300992",
  "text" : "\"I\u2019m here today because the time has come for common-sense, comprehensive #ImmigrationReform. Now is the time.\" \u2014President Obama",
  "id" : 296343255321300992,
  "created_at" : "2013-01-29 19:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 112, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "296342665132392448",
  "text" : "Happening now: President Obama speaks on immigration reform from Las Vegas, Nevada. Watch: http:\/\/t.co\/u95tzH8r #ImmigrationReform",
  "id" : 296342665132392448,
  "created_at" : "2013-01-29 19:42:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/C4iYk2oW",
      "expanded_url" : "http:\/\/at.wh.gov\/heqn8",
      "display_url" : "at.wh.gov\/heqn8"
    } ]
  },
  "geo" : { },
  "id_str" : "296305023531495427",
  "text" : "Watch live at 2:55 ET: President Obama speaks on the need to fix the broken immigration system: http:\/\/t.co\/C4iYk2oW #ImmigrationReform",
  "id" : 296305023531495427,
  "created_at" : "2013-01-29 17:13:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SyriaAid",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/od2uBD46",
      "expanded_url" : "http:\/\/at.wh.gov\/he0Mo",
      "display_url" : "at.wh.gov\/he0Mo"
    }, {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/dz9q5uN1",
      "expanded_url" : "http:\/\/at.wh.gov\/he0Js",
      "display_url" : "at.wh.gov\/he0Js"
    } ]
  },
  "geo" : { },
  "id_str" : "296264369669554176",
  "text" : "President Obama announces additional humanitarian aid for the Syrian people: http:\/\/t.co\/od2uBD46 Watch: http:\/\/t.co\/dz9q5uN1 #SyriaAid",
  "id" : 296264369669554176,
  "created_at" : "2013-01-29 14:31:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 60, 70 ],
      "id_str" : "23083404",
      "id" : 23083404
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/296097858841620481\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/d0267Kob",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBvzbw-CMAARmFJ.jpg",
      "id_str" : "296097858850009088",
      "id" : 296097858850009088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBvzbw-CMAARmFJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/d0267Kob"
    } ],
    "hashtags" : [ {
      "text" : "Heat",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "296097858841620481",
  "text" : "Photo of the Day: President Obama accepts a basketball from @KingJames during a ceremony to honor the Miami #Heat: http:\/\/t.co\/d0267Kob",
  "id" : 296097858841620481,
  "created_at" : "2013-01-29 03:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miami HEAT",
      "screen_name" : "MiamiHEAT",
      "indices" : [ 49, 59 ],
      "id_str" : "11026952",
      "id" : 11026952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HEATatWhiteHouse",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/EfIh3snE",
      "expanded_url" : "http:\/\/at.wh.gov\/hcWuK",
      "display_url" : "at.wh.gov\/hcWuK"
    } ]
  },
  "geo" : { },
  "id_str" : "296033590997815297",
  "text" : "Video: President Obama welcomes the NBA champion @MiamiHEAT to the White House: http:\/\/t.co\/EfIh3snE #HEATatWhiteHouse",
  "id" : 296033590997815297,
  "created_at" : "2013-01-28 23:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miami HEAT",
      "screen_name" : "MiamiHEAT",
      "indices" : [ 3, 13 ],
      "id_str" : "11026952",
      "id" : 11026952
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 25, 36 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HEATatWhiteHouse",
      "indices" : [ 56, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "295961547044429826",
  "text" : "RT @MiamiHEAT And we are @whitehouse bound! Stay tuned! #HEATatWhiteHouse \/\/ Watch live at 1:40 ET: http:\/\/t.co\/u95tzH8r",
  "id" : 295961547044429826,
  "created_at" : "2013-01-28 18:28:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 43, 53 ],
      "id_str" : "23083404",
      "id" : 23083404
    }, {
      "name" : "DWade",
      "screen_name" : "DwyaneWade",
      "indices" : [ 55, 66 ],
      "id_str" : "33995409",
      "id" : 33995409
    }, {
      "name" : "Miami HEAT",
      "screen_name" : "MiamiHEAT",
      "indices" : [ 90, 100 ],
      "id_str" : "11026952",
      "id" : 11026952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "295931064185143296",
  "text" : "Today at 1:40 ET: President Obama welcomes @KingJames, @DwyaneWade &amp; the NBA Champion @MiamiHEAT to the WH. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 295931064185143296,
  "created_at" : "2013-01-28 16:27:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 107, 112 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/SgXmjcU6",
      "expanded_url" : "http:\/\/at.wh.gov\/hao5A",
      "display_url" : "at.wh.gov\/hao5A"
    } ]
  },
  "geo" : { },
  "id_str" : "295571334396801025",
  "text" : "Watch: President Obama on his nomination of Mary Jo White to lead the SEC &amp; Richard Cordray to cont as @CFPB Director http:\/\/t.co\/SgXmjcU6",
  "id" : 295571334396801025,
  "created_at" : "2013-01-27 16:37:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/7AEqnrRX",
      "expanded_url" : "http:\/\/at.wh.gov\/h9ENB",
      "display_url" : "at.wh.gov\/h9ENB"
    } ]
  },
  "geo" : { },
  "id_str" : "295237723462189056",
  "text" : "President Obama: \"My top priority is simple: to do everything in my power to fight for middle-class families\" Watch: http:\/\/t.co\/7AEqnrRX",
  "id" : 295237723462189056,
  "created_at" : "2013-01-26 18:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/AU7gUbYl",
      "expanded_url" : "http:\/\/at.wh.gov\/h8WgR",
      "display_url" : "at.wh.gov\/h8WgR"
    } ]
  },
  "geo" : { },
  "id_str" : "295009425197002752",
  "text" : "From the terrace of the Capitol to backstage at the balls here's a behind-the-scenes look at Inauguration 2013: http:\/\/t.co\/AU7gUbYl",
  "id" : 295009425197002752,
  "created_at" : "2013-01-26 03:25:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "MountRainierNPS",
      "screen_name" : "MountRainierNPS",
      "indices" : [ 82, 98 ],
      "id_str" : "316742293",
      "id" : 316742293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "milkyway",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/YdRMmuL5",
      "expanded_url" : "http:\/\/instagr.am\/p\/U7KGbSAu2Y",
      "display_url" : "instagr.am\/p\/U7KGbSAu2Y"
    } ]
  },
  "geo" : { },
  "id_str" : "294988048498847744",
  "text" : "RT @Interior: One of the most stunning photos we've ever seen. The #milkyway over @MountRainierNPS http:\/\/t.co\/YdRMmuL5",
  "id" : 294988048498847744,
  "created_at" : "2013-01-26 02:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/294975218135478272\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/nqQ6QThB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBf2ZecCMAAUEIA.jpg",
      "id_str" : "294975218143866880",
      "id" : 294975218143866880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBf2ZecCMAAUEIA.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/nqQ6QThB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294975218135478272",
  "text" : "Photo of the Day: President Obama runs along the Colonnade with the kids of newly named Chief of Staff Denis McDonough: http:\/\/t.co\/nqQ6QThB",
  "id" : 294975218135478272,
  "created_at" : "2013-01-26 01:09:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 85, 96 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/294932833196208130\/photo\/1",
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/jU1IlfMm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBfP2WPCcAECATJ.jpg",
      "id_str" : "294932833204596737",
      "id" : 294932833204596737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBfP2WPCcAECATJ.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jU1IlfMm"
    } ],
    "hashtags" : [ {
      "text" : "snow",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294949073126060033",
  "text" : "RT @FLOTUS: Bo in #snow! Photo: The Obama family dog plays in the Rose Garden of the @WhiteHouse: http:\/\/t.co\/jU1IlfMm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 73, 84 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/294932833196208130\/photo\/1",
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/jU1IlfMm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBfP2WPCcAECATJ.jpg",
        "id_str" : "294932833204596737",
        "id" : 294932833204596737,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBfP2WPCcAECATJ.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jU1IlfMm"
      } ],
      "hashtags" : [ {
        "text" : "snow",
        "indices" : [ 6, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294932833196208130",
    "text" : "Bo in #snow! Photo: The Obama family dog plays in the Rose Garden of the @WhiteHouse: http:\/\/t.co\/jU1IlfMm",
    "id" : 294932833196208130,
    "created_at" : "2013-01-25 22:20:42 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 294949073126060033,
  "created_at" : "2013-01-25 23:25:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hispanic Caucus",
      "screen_name" : "HispanicCaucus",
      "indices" : [ 61, 76 ],
      "id_str" : "33530012",
      "id" : 33530012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/aiYYtf3p",
      "expanded_url" : "http:\/\/flic.kr\/p\/dPv922",
      "display_url" : "flic.kr\/p\/dPv922"
    } ]
  },
  "geo" : { },
  "id_str" : "294921542993854464",
  "text" : "Today, President Obama met with members of the Congressional @HispanicCaucus in the Roosevelt Room: http:\/\/t.co\/aiYYtf3p",
  "id" : 294921542993854464,
  "created_at" : "2013-01-25 21:35:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "294855863145996288",
  "text" : "\"I\u2019m pleased to announce my next Chief of Staff...Denis McDonough.\" -President Obama: http:\/\/t.co\/u95tzH8r",
  "id" : 294855863145996288,
  "created_at" : "2013-01-25 17:14:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/XT0MCTMT",
      "expanded_url" : "http:\/\/at.wh.gov\/h8dl0",
      "display_url" : "at.wh.gov\/h8dl0"
    } ]
  },
  "geo" : { },
  "id_str" : "294854827861737473",
  "text" : "Happening now: President Obama makes a personnel announcement from the East Room of the White House. Watch live: http:\/\/t.co\/XT0MCTMT",
  "id" : 294854827861737473,
  "created_at" : "2013-01-25 17:10:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/T0mIOFI0",
      "expanded_url" : "http:\/\/at.wh.gov\/h7O0k",
      "display_url" : "at.wh.gov\/h7O0k"
    } ]
  },
  "geo" : { },
  "id_str" : "294812358583402496",
  "text" : "Today at 12:10 p.m. ET, President Obama will make a personnel announcement from the East Room. Watch: http:\/\/t.co\/T0mIOFI0",
  "id" : 294812358583402496,
  "created_at" : "2013-01-25 14:21:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 26, 29 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowisthetime",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/3WjBoyEU",
      "expanded_url" : "http:\/\/at.wh.gov\/h6QVW",
      "display_url" : "at.wh.gov\/h6QVW"
    } ]
  },
  "geo" : { },
  "id_str" : "294648315293884416",
  "text" : "\"Make your voices heard\" -@VP Biden on taking action to reduce gun violence during a Google+ Hangout: http:\/\/t.co\/3WjBoyEU #nowisthetime",
  "id" : 294648315293884416,
  "created_at" : "2013-01-25 03:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/294627171404746753\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/gSASXR4w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBa52fVCEAIb8H1.jpg",
      "id_str" : "294627171413135362",
      "id" : 294627171413135362,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBa52fVCEAIb8H1.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gSASXR4w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294627171404746753",
  "text" : "Photo of the Day: President Obama meets with Treasury Secretary Timothy Geithner in the Oval Office, Jan. 23, 2013: http:\/\/t.co\/gSASXR4w",
  "id" : 294627171404746753,
  "created_at" : "2013-01-25 02:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/294604198975270914\/photo\/1",
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/v6J6sPJF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBak9UYCcAAr2FE.jpg",
      "id_str" : "294604198987853824",
      "id" : 294604198987853824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBak9UYCcAAr2FE.jpg",
      "sizes" : [ {
        "h" : 485,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 561
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 561
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 561
      } ],
      "display_url" : "pic.twitter.com\/v6J6sPJF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294604820076175361",
  "text" : "RT @petesouza: Photo of Bo, the \"first dog\", in the Rose Garden today http:\/\/t.co\/v6J6sPJF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/294604198975270914\/photo\/1",
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/v6J6sPJF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBak9UYCcAAr2FE.jpg",
        "id_str" : "294604198987853824",
        "id" : 294604198987853824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBak9UYCcAAr2FE.jpg",
        "sizes" : [ {
          "h" : 485,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 561
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 561
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 561
        } ],
        "display_url" : "pic.twitter.com\/v6J6sPJF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294604198975270914",
    "text" : "Photo of Bo, the \"first dog\", in the Rose Garden today http:\/\/t.co\/v6J6sPJF",
    "id" : 294604198975270914,
    "created_at" : "2013-01-25 00:34:28 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 294604820076175361,
  "created_at" : "2013-01-25 00:37:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 15, 18 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/kLJblOt9",
      "expanded_url" : "http:\/\/wh.gov\/yAkY",
      "display_url" : "wh.gov\/yAkY"
    } ]
  },
  "geo" : { },
  "id_str" : "294585596750491650",
  "text" : "RT @VP: Today, @VP Biden participated in a Google+ Hangout about the Admin's plan to reduce gun violence: http:\/\/t.co\/kLJblOt9 http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 7, 10 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/294575545520357377\/photo\/1",
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/Nvrb1eQA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBaK5d7CAAAmu3b.jpg",
        "id_str" : "294575545528745984",
        "id" : 294575545528745984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBaK5d7CAAAmu3b.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/Nvrb1eQA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/kLJblOt9",
        "expanded_url" : "http:\/\/wh.gov\/yAkY",
        "display_url" : "wh.gov\/yAkY"
      } ]
    },
    "geo" : { },
    "id_str" : "294575545520357377",
    "text" : "Today, @VP Biden participated in a Google+ Hangout about the Admin's plan to reduce gun violence: http:\/\/t.co\/kLJblOt9 http:\/\/t.co\/Nvrb1eQA",
    "id" : 294575545520357377,
    "created_at" : "2013-01-24 22:40:58 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 294585596750491650,
  "created_at" : "2013-01-24 23:20:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 59, 62 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiresideHangout",
      "indices" : [ 37, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/T39ipbAV",
      "expanded_url" : "http:\/\/at.wh.gov\/h6C1n",
      "display_url" : "at.wh.gov\/h6C1n"
    } ]
  },
  "geo" : { },
  "id_str" : "294551808645406722",
  "text" : "In case you missed it: Watch today's #FiresideHangout with @VP Biden on reducing gun violence: http:\/\/t.co\/T39ipbAV",
  "id" : 294551808645406722,
  "created_at" : "2013-01-24 21:06:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/iglXyLSC",
      "expanded_url" : "http:\/\/wh.gov\/y779",
      "display_url" : "wh.gov\/y779"
    } ]
  },
  "geo" : { },
  "id_str" : "294535237235535872",
  "text" : "\"Every American can be proud that our military will grow even stronger\" \u2014Pres. Obama on opening combat units to women: http:\/\/t.co\/iglXyLSC",
  "id" : 294535237235535872,
  "created_at" : "2013-01-24 20:00:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 139, 144 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294530292465692672",
  "text" : "President Obama: \"Today, I\u2019m nominating Mary Jo White to lead the Securities &amp; Exchange Commission &amp; Richard Cordray to [lead] the @CFPB\"",
  "id" : 294530292465692672,
  "created_at" : "2013-01-24 19:41:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "294530100131659777",
  "text" : "Happening now: President Obama makes a personnel announcement. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 294530100131659777,
  "created_at" : "2013-01-24 19:40:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 14, 17 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowisthetime",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/bPhFZAmE",
      "expanded_url" : "http:\/\/wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "294515657196851201",
  "text" : "Starting now: @VP Biden participates in a Google+ Hangout on reducing gun violence. Watch it live: http:\/\/t.co\/bPhFZAmE #nowisthetime",
  "id" : 294515657196851201,
  "created_at" : "2013-01-24 18:42:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/294452278759391232\/photo\/1",
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/yOokLfpR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBYayZcCAAEWO-I.jpg",
      "id_str" : "294452278763585537",
      "id" : 294452278763585537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBYayZcCAAEWO-I.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yOokLfpR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294491715551756289",
  "text" : "RT @petesouza: Snow! The view from outside the Oval Office. http:\/\/t.co\/yOokLfpR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/294452278759391232\/photo\/1",
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/yOokLfpR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBYayZcCAAEWO-I.jpg",
        "id_str" : "294452278763585537",
        "id" : 294452278763585537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBYayZcCAAEWO-I.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/yOokLfpR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294452278759391232",
    "text" : "Snow! The view from outside the Oval Office. http:\/\/t.co\/yOokLfpR",
    "id" : 294452278759391232,
    "created_at" : "2013-01-24 14:31:08 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 294491715551756289,
  "created_at" : "2013-01-24 17:07:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "294476057564819457",
  "text" : "Happening at 2:30ET: President Obama makes a personnel announcement from the White House. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 294476057564819457,
  "created_at" : "2013-01-24 16:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 11, 14 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/3PgeUGpe",
      "expanded_url" : "http:\/\/www.wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "294465006148403201",
  "text" : "At 1:45ET: @VP Biden discusses the Admin's plan to reduce gun violence in a Google+ Hangout. Watch live: http:\/\/t.co\/3PgeUGpe #NowIsTheTime",
  "id" : 294465006148403201,
  "created_at" : "2013-01-24 15:21:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 40, 47 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 86, 97 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/294289934460801024\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/YmGHMlgp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBWHIt1CUAAJdxp.jpg",
      "id_str" : "294289934473383936",
      "id" : 294289934473383936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBWHIt1CUAAJdxp.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YmGHMlgp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/O5MBdjbl",
      "expanded_url" : "http:\/\/on.wh.gov\/f792qvg",
      "display_url" : "on.wh.gov\/f792qvg"
    } ]
  },
  "geo" : { },
  "id_str" : "294289934460801024",
  "text" : "Photo of the Day: President Obama &amp; @FLOTUS Michelle Obama surprise visitors on a @WhiteHouse tour http:\/\/t.co\/O5MBdjbl http:\/\/t.co\/YmGHMlgp",
  "id" : 294289934460801024,
  "created_at" : "2013-01-24 03:46:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 52, 56 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "Miami HEAT",
      "screen_name" : "MiamiHEAT",
      "indices" : [ 66, 76 ],
      "id_str" : "11026952",
      "id" : 11026952
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 98, 109 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294263274705391616",
  "text" : "On Monday at 1:35ET: President Obama will honor the @NBA Champion @MiamiHeat in a ceremony at the @Whitehouse.",
  "id" : 294263274705391616,
  "created_at" : "2013-01-24 02:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/294256480801136642\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/5Q5O3IR1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBVotdPCIAAjB43.jpg",
      "id_str" : "294256480813719552",
      "id" : 294256480813719552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBVotdPCIAAjB43.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5Q5O3IR1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/M2AgvFWN",
      "expanded_url" : "http:\/\/on.wh.gov\/e9VehWA",
      "display_url" : "on.wh.gov\/e9VehWA"
    } ]
  },
  "geo" : { },
  "id_str" : "294256480801136642",
  "text" : "Photo Gallery: Behind the scenes at the Inauguration: http:\/\/t.co\/M2AgvFWN Incl the President waiting to take the stage http:\/\/t.co\/5Q5O3IR1",
  "id" : 294256480801136642,
  "created_at" : "2013-01-24 01:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 24, 27 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/294241632855937024\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/8K0ZECbF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBVbNMTCUAAfR-9.jpg",
      "id_str" : "294241632860131328",
      "id" : 294241632860131328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBVbNMTCUAAfR-9.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/8K0ZECbF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/zf2r5SSu",
      "expanded_url" : "http:\/\/on.wh.gov\/hF0f2rW",
      "display_url" : "on.wh.gov\/hF0f2rW"
    } ]
  },
  "geo" : { },
  "id_str" : "294241632855937024",
  "text" : "On 1\/24 @ 1:45ET: Watch @VP in his 1st Google+ hangout, a \"Fireside Chat\" on reducing gun violence http:\/\/t.co\/zf2r5SSu http:\/\/t.co\/8K0ZECbF",
  "id" : 294241632855937024,
  "created_at" : "2013-01-24 00:34:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Kelly",
      "screen_name" : "WichitaCindy",
      "indices" : [ 3, 16 ],
      "id_str" : "14076555",
      "id" : 14076555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/tSA0Py4k",
      "expanded_url" : "http:\/\/1.usa.gov\/WM7uD7",
      "display_url" : "1.usa.gov\/WM7uD7"
    } ]
  },
  "geo" : { },
  "id_str" : "294224849738543105",
  "text" : "RT @WichitaCindy: White House response to Death Star http:\/\/t.co\/tSA0Py4k It's a trap! Educating Americans about space program! http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "former Macon44",
        "screen_name" : "macon44",
        "indices" : [ 132, 140 ],
        "id_str" : "776593497122082820",
        "id" : 776593497122082820
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/tSA0Py4k",
        "expanded_url" : "http:\/\/1.usa.gov\/WM7uD7",
        "display_url" : "1.usa.gov\/WM7uD7"
      }, {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/B8JioA4O",
        "expanded_url" : "http:\/\/bit.ly\/YnV6P7",
        "display_url" : "bit.ly\/YnV6P7"
      } ]
    },
    "geo" : { },
    "id_str" : "294220741728141312",
    "text" : "White House response to Death Star http:\/\/t.co\/tSA0Py4k It's a trap! Educating Americans about space program! http:\/\/t.co\/B8JioA4O \/@macon44",
    "id" : 294220741728141312,
    "created_at" : "2013-01-23 23:11:05 +0000",
    "user" : {
      "name" : "Cindy Kelly",
      "screen_name" : "WichitaCindy",
      "protected" : false,
      "id_str" : "14076555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610791667449360384\/JI_rrW1x_normal.jpg",
      "id" : 14076555,
      "verified" : false
    }
  },
  "id" : 294224849738543105,
  "created_at" : "2013-01-23 23:27:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 3, 10 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 17, 20 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/juNFuqWV",
      "expanded_url" : "http:\/\/goo.gl\/1Fg44",
      "display_url" : "goo.gl\/1Fg44"
    } ]
  },
  "geo" : { },
  "id_str" : "294178598666006530",
  "text" : "RT @google: Join @VP Biden in a discussion on gun violence - tomorrow Thurs 1\/24 at 1:45pm ET http:\/\/t.co\/juNFuqWV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 5, 8 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/juNFuqWV",
        "expanded_url" : "http:\/\/goo.gl\/1Fg44",
        "display_url" : "goo.gl\/1Fg44"
      } ]
    },
    "geo" : { },
    "id_str" : "294132410700951552",
    "text" : "Join @VP Biden in a discussion on gun violence - tomorrow Thurs 1\/24 at 1:45pm ET http:\/\/t.co\/juNFuqWV",
    "id" : 294132410700951552,
    "created_at" : "2013-01-23 17:20:06 +0000",
    "user" : {
      "name" : "Google",
      "screen_name" : "google",
      "protected" : false,
      "id_str" : "20536157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762369348300251136\/5Obhonwa_normal.jpg",
      "id" : 20536157,
      "verified" : true
    }
  },
  "id" : 294178598666006530,
  "created_at" : "2013-01-23 20:23:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 28, 31 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294133385734021120",
  "text" : "RT @VP: Tomorrow at 1:45ET, @VP Biden will participate in a \"Fireside Chat\" hangout on Google+ to discuss reducing gun violence http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 20, 23 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/mzKZJV2X",
        "expanded_url" : "http:\/\/googleblog.blogspot.com\/2013\/01\/fireside-hangouts-join-vice-president.html",
        "display_url" : "googleblog.blogspot.com\/2013\/01\/firesi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "294132903170945024",
    "text" : "Tomorrow at 1:45ET, @VP Biden will participate in a \"Fireside Chat\" hangout on Google+ to discuss reducing gun violence http:\/\/t.co\/mzKZJV2X",
    "id" : 294132903170945024,
    "created_at" : "2013-01-23 17:22:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 294133385734021120,
  "created_at" : "2013-01-23 17:23:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 22, 29 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/293868681656672256\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/5m7As3Sy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBQIAk1CIAILURS.jpg",
      "id_str" : "293868681665060866",
      "id" : 293868681665060866,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBQIAk1CIAILURS.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5m7As3Sy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293868681656672256",
  "text" : "President Obama &amp; @FLOTUS Michelle Obama dance together at the inaugural ball last night in Washington, DC: http:\/\/t.co\/5m7As3Sy",
  "id" : 293868681656672256,
  "created_at" : "2013-01-22 23:52:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/FagbBeSk",
      "expanded_url" : "http:\/\/at.wh.gov\/h2y80",
      "display_url" : "at.wh.gov\/h2y80"
    } ]
  },
  "geo" : { },
  "id_str" : "293854689655676928",
  "text" : "\"We recommit ourselves to supporting women &amp; families in the choices they make\" \u2014President Obama on Roe v. Wade Anniv: http:\/\/t.co\/FagbBeSk",
  "id" : 293854689655676928,
  "created_at" : "2013-01-22 22:56:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RoeAt40",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293835958766415872",
  "text" : "RT @vj44: On #RoeAt40, we reaffirm our commitment to its principles of protecting the health &amp; reproductive freedom of women: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RoeAt40",
        "indices" : [ 3, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/mqBKq42i",
        "expanded_url" : "http:\/\/wh.gov\/yXO2",
        "display_url" : "wh.gov\/yXO2"
      } ]
    },
    "geo" : { },
    "id_str" : "293814634975199233",
    "text" : "On #RoeAt40, we reaffirm our commitment to its principles of protecting the health &amp; reproductive freedom of women: http:\/\/t.co\/mqBKq42i",
    "id" : 293814634975199233,
    "created_at" : "2013-01-22 20:17:22 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 293835958766415872,
  "created_at" : "2013-01-22 21:42:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 69, 80 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293796086865330176",
  "text" : "RT @FLOTUS: Shhhh! Barack, Bo &amp; I are about to surprise folks on @WhiteHouse tours! I love doing this. Watch here: http:\/\/t.co\/7XaBs ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 57, 68 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/7XaBsO6y",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "293794491473739776",
    "text" : "Shhhh! Barack, Bo &amp; I are about to surprise folks on @WhiteHouse tours! I love doing this. Watch here: http:\/\/t.co\/7XaBsO6y \u2013mo",
    "id" : 293794491473739776,
    "created_at" : "2013-01-22 18:57:19 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 293796086865330176,
  "created_at" : "2013-01-22 19:03:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293743453232304129\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/p0HoojP1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBOWHUmCEAATmoM.jpg",
      "id_str" : "293743453240692736",
      "id" : 293743453240692736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBOWHUmCEAATmoM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/p0HoojP1"
    } ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293743453232304129",
  "text" : "\"I want to take a look one more time\"-President Obama looks back at the crowd following the #inaug2013 ceremony: http:\/\/t.co\/p0HoojP1",
  "id" : 293743453232304129,
  "created_at" : "2013-01-22 15:34:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/CXBNftb9",
      "expanded_url" : "http:\/\/on.wh.gov\/izXc9sr",
      "display_url" : "on.wh.gov\/izXc9sr"
    } ]
  },
  "geo" : { },
  "id_str" : "293579770602598400",
  "text" : "\"You and I, as citizens, have the power to set this country's course\" -President Obama in his inaugural address. Watch: http:\/\/t.co\/CXBNftb9",
  "id" : 293579770602598400,
  "created_at" : "2013-01-22 04:44:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293568703310725121\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Ph4J3cqB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBL3LiaCAAE9tBv.jpg",
      "id_str" : "293568703319113729",
      "id" : 293568703319113729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBL3LiaCAAE9tBv.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Ph4J3cqB"
    } ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293568703310725121",
  "text" : "\"Our journey is not complete until no citizen is forced to wait for hours to exercise the right to vote\" #Inaug2013 http:\/\/t.co\/Ph4J3cqB",
  "id" : 293568703310725121,
  "created_at" : "2013-01-22 04:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 41, 48 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293559408590479360",
  "text" : "RT @FLOTUS: Photo: President Obama &amp; @FLOTUS Michelle Obama wave to the crowd as they walk down Pennsylvania Ave in DC: #inaug2013 h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 29, 36 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/293559196031520769\/photo\/1",
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/WjM6bsRl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBLuiJCCEAAeq5N.jpg",
        "id_str" : "293559196039909376",
        "id" : 293559196039909376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBLuiJCCEAAeq5N.jpg",
        "sizes" : [ {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/WjM6bsRl"
      } ],
      "hashtags" : [ {
        "text" : "inaug2013",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293559196031520769",
    "text" : "Photo: President Obama &amp; @FLOTUS Michelle Obama wave to the crowd as they walk down Pennsylvania Ave in DC: #inaug2013 http:\/\/t.co\/WjM6bsRl",
    "id" : 293559196031520769,
    "created_at" : "2013-01-22 03:22:21 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 293559408590479360,
  "created_at" : "2013-01-22 03:23:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293541122389729280",
  "text" : "RT @FLOTUS: Just danced to \"Let's Stay Together\" with the love of my life and the President of the United States. I\u2019m so proud of Barack ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293540056235397120",
    "text" : "Just danced to \"Let's Stay Together\" with the love of my life and the President of the United States. I\u2019m so proud of Barack. \u2013mo",
    "id" : 293540056235397120,
    "created_at" : "2013-01-22 02:06:17 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 293541122389729280,
  "created_at" : "2013-01-22 02:10:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/KYpVXAJt",
      "expanded_url" : "http:\/\/on.wh.gov\/KTIjaHb",
      "display_url" : "on.wh.gov\/KTIjaHb"
    } ]
  },
  "geo" : { },
  "id_str" : "293539249280651264",
  "text" : "\"It is now our generation's task to carry on what those pioneers began.\" -President Obama in his inaugural address: http:\/\/t.co\/KYpVXAJt",
  "id" : 293539249280651264,
  "created_at" : "2013-01-22 02:03:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293537937260417024",
  "text" : "\"I have no greater honor than being your Commander-in-Chief\" \u2014President Obama to service members at the Commander-in-Chief's Ball #Inaug2013",
  "id" : 293537937260417024,
  "created_at" : "2013-01-22 01:57:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/u7QZm2nD",
      "expanded_url" : "http:\/\/on.wh.gov\/b7eLDJy",
      "display_url" : "on.wh.gov\/b7eLDJy"
    } ]
  },
  "geo" : { },
  "id_str" : "293525907761676290",
  "text" : "Watch: James Taylor Performs 'America the Beautiful' at #Inaug2013: http:\/\/t.co\/u7QZm2nD",
  "id" : 293525907761676290,
  "created_at" : "2013-01-22 01:10:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/i2WmrDcx",
      "expanded_url" : "http:\/\/on.wh.gov\/DyjBipd",
      "display_url" : "on.wh.gov\/DyjBipd"
    } ]
  },
  "geo" : { },
  "id_str" : "293517353562562560",
  "text" : "President Obama: \"We must act, knowing that our work will be imperfect.\" Watch the second inaugural address: http:\/\/t.co\/i2WmrDcx #inaug2013",
  "id" : 293517353562562560,
  "created_at" : "2013-01-22 00:36:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293493231423983617\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/rhAC6M4z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBKyifuCEAE_lGh.jpg",
      "id_str" : "293493231432372225",
      "id" : 293493231432372225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBKyifuCEAE_lGh.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/rhAC6M4z"
    } ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/MTFUBC2c",
      "expanded_url" : "http:\/\/on.wh.gov\/C5zh9UU",
      "display_url" : "on.wh.gov\/C5zh9UU"
    } ]
  },
  "geo" : { },
  "id_str" : "293493231423983617",
  "text" : "\"Our journey is not complete until all our children...know that they are cared for\" http:\/\/t.co\/MTFUBC2c #Inaug2013 http:\/\/t.co\/rhAC6M4z",
  "id" : 293493231423983617,
  "created_at" : "2013-01-21 23:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "soudary",
      "screen_name" : "soudary",
      "indices" : [ 3, 11 ],
      "id_str" : "17760185",
      "id" : 17760185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InaugQuote",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Osl6JmaU",
      "expanded_url" : "http:\/\/at.wh.gov\/gZYVx",
      "display_url" : "at.wh.gov\/gZYVx"
    } ]
  },
  "geo" : { },
  "id_str" : "293466530786705409",
  "text" : "RT @soudary: President Obama: \"preserving our individual freedoms ultimately requires collective action\" #InaugQuote http:\/\/t.co\/Osl6JmaU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 92, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/Osl6JmaU",
        "expanded_url" : "http:\/\/at.wh.gov\/gZYVx",
        "display_url" : "at.wh.gov\/gZYVx"
      } ]
    },
    "geo" : { },
    "id_str" : "293458079515828225",
    "text" : "President Obama: \"preserving our individual freedoms ultimately requires collective action\" #InaugQuote http:\/\/t.co\/Osl6JmaU",
    "id" : 293458079515828225,
    "created_at" : "2013-01-21 20:40:33 +0000",
    "user" : {
      "name" : "soudary",
      "screen_name" : "soudary",
      "protected" : false,
      "id_str" : "17760185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780614230777077760\/Y77814kS_normal.jpg",
      "id" : 17760185,
      "verified" : false
    }
  },
  "id" : 293466530786705409,
  "created_at" : "2013-01-21 21:14:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/ncjGusur",
      "expanded_url" : "http:\/\/wh.gov\/inauguration",
      "display_url" : "wh.gov\/inauguration"
    } ]
  },
  "geo" : { },
  "id_str" : "293465957135962113",
  "text" : "Happening now: President Obama returns to the White House for the Inaugural Parade. Watch live: http:\/\/t.co\/ncjGusur #inaug2013",
  "id" : 293465957135962113,
  "created_at" : "2013-01-21 21:11:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 67, 78 ],
      "id_str" : "5943942",
      "id" : 5943942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/YslT0BA1",
      "expanded_url" : "http:\/\/at.wh.gov\/h07E2",
      "display_url" : "at.wh.gov\/h07E2"
    } ]
  },
  "geo" : { },
  "id_str" : "293446916807729152",
  "text" : "RT @ks44: Full audio of President Obama's inaugural address now on @SoundCloud: http:\/\/t.co\/YslT0BA1 #inaug2013 Share favorite quotes w  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SoundCloud",
        "screen_name" : "SoundCloud",
        "indices" : [ 57, 68 ],
        "id_str" : "5943942",
        "id" : 5943942
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inaug2013",
        "indices" : [ 91, 101 ]
      }, {
        "text" : "InaugQuote",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/YslT0BA1",
        "expanded_url" : "http:\/\/at.wh.gov\/h07E2",
        "display_url" : "at.wh.gov\/h07E2"
      } ]
    },
    "geo" : { },
    "id_str" : "293441846489792512",
    "text" : "Full audio of President Obama's inaugural address now on @SoundCloud: http:\/\/t.co\/YslT0BA1 #inaug2013 Share favorite quotes w #InaugQuote",
    "id" : 293441846489792512,
    "created_at" : "2013-01-21 19:36:02 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 293446916807729152,
  "created_at" : "2013-01-21 19:56:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Mann",
      "screen_name" : "James_hnm",
      "indices" : [ 3, 13 ],
      "id_str" : "45332292",
      "id" : 45332292
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293445280588787712",
  "text" : "RT @James_hnm: @whitehouse \"For history tells us that while these truths may be self-evident, they have never been self-executing\" #Inau ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293442590735486977",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \"For history tells us that while these truths may be self-evident, they have never been self-executing\" #InaugQuote",
    "id" : 293442590735486977,
    "created_at" : "2013-01-21 19:39:00 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "James Mann",
      "screen_name" : "James_hnm",
      "protected" : false,
      "id_str" : "45332292",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3472727036\/429024058ba56c5b1756fb65a0142338_normal.jpeg",
      "id" : 45332292,
      "verified" : false
    }
  },
  "id" : 293445280588787712,
  "created_at" : "2013-01-21 19:49:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/293444791092527104\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/nJiQVk7Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBKGe5cCQAAOTFm.jpg",
      "id_str" : "293444791105110016",
      "id" : 293444791105110016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBKGe5cCQAAOTFm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 944,
        "resize" : "fit",
        "w" : 1416
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nJiQVk7Y"
    } ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293444791092527104",
  "text" : "President Obama takes the oath of office during the Inaugural swearing-in ceremony at the U.S. Capitol #inaug2013 http:\/\/t.co\/nJiQVk7Y",
  "id" : 293444791092527104,
  "created_at" : "2013-01-21 19:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/wReZIfHz",
      "expanded_url" : "http:\/\/at.wh.gov\/h06KQ",
      "display_url" : "at.wh.gov\/h06KQ"
    } ]
  },
  "geo" : { },
  "id_str" : "293440272258457601",
  "text" : "Full video: President Obama takes the oath of office and delivers his second inaugural address: http:\/\/t.co\/wReZIfHz #inaug2013",
  "id" : 293440272258457601,
  "created_at" : "2013-01-21 19:29:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/293439231202840576\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/DVvPcdYr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBKBbRPCUAE2ca4.jpg",
      "id_str" : "293439231215423489",
      "id" : 293439231215423489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBKBbRPCUAE2ca4.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/DVvPcdYr"
    } ],
    "hashtags" : [ {
      "text" : "InaugQuote",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293439231202840576",
  "text" : "\"Our interests &amp; our conscience compel us to act on behalf of those who long for freedom.\" \u2014President Obama #InaugQuote http:\/\/t.co\/DVvPcdYr",
  "id" : 293439231202840576,
  "created_at" : "2013-01-21 19:25:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taryn B. Cornell",
      "screen_name" : "TarynCornell",
      "indices" : [ 3, 16 ],
      "id_str" : "1053473312",
      "id" : 1053473312
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293437796838948864",
  "text" : "RT @TarynCornell: @whitehouse \"let us answer the call of history, and carry into an uncertain future that precious light of freedom.\" #I ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293436673423978499",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \"let us answer the call of history, and carry into an uncertain future that precious light of freedom.\" #InaugQuote",
    "id" : 293436673423978499,
    "created_at" : "2013-01-21 19:15:29 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Taryn B. Cornell",
      "screen_name" : "TarynCornell",
      "protected" : false,
      "id_str" : "1053473312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775306229849661440\/icBCQJAk_normal.jpg",
      "id" : 1053473312,
      "verified" : false
    }
  },
  "id" : 293437796838948864,
  "created_at" : "2013-01-21 19:19:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cary Tallent",
      "screen_name" : "tallentc82",
      "indices" : [ 3, 14 ],
      "id_str" : "35659425",
      "id" : 35659425
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293435274250289153",
  "text" : "RT @tallentc82: @whitehouse Our journey is not complete until our gay brothers and sisters are treated like anyone else under the law \u2013  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 120, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293434855881076736",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Our journey is not complete until our gay brothers and sisters are treated like anyone else under the law \u2013 #InaugQuote",
    "id" : 293434855881076736,
    "created_at" : "2013-01-21 19:08:16 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Cary Tallent",
      "screen_name" : "tallentc82",
      "protected" : false,
      "id_str" : "35659425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000313515071\/7fafc3a2b76c0c08fbb475a7de4e6ef9_normal.jpeg",
      "id" : 35659425,
      "verified" : false
    }
  },
  "id" : 293435274250289153,
  "created_at" : "2013-01-21 19:09:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293432547466158080\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/09HjfLFC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJ7WOXCIAAzlBr.jpg",
      "id_str" : "293432547474546688",
      "id" : 293432547474546688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJ7WOXCIAAzlBr.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/09HjfLFC"
    } ],
    "hashtags" : [ {
      "text" : "InaugQuote",
      "indices" : [ 97, 108 ]
    }, {
      "text" : "Inaug2013",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293432547466158080",
  "text" : "\"That is our generation\u2019s task \u2013 to make these words...real for every American\" -President Obama #InaugQuote #Inaug2013 http:\/\/t.co\/09HjfLFC",
  "id" : 293432547466158080,
  "created_at" : "2013-01-21 18:59:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Key Halverson",
      "screen_name" : "keyhalverson",
      "indices" : [ 3, 16 ],
      "id_str" : "230746281",
      "id" : 230746281
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293430208520916993",
  "text" : "RT @keyhalverson: @whitehouse \"The patriots of 1776 did not fight to replace the tyranny of a king with privileges of a few or rule of a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293429077732388864",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \"The patriots of 1776 did not fight to replace the tyranny of a king with privileges of a few or rule of a mob.\" #InaugQuote",
    "id" : 293429077732388864,
    "created_at" : "2013-01-21 18:45:18 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Key Halverson",
      "screen_name" : "keyhalverson",
      "protected" : false,
      "id_str" : "230746281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2525384371\/uapy9zwzwnxk6ckoxg4g_normal.jpeg",
      "id" : 230746281,
      "verified" : false
    }
  },
  "id" : 293430208520916993,
  "created_at" : "2013-01-21 18:49:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen Parks",
      "screen_name" : "Kristen_K_Parks",
      "indices" : [ 3, 19 ],
      "id_str" : "807838796",
      "id" : 807838796
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaugQuote",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293429165422690304",
  "text" : "RT @Kristen_K_Parks: @whitehouse \"we cannot mistake absolutism for principle, or substitute spectacle for politics\" #inaugQuote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inaugQuote",
        "indices" : [ 95, 106 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "293422999896477696",
    "geo" : { },
    "id_str" : "293428385022095362",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \"we cannot mistake absolutism for principle, or substitute spectacle for politics\" #inaugQuote",
    "id" : 293428385022095362,
    "in_reply_to_status_id" : 293422999896477696,
    "created_at" : "2013-01-21 18:42:33 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Kristen Parks",
      "screen_name" : "Kristen_K_Parks",
      "protected" : false,
      "id_str" : "807838796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796438785810526209\/B48NgWd6_normal.jpg",
      "id" : 807838796,
      "verified" : false
    }
  },
  "id" : 293429165422690304,
  "created_at" : "2013-01-21 18:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Phares",
      "screen_name" : "PLarryR",
      "indices" : [ 3, 11 ],
      "id_str" : "257105719",
      "id" : 257105719
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293428977232658432",
  "text" : "RT @PLarryR: @whitehouse \"We, the people, still believe that our obligations as Americans are not just to ourselves, but to all posterit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inaugquote",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293428242008915968",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \"We, the people, still believe that our obligations as Americans are not just to ourselves, but to all posterity.\" #inaugquote",
    "id" : 293428242008915968,
    "created_at" : "2013-01-21 18:41:59 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Larry Phares",
      "screen_name" : "PLarryR",
      "protected" : false,
      "id_str" : "257105719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759498667585835008\/iSTC62dU_normal.jpg",
      "id" : 257105719,
      "verified" : false
    }
  },
  "id" : 293428977232658432,
  "created_at" : "2013-01-21 18:44:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Marshall",
      "screen_name" : "a_r_marshall",
      "indices" : [ 3, 16 ],
      "id_str" : "613968190",
      "id" : 613968190
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/a_r_marshall\/status\/293427358449401856\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/sgO57KVM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJ2oLwCAAE3baC.jpg",
      "id_str" : "293427358453596161",
      "id" : 293427358453596161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJ2oLwCAAE3baC.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/sgO57KVM"
    } ],
    "hashtags" : [ {
      "text" : "InaugQuote",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293427586858627073",
  "text" : "RT @a_r_marshall: Did the White House just retweet me? The White House did just retweet me. #InaugQuote http:\/\/t.co\/sgO57KVM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/a_r_marshall\/status\/293427358449401856\/photo\/1",
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/sgO57KVM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJ2oLwCAAE3baC.jpg",
        "id_str" : "293427358453596161",
        "id" : 293427358453596161,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJ2oLwCAAE3baC.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/sgO57KVM"
      } ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 74, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293427358449401856",
    "text" : "Did the White House just retweet me? The White House did just retweet me. #InaugQuote http:\/\/t.co\/sgO57KVM",
    "id" : 293427358449401856,
    "created_at" : "2013-01-21 18:38:28 +0000",
    "user" : {
      "name" : "Alex Marshall",
      "screen_name" : "a_r_marshall",
      "protected" : false,
      "id_str" : "613968190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435639882984083456\/l-bnJDeB_normal.jpeg",
      "id" : 613968190,
      "verified" : false
    }
  },
  "id" : 293427586858627073,
  "created_at" : "2013-01-21 18:39:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Kamoie",
      "screen_name" : "BrianKamoie",
      "indices" : [ 3, 15 ],
      "id_str" : "866589074",
      "id" : 866589074
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293427360290709505",
  "text" : "RT @BrianKamoie: @whitehouse: \"The most evident of truths \u2013 that all of us are created equal \u2013 is still the star that guides us still.\"  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 119, 130 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "293404369678901248",
    "geo" : { },
    "id_str" : "293426937106419713",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse: \"The most evident of truths \u2013 that all of us are created equal \u2013 is still the star that guides us still.\" #InaugQuote",
    "id" : 293426937106419713,
    "in_reply_to_status_id" : 293404369678901248,
    "created_at" : "2013-01-21 18:36:48 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Brian Kamoie",
      "screen_name" : "BrianKamoie",
      "protected" : false,
      "id_str" : "866589074",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722454595780227073\/7Ze_3Xhp_normal.jpg",
      "id" : 866589074,
      "verified" : false
    }
  },
  "id" : 293427360290709505,
  "created_at" : "2013-01-21 18:38:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Marshall",
      "screen_name" : "a_r_marshall",
      "indices" : [ 3, 16 ],
      "id_str" : "613968190",
      "id" : 613968190
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InaugQuote",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293427034917572609",
  "text" : "RT @a_r_marshall: @whitehouse \"You and I, as citizens, have the power to set this country\u2019s course.\" #InaugQuote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 83, 94 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "293422999896477696",
    "geo" : { },
    "id_str" : "293426532326727680",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \"You and I, as citizens, have the power to set this country\u2019s course.\" #InaugQuote",
    "id" : 293426532326727680,
    "in_reply_to_status_id" : 293422999896477696,
    "created_at" : "2013-01-21 18:35:11 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Alex Marshall",
      "screen_name" : "a_r_marshall",
      "protected" : false,
      "id_str" : "613968190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435639882984083456\/l-bnJDeB_normal.jpeg",
      "id" : 613968190,
      "verified" : false
    }
  },
  "id" : 293427034917572609,
  "created_at" : "2013-01-21 18:37:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seranya",
      "screen_name" : "seranyamoodley",
      "indices" : [ 3, 18 ],
      "id_str" : "160181214",
      "id" : 160181214
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293425872814342144",
  "text" : "RT @seranyamoodley: @whitehouse \u201CWe do not believe that in this country, freedom is reserved for the lucky, or happiness for the few.\u201D # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inaugQuote",
        "indices" : [ 115, 126 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "293422999896477696",
    "geo" : { },
    "id_str" : "293424952395317248",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \u201CWe do not believe that in this country, freedom is reserved for the lucky, or happiness for the few.\u201D #inaugQuote",
    "id" : 293424952395317248,
    "in_reply_to_status_id" : 293422999896477696,
    "created_at" : "2013-01-21 18:28:54 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Seranya",
      "screen_name" : "seranyamoodley",
      "protected" : false,
      "id_str" : "160181214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/480388775206723584\/aOuZhrAf_normal.jpeg",
      "id" : 160181214,
      "verified" : false
    }
  },
  "id" : 293425872814342144,
  "created_at" : "2013-01-21 18:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Sosdian",
      "screen_name" : "asosdian",
      "indices" : [ 3, 12 ],
      "id_str" : "36249953",
      "id" : 36249953
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaugquote",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293425500204961792",
  "text" : "RT @asosdian: #inaugquote \"Our journey is not complete until our wives, our mothers, and daughters can earn a living equal to their efforts\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inaugquote",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293425140618915841",
    "text" : "#inaugquote \"Our journey is not complete until our wives, our mothers, and daughters can earn a living equal to their efforts\"",
    "id" : 293425140618915841,
    "created_at" : "2013-01-21 18:29:39 +0000",
    "user" : {
      "name" : "Anna Sosdian",
      "screen_name" : "asosdian",
      "protected" : false,
      "id_str" : "36249953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3115280540\/b79bf8cf39b4d769035cf1b0289396a4_normal.jpeg",
      "id" : 36249953,
      "verified" : false
    }
  },
  "id" : 293425500204961792,
  "created_at" : "2013-01-21 18:31:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Ne",
      "screen_name" : "ShaneNe808",
      "indices" : [ 3, 14 ],
      "id_str" : "56919204",
      "id" : 56919204
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InaugQuote",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293424521506078720",
  "text" : "RT @ShaneNe808: @whitehouse \"We have always understood that when times change, so must we\". #InaugQuote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 76, 87 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "293422999896477696",
    "geo" : { },
    "id_str" : "293424085701107712",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \"We have always understood that when times change, so must we\". #InaugQuote",
    "id" : 293424085701107712,
    "in_reply_to_status_id" : 293422999896477696,
    "created_at" : "2013-01-21 18:25:28 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Shane Ne",
      "screen_name" : "ShaneNe808",
      "protected" : false,
      "id_str" : "56919204",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765447015895486464\/EWd-Uj96_normal.jpg",
      "id" : 56919204,
      "verified" : false
    }
  },
  "id" : 293424521506078720,
  "created_at" : "2013-01-21 18:27:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InaugQuote",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293424343625654272",
  "text" : "RT @dr_ffunkenstein: @whitehouse \"Our individual freedom is in inextricably bound to the freedom of every soul on Earth\" #InaugQuote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 100, 111 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "293422999896477696",
    "geo" : { },
    "id_str" : "293423582623711232",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \"Our individual freedom is in inextricably bound to the freedom of every soul on Earth\" #InaugQuote",
    "id" : 293423582623711232,
    "in_reply_to_status_id" : 293422999896477696,
    "created_at" : "2013-01-21 18:23:28 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "D.F. Rasin",
      "screen_name" : "dfrasinphoto",
      "protected" : false,
      "id_str" : "258032863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436348379623600131\/LV9uz1yf_normal.jpeg",
      "id" : 258032863,
      "verified" : false
    }
  },
  "id" : 293424343625654272,
  "created_at" : "2013-01-21 18:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gibbs",
      "screen_name" : "Jeremy_Gibbs",
      "indices" : [ 3, 16 ],
      "id_str" : "19303241",
      "id" : 19303241
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293424156320616448",
  "text" : "RT @Jeremy_Gibbs: @whitehouse \u201Cfor if we are truly created equal, then surely the love we commit to one another must be equal as well.\u201D  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InaugQuote",
        "indices" : [ 118, 129 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "293422999896477696",
    "geo" : { },
    "id_str" : "293423451589447680",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse \u201Cfor if we are truly created equal, then surely the love we commit to one another must be equal as well.\u201D #InaugQuote",
    "id" : 293423451589447680,
    "in_reply_to_status_id" : 293422999896477696,
    "created_at" : "2013-01-21 18:22:57 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Jeremy Gibbs",
      "screen_name" : "Jeremy_Gibbs",
      "protected" : false,
      "id_str" : "19303241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796254231812411392\/6Ij0TXmx_normal.jpg",
      "id" : 19303241,
      "verified" : false
    }
  },
  "id" : 293424156320616448,
  "created_at" : "2013-01-21 18:25:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "InaugQuote",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/DghWpqNh",
      "expanded_url" : "http:\/\/at.wh.gov\/gZYVx",
      "display_url" : "at.wh.gov\/gZYVx"
    } ]
  },
  "geo" : { },
  "id_str" : "293422999896477696",
  "text" : "President Obama just delivered his second inaugural address. What was your favorite #quote? http:\/\/t.co\/DghWpqNh Tell us with #InaugQuote",
  "id" : 293422999896477696,
  "created_at" : "2013-01-21 18:21:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/UpplHUeG",
      "expanded_url" : "http:\/\/at.wh.gov\/gZUp1",
      "display_url" : "at.wh.gov\/gZUp1"
    } ]
  },
  "geo" : { },
  "id_str" : "293414157942919168",
  "text" : "The voices of the American people are making a real difference. Be a part of the next four years: http:\/\/t.co\/UpplHUeG #inaug2013",
  "id" : 293414157942919168,
  "created_at" : "2013-01-21 17:46:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/293409419792900096\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/hAtROggQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJmUBDCYAAiP2G.jpg",
      "id_str" : "293409419797094400",
      "id" : 293409419797094400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJmUBDCYAAiP2G.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/hAtROggQ"
    } ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293409419792900096",
  "text" : "\"That all of us are created equal \u2013 is still the star that guides us still.\" \u2014President Obama #inaug2013 http:\/\/t.co\/hAtROggQ",
  "id" : 293409419792900096,
  "created_at" : "2013-01-21 17:27:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293405573741936640",
  "text" : "\"Thank you, God Bless you, and may He forever bless these United States of America.\" \u2014President Obama #inaug2013",
  "id" : 293405573741936640,
  "created_at" : "2013-01-21 17:11:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293405510739300352",
  "text" : "Obama: \"With passion &amp; dedication, let us answer the call of history &amp; carry into an uncertain future that precious light of freedom\"",
  "id" : 293405510739300352,
  "created_at" : "2013-01-21 17:11:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293405488266235904\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/sIFvZP1D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJivK_CUAACwmm.jpg",
      "id_str" : "293405488274624512",
      "id" : 293405488274624512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJivK_CUAACwmm.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/sIFvZP1D"
    } ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293405488266235904",
  "text" : "\"You and I, as citizens, have the power to set this country\u2019s course.\" \u2014President Obama #inaug2013 http:\/\/t.co\/sIFvZP1D",
  "id" : 293405488266235904,
  "created_at" : "2013-01-21 17:11:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293405463956029440",
  "text" : "President Obama: \"Let each of us now embrace, with solemn duty and awesome joy, what is our lasting birthright.\" #inaug2013",
  "id" : 293405463956029440,
  "created_at" : "2013-01-21 17:11:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293405360625172480",
  "text" : "\u201CThey are the words of citizens, and they represent our greatest hope.\u201D \u2014President Obama #inaug2013",
  "id" : 293405360625172480,
  "created_at" : "2013-01-21 17:11:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293405320229842944",
  "text" : "President Obama: \"My oath is not so different from the pledge we all make to the flag that waves above &amp; that fills our hearts with pride.\"",
  "id" : 293405320229842944,
  "created_at" : "2013-01-21 17:10:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293405250151407617",
  "text" : "Obama: \"The words I spoke today are not so different from the oath that is taken each time a soldier signs up for duty\" #inaug2013",
  "id" : 293405250151407617,
  "created_at" : "2013-01-21 17:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293405189342375937",
  "text" : "\"The oath I have sworn before you today...was an oath to God and country, not party or faction\" \u2014President Obama #inaug2013",
  "id" : 293405189342375937,
  "created_at" : "2013-01-21 17:10:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293405023981944832",
  "text" : "\u201CWe must act, knowing that our work will be imperfect.\u201D \u2014President Obama #inaug2013",
  "id" : 293405023981944832,
  "created_at" : "2013-01-21 17:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404986757509121",
  "text" : "Obama: \"We cannot mistake absolutism for principle, or substitute spectacle for politics, or treat name-calling as reasoned debate.\"",
  "id" : 293404986757509121,
  "created_at" : "2013-01-21 17:09:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404944944484352",
  "text" : "\"For now decisions are upon us, and we cannot afford delay.\" \u2014President Obama #inaug2013",
  "id" : 293404944944484352,
  "created_at" : "2013-01-21 17:09:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404910060453889",
  "text" : "Obama: \"Progress does not compel us to settle centuries-long debates about the role of government...but it does require us to act\"",
  "id" : 293404910060453889,
  "created_at" : "2013-01-21 17:09:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404870399123456",
  "text" : "President Obama: \"Being true to our founding documents does not require us to agree on every contour of life\" #inaug2013",
  "id" : 293404870399123456,
  "created_at" : "2013-01-21 17:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404812236693504",
  "text" : "Obama: \"That is our generation\u2019s task \u2013 to make...these values \u2013 of Life &amp; Liberty &amp; the Pursuit of Happiness \u2013 real for every American\"",
  "id" : 293404812236693504,
  "created_at" : "2013-01-21 17:08:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404754393059328",
  "text" : "\"Our journey is not complete until all our children...know that they are cared for &amp; cherished &amp; always safe from harm.\" \u2014President Obama",
  "id" : 293404754393059328,
  "created_at" : "2013-01-21 17:08:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293404724881940482\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/CiImlQNY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJiCvKCYAEVE33.jpg",
      "id_str" : "293404724890329089",
      "id" : 293404724890329089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJiCvKCYAEVE33.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/CiImlQNY"
    } ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404724881940482",
  "text" : "\"Our journey is not complete until we find a better way to welcome the striving, hopeful immigrants\" #inaug2013 http:\/\/t.co\/CiImlQNY",
  "id" : 293404724881940482,
  "created_at" : "2013-01-21 17:08:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293404632171048962\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/WDgBt5H2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJh9VyCcAAW9Iu.jpg",
      "id_str" : "293404632179437568",
      "id" : 293404632179437568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJh9VyCcAAW9Iu.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/WDgBt5H2"
    } ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404632171048962",
  "text" : "\"Our journey is not complete until our gay brothers and sisters are treated like anyone else under the law\" #inaug2013 http:\/\/t.co\/WDgBt5H2",
  "id" : 293404632171048962,
  "created_at" : "2013-01-21 17:08:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293404515313532928\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/9zl5HXmx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJh2idCQAAS6aH.jpg",
      "id_str" : "293404515321921536",
      "id" : 293404515321921536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJh2idCQAAS6aH.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/9zl5HXmx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404515313532928",
  "text" : "\"Our journey is not complete until our wives, our mothers &amp; daughters can earn a living equal to their efforts\" http:\/\/t.co\/9zl5HXmx",
  "id" : 293404515313532928,
  "created_at" : "2013-01-21 17:07:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404377912328192",
  "text" : "\"It is now our generation\u2019s task to carry on what those pioneers began.\" \u2014President Obama #inaug2013",
  "id" : 293404377912328192,
  "created_at" : "2013-01-21 17:07:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293404369678901248",
  "text" : "\"The most evident of truths \u2013 that all of us are created equal \u2013 is still the star that guides us still.\" \u2014President Obama #inaug2013",
  "id" : 293404369678901248,
  "created_at" : "2013-01-21 17:07:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403849518088192",
  "text" : "President Obama: \"We will show the courage to try and resolve our differences with other nations peacefully\" #inaug2013",
  "id" : 293403849518088192,
  "created_at" : "2013-01-21 17:05:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403808078376961",
  "text" : "President Obama: \"We will defend our people and uphold our values through strength of arms and rule of law.\" #inaug2013",
  "id" : 293403808078376961,
  "created_at" : "2013-01-21 17:04:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403744362721280",
  "text" : "President Obama: \"The knowledge of their sacrifice will keep us forever vigilant against those who would do us harm.\" #inaug2013",
  "id" : 293403744362721280,
  "created_at" : "2013-01-21 17:04:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403705376641025",
  "text" : "President Obama: \"Our citizens, seared by the memory of those we have lost, know too well the price that is paid for liberty.\" #inaug2013",
  "id" : 293403705376641025,
  "created_at" : "2013-01-21 17:04:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403659914592258",
  "text" : "President Obama: \"Our brave men and women in uniform, tempered by the flames of battle, are unmatched in skill &amp; courage.\" #inaug2013",
  "id" : 293403659914592258,
  "created_at" : "2013-01-21 17:04:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403586975637507",
  "text" : "\"We, the people, still believe that enduring security and lasting peace do not require perpetual war.\" \u2014President Obama #inaug2013",
  "id" : 293403586975637507,
  "created_at" : "2013-01-21 17:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403458755784704",
  "text" : "\"We cannot cede to other nations the technology that will power new jobs &amp; new industries \u2013 we must claim its promise.\" \u2014President Obama",
  "id" : 293403458755784704,
  "created_at" : "2013-01-21 17:03:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403413323055104",
  "text" : "Obama: \"The path towards sustainable energy sources will be long...But America cannot resist this transition; we must lead it.\" #inaug2013",
  "id" : 293403413323055104,
  "created_at" : "2013-01-21 17:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403344792322048",
  "text" : "\"None can avoid the devastating impact of raging fires, and crippling drought &amp; more powerful storms.\" \u2014President Obama #inaug2013",
  "id" : 293403344792322048,
  "created_at" : "2013-01-21 17:03:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293403289247162368\/photo\/1",
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/fpasGbNG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJgvLACIAQ1d65.jpg",
      "id_str" : "293403289255550980",
      "id" : 293403289255550980,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJgvLACIAQ1d65.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/fpasGbNG"
    } ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403289247162368",
  "text" : "\u201CWe will respond to the threat of climate change\u201D \u2014President Obama #inaug2013 http:\/\/t.co\/fpasGbNG",
  "id" : 293403289247162368,
  "created_at" : "2013-01-21 17:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403251745906688",
  "text" : "Obama: \"We, the people, still believe that our obligations as Americans are not just to ourselves, but to all posterity.\" #inaug2013",
  "id" : 293403251745906688,
  "created_at" : "2013-01-21 17:02:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293403000947499008",
  "text" : "President Obama: \"We do not believe that in this country, freedom is reserved for the lucky, or happiness for the few.\" #inaug2013",
  "id" : 293403000947499008,
  "created_at" : "2013-01-21 17:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402863756005377",
  "text" : "\"We must make the hard choices to reduce the cost of health care and the size of our deficit.\" \u2014President Obama #inaug2013",
  "id" : 293402863756005377,
  "created_at" : "2013-01-21 17:01:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402820521119746",
  "text" : "\"We, the people, still believe that every citizen deserves a basic measure of security and dignity.\" \u2014President Obama #inaug2013",
  "id" : 293402820521119746,
  "created_at" : "2013-01-21 17:00:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402732663021568",
  "text" : "Obama: \"While the means will change, our purpose endures: a nation that rewards the effort &amp; determination of every single American\"",
  "id" : 293402732663021568,
  "created_at" : "2013-01-21 17:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402697036607488",
  "text" : "\"[We must] empower our citizens with the skills they need to work harder, learn more &amp; reach higher.\" \u2014President Obama #inaug2013",
  "id" : 293402697036607488,
  "created_at" : "2013-01-21 17:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402657152983040",
  "text" : "President Obama: \"We must harness new ideas &amp; technology to remake our government, revamp our tax code, reform our schools\" #inaug2013",
  "id" : 293402657152983040,
  "created_at" : "2013-01-21 17:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402545022455809",
  "text" : "Obama: \"We are true to our creed when a little girl born into the bleakest poverty knows that she has the same chance to succeed as anybody\"",
  "id" : 293402545022455809,
  "created_at" : "2013-01-21 16:59:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402499963052034",
  "text" : "\"We know that America thrives when every person can find independence and pride in their work.\"\u2014President Obama #inaug2013",
  "id" : 293402499963052034,
  "created_at" : "2013-01-21 16:59:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 117, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402462688247808",
  "text" : "\"We believe that America\u2019s prosperity must rest upon the broad shoulders of a rising middle class..\"\u2014President Obama #inaug2013",
  "id" : 293402462688247808,
  "created_at" : "2013-01-21 16:59:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402416982925314",
  "text" : "Obama: \"For we, the people, understand that our country cannot succeed when a shrinking few do very well &amp; a growing many barely make it\"",
  "id" : 293402416982925314,
  "created_at" : "2013-01-21 16:59:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293402411140251650\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/JGUXWIHG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBJf8D0CAAAdWCs.jpg",
      "id_str" : "293402411152834560",
      "id" : 293402411152834560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBJf8D0CAAAdWCs.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/JGUXWIHG"
    } ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402411140251650",
  "text" : "\"We are made for this moment &amp; we will seize it \u2013 so long as we seize it together.\" \u2014President Obama #inaug2013 http:\/\/t.co\/JGUXWIHG",
  "id" : 293402411140251650,
  "created_at" : "2013-01-21 16:59:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402166801080323",
  "text" : "President Obama: \"This generation of Americans has been tested by crises that steeled our resolve and proved our resilience\" #inaug2013",
  "id" : 293402166801080323,
  "created_at" : "2013-01-21 16:58:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402099843223552",
  "text" : "\"Now, more than ever, we must do these things together, as one nation, and one people.\" \u2014President Obama #inaug2013",
  "id" : 293402099843223552,
  "created_at" : "2013-01-21 16:58:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293402014300377088",
  "text" : "Obama: Americans \"can no more meet the demands of today\u2019s world by acting alone than American soldiers could have met the forces of fascism\"",
  "id" : 293402014300377088,
  "created_at" : "2013-01-21 16:57:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401929927782400",
  "text" : "\"We have always understood that when times change, so must we\" \u2014President Obama #inaug2013",
  "id" : 293401929927782400,
  "created_at" : "2013-01-21 16:57:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401899246440448",
  "text" : "Obama: \"Our celebration of initiative...our insistence on hard work and personal responsibility, these are constants in our character.\"",
  "id" : 293401899246440448,
  "created_at" : "2013-01-21 16:57:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 131, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401745726521344",
  "text" : "Obama: \"Together, we resolved that a great nation must care for the vulnerable &amp; protect its people from life\u2019s worst hazards\" #inaug2013",
  "id" : 293401745726521344,
  "created_at" : "2013-01-21 16:56:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401699912138754",
  "text" : "Obama: \"Together, we discovered that a free market only thrives when there are rules to ensure competition and fair play.\" #inaug2013",
  "id" : 293401699912138754,
  "created_at" : "2013-01-21 16:56:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 135, 145 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401668152856576",
  "text" : "Obama: \"Together, we determined that a modern economy requires railroads &amp; highways...schools &amp; colleges to train our workers\" #inaug2013",
  "id" : 293401668152856576,
  "created_at" : "2013-01-21 16:56:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401631050039296",
  "text" : "President Obama: \u201CWe made ourselves anew, and vowed to move forward together.\u201D #inaug2013",
  "id" : 293401631050039296,
  "created_at" : "2013-01-21 16:56:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401602100961281",
  "text" : "Obama: \"We learned that no union founded on the principles of liberty and equality could survive half-slave &amp; half-free\" #inaug2013",
  "id" : 293401602100961281,
  "created_at" : "2013-01-21 16:56:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401557494542336",
  "text" : "President Obama: \u201CFor more than two hundred years, we have.\u201D #inaug2013",
  "id" : 293401557494542336,
  "created_at" : "2013-01-21 16:55:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401518718189571",
  "text" : "Obama: \"They gave to us a Republic, a government of, and by, &amp; for the people, entrusting each generation to keep safe our founding creed.\"",
  "id" : 293401518718189571,
  "created_at" : "2013-01-21 16:55:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401469183475713",
  "text" : "Obama: \"The patriots of 1776 did not fight to replace the tyranny of a king with the privileges of a few or the rule of a mob.\" #inaug2013",
  "id" : 293401469183475713,
  "created_at" : "2013-01-21 16:55:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401408844206080",
  "text" : "Obama: \"while freedom is a gift from God, it must be secured by His people here on Earth.\" #inaug2013",
  "id" : 293401408844206080,
  "created_at" : "2013-01-21 16:55:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401368864096256",
  "text" : "Obama: \"For history tells us that while these truths may be self-evident, they have never been self-executing\" #inaug2013",
  "id" : 293401368864096256,
  "created_at" : "2013-01-21 16:55:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401325683761152",
  "text" : "President Obama: \"Today we continue a never-ending journey, to bridge the meaning of those words with the realities of our time.\" #inaug2013",
  "id" : 293401325683761152,
  "created_at" : "2013-01-21 16:55:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401245115351040",
  "text" : "Obama cites the Declaration of Independence: \u201Call men are created equal...endowed by their Creator with certain unalienable rights\"",
  "id" : 293401245115351040,
  "created_at" : "2013-01-21 16:54:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401148738658304",
  "text" : "Obama: \"What makes us exceptional \u2013 what makes us American \u2013 is our allegiance to an idea, articulated in a declaration...\" #Inaug2013",
  "id" : 293401148738658304,
  "created_at" : "2013-01-21 16:54:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293401032359284736",
  "text" : "President Obama: \"Each time we gather to inaugurate a president, we bear witness to the enduring strength of our Constitution.\" #inaug2013",
  "id" : 293401032359284736,
  "created_at" : "2013-01-21 16:53:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293400963266539520",
  "text" : "President Obama: Vice President Biden, Mr. Chief Justice, Members of the United States Congress, distinguished guests &amp; fellow citizens:",
  "id" : 293400963266539520,
  "created_at" : "2013-01-21 16:53:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293391222557515776",
  "text" : "RT @FLOTUS: Honored and blessed to be joining so many of my fellow Americans gathered to watch the Inauguration. \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293391065325662208",
    "text" : "Honored and blessed to be joining so many of my fellow Americans gathered to watch the Inauguration. \u2013mo",
    "id" : 293391065325662208,
    "created_at" : "2013-01-21 16:14:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 293391222557515776,
  "created_at" : "2013-01-21 16:14:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 134, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/ncjGusur",
      "expanded_url" : "http:\/\/wh.gov\/inauguration",
      "display_url" : "wh.gov\/inauguration"
    } ]
  },
  "geo" : { },
  "id_str" : "293388466291605505",
  "text" : "Happening now: President Obama takes the oath of office &amp; delivers his second inaugural address. Watch live: http:\/\/t.co\/ncjGusur #inaug2013",
  "id" : 293388466291605505,
  "created_at" : "2013-01-21 16:03:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doris Kearns Goodwin",
      "screen_name" : "DorisKGoodwin",
      "indices" : [ 11, 25 ],
      "id_str" : "610922415",
      "id" : 610922415
    }, {
      "name" : "Michael Beschloss",
      "screen_name" : "BeschlossDC",
      "indices" : [ 27, 39 ],
      "id_str" : "874916178",
      "id" : 874916178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 134, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/q7GKZK67",
      "expanded_url" : "http:\/\/youtu.be\/Lu1YxRLUt5U",
      "display_url" : "youtu.be\/Lu1YxRLUt5U"
    } ]
  },
  "geo" : { },
  "id_str" : "293382608845422592",
  "text" : "Historians @DorisKGoodwin, @BeschlossDC, Douglas Brinkley &amp; Robert Caro on Presidential Inaugurations. Watch http:\/\/t.co\/q7GKZK67 #Inaug2013",
  "id" : 293382608845422592,
  "created_at" : "2013-01-21 15:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/B0jOYEEb",
      "expanded_url" : "http:\/\/at.wh.gov\/gZqRo",
      "display_url" : "at.wh.gov\/gZqRo"
    } ]
  },
  "geo" : { },
  "id_str" : "293363451500306433",
  "text" : "At 11:00 ET: President Obama delivers his second inaugural address from the Capitol. Watch live: http:\/\/t.co\/B0jOYEEb #Inaug2013",
  "id" : 293363451500306433,
  "created_at" : "2013-01-21 14:24:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/293176979744763904\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/j2Xeqomp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBGS6OaCMAAst9Z.jpg",
      "id_str" : "293176979753152512",
      "id" : 293176979753152512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBGS6OaCMAAst9Z.jpg",
      "sizes" : [ {
        "h" : 906,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1937,
        "resize" : "fit",
        "w" : 1283
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1546,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/j2Xeqomp"
    } ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/VsjQP6Lz",
      "expanded_url" : "http:\/\/at.wh.gov\/gYDia",
      "display_url" : "at.wh.gov\/gYDia"
    } ]
  },
  "geo" : { },
  "id_str" : "293176979744763904",
  "text" : "Photos: The Inauguration of President Obama: http:\/\/t.co\/VsjQP6Lz Watch the #inaug2013 address on Jan. 21 at 11ET http:\/\/t.co\/j2Xeqomp",
  "id" : 293176979744763904,
  "created_at" : "2013-01-21 02:03:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293075767590539264\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/nmNroT6c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBE225vCUAE1NAX.jpg",
      "id_str" : "293075767594733569",
      "id" : 293075767594733569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBE225vCUAE1NAX.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/nmNroT6c"
    } ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/ncjGusur",
      "expanded_url" : "http:\/\/wh.gov\/inauguration",
      "display_url" : "wh.gov\/inauguration"
    } ]
  },
  "geo" : { },
  "id_str" : "293075767590539264",
  "text" : "President Obama has officially been sworn in for a second term. Don't miss the #Inaug2013 Address: http:\/\/t.co\/ncjGusur http:\/\/t.co\/nmNroT6c",
  "id" : 293075767590539264,
  "created_at" : "2013-01-20 19:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 29, 32 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/293067077558882304\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/SUkTeBFI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBEu9E3CUAEj5yY.jpg",
      "id_str" : "293067077567270913",
      "id" : 293067077567270913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBEu9E3CUAEj5yY.jpg",
      "sizes" : [ {
        "h" : 965,
        "resize" : "fit",
        "w" : 1447
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SUkTeBFI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293067077558882304",
  "text" : "Photo: President Obama &amp; @VP Biden lay a wreath at the Tomb of the Unknowns at Arlington National Cemetery: http:\/\/t.co\/SUkTeBFI",
  "id" : 293067077558882304,
  "created_at" : "2013-01-20 18:46:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/D7Py5SmU",
      "expanded_url" : "http:\/\/at.wh.gov\/gYfMU",
      "display_url" : "at.wh.gov\/gYfMU"
    } ]
  },
  "geo" : { },
  "id_str" : "293055014493122563",
  "text" : "Video: President Obama takes the oath of office for a second term: http:\/\/t.co\/D7Py5SmU #inaug2013",
  "id" : 293055014493122563,
  "created_at" : "2013-01-20 17:58:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/293051923525939200\/photo\/1",
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/Vau1x1h2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBEhK_rCMAErrnS.jpg",
      "id_str" : "293051923530133505",
      "id" : 293051923530133505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBEhK_rCMAErrnS.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 902,
        "resize" : "fit",
        "w" : 902
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 902,
        "resize" : "fit",
        "w" : 902
      } ],
      "display_url" : "pic.twitter.com\/Vau1x1h2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293053062933782528",
  "text" : "President Obama takes the oath of office for a second term surrounded by family at the White House: http:\/\/t.co\/Vau1x1h2",
  "id" : 293053062933782528,
  "created_at" : "2013-01-20 17:51:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/293048739529121792\/photo\/1",
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/09F5TTC8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBEeRqXCYAA4k2y.jpg",
      "id_str" : "293048739533316096",
      "id" : 293048739533316096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBEeRqXCYAA4k2y.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      } ],
      "display_url" : "pic.twitter.com\/09F5TTC8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293051042977943554",
  "text" : "RT @petesouza: Photo of POTUS taking the oath of office http:\/\/t.co\/09F5TTC8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/293048739529121792\/photo\/1",
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/09F5TTC8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBEeRqXCYAA4k2y.jpg",
        "id_str" : "293048739533316096",
        "id" : 293048739533316096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBEeRqXCYAA4k2y.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        } ],
        "display_url" : "pic.twitter.com\/09F5TTC8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293048739529121792",
    "text" : "Photo of POTUS taking the oath of office http:\/\/t.co\/09F5TTC8",
    "id" : 293048739529121792,
    "created_at" : "2013-01-20 17:33:59 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 293051042977943554,
  "created_at" : "2013-01-20 17:43:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293045612583211008",
  "text" : "RT @FLOTUS: Barack just took the official oath at the @WhiteHouse &amp; used my grandma\u2019s bible for the ceremony. I\u2019m so proud of him. \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 42, 53 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293045535139586048",
    "text" : "Barack just took the official oath at the @WhiteHouse &amp; used my grandma\u2019s bible for the ceremony. I\u2019m so proud of him. \u2013mo",
    "id" : 293045535139586048,
    "created_at" : "2013-01-20 17:21:14 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 293045612583211008,
  "created_at" : "2013-01-20 17:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/ncjGusur",
      "expanded_url" : "http:\/\/wh.gov\/inauguration",
      "display_url" : "wh.gov\/inauguration"
    } ]
  },
  "geo" : { },
  "id_str" : "293039209990729729",
  "text" : "Watch live: President Obama takes the oath of office at the official swearing-in ceremony at the White House: http:\/\/t.co\/ncjGusur",
  "id" : 293039209990729729,
  "created_at" : "2013-01-20 16:56:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/293038536385515520\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/VgnBRj51",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBEU_wtCUAAIqds.jpg",
      "id_str" : "293038536393904128",
      "id" : 293038536393904128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBEU_wtCUAAIqds.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VgnBRj51"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293038536385515520",
  "text" : "At 12ET, the President takes the oath of office using the family Bible of First Lady Michelle Obama's grandparents: http:\/\/t.co\/VgnBRj51",
  "id" : 293038536385515520,
  "created_at" : "2013-01-20 16:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/8qUD3M3F",
      "expanded_url" : "http:\/\/at.wh.gov\/gYbaR",
      "display_url" : "at.wh.gov\/gYbaR"
    } ]
  },
  "geo" : { },
  "id_str" : "293031676181876739",
  "text" : "Watch at 11:55 ET: President Obama takes the oath of office at the official swearing-in ceremony: http:\/\/t.co\/8qUD3M3F #inaug2013",
  "id" : 293031676181876739,
  "created_at" : "2013-01-20 16:26:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293007923142090752",
  "text" : "RT @VP: Justice Sotomayor administers the oath of office to Vice President Joe Biden during the official swearing-in ceremony: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/293007781986983937\/photo\/1",
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/9Acd45Iw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBD5BnoCYAIEjjZ.jpg",
        "id_str" : "293007781991178242",
        "id" : 293007781991178242,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBD5BnoCYAIEjjZ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9Acd45Iw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "293007781986983937",
    "text" : "Justice Sotomayor administers the oath of office to Vice President Joe Biden during the official swearing-in ceremony: http:\/\/t.co\/9Acd45Iw",
    "id" : 293007781986983937,
    "created_at" : "2013-01-20 14:51:14 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 293007923142090752,
  "created_at" : "2013-01-20 14:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292998249349009408",
  "text" : "RT @VP: VP Joe Biden has officially been sworn in for his second term as Vice President of the United States.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292998140745875456",
    "text" : "VP Joe Biden has officially been sworn in for his second term as Vice President of the United States.",
    "id" : 292998140745875456,
    "created_at" : "2013-01-20 14:12:55 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 292998249349009408,
  "created_at" : "2013-01-20 14:13:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/DBduOoyj",
      "expanded_url" : "http:\/\/wh.gov\/Inauguration",
      "display_url" : "wh.gov\/Inauguration"
    } ]
  },
  "geo" : { },
  "id_str" : "292802408663371776",
  "text" : "Be a part of history: For everything you need to know about the 57th Presidential Inauguration visit: http:\/\/t.co\/DBduOoyj #Inaug2013",
  "id" : 292802408663371776,
  "created_at" : "2013-01-20 01:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292798515283910656",
  "text" : "RT @FLOTUS: \u201CMy very favorite part of this entire weekend is being right here with all of you\u201D \u2013The First Lady to military families http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/292797286474465282\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/anLiDNnU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBA5lKwCQAA0s-r.jpg",
        "id_str" : "292797286482853888",
        "id" : 292797286482853888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBA5lKwCQAA0s-r.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 568
        } ],
        "display_url" : "pic.twitter.com\/anLiDNnU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292797286474465282",
    "text" : "\u201CMy very favorite part of this entire weekend is being right here with all of you\u201D \u2013The First Lady to military families http:\/\/t.co\/anLiDNnU",
    "id" : 292797286474465282,
    "created_at" : "2013-01-20 00:54:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 292798515283910656,
  "created_at" : "2013-01-20 00:59:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "SoulChildrenChicago",
      "screen_name" : "ChiSoulChildren",
      "indices" : [ 96, 112 ],
      "id_str" : "428636197",
      "id" : 428636197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/FiB8JMzr",
      "expanded_url" : "http:\/\/www.2013pic.org\/live",
      "display_url" : "2013pic.org\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "292791184433238017",
  "text" : "RT @FLOTUS: Amazing performances at the Kids' Concert. Are you watching?   http:\/\/t.co\/FiB8JMzr @ChiSoulChildren on stage: http:\/\/t.co\/c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SoulChildrenChicago",
        "screen_name" : "ChiSoulChildren",
        "indices" : [ 84, 100 ],
        "id_str" : "428636197",
        "id" : 428636197
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/292790198838915072\/photo\/1",
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/ctKmFeEu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBAzInQCcAE3t0o.jpg",
        "id_str" : "292790198847303681",
        "id" : 292790198847303681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBAzInQCcAE3t0o.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/ctKmFeEu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/FiB8JMzr",
        "expanded_url" : "http:\/\/www.2013pic.org\/live",
        "display_url" : "2013pic.org\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "292790198838915072",
    "text" : "Amazing performances at the Kids' Concert. Are you watching?   http:\/\/t.co\/FiB8JMzr @ChiSoulChildren on stage: http:\/\/t.co\/ctKmFeEu",
    "id" : 292790198838915072,
    "created_at" : "2013-01-20 00:26:38 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 292791184433238017,
  "created_at" : "2013-01-20 00:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292767991341408256",
  "text" : "RT @FLOTUS: Photo: The First Lady &amp; Dr. Biden greet Jaelen, a 10 year old military kid &amp; his family before tonight's concert: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/292760449001336832\/photo\/1",
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/h08F67fi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BBAYE8gCMAA28Oq.jpg",
        "id_str" : "292760449018114048",
        "id" : 292760449018114048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBAYE8gCMAA28Oq.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1136,
          "resize" : "fit",
          "w" : 1136
        } ],
        "display_url" : "pic.twitter.com\/h08F67fi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292760449001336832",
    "text" : "Photo: The First Lady &amp; Dr. Biden greet Jaelen, a 10 year old military kid &amp; his family before tonight's concert: http:\/\/t.co\/h08F67fi",
    "id" : 292760449001336832,
    "created_at" : "2013-01-19 22:28:25 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 292767991341408256,
  "created_at" : "2013-01-19 22:58:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KATY PERRY",
      "screen_name" : "katyperry",
      "indices" : [ 55, 65 ],
      "id_str" : "21447363",
      "id" : 21447363
    }, {
      "name" : "GLEE",
      "screen_name" : "GLEEonFOX",
      "indices" : [ 84, 94 ],
      "id_str" : "30104231",
      "id" : 30104231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/y7Njj8eW",
      "expanded_url" : "http:\/\/at.wh.gov\/gXxeG",
      "display_url" : "at.wh.gov\/gXxeG"
    } ]
  },
  "geo" : { },
  "id_str" : "292764680819204098",
  "text" : "Starting at 6ET: The Kids' Inaugural Concert featuring @KatyPerry &amp; the cast of @GLEEonFOX. Watch live: http:\/\/t.co\/y7Njj8eW #Inaug2013",
  "id" : 292764680819204098,
  "created_at" : "2013-01-19 22:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292754509262884864",
  "text" : "RT @FLOTUS: So excited for tonight\u2019s concert for military kids! There will be amazing performers \u2013 watch it live at 6pm ET http:\/\/t.co\/F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/FiB8JMzr",
        "expanded_url" : "http:\/\/www.2013pic.org\/live",
        "display_url" : "2013pic.org\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "292753715864162304",
    "text" : "So excited for tonight\u2019s concert for military kids! There will be amazing performers \u2013 watch it live at 6pm ET http:\/\/t.co\/FiB8JMzr. \u2013mo",
    "id" : 292753715864162304,
    "created_at" : "2013-01-19 22:01:39 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 292754509262884864,
  "created_at" : "2013-01-19 22:04:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/292738909815832577\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/m5dT53k6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BBAEfMwCAAEBw3-.jpg",
      "id_str" : "292738909824221185",
      "id" : 292738909824221185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BBAEfMwCAAEBw3-.jpg",
      "sizes" : [ {
        "h" : 989,
        "resize" : "fit",
        "w" : 1513
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/m5dT53k6"
    } ],
    "hashtags" : [ {
      "text" : "iserve",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292738909815832577",
  "text" : "Photo: President Obama joins a National Day of Service project at Burrville Elementary School, Jan. 19, 2013. #iserve http:\/\/t.co\/m5dT53k6",
  "id" : 292738909815832577,
  "created_at" : "2013-01-19 21:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nowisthetime",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/sxkVCxMO",
      "expanded_url" : "http:\/\/at.wh.gov\/gXdwD",
      "display_url" : "at.wh.gov\/gXdwD"
    } ]
  },
  "geo" : { },
  "id_str" : "292716839132340224",
  "text" : "President Obama: \"Let\u2019s make this country a safer place for all our children.\" Watch the Weekly Address http:\/\/t.co\/sxkVCxMO #Nowisthetime",
  "id" : 292716839132340224,
  "created_at" : "2013-01-19 19:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ennisantoine",
      "screen_name" : "ennisantoine",
      "indices" : [ 3, 16 ],
      "id_str" : "16341058",
      "id" : 16341058
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ennisantoine\/status\/292713366609338370\/photo\/1",
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/2Co6rzwd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA_tQY4CIAA1Gnf.jpg",
      "id_str" : "292713366613532672",
      "id" : 292713366613532672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA_tQY4CIAA1Gnf.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1045,
        "resize" : "fit",
        "w" : 1400
      } ],
      "display_url" : "pic.twitter.com\/2Co6rzwd"
    } ],
    "hashtags" : [ {
      "text" : "iserve",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292714609687818240",
  "text" : "RT @ennisantoine: I volunteered at National Mall #iserve http:\/\/t.co\/2Co6rzwd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ennisantoine\/status\/292713366609338370\/photo\/1",
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/2Co6rzwd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BA_tQY4CIAA1Gnf.jpg",
        "id_str" : "292713366613532672",
        "id" : 292713366613532672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA_tQY4CIAA1Gnf.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1045,
          "resize" : "fit",
          "w" : 1400
        } ],
        "display_url" : "pic.twitter.com\/2Co6rzwd"
      } ],
      "hashtags" : [ {
        "text" : "iserve",
        "indices" : [ 31, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292713366609338370",
    "text" : "I volunteered at National Mall #iserve http:\/\/t.co\/2Co6rzwd",
    "id" : 292713366609338370,
    "created_at" : "2013-01-19 19:21:20 +0000",
    "user" : {
      "name" : "ennisantoine",
      "screen_name" : "ennisantoine",
      "protected" : false,
      "id_str" : "16341058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576390292\/ernis_antoine_normal.jpg",
      "id" : 16341058,
      "verified" : false
    }
  },
  "id" : 292714609687818240,
  "created_at" : "2013-01-19 19:26:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vimala Phongsavanh",
      "screen_name" : "vimalap",
      "indices" : [ 3, 11 ],
      "id_str" : "18990302",
      "id" : 18990302
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vimalap\/status\/292712399042117632\/photo\/1",
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/Xke4jNaK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA_sYEaCAAABUMm.jpg",
      "id_str" : "292712399046311936",
      "id" : 292712399046311936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA_sYEaCAAABUMm.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Xke4jNaK"
    } ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 42, 49 ]
    }, {
      "text" : "Woonsocket",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "iserve",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292713792494764033",
  "text" : "RT @vimalap: Painting a mural at the YMCA #MLKDay #Woonsocket  #iserve http:\/\/t.co\/Xke4jNaK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vimalap\/status\/292712399042117632\/photo\/1",
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/Xke4jNaK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BA_sYEaCAAABUMm.jpg",
        "id_str" : "292712399046311936",
        "id" : 292712399046311936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA_sYEaCAAABUMm.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Xke4jNaK"
      } ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 29, 36 ]
      }, {
        "text" : "Woonsocket",
        "indices" : [ 37, 48 ]
      }, {
        "text" : "iserve",
        "indices" : [ 50, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292712399042117632",
    "text" : "Painting a mural at the YMCA #MLKDay #Woonsocket  #iserve http:\/\/t.co\/Xke4jNaK",
    "id" : 292712399042117632,
    "created_at" : "2013-01-19 19:17:29 +0000",
    "user" : {
      "name" : "Vimala Phongsavanh",
      "screen_name" : "vimalap",
      "protected" : false,
      "id_str" : "18990302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660436319064166400\/vP1tmS8N_normal.jpg",
      "id" : 18990302,
      "verified" : false
    }
  },
  "id" : 292713792494764033,
  "created_at" : "2013-01-19 19:23:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Cunningham",
      "screen_name" : "cunningham88",
      "indices" : [ 3, 16 ],
      "id_str" : "48215121",
      "id" : 48215121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iserve",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292709177858609153",
  "text" : "RT @cunningham88: Today #iserve at a Sandy relief kitchen in Brooklyn. Hundreds of sandwiches and cups of soup for those in need. http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/cunningham88\/status\/292705179164348416\/photo\/1",
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/Zv8Mo01m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BA_lz0TCEAADbS7.jpg",
        "id_str" : "292705179176931328",
        "id" : 292705179176931328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA_lz0TCEAADbS7.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Zv8Mo01m"
      } ],
      "hashtags" : [ {
        "text" : "iserve",
        "indices" : [ 6, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292705179164348416",
    "text" : "Today #iserve at a Sandy relief kitchen in Brooklyn. Hundreds of sandwiches and cups of soup for those in need. http:\/\/t.co\/Zv8Mo01m",
    "id" : 292705179164348416,
    "created_at" : "2013-01-19 18:48:47 +0000",
    "user" : {
      "name" : "Zach Cunningham",
      "screen_name" : "cunningham88",
      "protected" : false,
      "id_str" : "48215121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3529189396\/eb44da13a7c300efab948982785aad7d_normal.jpeg",
      "id" : 48215121,
      "verified" : false
    }
  },
  "id" : 292709177858609153,
  "created_at" : "2013-01-19 19:04:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lily Bolourian",
      "screen_name" : "LilyBolourian",
      "indices" : [ 3, 17 ],
      "id_str" : "265180740",
      "id" : 265180740
    }, {
      "name" : "Obama Inauguration",
      "screen_name" : "obamainaugural",
      "indices" : [ 117, 132 ],
      "id_str" : "18177016",
      "id" : 18177016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DCFoodDrive",
      "indices" : [ 95, 107 ]
    }, {
      "text" : "iserve",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292708510062497793",
  "text" : "RT @LilyBolourian: So heart-warming seeing the community come together for the less fortunate. #DCFoodDrive #iserve  @obamainaugural htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Obama Inauguration",
        "screen_name" : "obamainaugural",
        "indices" : [ 98, 113 ],
        "id_str" : "18177016",
        "id" : 18177016
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LilyBolourian\/status\/292706465158946816\/photo\/1",
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/4X9JoSzL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BA_m-q-CYAU70by.jpg",
        "id_str" : "292706465163141125",
        "id" : 292706465163141125,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA_m-q-CYAU70by.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4X9JoSzL"
      } ],
      "hashtags" : [ {
        "text" : "DCFoodDrive",
        "indices" : [ 76, 88 ]
      }, {
        "text" : "iserve",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292706465158946816",
    "text" : "So heart-warming seeing the community come together for the less fortunate. #DCFoodDrive #iserve  @obamainaugural http:\/\/t.co\/4X9JoSzL",
    "id" : 292706465158946816,
    "created_at" : "2013-01-19 18:53:54 +0000",
    "user" : {
      "name" : "Lily Bolourian",
      "screen_name" : "LilyBolourian",
      "protected" : false,
      "id_str" : "265180740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796404399690096644\/n_JB6Xnn_normal.jpg",
      "id" : 265180740,
      "verified" : false
    }
  },
  "id" : 292708510062497793,
  "created_at" : "2013-01-19 19:02:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "CityYear",
      "screen_name" : "CityYear",
      "indices" : [ 77, 86 ],
      "id_str" : "15758330",
      "id" : 15758330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iserve",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292704386306691072",
  "text" : "RT @FLOTUS: Today, our family volunteered at an elementary school in DC with @CityYear for MLK Day. Hope you are serving too! #iserve \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CityYear",
        "screen_name" : "CityYear",
        "indices" : [ 65, 74 ],
        "id_str" : "15758330",
        "id" : 15758330
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iserve",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292704085440880640",
    "text" : "Today, our family volunteered at an elementary school in DC with @CityYear for MLK Day. Hope you are serving too! #iserve \u2013mo",
    "id" : 292704085440880640,
    "created_at" : "2013-01-19 18:44:26 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 292704386306691072,
  "created_at" : "2013-01-19 18:45:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obama Inauguration",
      "screen_name" : "obamainaugural",
      "indices" : [ 3, 18 ],
      "id_str" : "18177016",
      "id" : 18177016
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 21, 24 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Points of Light",
      "screen_name" : "PointsofLight",
      "indices" : [ 75, 89 ],
      "id_str" : "224382700",
      "id" : 224382700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292697422109478912",
  "text" : "RT @obamainaugural: .@VP Biden helps package care kits for our troops at a @PointsofLight service project to kick off #inaug2013. http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 1, 4 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "Points of Light",
        "screen_name" : "PointsofLight",
        "indices" : [ 55, 69 ],
        "id_str" : "224382700",
        "id" : 224382700
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/obamainaugural\/status\/292696646301667328\/photo\/1",
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/jlJG1jMJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BA_eDI7CAAAKPi-.jpg",
        "id_str" : "292696646318424064",
        "id" : 292696646318424064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA_eDI7CAAAKPi-.jpg",
        "sizes" : [ {
          "h" : 867,
          "resize" : "fit",
          "w" : 1300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jlJG1jMJ"
      } ],
      "hashtags" : [ {
        "text" : "inaug2013",
        "indices" : [ 98, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292696646301667328",
    "text" : ".@VP Biden helps package care kits for our troops at a @PointsofLight service project to kick off #inaug2013. http:\/\/t.co\/jlJG1jMJ",
    "id" : 292696646301667328,
    "created_at" : "2013-01-19 18:14:53 +0000",
    "user" : {
      "name" : "Obama Inauguration",
      "screen_name" : "obamainaugural",
      "protected" : false,
      "id_str" : "18177016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2940082541\/ec2971fdd745e0fe674e4b415e312280_normal.jpeg",
      "id" : 18177016,
      "verified" : true
    }
  },
  "id" : 292697422109478912,
  "created_at" : "2013-01-19 18:17:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 32, 39 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/292685393755774976\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/rmaq2EsS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA_T0J5CIAALBIh.jpg",
      "id_str" : "292685393764163584",
      "id" : 292685393764163584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA_T0J5CIAALBIh.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/rmaq2EsS"
    } ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "iserve",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/iYgaz9lb",
      "expanded_url" : "http:\/\/on.wh.gov\/h678Ife",
      "display_url" : "on.wh.gov\/h678Ife"
    } ]
  },
  "geo" : { },
  "id_str" : "292685393755774976",
  "text" : "Today, join the President &amp; @FLOTUS in volunteering for #MLKDay of Service. Find an event http:\/\/t.co\/iYgaz9lb #iserve http:\/\/t.co\/rmaq2EsS",
  "id" : 292685393755774976,
  "created_at" : "2013-01-19 17:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/JDCJpV3L",
      "expanded_url" : "http:\/\/at.wh.gov\/gXbPB",
      "display_url" : "at.wh.gov\/gXbPB"
    } ]
  },
  "geo" : { },
  "id_str" : "292638531942236160",
  "text" : "President Obama's Weekly Address: #NowIsTheTime to take action to reduce gun violence: http:\/\/t.co\/JDCJpV3L",
  "id" : 292638531942236160,
  "created_at" : "2013-01-19 14:23:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 40, 47 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/292482791793381377\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/9D45Ohmu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA8bjKxCUAAaLsK.jpg",
      "id_str" : "292482791801769984",
      "id" : 292482791801769984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA8bjKxCUAAaLsK.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9D45Ohmu"
    } ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292482791793381377",
  "text" : "Photo of the Day: President Obama &amp; @FLOTUS Michelle Obama in the Blue Room before a brunch celebrating #Inaug2013: http:\/\/t.co\/9D45Ohmu",
  "id" : 292482791793381377,
  "created_at" : "2013-01-19 04:05:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/292452523955064832\/photo\/1",
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/b9ApUVZL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA8ABWSCEAAiZsE.jpg",
      "id_str" : "292452523963453440",
      "id" : 292452523963453440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA8ABWSCEAAiZsE.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/b9ApUVZL"
    } ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 31, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292452523955064832",
  "text" : "Today, President talked to the #Inaug2013 Citizen Co-Chairs in the Oval Office, Jan. 18, 2013: http:\/\/t.co\/b9ApUVZL",
  "id" : 292452523955064832,
  "created_at" : "2013-01-19 02:04:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 40, 56 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLK",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292442608385540097",
  "text" : "RT @Interior: In honor of #MLK day, the @NatlParkService is waiving entrance fees at all National Parks this weekend. RT to spread the word!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 26, 42 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLK",
        "indices" : [ 12, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292435556309286912",
    "text" : "In honor of #MLK day, the @NatlParkService is waiving entrance fees at all National Parks this weekend. RT to spread the word!",
    "id" : 292435556309286912,
    "created_at" : "2013-01-19 00:57:24 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 292442608385540097,
  "created_at" : "2013-01-19 01:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Highlights",
      "screen_name" : "Highlights",
      "indices" : [ 31, 42 ],
      "id_str" : "17294493",
      "id" : 17294493
    }, {
      "name" : "NatGeoKIDS",
      "screen_name" : "NGKids",
      "indices" : [ 43, 50 ],
      "id_str" : "41606204",
      "id" : 41606204
    }, {
      "name" : "Scholastic",
      "screen_name" : "Scholastic",
      "indices" : [ 51, 62 ],
      "id_str" : "14342018",
      "id" : 14342018
    }, {
      "name" : "TimeForKidsMag",
      "screen_name" : "TimeForKidsMag",
      "indices" : [ 69, 84 ],
      "id_str" : "2548542457",
      "id" : 2548542457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292391045839343616",
  "text" : "RT @FLOTUS: Kid reporters from @Highlights @NGKids @Scholastic &amp; @TimeForKidsMag just asked Mrs. Obama &amp; Dr. Biden some great Qs ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Highlights",
        "screen_name" : "Highlights",
        "indices" : [ 19, 30 ],
        "id_str" : "17294493",
        "id" : 17294493
      }, {
        "name" : "NatGeoKIDS",
        "screen_name" : "NGKids",
        "indices" : [ 31, 38 ],
        "id_str" : "41606204",
        "id" : 41606204
      }, {
        "name" : "Scholastic",
        "screen_name" : "Scholastic",
        "indices" : [ 39, 50 ],
        "id_str" : "14342018",
        "id" : 14342018
      }, {
        "name" : "TimeForKidsMag",
        "screen_name" : "TimeForKidsMag",
        "indices" : [ 57, 72 ],
        "id_str" : "2548542457",
        "id" : 2548542457
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/292387401471504385\/photo\/1",
        "indices" : [ 126, 146 ],
        "url" : "http:\/\/t.co\/dIZTtUN0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BA7EyuICMAIYmO9.jpg",
        "id_str" : "292387401479892994",
        "id" : 292387401479892994,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA7EyuICMAIYmO9.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/dIZTtUN0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "292387401471504385",
    "text" : "Kid reporters from @Highlights @NGKids @Scholastic &amp; @TimeForKidsMag just asked Mrs. Obama &amp; Dr. Biden some great Qs! http:\/\/t.co\/dIZTtUN0",
    "id" : 292387401471504385,
    "created_at" : "2013-01-18 21:46:03 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 292391045839343616,
  "created_at" : "2013-01-18 22:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/292297545902866432\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/I3tDjPzn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA5zEcDCQAEWooz.jpg",
      "id_str" : "292297545911255041",
      "id" : 292297545911255041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA5zEcDCQAEWooz.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/I3tDjPzn"
    } ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292297545902866432",
  "text" : "Photo of the Day: President Obama returns to the White House following a visit to #Inaug2013 headquarters in DC: http:\/\/t.co\/I3tDjPzn",
  "id" : 292297545902866432,
  "created_at" : "2013-01-18 15:49:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/Blex01HP",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/whitehouse\/8390033709\/in\/photostream",
      "display_url" : "flickr.com\/photos\/whiteho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292281924637036544",
  "text" : "RT @jearnest44: Check out the new official POTUS portrait - just in time for the Inauguration: http:\/\/t.co\/Blex01HP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/Blex01HP",
        "expanded_url" : "http:\/\/www.flickr.com\/photos\/whitehouse\/8390033709\/in\/photostream",
        "display_url" : "flickr.com\/photos\/whiteho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "292257167564746752",
    "text" : "Check out the new official POTUS portrait - just in time for the Inauguration: http:\/\/t.co\/Blex01HP",
    "id" : 292257167564746752,
    "created_at" : "2013-01-18 13:08:33 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 292281924637036544,
  "created_at" : "2013-01-18 14:46:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292280910999592961",
  "text" : "RT @NASA: It's NASA Open House day! If you're in DC for #Inaug2013, stop by NASA HQ. We're open from 10a-4p ET. Details: http:\/\/t.co\/2fD ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Inaug2013",
        "indices" : [ 46, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/2fDSjgQ4",
        "expanded_url" : "http:\/\/go.nasa.gov\/X381Pt",
        "display_url" : "go.nasa.gov\/X381Pt"
      } ]
    },
    "geo" : { },
    "id_str" : "292248473154232320",
    "text" : "It's NASA Open House day! If you're in DC for #Inaug2013, stop by NASA HQ. We're open from 10a-4p ET. Details: http:\/\/t.co\/2fDSjgQ4",
    "id" : 292248473154232320,
    "created_at" : "2013-01-18 12:34:00 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 292280910999592961,
  "created_at" : "2013-01-18 14:42:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292112376524845056",
  "text" : "RT @FLOTUS: Thanks for the warm welcome &amp; birthday wishes! Join me &amp; Barack for #MLKDay of Service this Saturday. Sign up: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/yJjvkcLm",
        "expanded_url" : "http:\/\/www.2013pic.org\/service",
        "display_url" : "2013pic.org\/service"
      } ]
    },
    "geo" : { },
    "id_str" : "292111153302233090",
    "text" : "Thanks for the warm welcome &amp; birthday wishes! Join me &amp; Barack for #MLKDay of Service this Saturday. Sign up: http:\/\/t.co\/yJjvkcLm \u2013mo",
    "id" : 292111153302233090,
    "created_at" : "2013-01-18 03:28:20 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 292112376524845056,
  "created_at" : "2013-01-18 03:33:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 70, 77 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/292096499754622977\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/i5ImJnYL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA28OAzCYAA1Bno.jpg",
      "id_str" : "292096499767205888",
      "id" : 292096499767205888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA28OAzCYAA1Bno.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/i5ImJnYL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/lHAfMVgh",
      "expanded_url" : "http:\/\/on.wh.gov\/nhe7yGL",
      "display_url" : "on.wh.gov\/nhe7yGL"
    } ]
  },
  "geo" : { },
  "id_str" : "292096499754622977",
  "text" : "New behind-the-scenes photos from December: http:\/\/t.co\/lHAfMVgh with @FLOTUS Michelle Obama delivering Toys for Tots: http:\/\/t.co\/i5ImJnYL",
  "id" : 292096499754622977,
  "created_at" : "2013-01-18 02:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowisthetime",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/kIoMrPqV",
      "expanded_url" : "http:\/\/at.wh.gov\/gUGYi",
      "display_url" : "at.wh.gov\/gUGYi"
    } ]
  },
  "geo" : { },
  "id_str" : "292080210323599362",
  "text" : "Grant, age 8, reads the letter he wrote to President Obama after the tragedy in Newtown: http:\/\/t.co\/kIoMrPqV #nowisthetime",
  "id" : 292080210323599362,
  "created_at" : "2013-01-18 01:25:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/292030830077956096\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/dZ73FuZK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BA2AfiLCUAAuME-.jpg",
      "id_str" : "292030830086344704",
      "id" : 292030830086344704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA2AfiLCUAAuME-.jpg",
      "sizes" : [ {
        "h" : 989,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 989,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 989,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dZ73FuZK"
    } ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/v2CBJHMx",
      "expanded_url" : "http:\/\/wh.gov\/now-is-the-time",
      "display_url" : "wh.gov\/now-is-the-time"
    } ]
  },
  "geo" : { },
  "id_str" : "292030830077956096",
  "text" : "RT if you agree: #NowIsTheTime to do something about gun violence: http:\/\/t.co\/v2CBJHMx President Obama's plan: http:\/\/t.co\/dZ73FuZK",
  "id" : 292030830077956096,
  "created_at" : "2013-01-17 22:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/yJjvkcLm",
      "expanded_url" : "http:\/\/www.2013pic.org\/service",
      "display_url" : "2013pic.org\/service"
    } ]
  },
  "geo" : { },
  "id_str" : "292004266246279168",
  "text" : "RT @FLOTUS: The First Lady just met with Inaugural citizen co-chair David Hall ahead of #MLKDay of Service: http:\/\/t.co\/yJjvkcLm http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/291999764973756416\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/E0vxKz73",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BA1kPTpCIAAZ-Ws.jpg",
        "id_str" : "291999764982145024",
        "id" : 291999764982145024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BA1kPTpCIAAZ-Ws.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/E0vxKz73"
      } ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/yJjvkcLm",
        "expanded_url" : "http:\/\/www.2013pic.org\/service",
        "display_url" : "2013pic.org\/service"
      } ]
    },
    "geo" : { },
    "id_str" : "291999764973756416",
    "text" : "The First Lady just met with Inaugural citizen co-chair David Hall ahead of #MLKDay of Service: http:\/\/t.co\/yJjvkcLm http:\/\/t.co\/E0vxKz73",
    "id" : 291999764973756416,
    "created_at" : "2013-01-17 20:05:44 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 292004266246279168,
  "created_at" : "2013-01-17 20:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/uhftw8xM",
      "expanded_url" : "http:\/\/youtu.be\/HvPSfeicWXQ",
      "display_url" : "youtu.be\/HvPSfeicWXQ"
    } ]
  },
  "geo" : { },
  "id_str" : "291985781671727106",
  "text" : "\"There are no words to explain how sad I am about the school shooting\" -Julia, 11, reads her letter to President Obama: http:\/\/t.co\/uhftw8xM",
  "id" : 291985781671727106,
  "created_at" : "2013-01-17 19:10:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 3, 13 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inauguration",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/nsO5pVSX",
      "expanded_url" : "http:\/\/bit.ly\/VMfir7",
      "display_url" : "bit.ly\/VMfir7"
    } ]
  },
  "geo" : { },
  "id_str" : "291979786857885696",
  "text" : "RT @todd_park: Headed to the #inauguration? Come to the Tech Open House at 3PM tomorrow http:\/\/t.co\/nsO5pVSX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inauguration",
        "indices" : [ 14, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/nsO5pVSX",
        "expanded_url" : "http:\/\/bit.ly\/VMfir7",
        "display_url" : "bit.ly\/VMfir7"
      } ]
    },
    "geo" : { },
    "id_str" : "291949828760547328",
    "text" : "Headed to the #inauguration? Come to the Tech Open House at 3PM tomorrow http:\/\/t.co\/nsO5pVSX",
    "id" : 291949828760547328,
    "created_at" : "2013-01-17 16:47:17 +0000",
    "user" : {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "protected" : false,
      "id_str" : "200176600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140157375\/toddpark_normal.jpg",
      "id" : 200176600,
      "verified" : false
    }
  },
  "id" : 291979786857885696,
  "created_at" : "2013-01-17 18:46:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 16, 23 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 41, 49 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291947614130282496",
  "text" : "RT @FLOTUS: The @FLOTUS Office is now on @twitter &amp; will post updates &amp; pics. When it's her, she'll sign -mo. PS: RT to wish Mrs ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 4, 11 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 29, 37 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HappyBirthday",
        "indices" : [ 134, 148 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291946811957051394",
    "text" : "The @FLOTUS Office is now on @twitter &amp; will post updates &amp; pics. When it's her, she'll sign -mo. PS: RT to wish Mrs. Obama a #HappyBirthday",
    "id" : 291946811957051394,
    "created_at" : "2013-01-17 16:35:18 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 291947614130282496,
  "created_at" : "2013-01-17 16:38:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowisthetime",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291922193582002176",
  "text" : "RT @jearnest44: Hartford Courant: POTUS \"might have been cautious...to his everlasting credit, he hasn't been\" #nowisthetime \nhttp:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nowisthetime",
        "indices" : [ 95, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/PBkFM2Ys",
        "expanded_url" : "http:\/\/www.courant.com\/news\/opinion\/editorials\/hc-ed-obama-gun-control-0117-20130116,0,1205849.story",
        "display_url" : "courant.com\/news\/opinion\/e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291919413991587840",
    "text" : "Hartford Courant: POTUS \"might have been cautious...to his everlasting credit, he hasn't been\" #nowisthetime \nhttp:\/\/t.co\/PBkFM2Ys",
    "id" : 291919413991587840,
    "created_at" : "2013-01-17 14:46:26 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 291922193582002176,
  "created_at" : "2013-01-17 14:57:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/291750469339058177\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/0fCJ4Hii",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAyBgZCCEAADRm7.jpg",
      "id_str" : "291750469347446784",
      "id" : 291750469347446784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAyBgZCCEAADRm7.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/0fCJ4Hii"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291750469339058177",
  "text" : "Joined by kids who sent letters after Newtown, the President issued 23 executive actions to reduce gun violence today: http:\/\/t.co\/0fCJ4Hii",
  "id" : 291750469339058177,
  "created_at" : "2013-01-17 03:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/291686778602151936\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Y0YO04QZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAxHlGjCYAEPcXH.jpg",
      "id_str" : "291686778610540545",
      "id" : 291686778610540545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAxHlGjCYAEPcXH.jpg",
      "sizes" : [ {
        "h" : 989,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 989,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 989,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Y0YO04QZ"
    } ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/k7hvZNch",
      "expanded_url" : "http:\/\/wh.gov\/-now-is-the-time",
      "display_url" : "wh.gov\/-now-is-the-ti\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291694427687251969",
  "text" : "RT @VP: RT if you agree: #NowIsTheTime to do something about gun violence: http:\/\/t.co\/k7hvZNch The plan at a glance: http:\/\/t.co\/Y0YO04QZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/291686778602151936\/photo\/1",
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/Y0YO04QZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAxHlGjCYAEPcXH.jpg",
        "id_str" : "291686778610540545",
        "id" : 291686778610540545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAxHlGjCYAEPcXH.jpg",
        "sizes" : [ {
          "h" : 989,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 989,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 989,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Y0YO04QZ"
      } ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 17, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/k7hvZNch",
        "expanded_url" : "http:\/\/wh.gov\/-now-is-the-time",
        "display_url" : "wh.gov\/-now-is-the-ti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "291686778602151936",
    "text" : "RT if you agree: #NowIsTheTime to do something about gun violence: http:\/\/t.co\/k7hvZNch The plan at a glance: http:\/\/t.co\/Y0YO04QZ",
    "id" : 291686778602151936,
    "created_at" : "2013-01-16 23:22:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 291694427687251969,
  "created_at" : "2013-01-16 23:52:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/291675419969720320\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/drXtAp9E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAw9P8WCEAMq-Uz.jpg",
      "id_str" : "291675419978108931",
      "id" : 291675419978108931,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAw9P8WCEAMq-Uz.jpg",
      "sizes" : [ {
        "h" : 1100,
        "resize" : "fit",
        "w" : 713
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 926,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 713
      } ],
      "display_url" : "pic.twitter.com\/drXtAp9E"
    } ],
    "hashtags" : [ {
      "text" : "nowisthetime",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291675419969720320",
  "text" : "This is one of the letters I received after Newtown. When it comes to protecting our kids, #nowisthetime to act. -bo http:\/\/t.co\/drXtAp9E",
  "id" : 291675419969720320,
  "created_at" : "2013-01-16 22:36:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The IACP",
      "screen_name" : "TheIACP",
      "indices" : [ 46, 54 ],
      "id_str" : "44917831",
      "id" : 44917831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/eVb8jli7",
      "expanded_url" : "http:\/\/at.wh.gov\/gSoaZ",
      "display_url" : "at.wh.gov\/gSoaZ"
    } ]
  },
  "geo" : { },
  "id_str" : "291663396422680576",
  "text" : "RT @PressSec: \"Effective, balanced approach\" -@TheIACP Police Chiefs on Obama's plan to reduce gun violence: http:\/\/t.co\/eVb8jli7 #NowIs ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The IACP",
        "screen_name" : "TheIACP",
        "indices" : [ 32, 40 ],
        "id_str" : "44917831",
        "id" : 44917831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 116, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/eVb8jli7",
        "expanded_url" : "http:\/\/at.wh.gov\/gSoaZ",
        "display_url" : "at.wh.gov\/gSoaZ"
      } ]
    },
    "geo" : { },
    "id_str" : "291663246576975873",
    "text" : "\"Effective, balanced approach\" -@TheIACP Police Chiefs on Obama's plan to reduce gun violence: http:\/\/t.co\/eVb8jli7 #NowIsTheTime",
    "id" : 291663246576975873,
    "created_at" : "2013-01-16 21:48:31 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 291663396422680576,
  "created_at" : "2013-01-16 21:49:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 29, 32 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/zJWpPBdA",
      "expanded_url" : "http:\/\/at.wh.gov\/gS9ZH",
      "display_url" : "at.wh.gov\/gS9ZH"
    }, {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/v2CBJHMx",
      "expanded_url" : "http:\/\/wh.gov\/now-is-the-time",
      "display_url" : "wh.gov\/now-is-the-time"
    } ]
  },
  "geo" : { },
  "id_str" : "291632105446842368",
  "text" : "Video: President Obama &amp; @VP Biden announce their plan to reduce gun violence: http:\/\/t.co\/zJWpPBdA http:\/\/t.co\/v2CBJHMx #NowIsTheTime",
  "id" : 291632105446842368,
  "created_at" : "2013-01-16 19:44:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chprpipr",
      "screen_name" : "chprpipr",
      "indices" : [ 3, 12 ],
      "id_str" : "14110120",
      "id" : 14110120
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 14, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/I5fWpik0",
      "expanded_url" : "http:\/\/Wh.gov\/nowisthetime",
      "display_url" : "Wh.gov\/nowisthetime"
    } ]
  },
  "geo" : { },
  "id_str" : "291616889824743424",
  "text" : "RT @chprpipr: #NowIsTheTime to require background checks for all gun sales http:\/\/t.co\/I5fWpik0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/I5fWpik0",
        "expanded_url" : "http:\/\/Wh.gov\/nowisthetime",
        "display_url" : "Wh.gov\/nowisthetime"
      } ]
    },
    "geo" : { },
    "id_str" : "291616644751577088",
    "text" : "#NowIsTheTime to require background checks for all gun sales http:\/\/t.co\/I5fWpik0",
    "id" : 291616644751577088,
    "created_at" : "2013-01-16 18:43:20 +0000",
    "user" : {
      "name" : "chprpipr",
      "screen_name" : "chprpipr",
      "protected" : false,
      "id_str" : "14110120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739297589078556673\/On0yoJZR_normal.jpg",
      "id" : 14110120,
      "verified" : false
    }
  },
  "id" : 291616889824743424,
  "created_at" : "2013-01-16 18:44:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cameron glenn",
      "screen_name" : "jetsjets",
      "indices" : [ 3, 12 ],
      "id_str" : "46133399",
      "id" : 46133399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 14, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291616239971885056",
  "text" : "RT @jetsjets: #NowIsTheTime to work together to reduce gun violence. RT if you agree",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291615341405167617",
    "text" : "#NowIsTheTime to work together to reduce gun violence. RT if you agree",
    "id" : 291615341405167617,
    "created_at" : "2013-01-16 18:38:10 +0000",
    "user" : {
      "name" : "cameron glenn",
      "screen_name" : "jetsjets",
      "protected" : false,
      "id_str" : "46133399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1629029197\/bocce_ball_normal.jpg",
      "id" : 46133399,
      "verified" : false
    }
  },
  "id" : 291616239971885056,
  "created_at" : "2013-01-16 18:41:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Allegrucci",
      "screen_name" : "allegrooch",
      "indices" : [ 3, 14 ],
      "id_str" : "27328702",
      "id" : 27328702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291611110178684929",
  "text" : "RT @allegrooch: I had 2 get fingerprinted &amp; background checkd 2 run a school arts program. But not 2 purchase firearms. Our kids R w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 129, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291610290758496256",
    "text" : "I had 2 get fingerprinted &amp; background checkd 2 run a school arts program. But not 2 purchase firearms. Our kids R worth it. #NowIsTheTime",
    "id" : 291610290758496256,
    "created_at" : "2013-01-16 18:18:05 +0000",
    "user" : {
      "name" : "Scott Allegrucci",
      "screen_name" : "allegrooch",
      "protected" : false,
      "id_str" : "27328702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769923685318742020\/CE8tNOGI_normal.jpg",
      "id" : 27328702,
      "verified" : false
    }
  },
  "id" : 291611110178684929,
  "created_at" : "2013-01-16 18:21:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291609494998355968",
  "text" : "RT @VP: Today, the President &amp; I put forth a plan to protect our nation's kids. #NowIsTheTime to get it done. Read our plan http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 76, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/0ItNTVIP",
        "expanded_url" : "http:\/\/wh.gov\/now-is-the-time",
        "display_url" : "wh.gov\/now-is-the-time"
      } ]
    },
    "geo" : { },
    "id_str" : "291602326517608448",
    "text" : "Today, the President &amp; I put forth a plan to protect our nation's kids. #NowIsTheTime to get it done. Read our plan http:\/\/t.co\/0ItNTVIP -VP",
    "id" : 291602326517608448,
    "created_at" : "2013-01-16 17:46:27 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 291609494998355968,
  "created_at" : "2013-01-16 18:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie",
      "screen_name" : "jjulesjenks",
      "indices" : [ 3, 15 ],
      "id_str" : "26102060",
      "id" : 26102060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291607087887286272",
  "text" : "RT @jjulesjenks: I had to get a background check to volunteer in my daughters' school. I support requiring background check for gun purc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291595311841935360",
    "text" : "I had to get a background check to volunteer in my daughters' school. I support requiring background check for gun purchases. #NowIsTheTime",
    "id" : 291595311841935360,
    "created_at" : "2013-01-16 17:18:34 +0000",
    "user" : {
      "name" : "Julie",
      "screen_name" : "jjulesjenks",
      "protected" : false,
      "id_str" : "26102060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2511089910\/fbfxt99w66l1o5r9t3wn_normal.jpeg",
      "id" : 26102060,
      "verified" : false
    }
  },
  "id" : 291607087887286272,
  "created_at" : "2013-01-16 18:05:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/v2CBJHMx",
      "expanded_url" : "http:\/\/wh.gov\/now-is-the-time",
      "display_url" : "wh.gov\/now-is-the-time"
    } ]
  },
  "geo" : { },
  "id_str" : "291602016717922305",
  "text" : "#NowIsTheTime to protect our children &amp; our communities by reducing gun violence. Read the President's plan: http:\/\/t.co\/v2CBJHMx",
  "id" : 291602016717922305,
  "created_at" : "2013-01-16 17:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291594848455241728",
  "text" : "\"Let\u2019s do the right thing for them, and for this country we love so much.\" \u2014President Obama",
  "id" : 291594848455241728,
  "created_at" : "2013-01-16 17:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291594013042147329",
  "text" : "\"The most important changes we can make depend on action from Congress. They need to bring these proposals up for a vote.\" \u2014President Obama",
  "id" : 291594013042147329,
  "created_at" : "2013-01-16 17:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291593315705577473",
  "text" : "\"The only way we can change is if the American people demand it.\" \u2014President Obama",
  "id" : 291593315705577473,
  "created_at" : "2013-01-16 17:10:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291592890176643072",
  "text" : "RT @WHLive: President Obama: \"Let me be absolutely clear: like most Americans, I believe the 2nd Amendment guarantees an individual righ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291592544746364928",
    "text" : "President Obama: \"Let me be absolutely clear: like most Americans, I believe the 2nd Amendment guarantees an individual right to bear arms.\"",
    "id" : 291592544746364928,
    "created_at" : "2013-01-16 17:07:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 291592890176643072,
  "created_at" : "2013-01-16 17:08:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291592472239407105",
  "text" : "RT @WHLive: President Obama: \"Finally, Congress needs to help, rather than hinder, law enforcement as it does its job.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291592316446199808",
    "text" : "President Obama: \"Finally, Congress needs to help, rather than hinder, law enforcement as it does its job.\"",
    "id" : 291592316446199808,
    "created_at" : "2013-01-16 17:06:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 291592472239407105,
  "created_at" : "2013-01-16 17:07:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291592317595447296",
  "text" : "RT @WHLive: President Obama: \"Second: Congress should restore a ban on military-style assault weapons, and a 10-round limit for magazines.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291591982340517890",
    "text" : "President Obama: \"Second: Congress should restore a ban on military-style assault weapons, and a 10-round limit for magazines.\"",
    "id" : 291591982340517890,
    "created_at" : "2013-01-16 17:05:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 291592317595447296,
  "created_at" : "2013-01-16 17:06:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291592156345401347",
  "text" : "RT @WHLive: President Obama: \"First: it\u2019s time for Congress to require a universal background check for anyone trying to buy a gun.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291591649493139456",
    "text" : "President Obama: \"First: it\u2019s time for Congress to require a universal background check for anyone trying to buy a gun.\"",
    "id" : 291591649493139456,
    "created_at" : "2013-01-16 17:04:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 291592156345401347,
  "created_at" : "2013-01-16 17:06:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291591386099220480",
  "text" : "\"If there is even one thing we can do to reduce this violence, if even one life can be saved, we have an obligation to try\" \u2014President Obama",
  "id" : 291591386099220480,
  "created_at" : "2013-01-16 17:02:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291590374437306369",
  "text" : "President Obama: \"While reducing gun violence is a complicated challenge, protecting our children from harm shouldn\u2019t be a divisive one.\"",
  "id" : 291590374437306369,
  "created_at" : "2013-01-16 16:58:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291589707228401665",
  "text" : "RT @VP: Vice President Biden: \"We should do as much as we can, as quickly as we can. And we cannot make the perfect the enemy of the good.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291589647694438400",
    "text" : "Vice President Biden: \"We should do as much as we can, as quickly as we can. And we cannot make the perfect the enemy of the good.\"",
    "id" : 291589647694438400,
    "created_at" : "2013-01-16 16:56:04 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 291589707228401665,
  "created_at" : "2013-01-16 16:56:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291588990040154112",
  "text" : "RT @VP: Vice President: \"You show incredible courage being here &amp; the President &amp; I are going to do our best to honor the memory ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291588887489433601",
    "text" : "Vice President: \"You show incredible courage being here &amp; the President &amp; I are going to do our best to honor the memory of your children\"",
    "id" : 291588887489433601,
    "created_at" : "2013-01-16 16:53:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 291588990040154112,
  "created_at" : "2013-01-16 16:53:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291588951746166784",
  "text" : "RT @VP: Vice President Biden: \"Before I begin, let me say, for the parents of the innocents who were murdered 33 days ago, my heart goes ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "291588689409232896",
    "text" : "Vice President Biden: \"Before I begin, let me say, for the parents of the innocents who were murdered 33 days ago, my heart goes out to you\"",
    "id" : 291588689409232896,
    "created_at" : "2013-01-16 16:52:15 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 291588951746166784,
  "created_at" : "2013-01-16 16:53:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 37, 40 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/UJM4AdEo",
      "expanded_url" : "http:\/\/at.wh.gov\/gRO4m",
      "display_url" : "at.wh.gov\/gRO4m"
    } ]
  },
  "geo" : { },
  "id_str" : "291588435452497920",
  "text" : "Happening now: President Obama &amp; @VP Biden announce proposals to reduce gun violence: http:\/\/t.co\/UJM4AdEo",
  "id" : 291588435452497920,
  "created_at" : "2013-01-16 16:51:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 45, 48 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/291572108721537025\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/YncVLCmj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAvfSb-CQAEyz64.jpg",
      "id_str" : "291572108734119937",
      "id" : 291572108734119937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAvfSb-CQAEyz64.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/YncVLCmj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/0GcbnXj6",
      "expanded_url" : "http:\/\/on.wh.gov\/SZ4hH7w",
      "display_url" : "on.wh.gov\/SZ4hH7w"
    } ]
  },
  "geo" : { },
  "id_str" : "291572108721537025",
  "text" : "Watch live at 11:55ET: President Obama &amp; @VP Biden announce proposals to reduce gun violence: http:\/\/t.co\/0GcbnXj6 http:\/\/t.co\/YncVLCmj",
  "id" : 291572108721537025,
  "created_at" : "2013-01-16 15:46:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/291395778767900672\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/w5xFwJkl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAs-6rsCUAATSbt.jpg",
      "id_str" : "291395778776289280",
      "id" : 291395778776289280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAs-6rsCUAATSbt.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/w5xFwJkl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291395778767900672",
  "text" : "Photo of the Day: President Obama talks with Kathryn Ruemmler, Counsel to the President, in the Outer Oval Office: http:\/\/t.co\/w5xFwJkl",
  "id" : 291395778767900672,
  "created_at" : "2013-01-16 04:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 32, 35 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291290691416518656",
  "text" : "Tomorrow, President Obama &amp; @VP Biden will unveil a package of proposals to reduce gun violence &amp; prevent future tragedies like Newtown.",
  "id" : 291290691416518656,
  "created_at" : "2013-01-15 21:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "DOS Careers",
      "screen_name" : "doscareers",
      "indices" : [ 81, 92 ],
      "id_str" : "21915158",
      "id" : 21915158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/kKKXRXtn",
      "expanded_url" : "http:\/\/youtu.be\/e-tkNw0G6xc",
      "display_url" : "youtu.be\/e-tkNw0G6xc"
    } ]
  },
  "geo" : { },
  "id_str" : "291255621716680706",
  "text" : "RT @StateDept: Interested in joining the Foreign Service? Watch a new video from @doscareers to learn about the job. http:\/\/t.co\/kKKXRXtn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DOS Careers",
        "screen_name" : "doscareers",
        "indices" : [ 66, 77 ],
        "id_str" : "21915158",
        "id" : 21915158
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/kKKXRXtn",
        "expanded_url" : "http:\/\/youtu.be\/e-tkNw0G6xc",
        "display_url" : "youtu.be\/e-tkNw0G6xc"
      } ]
    },
    "geo" : { },
    "id_str" : "290106915709673472",
    "text" : "Interested in joining the Foreign Service? Watch a new video from @doscareers to learn about the job. http:\/\/t.co\/kKKXRXtn",
    "id" : 290106915709673472,
    "created_at" : "2013-01-12 14:44:13 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 291255621716680706,
  "created_at" : "2013-01-15 18:48:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLK",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/6vNB9FV2",
      "expanded_url" : "http:\/\/at.wh.gov\/gPK9Q",
      "display_url" : "at.wh.gov\/gPK9Q"
    } ]
  },
  "geo" : { },
  "id_str" : "291231599129931776",
  "text" : "On Jan 19, join President Obama in a National Day of Service to honor the legacy of Dr. Martin Luther King, Jr: http:\/\/t.co\/6vNB9FV2 #MLK",
  "id" : 291231599129931776,
  "created_at" : "2013-01-15 17:13:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 40, 43 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/291199178820947968\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/qOFHnPlI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAqMHD0CEAAYZ3T.jpg",
      "id_str" : "291199178829336576",
      "id" : 291199178829336576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAqMHD0CEAAYZ3T.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qOFHnPlI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291199178820947968",
  "text" : "Photo of the Day: President Obama &amp; @VP Biden hold a policy meeting in the Cabinet Room of the White House: http:\/\/t.co\/qOFHnPlI",
  "id" : 291199178820947968,
  "created_at" : "2013-01-15 15:04:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Obama Inauguration",
      "screen_name" : "obamainaugural",
      "indices" : [ 3, 18 ],
      "id_str" : "18177016",
      "id" : 18177016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inaug2013",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290965320385036288",
  "text" : "RT @obamainaugural: Looking to stay connected to everything happening during #inaug2013? All you need is your smartphone: http:\/\/t.co\/3k ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "inaug2013",
        "indices" : [ 57, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/3kIJ1U5M",
        "expanded_url" : "http:\/\/bit.ly\/VVZ9Px",
        "display_url" : "bit.ly\/VVZ9Px"
      } ]
    },
    "geo" : { },
    "id_str" : "290826226904465408",
    "text" : "Looking to stay connected to everything happening during #inaug2013? All you need is your smartphone: http:\/\/t.co\/3kIJ1U5M",
    "id" : 290826226904465408,
    "created_at" : "2013-01-14 14:22:30 +0000",
    "user" : {
      "name" : "Obama Inauguration",
      "screen_name" : "obamainaugural",
      "protected" : false,
      "id_str" : "18177016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2940082541\/ec2971fdd745e0fe674e4b415e312280_normal.jpeg",
      "id" : 18177016,
      "verified" : true
    }
  },
  "id" : 290965320385036288,
  "created_at" : "2013-01-14 23:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debtceiling",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/0OUarP3G",
      "expanded_url" : "http:\/\/at.wh.gov\/gO2ss",
      "display_url" : "at.wh.gov\/gO2ss"
    } ]
  },
  "geo" : { },
  "id_str" : "290920327872135168",
  "text" : "In today's press conference, President Obama addressed the #debtceiling, and gun violence prevention policies. Watch: http:\/\/t.co\/0OUarP3G",
  "id" : 290920327872135168,
  "created_at" : "2013-01-14 20:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290909959686877184",
  "text" : "RT @VP: VP meets with House members &amp; Cabinet officials today at the WH to discuss efforts to curb gun violence. (WH Photo) http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/290908017422127104\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/xNHnO2XL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BAmDTPECUAAq33Z.jpg",
        "id_str" : "290908017426321408",
        "id" : 290908017426321408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAmDTPECUAAq33Z.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/xNHnO2XL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290908017422127104",
    "text" : "VP meets with House members &amp; Cabinet officials today at the WH to discuss efforts to curb gun violence. (WH Photo) http:\/\/t.co\/xNHnO2XL",
    "id" : 290908017422127104,
    "created_at" : "2013-01-14 19:47:31 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 290909959686877184,
  "created_at" : "2013-01-14 19:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290888694137753600",
  "text" : "RT @PressSec: POTUS: \"The financial wellbeing of the American people is not leverage to be used.\" Threatening U.S. default \"is not a bar ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290882400056115200",
    "text" : "POTUS: \"The financial wellbeing of the American people is not leverage to be used.\" Threatening U.S. default \"is not a bargaining chip.\"",
    "id" : 290882400056115200,
    "created_at" : "2013-01-14 18:05:43 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 290888694137753600,
  "created_at" : "2013-01-14 18:30:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290863131712974848",
  "text" : "\"Let\u2019s give our businesses and the world the certainty that our economy and our reputation are still second to none.\" \u2014President Obama",
  "id" : 290863131712974848,
  "created_at" : "2013-01-14 16:49:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290862557340778496",
  "text" : "RT @WHLive: President Obama: \"Republicans in Congress have 2 choices here. They can act responsibly &amp; pay their bills. Or they can a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290862387387592704",
    "text" : "President Obama: \"Republicans in Congress have 2 choices here. They can act responsibly &amp; pay their bills. Or they can act irresponsibly.\"",
    "id" : 290862387387592704,
    "created_at" : "2013-01-14 16:46:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 290862557340778496,
  "created_at" : "2013-01-14 16:46:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290862050845016065",
  "text" : "RT @WHLive: President Obama: \"[Raising the debt ceiling] simply allows the country to pay for spending that Congress has already committ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290861885732057090",
    "text" : "President Obama: \"[Raising the debt ceiling] simply allows the country to pay for spending that Congress has already committed to.\"",
    "id" : 290861885732057090,
    "created_at" : "2013-01-14 16:44:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 290862050845016065,
  "created_at" : "2013-01-14 16:44:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290862024492191744",
  "text" : "RT @WHLive: President Obama: \"I want to be clear about this...raising the debt ceiling doesn\u2019t authorize more spending.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290861848130105344",
    "text" : "President Obama: \"I want to be clear about this...raising the debt ceiling doesn\u2019t authorize more spending.\"",
    "id" : 290861848130105344,
    "created_at" : "2013-01-14 16:44:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 290862024492191744,
  "created_at" : "2013-01-14 16:44:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290861293689245696",
  "text" : "RT @WHLive: President Obama: \"The fact is, though, we can\u2019t finish the job of deficit reduction through spending cuts alone.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290861228476219392",
    "text" : "President Obama: \"The fact is, though, we can\u2019t finish the job of deficit reduction through spending cuts alone.\"",
    "id" : 290861228476219392,
    "created_at" : "2013-01-14 16:41:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 290861293689245696,
  "created_at" : "2013-01-14 16:41:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290860714061611008",
  "text" : "RT @WHLive: President Obama: \"It\u2019s been a busy and productive four years. And I expect the same of the next four.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "290860615642251264",
    "text" : "President Obama: \"It\u2019s been a busy and productive four years. And I expect the same of the next four.\"",
    "id" : 290860615642251264,
    "created_at" : "2013-01-14 16:39:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 290860714061611008,
  "created_at" : "2013-01-14 16:39:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "290859865981743104",
  "text" : "Starting now: President Obama holds a press conference live from the East Room. Watch: http:\/\/t.co\/u95tzH8r",
  "id" : 290859865981743104,
  "created_at" : "2013-01-14 16:36:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "290828189729710080",
  "text" : "Today, President Obama will hold the last press conference of his first term in the East Room. Watch live at 11:15 ET: http:\/\/t.co\/u95tzH8r",
  "id" : 290828189729710080,
  "created_at" : "2013-01-14 14:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/csOmUhVQ",
      "expanded_url" : "http:\/\/at.wh.gov\/gL3I7",
      "display_url" : "at.wh.gov\/gL3I7"
    } ]
  },
  "geo" : { },
  "id_str" : "290231722715537409",
  "text" : "President Obama: \"By the end of next year, America\u2019s war in Afghanistan will be over.\" Watch the Weekly Address: http:\/\/t.co\/csOmUhVQ",
  "id" : 290231722715537409,
  "created_at" : "2013-01-12 23:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/290206310329360386\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/Z5BL7qWW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAcFGgdCIAAfMC-.jpg",
      "id_str" : "290206310337748992",
      "id" : 290206310337748992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAcFGgdCIAAfMC-.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Z5BL7qWW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290206310329360386",
  "text" : "Photo of the Day: President Obama &amp; Ambassador Capricia Marshall wave to President Karzai as he departs the White House http:\/\/t.co\/Z5BL7qWW",
  "id" : 290206310329360386,
  "created_at" : "2013-01-12 21:19:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 104 ],
      "url" : "https:\/\/t.co\/GPW1u2nH",
      "expanded_url" : "https:\/\/petitions.whitehouse.gov\/response\/isnt-petition-response-youre-looking",
      "display_url" : "petitions.whitehouse.gov\/response\/isnt-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290155898570166272",
  "text" : "RT @wethepeople: New Response: This Isn't the Petition Response You're Looking For https:\/\/t.co\/GPW1u2nH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 87 ],
        "url" : "https:\/\/t.co\/GPW1u2nH",
        "expanded_url" : "https:\/\/petitions.whitehouse.gov\/response\/isnt-petition-response-youre-looking",
        "display_url" : "petitions.whitehouse.gov\/response\/isnt-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "289902925361328129",
    "text" : "New Response: This Isn't the Petition Response You're Looking For https:\/\/t.co\/GPW1u2nH",
    "id" : 289902925361328129,
    "created_at" : "2013-01-12 01:13:38 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 290155898570166272,
  "created_at" : "2013-01-12 17:58:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/gqb96ZYB",
      "expanded_url" : "http:\/\/on.wh.gov\/tEyFB05",
      "display_url" : "on.wh.gov\/tEyFB05"
    } ]
  },
  "geo" : { },
  "id_str" : "290110961489166336",
  "text" : "In this week's address, President Obama discusses how we will end the war in Afghanistan &amp; focus on rebuilding America: http:\/\/t.co\/gqb96ZYB",
  "id" : 290110961489166336,
  "created_at" : "2013-01-12 15:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/289899533389950976\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/1CZbK4Hn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAXuFvTCcAAZK0O.jpg",
      "id_str" : "289899533398339584",
      "id" : 289899533398339584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAXuFvTCcAAZK0O.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1CZbK4Hn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289899533389950976",
  "text" : "Photo of the Day: President Obama talks with advisors after a meeting in the Roosevelt Room, Jan. 10, 2013: http:\/\/t.co\/1CZbK4Hn",
  "id" : 289899533389950976,
  "created_at" : "2013-01-12 01:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/vMw1jEXU",
      "expanded_url" : "http:\/\/at.wh.gov\/gKjym",
      "display_url" : "at.wh.gov\/gKjym"
    } ]
  },
  "geo" : { },
  "id_str" : "289863782010867712",
  "text" : "Today, President Obama held a joint press conference with President Karzai of Afghanistan. Watch: http:\/\/t.co\/vMw1jEXU",
  "id" : 289863782010867712,
  "created_at" : "2013-01-11 22:38:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 21, 24 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Jh8SXAnE",
      "expanded_url" : "http:\/\/at.wh.gov\/gKa6p",
      "display_url" : "at.wh.gov\/gKa6p"
    } ]
  },
  "geo" : { },
  "id_str" : "289838850807836674",
  "text" : "This week at the WH: @VP held meetings on reducing gun violence &amp; President Obama nominated new Cabinet members: http:\/\/t.co\/Jh8SXAnE",
  "id" : 289838850807836674,
  "created_at" : "2013-01-11 20:59:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/xAK6wBe9",
      "expanded_url" : "http:\/\/at.wh.gov\/gJQZ1",
      "display_url" : "at.wh.gov\/gJQZ1"
    } ]
  },
  "geo" : { },
  "id_str" : "289803300755349504",
  "text" : "Starting now: President Obama &amp; President Karzai of Afghanistan hold a join press conference. Watch live: http:\/\/t.co\/xAK6wBe9",
  "id" : 289803300755349504,
  "created_at" : "2013-01-11 18:37:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/Mvldzief",
      "expanded_url" : "http:\/\/at.wh.gov\/gJH4B",
      "display_url" : "at.wh.gov\/gJH4B"
    } ]
  },
  "geo" : { },
  "id_str" : "289781079278243842",
  "text" : "Happening at 1:15 ET: President Obama &amp; President Karzai of Afghanistan hold a joint press conference. Watch live: http:\/\/t.co\/Mvldzief",
  "id" : 289781079278243842,
  "created_at" : "2013-01-11 17:09:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 16, 21 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/N1HSDeKb",
      "expanded_url" : "http:\/\/at.wh.gov\/gIjJ0",
      "display_url" : "at.wh.gov\/gIjJ0"
    } ]
  },
  "geo" : { },
  "id_str" : "289542175446941697",
  "text" : "A new rule from @CFPB will make sure that lenders offer mortgages that consumers can actually afford to pay back: http:\/\/t.co\/N1HSDeKb",
  "id" : 289542175446941697,
  "created_at" : "2013-01-11 01:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/3C87QBQZ",
      "expanded_url" : "http:\/\/bit.ly\/UD2UpB",
      "display_url" : "bit.ly\/UD2UpB"
    } ]
  },
  "geo" : { },
  "id_str" : "289521673970020353",
  "text" : "RT @petesouza: Photo of Daniel Day-Lewis viewing Gettysburg Address at WH in Nov: http:\/\/t.co\/3C87QBQZ Congrats to him for his Oscar nom ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/3C87QBQZ",
        "expanded_url" : "http:\/\/bit.ly\/UD2UpB",
        "display_url" : "bit.ly\/UD2UpB"
      } ]
    },
    "geo" : { },
    "id_str" : "289432841429843968",
    "text" : "Photo of Daniel Day-Lewis viewing Gettysburg Address at WH in Nov: http:\/\/t.co\/3C87QBQZ Congrats to him for his Oscar nomination today",
    "id" : 289432841429843968,
    "created_at" : "2013-01-10 18:05:41 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 289521673970020353,
  "created_at" : "2013-01-10 23:58:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289485505115082752",
  "text" : "RT @VP: PHOTO: VP met with gun owner groups today at the White House to discuss efforts to curb gun violence. (WH Photo) http:\/\/t.co\/R5f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/289482035184148480\/photo\/1",
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/R5fJsliB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BARyYJRCIAAJ7z7.jpg",
        "id_str" : "289482035188342784",
        "id" : 289482035188342784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BARyYJRCIAAJ7z7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/R5fJsliB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "289482035184148480",
    "text" : "PHOTO: VP met with gun owner groups today at the White House to discuss efforts to curb gun violence. (WH Photo) http:\/\/t.co\/R5fJsliB",
    "id" : 289482035184148480,
    "created_at" : "2013-01-10 21:21:10 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 289485505115082752,
  "created_at" : "2013-01-10 21:34:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/cqk5wSfO",
      "expanded_url" : "http:\/\/at.wh.gov\/gI6mE",
      "display_url" : "at.wh.gov\/gI6mE"
    } ]
  },
  "geo" : { },
  "id_str" : "289474013187682306",
  "text" : "Today, President Obama nominated Jack Lew for Secretary of the Treasury. Watch: http:\/\/t.co\/cqk5wSfO",
  "id" : 289474013187682306,
  "created_at" : "2013-01-10 20:49:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "289441522716377088",
  "text" : "Happening now: President Obama nominates Jack Lew for Secretary of the Treasury. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 289441522716377088,
  "created_at" : "2013-01-10 18:40:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/s8hchuu9",
      "expanded_url" : "http:\/\/at.wh.gov\/gHlmj",
      "display_url" : "at.wh.gov\/gHlmj"
    } ]
  },
  "geo" : { },
  "id_str" : "289386466411413505",
  "text" : "Happening at 1:30 ET: President Obama makes a personnel announcement from the White House. Watch live: http:\/\/t.co\/s8hchuu9",
  "id" : 289386466411413505,
  "created_at" : "2013-01-10 15:01:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 18, 21 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/289363499736506369\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/Sv7WLAKM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAQGkeVCIAAOhIT.jpg",
      "id_str" : "289363499744894976",
      "id" : 289363499744894976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAQGkeVCIAAOhIT.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Sv7WLAKM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289363499736506369",
  "text" : "Photo of the Day: @VP Biden meets with victims' groups &amp; gun safety orgs in response to the tragedy in Newtown, CT: http:\/\/t.co\/Sv7WLAKM",
  "id" : 289363499736506369,
  "created_at" : "2013-01-10 13:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/289186070606802945\/photo\/1",
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/pnSsGSub",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BANlMvUCcAA8kmB.jpg",
      "id_str" : "289186070615191552",
      "id" : 289186070615191552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BANlMvUCcAA8kmB.jpg",
      "sizes" : [ {
        "h" : 650,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 976
      } ],
      "display_url" : "pic.twitter.com\/pnSsGSub"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/SALuUt9V",
      "expanded_url" : "http:\/\/on.wh.gov\/8nheMgJ",
      "display_url" : "on.wh.gov\/8nheMgJ"
    } ]
  },
  "geo" : { },
  "id_str" : "289186070606802945",
  "text" : "2012 in Photos: http:\/\/t.co\/SALuUt9V Pic: The President &amp; First Lady smooch for the \"Kiss Cam\" at a basketball game: http:\/\/t.co\/pnSsGSub",
  "id" : 289186070606802945,
  "created_at" : "2013-01-10 01:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "indices" : [ 3, 10 ],
      "id_str" : "17001730",
      "id" : 17001730
    }, {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "indices" : [ 91, 98 ],
      "id_str" : "17001730",
      "id" : 17001730
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "dayofservice",
      "indices" : [ 38, 51 ]
    }, {
      "text" : "volunteer",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/q6hLe387",
      "expanded_url" : "http:\/\/mlkday.gov",
      "display_url" : "mlkday.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "289139500112822273",
  "text" : "RT @MLKDay: Did you know #MLKDay is a #dayofservice? Learn more about how to #volunteer w\/ @MLKDay at http:\/\/t.co\/q6hLe387.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MLK Day",
        "screen_name" : "MLKDay",
        "indices" : [ 79, 86 ],
        "id_str" : "17001730",
        "id" : 17001730
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 13, 20 ]
      }, {
        "text" : "dayofservice",
        "indices" : [ 26, 39 ]
      }, {
        "text" : "volunteer",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/q6hLe387",
        "expanded_url" : "http:\/\/mlkday.gov",
        "display_url" : "mlkday.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "286842435919814656",
    "text" : "Did you know #MLKDay is a #dayofservice? Learn more about how to #volunteer w\/ @MLKDay at http:\/\/t.co\/q6hLe387.",
    "id" : 286842435919814656,
    "created_at" : "2013-01-03 14:32:20 +0000",
    "user" : {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "protected" : false,
      "id_str" : "17001730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556146916442902528\/Cu6dRDjT_normal.jpeg",
      "id" : 17001730,
      "verified" : false
    }
  },
  "id" : 289139500112822273,
  "created_at" : "2013-01-09 22:40:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/289068788433944576\/photo\/1",
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/8QTihZq8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAL6iBLCAAAvKal.jpg",
      "id_str" : "289068788442333184",
      "id" : 289068788442333184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAL6iBLCAAAvKal.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8QTihZq8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289068788433944576",
  "text" : "Photo of the day: President Obama meets with senior advisors in the Oval Office, Jan. 8, 2013: http:\/\/t.co\/8QTihZq8",
  "id" : 289068788433944576,
  "created_at" : "2013-01-09 17:59:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Bears",
      "screen_name" : "ChicagoBears",
      "indices" : [ 104, 117 ],
      "id_str" : "47964412",
      "id" : 47964412
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/288797251235639297\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/70YiSACb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAIDkeRCcAEPxGv.jpg",
      "id_str" : "288797251239833601",
      "id" : 288797251239833601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAIDkeRCcAEPxGv.jpg",
      "sizes" : [ {
        "h" : 650,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 976
      } ],
      "display_url" : "pic.twitter.com\/70YiSACb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/5W4BYAC7",
      "expanded_url" : "http:\/\/on.wh.gov\/KcDyV2h",
      "display_url" : "on.wh.gov\/KcDyV2h"
    } ]
  },
  "geo" : { },
  "id_str" : "288797251235639297",
  "text" : "2012 in Photos: http:\/\/t.co\/5W4BYAC7 Pic: The President throws a football at Soldier Field, home of the @ChicagoBears: http:\/\/t.co\/70YiSACb",
  "id" : 288797251235639297,
  "created_at" : "2013-01-09 00:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/Ni0KdVUL",
      "expanded_url" : "http:\/\/at.wh.gov\/gEcyH",
      "display_url" : "at.wh.gov\/gEcyH"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/bx3wciQU",
      "expanded_url" : "http:\/\/at.wh.gov\/gEcxd",
      "display_url" : "at.wh.gov\/gEcxd"
    } ]
  },
  "geo" : { },
  "id_str" : "288765131788255235",
  "text" : "Happy Birthday, Stephen Hawking: http:\/\/t.co\/Ni0KdVUL Check out a never-before-seen video from his visit to the WH: http:\/\/t.co\/bx3wciQU",
  "id" : 288765131788255235,
  "created_at" : "2013-01-08 21:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/288629382686322689\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/EpztY94j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BAFq5PNCMAE1YPO.jpg",
      "id_str" : "288629382694711297",
      "id" : 288629382694711297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BAFq5PNCMAE1YPO.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EpztY94j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288629382686322689",
  "text" : "Photo of the Day: President Obama shakes hands with Chuck Hagel, nominee for Secretary of Defense, in the East Room: http:\/\/t.co\/EpztY94j",
  "id" : 288629382686322689,
  "created_at" : "2013-01-08 12:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/288443428977647616\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/0NdJPRKU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BADBxTqCIAAAZiU.jpg",
      "id_str" : "288443428986036224",
      "id" : 288443428986036224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BADBxTqCIAAAZiU.jpg",
      "sizes" : [ {
        "h" : 650,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 976
      } ],
      "display_url" : "pic.twitter.com\/0NdJPRKU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/uQQpAupc",
      "expanded_url" : "http:\/\/on.wh.gov\/Rgaob87",
      "display_url" : "on.wh.gov\/Rgaob87"
    } ]
  },
  "geo" : { },
  "id_str" : "288443428977647616",
  "text" : "\"Anyone want to try a piece of my strawberry pie?\"-President Obama. More from 2012 in Photos: http:\/\/t.co\/uQQpAupc http:\/\/t.co\/0NdJPRKU",
  "id" : 288443428977647616,
  "created_at" : "2013-01-08 00:34:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/KiRlBlRA",
      "expanded_url" : "http:\/\/at.wh.gov\/gC9Gg",
      "display_url" : "at.wh.gov\/gC9Gg"
    } ]
  },
  "geo" : { },
  "id_str" : "288402082673860609",
  "text" : "Today, President Obama nominated Chuck Hagel for Secretary of Defense &amp; John Brennan for Director of the CIA. Watch: http:\/\/t.co\/KiRlBlRA",
  "id" : 288402082673860609,
  "created_at" : "2013-01-07 21:49:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/ji1N9XFz",
      "expanded_url" : "http:\/\/at.wh.gov\/gC3K8",
      "display_url" : "at.wh.gov\/gC3K8"
    } ]
  },
  "geo" : { },
  "id_str" : "288390226416660482",
  "text" : "On Jan 19, join President Obama in a National Day of Service to honor the legacy of Dr. Martin Luther King, Jr: http:\/\/t.co\/ji1N9XFz #MLKDay",
  "id" : 288390226416660482,
  "created_at" : "2013-01-07 21:02:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288349635674791937",
  "text" : "President Obama: \"When it comes to the defense of our country, we\u2019re not Democrats or Republicans. We\u2019re Americans.\"",
  "id" : 288349635674791937,
  "created_at" : "2013-01-07 18:21:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "288348650017550338",
  "text" : "President Obama nominates Chuck Hagel for Secretary of Defense &amp; John Brennan for Director of the CIA. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 288348650017550338,
  "created_at" : "2013-01-07 18:17:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288348514969346049",
  "text" : "President Obama: \"To help meet the challenges of our time, I\u2019m proud to announce my choice for two key members of my national security team\"",
  "id" : 288348514969346049,
  "created_at" : "2013-01-07 18:16:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/V8G072wb",
      "expanded_url" : "http:\/\/at.wh.gov\/gBIqm",
      "display_url" : "at.wh.gov\/gBIqm"
    } ]
  },
  "geo" : { },
  "id_str" : "288347765120065536",
  "text" : "Watch live: President Obama makes a personnel announcement from the White House: http:\/\/t.co\/V8G072wb",
  "id" : 288347765120065536,
  "created_at" : "2013-01-07 18:13:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/WjKd1sQv",
      "expanded_url" : "http:\/\/at.wh.gov\/gBCQY",
      "display_url" : "at.wh.gov\/gBCQY"
    } ]
  },
  "geo" : { },
  "id_str" : "288335097336328192",
  "text" : "Starting at 1ET: President Obama makes a personnel announcement from the White House. Watch live: http:\/\/t.co\/WjKd1sQv",
  "id" : 288335097336328192,
  "created_at" : "2013-01-07 17:23:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/288088584936894464\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/LXbBoz5Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_9_CqmCMAAjsgp.jpg",
      "id_str" : "288088584945283072",
      "id" : 288088584945283072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_9_CqmCMAAjsgp.jpg",
      "sizes" : [ {
        "h" : 650,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 976
      } ],
      "display_url" : "pic.twitter.com\/LXbBoz5Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/lVoXBE63",
      "expanded_url" : "http:\/\/on.wh.gov\/LJmWLWA",
      "display_url" : "on.wh.gov\/LJmWLWA"
    } ]
  },
  "geo" : { },
  "id_str" : "288088584936894464",
  "text" : "\u200E2012 in Photos: http:\/\/t.co\/lVoXBE63 Includes President Obama getting a hug from 3-year-old Arianna in the Oval Office http:\/\/t.co\/LXbBoz5Y",
  "id" : 288088584936894464,
  "created_at" : "2013-01-07 01:04:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/asCNznso",
      "expanded_url" : "http:\/\/at.wh.gov\/gA6Cp",
      "display_url" : "at.wh.gov\/gA6Cp"
    } ]
  },
  "geo" : { },
  "id_str" : "288038565525463041",
  "text" : "In this week\u2019s address, President Obama discusses the deal passed by Congress to prevent a middle-class tax hike: http:\/\/t.co\/asCNznso",
  "id" : 288038565525463041,
  "created_at" : "2013-01-06 21:45:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/288012036644941825\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/mFuB0c7S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_85a9-CMAIxveK.jpg",
      "id_str" : "288012036649136130",
      "id" : 288012036649136130,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_85a9-CMAIxveK.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mFuB0c7S"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "288012036644941825",
  "text" : "Today, President Obama signed the #Sandy relief bill in the Diplomatic Reception Room of the White House. Photo: http:\/\/t.co\/mFuB0c7S",
  "id" : 288012036644941825,
  "created_at" : "2013-01-06 19:59:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fiscalcliff",
      "indices" : [ 55, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/M7jnfk54",
      "expanded_url" : "http:\/\/at.wh.gov\/gzl1S",
      "display_url" : "at.wh.gov\/gzl1S"
    } ]
  },
  "geo" : { },
  "id_str" : "287747969665626113",
  "text" : "White Board: Economic advisor Brian Deese explains the #fiscalcliff deal in under a minute: http:\/\/t.co\/M7jnfk54",
  "id" : 287747969665626113,
  "created_at" : "2013-01-06 02:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/287717912020664321\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/12PdLWaE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_4t6qYCQAEw2pM.jpg",
      "id_str" : "287717912029052929",
      "id" : 287717912029052929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_4t6qYCQAEw2pM.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/12PdLWaE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/DhXD4Fm9",
      "expanded_url" : "http:\/\/on.wh.gov\/FQA0y5O",
      "display_url" : "on.wh.gov\/FQA0y5O"
    } ]
  },
  "geo" : { },
  "id_str" : "287717912020664321",
  "text" : "2012: A Year in Photos: http:\/\/t.co\/DhXD4Fm9 Includes the President &amp; First Lady at a wedding in Chicago: http:\/\/t.co\/12PdLWaE",
  "id" : 287717912020664321,
  "created_at" : "2013-01-06 00:31:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/b61tbbv6",
      "expanded_url" : "http:\/\/at.wh.gov\/gzh9D",
      "display_url" : "at.wh.gov\/gzh9D"
    } ]
  },
  "geo" : { },
  "id_str" : "287685037585997824",
  "text" : "President Obama: \"I look forward to working with the new Congress in a bipartisan way.\" Watch the Weekly Address: http:\/\/t.co\/b61tbbv6",
  "id" : 287685037585997824,
  "created_at" : "2013-01-05 22:20:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/etKWYn2Q",
      "expanded_url" : "http:\/\/at.wh.gov\/gzkWv",
      "display_url" : "at.wh.gov\/gzkWv"
    } ]
  },
  "geo" : { },
  "id_str" : "287652838149070848",
  "text" : "Get the facts about the Taxpayer Relief Act of 2012 in the latest White House White Board: http:\/\/t.co\/etKWYn2Q",
  "id" : 287652838149070848,
  "created_at" : "2013-01-05 20:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/9KUdO5l9",
      "expanded_url" : "http:\/\/at.wh.gov\/gz3Hh",
      "display_url" : "at.wh.gov\/gz3Hh"
    } ]
  },
  "geo" : { },
  "id_str" : "287571925818028032",
  "text" : "President Obama's Weekly Address: Working together in the New Year to grow our economy and shrink our deficits: http:\/\/t.co\/9KUdO5l9",
  "id" : 287571925818028032,
  "created_at" : "2013-01-05 14:51:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/LWiGOCsK",
      "expanded_url" : "http:\/\/at.wh.gov\/gywJZ",
      "display_url" : "at.wh.gov\/gywJZ"
    } ]
  },
  "geo" : { },
  "id_str" : "287378048976830464",
  "text" : "What's in the Taxpayer Relief Act of 2012? Find out in the latest White House White Board: http:\/\/t.co\/LWiGOCsK",
  "id" : 287378048976830464,
  "created_at" : "2013-01-05 02:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/287346516727832576\/photo\/1",
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/lla1fxbq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_zcInFCIAIkH_D.jpg",
      "id_str" : "287346516732026882",
      "id" : 287346516732026882,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_zcInFCIAIkH_D.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/lla1fxbq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/NPyFIeP4",
      "expanded_url" : "http:\/\/on.wh.gov\/W8zcDlL",
      "display_url" : "on.wh.gov\/W8zcDlL"
    } ]
  },
  "geo" : { },
  "id_str" : "287346516727832576",
  "text" : "2012: A Year in Photos: http:\/\/t.co\/NPyFIeP4 http:\/\/t.co\/lla1fxbq",
  "id" : 287346516727832576,
  "created_at" : "2013-01-04 23:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/LeTwNAzl",
      "expanded_url" : "http:\/\/at.wh.gov\/gy63T",
      "display_url" : "at.wh.gov\/gy63T"
    } ]
  },
  "geo" : { },
  "id_str" : "287291148161150976",
  "text" : "Got 40 seconds? Watch a quick explainer about the new agreement to extend middle class tax cuts: http:\/\/t.co\/LeTwNAzl #my2k",
  "id" : 287291148161150976,
  "created_at" : "2013-01-04 20:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/n2KlbbeN",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/omb\/budget\/Overview",
      "display_url" : "whitehouse.gov\/omb\/budget\/Ove\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287238195362537472",
  "text" : "RT @WHLive: POTUS will do more spending cuts &amp; has specific proposals eg: http:\/\/t.co\/n2KlbbeN. But needs to be balanced w new reven ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fiscalcliff411",
        "indices" : [ 128, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/n2KlbbeN",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/omb\/budget\/Overview",
        "display_url" : "whitehouse.gov\/omb\/budget\/Ove\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "287237703219679233",
    "text" : "POTUS will do more spending cuts &amp; has specific proposals eg: http:\/\/t.co\/n2KlbbeN. But needs to be balanced w new revenues #fiscalcliff411",
    "id" : 287237703219679233,
    "created_at" : "2013-01-04 16:42:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 287238195362537472,
  "created_at" : "2013-01-04 16:44:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 3, 16 ],
      "id_str" : "19546277",
      "id" : 19546277
    }, {
      "name" : "Farnoosh Torabi",
      "screen_name" : "FARNOOSH",
      "indices" : [ 24, 33 ],
      "id_str" : "14467969",
      "id" : 14467969
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiscalCliff",
      "indices" : [ 35, 47 ]
    }, {
      "text" : "taxes",
      "indices" : [ 63, 69 ]
    }, {
      "text" : "debt",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287238108410433537",
  "text" : "RT @YahooFinance: Q via @Farnoosh: #FiscalCliff deal addressed #taxes but not much re: #debt ceiling. What spending cuts will POTUS figh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Farnoosh Torabi",
        "screen_name" : "FARNOOSH",
        "indices" : [ 6, 15 ],
        "id_str" : "14467969",
        "id" : 14467969
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FiscalCliff",
        "indices" : [ 17, 29 ]
      }, {
        "text" : "taxes",
        "indices" : [ 45, 51 ]
      }, {
        "text" : "debt",
        "indices" : [ 69, 74 ]
      }, {
        "text" : "FiscalCliff411",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287236354688040960",
    "text" : "Q via @Farnoosh: #FiscalCliff deal addressed #taxes but not much re: #debt ceiling. What spending cuts will POTUS fight for? #FiscalCliff411",
    "id" : 287236354688040960,
    "created_at" : "2013-01-04 16:37:38 +0000",
    "user" : {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "protected" : false,
      "id_str" : "19546277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710978975376388096\/1U2djlFO_normal.jpg",
      "id" : 19546277,
      "verified" : true
    }
  },
  "id" : 287238108410433537,
  "created_at" : "2013-01-04 16:44:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 67, 80 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fiscalcliff411",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "287236681478840321",
  "text" : "RT @WHLive: Good morning everyone, Brian here. Happy to be joining @yahoofinance for this #fiscalcliff411",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yahoo Finance",
        "screen_name" : "YahooFinance",
        "indices" : [ 55, 68 ],
        "id_str" : "19546277",
        "id" : 19546277
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fiscalcliff411",
        "indices" : [ 78, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "287236020070653953",
    "text" : "Good morning everyone, Brian here. Happy to be joining @yahoofinance for this #fiscalcliff411",
    "id" : 287236020070653953,
    "created_at" : "2013-01-04 16:36:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 287236681478840321,
  "created_at" : "2013-01-04 16:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/287227703197827073\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/lti1smhs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_xwEwMCAAEmspv.jpg",
      "id_str" : "287227703202021377",
      "id" : 287227703202021377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_xwEwMCAAEmspv.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/lti1smhs"
    } ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 9, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/k091tfIz",
      "expanded_url" : "http:\/\/wh.gov\/UwOQ",
      "display_url" : "wh.gov\/UwOQ"
    } ]
  },
  "geo" : { },
  "id_str" : "287227703197827073",
  "text" : "New jobs #s: US economy adds 168k private sector jobs in Dec, 5.8M jobs over 34 months: http:\/\/t.co\/k091tfIz More to do http:\/\/t.co\/lti1smhs",
  "id" : 287227703197827073,
  "created_at" : "2013-01-04 16:03:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fiscalcliff411",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/2Cd9ucms",
      "expanded_url" : "http:\/\/at.wh.gov\/gxF2q",
      "display_url" : "at.wh.gov\/gxF2q"
    } ]
  },
  "geo" : { },
  "id_str" : "287220673640812544",
  "text" : "Have Qs on the agreement to extend middle class tax cuts? Watch: http:\/\/t.co\/2Cd9ucms &amp; ask: #fiscalcliff411. We'll answer today @ 11:30ET",
  "id" : 287220673640812544,
  "created_at" : "2013-01-04 15:35:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 3, 16 ],
      "id_str" : "19546277",
      "id" : 19546277
    }, {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 80, 93 ],
      "id_str" : "19546277",
      "id" : 19546277
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 94, 101 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiscalCliff",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286984565401198593",
  "text" : "RT @YahooFinance: What questions do you have on the #FiscalCliff deal? Join our @YahooFinance @WHlive chat Friday 11:30AM ET for all the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yahoo Finance",
        "screen_name" : "YahooFinance",
        "indices" : [ 62, 75 ],
        "id_str" : "19546277",
        "id" : 19546277
      }, {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 76, 83 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FiscalCliff",
        "indices" : [ 34, 46 ]
      }, {
        "text" : "FiscalCliff411",
        "indices" : [ 119, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "286982442181603329",
    "text" : "What questions do you have on the #FiscalCliff deal? Join our @YahooFinance @WHlive chat Friday 11:30AM ET for all the #FiscalCliff411",
    "id" : 286982442181603329,
    "created_at" : "2013-01-03 23:48:40 +0000",
    "user" : {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "protected" : false,
      "id_str" : "19546277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710978975376388096\/1U2djlFO_normal.jpg",
      "id" : 19546277,
      "verified" : true
    }
  },
  "id" : 286984565401198593,
  "created_at" : "2013-01-03 23:57:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/286963276439494657\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/l7FCBXy9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_t_lFxCIAAbvJJ.jpg",
      "id_str" : "286963276447883264",
      "id" : 286963276447883264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_t_lFxCIAAbvJJ.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/l7FCBXy9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/YBGsapcH",
      "expanded_url" : "http:\/\/on.wh.gov\/qNtB96A",
      "display_url" : "on.wh.gov\/qNtB96A"
    } ]
  },
  "geo" : { },
  "id_str" : "286963276439494657",
  "text" : "Year in Review: The top White House tweets of 2012: http:\/\/t.co\/YBGsapcH Including President Obama's live Twitter Q&amp;A: http:\/\/t.co\/l7FCBXy9",
  "id" : 286963276439494657,
  "created_at" : "2013-01-03 22:32:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/3QAl6vFG",
      "expanded_url" : "http:\/\/bit.ly\/TylPo6",
      "display_url" : "bit.ly\/TylPo6"
    } ]
  },
  "geo" : { },
  "id_str" : "286854686575845378",
  "text" : "RT @petesouza: The Year in Photographs, 2012. Includes many new photos. Let me know if you have a favorite. http:\/\/t.co\/3QAl6vFG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/3QAl6vFG",
        "expanded_url" : "http:\/\/bit.ly\/TylPo6",
        "display_url" : "bit.ly\/TylPo6"
      } ]
    },
    "geo" : { },
    "id_str" : "286788964508127232",
    "text" : "The Year in Photographs, 2012. Includes many new photos. Let me know if you have a favorite. http:\/\/t.co\/3QAl6vFG",
    "id" : 286788964508127232,
    "created_at" : "2013-01-03 10:59:52 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 286854686575845378,
  "created_at" : "2013-01-03 15:21:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/286571414755102720\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/egyCjYna",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_obLvPCUAAYSRN.jpg",
      "id_str" : "286571414763491328",
      "id" : 286571414763491328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_obLvPCUAAYSRN.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 588,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/egyCjYna"
    } ],
    "hashtags" : [ {
      "text" : "fiscalcliff",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/T32iahEk",
      "expanded_url" : "http:\/\/on.wh.gov\/J4Ep4Iw",
      "display_url" : "on.wh.gov\/J4Ep4Iw"
    } ]
  },
  "geo" : { },
  "id_str" : "286571414755102720",
  "text" : "The bipartisan #fiscalcliff deal protects the middle class &amp; reduces the deficit by $737 billion: http:\/\/t.co\/T32iahEk http:\/\/t.co\/egyCjYna",
  "id" : 286571414755102720,
  "created_at" : "2013-01-02 20:35:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/286529069087068160\/photo\/1",
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/w6d9KodD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A_n0q5UCEAAjQp7.jpg",
      "id_str" : "286529069091262464",
      "id" : 286529069091262464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A_n0q5UCEAAjQp7.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 588,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/w6d9KodD"
    } ],
    "hashtags" : [ {
      "text" : "fiscalcliff",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/gbxnqGha",
      "expanded_url" : "http:\/\/wh.gov\/UNjo",
      "display_url" : "wh.gov\/UNjo"
    } ]
  },
  "geo" : { },
  "id_str" : "286529069087068160",
  "text" : "7 things you need to know about the #fiscalcliff deal: http:\/\/t.co\/gbxnqGha http:\/\/t.co\/w6d9KodD",
  "id" : 286529069087068160,
  "created_at" : "2013-01-02 17:47:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fiscalcliff",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/IWQHAGBL",
      "expanded_url" : "http:\/\/at.wh.gov\/gu208",
      "display_url" : "at.wh.gov\/gu208"
    } ]
  },
  "geo" : { },
  "id_str" : "286507920554860544",
  "text" : "What You Need to Know About the Bipartisan Tax Agreement: http:\/\/t.co\/IWQHAGBL #fiscalcliff",
  "id" : 286507920554860544,
  "created_at" : "2013-01-02 16:23:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/oBtCX6VQ",
      "expanded_url" : "http:\/\/at.wh.gov\/gtgU7",
      "display_url" : "at.wh.gov\/gtgU7"
    } ]
  },
  "geo" : { },
  "id_str" : "286337678176292865",
  "text" : "Tonight, President Obama delivered a statement on the tax agreement from the Briefing Room. Watch: http:\/\/t.co\/oBtCX6VQ",
  "id" : 286337678176292865,
  "created_at" : "2013-01-02 05:06:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286327656679604224",
  "text" : "President Obama: \"There is a path forward, if we focus not on politics, but on what\u2019s right for the country\"",
  "id" : 286327656679604224,
  "created_at" : "2013-01-02 04:26:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286327498671812608",
  "text" : "President Obama: \u201CToday\u2019s agreement enshrines a principle into law...the deficit must be reduced in a way that is balanced\"",
  "id" : 286327498671812608,
  "created_at" : "2013-01-02 04:26:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286326877554094080",
  "text" : "President Obama: \"Tonight\u2019s agreement further reduces the deficit by raising $620 billion in revenue from the wealthiest households\u201D",
  "id" : 286326877554094080,
  "created_at" : "2013-01-02 04:23:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286326607235383296",
  "text" : "President Obama: \u201CThis law is one more step in the broader effort to strengthen our economy and broaden opportunity\u201D",
  "id" : 286326607235383296,
  "created_at" : "2013-01-02 04:22:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286326513488506880",
  "text" : "Obama on tax agreement: \u201CMillions of families will continue to receive tax credits to help raise their children &amp; send them to college\u201D",
  "id" : 286326513488506880,
  "created_at" : "2013-01-02 04:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286326443099693057",
  "text" : "President Obama: \"Under this law, more than 98% of Americans &amp; 97% of small business will not see their income taxes go up.\"",
  "id" : 286326443099693057,
  "created_at" : "2013-01-02 04:21:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286326259951226880",
  "text" : "President Obama: \"I will sign a law that raises taxes on the wealthiest 2% of Americans...while preventing a middle-class tax hike\"",
  "id" : 286326259951226880,
  "created_at" : "2013-01-02 04:21:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "286326141508255744",
  "text" : "Happening now: President Obama delivers remarks on Congress passing the tax agreement. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 286326141508255744,
  "created_at" : "2013-01-02 04:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "286324549778276352",
  "text" : "At 11:20pm ET, President Obama will deliver a statement from the Briefing Room. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 286324549778276352,
  "created_at" : "2013-01-02 04:14:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]