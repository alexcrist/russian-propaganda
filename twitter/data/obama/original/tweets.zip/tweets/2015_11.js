Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671501001334104064\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/1GbnRyNhqV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVGmgU2WcAA6kRJ.jpg",
      "id_str" : "671500893737611264",
      "id" : 671500893737611264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVGmgU2WcAA6kRJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1GbnRyNhqV"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 12, 25 ]
    }, {
      "text" : "COP21",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/wHaMOgp59B",
      "expanded_url" : "http:\/\/go.wh.gov\/kEsr6g",
      "display_url" : "go.wh.gov\/kEsr6g"
    } ]
  },
  "geo" : { },
  "id_str" : "671501001334104064",
  "text" : "The time to #ActOnClimate is now. Let's get to work \u2192 https:\/\/t.co\/wHaMOgp59B #COP21 https:\/\/t.co\/1GbnRyNhqV",
  "id" : 671501001334104064,
  "created_at" : "2015-12-01 01:28:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 111, 125 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthRightNow",
      "indices" : [ 60, 74 ]
    }, {
      "text" : "Paris",
      "indices" : [ 86, 92 ]
    }, {
      "text" : "COP21",
      "indices" : [ 99, 105 ]
    }, {
      "text" : "YearInSpace",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671481110610579456",
  "text" : "RT @StationCDRKelly: The thin film of the atmosphere of our #EarthRightNow glows over #Paris &amp; #COP21 from @space_station. #YearInSpace htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 90, 104 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StationCDRKelly\/status\/671439410332835840\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/u3959PUyql",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVFulfQXIAAKo8p.jpg",
        "id_str" : "671439409779253248",
        "id" : 671439409779253248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVFulfQXIAAKo8p.jpg",
        "sizes" : [ {
          "h" : 816,
          "resize" : "fit",
          "w" : 1226
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/u3959PUyql"
      } ],
      "hashtags" : [ {
        "text" : "EarthRightNow",
        "indices" : [ 39, 53 ]
      }, {
        "text" : "Paris",
        "indices" : [ 65, 71 ]
      }, {
        "text" : "COP21",
        "indices" : [ 78, 84 ]
      }, {
        "text" : "YearInSpace",
        "indices" : [ 106, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671439410332835840",
    "text" : "The thin film of the atmosphere of our #EarthRightNow glows over #Paris &amp; #COP21 from @space_station. #YearInSpace https:\/\/t.co\/u3959PUyql",
    "id" : 671439410332835840,
    "created_at" : "2015-11-30 21:23:24 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 671481110610579456,
  "created_at" : "2015-12-01 00:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Narendra Modi",
      "screen_name" : "narendramodi",
      "indices" : [ 3, 16 ],
      "id_str" : "18839785",
      "id" : 18839785
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671477434265530368",
  "text" : "RT @narendramodi: Talked about the importance of innovation to combat climate change at the Innovation Summit hosted by @POTUS. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 102, 108 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/Yev9nklBBF",
        "expanded_url" : "http:\/\/nm-4.com\/20eb",
        "display_url" : "nm-4.com\/20eb"
      } ]
    },
    "geo" : { },
    "id_str" : "671382590495019012",
    "text" : "Talked about the importance of innovation to combat climate change at the Innovation Summit hosted by @POTUS. https:\/\/t.co\/Yev9nklBBF #COP21",
    "id" : 671382590495019012,
    "created_at" : "2015-11-30 17:37:37 +0000",
    "user" : {
      "name" : "Narendra Modi",
      "screen_name" : "narendramodi",
      "protected" : false,
      "id_str" : "18839785",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718314968102367232\/ypY1GPCQ_normal.jpg",
      "id" : 18839785,
      "verified" : true
    }
  },
  "id" : 671477434265530368,
  "created_at" : "2015-11-30 23:54:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 1, 16 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 81, 87 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671471821623967744\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/th6rCm1mea",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVGLzZbUkAQkZ_Z.jpg",
      "id_str" : "671471534569984004",
      "id" : 671471534569984004,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVGLzZbUkAQkZ_Z.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/th6rCm1mea"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671471821623967744",
  "text" : ".@AmbassadorRice on the confirmation of Gayle Smith as our next Administrator of @USAID. https:\/\/t.co\/th6rCm1mea",
  "id" : 671471821623967744,
  "created_at" : "2015-11-30 23:32:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "indices" : [ 1, 11 ],
      "id_str" : "50393960",
      "id" : 50393960
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671466532749352964\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/AC2F8iaGaP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVGG-zKXAAAC-Wq.jpg",
      "id_str" : "671466232898584576",
      "id" : 671466232898584576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVGG-zKXAAAC-Wq.jpg",
      "sizes" : [ {
        "h" : 1935,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 708,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AC2F8iaGaP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/a28VFqn9IT",
      "expanded_url" : "http:\/\/go.wh.gov\/GmcLre",
      "display_url" : "go.wh.gov\/GmcLre"
    } ]
  },
  "geo" : { },
  "id_str" : "671466532749352964",
  "text" : ".@BillGates and other top business leaders are making historic investments in clean energy: https:\/\/t.co\/a28VFqn9IT https:\/\/t.co\/AC2F8iaGaP",
  "id" : 671466532749352964,
  "created_at" : "2015-11-30 23:11:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671452649514995712",
  "text" : "RT @NSCPress: The U.S. is aggressively strengthening the Visa Waiver Program, which permits travel for 20 million visitors yearly. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/671421315685990408\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/VnXhqjeqmE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVFeINUU4AASKGc.jpg",
        "id_str" : "671421314561794048",
        "id" : 671421314561794048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVFeINUU4AASKGc.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VnXhqjeqmE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671421315685990408",
    "text" : "The U.S. is aggressively strengthening the Visa Waiver Program, which permits travel for 20 million visitors yearly. https:\/\/t.co\/VnXhqjeqmE",
    "id" : 671421315685990408,
    "created_at" : "2015-11-30 20:11:30 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 671452649514995712,
  "created_at" : "2015-11-30 22:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Trudeau",
      "screen_name" : "JustinTrudeau",
      "indices" : [ 3, 17 ],
      "id_str" : "14260960",
      "id" : 14260960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MissionInnovation",
      "indices" : [ 41, 59 ]
    }, {
      "text" : "Cop21",
      "indices" : [ 118, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671446652998328320",
  "text" : "RT @JustinTrudeau: Canada is joining the #MissionInnovation project to support clean energy and technology innovators #Cop21: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MissionInnovation",
        "indices" : [ 22, 40 ]
      }, {
        "text" : "Cop21",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/FW1NyhEKmU",
        "expanded_url" : "http:\/\/mission-innovation.net",
        "display_url" : "mission-innovation.net"
      } ]
    },
    "geo" : { },
    "id_str" : "671366045773471746",
    "text" : "Canada is joining the #MissionInnovation project to support clean energy and technology innovators #Cop21: https:\/\/t.co\/FW1NyhEKmU",
    "id" : 671366045773471746,
    "created_at" : "2015-11-30 16:31:53 +0000",
    "user" : {
      "name" : "Justin Trudeau",
      "screen_name" : "JustinTrudeau",
      "protected" : false,
      "id_str" : "14260960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797443159198470144\/1AwTnliW_normal.jpg",
      "id" : 14260960,
      "verified" : true
    }
  },
  "id" : 671446652998328320,
  "created_at" : "2015-11-30 21:52:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671431155326050304",
  "text" : "RT @VP: The Brady Bill became law 22 years ago today. Once again, our political system must do right by the majority of Americans demanding\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "671425311637168128",
    "geo" : { },
    "id_str" : "671428512440582144",
    "in_reply_to_user_id" : 325830217,
    "text" : "The Brady Bill became law 22 years ago today. Once again, our political system must do right by the majority of Americans demanding change.",
    "id" : 671428512440582144,
    "in_reply_to_status_id" : 671425311637168128,
    "created_at" : "2015-11-30 20:40:06 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 671431155326050304,
  "created_at" : "2015-11-30 20:50:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671429870510018560",
  "text" : "RT @VP: Our prayers may comfort the families of the CO victims, but our actions can truly stop gun violence in America. Enough is enough.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671425311637168128",
    "text" : "Our prayers may comfort the families of the CO victims, but our actions can truly stop gun violence in America. Enough is enough.",
    "id" : 671425311637168128,
    "created_at" : "2015-11-30 20:27:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 671429870510018560,
  "created_at" : "2015-11-30 20:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forest Whitaker",
      "screen_name" : "ForestWhitaker",
      "indices" : [ 3, 18 ],
      "id_str" : "257242329",
      "id" : 257242329
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671406730996224000",
  "text" : "RT @ForestWhitaker: We must take strong &amp; decisive action. The stakes are too high for inaction. Our children's futures are in our hands #C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 121, 127 ]
      }, {
        "text" : "Actonclimate",
        "indices" : [ 128, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671387504768098305",
    "text" : "We must take strong &amp; decisive action. The stakes are too high for inaction. Our children's futures are in our hands #COP21 #Actonclimate",
    "id" : 671387504768098305,
    "created_at" : "2015-11-30 17:57:09 +0000",
    "user" : {
      "name" : "Forest Whitaker",
      "screen_name" : "ForestWhitaker",
      "protected" : false,
      "id_str" : "257242329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000604282474\/8bda40f10e4c4b29ef91505692b6896a_normal.jpeg",
      "id" : 257242329,
      "verified" : true
    }
  },
  "id" : 671406730996224000,
  "created_at" : "2015-11-30 19:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/yF4qMQMYiY",
      "expanded_url" : "http:\/\/mission-innovation.net\/",
      "display_url" : "mission-innovation.net"
    } ]
  },
  "geo" : { },
  "id_str" : "671402270064537600",
  "text" : "Big news: Nations representing 75% of CO2 emissions from electricity are doubling clean energy investments \u2192 https:\/\/t.co\/yF4qMQMYiY #COP21",
  "id" : 671402270064537600,
  "created_at" : "2015-11-30 18:55:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "indices" : [ 3, 13 ],
      "id_str" : "50393960",
      "id" : 50393960
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671393053261832192",
  "text" : "RT @BillGates: .@POTUS Thank you for your leadership. What a historic day.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "671365993399255040",
    "geo" : { },
    "id_str" : "671390904628862976",
    "in_reply_to_user_id" : 1536791610,
    "text" : ".@POTUS Thank you for your leadership. What a historic day.",
    "id" : 671390904628862976,
    "in_reply_to_status_id" : 671365993399255040,
    "created_at" : "2015-11-30 18:10:40 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "protected" : false,
      "id_str" : "50393960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558109954561679360\/j1f9DiJi_normal.jpeg",
      "id" : 50393960,
      "verified" : true
    }
  },
  "id" : 671393053261832192,
  "created_at" : "2015-11-30 18:19:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671367841459884032",
  "text" : "RT @POTUS: Addressing climate change takes all of us, especially the private sector going all-in on clean energy worldwide. https:\/\/t.co\/qQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/qQ6wCZUR1Z",
        "expanded_url" : "https:\/\/twitter.com\/billgates\/status\/671325937749872640",
        "display_url" : "twitter.com\/billgates\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "671365993399255040",
    "text" : "Addressing climate change takes all of us, especially the private sector going all-in on clean energy worldwide. https:\/\/t.co\/qQ6wCZUR1Z",
    "id" : 671365993399255040,
    "created_at" : "2015-11-30 16:31:40 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 671367841459884032,
  "created_at" : "2015-11-30 16:39:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/LgUKwxVQ7c",
      "expanded_url" : "http:\/\/snpy.tv\/1YCZCos",
      "display_url" : "snpy.tv\/1YCZCos"
    } ]
  },
  "geo" : { },
  "id_str" : "671358519417937920",
  "text" : ".@POTUS on the task in Paris: \"A long-term strategy that gives the world confidence in a low-carbon future.\" #COP21 https:\/\/t.co\/LgUKwxVQ7c",
  "id" : 671358519417937920,
  "created_at" : "2015-11-30 16:01:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climate",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671341916701786112",
  "text" : "RT @JohnKerry: US &amp; 10 other nations just announced nearly $250M for Least Developed Countries Fund - help those in need with #climate adap\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "climate",
        "indices" : [ 115, 123 ]
      }, {
        "text" : "COP21",
        "indices" : [ 136, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671329143489994752",
    "text" : "US &amp; 10 other nations just announced nearly $250M for Least Developed Countries Fund - help those in need with #climate adaptation. #COP21",
    "id" : 671329143489994752,
    "created_at" : "2015-11-30 14:05:15 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 671341916701786112,
  "created_at" : "2015-11-30 14:56:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/yOwtiecSjb",
      "expanded_url" : "http:\/\/snpy.tv\/1lTUgXK",
      "display_url" : "snpy.tv\/1lTUgXK"
    } ]
  },
  "geo" : { },
  "id_str" : "671306441811206144",
  "text" : "\"There is such a thing as being too late\" \u2014@POTUS at #COP21\n\nRT if you agree: It's time to #ActOnClimate. https:\/\/t.co\/yOwtiecSjb",
  "id" : 671306441811206144,
  "created_at" : "2015-11-30 12:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisClimateConference",
      "indices" : [ 90, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/5w2hTP5Cja",
      "expanded_url" : "http:\/\/snpy.tv\/1lTSGFs",
      "display_url" : "snpy.tv\/1lTSGFs"
    } ]
  },
  "geo" : { },
  "id_str" : "671300176007585792",
  "text" : "\"Let that be our common purpose in Paris: A world that is worthy of our children\" \u2014@POTUS #ParisClimateConference https:\/\/t.co\/5w2hTP5Cja",
  "id" : 671300176007585792,
  "created_at" : "2015-11-30 12:10:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisClimateConference",
      "indices" : [ 117, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671298251463729152",
  "text" : "\"There is such a thing as being too late, and when it comes to climate change, that hour is almost upon us.\" \u2014@POTUS #ParisClimateConference",
  "id" : 671298251463729152,
  "created_at" : "2015-11-30 12:02:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671298075089108997\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/i2mQ1VCkCB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVDuCkOWsAUYsKP.jpg",
      "id_str" : "671298072329236485",
      "id" : 671298072329236485,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVDuCkOWsAUYsKP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/i2mQ1VCkCB"
    } ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 85, 91 ]
    }, {
      "text" : "ParisClimateConference",
      "indices" : [ 92, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671298075089108997",
  "text" : "\"Here in Paris, we can show the world what\u2019s possible when we come together\" \u2014@POTUS #COP21 #ParisClimateConference https:\/\/t.co\/i2mQ1VCkCB",
  "id" : 671298075089108997,
  "created_at" : "2015-11-30 12:01:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671297739003666432",
  "text" : "RT @FactsOnClimate: \"Let\u2019s show businesses and investors that the global economy is on a firm path towards a low-carbon future.\" \u2014@POTUS #P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 110, 116 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisClimateConference",
        "indices" : [ 117, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671297658972209152",
    "text" : "\"Let\u2019s show businesses and investors that the global economy is on a firm path towards a low-carbon future.\" \u2014@POTUS #ParisClimateConference",
    "id" : 671297658972209152,
    "created_at" : "2015-11-30 12:00:08 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 671297739003666432,
  "created_at" : "2015-11-30 12:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671297248676941824\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/GM0aN1qK7E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVDtRdPWcAACyPf.jpg",
      "id_str" : "671297228640776192",
      "id" : 671297228640776192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVDtRdPWcAACyPf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GM0aN1qK7E"
    } ],
    "hashtags" : [ {
      "text" : "ParisClimateConference",
      "indices" : [ 85, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671297248676941824",
  "text" : "\"America will reduce our emissions 26-28% below 2005 levels within 10 years\" \u2014@POTUS #ParisClimateConference https:\/\/t.co\/GM0aN1qK7E",
  "id" : 671297248676941824,
  "created_at" : "2015-11-30 11:58:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/671296871290261504\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/amEgFyxq5w",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CVDs7l5WUAAB7L_.png",
      "id_str" : "671296853007290368",
      "id" : 671296853007290368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CVDs7l5WUAAB7L_.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/amEgFyxq5w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671296871290261504",
  "text" : "\"More than 180 countries representing nearly 95% of global emissions have put forward their own climate targets.\" https:\/\/t.co\/amEgFyxq5w",
  "id" : 671296871290261504,
  "created_at" : "2015-11-30 11:57:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671296272347828224\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/IwwFdBuml6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVDsXqbWoAEAXWu.jpg",
      "id_str" : "671296235748368385",
      "id" : 671296235748368385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVDsXqbWoAEAXWu.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IwwFdBuml6"
    } ],
    "hashtags" : [ {
      "text" : "ParisClimateConference",
      "indices" : [ 85, 108 ]
    }, {
      "text" : "COP21",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671296272347828224",
  "text" : "\"We have multiplied wind power threefold, and solar power more than 20-fold\" \u2014@POTUS #ParisClimateConference #COP21 https:\/\/t.co\/IwwFdBuml6",
  "id" : 671296272347828224,
  "created_at" : "2015-11-30 11:54:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671296082794647552\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/m5DjvcOdhM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVDsIMRWEAAxj8x.jpg",
      "id_str" : "671295969955287040",
      "id" : 671295969955287040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVDsIMRWEAAxj8x.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/m5DjvcOdhM"
    } ],
    "hashtags" : [ {
      "text" : "ParisClimateConference",
      "indices" : [ 72, 95 ]
    }, {
      "text" : "COP21",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671296082794647552",
  "text" : "\"Glaciers are melting at a pace unprecedented in modern times.\" \u2014@POTUS #ParisClimateConference #COP21 https:\/\/t.co\/m5DjvcOdhM",
  "id" : 671296082794647552,
  "created_at" : "2015-11-30 11:53:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671295789411512320\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/QeOzdgyJaf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVDr7z-XIAEc7Ne.jpg",
      "id_str" : "671295757274783745",
      "id" : 671295757274783745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVDr7z-XIAEc7Ne.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/QeOzdgyJaf"
    } ],
    "hashtags" : [ {
      "text" : "ParisClimateConference",
      "indices" : [ 90, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671295789411512320",
  "text" : "\"I saw the effects of climate change firsthand in our northernmost state, Alaska\" \u2014@POTUS #ParisClimateConference https:\/\/t.co\/QeOzdgyJaf",
  "id" : 671295789411512320,
  "created_at" : "2015-11-30 11:52:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 83, 96 ]
    }, {
      "text" : "COP21",
      "indices" : [ 97, 103 ]
    }, {
      "text" : "ParisClimateConference",
      "indices" : [ 104, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671295213978189824",
  "text" : "\"Nothing will deter us from building the future we want for our children.\" \u2014@POTUS #ActOnClimate #COP21 #ParisClimateConference",
  "id" : 671295213978189824,
  "created_at" : "2015-11-30 11:50:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    }, {
      "text" : "COP21",
      "indices" : [ 98, 104 ]
    }, {
      "text" : "ParisClimateConference",
      "indices" : [ 105, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671295110756352000",
  "text" : "\"We salute the people of Paris for insisting this crucial conference go on\" \u2014@POTUS #ActOnClimate #COP21 #ParisClimateConference",
  "id" : 671295110756352000,
  "created_at" : "2015-11-30 11:50:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisClimateConference",
      "indices" : [ 111, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671294917210185729",
  "text" : "\u201CPresident Hollande, Mr. Secretary General, fellow leaders: We have come to Paris to show our resolve\u201D \u2014@POTUS #ParisClimateConference",
  "id" : 671294917210185729,
  "created_at" : "2015-11-30 11:49:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisClimateConference",
      "indices" : [ 33, 56 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 83, 96 ]
    }, {
      "text" : "COP21",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/UO5vcB9k3v",
      "expanded_url" : "http:\/\/go.wh.gov\/79wDWi",
      "display_url" : "go.wh.gov\/79wDWi"
    } ]
  },
  "geo" : { },
  "id_str" : "671294748427198465",
  "text" : "Watch live: @POTUS speaks at the #ParisClimateConference \u2192 https:\/\/t.co\/UO5vcB9k3v #ActOnClimate #COP21",
  "id" : 671294748427198465,
  "created_at" : "2015-11-30 11:48:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/09so3nq2fo",
      "expanded_url" : "http:\/\/1.usa.gov\/1lT7yE6",
      "display_url" : "1.usa.gov\/1lT7yE6"
    } ]
  },
  "geo" : { },
  "id_str" : "671291336289591296",
  "text" : "RT @ENERGY: THIS IS BIG: @POTUS, 19 other nations to announce huge investment in #CleanEnergy innovation \u2192 https:\/\/t.co\/09so3nq2fo #ActOnCl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanEnergy",
        "indices" : [ 69, 81 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 119, 132 ]
      }, {
        "text" : "COP21",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/09so3nq2fo",
        "expanded_url" : "http:\/\/1.usa.gov\/1lT7yE6",
        "display_url" : "1.usa.gov\/1lT7yE6"
      } ]
    },
    "geo" : { },
    "id_str" : "671130116894912512",
    "text" : "THIS IS BIG: @POTUS, 19 other nations to announce huge investment in #CleanEnergy innovation \u2192 https:\/\/t.co\/09so3nq2fo #ActOnClimate #COP21",
    "id" : 671130116894912512,
    "created_at" : "2015-11-30 00:54:23 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 671291336289591296,
  "created_at" : "2015-11-30 11:35:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 21, 29 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 110, 116 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/G7bcAcuRnH",
      "expanded_url" : "http:\/\/nyti.ms\/1jq0lti",
      "display_url" : "nyti.ms\/1jq0lti"
    } ]
  },
  "geo" : { },
  "id_str" : "671288134102097920",
  "text" : "RT @FactsOnClimate: .@NYTimes: Short answers to hard questions about climate change \u2192 https:\/\/t.co\/G7bcAcuRnH #COP21 #ActOnClimate https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 1, 9 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/671287761765343232\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/HdCHWVXJtd",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CVDkmneWoAAB8cq.png",
        "id_str" : "671287696560660480",
        "id" : 671287696560660480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CVDkmneWoAAB8cq.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HdCHWVXJtd"
      } ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 90, 96 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 97, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/G7bcAcuRnH",
        "expanded_url" : "http:\/\/nyti.ms\/1jq0lti",
        "display_url" : "nyti.ms\/1jq0lti"
      } ]
    },
    "geo" : { },
    "id_str" : "671287761765343232",
    "text" : ".@NYTimes: Short answers to hard questions about climate change \u2192 https:\/\/t.co\/G7bcAcuRnH #COP21 #ActOnClimate https:\/\/t.co\/HdCHWVXJtd",
    "id" : 671287761765343232,
    "created_at" : "2015-11-30 11:20:48 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 671288134102097920,
  "created_at" : "2015-11-30 11:22:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateChange",
      "indices" : [ 66, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/TKhq11KgCR",
      "expanded_url" : "http:\/\/go.usa.gov\/cWtX5",
      "display_url" : "go.usa.gov\/cWtX5"
    } ]
  },
  "geo" : { },
  "id_str" : "671280612897067008",
  "text" : "RT @StateDept: Here are five things you need to know about the UN #ClimateChange Conference as it begins in Paris: https:\/\/t.co\/TKhq11KgCR \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ClimateChange",
        "indices" : [ 51, 65 ]
      }, {
        "text" : "COP21",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/TKhq11KgCR",
        "expanded_url" : "http:\/\/go.usa.gov\/cWtX5",
        "display_url" : "go.usa.gov\/cWtX5"
      } ]
    },
    "geo" : { },
    "id_str" : "671198948695138304",
    "text" : "Here are five things you need to know about the UN #ClimateChange Conference as it begins in Paris: https:\/\/t.co\/TKhq11KgCR #COP21",
    "id" : 671198948695138304,
    "created_at" : "2015-11-30 05:27:54 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 671280612897067008,
  "created_at" : "2015-11-30 10:52:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/QscCX2BfYE",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/27AHkssxbr",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/877cb8ca-be04-41c7-b522-e13ee99bb53f",
      "display_url" : "amp.twimg.com\/v\/877cb8ca-be0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "671175598274818049",
  "text" : "Watch: @POTUS's climate advisor previews the climate negotiations in Paris \u2192 https:\/\/t.co\/QscCX2BfYE #ActOnClimate\nhttps:\/\/t.co\/27AHkssxbr",
  "id" : 671175598274818049,
  "created_at" : "2015-11-30 03:55:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 9, 19 ],
      "id_str" : "18814998",
      "id" : 18814998
    }, {
      "name" : "Anne Hidalgo",
      "screen_name" : "Anne_Hidalgo",
      "indices" : [ 26, 39 ],
      "id_str" : "26073581",
      "id" : 26073581
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671148024526151680\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/sFvxpOTUQX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CVBlkj8WUAASZ8v.jpg",
      "id_str" : "671148023276261376",
      "id" : 671148023276261376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVBlkj8WUAASZ8v.jpg",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2036,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/sFvxpOTUQX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671148024526151680",
  "text" : ".@POTUS, @fhollande &amp; @Anne_Hidalgo honor the victims of the terrorist attacks at the Bataclan in Paris. https:\/\/t.co\/sFvxpOTUQX",
  "id" : 671148024526151680,
  "created_at" : "2015-11-30 02:05:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cop21",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Ze00jvBJK7",
      "expanded_url" : "http:\/\/on.mash.to\/1RfwMbK",
      "display_url" : "on.mash.to\/1RfwMbK"
    } ]
  },
  "geo" : { },
  "id_str" : "671128093122240512",
  "text" : "RT @mashable: Obama and Bill Gates to announce historic investment in clean energy research https:\/\/t.co\/Ze00jvBJK7 #cop21 https:\/\/t.co\/2yi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mashable\/status\/671117890683322370\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/2yiBL2lGbJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVBKKlOWcAAHRcW.jpg",
        "id_str" : "671117890129653760",
        "id" : 671117890129653760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVBKKlOWcAAHRcW.jpg",
        "sizes" : [ {
          "h" : 534,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2yiBL2lGbJ"
      } ],
      "hashtags" : [ {
        "text" : "cop21",
        "indices" : [ 102, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/Ze00jvBJK7",
        "expanded_url" : "http:\/\/on.mash.to\/1RfwMbK",
        "display_url" : "on.mash.to\/1RfwMbK"
      } ]
    },
    "geo" : { },
    "id_str" : "671117890683322370",
    "text" : "Obama and Bill Gates to announce historic investment in clean energy research https:\/\/t.co\/Ze00jvBJK7 #cop21 https:\/\/t.co\/2yiBL2lGbJ",
    "id" : 671117890683322370,
    "created_at" : "2015-11-30 00:05:48 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760998040949841922\/XT79xzRT_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 671128093122240512,
  "created_at" : "2015-11-30 00:46:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    }, {
      "text" : "COP21",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/T2lZWRsuja",
      "expanded_url" : "http:\/\/go.wh.gov\/GmcLre",
      "display_url" : "go.wh.gov\/GmcLre"
    } ]
  },
  "geo" : { },
  "id_str" : "671125622522007554",
  "text" : "RT @FactsOnClimate: BREAKING: @POTUS joins 19 countries to double clean energy funding \u2192 https:\/\/t.co\/T2lZWRsuja #ActOnClimate #COP21 https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/671125270011736064\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/eYBKctwmEd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVBP8MaW4AAeAI3.jpg",
        "id_str" : "671124240020725760",
        "id" : 671124240020725760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVBP8MaW4AAeAI3.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/eYBKctwmEd"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 93, 106 ]
      }, {
        "text" : "COP21",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/T2lZWRsuja",
        "expanded_url" : "http:\/\/go.wh.gov\/GmcLre",
        "display_url" : "go.wh.gov\/GmcLre"
      } ]
    },
    "geo" : { },
    "id_str" : "671125270011736064",
    "text" : "BREAKING: @POTUS joins 19 countries to double clean energy funding \u2192 https:\/\/t.co\/T2lZWRsuja #ActOnClimate #COP21 https:\/\/t.co\/eYBKctwmEd",
    "id" : 671125270011736064,
    "created_at" : "2015-11-30 00:35:07 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 671125622522007554,
  "created_at" : "2015-11-30 00:36:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671096109381488640",
  "text" : "RT @POTUS: Good news: the world now adds more clean power capacity each year than dirtier fossil-fuel based power capacity. https:\/\/t.co\/nr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/671094262826704896\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/nrNiwDAKuN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CVA0q8DWEAArvm0.jpg",
        "id_str" : "671094256757510144",
        "id" : 671094256757510144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CVA0q8DWEAArvm0.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/nrNiwDAKuN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671094262826704896",
    "text" : "Good news: the world now adds more clean power capacity each year than dirtier fossil-fuel based power capacity. https:\/\/t.co\/nrNiwDAKuN",
    "id" : 671094262826704896,
    "created_at" : "2015-11-29 22:31:55 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 671096109381488640,
  "created_at" : "2015-11-29 22:39:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    }, {
      "text" : "COP21",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/cUFZym1leo",
      "expanded_url" : "http:\/\/snpy.tv\/1NqlGAS",
      "display_url" : "snpy.tv\/1NqlGAS"
    } ]
  },
  "geo" : { },
  "id_str" : "671050111259045889",
  "text" : "\"What a powerful rebuke to the terrorists it will be when the world stands as one\u201D \u2014@POTUS #ActOnClimate #COP21 https:\/\/t.co\/cUFZym1leo",
  "id" : 671050111259045889,
  "created_at" : "2015-11-29 19:36:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/671023184624291840\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/uKzR16Azoh",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CU_z2QvUwAA6tNo.png",
      "id_str" : "671022983033438208",
      "id" : 671022983033438208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CU_z2QvUwAA6tNo.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uKzR16Azoh"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 32, 45 ]
    }, {
      "text" : "COP21",
      "indices" : [ 62, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/QscCX2BfYE",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "671023184624291840",
  "text" : "America is leading the world to #ActOnClimate as we head into #COP21 \u2192 https:\/\/t.co\/QscCX2BfYE https:\/\/t.co\/uKzR16Azoh",
  "id" : 671023184624291840,
  "created_at" : "2015-11-29 17:49:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 90, 103 ]
    }, {
      "text" : "COP21",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/uLtVMN2A7C",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "671015825155956736",
  "text" : "RT @FactsOnClimate: Nations representing nearly 95% of global emissions have committed to #ActOnClimate: https:\/\/t.co\/uLtVMN2A7C #COP21 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/671014992540540928\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/X8sSaI1jNw",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CU_shkNWcAAxtcI.png",
        "id_str" : "671014930901004288",
        "id" : 671014930901004288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CU_shkNWcAAxtcI.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/X8sSaI1jNw"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 70, 83 ]
      }, {
        "text" : "COP21",
        "indices" : [ 109, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/uLtVMN2A7C",
        "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
        "display_url" : "go.wh.gov\/ClimateTalks"
      } ]
    },
    "geo" : { },
    "id_str" : "671014992540540928",
    "text" : "Nations representing nearly 95% of global emissions have committed to #ActOnClimate: https:\/\/t.co\/uLtVMN2A7C #COP21 https:\/\/t.co\/X8sSaI1jNw",
    "id" : 671014992540540928,
    "created_at" : "2015-11-29 17:16:55 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 671015825155956736,
  "created_at" : "2015-11-29 17:20:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/670996672139276288\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zOFmr9Z6Wz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU_bpYGUEAABOhq.png",
      "id_str" : "670996373391544320",
      "id" : 670996373391544320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU_bpYGUEAABOhq.png",
      "sizes" : [ {
        "h" : 625,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 616
      } ],
      "display_url" : "pic.twitter.com\/zOFmr9Z6Wz"
    } ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/QscCX2BfYE",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "670996672139276288",
  "text" : ".@POTUS is headed to Paris for the global climate change conference.\nFollow along \u2192 https:\/\/t.co\/QscCX2BfYE #COP21 https:\/\/t.co\/zOFmr9Z6Wz",
  "id" : 670996672139276288,
  "created_at" : "2015-11-29 16:04:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHolidays",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/ZGLyhpkAmS",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/58263c0f-ed0a-446e-9760-10dafacd3c4f",
      "display_url" : "amp.twimg.com\/v\/58263c0f-ed0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "670799600727494656",
  "text" : "RT @FLOTUS: The @WhiteHouse Christmas tree has arrived! #WHHolidays\nhttps:\/\/t.co\/ZGLyhpkAmS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHolidays",
        "indices" : [ 44, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/ZGLyhpkAmS",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/58263c0f-ed0a-446e-9760-10dafacd3c4f",
        "display_url" : "amp.twimg.com\/v\/58263c0f-ed0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670781136109355008",
    "text" : "The @WhiteHouse Christmas tree has arrived! #WHHolidays\nhttps:\/\/t.co\/ZGLyhpkAmS",
    "id" : 670781136109355008,
    "created_at" : "2015-11-29 01:47:40 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 670799600727494656,
  "created_at" : "2015-11-29 03:01:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Franklins Brewery",
      "screen_name" : "FranklinsBrwry",
      "indices" : [ 35, 50 ],
      "id_str" : "529073236",
      "id" : 529073236
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DineSmall",
      "indices" : [ 109, 119 ]
    }, {
      "text" : "ShopSmall",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670780997005385729",
  "text" : "RT @LaborSec: Had a great lunch at @FranklinsBrwry, one of my favorite local establishments. Don\u2019t forget to #DineSmall &amp; #ShopSmall today!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Franklins Brewery",
        "screen_name" : "FranklinsBrwry",
        "indices" : [ 21, 36 ],
        "id_str" : "529073236",
        "id" : 529073236
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DineSmall",
        "indices" : [ 95, 105 ]
      }, {
        "text" : "ShopSmall",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670695365012795392",
    "text" : "Had a great lunch at @FranklinsBrwry, one of my favorite local establishments. Don\u2019t forget to #DineSmall &amp; #ShopSmall today!",
    "id" : 670695365012795392,
    "created_at" : "2015-11-28 20:06:50 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 670780997005385729,
  "created_at" : "2015-11-29 01:47:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670746817450020864",
  "text" : "RT @POTUS: Enjoyed stopping by Upshur Street Books today. Celebrate Small Business Saturday by supporting a business near you. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/670745089975721984\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/udTcIhxtOC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7292FWsAAYkhx.jpg",
        "id_str" : "670744936875208704",
        "id" : 670744936875208704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7292FWsAAYkhx.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/udTcIhxtOC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670745089975721984",
    "text" : "Enjoyed stopping by Upshur Street Books today. Celebrate Small Business Saturday by supporting a business near you. https:\/\/t.co\/udTcIhxtOC",
    "id" : 670745089975721984,
    "created_at" : "2015-11-28 23:24:25 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 670746817450020864,
  "created_at" : "2015-11-28 23:31:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSaturday",
      "indices" : [ 29, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670740077069365248",
  "text" : "RT @ErnestMoniz: Celebrating #SmallBizSaturday at Shimon's Service Station in Brookline, MA. Falling gas prices 3 years running! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/670728288575340545\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/x8xRRM7vTh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7n0u-VEAAwsA8.jpg",
        "id_str" : "670728287673454592",
        "id" : 670728287673454592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7n0u-VEAAwsA8.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/x8xRRM7vTh"
      } ],
      "hashtags" : [ {
        "text" : "SmallBizSaturday",
        "indices" : [ 12, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670728288575340545",
    "text" : "Celebrating #SmallBizSaturday at Shimon's Service Station in Brookline, MA. Falling gas prices 3 years running! https:\/\/t.co\/x8xRRM7vTh",
    "id" : 670728288575340545,
    "created_at" : "2015-11-28 22:17:40 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 670740077069365248,
  "created_at" : "2015-11-28 23:04:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "57th Street Boo!",
      "screen_name" : "57thstreetbooks",
      "indices" : [ 38, 54 ],
      "id_str" : "3130341674",
      "id" : 3130341674
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSaturday",
      "indices" : [ 104, 121 ]
    }, {
      "text" : "shopsmall",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670739172458684416",
  "text" : "RT @arneduncan: Went book shopping at @57thstreetbooks and got my haircut at University barber shop for #SmallBizSaturday #shopsmall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "57th Street Boo!",
        "screen_name" : "57thstreetbooks",
        "indices" : [ 22, 38 ],
        "id_str" : "3130341674",
        "id" : 3130341674
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSaturday",
        "indices" : [ 88, 105 ]
      }, {
        "text" : "shopsmall",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670723517395173376",
    "text" : "Went book shopping at @57thstreetbooks and got my haircut at University barber shop for #SmallBizSaturday #shopsmall",
    "id" : 670723517395173376,
    "created_at" : "2015-11-28 21:58:42 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 670739172458684416,
  "created_at" : "2015-11-28 23:00:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Pleasant Pops",
      "screen_name" : "pleasantpops",
      "indices" : [ 41, 54 ],
      "id_str" : "54905208",
      "id" : 54905208
    }, {
      "name" : "Upshur Street Books",
      "screen_name" : "UpshurStBooks",
      "indices" : [ 59, 73 ],
      "id_str" : "2482685490",
      "id" : 2482685490
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/670734216381005824\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/zlJUXhNJkH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7tK5lWsAA5SNH.jpg",
      "id_str" : "670734166036754432",
      "id" : 670734166036754432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7tK5lWsAA5SNH.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/zlJUXhNJkH"
    } ],
    "hashtags" : [ {
      "text" : "SmallBizSaturday",
      "indices" : [ 5, 22 ]
    }, {
      "text" : "ShopSmall",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/AsD6YNkHwN",
      "expanded_url" : "http:\/\/go.wh.gov\/jWdi81",
      "display_url" : "go.wh.gov\/jWdi81"
    } ]
  },
  "geo" : { },
  "id_str" : "670734216381005824",
  "text" : "It's #SmallBizSaturday! @POTUS headed to @PleasantPops and @UpshurStBooks to #ShopSmall. https:\/\/t.co\/AsD6YNkHwN https:\/\/t.co\/zlJUXhNJkH",
  "id" : 670734216381005824,
  "created_at" : "2015-11-28 22:41:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PennyPritzker\/status\/670412294963134464\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/iKdGVegtdE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU3IaW8UYAAo9j4.jpg",
      "id_str" : "670412274708799488",
      "id" : 670412274708799488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU3IaW8UYAAo9j4.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/iKdGVegtdE"
    } ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 73, 85 ]
    }, {
      "text" : "shopsmall",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670733166315970560",
  "text" : "RT @PennyPritzker: Getting ready for Small Business Saturday at Del Sol. #SmallBizSat #shopsmall https:\/\/t.co\/iKdGVegtdE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PennyPritzker\/status\/670412294963134464\/photo\/1",
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/iKdGVegtdE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU3IaW8UYAAo9j4.jpg",
        "id_str" : "670412274708799488",
        "id" : 670412274708799488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU3IaW8UYAAo9j4.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/iKdGVegtdE"
      } ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 54, 66 ]
      }, {
        "text" : "shopsmall",
        "indices" : [ 67, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670412294963134464",
    "text" : "Getting ready for Small Business Saturday at Del Sol. #SmallBizSat #shopsmall https:\/\/t.co\/iKdGVegtdE",
    "id" : 670412294963134464,
    "created_at" : "2015-11-28 01:22:01 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 670733166315970560,
  "created_at" : "2015-11-28 22:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GSA",
      "screen_name" : "USGSA",
      "indices" : [ 3, 9 ],
      "id_str" : "61583656",
      "id" : 61583656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670724815679041537",
  "text" : "RT @USGSA: Happy #SmallBizSat! Our Ast Administrator Jerome Fletcher visited his local donut shop. Where will you shop small? https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USGSA\/status\/670648828912115713\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/yDyLIxqtKT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6fjRpUAAEbhWK.jpg",
        "id_str" : "670648822905700353",
        "id" : 670648822905700353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6fjRpUAAEbhWK.jpg",
        "sizes" : [ {
          "h" : 582,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/yDyLIxqtKT"
      } ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 6, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670648828912115713",
    "text" : "Happy #SmallBizSat! Our Ast Administrator Jerome Fletcher visited his local donut shop. Where will you shop small? https:\/\/t.co\/yDyLIxqtKT",
    "id" : 670648828912115713,
    "created_at" : "2015-11-28 17:01:55 +0000",
    "user" : {
      "name" : "GSA",
      "screen_name" : "USGSA",
      "protected" : false,
      "id_str" : "61583656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660125084967825409\/XFGGkgQc_normal.png",
      "id" : 61583656,
      "verified" : true
    }
  },
  "id" : 670724815679041537,
  "created_at" : "2015-11-28 22:03:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    }, {
      "name" : "Wankel's Hardware",
      "screen_name" : "wankelshardware",
      "indices" : [ 22, 38 ],
      "id_str" : "92989542",
      "id" : 92989542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670719662620061698",
  "text" : "RT @AmbassadorPower: .@wankelshardware has served NY-ers since 1890. VP Sean Wankel says 15 of 20 employees are refugees. #SmallBizSat http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wankel's Hardware",
        "screen_name" : "wankelshardware",
        "indices" : [ 1, 17 ],
        "id_str" : "92989542",
        "id" : 92989542
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmbassadorPower\/status\/670709009523957760\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/m0ujGQseMj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7WSH1VAAELoBB.jpg",
        "id_str" : "670709001353494529",
        "id" : 670709001353494529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7WSH1VAAELoBB.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/m0ujGQseMj"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AmbassadorPower\/status\/670709009523957760\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/m0ujGQseMj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7WSH2UAAAQsvU.jpg",
        "id_str" : "670709001357623296",
        "id" : 670709001357623296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7WSH2UAAAQsvU.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/m0ujGQseMj"
      } ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670709009523957760",
    "text" : ".@wankelshardware has served NY-ers since 1890. VP Sean Wankel says 15 of 20 employees are refugees. #SmallBizSat https:\/\/t.co\/m0ujGQseMj",
    "id" : 670709009523957760,
    "created_at" : "2015-11-28 21:01:03 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 670719662620061698,
  "created_at" : "2015-11-28 21:43:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria ContrerasSweet",
      "screen_name" : "MCS4Biz",
      "indices" : [ 3, 11 ],
      "id_str" : "2485930448",
      "id" : 2485930448
    }, {
      "name" : "Soaptopia",
      "screen_name" : "Soaptopia",
      "indices" : [ 89, 99 ],
      "id_str" : "40160835",
      "id" : 40160835
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSaturday",
      "indices" : [ 16, 33 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670716929095651329",
  "text" : "RT @MCS4Biz: On #SmallBizSaturday we celebrate entrepreneurs like Jolie, whose #smallbiz @Soaptopia is exporting to Japan https:\/\/t.co\/ntja\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Soaptopia",
        "screen_name" : "Soaptopia",
        "indices" : [ 76, 86 ],
        "id_str" : "40160835",
        "id" : 40160835
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MCS4Biz\/status\/670685494334717952\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/ntjagdttAP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7A5iHVAAEKHxw.jpg",
        "id_str" : "670685489167400961",
        "id" : 670685489167400961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7A5iHVAAEKHxw.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ntjagdttAP"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MCS4Biz\/status\/670685494334717952\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/ntjagdttAP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU7A5iJU8AASzuH.jpg",
        "id_str" : "670685489175785472",
        "id" : 670685489175785472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU7A5iJU8AASzuH.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ntjagdttAP"
      } ],
      "hashtags" : [ {
        "text" : "SmallBizSaturday",
        "indices" : [ 3, 20 ]
      }, {
        "text" : "smallbiz",
        "indices" : [ 66, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670685494334717952",
    "text" : "On #SmallBizSaturday we celebrate entrepreneurs like Jolie, whose #smallbiz @Soaptopia is exporting to Japan https:\/\/t.co\/ntjagdttAP",
    "id" : 670685494334717952,
    "created_at" : "2015-11-28 19:27:37 +0000",
    "user" : {
      "name" : "Maria ContrerasSweet",
      "screen_name" : "MCS4Biz",
      "protected" : false,
      "id_str" : "2485930448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466740000495640576\/SLRfKmW-_normal.png",
      "id" : 2485930448,
      "verified" : true
    }
  },
  "id" : 670716929095651329,
  "created_at" : "2015-11-28 21:32:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670690855024517126",
  "text" : "RT @NASA: Did you know that we buy products from small businesses? Including parts used on our Orion spacecraft. #SmallBizSat\nhttps:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/1v3QwWRJ74",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/d253b712-08cc-4d10-b4b4-410b93b34d2d",
        "display_url" : "amp.twimg.com\/v\/d253b712-08c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "670656438394490880",
    "text" : "Did you know that we buy products from small businesses? Including parts used on our Orion spacecraft. #SmallBizSat\nhttps:\/\/t.co\/1v3QwWRJ74",
    "id" : 670656438394490880,
    "created_at" : "2015-11-28 17:32:09 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 670690855024517126,
  "created_at" : "2015-11-28 19:48:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/670666223638679552\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/jYVW0zNCWT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6vXzXWEAI-xG4.jpg",
      "id_str" : "670666217984757762",
      "id" : 670666217984757762,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6vXzXWEAI-xG4.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jYVW0zNCWT"
    } ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 61, 73 ]
    }, {
      "text" : "DineSmall",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670675028954865664",
  "text" : "RT @vj44: Enjoyed a delicious cup of tea at Sip &amp; Savor! #SmallBizSat #DineSmall https:\/\/t.co\/jYVW0zNCWT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/670666223638679552\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/jYVW0zNCWT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6vXzXWEAI-xG4.jpg",
        "id_str" : "670666217984757762",
        "id" : 670666217984757762,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6vXzXWEAI-xG4.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jYVW0zNCWT"
      } ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 51, 63 ]
      }, {
        "text" : "DineSmall",
        "indices" : [ 64, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "670666223638679552",
    "text" : "Enjoyed a delicious cup of tea at Sip &amp; Savor! #SmallBizSat #DineSmall https:\/\/t.co\/jYVW0zNCWT",
    "id" : 670666223638679552,
    "created_at" : "2015-11-28 18:11:02 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 670675028954865664,
  "created_at" : "2015-11-28 18:46:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/670618648323690496\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/BfUkqdLyY8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CU6EA12W4AA0MjK.png",
      "id_str" : "670618544514719744",
      "id" : 670618544514719744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CU6EA12W4AA0MjK.png",
      "sizes" : [ {
        "h" : 265,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 914
      }, {
        "h" : 150,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 914
      } ],
      "display_url" : "pic.twitter.com\/BfUkqdLyY8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670618648323690496",
  "text" : "\"This is not normal. We can\u2019t let it become normal.\" \u2014@POTUS on the shooting in Colorado https:\/\/t.co\/BfUkqdLyY8",
  "id" : 670618648323690496,
  "created_at" : "2015-11-28 15:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/Jiwdvk8nII",
      "expanded_url" : "http:\/\/go.wh.gov\/HV9zee",
      "display_url" : "go.wh.gov\/HV9zee"
    } ]
  },
  "geo" : { },
  "id_str" : "670353928857325568",
  "text" : "\"What makes America America is that we offer that chance. We turn Lady Liberty\u2019s light to the world.\" \u2014@POTUS: https:\/\/t.co\/Jiwdvk8nII",
  "id" : 670353928857325568,
  "created_at" : "2015-11-27 21:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/670338840490446848\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/16Q6WfKbsy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUwQADvWIAA8WMB.jpg",
      "id_str" : "669928037761294336",
      "id" : 669928037761294336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUwQADvWIAA8WMB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/16Q6WfKbsy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/EQ6DpnMa62",
      "expanded_url" : "http:\/\/go.wh.gov\/GJdfHi",
      "display_url" : "go.wh.gov\/GJdfHi"
    } ]
  },
  "geo" : { },
  "id_str" : "670338840490446848",
  "text" : "\"Nearly four centuries after the Mayflower set sail, the world is still full of pilgrims.\" https:\/\/t.co\/EQ6DpnMa62 https:\/\/t.co\/16Q6WfKbsy",
  "id" : 670338840490446848,
  "created_at" : "2015-11-27 20:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Jiwdvk8nII",
      "expanded_url" : "http:\/\/go.wh.gov\/HV9zee",
      "display_url" : "go.wh.gov\/HV9zee"
    } ]
  },
  "geo" : { },
  "id_str" : "670304081362092032",
  "text" : "\"No refugee can enter our borders until they undergo the highest security checks of anyone traveling to the U.S.\" https:\/\/t.co\/Jiwdvk8nII",
  "id" : 670304081362092032,
  "created_at" : "2015-11-27 18:12:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Jiwdvk8nII",
      "expanded_url" : "http:\/\/go.wh.gov\/HV9zee",
      "display_url" : "go.wh.gov\/HV9zee"
    } ]
  },
  "geo" : { },
  "id_str" : "670288999840247808",
  "text" : "\"I\u2019ve been touched by the generosity of the Americans who\u2019ve written me...offering to open their homes to refugees.\" https:\/\/t.co\/Jiwdvk8nII",
  "id" : 670288999840247808,
  "created_at" : "2015-11-27 17:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Jiwdvk8nII",
      "expanded_url" : "http:\/\/go.wh.gov\/HV9zee",
      "display_url" : "go.wh.gov\/HV9zee"
    } ]
  },
  "geo" : { },
  "id_str" : "670005134533857280",
  "text" : "\"I hope that you and your family have a wonderful Thanksgiving, surrounded by loved ones, and full of joy.\" \u2014@POTUS: https:\/\/t.co\/Jiwdvk8nII",
  "id" : 670005134533857280,
  "created_at" : "2015-11-26 22:24:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Jiwdvk8nII",
      "expanded_url" : "http:\/\/go.wh.gov\/HV9zee",
      "display_url" : "go.wh.gov\/HV9zee"
    } ]
  },
  "geo" : { },
  "id_str" : "669950033471508480",
  "text" : "\"On this uniquely American holiday we also remember that so much of our greatness comes from our generosity\" \u2014@POTUS https:\/\/t.co\/Jiwdvk8nII",
  "id" : 669950033471508480,
  "created_at" : "2015-11-26 18:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/669931261574701056\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/hw8Aux6HWQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUwS7qBWEAAiMDc.jpg",
      "id_str" : "669931260672872448",
      "id" : 669931260672872448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUwS7qBWEAAiMDc.jpg",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 983,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hw8Aux6HWQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/pNCOFGLqJB",
      "expanded_url" : "http:\/\/bit.ly\/1MFQIB6",
      "display_url" : "bit.ly\/1MFQIB6"
    } ]
  },
  "geo" : { },
  "id_str" : "669940744036196352",
  "text" : "RT @petesouza: President Obama makes Thanksgiving phone calls to U.S. troops: https:\/\/t.co\/pNCOFGLqJB https:\/\/t.co\/hw8Aux6HWQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/669931261574701056\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/hw8Aux6HWQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUwS7qBWEAAiMDc.jpg",
        "id_str" : "669931260672872448",
        "id" : 669931260672872448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUwS7qBWEAAiMDc.jpg",
        "sizes" : [ {
          "h" : 393,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 983,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hw8Aux6HWQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/pNCOFGLqJB",
        "expanded_url" : "http:\/\/bit.ly\/1MFQIB6",
        "display_url" : "bit.ly\/1MFQIB6"
      } ]
    },
    "geo" : { },
    "id_str" : "669931261574701056",
    "text" : "President Obama makes Thanksgiving phone calls to U.S. troops: https:\/\/t.co\/pNCOFGLqJB https:\/\/t.co\/hw8Aux6HWQ",
    "id" : 669931261574701056,
    "created_at" : "2015-11-26 17:30:34 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 669940744036196352,
  "created_at" : "2015-11-26 18:08:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/669933979638718464\/photo\/1",
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/aGzXpfcvDb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUwTmWGXIAAfi4o.jpg",
      "id_str" : "669931994059579392",
      "id" : 669931994059579392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUwTmWGXIAAfi4o.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aGzXpfcvDb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669933979638718464",
  "text" : "Happy Thanksgiving! https:\/\/t.co\/aGzXpfcvDb",
  "id" : 669933979638718464,
  "created_at" : "2015-11-26 17:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669925552615100416",
  "text" : "RT @POTUS: Happy Thanksgiving, everyone! Today, we give thanks for all of our loved ones and the brave men and women in uniform who serve o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669923936574922752",
    "text" : "Happy Thanksgiving, everyone! Today, we give thanks for all of our loved ones and the brave men and women in uniform who serve our country.",
    "id" : 669923936574922752,
    "created_at" : "2015-11-26 17:01:27 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 669925552615100416,
  "created_at" : "2015-11-26 17:07:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/669919646074724352\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/uNhX35E5hq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUwIXN9WcAECgVQ.jpg",
      "id_str" : "669919639548358657",
      "id" : 669919639548358657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUwIXN9WcAECgVQ.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uNhX35E5hq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669921031226851329",
  "text" : "RT @FLOTUS: Today is a reminder to be thankful for what we have, and share our blessings by helping others. \u2013mo https:\/\/t.co\/uNhX35E5hq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/669919646074724352\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/uNhX35E5hq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUwIXN9WcAECgVQ.jpg",
        "id_str" : "669919639548358657",
        "id" : 669919639548358657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUwIXN9WcAECgVQ.jpg",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uNhX35E5hq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669919646074724352",
    "text" : "Today is a reminder to be thankful for what we have, and share our blessings by helping others. \u2013mo https:\/\/t.co\/uNhX35E5hq",
    "id" : 669919646074724352,
    "created_at" : "2015-11-26 16:44:24 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 669921031226851329,
  "created_at" : "2015-11-26 16:49:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/JiwdvkpZ7i",
      "expanded_url" : "http:\/\/go.wh.gov\/HV9zee",
      "display_url" : "go.wh.gov\/HV9zee"
    } ]
  },
  "geo" : { },
  "id_str" : "669914118175006720",
  "text" : "From the Obama family to yours, have a great Thanksgiving: https:\/\/t.co\/JiwdvkpZ7i",
  "id" : 669914118175006720,
  "created_at" : "2015-11-26 16:22:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/669665940129390592\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/QRAqO5PnaC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUshCuVWEAEPhl3.png",
      "id_str" : "669665300275662849",
      "id" : 669665300275662849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUshCuVWEAEPhl3.png",
      "sizes" : [ {
        "h" : 140,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 491
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 491
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 491
      } ],
      "display_url" : "pic.twitter.com\/QRAqO5PnaC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/CJ93od5PXO",
      "expanded_url" : "http:\/\/on.fb.me\/1PavsaB",
      "display_url" : "on.fb.me\/1PavsaB"
    } ]
  },
  "geo" : { },
  "id_str" : "669665940129390592",
  "text" : ".@POTUS on the tragic shooting of 17-year-old Laquan McDonald: https:\/\/t.co\/CJ93od5PXO https:\/\/t.co\/QRAqO5PnaC",
  "id" : 669665940129390592,
  "created_at" : "2015-11-25 23:56:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gloria Estefan",
      "screen_name" : "GloriaEstefan",
      "indices" : [ 6, 20 ],
      "id_str" : "270005881",
      "id" : 270005881
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 95, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/jqO0NVPxyu",
      "expanded_url" : "http:\/\/go.wh.gov\/MedalOfFreedom",
      "display_url" : "go.wh.gov\/MedalOfFreedom"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/jY5eLpnfhy",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f7a7c962-16ca-43f4-b9a0-adc5fa7da9db",
      "display_url" : "amp.twimg.com\/v\/f7a7c962-16c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "669643474589749248",
  "text" : "Watch @GloriaEstefan tell the story of how her family came to America: https:\/\/t.co\/jqO0NVPxyu #RefugeesWelcome\nhttps:\/\/t.co\/jY5eLpnfhy",
  "id" : 669643474589749248,
  "created_at" : "2015-11-25 22:27:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/669630406744932352\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/V9MN0hAU8Z",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CUsAV4qWcAAubso.png",
      "id_str" : "669629345581920256",
      "id" : 669629345581920256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CUsAV4qWcAAubso.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/V9MN0hAU8Z"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 57, 70 ]
    }, {
      "text" : "COP21",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/uLtVMNkaZa",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
      "display_url" : "go.wh.gov\/ClimateTalks"
    } ]
  },
  "geo" : { },
  "id_str" : "669630864830160896",
  "text" : "RT @FactsOnClimate: Here's what the world stepping up to #ActOnClimate looks like \u2192 https:\/\/t.co\/uLtVMNkaZa #COP21 https:\/\/t.co\/V9MN0hAU8Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/669630406744932352\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/V9MN0hAU8Z",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CUsAV4qWcAAubso.png",
        "id_str" : "669629345581920256",
        "id" : 669629345581920256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CUsAV4qWcAAubso.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/V9MN0hAU8Z"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 37, 50 ]
      }, {
        "text" : "COP21",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/uLtVMNkaZa",
        "expanded_url" : "http:\/\/go.wh.gov\/ClimateTalks",
        "display_url" : "go.wh.gov\/ClimateTalks"
      } ]
    },
    "in_reply_to_status_id_str" : "669628807016538112",
    "geo" : { },
    "id_str" : "669630406744932352",
    "in_reply_to_user_id" : 3907577966,
    "text" : "Here's what the world stepping up to #ActOnClimate looks like \u2192 https:\/\/t.co\/uLtVMNkaZa #COP21 https:\/\/t.co\/V9MN0hAU8Z",
    "id" : 669630406744932352,
    "in_reply_to_status_id" : 669628807016538112,
    "created_at" : "2015-11-25 21:35:04 +0000",
    "in_reply_to_screen_name" : "FactsOnClimate",
    "in_reply_to_user_id_str" : "3907577966",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 669630864830160896,
  "created_at" : "2015-11-25 21:36:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GivingBack",
      "indices" : [ 25, 36 ]
    }, {
      "text" : "volunteer",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/5TpOuQcy45",
      "expanded_url" : "http:\/\/Serve.gov",
      "display_url" : "Serve.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "669619897668800512",
  "text" : "RT @ServeDotGov: Are you #GivingBack during the Thanksgiving weekend? Find a #volunteer opportunity now on https:\/\/t.co\/5TpOuQcy45! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ServeDotGov\/status\/669543930267107328\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/NVy4A1iVmY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUqypf8UcAAe0Qr.jpg",
        "id_str" : "669543920636817408",
        "id" : 669543920636817408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUqypf8UcAAe0Qr.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 289,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NVy4A1iVmY"
      } ],
      "hashtags" : [ {
        "text" : "GivingBack",
        "indices" : [ 8, 19 ]
      }, {
        "text" : "volunteer",
        "indices" : [ 60, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/5TpOuQcy45",
        "expanded_url" : "http:\/\/Serve.gov",
        "display_url" : "Serve.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "669543930267107328",
    "text" : "Are you #GivingBack during the Thanksgiving weekend? Find a #volunteer opportunity now on https:\/\/t.co\/5TpOuQcy45! https:\/\/t.co\/NVy4A1iVmY",
    "id" : 669543930267107328,
    "created_at" : "2015-11-25 15:51:27 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 669619897668800512,
  "created_at" : "2015-11-25 20:53:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NatlTurkeyFederation",
      "screen_name" : "TurkeyGal",
      "indices" : [ 3, 13 ],
      "id_str" : "22919519",
      "id" : 22919519
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TurkeyGal\/status\/669603331212447744\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/XA4ytTckMx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUrorTTWsAAzDdz.jpg",
      "id_str" : "669603325231411200",
      "id" : 669603325231411200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUrorTTWsAAzDdz.jpg",
      "sizes" : [ {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/XA4ytTckMx"
    } ],
    "hashtags" : [ {
      "text" : "TurkeyPardon2015",
      "indices" : [ 54, 71 ]
    }, {
      "text" : "TeamAbe",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669609366744510464",
  "text" : "RT @TurkeyGal: Pleased to announce America's turkey!  #TurkeyPardon2015 #TeamAbe https:\/\/t.co\/XA4ytTckMx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TurkeyGal\/status\/669603331212447744\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/XA4ytTckMx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUrorTTWsAAzDdz.jpg",
        "id_str" : "669603325231411200",
        "id" : 669603325231411200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUrorTTWsAAzDdz.jpg",
        "sizes" : [ {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/XA4ytTckMx"
      } ],
      "hashtags" : [ {
        "text" : "TurkeyPardon2015",
        "indices" : [ 39, 56 ]
      }, {
        "text" : "TeamAbe",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669603331212447744",
    "text" : "Pleased to announce America's turkey!  #TurkeyPardon2015 #TeamAbe https:\/\/t.co\/XA4ytTckMx",
    "id" : 669603331212447744,
    "created_at" : "2015-11-25 19:47:29 +0000",
    "user" : {
      "name" : "NatlTurkeyFederation",
      "screen_name" : "TurkeyGal",
      "protected" : false,
      "id_str" : "22919519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2931591580\/2429469fa8cf336790f4900e69b90846_normal.jpeg",
      "id" : 22919519,
      "verified" : false
    }
  },
  "id" : 669609366744510464,
  "created_at" : "2015-11-25 20:11:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669604479549837312",
  "text" : "\u201CWe live in the greatest country on Earth, and we are blessed in so many ways.\u201D \u2014@POTUS wishing all Americans a Happy Thanksgiving",
  "id" : 669604479549837312,
  "created_at" : "2015-11-25 19:52:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/HieTxgsF6Q",
      "expanded_url" : "http:\/\/go.wh.gov\/hSjZGG",
      "display_url" : "go.wh.gov\/hSjZGG"
    } ]
  },
  "geo" : { },
  "id_str" : "669603019948863488",
  "text" : "\u201CAbe is now a free bird. He is TOTUS\u2014the Turkey of the United States.\u201D \u2014@POTUS on the National Thanksgiving Turkey: https:\/\/t.co\/HieTxgsF6Q",
  "id" : 669603019948863488,
  "created_at" : "2015-11-25 19:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/HieTxgsF6Q",
      "expanded_url" : "http:\/\/go.wh.gov\/hSjZGG",
      "display_url" : "go.wh.gov\/hSjZGG"
    } ]
  },
  "geo" : { },
  "id_str" : "669602657523240961",
  "text" : "Watch live: @POTUS pardons the National Thanksgiving Turkey \u2192 https:\/\/t.co\/HieTxgsF6Q",
  "id" : 669602657523240961,
  "created_at" : "2015-11-25 19:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/YYfLjt8NXw",
      "expanded_url" : "http:\/\/snpy.tv\/1QIrd6j",
      "display_url" : "snpy.tv\/1QIrd6j"
    } ]
  },
  "geo" : { },
  "id_str" : "669578832022605824",
  "text" : "\"We are both equipped to prevent attacks, and resilient in the face of those who would try to do us harm.\"\u2014@POTUS  https:\/\/t.co\/YYfLjt8NXw",
  "id" : 669578832022605824,
  "created_at" : "2015-11-25 18:10:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/YYfLjsRd5Y",
      "expanded_url" : "http:\/\/snpy.tv\/1QIrd6j",
      "display_url" : "snpy.tv\/1QIrd6j"
    } ]
  },
  "geo" : { },
  "id_str" : "669569118903910401",
  "text" : "Watch @POTUS give an update on our safety and security after meeting with his Homeland Security Team. https:\/\/t.co\/YYfLjsRd5Y",
  "id" : 669569118903910401,
  "created_at" : "2015-11-25 17:31:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669563295041495040",
  "text" : "\"We are both equipped to prevent attacks, and resilient in the face of those who would try to do us harm.\" \u2014@POTUS",
  "id" : 669563295041495040,
  "created_at" : "2015-11-25 17:08:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669562900160344065",
  "text" : "\"Our counterterrorism, intelligence, homeland security, and law enforcement professionals at every level are working overtime.\" \u2014@POTUS",
  "id" : 669562900160344065,
  "created_at" : "2015-11-25 17:06:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669562576100073472",
  "text" : "\"We will not let up\u2014adjusting our tactics where necessary\u2014until they are beaten.\u201D \u2014@POTUS on strategy to degrade and destroy ISIL",
  "id" : 669562576100073472,
  "created_at" : "2015-11-25 17:05:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/669562408134975489\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/f9wDAH3T3x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUrDdXbWsAA-6OM.jpg",
      "id_str" : "669562403890311168",
      "id" : 669562403890311168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUrDdXbWsAA-6OM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/f9wDAH3T3x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669562408134975489",
  "text" : "\"We are going after ISIL wherever it hides.\" \u2014@POTUS on strategy to degrade and destroy ISIL https:\/\/t.co\/f9wDAH3T3x",
  "id" : 669562408134975489,
  "created_at" : "2015-11-25 17:04:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669562289457115136",
  "text" : "\"What I want the American people to know is that we\u2019re taking every step possible to keep our homeland safe.\" \u2014@POTUS",
  "id" : 669562289457115136,
  "created_at" : "2015-11-25 17:04:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/4zPvbQMEbo",
      "expanded_url" : "http:\/\/go.wh.gov\/jKE9wP",
      "display_url" : "go.wh.gov\/jKE9wP"
    } ]
  },
  "geo" : { },
  "id_str" : "669561790888448001",
  "text" : "Watch live as @POTUS delivers a statement from the White House \u2192 https:\/\/t.co\/4zPvbQMEbo",
  "id" : 669561790888448001,
  "created_at" : "2015-11-25 17:02:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/4zPvbR4fzY",
      "expanded_url" : "http:\/\/go.wh.gov\/jKE9wP",
      "display_url" : "go.wh.gov\/jKE9wP"
    } ]
  },
  "geo" : { },
  "id_str" : "669554150485676032",
  "text" : "At 11:40am ET, @POTUS will deliver a statement from the White House. Watch here \u2192 https:\/\/t.co\/4zPvbR4fzY",
  "id" : 669554150485676032,
  "created_at" : "2015-11-25 16:32:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 59, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/GrkLsyuYuB",
      "expanded_url" : "http:\/\/snpy.tv\/1TdunNS",
      "display_url" : "snpy.tv\/1TdunNS"
    } ]
  },
  "geo" : { },
  "id_str" : "669304664320552960",
  "text" : "Watch as @POTUS awards 17 extraordinary Americans with the #MedalOfFreedom, our nation's highest civilian honor. https:\/\/t.co\/GrkLsyuYuB",
  "id" : 669304664320552960,
  "created_at" : "2015-11-25 00:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669280037951152128",
  "text" : "\u201CIn her 33 years at NASA, Katherine was a pioneer who broke the barriers of race and gender\" \u2014@POTUS on Katherine Johnson #MedalOfFreedom",
  "id" : 669280037951152128,
  "created_at" : "2015-11-24 22:22:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669279393810939905",
  "text" : "\u201CWe celebrate extraordinary people\u2014innovators, artists and leaders\u2014who contribute to America\u2019s strength as a nation\" \u2014@POTUS #MedalOfFreedom",
  "id" : 669279393810939905,
  "created_at" : "2015-11-24 22:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/669279090726313984\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Oiy7gYWSsk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUnBvjgWIAAhGPe.jpg",
      "id_str" : "669279042370150400",
      "id" : 669279042370150400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUnBvjgWIAAhGPe.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Oiy7gYWSsk"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 45, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/jqO0NW78X4",
      "expanded_url" : "http:\/\/go.wh.gov\/MedalOfFreedom",
      "display_url" : "go.wh.gov\/MedalOfFreedom"
    } ]
  },
  "geo" : { },
  "id_str" : "669279090726313984",
  "text" : "Watch live as @POTUS awards the Presidential #MedalOfFreedom \u2192 https:\/\/t.co\/jqO0NW78X4 https:\/\/t.co\/Oiy7gYWSsk",
  "id" : 669279090726313984,
  "created_at" : "2015-11-24 22:19:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Berra",
      "screen_name" : "lindsayberra",
      "indices" : [ 3, 16 ],
      "id_str" : "113450686",
      "id" : 113450686
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669268063901061120",
  "text" : "RT @lindsayberra: The @WhiteHouse announced Grampa will posthumously recieve Medal of Freedom. Bittersweet, but could not be more proud! #Y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Yankees",
        "indices" : [ 119, 127 ]
      }, {
        "text" : "YogiBerra",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666365262002823168",
    "text" : "The @WhiteHouse announced Grampa will posthumously recieve Medal of Freedom. Bittersweet, but could not be more proud! #Yankees #YogiBerra",
    "id" : 666365262002823168,
    "created_at" : "2015-11-16 21:20:33 +0000",
    "user" : {
      "name" : "Lindsay Berra",
      "screen_name" : "lindsayberra",
      "protected" : false,
      "id_str" : "113450686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788100574185189376\/wNSSo9RF_normal.jpg",
      "id" : 113450686,
      "verified" : true
    }
  },
  "id" : 669268063901061120,
  "created_at" : "2015-11-24 21:35:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/669264691756195840\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/1F1Dtxu7b8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUm0pg3WwAA4dJh.jpg",
      "id_str" : "669264644930977792",
      "id" : 669264644930977792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUm0pg3WwAA4dJh.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1F1Dtxu7b8"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 21, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/jqO0NW78X4",
      "expanded_url" : "http:\/\/go.wh.gov\/MedalOfFreedom",
      "display_url" : "go.wh.gov\/MedalOfFreedom"
    } ]
  },
  "geo" : { },
  "id_str" : "669264691756195840",
  "text" : "Meet these inspiring #MedalOfFreedom recipients from 2015 and years past: https:\/\/t.co\/jqO0NW78X4 https:\/\/t.co\/1F1Dtxu7b8",
  "id" : 669264691756195840,
  "created_at" : "2015-11-24 21:21:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Mikulski",
      "screen_name" : "SenatorBarb",
      "indices" : [ 3, 15 ],
      "id_str" : "132278386",
      "id" : 132278386
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669262982204022785",
  "text" : "RT @SenatorBarb: Humbled &amp; honored to be recognized today at White House by @POTUS w Presidential Medal of Freedom.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 63, 69 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669257844877828098",
    "text" : "Humbled &amp; honored to be recognized today at White House by @POTUS w Presidential Medal of Freedom.",
    "id" : 669257844877828098,
    "created_at" : "2015-11-24 20:54:39 +0000",
    "user" : {
      "name" : "Barbara Mikulski",
      "screen_name" : "SenatorBarb",
      "protected" : false,
      "id_str" : "132278386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000022234700\/36ab4124ca43bb8a96b1c26c32c55ddf_normal.jpeg",
      "id" : 132278386,
      "verified" : true
    }
  },
  "id" : 669262982204022785,
  "created_at" : "2015-11-24 21:15:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NatlTurkeyFederation",
      "screen_name" : "TurkeyGal",
      "indices" : [ 3, 13 ],
      "id_str" : "22919519",
      "id" : 22919519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TurkeyPardon2015",
      "indices" : [ 103, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669250720076550144",
  "text" : "RT @TurkeyGal: Vote for the National Thanksgiving Turkey that President Obama will \nannounce tomorrow. #TurkeyPardon2015",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TurkeyPardon2015",
        "indices" : [ 88, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669199231199092736",
    "text" : "Vote for the National Thanksgiving Turkey that President Obama will \nannounce tomorrow. #TurkeyPardon2015",
    "id" : 669199231199092736,
    "created_at" : "2015-11-24 17:01:44 +0000",
    "user" : {
      "name" : "NatlTurkeyFederation",
      "screen_name" : "TurkeyGal",
      "protected" : false,
      "id_str" : "22919519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2931591580\/2429469fa8cf336790f4900e69b90846_normal.jpeg",
      "id" : 22919519,
      "verified" : false
    }
  },
  "id" : 669250720076550144,
  "created_at" : "2015-11-24 20:26:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669240946408689664",
  "text" : "RT @GinaEPA: We've come a long way in protecting our planet. At #COP21 climate talks I'm confident we can reach global agreement. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "COP21",
        "indices" : [ 51, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/N49Th28n1E",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=RRLOrjuegPU",
        "display_url" : "youtube.com\/watch?v=RRLOrj\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "669237785296027648",
    "text" : "We've come a long way in protecting our planet. At #COP21 climate talks I'm confident we can reach global agreement. https:\/\/t.co\/N49Th28n1E",
    "id" : 669237785296027648,
    "created_at" : "2015-11-24 19:34:56 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 669240946408689664,
  "created_at" : "2015-11-24 19:47:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcia Snyder",
      "screen_name" : "GovSteveBeshear",
      "indices" : [ 3, 19 ],
      "id_str" : "4549215252",
      "id" : 4549215252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669236324021440514",
  "text" : "RT @GovSteveBeshear: I\u2019ve signed an EO that automatically restores the right to vote &amp; hold public office to certain offenders who\u2019ve serve\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "669172579723288577",
    "text" : "I\u2019ve signed an EO that automatically restores the right to vote &amp; hold public office to certain offenders who\u2019ve served out their sentences",
    "id" : 669172579723288577,
    "created_at" : "2015-11-24 15:15:50 +0000",
    "user" : {
      "name" : "Steve Beshear",
      "screen_name" : "Steve__Beshear",
      "protected" : false,
      "id_str" : "37656339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674302651681648640\/9IZtv6cB_normal.jpg",
      "id" : 37656339,
      "verified" : false
    }
  },
  "id" : 669236324021440514,
  "created_at" : "2015-11-24 19:29:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 25, 35 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/4S8yXdj4GA",
      "expanded_url" : "http:\/\/snpy.tv\/1QGkycL",
      "display_url" : "snpy.tv\/1QGkycL"
    } ]
  },
  "geo" : { },
  "id_str" : "669229519128141825",
  "text" : ".@POTUS speaks alongside @fhollande on our strategy to degrade and destroy ISIL. https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/4S8yXdj4GA",
  "id" : 669229519128141825,
  "created_at" : "2015-11-24 19:02:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/zQnflSy4C8",
      "expanded_url" : "http:\/\/snpy.tv\/1QGiTUE",
      "display_url" : "snpy.tv\/1QGiTUE"
    } ]
  },
  "geo" : { },
  "id_str" : "669212088137605120",
  "text" : "\"Each of us, all of us, must show that America is strengthened by people of every faith and background.\" \u2014@POTUS https:\/\/t.co\/zQnflSy4C8",
  "id" : 669212088137605120,
  "created_at" : "2015-11-24 17:52:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 111, 124 ]
    }, {
      "text" : "COP21",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669208483590483968",
  "text" : "RT @FactsOnClimate: \"What a powerful rebuke to the terrorists it will be when the world stands as one\u201D \u2014@POTUS #ActOnClimate #COP21 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 84, 90 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 91, 104 ]
      }, {
        "text" : "COP21",
        "indices" : [ 105, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/cf0UDaBB7e",
        "expanded_url" : "http:\/\/snpy.tv\/1NqlGAS",
        "display_url" : "snpy.tv\/1NqlGAS"
      } ]
    },
    "geo" : { },
    "id_str" : "669206791004270592",
    "text" : "\"What a powerful rebuke to the terrorists it will be when the world stands as one\u201D \u2014@POTUS #ActOnClimate #COP21 https:\/\/t.co\/cf0UDaBB7e",
    "id" : 669206791004270592,
    "created_at" : "2015-11-24 17:31:46 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 669208483590483968,
  "created_at" : "2015-11-24 17:38:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/Y2Rrhi1f22",
      "expanded_url" : "http:\/\/snpy.tv\/1QGh7Tg",
      "display_url" : "snpy.tv\/1QGh7Tg"
    } ]
  },
  "geo" : { },
  "id_str" : "669205626111832064",
  "text" : "\"We cannot &amp; we will not succumb to fear.\nNor can we allow fear to divide us.\nFor that\u2019s how terrorists win\u201D \u2014@POTUS https:\/\/t.co\/Y2Rrhi1f22",
  "id" : 669205626111832064,
  "created_at" : "2015-11-24 17:27:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/669202560226615296\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/pKMnk8RJUm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUl8JcIUkAAsDSD.jpg",
      "id_str" : "669202521252990976",
      "id" : 669202521252990976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUl8JcIUkAAsDSD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pKMnk8RJUm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669202560226615296",
  "text" : "\"Make no mistake, we will win and groups like ISIL will lose.\" \u2014@POTUS https:\/\/t.co\/pKMnk8RJUm",
  "id" : 669202560226615296,
  "created_at" : "2015-11-24 17:14:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669202437148966912",
  "text" : "\"Even as we are relentless in the face of evil, we draw on what\u2019s best in ourselves and in the character of our countries.\" \u2014@POTUS",
  "id" : 669202437148966912,
  "created_at" : "2015-11-24 17:14:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "COP21",
      "indices" : [ 120, 126 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669202300716589056",
  "text" : "\"We will not be deterred from building a better future we want for our children.\" \u2014@POTUS on the climate talks in Paris #COP21 #ActOnClimate",
  "id" : 669202300716589056,
  "created_at" : "2015-11-24 17:13:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    }, {
      "text" : "COP21",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669202204818063360",
  "text" : "\"Next week, I\u2019ll be joining President Hollande and world leaders in Paris for the global climate conference.\" \u2014@POTUS #ActOnClimate #COP21",
  "id" : 669202204818063360,
  "created_at" : "2015-11-24 17:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669202023070441472",
  "text" : "\"I want to salute the people of Paris for showing the world how to stay strong in the face of terrorism.\" \u2014@POTUS",
  "id" : 669202023070441472,
  "created_at" : "2015-11-24 17:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669201960780881920",
  "text" : "\"'Give me your tired, your poor, your huddled masses yearning to breathe free.' That\u2019s the spirit that makes us Americans.\" \u2014@POTUS",
  "id" : 669201960780881920,
  "created_at" : "2015-11-24 17:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/669201867247853569\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/SzexTF76zd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUl7g4QWoAErxrQ.jpg",
      "id_str" : "669201824428236801",
      "id" : 669201824428236801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUl7g4QWoAErxrQ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SzexTF76zd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669201867247853569",
  "text" : "\"Our humanitarian duty to help desperate refugees &amp; our duty to our security\u2014those duties go hand in hand.\" \u2014@POTUS https:\/\/t.co\/SzexTF76zd",
  "id" : 669201867247853569,
  "created_at" : "2015-11-24 17:12:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669201673244553216",
  "text" : "\"Each of us, all of us, must show that America is strengthened by people of every faith and every background.\" \u2014@POTUS",
  "id" : 669201673244553216,
  "created_at" : "2015-11-24 17:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669201481615220736",
  "text" : "\"Our actions have shown that we have too much resolve, and too much character. Americans will not be terrorized.\" \u2014@POTUS",
  "id" : 669201481615220736,
  "created_at" : "2015-11-24 17:10:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669201218921713665",
  "text" : "\"We cannot, and we will not succumb to fear. Nor can we allow fear to divide us. For that\u2019s how terrorists win.\u201D \u2014@POTUS",
  "id" : 669201218921713665,
  "created_at" : "2015-11-24 17:09:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669200946409431040",
  "text" : "\"I want you to know that we will continue to do everything in our power to defend our nation.\" \u2014@POTUS to the American people",
  "id" : 669200946409431040,
  "created_at" : "2015-11-24 17:08:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669200801907257348",
  "text" : "\"Francois and I understand that one of our greatest weapons in the fight against ISIL is the strength and resilience of our people.\" \u2014@POTUS",
  "id" : 669200801907257348,
  "created_at" : "2015-11-24 17:07:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669200314843664384",
  "text" : "\"More than 8,000 airstrikes\u2014combined with local partners on the ground\u2014have pushed ISIL back\u2026in both Iraq and Syria.\" \u2014@POTUS",
  "id" : 669200314843664384,
  "created_at" : "2015-11-24 17:06:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669199797916721153",
  "text" : "\"We have never forgotten how the French people stood with us after 9\/11. Today, we stand with you\u2014nous sommes tous Francais.\" \u2014@POTUS",
  "id" : 669199797916721153,
  "created_at" : "2015-11-24 17:03:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/669199362694754305\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kYEpO7YqWG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUl5QnsWsAI_J-R.jpg",
      "id_str" : "669199346081116162",
      "id" : 669199346081116162,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUl5QnsWsAI_J-R.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kYEpO7YqWG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669199362694754305",
  "text" : "\u201CIt cannot be tolerated. It must be destroyed. And we must do it together.\" \u2014@POTUS on ISIL https:\/\/t.co\/kYEpO7YqWG",
  "id" : 669199362694754305,
  "created_at" : "2015-11-24 17:02:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 92, 102 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669198952647032832",
  "text" : "\u201CAs Americans, we stand by our friends\u2014in good times and in bad\u2014no matter what.\u201D \u2014@POTUS to @fhollande",
  "id" : 669198952647032832,
  "created_at" : "2015-11-24 17:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 23, 33 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/yH96s4DHil",
      "expanded_url" : "http:\/\/go.wh.gov\/vj2opS",
      "display_url" : "go.wh.gov\/vj2opS"
    } ]
  },
  "geo" : { },
  "id_str" : "669198858782666753",
  "text" : "Watch live: @POTUS and @fhollande hold a joint press conference \u2192 https:\/\/t.co\/yH96s4DHil",
  "id" : 669198858782666753,
  "created_at" : "2015-11-24 17:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "indices" : [ 3, 8 ],
      "id_str" : "214112621",
      "id" : 214112621
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/attn\/status\/669184366262796288\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/DKle7oyZxj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUlrhmgWEAAPkPb.jpg",
      "id_str" : "669184244657295360",
      "id" : 669184244657295360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUlrhmgWEAAPkPb.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3000,
        "resize" : "fit",
        "w" : 5333
      } ],
      "display_url" : "pic.twitter.com\/DKle7oyZxj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/z22QBORddS",
      "expanded_url" : "http:\/\/on.fb.me\/1LxA5nb",
      "display_url" : "on.fb.me\/1LxA5nb"
    } ]
  },
  "geo" : { },
  "id_str" : "669187215675817988",
  "text" : "RT @attn: Next time you hear someone say Syrian refugees are dangerous, show them this.  https:\/\/t.co\/z22QBORddS https:\/\/t.co\/DKle7oyZxj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/attn\/status\/669184366262796288\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/DKle7oyZxj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUlrhmgWEAAPkPb.jpg",
        "id_str" : "669184244657295360",
        "id" : 669184244657295360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUlrhmgWEAAPkPb.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3000,
          "resize" : "fit",
          "w" : 5333
        } ],
        "display_url" : "pic.twitter.com\/DKle7oyZxj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/z22QBORddS",
        "expanded_url" : "http:\/\/on.fb.me\/1LxA5nb",
        "display_url" : "on.fb.me\/1LxA5nb"
      } ]
    },
    "geo" : { },
    "id_str" : "669184366262796288",
    "text" : "Next time you hear someone say Syrian refugees are dangerous, show them this.  https:\/\/t.co\/z22QBORddS https:\/\/t.co\/DKle7oyZxj",
    "id" : 669184366262796288,
    "created_at" : "2015-11-24 16:02:40 +0000",
    "user" : {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "protected" : false,
      "id_str" : "214112621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616387650560389120\/7dI5Ky0i_normal.jpg",
      "id" : 214112621,
      "verified" : true
    }
  },
  "id" : 669187215675817988,
  "created_at" : "2015-11-24 16:13:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VHByh4AeWv",
      "expanded_url" : "http:\/\/snpy.tv\/1N9PVtG",
      "display_url" : "snpy.tv\/1N9PVtG"
    } ]
  },
  "geo" : { },
  "id_str" : "669180003209318400",
  "text" : "There is no law on the books that prevents someone on a terror list from buying a weapon. Congress can change that. https:\/\/t.co\/VHByh4AeWv",
  "id" : 669180003209318400,
  "created_at" : "2015-11-24 15:45:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/XYmEK0PNWe",
      "expanded_url" : "http:\/\/snpy.tv\/1N9aMNT",
      "display_url" : "snpy.tv\/1N9aMNT"
    } ]
  },
  "geo" : { },
  "id_str" : "668938101214027776",
  "text" : "\"We don\u2019t change our institutions and our culture and our values because of them\" \u2014@POTUS on our fight against ISIL https:\/\/t.co\/XYmEK0PNWe",
  "id" : 668938101214027776,
  "created_at" : "2015-11-23 23:44:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pJWNzRjX4W",
      "expanded_url" : "http:\/\/snpy.tv\/1Nnj077",
      "display_url" : "snpy.tv\/1Nnj077"
    } ]
  },
  "geo" : { },
  "id_str" : "668925580436480000",
  "text" : "\"The process...takes between 18 to 24 months for somebody to be approved.\" \u2014@POTUS on welcoming refugees to the U.S. https:\/\/t.co\/pJWNzRjX4W",
  "id" : 668925580436480000,
  "created_at" : "2015-11-23 22:54:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/VHByh4AeWv",
      "expanded_url" : "http:\/\/snpy.tv\/1N9PVtG",
      "display_url" : "snpy.tv\/1N9PVtG"
    } ]
  },
  "geo" : { },
  "id_str" : "668913616054259712",
  "text" : "There is no law on the books that prevents someone on a terror list from buying a weapon.\n\nIt's time to change that. https:\/\/t.co\/VHByh4AeWv",
  "id" : 668913616054259712,
  "created_at" : "2015-11-23 22:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/TKydhhax7O",
      "expanded_url" : "http:\/\/www.stopbullying.gov\/",
      "display_url" : "stopbullying.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "668911360441491456",
  "text" : "RT @vj44: LGBTQ youth are often victims of bullying. Check out https:\/\/t.co\/TKydhhax7O to learn more about what we can all do. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/TKydhhax7O",
        "expanded_url" : "http:\/\/www.stopbullying.gov\/",
        "display_url" : "stopbullying.gov"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/0sBix2vMRl",
        "expanded_url" : "https:\/\/twitter.com\/ViolettaGolding\/status\/668903931016306688",
        "display_url" : "twitter.com\/ViolettaGoldin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668907327509151744",
    "text" : "LGBTQ youth are often victims of bullying. Check out https:\/\/t.co\/TKydhhax7O to learn more about what we can all do. https:\/\/t.co\/0sBix2vMRl",
    "id" : 668907327509151744,
    "created_at" : "2015-11-23 21:41:49 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 668911360441491456,
  "created_at" : "2015-11-23 21:57:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668907362472878080",
  "text" : "RT @SecretaryCastro: Up to 40 % of homeless youth are LGBT. LGBT persons are often rejected from their homes because of who they are. @Real\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "KiraAynDavis",
        "screen_name" : "RealKiraDavis",
        "indices" : [ 113, 127 ],
        "id_str" : "253872062",
        "id" : 253872062
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTchamps",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "668202032851869697",
    "geo" : { },
    "id_str" : "668901095616417797",
    "in_reply_to_user_id" : 253872062,
    "text" : "Up to 40 % of homeless youth are LGBT. LGBT persons are often rejected from their homes because of who they are. @RealKiraDavis #LGBTchamps",
    "id" : 668901095616417797,
    "in_reply_to_status_id" : 668202032851869697,
    "created_at" : "2015-11-23 21:17:03 +0000",
    "in_reply_to_screen_name" : "RealKiraDavis",
    "in_reply_to_user_id_str" : "253872062",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 668907362472878080,
  "created_at" : "2015-11-23 21:41:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Murray",
      "screen_name" : "MayorEdMurray",
      "indices" : [ 3, 17 ],
      "id_str" : "2173418911",
      "id" : 2173418911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayofDignity",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668885697768652800",
  "text" : "RT @MayorEdMurray: Refugees and Muslim community help homeless vets at #DayofDignity event. Seattle welcomes and supports all in need. \nhtt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DayofDignity",
        "indices" : [ 52, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/lKPGlLbW4o",
        "expanded_url" : "http:\/\/kuow.org\/post\/guess-whos-helping-seattle-homeless-veterans-syrian-refugees",
        "display_url" : "kuow.org\/post\/guess-who\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "668850404147359744",
    "text" : "Refugees and Muslim community help homeless vets at #DayofDignity event. Seattle welcomes and supports all in need. \nhttps:\/\/t.co\/lKPGlLbW4o",
    "id" : 668850404147359744,
    "created_at" : "2015-11-23 17:55:37 +0000",
    "user" : {
      "name" : "Ed Murray",
      "screen_name" : "MayorEdMurray",
      "protected" : false,
      "id_str" : "2173418911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655153920482738176\/w1gyKnvy_normal.jpg",
      "id" : 2173418911,
      "verified" : true
    }
  },
  "id" : 668885697768652800,
  "created_at" : "2015-11-23 20:15:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 94, 103 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VHByh4AeWv",
      "expanded_url" : "http:\/\/snpy.tv\/1N9PVtG",
      "display_url" : "snpy.tv\/1N9PVtG"
    } ]
  },
  "geo" : { },
  "id_str" : "668872138460372996",
  "text" : "\"Pass a law that prevents somebody...on a terror watch list from being able to buy a weapon\" \u2014@PressSec to Congress https:\/\/t.co\/VHByh4AeWv",
  "id" : 668872138460372996,
  "created_at" : "2015-11-23 19:21:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/IG9Flv2bk3",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/5e88a39d-b3fc-4d00-b350-6c9f799c6b5a",
      "display_url" : "amp.twimg.com\/v\/5e88a39d-b3f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668864074441060352",
  "text" : "Watch: Here are the key components of our strategy to degrade and destroy ISIL \u2192 https:\/\/t.co\/oDIQ2V3W6i\nhttps:\/\/t.co\/IG9Flv2bk3",
  "id" : 668864074441060352,
  "created_at" : "2015-11-23 18:49:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 95, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/pJWNzRjX4W",
      "expanded_url" : "http:\/\/snpy.tv\/1Nnj077",
      "display_url" : "snpy.tv\/1Nnj077"
    } ]
  },
  "geo" : { },
  "id_str" : "668849943680000001",
  "text" : ".@POTUS on how we can continue to welcome refugees while ensuring the safety of all Americans. #RefugeesWelcome https:\/\/t.co\/pJWNzRjX4W",
  "id" : 668849943680000001,
  "created_at" : "2015-11-23 17:53:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/pJWNzRjX4W",
      "expanded_url" : "http:\/\/snpy.tv\/1Nnj077",
      "display_url" : "snpy.tv\/1Nnj077"
    } ]
  },
  "geo" : { },
  "id_str" : "668842753283985408",
  "text" : "\"We\u2019ve got to do everything we can to stop it.\" \u2014@POTUS on our strategy to degrade and destroy ISIL https:\/\/t.co\/pJWNzRjX4W",
  "id" : 668842753283985408,
  "created_at" : "2015-11-23 17:25:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/XYmEK0PNWe",
      "expanded_url" : "http:\/\/snpy.tv\/1N9aMNT",
      "display_url" : "snpy.tv\/1N9aMNT"
    } ]
  },
  "geo" : { },
  "id_str" : "668828542000582656",
  "text" : "\"The most powerful tool we have to fight ISIL is to say that we\u2019re not afraid, to not elevate them\" \u2014@POTUS https:\/\/t.co\/XYmEK0PNWe",
  "id" : 668828542000582656,
  "created_at" : "2015-11-23 16:28:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 107, 120 ]
    }, {
      "text" : "COP21",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/J0rBqxkaIq",
      "expanded_url" : "http:\/\/mojo.ly\/1SMTFl1",
      "display_url" : "mojo.ly\/1SMTFl1"
    } ]
  },
  "geo" : { },
  "id_str" : "668789996510400512",
  "text" : "RT @FactsOnClimate: American companies are using a record amount of clean energy \u2192 https:\/\/t.co\/J0rBqxkaIq #ActOnClimate #COP21 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/668789442296029184\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/wja3KZTZDs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUgETLbWoAAKTm4.jpg",
        "id_str" : "668789272196063232",
        "id" : 668789272196063232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUgETLbWoAAKTm4.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wja3KZTZDs"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 87, 100 ]
      }, {
        "text" : "COP21",
        "indices" : [ 101, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/J0rBqxkaIq",
        "expanded_url" : "http:\/\/mojo.ly\/1SMTFl1",
        "display_url" : "mojo.ly\/1SMTFl1"
      } ]
    },
    "geo" : { },
    "id_str" : "668789442296029184",
    "text" : "American companies are using a record amount of clean energy \u2192 https:\/\/t.co\/J0rBqxkaIq #ActOnClimate #COP21 https:\/\/t.co\/wja3KZTZDs",
    "id" : 668789442296029184,
    "created_at" : "2015-11-23 13:53:23 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 668789996510400512,
  "created_at" : "2015-11-23 13:55:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/668565886425366528\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/bi3iv5zzi6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUbY32JWIAATVq_.jpg",
      "id_str" : "668460048650215424",
      "id" : 668460048650215424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUbY32JWIAATVq_.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bi3iv5zzi6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668565886425366528",
  "text" : "FACT: Zero Syrian refugees that have resettled in the U.S. have been arrested or removed on terrorism charges. https:\/\/t.co\/bi3iv5zzi6",
  "id" : 668565886425366528,
  "created_at" : "2015-11-22 23:05:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/668535702695489538\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/8H1gnqrOyR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUbYxRCWcAAbsps.jpg",
      "id_str" : "668459935609548800",
      "id" : 668459935609548800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUbYxRCWcAAbsps.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8H1gnqrOyR"
    } ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 86, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/mtBAgDmCjL",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "668535702695489538",
  "text" : "What you need to know about the Syrian refugees in the U.S. \u2192 https:\/\/t.co\/mtBAgDmCjL #RefugeesWelcome https:\/\/t.co\/8H1gnqrOyR",
  "id" : 668535702695489538,
  "created_at" : "2015-11-22 21:05:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 100, 103 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/lsBGVUxZyl",
      "expanded_url" : "http:\/\/go.wh.gov\/BB6t2i",
      "display_url" : "go.wh.gov\/BB6t2i"
    } ]
  },
  "geo" : { },
  "id_str" : "668505496110804993",
  "text" : "\"Unlike in Europe, refugees don\u2019t set foot in the United States until they are thoroughly vetted.\" \u2014@VP https:\/\/t.co\/lsBGVUxZyl",
  "id" : 668505496110804993,
  "created_at" : "2015-11-22 19:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 86, 89 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/668475294982926337\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/d4AD1rxSOK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUbYfEtWsAADG8G.jpg",
      "id_str" : "668459623062614016",
      "id" : 668459623062614016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUbYfEtWsAADG8G.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d4AD1rxSOK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/mFekkOlxD0",
      "expanded_url" : "http:\/\/go.wh.gov\/Fx9T2q",
      "display_url" : "go.wh.gov\/Fx9T2q"
    } ]
  },
  "geo" : { },
  "id_str" : "668475294982926337",
  "text" : "\"Right now, refugees wait 18 to 24 months while the screening process is completed.\" \u2014@VP: https:\/\/t.co\/mFekkOlxD0 https:\/\/t.co\/d4AD1rxSOK",
  "id" : 668475294982926337,
  "created_at" : "2015-11-22 17:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 25, 41 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 48, 53 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Transparent",
      "screen_name" : "transparent_tv",
      "indices" : [ 66, 81 ],
      "id_str" : "2329150328",
      "id" : 2329150328
    }, {
      "name" : "The Danish Girl",
      "screen_name" : "danishgirlmov",
      "indices" : [ 88, 102 ],
      "id_str" : "3307223234",
      "id" : 3307223234
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/668459182979346432\/photo\/1",
      "indices" : [ 125, 148 ],
      "url" : "https:\/\/t.co\/7YnTuWFXLw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUXr7AuWEAAlk3t.jpg",
      "id_str" : "668199518773579776",
      "id" : 668199518773579776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUXr7AuWEAAlk3t.jpg",
      "sizes" : [ {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1835,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7YnTuWFXLw"
    } ],
    "hashtags" : [ {
      "text" : "LGBTchamps",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668459182979346432",
  "text" : "Ask away on #LGBTchamps! @SecretaryCastro &amp; @VJ44 are joining @Transparent_TV &amp; @DanishGirlMov for a Q&amp;A Monday. https:\/\/t.co\/7YnTuWFXLw",
  "id" : 668459182979346432,
  "created_at" : "2015-11-22 16:01:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/OXYQmCxPdM",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f608ded7-85d6-43fa-bf01-1ff54de70c7f",
      "display_url" : "amp.twimg.com\/v\/f608ded7-85d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668249612377976832",
  "text" : "\"They're just like our kids, and they deserve love, and protection...and an education.\" \u2014@POTUS #RefugeesWelcome\nhttps:\/\/t.co\/OXYQmCxPdM",
  "id" : 668249612377976832,
  "created_at" : "2015-11-22 02:08:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 108, 111 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/lsBGVUxZyl",
      "expanded_url" : "http:\/\/go.wh.gov\/BB6t2i",
      "display_url" : "go.wh.gov\/BB6t2i"
    } ]
  },
  "geo" : { },
  "id_str" : "668204510557290496",
  "text" : "\"There\u2019s nothing President Obama and I take more seriously though, than keeping the American people safe.\" \u2014@VP: https:\/\/t.co\/lsBGVUxZyl",
  "id" : 668204510557290496,
  "created_at" : "2015-11-21 23:09:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 50, 66 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SecretaryCastro\/status\/667728225611735040\/video\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/J7oZkDUyzT",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/667726694241820673\/pu\/img\/KKrNt7ZJx5-1bubY.jpg",
      "id_str" : "667726694241820673",
      "id" : 667726694241820673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/667726694241820673\/pu\/img\/KKrNt7ZJx5-1bubY.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/J7oZkDUyzT"
    } ],
    "hashtags" : [ {
      "text" : "LGBTchamps",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668199282755940352",
  "text" : "Questions about LGBT housing or homelessness? Ask @SecretaryCastro by Monday at 4pm ET using #LGBTchamps. https:\/\/t.co\/J7oZkDUyzT",
  "id" : 668199282755940352,
  "created_at" : "2015-11-21 22:48:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/668174298830405632\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/2VgKsWxb30",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUWCrFUWEAA2hl_.jpg",
      "id_str" : "668083796407881728",
      "id" : 668083796407881728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUWCrFUWEAA2hl_.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2VgKsWxb30"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/mtBAgDmCjL",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "668174298830405632",
  "text" : "By the numbers: Four facts about Syrian refugees in the U.S. \u2192 https:\/\/t.co\/mtBAgDmCjL https:\/\/t.co\/2VgKsWxb30",
  "id" : 668174298830405632,
  "created_at" : "2015-11-21 21:09:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 87, 90 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/668143850993483776\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/TnEh7jw8MG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUWCaUcWEAA2EOW.jpg",
      "id_str" : "668083508410191872",
      "id" : 668083508410191872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUWCaUcWEAA2EOW.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/TnEh7jw8MG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/mFekkOlxD0",
      "expanded_url" : "http:\/\/go.wh.gov\/Fx9T2q",
      "display_url" : "go.wh.gov\/Fx9T2q"
    } ]
  },
  "geo" : { },
  "id_str" : "668143850993483776",
  "text" : "\"Refugees face the most rigorous screening of anyone who comes to the United States.\" \u2014@VP: https:\/\/t.co\/mFekkOlxD0 https:\/\/t.co\/TnEh7jw8MG",
  "id" : 668143850993483776,
  "created_at" : "2015-11-21 19:08:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668127502242611200",
  "text" : "RT @VP: We win by prioritizing our security while refusing to compromise our fundamental American values: Freedom. Openness. Tolerance.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "668090055219683328",
    "geo" : { },
    "id_str" : "668092018992791552",
    "in_reply_to_user_id" : 325830217,
    "text" : "We win by prioritizing our security while refusing to compromise our fundamental American values: Freedom. Openness. Tolerance.",
    "id" : 668092018992791552,
    "in_reply_to_status_id" : 668090055219683328,
    "created_at" : "2015-11-21 15:42:04 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 668127502242611200,
  "created_at" : "2015-11-21 18:03:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/668113421645156352\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/dXqz3sJAXK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUWCLieXAAAm8jv.jpg",
      "id_str" : "668083254478700544",
      "id" : 668083254478700544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUWCLieXAAAm8jv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dXqz3sJAXK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/1YvaL9l5XO",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeeScreening",
      "display_url" : "go.wh.gov\/RefugeeScreeni\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "668113421645156352",
  "text" : "Here's what the screening process looks like for refugee entry into the United States: https:\/\/t.co\/1YvaL9l5XO https:\/\/t.co\/dXqz3sJAXK",
  "id" : 668113421645156352,
  "created_at" : "2015-11-21 17:07:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668112143204679680",
  "text" : "RT @VP: To turn these refugees away would play right into the terrorists' hands. And we know what ISIL hopes to accomplish. They've told us.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "668088304579928064",
    "geo" : { },
    "id_str" : "668090055219683328",
    "in_reply_to_user_id" : 325830217,
    "text" : "To turn these refugees away would play right into the terrorists' hands. And we know what ISIL hopes to accomplish. They've told us.",
    "id" : 668090055219683328,
    "in_reply_to_status_id" : 668088304579928064,
    "created_at" : "2015-11-21 15:34:16 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 668112143204679680,
  "created_at" : "2015-11-21 17:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 84, 91 ],
      "id_str" : "15647676",
      "id" : 15647676
    }, {
      "name" : "FBI",
      "screen_name" : "FBI",
      "indices" : [ 104, 108 ],
      "id_str" : "17629860",
      "id" : 17629860
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 110, 120 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 122, 136 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668110316660785152",
  "text" : "RT @VP: ALL refugees who come to the U.S. get:\n\nFingerprinted.\nSecurity screenings.\n@DHSgov interviews.\n@FBI, @StateDept, @DeptofDefense si\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Homeland Security",
        "screen_name" : "DHSgov",
        "indices" : [ 76, 83 ],
        "id_str" : "15647676",
        "id" : 15647676
      }, {
        "name" : "FBI",
        "screen_name" : "FBI",
        "indices" : [ 96, 100 ],
        "id_str" : "17629860",
        "id" : 17629860
      }, {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 102, 112 ],
        "id_str" : "9624742",
        "id" : 9624742
      }, {
        "name" : "U.S. Dept of Defense",
        "screen_name" : "DeptofDefense",
        "indices" : [ 114, 128 ],
        "id_str" : "66369181",
        "id" : 66369181
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "668086206568230912",
    "geo" : { },
    "id_str" : "668088304579928064",
    "in_reply_to_user_id" : 325830217,
    "text" : "ALL refugees who come to the U.S. get:\n\nFingerprinted.\nSecurity screenings.\n@DHSgov interviews.\n@FBI, @StateDept, @DeptofDefense sign off.",
    "id" : 668088304579928064,
    "in_reply_to_status_id" : 668086206568230912,
    "created_at" : "2015-11-21 15:27:18 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 668110316660785152,
  "created_at" : "2015-11-21 16:54:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668109085141819393",
  "text" : "RT @VP: The vast majority of Syrian refugees are: \n \nWomen, children, and orphans.\nSurvivors of torture.\nPeople desperately in need of medi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "668086206568230912",
    "text" : "The vast majority of Syrian refugees are: \n \nWomen, children, and orphans.\nSurvivors of torture.\nPeople desperately in need of medical help.",
    "id" : 668086206568230912,
    "created_at" : "2015-11-21 15:18:58 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 668109085141819393,
  "created_at" : "2015-11-21 16:49:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/668095216608481281\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/QwxOnDUH9R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUWNAj7WoAA061z.jpg",
      "id_str" : "668095160518090752",
      "id" : 668095160518090752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUWNAj7WoAA061z.jpg",
      "sizes" : [ {
        "h" : 391,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1825,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QwxOnDUH9R"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/u3CX3764G5",
      "expanded_url" : "http:\/\/on.fb.me\/1T6abxo",
      "display_url" : "on.fb.me\/1T6abxo"
    } ]
  },
  "geo" : { },
  "id_str" : "668095216608481281",
  "text" : "\"Despite all they\u2019ve endured\u2014the brave, hardworking children I met remain hopeful\" \u2014@POTUS: https:\/\/t.co\/u3CX3764G5 https:\/\/t.co\/QwxOnDUH9R",
  "id" : 668095216608481281,
  "created_at" : "2015-11-21 15:54:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 43, 46 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/lsBGVUPAWV",
      "expanded_url" : "http:\/\/go.wh.gov\/BB6t2i",
      "display_url" : "go.wh.gov\/BB6t2i"
    } ]
  },
  "geo" : { },
  "id_str" : "668082740638695424",
  "text" : "\"In the face of terror, we stand as one.\" \u2014@VP Biden: https:\/\/t.co\/lsBGVUPAWV",
  "id" : 668082740638695424,
  "created_at" : "2015-11-21 15:05:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/5Q4QkVy1dF",
      "expanded_url" : "http:\/\/snpy.tv\/1jccvpz",
      "display_url" : "snpy.tv\/1jccvpz"
    } ]
  },
  "geo" : { },
  "id_str" : "667896118139834369",
  "text" : "\"We will stand with the people of Mali as they work to rid their country of terrorists.\" \u2014@POTUS: https:\/\/t.co\/5Q4QkVy1dF",
  "id" : 667896118139834369,
  "created_at" : "2015-11-21 02:43:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/Pavv3tXNM6",
      "expanded_url" : "http:\/\/go.wh.gov\/vNg5Xt",
      "display_url" : "go.wh.gov\/vNg5Xt"
    } ]
  },
  "geo" : { },
  "id_str" : "667892037761548288",
  "text" : "Tune in: @POTUS gives remarks in Kuala Lumpur, Malaysia: https:\/\/t.co\/Pavv3tXNM6",
  "id" : 667892037761548288,
  "created_at" : "2015-11-21 02:27:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 16, 32 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 39, 44 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Transparent",
      "screen_name" : "transparent_tv",
      "indices" : [ 115, 130 ],
      "id_str" : "2329150328",
      "id" : 2329150328
    }, {
      "name" : "The Danish Girl",
      "screen_name" : "danishgirlmov",
      "indices" : [ 137, 151 ],
      "id_str" : "3307223234",
      "id" : 3307223234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTchamps",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667846322880409600",
  "text" : "Just announced: @SecretaryCastro &amp; @VJ44 will host a Q&amp;A on #LGBTchamps Monday at 4pm ET with artists from @Transparent_TV &amp; @DanishGirlMov.",
  "id" : 667846322880409600,
  "created_at" : "2015-11-20 23:25:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 3, 17 ],
      "id_str" : "16581604",
      "id" : 16581604
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 102, 107 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Compact of Mayors",
      "screen_name" : "CompactofMayors",
      "indices" : [ 111, 127 ],
      "id_str" : "3294157876",
      "id" : 3294157876
    }, {
      "name" : "COP21 - Paris 2015",
      "screen_name" : "COP21",
      "indices" : [ 128, 134 ],
      "id_str" : "2617471956",
      "id" : 2617471956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667841736639717376",
  "text" : "RT @MikeBloomberg: \"Cities aren't waiting for someone else to act. They are taking action right now.\" @vj44 on @CompactofMayors @COP21 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 83, 88 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "Compact of Mayors",
        "screen_name" : "CompactofMayors",
        "indices" : [ 92, 108 ],
        "id_str" : "3294157876",
        "id" : 3294157876
      }, {
        "name" : "COP21 - Paris 2015",
        "screen_name" : "COP21",
        "indices" : [ 109, 115 ],
        "id_str" : "2617471956",
        "id" : 2617471956
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/1r6Psr1nr1",
        "expanded_url" : "http:\/\/mikebloom.bg\/1kLVSTi",
        "display_url" : "mikebloom.bg\/1kLVSTi"
      } ]
    },
    "geo" : { },
    "id_str" : "667830589962121216",
    "text" : "\"Cities aren't waiting for someone else to act. They are taking action right now.\" @vj44 on @CompactofMayors @COP21 https:\/\/t.co\/1r6Psr1nr1",
    "id" : 667830589962121216,
    "created_at" : "2015-11-20 22:23:14 +0000",
    "user" : {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "protected" : false,
      "id_str" : "16581604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615510114447953920\/_1c4TTMM_normal.jpg",
      "id" : 16581604,
      "verified" : true
    }
  },
  "id" : 667841736639717376,
  "created_at" : "2015-11-20 23:07:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667806946615930880\/photo\/1",
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/MnlPWA3UMC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUSGv54WoAEkCCM.jpg",
      "id_str" : "667806802306834433",
      "id" : 667806802306834433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUSGv54WoAEkCCM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MnlPWA3UMC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667806946615930880",
  "text" : ".@NSCPress on the terrorist attack in Mali. https:\/\/t.co\/MnlPWA3UMC",
  "id" : 667806946615930880,
  "created_at" : "2015-11-20 20:49:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayor Adler",
      "screen_name" : "MayorAdler",
      "indices" : [ 3, 14 ],
      "id_str" : "2300278368",
      "id" : 2300278368
    }, {
      "name" : "TribTalk",
      "screen_name" : "TribTalkTX",
      "indices" : [ 27, 38 ],
      "id_str" : "2458364053",
      "id" : 2458364053
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SyrianRefugees",
      "indices" : [ 76, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667794406196584448",
  "text" : "RT @MayorAdler: My oped in @TribTalkTX: Austin is happy to lift the lamp to #SyrianRefugees. It's safe &amp; we're a strong city. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TribTalk",
        "screen_name" : "TribTalkTX",
        "indices" : [ 11, 22 ],
        "id_str" : "2458364053",
        "id" : 2458364053
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SyrianRefugees",
        "indices" : [ 60, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/YnSy7Irug6",
        "expanded_url" : "http:\/\/tribtalk.org\/2015\/11\/20\/syrian-refugees-are-welcome-in-austin\/",
        "display_url" : "tribtalk.org\/2015\/11\/20\/syr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667773091402002432",
    "text" : "My oped in @TribTalkTX: Austin is happy to lift the lamp to #SyrianRefugees. It's safe &amp; we're a strong city. https:\/\/t.co\/YnSy7Irug6",
    "id" : 667773091402002432,
    "created_at" : "2015-11-20 18:34:46 +0000",
    "user" : {
      "name" : "Mayor Adler",
      "screen_name" : "MayorAdler",
      "protected" : false,
      "id_str" : "2300278368",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740916584982577152\/X9CAAPB4_normal.jpg",
      "id" : 2300278368,
      "verified" : true
    }
  },
  "id" : 667794406196584448,
  "created_at" : "2015-11-20 19:59:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 24, 33 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/667787366401118208\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/Kexfj4R23E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUR048QUwAEfLZT.jpg",
      "id_str" : "667787166353768449",
      "id" : 667787166353768449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUR048QUwAEfLZT.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Kexfj4R23E"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/3eG6VArsxv",
      "expanded_url" : "http:\/\/on.fb.me\/1l9Edog",
      "display_url" : "on.fb.me\/1l9Edog"
    } ]
  },
  "geo" : { },
  "id_str" : "667787366401118208",
  "text" : ".@NSCPress is holding a @Facebook Q&amp;A on refugees at 3pm ET.\nSend us your questions here \u2192 https:\/\/t.co\/3eG6VArsxv https:\/\/t.co\/Kexfj4R23E",
  "id" : 667787366401118208,
  "created_at" : "2015-11-20 19:31:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 43, 46 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/667763767229321217\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/UjFfuoZC9A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CURfmzHU8AAAXlF.jpg",
      "id_str" : "667763764918284288",
      "id" : 667763764918284288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CURfmzHU8AAAXlF.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 3000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UjFfuoZC9A"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/oH7inIzWNA",
      "expanded_url" : "https:\/\/instagram.com\/p\/-UNQ1sk7xu\/",
      "display_url" : "instagram.com\/p\/-UNQ1sk7xu\/"
    } ]
  },
  "geo" : { },
  "id_str" : "667782484633985025",
  "text" : "RT @DrBiden: Happy birthday to my favorite @VP, best friend and love of my life! \u2013Jill https:\/\/t.co\/oH7inIzWNA https:\/\/t.co\/UjFfuoZC9A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 30, 33 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/667763767229321217\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/UjFfuoZC9A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CURfmzHU8AAAXlF.jpg",
        "id_str" : "667763764918284288",
        "id" : 667763764918284288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CURfmzHU8AAAXlF.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UjFfuoZC9A"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/oH7inIzWNA",
        "expanded_url" : "https:\/\/instagram.com\/p\/-UNQ1sk7xu\/",
        "display_url" : "instagram.com\/p\/-UNQ1sk7xu\/"
      } ]
    },
    "geo" : { },
    "id_str" : "667763767229321217",
    "text" : "Happy birthday to my favorite @VP, best friend and love of my life! \u2013Jill https:\/\/t.co\/oH7inIzWNA https:\/\/t.co\/UjFfuoZC9A",
    "id" : 667763767229321217,
    "created_at" : "2015-11-20 17:57:43 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 667782484633985025,
  "created_at" : "2015-11-20 19:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667775242971037696",
  "text" : "RT @vj44: Acceptance and understanding will make us a stronger nation, not fear and hate. Today we remember the trans victims of violence. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TDOR",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667770388181553152",
    "text" : "Acceptance and understanding will make us a stronger nation, not fear and hate. Today we remember the trans victims of violence. #TDOR",
    "id" : 667770388181553152,
    "created_at" : "2015-11-20 18:24:01 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 667775242971037696,
  "created_at" : "2015-11-20 18:43:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/667760799130218498\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/F00xTKTFjd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CURc22uWcAEGZTd.jpg",
      "id_str" : "667760742230290433",
      "id" : 667760742230290433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CURc22uWcAEGZTd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/F00xTKTFjd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667760799130218498",
  "text" : "\"Our focus is giving safe haven to the most vulnerable Syrians\u2014 women, children, and survivors of torture.\" \u2014@POTUS https:\/\/t.co\/F00xTKTFjd",
  "id" : 667760799130218498,
  "created_at" : "2015-11-20 17:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667748022458015744\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/QQQSOwGQib",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CURQfvcXIAAAF3X.jpg",
      "id_str" : "667747150999265280",
      "id" : 667747150999265280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CURQfvcXIAAAF3X.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QQQSOwGQib"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/mtBAgDmCjL",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667748022458015744",
  "text" : "FACT: Refugees undergo more rigorous screening than anyone else we allow into the U.S. https:\/\/t.co\/mtBAgDmCjL https:\/\/t.co\/QQQSOwGQib",
  "id" : 667748022458015744,
  "created_at" : "2015-11-20 16:55:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/667740584057176064\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/8pN7nH2Pg9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CURKPQLWoAAzWZ5.jpg",
      "id_str" : "667740270658756608",
      "id" : 667740270658756608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CURKPQLWoAAzWZ5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/8pN7nH2Pg9"
    } ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667740584057176064",
  "text" : "By the numbers: Four facts about Syrian refugees in the U.S. \u2192 https:\/\/t.co\/mtBAgDEdIl #RefugeesWelcome https:\/\/t.co\/8pN7nH2Pg9",
  "id" : 667740584057176064,
  "created_at" : "2015-11-20 16:25:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667510981141073921\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/Cl3Kbt9D45",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUN3PK0XAAIf-vG.jpg",
      "id_str" : "667508272266674178",
      "id" : 667508272266674178,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUN3PK0XAAIf-vG.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Cl3Kbt9D45"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/0XXoHFrhGU",
      "expanded_url" : "http:\/\/go.wh.gov\/3LtgrA",
      "display_url" : "go.wh.gov\/3LtgrA"
    } ]
  },
  "geo" : { },
  "id_str" : "667510981141073921",
  "text" : "218 schools representing 3.3 million students are stepping up to #ActOnClimate \u2192 https:\/\/t.co\/0XXoHFrhGU https:\/\/t.co\/Cl3Kbt9D45",
  "id" : 667510981141073921,
  "created_at" : "2015-11-20 01:13:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 26, 35 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/aYxsiHtJyC",
      "expanded_url" : "http:\/\/go.wh.gov\/roKKEb",
      "display_url" : "go.wh.gov\/roKKEb"
    }, {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/W69RtnWX9r",
      "expanded_url" : "http:\/\/snpy.tv\/1jajdwk",
      "display_url" : "snpy.tv\/1jajdwk"
    } ]
  },
  "geo" : { },
  "id_str" : "667510708179873792",
  "text" : "Go behind the scenes with @PressSec on @POTUS's trip to the Asia Pacific: https:\/\/t.co\/aYxsiHtJyC https:\/\/t.co\/W69RtnWX9r",
  "id" : 667510708179873792,
  "created_at" : "2015-11-20 01:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 12, 19 ],
      "id_str" : "15647676",
      "id" : 15647676
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667481850357641216\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/SqmUhnGZ9K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNfH0hUwAAZYLp.jpg",
      "id_str" : "667481757743104000",
      "id" : 667481757743104000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNfH0hUwAAZYLp.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 889
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 889
      } ],
      "display_url" : "pic.twitter.com\/SqmUhnGZ9K"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/eZv3heTe7l",
      "expanded_url" : "http:\/\/go.wh.gov\/HRR7nM",
      "display_url" : "go.wh.gov\/HRR7nM"
    } ]
  },
  "geo" : { },
  "id_str" : "667481850357641216",
  "text" : "Read former @DHSgov Secretaries' letter to @POTUS on safely welcoming Syrian refugees: https:\/\/t.co\/eZv3heTe7l https:\/\/t.co\/SqmUhnGZ9K",
  "id" : 667481850357641216,
  "created_at" : "2015-11-19 23:17:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 17, 25 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667476278077861888",
  "text" : "RT @vj44: Thanks @Spotify!! Looking forward to the day when companies that adopt family-friendly policies no longer make news. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Spotify",
        "screen_name" : "Spotify",
        "indices" : [ 7, 15 ],
        "id_str" : "17230018",
        "id" : 17230018
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/r1A32fOGK3",
        "expanded_url" : "https:\/\/twitter.com\/HuffPostBiz\/status\/667420973306658816",
        "display_url" : "twitter.com\/HuffPostBiz\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667476113426288640",
    "text" : "Thanks @Spotify!! Looking forward to the day when companies that adopt family-friendly policies no longer make news. https:\/\/t.co\/r1A32fOGK3",
    "id" : 667476113426288640,
    "created_at" : "2015-11-19 22:54:41 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 667476278077861888,
  "created_at" : "2015-11-19 22:55:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667473804835295233",
  "text" : "RT @vj44: Fathers who have access to paid leave are more like to actually take leave. That's good for our children &amp; families. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/LAThfXuWaC",
        "expanded_url" : "https:\/\/twitter.com\/cplleadership\/status\/667469305399742465",
        "display_url" : "twitter.com\/cplleadership\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667470711997509637",
    "text" : "Fathers who have access to paid leave are more like to actually take leave. That's good for our children &amp; families. https:\/\/t.co\/LAThfXuWaC",
    "id" : 667470711997509637,
    "created_at" : "2015-11-19 22:33:13 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 667473804835295233,
  "created_at" : "2015-11-19 22:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Mary Spicuzza",
      "screen_name" : "MSpicuzzaMJS",
      "indices" : [ 11, 24 ],
      "id_str" : "160726477",
      "id" : 160726477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PaidLeave",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667470448783921152",
  "text" : "RT @vj44: .@MSpicuzzaMJS: Amen to that. We are the only advanced country in the world that does not have a #PaidLeave policy. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary Spicuzza",
        "screen_name" : "MSpicuzzaMJS",
        "indices" : [ 1, 14 ],
        "id_str" : "160726477",
        "id" : 160726477
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/667470253618778113\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/bifcbqYrG3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNUh9CXAAEhxHU.jpg",
        "id_str" : "667470112077840385",
        "id" : 667470112077840385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNUh9CXAAEhxHU.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bifcbqYrG3"
      } ],
      "hashtags" : [ {
        "text" : "PaidLeave",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667380066846957568",
    "geo" : { },
    "id_str" : "667470253618778113",
    "in_reply_to_user_id" : 160726477,
    "text" : ".@MSpicuzzaMJS: Amen to that. We are the only advanced country in the world that does not have a #PaidLeave policy. https:\/\/t.co\/bifcbqYrG3",
    "id" : 667470253618778113,
    "in_reply_to_status_id" : 667380066846957568,
    "created_at" : "2015-11-19 22:31:24 +0000",
    "in_reply_to_screen_name" : "MSpicuzzaMJS",
    "in_reply_to_user_id_str" : "160726477",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 667470448783921152,
  "created_at" : "2015-11-19 22:32:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "jon",
      "screen_name" : "jonathanmprice",
      "indices" : [ 61, 76 ],
      "id_str" : "1385601025",
      "id" : 1385601025
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 82, 90 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667468088011456513",
  "text" : "RT @vj44: Welcome to my weekly office hours. Joined today by @JonathanMPrice from @Spotify\nExcited to do a #LeadOnLeave chat. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jon",
        "screen_name" : "jonathanmprice",
        "indices" : [ 51, 66 ],
        "id_str" : "1385601025",
        "id" : 1385601025
      }, {
        "name" : "Spotify",
        "screen_name" : "Spotify",
        "indices" : [ 72, 80 ],
        "id_str" : "17230018",
        "id" : 17230018
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/667467119060234240\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/d4jXDqpB5w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNRsvjWsAQKls6.jpg",
        "id_str" : "667466998901813252",
        "id" : 667466998901813252,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNRsvjWsAQKls6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/d4jXDqpB5w"
      } ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667467119060234240",
    "text" : "Welcome to my weekly office hours. Joined today by @JonathanMPrice from @Spotify\nExcited to do a #LeadOnLeave chat. https:\/\/t.co\/d4jXDqpB5w",
    "id" : 667467119060234240,
    "created_at" : "2015-11-19 22:18:56 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 667468088011456513,
  "created_at" : "2015-11-19 22:22:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667456301295935488\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/oPnDiZbSsU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUNGlV5UYAAaPP8.jpg",
      "id_str" : "667454777127624704",
      "id" : 667454777127624704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUNGlV5UYAAaPP8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oPnDiZbSsU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667456301295935488",
  "text" : "ZERO Syrian refugees that resettled in the U.S. have been arrested or removed on terrorism charges. https:\/\/t.co\/oPnDiZbSsU",
  "id" : 667456301295935488,
  "created_at" : "2015-11-19 21:35:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 6, 14 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Emily Graslie",
      "screen_name" : "Ehmee",
      "indices" : [ 53, 59 ],
      "id_str" : "16435797",
      "id" : 16435797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/pvVHnqf8bz",
      "expanded_url" : "http:\/\/on.fb.me\/1I1HsTQ",
      "display_url" : "on.fb.me\/1I1HsTQ"
    } ]
  },
  "geo" : { },
  "id_str" : "667433939632570368",
  "text" : "Watch @GinaEPA &amp; \u201CChief Curiosity Correspondent\u201D @Ehmee discuss how campuses are stepping up to #ActOnClimate \u2192 https:\/\/t.co\/pvVHnqf8bz",
  "id" : 667433939632570368,
  "created_at" : "2015-11-19 20:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667425254977966081\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/QJdQQKmR4x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMrepBXIAYFLdM.jpg",
      "id_str" : "667424975188598790",
      "id" : 667424975188598790,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMrepBXIAYFLdM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/QJdQQKmR4x"
    } ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 86, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667425254977966081",
  "text" : "What you need to know about the Syrian refugees in the U.S. \u2192\nhttps:\/\/t.co\/mtBAgDEdIl #RefugeesWelcome https:\/\/t.co\/QJdQQKmR4x",
  "id" : 667425254977966081,
  "created_at" : "2015-11-19 19:32:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 3, 11 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/dbbU3Xjoli",
      "expanded_url" : "http:\/\/spoti.fi\/215tgoo",
      "display_url" : "spoti.fi\/215tgoo"
    } ]
  },
  "geo" : { },
  "id_str" : "667412730454925312",
  "text" : "RT @Spotify: Spotify is proud to #LeadOnLeave. Introducing: 100% paid parental leave for all employees\u2014Learn more: https:\/\/t.co\/dbbU3Xjoli",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 20, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/dbbU3Xjoli",
        "expanded_url" : "http:\/\/spoti.fi\/215tgoo",
        "display_url" : "spoti.fi\/215tgoo"
      } ]
    },
    "geo" : { },
    "id_str" : "667377213935894528",
    "text" : "Spotify is proud to #LeadOnLeave. Introducing: 100% paid parental leave for all employees\u2014Learn more: https:\/\/t.co\/dbbU3Xjoli",
    "id" : 667377213935894528,
    "created_at" : "2015-11-19 16:21:41 +0000",
    "user" : {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "protected" : false,
      "id_str" : "17230018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753188521540714497\/ge3tfN8Z_normal.jpg",
      "id" : 17230018,
      "verified" : true
    }
  },
  "id" : 667412730454925312,
  "created_at" : "2015-11-19 18:42:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Trudeau",
      "screen_name" : "JustinTrudeau",
      "indices" : [ 3, 17 ],
      "id_str" : "14260960",
      "id" : 14260960
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667393473612509184",
  "text" : "RT @JustinTrudeau: Today I discussed welcoming refugees &amp; tackling climate change with @POTUS. A new era in Canada-US relations. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 72, 78 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JustinTrudeau\/status\/667385637297782784\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/BT7yyrvGWf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMHsylUAAAoXeq.jpg",
        "id_str" : "667385635854876672",
        "id" : 667385635854876672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMHsylUAAAoXeq.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/BT7yyrvGWf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667385637297782784",
    "text" : "Today I discussed welcoming refugees &amp; tackling climate change with @POTUS. A new era in Canada-US relations. https:\/\/t.co\/BT7yyrvGWf",
    "id" : 667385637297782784,
    "created_at" : "2015-11-19 16:55:10 +0000",
    "user" : {
      "name" : "Justin Trudeau",
      "screen_name" : "JustinTrudeau",
      "protected" : false,
      "id_str" : "14260960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797443159198470144\/1AwTnliW_normal.jpg",
      "id" : 14260960,
      "verified" : true
    }
  },
  "id" : 667393473612509184,
  "created_at" : "2015-11-19 17:26:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/667387230281973760\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/FkPLebcbA3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMI36IWwAAVmTo.jpg",
      "id_str" : "667386926371094528",
      "id" : 667386926371094528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMI36IWwAAVmTo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/FkPLebcbA3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667387230281973760",
  "text" : "FACT: Zero Syrian refugees that have resettled in the U.S. have been arrested or removed on terrorism charges. https:\/\/t.co\/FkPLebcbA3",
  "id" : 667387230281973760,
  "created_at" : "2015-11-19 17:01:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 24, 34 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667385407831728128\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/wfoGXV8gtG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUMHZKAWoAAT6dE.jpg",
      "id_str" : "667385298544926720",
      "id" : 667385298544926720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUMHZKAWoAAT6dE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wfoGXV8gtG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667385407831728128",
  "text" : ".@POTUS just spoke with @FHollande about the investigation into the Paris terrorist attacks. https:\/\/t.co\/wfoGXV8gtG",
  "id" : 667385407831728128,
  "created_at" : "2015-11-19 16:54:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 11, 19 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PaidLeave",
      "indices" : [ 55, 65 ]
    }, {
      "text" : "LeadOnLeave",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667375649674366976",
  "text" : "RT @vj44: .@Spotify just announced that it's expanding #PaidLeave. Got Qs? Ask with #LeadOnLeave by 5:15pm ET, and I'll answer with @Jonath\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Spotify",
        "screen_name" : "Spotify",
        "indices" : [ 1, 9 ],
        "id_str" : "17230018",
        "id" : 17230018
      }, {
        "name" : "Jonathan Prince",
        "screen_name" : "jonathanmprince",
        "indices" : [ 122, 138 ],
        "id_str" : "104905030",
        "id" : 104905030
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PaidLeave",
        "indices" : [ 45, 55 ]
      }, {
        "text" : "LeadOnLeave",
        "indices" : [ 74, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667371620047134720",
    "text" : ".@Spotify just announced that it's expanding #PaidLeave. Got Qs? Ask with #LeadOnLeave by 5:15pm ET, and I'll answer with @JonathanMPrince.",
    "id" : 667371620047134720,
    "created_at" : "2015-11-19 15:59:28 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 667375649674366976,
  "created_at" : "2015-11-19 16:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667371453440880641",
  "text" : "RT @SenatorReid: We\u2019ve heard Republicans say: \n- we're at war with Islam\n- shut down mosques\n- ban Muslims from govt \n- reject Muslim refug\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667361365045190656",
    "text" : "We\u2019ve heard Republicans say: \n- we're at war with Islam\n- shut down mosques\n- ban Muslims from govt \n- reject Muslim refugees\n\nShameful hate",
    "id" : 667361365045190656,
    "created_at" : "2015-11-19 15:18:43 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 667371453440880641,
  "created_at" : "2015-11-19 15:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/667362537487392772\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/4Zpjg4FnnS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CULthGYUAAA3iL8.png",
      "id_str" : "667356847708307456",
      "id" : 667356847708307456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CULthGYUAAA3iL8.png",
      "sizes" : [ {
        "h" : 502,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4Zpjg4FnnS"
    } ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/WyV8U51Uoe",
      "expanded_url" : "http:\/\/n.pr\/1W4nq6Q",
      "display_url" : "n.pr\/1W4nq6Q"
    } ]
  },
  "geo" : { },
  "id_str" : "667362537487392772",
  "text" : "Meet this Syrian refugee family rebuilding a new life in Ohio: https:\/\/t.co\/WyV8U51Uoe #RefugeesWelcome https:\/\/t.co\/4Zpjg4FnnS",
  "id" : 667362537487392772,
  "created_at" : "2015-11-19 15:23:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Kriseman",
      "screen_name" : "Kriseman",
      "indices" : [ 3, 12 ],
      "id_str" : "62009570",
      "id" : 62009570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CityOfOpportunity",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/jha9egEmtT",
      "expanded_url" : "http:\/\/www.tampabay.com\/news\/gov-rick-scott-and-democratic-mayors-diverge-on-acceptance-of-syrian\/2254562",
      "display_url" : "tampabay.com\/news\/gov-rick-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667356024035258369",
  "text" : "RT @Kriseman: We welcome people with open arms in St. Pete and we're succeeding because of it. https:\/\/t.co\/jha9egEmtT #CityOfOpportunity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CityOfOpportunity",
        "indices" : [ 105, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/jha9egEmtT",
        "expanded_url" : "http:\/\/www.tampabay.com\/news\/gov-rick-scott-and-democratic-mayors-diverge-on-acceptance-of-syrian\/2254562",
        "display_url" : "tampabay.com\/news\/gov-rick-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667184437545824257",
    "text" : "We welcome people with open arms in St. Pete and we're succeeding because of it. https:\/\/t.co\/jha9egEmtT #CityOfOpportunity",
    "id" : 667184437545824257,
    "created_at" : "2015-11-19 03:35:40 +0000",
    "user" : {
      "name" : "Rick Kriseman",
      "screen_name" : "Kriseman",
      "protected" : false,
      "id_str" : "62009570",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567749597812908032\/pXTeoIg7_normal.jpeg",
      "id" : 62009570,
      "verified" : false
    }
  },
  "id" : 667356024035258369,
  "created_at" : "2015-11-19 14:57:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667349421949108224\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/m8up6UUUzi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CULmqIVW4AABFuw.jpg",
      "id_str" : "667349306270212096",
      "id" : 667349306270212096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CULmqIVW4AABFuw.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/m8up6UUUzi"
    } ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 23, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667349421949108224",
  "text" : "Here's how we can make #RefugeesWelcome while ensuring our own safety \u2192 https:\/\/t.co\/mtBAgDEdIl https:\/\/t.co\/m8up6UUUzi",
  "id" : 667349421949108224,
  "created_at" : "2015-11-19 14:31:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/9bsbGC7tJ9",
      "expanded_url" : "https:\/\/twitter.com\/patricks1591\/status\/667168963583832065",
      "display_url" : "twitter.com\/patricks1591\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667175940955512833",
  "text" : "RT @PressSec: Yes, it is. Fighting for his country overseas &amp; living up to our values here at home. #AskPressSec  https:\/\/t.co\/9bsbGC7tJ9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 90, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/9bsbGC7tJ9",
        "expanded_url" : "https:\/\/twitter.com\/patricks1591\/status\/667168963583832065",
        "display_url" : "twitter.com\/patricks1591\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667173623640272896",
    "text" : "Yes, it is. Fighting for his country overseas &amp; living up to our values here at home. #AskPressSec  https:\/\/t.co\/9bsbGC7tJ9",
    "id" : 667173623640272896,
    "created_at" : "2015-11-19 02:52:42 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 667175940955512833,
  "created_at" : "2015-11-19 03:01:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/3tI6fXO5vn",
      "expanded_url" : "https:\/\/twitter.com\/madeleine\/status\/666770241343643648",
      "display_url" : "twitter.com\/madeleine\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667174241704534016",
  "text" : "RT @PressSec: Well said - by a woman who is a shining example of how refugees have made America great. #AskPressSec  https:\/\/t.co\/3tI6fXO5vn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 89, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/3tI6fXO5vn",
        "expanded_url" : "https:\/\/twitter.com\/madeleine\/status\/666770241343643648",
        "display_url" : "twitter.com\/madeleine\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667172174243999744",
    "text" : "Well said - by a woman who is a shining example of how refugees have made America great. #AskPressSec  https:\/\/t.co\/3tI6fXO5vn",
    "id" : 667172174243999744,
    "created_at" : "2015-11-19 02:46:56 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 667174241704534016,
  "created_at" : "2015-11-19 02:55:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/9HYpoi5bJt",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667171767916605440",
  "text" : "RT @PressSec: Here's a good rundown of the already intensive refugee screening process: https:\/\/t.co\/9HYpoi5bJt #AskPressSec  https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/9HYpoi5bJt",
        "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
        "display_url" : "go.wh.gov\/RefugeesWelcome"
      }, {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/gS6G0XPry5",
        "expanded_url" : "https:\/\/twitter.com\/PaulRigas\/status\/667153994469347328",
        "display_url" : "twitter.com\/PaulRigas\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667171533106843650",
    "text" : "Here's a good rundown of the already intensive refugee screening process: https:\/\/t.co\/9HYpoi5bJt #AskPressSec  https:\/\/t.co\/gS6G0XPry5",
    "id" : 667171533106843650,
    "created_at" : "2015-11-19 02:44:23 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 667171767916605440,
  "created_at" : "2015-11-19 02:45:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askpresssec",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/8z307uxcDN",
      "expanded_url" : "http:\/\/1.usa.gov\/1j8AeH3",
      "display_url" : "1.usa.gov\/1j8AeH3"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/LPL44kPouf",
      "expanded_url" : "https:\/\/twitter.com\/ShanFroman2016\/status\/667162110019768320",
      "display_url" : "twitter.com\/ShanFroman2016\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667167414547795968",
  "text" : "RT @PressSec: People of faith (not all Obama supporters) make a strong case: https:\/\/t.co\/8z307uxcDN #askpresssec https:\/\/t.co\/LPL44kPouf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askpresssec",
        "indices" : [ 87, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/8z307uxcDN",
        "expanded_url" : "http:\/\/1.usa.gov\/1j8AeH3",
        "display_url" : "1.usa.gov\/1j8AeH3"
      }, {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/LPL44kPouf",
        "expanded_url" : "https:\/\/twitter.com\/ShanFroman2016\/status\/667162110019768320",
        "display_url" : "twitter.com\/ShanFroman2016\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667165937607581696",
    "text" : "People of faith (not all Obama supporters) make a strong case: https:\/\/t.co\/8z307uxcDN #askpresssec https:\/\/t.co\/LPL44kPouf",
    "id" : 667165937607581696,
    "created_at" : "2015-11-19 02:22:09 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 667167414547795968,
  "created_at" : "2015-11-19 02:28:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 56, 63 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/667161144650547200\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/1xSsCMkaKZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUI7c9LWsAAs_UC.jpg",
      "id_str" : "667161063448817664",
      "id" : 667161063448817664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUI7c9LWsAAs_UC.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/1xSsCMkaKZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667161144650547200",
  "text" : "Refugees have helped shape America for generations\u2014like @Google co-founder Sergey Brin: https:\/\/t.co\/mtBAgDEdIl https:\/\/t.co\/1xSsCMkaKZ",
  "id" : 667161144650547200,
  "created_at" : "2015-11-19 02:03:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667150930903760896\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/Jyei3b3f6l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUIx76sWEAAY5Wj.jpg",
      "id_str" : "667150600241549312",
      "id" : 667150600241549312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUIx76sWEAAY5Wj.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/Jyei3b3f6l"
    } ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667150930903760896",
  "text" : "\"America can ensure our own security while welcoming refugees\" \u2014@POTUS: https:\/\/t.co\/mtBAgDEdIl #RefugeesWelcome https:\/\/t.co\/Jyei3b3f6l",
  "id" : 667150930903760896,
  "created_at" : "2015-11-19 01:22:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 118, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/lK6BWhpAXP",
      "expanded_url" : "http:\/\/n.pr\/1W4nq6Q",
      "display_url" : "n.pr\/1W4nq6Q"
    } ]
  },
  "geo" : { },
  "id_str" : "667141282498805760",
  "text" : "RT @rhodes44: Omar's family and new life in OH: \"I feel happy, excited &amp; at peace inside\" https:\/\/t.co\/lK6BWhpAXP #RefugeesWelcome https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/667138685150715904\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/HWBdvn0C14",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUInGRwUYAAVmjm.png",
        "id_str" : "667138683603017728",
        "id" : 667138683603017728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUInGRwUYAAVmjm.png",
        "sizes" : [ {
          "h" : 284,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 649
        } ],
        "display_url" : "pic.twitter.com\/HWBdvn0C14"
      } ],
      "hashtags" : [ {
        "text" : "RefugeesWelcome",
        "indices" : [ 104, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/lK6BWhpAXP",
        "expanded_url" : "http:\/\/n.pr\/1W4nq6Q",
        "display_url" : "n.pr\/1W4nq6Q"
      } ]
    },
    "geo" : { },
    "id_str" : "667138685150715904",
    "text" : "Omar's family and new life in OH: \"I feel happy, excited &amp; at peace inside\" https:\/\/t.co\/lK6BWhpAXP #RefugeesWelcome https:\/\/t.co\/HWBdvn0C14",
    "id" : 667138685150715904,
    "created_at" : "2015-11-19 00:33:52 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 667141282498805760,
  "created_at" : "2015-11-19 00:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 5, 14 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 53, 69 ]
    }, {
      "text" : "AskPressSec",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667134484056293377",
  "text" : "Join @PressSec for a Q&amp;A from the Philippines on #RefugeesWelcome at 9pm ET\/10am local time. Send him your questions using #AskPressSec.",
  "id" : 667134484056293377,
  "created_at" : "2015-11-19 00:17:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667126525083414532",
  "text" : "RT @OMBPress: 2,174 Syrian refugees admitted to the US since 9\/11\/2001. Not one arrested or deported on terrorism-related grounds https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/IiP4e4uKEj",
        "expanded_url" : "http:\/\/1.usa.gov\/1MVzfBM",
        "display_url" : "1.usa.gov\/1MVzfBM"
      } ]
    },
    "geo" : { },
    "id_str" : "667120612167557124",
    "text" : "2,174 Syrian refugees admitted to the US since 9\/11\/2001. Not one arrested or deported on terrorism-related grounds https:\/\/t.co\/IiP4e4uKEj",
    "id" : 667120612167557124,
    "created_at" : "2015-11-18 23:22:03 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 667126525083414532,
  "created_at" : "2015-11-18 23:45:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667098206912839680\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/sosf4NOchA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUIBZEoWcAA1M_i.jpg",
      "id_str" : "667097225055596544",
      "id" : 667097225055596544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUIBZEoWcAA1M_i.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sosf4NOchA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667098206912839680",
  "text" : "It's a false choice to choose between welcoming refugees and ensuring our own safety: https:\/\/t.co\/mtBAgDEdIl https:\/\/t.co\/sosf4NOchA",
  "id" : 667098206912839680,
  "created_at" : "2015-11-18 21:53:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "indices" : [ 1, 11 ],
      "id_str" : "1707321486",
      "id" : 1707321486
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/667083981742088195\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/BXFObiCmuS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUH1UYwWoAAyOat.jpg",
      "id_str" : "667083950418993152",
      "id" : 667083950418993152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUH1UYwWoAAyOat.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BXFObiCmuS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/IktgGO4iqG",
      "expanded_url" : "http:\/\/ti.me\/1LkE8mI",
      "display_url" : "ti.me\/1LkE8mI"
    } ]
  },
  "geo" : { },
  "id_str" : "667083981742088195",
  "text" : ".@Madeleine on security process for refugees: It works &amp; it shouldn't be stopped or paused. https:\/\/t.co\/IktgGO4iqG https:\/\/t.co\/BXFObiCmuS",
  "id" : 667083981742088195,
  "created_at" : "2015-11-18 20:56:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 3, 15 ],
      "id_str" : "17004618",
      "id" : 17004618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667076937672691712",
  "text" : "RT @NickKristof: \"Syrian refugees are mothers, brothers, orphans...fleeing unthinkable violence...They deserve support, not disdain\" https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/uDwpBOqpgJ",
        "expanded_url" : "http:\/\/campaign.r20.constantcontact.com\/render?ca=43c65259-30d2-4166-8b57-44208b0f0bff&c=7a4a0b80-2946-11e4-8753-d4ae5292c38a&ch=7a69ef90-2946-11e4-8760-d4ae5292c38a",
        "display_url" : "campaign.r20.constantcontact.com\/render?ca=43c6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666771412363907073",
    "text" : "\"Syrian refugees are mothers, brothers, orphans...fleeing unthinkable violence...They deserve support, not disdain\" https:\/\/t.co\/uDwpBOqpgJ",
    "id" : 666771412363907073,
    "created_at" : "2015-11-18 00:14:27 +0000",
    "user" : {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "protected" : false,
      "id_str" : "17004618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680936862387589120\/DfkrlW27_normal.jpg",
      "id" : 17004618,
      "verified" : true
    }
  },
  "id" : 667076937672691712,
  "created_at" : "2015-11-18 20:28:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/667065395115880448\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/TzMJFodZQk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUHj705UcAAyCXh.jpg",
      "id_str" : "667064836778389504",
      "id" : 667064836778389504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUHj705UcAAyCXh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TzMJFodZQk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667065395115880448",
  "text" : "Refugees are subject to the highest level of security checks of any category of traveler. https:\/\/t.co\/mtBAgDEdIl https:\/\/t.co\/TzMJFodZQk",
  "id" : 667065395115880448,
  "created_at" : "2015-11-18 19:42:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gwendolyn",
      "screen_name" : "scvbuckeye",
      "indices" : [ 15, 26 ],
      "id_str" : "72873606",
      "id" : 72873606
    }, {
      "name" : "UN Refugee Agency",
      "screen_name" : "Refugees",
      "indices" : [ 94, 103 ],
      "id_str" : "14361155",
      "id" : 14361155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/rEcDF6YUrF",
      "expanded_url" : "http:\/\/data.unhcr.org\/syrianrefugees\/regional.php",
      "display_url" : "data.unhcr.org\/syrianrefugees\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667050312633552896",
  "text" : "RT @NSCPress: .@scvbuckeye: To see demographics about Syrian refugees, check out data from UN @Refugees: https:\/\/t.co\/rEcDF6YUrF https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gwendolyn",
        "screen_name" : "scvbuckeye",
        "indices" : [ 1, 12 ],
        "id_str" : "72873606",
        "id" : 72873606
      }, {
        "name" : "UN Refugee Agency",
        "screen_name" : "Refugees",
        "indices" : [ 80, 89 ],
        "id_str" : "14361155",
        "id" : 14361155
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/667050114184323073\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/UAH0xzdulS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUHWfhCW4AAUVnU.jpg",
        "id_str" : "667050056760090624",
        "id" : 667050056760090624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUHWfhCW4AAUVnU.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UAH0xzdulS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/rEcDF6YUrF",
        "expanded_url" : "http:\/\/data.unhcr.org\/syrianrefugees\/regional.php",
        "display_url" : "data.unhcr.org\/syrianrefugees\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "667049041100869632",
    "geo" : { },
    "id_str" : "667050114184323073",
    "in_reply_to_user_id" : 72873606,
    "text" : ".@scvbuckeye: To see demographics about Syrian refugees, check out data from UN @Refugees: https:\/\/t.co\/rEcDF6YUrF https:\/\/t.co\/UAH0xzdulS",
    "id" : 667050114184323073,
    "in_reply_to_status_id" : 667049041100869632,
    "created_at" : "2015-11-18 18:41:55 +0000",
    "in_reply_to_screen_name" : "scvbuckeye",
    "in_reply_to_user_id_str" : "72873606",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 667050312633552896,
  "created_at" : "2015-11-18 18:42:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/oqDg5evY0Q",
      "expanded_url" : "http:\/\/snpy.tv\/1QuvtWJ",
      "display_url" : "snpy.tv\/1QuvtWJ"
    } ]
  },
  "geo" : { },
  "id_str" : "667045499975950336",
  "text" : "RT @NSCPress: We agree. That's why refugees undergo the most rigorous screening of any traveler to the US: https:\/\/t.co\/oqDg5evY0Q https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/oqDg5evY0Q",
        "expanded_url" : "http:\/\/snpy.tv\/1QuvtWJ",
        "display_url" : "snpy.tv\/1QuvtWJ"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/s4xE4xo5Nl",
        "expanded_url" : "https:\/\/twitter.com\/mpkhome\/status\/667037352028725252",
        "display_url" : "twitter.com\/mpkhome\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "667043067883626496",
    "text" : "We agree. That's why refugees undergo the most rigorous screening of any traveler to the US: https:\/\/t.co\/oqDg5evY0Q https:\/\/t.co\/s4xE4xo5Nl",
    "id" : 667043067883626496,
    "created_at" : "2015-11-18 18:13:55 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 667045499975950336,
  "created_at" : "2015-11-18 18:23:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667037790245396480\/photo\/1",
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/pKip65WU7q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUHLMpmWwAQXaSS.jpg",
      "id_str" : "667037638013140996",
      "id" : 667037638013140996,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUHLMpmWwAQXaSS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pKip65WU7q"
    } ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 105, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667037790245396480",
  "text" : "We can welcome refugees &amp; ensure our safety. Have questions? Ask @NSCPress for a 1pm ET Q&amp;A with #RefugeesWelcome. https:\/\/t.co\/pKip65WU7q",
  "id" : 667037790245396480,
  "created_at" : "2015-11-18 17:52:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 107, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667030774462443520",
  "text" : "RT @NSCPress: Today at 1:00PM EST, @POTUS\u2019 National Security Staff will answer your questions on refugees. #RefugeesWelcome \u2192 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 21, 27 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RefugeesWelcome",
        "indices" : [ 93, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/NJuCzDcQhp",
        "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
        "display_url" : "go.wh.gov\/RefugeesWelcome"
      } ]
    },
    "geo" : { },
    "id_str" : "667024425020207104",
    "text" : "Today at 1:00PM EST, @POTUS\u2019 National Security Staff will answer your questions on refugees. #RefugeesWelcome \u2192 https:\/\/t.co\/NJuCzDcQhp",
    "id" : 667024425020207104,
    "created_at" : "2015-11-18 16:59:50 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 667030774462443520,
  "created_at" : "2015-11-18 17:25:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/667024871701028864\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/8v7OTGv8bg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUG_VbrXAAAExtN.jpg",
      "id_str" : "667024594755321856",
      "id" : 667024594755321856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUG_VbrXAAAExtN.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8v7OTGv8bg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "667024871701028864",
  "text" : "Get the facts on why we cannot turn our backs on those most threatened by ISIL: https:\/\/t.co\/mtBAgDEdIl https:\/\/t.co\/8v7OTGv8bg",
  "id" : 667024871701028864,
  "created_at" : "2015-11-18 17:01:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667022149337661441",
  "text" : "RT @POTUS: Slamming the door in the face of refugees would betray our deepest values. That's not who we are. And it's not what we're going \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667021076094976002",
    "geo" : { },
    "id_str" : "667021784726769665",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Slamming the door in the face of refugees would betray our deepest values. That's not who we are. And it's not what we're going to do.",
    "id" : 667021784726769665,
    "in_reply_to_status_id" : 667021076094976002,
    "created_at" : "2015-11-18 16:49:20 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 667022149337661441,
  "created_at" : "2015-11-18 16:50:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667021623468433408",
  "text" : "RT @POTUS: Welcoming the world\u2019s vulnerable who seek the safety of America is not new to us. We've safely welcomed 3 million refugees since\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667020445066096640",
    "geo" : { },
    "id_str" : "667021076094976002",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Welcoming the world\u2019s vulnerable who seek the safety of America is not new to us. We've safely welcomed 3 million refugees since 1975.",
    "id" : 667021076094976002,
    "in_reply_to_status_id" : 667020445066096640,
    "created_at" : "2015-11-18 16:46:31 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 667021623468433408,
  "created_at" : "2015-11-18 16:48:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667021129412923393",
  "text" : "RT @POTUS: Here, our focus is giving safe haven to the most vulnerable Syrians \u2013 women, children, and survivors of torture.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667019888234528768",
    "geo" : { },
    "id_str" : "667020445066096640",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Here, our focus is giving safe haven to the most vulnerable Syrians \u2013 women, children, and survivors of torture.",
    "id" : 667020445066096640,
    "in_reply_to_status_id" : 667019888234528768,
    "created_at" : "2015-11-18 16:44:01 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 667021129412923393,
  "created_at" : "2015-11-18 16:46:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667020797437964288",
  "text" : "RT @POTUS: We will provide refuge to at least 10,000 refugees fleeing violence in Syria over the next year after they pass the highest secu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667019384225996800",
    "geo" : { },
    "id_str" : "667019888234528768",
    "in_reply_to_user_id" : 1536791610,
    "text" : "We will provide refuge to at least 10,000 refugees fleeing violence in Syria over the next year after they pass the highest security checks.",
    "id" : 667019888234528768,
    "in_reply_to_status_id" : 667019384225996800,
    "created_at" : "2015-11-18 16:41:48 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 667020797437964288,
  "created_at" : "2015-11-18 16:45:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667020673991225344",
  "text" : "RT @POTUS: We also win this fight with our values. America can ensure our own security while welcoming refugees desperately seeking safety \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "667018696137773056",
    "geo" : { },
    "id_str" : "667019384225996800",
    "in_reply_to_user_id" : 1536791610,
    "text" : "We also win this fight with our values. America can ensure our own security while welcoming refugees desperately seeking safety from ISIL.",
    "id" : 667019384225996800,
    "in_reply_to_status_id" : 667018696137773056,
    "created_at" : "2015-11-18 16:39:48 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 667020673991225344,
  "created_at" : "2015-11-18 16:44:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667018816392572929",
  "text" : "RT @POTUS: Protecting the American people is my top priority. With our 65 global partners, we're leading the campaign to degrade and destro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "667018696137773056",
    "text" : "Protecting the American people is my top priority. With our 65 global partners, we're leading the campaign to degrade and destroy ISIL.",
    "id" : 667018696137773056,
    "created_at" : "2015-11-18 16:37:04 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 667018816392572929,
  "created_at" : "2015-11-18 16:37:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/9DxJo9qFmp",
      "expanded_url" : "http:\/\/snpy.tv\/1QuvtWJ",
      "display_url" : "snpy.tv\/1QuvtWJ"
    } ]
  },
  "geo" : { },
  "id_str" : "667013865947979776",
  "text" : "Get the facts on how we're responding to the refugee crisis and protecting our security: https:\/\/t.co\/mtBAgDEdIl https:\/\/t.co\/9DxJo9qFmp",
  "id" : 667013865947979776,
  "created_at" : "2015-11-18 16:17:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667006689556721664",
  "text" : "RT @NSCPress: It\u2019s Global Entrepreneurship Week! @POTUS just announced the 2016 Global Entrepreneurship Summit in Silicon Valley https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 35, 41 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/hcJsHwKVV1",
        "expanded_url" : "http:\/\/snpy.tv\/1SDN7oI",
        "display_url" : "snpy.tv\/1SDN7oI"
      } ]
    },
    "geo" : { },
    "id_str" : "666996613936615424",
    "text" : "It\u2019s Global Entrepreneurship Week! @POTUS just announced the 2016 Global Entrepreneurship Summit in Silicon Valley https:\/\/t.co\/hcJsHwKVV1",
    "id" : 666996613936615424,
    "created_at" : "2015-11-18 15:09:19 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 667006689556721664,
  "created_at" : "2015-11-18 15:49:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/666818388635709441\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/TbtmW4Xe9L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUEAgcaXAAAtdpj.jpg",
      "id_str" : "666814777210109952",
      "id" : 666814777210109952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUEAgcaXAAAtdpj.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TbtmW4Xe9L"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/mtBAgDmCjL",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "666818388635709441",
  "text" : "America has been welcoming refugees from around the globe for generations. Get the facts: https:\/\/t.co\/mtBAgDmCjL https:\/\/t.co\/TbtmW4Xe9L",
  "id" : 666818388635709441,
  "created_at" : "2015-11-18 03:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Jay Inslee",
      "screen_name" : "GovInslee",
      "indices" : [ 3, 13 ],
      "id_str" : "1077214808",
      "id" : 1077214808
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 26, 37 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666814419708588032",
  "text" : "RT @GovInslee: Briefed by @WhiteHouse on security protocols re: refugee resettlement. They are assuring our citizens are safe: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 11, 22 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/AMOPorfIzi",
        "expanded_url" : "http:\/\/1.usa.gov\/1H7Gg6E",
        "display_url" : "1.usa.gov\/1H7Gg6E"
      } ]
    },
    "geo" : { },
    "id_str" : "666784477448945664",
    "text" : "Briefed by @WhiteHouse on security protocols re: refugee resettlement. They are assuring our citizens are safe: https:\/\/t.co\/AMOPorfIzi",
    "id" : 666784477448945664,
    "created_at" : "2015-11-18 01:06:22 +0000",
    "user" : {
      "name" : "Governor Jay Inslee",
      "screen_name" : "GovInslee",
      "protected" : false,
      "id_str" : "1077214808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738748381569253377\/EcSskMQ8_normal.jpg",
      "id" : 1077214808,
      "verified" : true
    }
  },
  "id" : 666814419708588032,
  "created_at" : "2015-11-18 03:05:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "APEC2015",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/WrJTxNX9pw",
      "expanded_url" : "http:\/\/snpy.tv\/1OekzkE",
      "display_url" : "snpy.tv\/1OekzkE"
    } ]
  },
  "geo" : { },
  "id_str" : "666810849705762817",
  "text" : "\"No nation is immune to the consequences of a changing climate.\" \u2014@POTUS at #APEC2015\n\nIt's time to #ActOnClimate https:\/\/t.co\/WrJTxNX9pw",
  "id" : 666810849705762817,
  "created_at" : "2015-11-18 02:51:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/666805066230341632\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IE85UewTVf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUD3nFpXAAI_ivJ.jpg",
      "id_str" : "666804995753443330",
      "id" : 666804995753443330,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUD3nFpXAAI_ivJ.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IE85UewTVf"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    }, {
      "text" : "APEC2015",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666805066230341632",
  "text" : "\"We\u2019re producing three times as much wind power and 20 times as much solar power.\" \u2014@POTUS #ActOnClimate #APEC2015 https:\/\/t.co\/IE85UewTVf",
  "id" : 666805066230341632,
  "created_at" : "2015-11-18 02:28:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666804137334546432",
  "text" : "\"Already, more than 160 countries representing about 90% of global emissions have put forward climate targets for post-2020.\" \u2014@POTUS",
  "id" : 666804137334546432,
  "created_at" : "2015-11-18 02:24:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666803901941813248",
  "text" : "\"The patterns and the science don\u2019t lie\u2014temperatures and sea levels are rising; ice caps are melting; storms are strengthening.\"  \u2014@POTUS",
  "id" : 666803901941813248,
  "created_at" : "2015-11-18 02:23:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "APEC2015",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666803581555769348",
  "text" : "\"Here at APEC, we\u2019re working to deepen our economic cooperation in a way that is sustainable for our communities.\" \u2014@POTUS at #APEC2015",
  "id" : 666803581555769348,
  "created_at" : "2015-11-18 02:22:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "APEC2015",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/90r3O2EVVj",
      "expanded_url" : "http:\/\/go.wh.gov\/xdsD7m",
      "display_url" : "go.wh.gov\/xdsD7m"
    } ]
  },
  "geo" : { },
  "id_str" : "666802950749204481",
  "text" : "Tune in: @POTUS speaks at the #APEC2015 CEO Summit in Manila, Philippines \u2192  https:\/\/t.co\/90r3O2EVVj",
  "id" : 666802950749204481,
  "created_at" : "2015-11-18 02:19:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Jeanne Shaheen",
      "screen_name" : "SenatorShaheen",
      "indices" : [ 3, 18 ],
      "id_str" : "109287731",
      "id" : 109287731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666782349728837632",
  "text" : "RT @SenatorShaheen: Unlike many EU countries w\/overwhelmed borders &amp; minimal screening, refugees seeking US entry undergo rigorous processi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666718966979493888",
    "text" : "Unlike many EU countries w\/overwhelmed borders &amp; minimal screening, refugees seeking US entry undergo rigorous processing that can take yrs",
    "id" : 666718966979493888,
    "created_at" : "2015-11-17 20:46:03 +0000",
    "user" : {
      "name" : "Sen. Jeanne Shaheen",
      "screen_name" : "SenatorShaheen",
      "protected" : false,
      "id_str" : "109287731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743472529445109760\/Q05EXt9M_normal.jpg",
      "id" : 109287731,
      "verified" : true
    }
  },
  "id" : 666782349728837632,
  "created_at" : "2015-11-18 00:57:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "indices" : [ 3, 13 ],
      "id_str" : "1707321486",
      "id" : 1707321486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666776636436684801",
  "text" : "RT @madeleine: USA should embrace refugees, not fear them. Words on Statue of Liberty shouldn't be empty promise #RefugeesWelcome  https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RefugeesWelcome",
        "indices" : [ 98, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/NeCWLz2w24",
        "expanded_url" : "http:\/\/time.com\/4117333\/madeleine-albright-refugees\/",
        "display_url" : "time.com\/4117333\/madele\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666770241343643648",
    "text" : "USA should embrace refugees, not fear them. Words on Statue of Liberty shouldn't be empty promise #RefugeesWelcome  https:\/\/t.co\/NeCWLz2w24",
    "id" : 666770241343643648,
    "created_at" : "2015-11-18 00:09:48 +0000",
    "user" : {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "protected" : false,
      "id_str" : "1707321486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482147628650856448\/oTqqAjkX_normal.jpeg",
      "id" : 1707321486,
      "verified" : true
    }
  },
  "id" : 666776636436684801,
  "created_at" : "2015-11-18 00:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Bob Casey",
      "screen_name" : "SenBobCasey",
      "indices" : [ 3, 15 ],
      "id_str" : "171598736",
      "id" : 171598736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666758804227432448",
  "text" : "RT @SenBobCasey: Of the 12 million Syrians displaced from their homes half are children. We cannot turn our back on them. https:\/\/t.co\/x4tP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/x4tPHK4Ab9",
        "expanded_url" : "http:\/\/www.casey.senate.gov\/newsroom\/releases\/casey-statement-on-admission-of-syrian-refugees",
        "display_url" : "casey.senate.gov\/newsroom\/relea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666714639443632129",
    "text" : "Of the 12 million Syrians displaced from their homes half are children. We cannot turn our back on them. https:\/\/t.co\/x4tPHK4Ab9",
    "id" : 666714639443632129,
    "created_at" : "2015-11-17 20:28:51 +0000",
    "user" : {
      "name" : "Senator Bob Casey",
      "screen_name" : "SenBobCasey",
      "protected" : false,
      "id_str" : "171598736",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748886037649297408\/B4cLMsR__normal.jpg",
      "id" : 171598736,
      "verified" : true
    }
  },
  "id" : 666758804227432448,
  "created_at" : "2015-11-17 23:24:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/666755310825177088\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/EUzCcpI62I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUDJZg4UkAA1ozX.jpg",
      "id_str" : "666754185010909184",
      "id" : 666754185010909184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUDJZg4UkAA1ozX.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EUzCcpI62I"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "666755310825177088",
  "text" : "Refugees have helped shape America. We can welcome refugees and ensure our own safety: https:\/\/t.co\/mtBAgDEdIl https:\/\/t.co\/EUzCcpI62I",
  "id" : 666755310825177088,
  "created_at" : "2015-11-17 23:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666736713541251072",
  "text" : "RT @NancyPelosi: We can both welcome refugees &amp; ensure our own security. No terrorist\u2019s hate can overcome the strength of US values. https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/mNS76UU94O",
        "expanded_url" : "http:\/\/goo.gl\/fkXXCo",
        "display_url" : "goo.gl\/fkXXCo"
      } ]
    },
    "geo" : { },
    "id_str" : "666721777343668224",
    "text" : "We can both welcome refugees &amp; ensure our own security. No terrorist\u2019s hate can overcome the strength of US values. https:\/\/t.co\/mNS76UU94O",
    "id" : 666721777343668224,
    "created_at" : "2015-11-17 20:57:13 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 666736713541251072,
  "created_at" : "2015-11-17 21:56:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Embassy France",
      "screen_name" : "USEmbassyFrance",
      "indices" : [ 3, 19 ],
      "id_str" : "72814599",
      "id" : 72814599
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/jHcS6xZKwe",
      "expanded_url" : "https:\/\/youtu.be\/SOxgMIxHwvE",
      "display_url" : "youtu.be\/SOxgMIxHwvE"
    } ]
  },
  "geo" : { },
  "id_str" : "666729554002751489",
  "text" : "RT @USEmbassyFrance: Today, we are all French. The U.S. stands shoulder to shoulder with the people of France. https:\/\/t.co\/jHcS6xZKwe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/jHcS6xZKwe",
        "expanded_url" : "https:\/\/youtu.be\/SOxgMIxHwvE",
        "display_url" : "youtu.be\/SOxgMIxHwvE"
      } ]
    },
    "geo" : { },
    "id_str" : "666553831292059648",
    "text" : "Today, we are all French. The U.S. stands shoulder to shoulder with the people of France. https:\/\/t.co\/jHcS6xZKwe",
    "id" : 666553831292059648,
    "created_at" : "2015-11-17 09:49:52 +0000",
    "user" : {
      "name" : "U.S. Embassy France",
      "screen_name" : "USEmbassyFrance",
      "protected" : false,
      "id_str" : "72814599",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675251330596868097\/JlxM8uiP_normal.jpg",
      "id" : 72814599,
      "verified" : true
    }
  },
  "id" : 666729554002751489,
  "created_at" : "2015-11-17 21:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/666624338532155392\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/XNNzjQ7VBU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUBTTW_WoAECXjv.png",
      "id_str" : "666624336904757249",
      "id" : 666624336904757249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUBTTW_WoAECXjv.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XNNzjQ7VBU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/0nwqbOsTT0",
      "expanded_url" : "http:\/\/nyti.ms\/1Odp9Q6",
      "display_url" : "nyti.ms\/1Odp9Q6"
    } ]
  },
  "geo" : { },
  "id_str" : "666711655456358400",
  "text" : "RT @nytimes: The United Nations\u2019 agency says refugees should not be turned into scapegoats https:\/\/t.co\/0nwqbOsTT0 https:\/\/t.co\/XNNzjQ7VBU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/666624338532155392\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/XNNzjQ7VBU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUBTTW_WoAECXjv.png",
        "id_str" : "666624336904757249",
        "id" : 666624336904757249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUBTTW_WoAECXjv.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XNNzjQ7VBU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/0nwqbOsTT0",
        "expanded_url" : "http:\/\/nyti.ms\/1Odp9Q6",
        "display_url" : "nyti.ms\/1Odp9Q6"
      } ]
    },
    "geo" : { },
    "id_str" : "666624338532155392",
    "text" : "The United Nations\u2019 agency says refugees should not be turned into scapegoats https:\/\/t.co\/0nwqbOsTT0 https:\/\/t.co\/XNNzjQ7VBU",
    "id" : 666624338532155392,
    "created_at" : "2015-11-17 14:30:02 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 666711655456358400,
  "created_at" : "2015-11-17 20:17:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/l2tbRM131V",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/afc5deb5-2aae-43c5-b177-ce592750a945",
      "display_url" : "amp.twimg.com\/v\/afc5deb5-2aa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666704511063433217",
  "text" : "FACT: Our coalition is intensifying airstrikes against ISIL. We've already launched more than 8,000 to date. https:\/\/t.co\/l2tbRM131V",
  "id" : 666704511063433217,
  "created_at" : "2015-11-17 19:48:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Ioffe",
      "screen_name" : "juliaioffe",
      "indices" : [ 3, 14 ],
      "id_str" : "71048726",
      "id" : 71048726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666691452488011776",
  "text" : "RT @juliaioffe: I am going to re-up this today. I was a refugee and I am so grateful the U.S. let me and my family in. https:\/\/t.co\/ozLq6TT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/ozLq6TTNRc",
        "expanded_url" : "http:\/\/foreignpolicy.com\/2015\/09\/07\/je-suis-refugee-europe-migrant-crisis-russia\/",
        "display_url" : "foreignpolicy.com\/2015\/09\/07\/je-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666633726814744576",
    "text" : "I am going to re-up this today. I was a refugee and I am so grateful the U.S. let me and my family in. https:\/\/t.co\/ozLq6TTNRc",
    "id" : 666633726814744576,
    "created_at" : "2015-11-17 15:07:20 +0000",
    "user" : {
      "name" : "Julia Ioffe",
      "screen_name" : "juliaioffe",
      "protected" : false,
      "id_str" : "71048726",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/395174322\/octoberist_twitter_normal.jpg",
      "id" : 71048726,
      "verified" : true
    }
  },
  "id" : 666691452488011776,
  "created_at" : "2015-11-17 18:56:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/666688825406693376\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/C2s5iQTYeO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUCNx59WsAAHwOD.jpg",
      "id_str" : "666688633362100224",
      "id" : 666688633362100224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUCNx59WsAAHwOD.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C2s5iQTYeO"
    } ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 101, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/mtBAgDEdIl",
      "expanded_url" : "http:\/\/go.wh.gov\/RefugeesWelcome",
      "display_url" : "go.wh.gov\/RefugeesWelcome"
    } ]
  },
  "geo" : { },
  "id_str" : "666688825406693376",
  "text" : "America can welcome refugees &amp; ensure our own security at the same time: https:\/\/t.co\/mtBAgDEdIl #RefugeesWelcome https:\/\/t.co\/C2s5iQTYeO",
  "id" : 666688825406693376,
  "created_at" : "2015-11-17 18:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 3, 7 ],
      "id_str" : "759251",
      "id" : 759251
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CNN\/status\/666678709303250945\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/0OpXQJSca4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUCEwPWXAAE-Q1n.jpg",
      "id_str" : "666678709139734529",
      "id" : 666678709139734529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUCEwPWXAAE-Q1n.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/0OpXQJSca4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Ooy25EudEd",
      "expanded_url" : "http:\/\/cnn.it\/1l3esps",
      "display_url" : "cnn.it\/1l3esps"
    } ]
  },
  "geo" : { },
  "id_str" : "666683725594406916",
  "text" : "RT @CNN: Delaware governor: Why my state won't turn refugees away https:\/\/t.co\/Ooy25EudEd https:\/\/t.co\/0OpXQJSca4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CNN\/status\/666678709303250945\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/0OpXQJSca4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUCEwPWXAAE-Q1n.jpg",
        "id_str" : "666678709139734529",
        "id" : 666678709139734529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUCEwPWXAAE-Q1n.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/0OpXQJSca4"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/Ooy25EudEd",
        "expanded_url" : "http:\/\/cnn.it\/1l3esps",
        "display_url" : "cnn.it\/1l3esps"
      } ]
    },
    "geo" : { },
    "id_str" : "666678709303250945",
    "text" : "Delaware governor: Why my state won't turn refugees away https:\/\/t.co\/Ooy25EudEd https:\/\/t.co\/0OpXQJSca4",
    "id" : 666678709303250945,
    "created_at" : "2015-11-17 18:06:05 +0000",
    "user" : {
      "name" : "CNN",
      "screen_name" : "CNN",
      "protected" : false,
      "id_str" : "759251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508960761826131968\/LnvhR8ED_normal.png",
      "id" : 759251,
      "verified" : true
    }
  },
  "id" : 666683725594406916,
  "created_at" : "2015-11-17 18:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/oDIQ2V3W6i",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/l2tbRMiDTt",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/afc5deb5-2aae-43c5-b177-ce592750a945",
      "display_url" : "amp.twimg.com\/v\/afc5deb5-2aa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666679651410948096",
  "text" : "Watch: @POTUS lays out the key components of our strategy to degrade and destroy ISIL \u2192 https:\/\/t.co\/oDIQ2V3W6i\nhttps:\/\/t.co\/l2tbRMiDTt",
  "id" : 666679651410948096,
  "created_at" : "2015-11-17 18:09:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 31, 40 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 68, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/Ha245v3rhP",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/019c3d37-7e84-4c1b-90d5-a1f9dcc0e6f8",
      "display_url" : "amp.twimg.com\/v\/019c3d37-7e8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666665897575084032",
  "text" : "Travel aboard Air Force One as @Rhodes44 recaps @POTUS\u2019 trip to the #G20 Summit in Turkey:\nhttps:\/\/t.co\/Ha245v3rhP",
  "id" : 666665897575084032,
  "created_at" : "2015-11-17 17:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Salt Lake Tribune",
      "screen_name" : "sltrib",
      "indices" : [ 3, 10 ],
      "id_str" : "15369276",
      "id" : 15369276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "utpol",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/iuhxvuUfVj",
      "expanded_url" : "http:\/\/www.sltrib.com\/news\/3186821-155\/utah-guv-says-state-will-still",
      "display_url" : "sltrib.com\/news\/3186821-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666663050905300993",
  "text" : "RT @sltrib: Herbert bucks the trend of GOP governors and says Utah will welcome Syrian refugees:\nhttps:\/\/t.co\/iuhxvuUfVj\n#utpol https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sltrib\/status\/666431844179546112\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/wh3VyTew5m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT-dKuIVEAEskI6.png",
        "id_str" : "666424077381341185",
        "id" : 666424077381341185,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT-dKuIVEAEskI6.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 254
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 254
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 254
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 254
        } ],
        "display_url" : "pic.twitter.com\/wh3VyTew5m"
      } ],
      "hashtags" : [ {
        "text" : "utpol",
        "indices" : [ 109, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/iuhxvuUfVj",
        "expanded_url" : "http:\/\/www.sltrib.com\/news\/3186821-155\/utah-guv-says-state-will-still",
        "display_url" : "sltrib.com\/news\/3186821-1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666431844179546112",
    "text" : "Herbert bucks the trend of GOP governors and says Utah will welcome Syrian refugees:\nhttps:\/\/t.co\/iuhxvuUfVj\n#utpol https:\/\/t.co\/wh3VyTew5m",
    "id" : 666431844179546112,
    "created_at" : "2015-11-17 01:45:08 +0000",
    "user" : {
      "name" : "Salt Lake Tribune",
      "screen_name" : "sltrib",
      "protected" : false,
      "id_str" : "15369276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1349198782\/tribuneicon-red2_normal.png",
      "id" : 15369276,
      "verified" : true
    }
  },
  "id" : 666663050905300993,
  "created_at" : "2015-11-17 17:03:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Denver Post",
      "screen_name" : "denverpost",
      "indices" : [ 3, 14 ],
      "id_str" : "8216772",
      "id" : 8216772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Colorado",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "SyrianRefugees",
      "indices" : [ 47, 62 ]
    }, {
      "text" : "copolitics",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/uDXBFgCf5w",
      "expanded_url" : "http:\/\/dpo.st\/1MNEHec",
      "display_url" : "dpo.st\/1MNEHec"
    } ]
  },
  "geo" : { },
  "id_str" : "666653442799104000",
  "text" : "RT @denverpost: JUST IN: #Colorado will accept #SyrianRefugees, Hickenlooper says: https:\/\/t.co\/uDXBFgCf5w #copolitics https:\/\/t.co\/ZKCRoQ6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/denverpost\/status\/666365623677485056\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/ZKCRoQ6YSs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT9n9ZGVAAAXqu-.jpg",
        "id_str" : "666365574281232384",
        "id" : 666365574281232384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT9n9ZGVAAAXqu-.jpg",
        "sizes" : [ {
          "h" : 435,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZKCRoQ6YSs"
      } ],
      "hashtags" : [ {
        "text" : "Colorado",
        "indices" : [ 9, 18 ]
      }, {
        "text" : "SyrianRefugees",
        "indices" : [ 31, 46 ]
      }, {
        "text" : "copolitics",
        "indices" : [ 91, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/uDXBFgCf5w",
        "expanded_url" : "http:\/\/dpo.st\/1MNEHec",
        "display_url" : "dpo.st\/1MNEHec"
      } ]
    },
    "geo" : { },
    "id_str" : "666365623677485056",
    "text" : "JUST IN: #Colorado will accept #SyrianRefugees, Hickenlooper says: https:\/\/t.co\/uDXBFgCf5w #copolitics https:\/\/t.co\/ZKCRoQ6YSs",
    "id" : 666365623677485056,
    "created_at" : "2015-11-16 21:21:59 +0000",
    "user" : {
      "name" : "The Denver Post",
      "screen_name" : "denverpost",
      "protected" : false,
      "id_str" : "8216772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696779704150335488\/yF8sCXSN_normal.jpg",
      "id" : 8216772,
      "verified" : true
    }
  },
  "id" : 666653442799104000,
  "created_at" : "2015-11-17 16:25:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/666641671724122112\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/3B5985cqrg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUBi-OEXIAAU3Xh.jpg",
      "id_str" : "666641565918633984",
      "id" : 666641565918633984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUBi-OEXIAAU3Xh.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/3B5985cqrg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/tE5Yy4RL8n",
      "expanded_url" : "http:\/\/go.wh.gov\/Manila",
      "display_url" : "go.wh.gov\/Manila"
    } ]
  },
  "geo" : { },
  "id_str" : "666641671724122112",
  "text" : "Find out why @POTUS was on a cutter &amp; how we're strengthening the security of Philippines \u2192 https:\/\/t.co\/tE5Yy4RL8n https:\/\/t.co\/3B5985cqrg",
  "id" : 666641671724122112,
  "created_at" : "2015-11-17 15:38:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/hlkgf61PMQ",
      "expanded_url" : "https:\/\/www.nasa.gov\/audience\/foreducators\/a-lifetime-of-stem.html",
      "display_url" : "nasa.gov\/audience\/fored\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666638331430744064",
  "text" : "RT @NASA: Katherine Johnson, to be awarded the Presidential Medal of Freedom, led a lifetime of math: https:\/\/t.co\/hlkgf61PMQ https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/666380033334841344\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/uWS5uNZYAX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT91G8PWcAEduPe.jpg",
        "id_str" : "666380031984300033",
        "id" : 666380031984300033,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT91G8PWcAEduPe.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2249,
          "resize" : "fit",
          "w" : 3000
        } ],
        "display_url" : "pic.twitter.com\/uWS5uNZYAX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/hlkgf61PMQ",
        "expanded_url" : "https:\/\/www.nasa.gov\/audience\/foreducators\/a-lifetime-of-stem.html",
        "display_url" : "nasa.gov\/audience\/fored\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666380033334841344",
    "text" : "Katherine Johnson, to be awarded the Presidential Medal of Freedom, led a lifetime of math: https:\/\/t.co\/hlkgf61PMQ https:\/\/t.co\/uWS5uNZYAX",
    "id" : 666380033334841344,
    "created_at" : "2015-11-16 22:19:15 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 666638331430744064,
  "created_at" : "2015-11-17 15:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 37, 43 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TechHire",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666631262166245376",
  "text" : "RT @USDOL: BREAKING: @WhiteHouse and @USDOL launch $100 million #TechHire grant competition including $50 million for youth. https:\/\/t.co\/r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 10, 21 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "US Labor Department",
        "screen_name" : "USDOL",
        "indices" : [ 26, 32 ],
        "id_str" : "20179628",
        "id" : 20179628
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/666626741859938306\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/rNqgkddcAQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CUBVeF5W4AAXclA.png",
        "id_str" : "666626720318021632",
        "id" : 666626720318021632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUBVeF5W4AAXclA.png",
        "sizes" : [ {
          "h" : 78,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 137,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 175,
          "resize" : "fit",
          "w" : 767
        }, {
          "h" : 175,
          "resize" : "fit",
          "w" : 767
        } ],
        "display_url" : "pic.twitter.com\/rNqgkddcAQ"
      } ],
      "hashtags" : [ {
        "text" : "TechHire",
        "indices" : [ 53, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666626741859938306",
    "text" : "BREAKING: @WhiteHouse and @USDOL launch $100 million #TechHire grant competition including $50 million for youth. https:\/\/t.co\/rNqgkddcAQ",
    "id" : 666626741859938306,
    "created_at" : "2015-11-17 14:39:35 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 666631262166245376,
  "created_at" : "2015-11-17 14:57:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MayorSlay.com",
      "screen_name" : "MayorSlay",
      "indices" : [ 3, 13 ],
      "id_str" : "16332522",
      "id" : 16332522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fgs",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666395334814265344",
  "text" : "RT @MayorSlay: I see the other lesson. The terror in Paris redoubles my resolve to offer STL as a better home for Syrian refugees. #fgs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fgs",
        "indices" : [ 116, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665596351267233792",
    "text" : "I see the other lesson. The terror in Paris redoubles my resolve to offer STL as a better home for Syrian refugees. #fgs",
    "id" : 665596351267233792,
    "created_at" : "2015-11-14 18:25:10 +0000",
    "user" : {
      "name" : "MayorSlay.com",
      "screen_name" : "MayorSlay",
      "protected" : false,
      "id_str" : "16332522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2756545289\/05bd2ce1e341434544143eb7ce41b2ac_normal.png",
      "id" : 16332522,
      "verified" : true
    }
  },
  "id" : 666395334814265344,
  "created_at" : "2015-11-16 23:20:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcia Snyder",
      "screen_name" : "GovSteveBeshear",
      "indices" : [ 3, 19 ],
      "id_str" : "4549215252",
      "id" : 4549215252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666389542874779649",
  "text" : "RT @GovSteveBeshear: In terms of refugees--these are women &amp; children and people who are in desperate need, &amp; if America needs to help out,\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666374000130572288",
    "text" : "In terms of refugees--these are women &amp; children and people who are in desperate need, &amp; if America needs to help out, we will help out. 3\/3",
    "id" : 666374000130572288,
    "created_at" : "2015-11-16 21:55:16 +0000",
    "user" : {
      "name" : "Steve Beshear",
      "screen_name" : "Steve__Beshear",
      "protected" : false,
      "id_str" : "37656339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674302651681648640\/9IZtv6cB_normal.jpg",
      "id" : 37656339,
      "verified" : false
    }
  },
  "id" : 666389542874779649,
  "created_at" : "2015-11-16 22:57:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/iL6ObNCYom",
      "expanded_url" : "http:\/\/go.wh.gov\/X3UdiB",
      "display_url" : "go.wh.gov\/X3UdiB"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Xs4fRRBaGp",
      "expanded_url" : "http:\/\/snpy.tv\/1MMMvNw",
      "display_url" : "snpy.tv\/1MMMvNw"
    } ]
  },
  "geo" : { },
  "id_str" : "666352416682569728",
  "text" : "\"We are united against this threat.\" \u2014@POTUS on the international coalition to fight ISIL: https:\/\/t.co\/iL6ObNCYom https:\/\/t.co\/Xs4fRRBaGp",
  "id" : 666352416682569728,
  "created_at" : "2015-11-16 20:29:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senate Democrats",
      "screen_name" : "SenateDems",
      "indices" : [ 3, 14 ],
      "id_str" : "73238146",
      "id" : 73238146
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/waKfN6bfzS",
      "expanded_url" : "https:\/\/www.facebook.com\/USSenateDemocrats\/videos\/vb.119747438094459\/914679228601272\/?type=2&theater",
      "display_url" : "facebook.com\/USSenateDemocr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666339535396184066",
  "text" : "RT @SenateDems: Watch @POTUS reject Muslim-bashing by passionately defending American values: https:\/\/t.co\/waKfN6bfzS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/waKfN6bfzS",
        "expanded_url" : "https:\/\/www.facebook.com\/USSenateDemocrats\/videos\/vb.119747438094459\/914679228601272\/?type=2&theater",
        "display_url" : "facebook.com\/USSenateDemocr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "666295802650849280",
    "text" : "Watch @POTUS reject Muslim-bashing by passionately defending American values: https:\/\/t.co\/waKfN6bfzS",
    "id" : 666295802650849280,
    "created_at" : "2015-11-16 16:44:33 +0000",
    "user" : {
      "name" : "Senate Democrats",
      "screen_name" : "SenateDems",
      "protected" : false,
      "id_str" : "73238146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1214915758\/Reid_and_Dem_Senate_leadership_normal.jpg",
      "id" : 73238146,
      "verified" : true
    }
  },
  "id" : 666339535396184066,
  "created_at" : "2015-11-16 19:38:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/NkKgSQHCE7",
      "expanded_url" : "http:\/\/snpy.tv\/1kAmIxH",
      "display_url" : "snpy.tv\/1kAmIxH"
    } ]
  },
  "geo" : { },
  "id_str" : "666300724536561664",
  "text" : "\"We do not close our hearts to these victims of such violence.\" \u2014@POTUS on the Syrian refugee crisis https:\/\/t.co\/NkKgSQHCE7",
  "id" : 666300724536561664,
  "created_at" : "2015-11-16 17:04:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Paris",
      "indices" : [ 52, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666295831369240576",
  "text" : "RT @NSCPress: Honoring the victims of the attack in #Paris, @POTUS ordered flags to be flown at half-staff through 11\/19\/15 https:\/\/t.co\/7A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 46, 52 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/666280967892545536\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/7AWs8AiyER",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT8bAmBWIAAsjvz.jpg",
        "id_str" : "666280966894264320",
        "id" : 666280966894264320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT8bAmBWIAAsjvz.jpg",
        "sizes" : [ {
          "h" : 560,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2800,
          "resize" : "fit",
          "w" : 1700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 988,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1687,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7AWs8AiyER"
      } ],
      "hashtags" : [ {
        "text" : "Paris",
        "indices" : [ 38, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666280967892545536",
    "text" : "Honoring the victims of the attack in #Paris, @POTUS ordered flags to be flown at half-staff through 11\/19\/15 https:\/\/t.co\/7AWs8AiyER",
    "id" : 666280967892545536,
    "created_at" : "2015-11-16 15:45:36 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 666295831369240576,
  "created_at" : "2015-11-16 16:44:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/rI7IbBxHnv",
      "expanded_url" : "http:\/\/snpy.tv\/1MMQQQT",
      "display_url" : "snpy.tv\/1MMQQQT"
    } ]
  },
  "geo" : { },
  "id_str" : "666290636505620481",
  "text" : "\"The overwhelming majority of victims of ISIL are themselves Muslims.\" \u2014@POTUS https:\/\/t.co\/rI7IbBxHnv",
  "id" : 666290636505620481,
  "created_at" : "2015-11-16 16:24:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/IylQ5jEj3r",
      "expanded_url" : "http:\/\/snpy.tv\/1MMPZzB",
      "display_url" : "snpy.tv\/1MMPZzB"
    } ]
  },
  "geo" : { },
  "id_str" : "666281348328484864",
  "text" : ".@POTUS on why putting large numbers of U.S. troops on the ground in Syria and Iraq would be a mistake. https:\/\/t.co\/IylQ5jEj3r",
  "id" : 666281348328484864,
  "created_at" : "2015-11-16 15:47:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/oxNHay5dif",
      "expanded_url" : "http:\/\/snpy.tv\/1MMOhhx",
      "display_url" : "snpy.tv\/1MMOhhx"
    } ]
  },
  "geo" : { },
  "id_str" : "666274602570547202",
  "text" : "\"Slamming the door in their face would be a betrayal of our values.\" \u2014@POTUS on Syrian refugees https:\/\/t.co\/oxNHay5dif",
  "id" : 666274602570547202,
  "created_at" : "2015-11-16 15:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Xs4fRRBaGp",
      "expanded_url" : "http:\/\/snpy.tv\/1MMMvNw",
      "display_url" : "snpy.tv\/1MMMvNw"
    } ]
  },
  "geo" : { },
  "id_str" : "666271702993739776",
  "text" : "\"The attacks in Paris remind us that it will not be enough to defeat ISIL in Syria and Iraq alone.\" \u2014@POTUS https:\/\/t.co\/Xs4fRRBaGp",
  "id" : 666271702993739776,
  "created_at" : "2015-11-16 15:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666269844392837120",
  "text" : "\"For the 1st time, all the major countries on all sides of this Syrian conflict agree on the process that\u2019s needed to end this war\" \u2014@POTUS",
  "id" : 666269844392837120,
  "created_at" : "2015-11-16 15:01:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666268888909217792",
  "text" : "\"Here at the G-20, our nations have sent an unmistakable message\u2014we are united against this threat.\" \u2014@POTUS on our fight against ISIL",
  "id" : 666268888909217792,
  "created_at" : "2015-11-16 14:57:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666268846295269376",
  "text" : "\"Our nations therefore committed to strengthening border controls, sharing more information and stepping up our efforts.\" \u2014@POTUS",
  "id" : 666268846295269376,
  "created_at" : "2015-11-16 14:57:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666267841411313664",
  "text" : "RT @WHLive: \"I want to thank President Erdogan and the people of Antalya and Turkey for their outstanding work in hosting this G-20 summit\"\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 129, 135 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666267800667844608",
    "text" : "\"I want to thank President Erdogan and the people of Antalya and Turkey for their outstanding work in hosting this G-20 summit\" \u2014@POTUS",
    "id" : 666267800667844608,
    "created_at" : "2015-11-16 14:53:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 666267841411313664,
  "created_at" : "2015-11-16 14:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 31, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/t6jJUYYxHK",
      "expanded_url" : "http:\/\/go.wh.gov\/119QDs",
      "display_url" : "go.wh.gov\/119QDs"
    } ]
  },
  "geo" : { },
  "id_str" : "666267540579069952",
  "text" : "Watch live: @POTUS speaks at a #G20 press conference in Turkey \u2192https:\/\/t.co\/t6jJUYYxHK",
  "id" : 666267540579069952,
  "created_at" : "2015-11-16 14:52:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666102434373181440",
  "text" : "RT @JohnKerry: Reps from 19 delegations met in Vienna today toward Syrian political solution. Paris attacks stiffen resolve to work hard to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665583864870473728",
    "text" : "Reps from 19 delegations met in Vienna today toward Syrian political solution. Paris attacks stiffen resolve to work hard to fight terror.",
    "id" : 665583864870473728,
    "created_at" : "2015-11-14 17:35:33 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 666102434373181440,
  "created_at" : "2015-11-16 03:56:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/666091445665820672\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/DxinKeZmIj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT5uA5BWoAA1RRq.jpg",
      "id_str" : "666090756482965504",
      "id" : 666090756482965504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT5uA5BWoAA1RRq.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DxinKeZmIj"
    } ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666091445665820672",
  "text" : "World leaders at the #G20 Summit observe a moment of silence for the victims of the terrorist attacks in Paris. https:\/\/t.co\/DxinKeZmIj",
  "id" : 666091445665820672,
  "created_at" : "2015-11-16 03:12:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/666083939627462656\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/jRuXrv6hmO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT5n0CnUAAADW_E.jpg",
      "id_str" : "666083938650030080",
      "id" : 666083938650030080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT5n0CnUAAADW_E.jpg",
      "sizes" : [ {
        "h" : 2553,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 934,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 547,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jRuXrv6hmO"
    } ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 34, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/C3htRp6A5P",
      "expanded_url" : "http:\/\/go.wh.gov\/UBDPQt",
      "display_url" : "go.wh.gov\/UBDPQt"
    } ]
  },
  "geo" : { },
  "id_str" : "666083939627462656",
  "text" : ".@POTUS arrives in Turkey for the #G20 Summit: https:\/\/t.co\/C3htRp6A5P https:\/\/t.co\/jRuXrv6hmO",
  "id" : 666083939627462656,
  "created_at" : "2015-11-16 02:42:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/2HRVgJmuuo",
      "expanded_url" : "http:\/\/snpy.tv\/1j082WW",
      "display_url" : "snpy.tv\/1j082WW"
    } ]
  },
  "geo" : { },
  "id_str" : "665948319655555073",
  "text" : "\"Every American should know that our veterans are some of the most talented, capable people in the world.\" \u2014@POTUS https:\/\/t.co\/2HRVgJmuuo",
  "id" : 665948319655555073,
  "created_at" : "2015-11-15 17:43:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665566088923627520",
  "text" : "RT @JohnKerry: Our hearts go out to the people of Paris, to the French, to people of other countries who lost their lives last night in atr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665506033079468032",
    "text" : "Our hearts go out to the people of Paris, to the French, to people of other countries who lost their lives last night in atrocious attack.",
    "id" : 665506033079468032,
    "created_at" : "2015-11-14 12:26:17 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 665566088923627520,
  "created_at" : "2015-11-14 16:24:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/665393766413369344\/photo\/1",
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/6tn4vXX39e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTv0D35WoAAkmKs.png",
      "id_str" : "665393717348573184",
      "id" : 665393717348573184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTv0D35WoAAkmKs.png",
      "sizes" : [ {
        "h" : 222,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 111,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6tn4vXX39e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665393766413369344",
  "text" : "Readout of President Obama's Call with President Hollande of France: https:\/\/t.co\/6tn4vXX39e",
  "id" : 665393766413369344,
  "created_at" : "2015-11-14 05:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665321780966354944",
  "text" : "RT @VP: Our hearts are with Paris tonight. As we learn more about these tragic attacks, we stand together. We will never bow. We will never\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665321679606980609",
    "text" : "Our hearts are with Paris tonight. As we learn more about these tragic attacks, we stand together. We will never bow. We will never break.",
    "id" : 665321679606980609,
    "created_at" : "2015-11-14 00:13:44 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 665321780966354944,
  "created_at" : "2015-11-14 00:14:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/yQThOvrdxZ",
      "expanded_url" : "http:\/\/snpy.tv\/1iZLlSy",
      "display_url" : "snpy.tv\/1iZLlSy"
    } ]
  },
  "geo" : { },
  "id_str" : "665310041554075652",
  "text" : "\"This is an attack on all of humanity and the universal values that we share.\" \u2014@POTUS on the attacks in Paris https:\/\/t.co\/yQThOvrdxZ",
  "id" : 665310041554075652,
  "created_at" : "2015-11-13 23:27:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/yQThOvrdxZ",
      "expanded_url" : "http:\/\/snpy.tv\/1iZLlSy",
      "display_url" : "snpy.tv\/1iZLlSy"
    } ]
  },
  "geo" : { },
  "id_str" : "665301298871308289",
  "text" : "Watch the full statement from @POTUS on the attacks in Paris. https:\/\/t.co\/yQThOvrdxZ",
  "id" : 665301298871308289,
  "created_at" : "2015-11-13 22:52:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665300160910462977",
  "text" : "\"We stand prepared and ready to provide whatever assistance the government and the people of France need to respond.\" \u2014@POTUS",
  "id" : 665300160910462977,
  "created_at" : "2015-11-13 22:48:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/dPiUSKHDlH",
      "expanded_url" : "http:\/\/go.wh.gov\/K4vtpL",
      "display_url" : "go.wh.gov\/K4vtpL"
    } ]
  },
  "geo" : { },
  "id_str" : "665299722718941184",
  "text" : "Watch live: @POTUS speaks on the situation in Paris \u2192 https:\/\/t.co\/dPiUSKHDlH",
  "id" : 665299722718941184,
  "created_at" : "2015-11-13 22:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/dPiUSKHDlH",
      "expanded_url" : "http:\/\/go.wh.gov\/K4vtpL",
      "display_url" : "go.wh.gov\/K4vtpL"
    } ]
  },
  "geo" : { },
  "id_str" : "665298451731615744",
  "text" : "At 5:45pm ET, @POTUS will deliver a statement on the situation in Paris. Watch here \u2192 https:\/\/t.co\/dPiUSKHDlH",
  "id" : 665298451731615744,
  "created_at" : "2015-11-13 22:41:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/24K8z5xMsq",
      "expanded_url" : "http:\/\/goo.gl\/szispM",
      "display_url" : "goo.gl\/szispM"
    } ]
  },
  "geo" : { },
  "id_str" : "665277504576479232",
  "text" : "RT @NancyPelosi: We must do more to unleash the full potential of women &amp; girls of color in America! \u2192 https:\/\/t.co\/24K8z5xMsq #WomenSuccee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomenSucceed",
        "indices" : [ 114, 127 ]
      }, {
        "text" : "YesSheCan",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/24K8z5xMsq",
        "expanded_url" : "http:\/\/goo.gl\/szispM",
        "display_url" : "goo.gl\/szispM"
      } ]
    },
    "geo" : { },
    "id_str" : "665264005456535553",
    "text" : "We must do more to unleash the full potential of women &amp; girls of color in America! \u2192 https:\/\/t.co\/24K8z5xMsq #WomenSucceed #YesSheCan",
    "id" : 665264005456535553,
    "created_at" : "2015-11-13 20:24:33 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 665277504576479232,
  "created_at" : "2015-11-13 21:18:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/665259902894481408\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/hrGXZ883a3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTt6O2bWEAAcXXc.jpg",
      "id_str" : "665259765514244096",
      "id" : 665259765514244096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTt6O2bWEAAcXXc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hrGXZ883a3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665259902894481408",
  "text" : ".@POTUS on the passing of White House staffer Rick McKay: https:\/\/t.co\/hrGXZ883a3",
  "id" : 665259902894481408,
  "created_at" : "2015-11-13 20:08:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/665254882635620352\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fJvswfcmI7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTt1rl6WwAAk3ej.jpg",
      "id_str" : "665254761738977280",
      "id" : 665254761738977280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTt1rl6WwAAk3ej.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fJvswfcmI7"
    } ],
    "hashtags" : [ {
      "text" : "CloseTheGap",
      "indices" : [ 30, 42 ]
    }, {
      "text" : "YesSheCan",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/7dJl9Ki5xj",
      "expanded_url" : "http:\/\/go.wh.gov\/NAuB16",
      "display_url" : "go.wh.gov\/NAuB16"
    } ]
  },
  "geo" : { },
  "id_str" : "665254882635620352",
  "text" : "RT if you agree: It's time to #CloseTheGap so more women have a shot at success. https:\/\/t.co\/7dJl9Ki5xj #YesSheCan https:\/\/t.co\/fJvswfcmI7",
  "id" : 665254882635620352,
  "created_at" : "2015-11-13 19:48:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665221700162863104",
  "text" : "RT @vj44: Good news.  All health insurance plans must provide breastfeeding support and equipment for the duration at no cost. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/wsafwx0ZHX",
        "expanded_url" : "https:\/\/twitter.com\/inkedmommy252\/status\/665218187705741312",
        "display_url" : "twitter.com\/inkedmommy252\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "665220425128001536",
    "text" : "Good news.  All health insurance plans must provide breastfeeding support and equipment for the duration at no cost. https:\/\/t.co\/wsafwx0ZHX",
    "id" : 665220425128001536,
    "created_at" : "2015-11-13 17:31:23 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 665221700162863104,
  "created_at" : "2015-11-13 17:36:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665218196710932481",
  "text" : "RT @vj44: For the first time in U.S. history, 90 percent of Americans are covered.  17.6 million have signed up!!  #getcovered https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 105, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/T7e8891GaJ",
        "expanded_url" : "https:\/\/twitter.com\/SusanDanzig219\/status\/665045132211679232",
        "display_url" : "twitter.com\/SusanDanzig219\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "665217563014643714",
    "text" : "For the first time in U.S. history, 90 percent of Americans are covered.  17.6 million have signed up!!  #getcovered https:\/\/t.co\/T7e8891GaJ",
    "id" : 665217563014643714,
    "created_at" : "2015-11-13 17:20:00 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 665218196710932481,
  "created_at" : "2015-11-13 17:22:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 14, 19 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/665213510226485248\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/oMyhPlelY8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTtQF4eWcAA37iK.jpg",
      "id_str" : "665213431956533248",
      "id" : 665213431956533248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTtQF4eWcAA37iK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oMyhPlelY8"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/0mUOE5nSZx",
      "expanded_url" : "http:\/\/ti.me\/1H0tXZL",
      "display_url" : "ti.me\/1H0tXZL"
    } ]
  },
  "geo" : { },
  "id_str" : "665213510226485248",
  "text" : "Starting now: @VJ44 answers your questions on women's health care. Ask with #GetCovered: https:\/\/t.co\/0mUOE5nSZx https:\/\/t.co\/oMyhPlelY8",
  "id" : 665213510226485248,
  "created_at" : "2015-11-13 17:03:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Johnson",
      "screen_name" : "jackjohnson",
      "indices" : [ 1, 13 ],
      "id_str" : "61898653",
      "id" : 61898653
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/665208907489349632\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Bjbpj9y5ub",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTtL-e4W4AAhUqX.jpg",
      "id_str" : "665208906780696576",
      "id" : 665208906780696576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTtL-e4W4AAhUqX.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Bjbpj9y5ub"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ta10vTp2km",
      "expanded_url" : "https:\/\/youtu.be\/i5B3q3Wz2uM",
      "display_url" : "youtu.be\/i5B3q3Wz2uM"
    } ]
  },
  "geo" : { },
  "id_str" : "665208907489349632",
  "text" : ".@JackJohnson is helping every 4th grader in Hawaii explore our public lands! https:\/\/t.co\/ta10vTp2km #FindYourPark https:\/\/t.co\/Bjbpj9y5ub",
  "id" : 665208907489349632,
  "created_at" : "2015-11-13 16:45:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665171567438000128",
  "text" : "RT @kerrywashington: Check this out! \"Advancing Equity for Women &amp; Girls of Color:A Research Agenda for the Next Decade\" GO TO https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YesSheCan",
        "indices" : [ 134, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/RQ6tR2uxlg",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "665165027901440000",
    "text" : "Check this out! \"Advancing Equity for Women &amp; Girls of Color:A Research Agenda for the Next Decade\" GO TO https:\/\/t.co\/RQ6tR2uxlg #YesSheCan",
    "id" : 665165027901440000,
    "created_at" : "2015-11-13 13:51:15 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 665171567438000128,
  "created_at" : "2015-11-13 14:17:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 105, 110 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "What To Expect",
      "screen_name" : "WhatToExpect",
      "indices" : [ 112, 125 ],
      "id_str" : "19308735",
      "id" : 19308735
    }, {
      "name" : "MomsRising",
      "screen_name" : "MomsRising",
      "indices" : [ 133, 144 ],
      "id_str" : "15174710",
      "id" : 15174710
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 17, 21 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665162095890210816",
  "text" : "Questions on the #ACA, women's health, &amp; moms?\nAsk by 12pm ET using #GetCovered.\nYou might hear from @VJ44, @WhatToExpect, &amp; @MomsRising.",
  "id" : 665162095890210816,
  "created_at" : "2015-11-13 13:39:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/MYajMLVTNW",
      "expanded_url" : "http:\/\/go.nasa.gov\/20PNLp1",
      "display_url" : "go.nasa.gov\/20PNLp1"
    } ]
  },
  "geo" : { },
  "id_str" : "664966573560619008",
  "text" : "RT @NASA: Major glacier breaks loose from stable position in Greenland. See the impacts of this: https:\/\/t.co\/MYajMLVTNW https:\/\/t.co\/cLvzR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/664950184925863936\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/cLvzRYIPol",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CTpgq01XIAIpNED.png",
        "id_str" : "664950183843799042",
        "id" : 664950183843799042,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CTpgq01XIAIpNED.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/cLvzRYIPol"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/MYajMLVTNW",
        "expanded_url" : "http:\/\/go.nasa.gov\/20PNLp1",
        "display_url" : "go.nasa.gov\/20PNLp1"
      } ]
    },
    "geo" : { },
    "id_str" : "664950184925863936",
    "text" : "Major glacier breaks loose from stable position in Greenland. See the impacts of this: https:\/\/t.co\/MYajMLVTNW https:\/\/t.co\/cLvzRYIPol",
    "id" : 664950184925863936,
    "created_at" : "2015-11-12 23:37:32 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 664966573560619008,
  "created_at" : "2015-11-13 00:42:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eBay",
      "screen_name" : "eBay",
      "indices" : [ 74, 79 ],
      "id_str" : "19709040",
      "id" : 19709040
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/664959058420621312\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/I4Azw0mme8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTpoeidWUAQCX-C.jpg",
      "id_str" : "664958768845836292",
      "id" : 664958768845836292,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTpoeidWUAQCX-C.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 525
      } ],
      "display_url" : "pic.twitter.com\/I4Azw0mme8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/MlVKPFJisL",
      "expanded_url" : "http:\/\/www.ebaymainstreet.com\/POTUS-TPP-Letter",
      "display_url" : "ebaymainstreet.com\/POTUS-TPP-Lett\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664959058420621312",
  "text" : "Learn how the President's trade deal is protecting online businesses like @eBay sellers:  https:\/\/t.co\/MlVKPFJisL https:\/\/t.co\/I4Azw0mme8",
  "id" : 664959058420621312,
  "created_at" : "2015-11-13 00:12:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeorgeStephanopoulos",
      "screen_name" : "GStephanopoulos",
      "indices" : [ 3, 19 ],
      "id_str" : "17074440",
      "id" : 17074440
    }, {
      "name" : "AWN",
      "screen_name" : "WNTonight",
      "indices" : [ 100, 110 ],
      "id_str" : "4861868667",
      "id" : 4861868667
    }, {
      "name" : "Good Morning America",
      "screen_name" : "GMA",
      "indices" : [ 113, 117 ],
      "id_str" : "22650211",
      "id" : 22650211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664952927082176513",
  "text" : "RT @GStephanopoulos: Just sat down w\/ Pres. Obama for an exclusive interview. More to come later on @WNTonight + @GMA tmrw. https:\/\/t.co\/Cf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AWN",
        "screen_name" : "WNTonight",
        "indices" : [ 79, 89 ],
        "id_str" : "4861868667",
        "id" : 4861868667
      }, {
        "name" : "Good Morning America",
        "screen_name" : "GMA",
        "indices" : [ 92, 96 ],
        "id_str" : "22650211",
        "id" : 22650211
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GStephanopoulos\/status\/664923045140799488\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/CflbbH7vvQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTpH-1QUwAA4vG3.jpg",
        "id_str" : "664923039763578880",
        "id" : 664923039763578880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTpH-1QUwAA4vG3.jpg",
        "sizes" : [ {
          "h" : 342,
          "resize" : "fit",
          "w" : 608
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 608
        } ],
        "display_url" : "pic.twitter.com\/CflbbH7vvQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664923045140799488",
    "text" : "Just sat down w\/ Pres. Obama for an exclusive interview. More to come later on @WNTonight + @GMA tmrw. https:\/\/t.co\/CflbbH7vvQ",
    "id" : 664923045140799488,
    "created_at" : "2015-11-12 21:49:42 +0000",
    "user" : {
      "name" : "GeorgeStephanopoulos",
      "screen_name" : "GStephanopoulos",
      "protected" : false,
      "id_str" : "17074440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67746253\/abc_george_081014_blog_normal.jpg",
      "id" : 17074440,
      "verified" : true
    }
  },
  "id" : 664952927082176513,
  "created_at" : "2015-11-12 23:48:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Heidi Murkoff",
      "screen_name" : "HeidiMurkoff",
      "indices" : [ 110, 123 ],
      "id_str" : "179083387",
      "id" : 179083387
    }, {
      "name" : "What To Expect",
      "screen_name" : "WhatToExpect",
      "indices" : [ 125, 138 ],
      "id_str" : "19308735",
      "id" : 19308735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664940125718224896",
  "text" : "RT @vj44: Qs about the ACA &amp; women's health? Ask by 12pm ET on Friday using #GetCovered. I'll answer with @HeidiMurkoff, @WhatToExpect, &amp; @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heidi Murkoff",
        "screen_name" : "HeidiMurkoff",
        "indices" : [ 100, 113 ],
        "id_str" : "179083387",
        "id" : 179083387
      }, {
        "name" : "What To Expect",
        "screen_name" : "WhatToExpect",
        "indices" : [ 115, 128 ],
        "id_str" : "19308735",
        "id" : 19308735
      }, {
        "name" : "MomsRising",
        "screen_name" : "MomsRising",
        "indices" : [ 136, 147 ],
        "id_str" : "15174710",
        "id" : 15174710
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 70, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664916870085091330",
    "text" : "Qs about the ACA &amp; women's health? Ask by 12pm ET on Friday using #GetCovered. I'll answer with @HeidiMurkoff, @WhatToExpect, &amp; @MomsRising",
    "id" : 664916870085091330,
    "created_at" : "2015-11-12 21:25:10 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 664940125718224896,
  "created_at" : "2015-11-12 22:57:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WHO",
      "screen_name" : "WHO",
      "indices" : [ 21, 25 ],
      "id_str" : "14499829",
      "id" : 14499829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664913587631226884",
  "text" : "RT @NSCPress: ICYMI: @WHO declared Sierra Leone free of Ebola transmission. The U.S. led w\/ int\u2019l partners to contain virus there https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WHO",
        "screen_name" : "WHO",
        "indices" : [ 7, 11 ],
        "id_str" : "14499829",
        "id" : 14499829
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/664910972772089856\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DeVxBjubNy",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CTo9AYXWEAARATm.png",
        "id_str" : "664910971740229632",
        "id" : 664910971740229632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CTo9AYXWEAARATm.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DeVxBjubNy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664910972772089856",
    "text" : "ICYMI: @WHO declared Sierra Leone free of Ebola transmission. The U.S. led w\/ int\u2019l partners to contain virus there https:\/\/t.co\/DeVxBjubNy",
    "id" : 664910972772089856,
    "created_at" : "2015-11-12 21:01:44 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 664913587631226884,
  "created_at" : "2015-11-12 21:12:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Jack Johnson",
      "screen_name" : "jackjohnson",
      "indices" : [ 24, 36 ],
      "id_str" : "61898653",
      "id" : 61898653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hawaii",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/wUgRYSEQzZ",
      "expanded_url" : "http:\/\/on.doi.gov\/1SmTmwW",
      "display_url" : "on.doi.gov\/1SmTmwW"
    } ]
  },
  "geo" : { },
  "id_str" : "664906773674000384",
  "text" : "RT @Interior: BIG NEWS: @jackjohnson is helping #Hawaii 4th graders visit America's living classrooms https:\/\/t.co\/wUgRYSEQzZ https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jack Johnson",
        "screen_name" : "jackjohnson",
        "indices" : [ 10, 22 ],
        "id_str" : "61898653",
        "id" : 61898653
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/664906117663866881\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/kdkS9S4D5I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTo4ir-UkAATNkJ.jpg",
        "id_str" : "664906063561396224",
        "id" : 664906063561396224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTo4ir-UkAATNkJ.jpg",
        "sizes" : [ {
          "h" : 583,
          "resize" : "fit",
          "w" : 836
        }, {
          "h" : 583,
          "resize" : "fit",
          "w" : 836
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kdkS9S4D5I"
      } ],
      "hashtags" : [ {
        "text" : "Hawaii",
        "indices" : [ 34, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/wUgRYSEQzZ",
        "expanded_url" : "http:\/\/on.doi.gov\/1SmTmwW",
        "display_url" : "on.doi.gov\/1SmTmwW"
      } ]
    },
    "geo" : { },
    "id_str" : "664906117663866881",
    "text" : "BIG NEWS: @jackjohnson is helping #Hawaii 4th graders visit America's living classrooms https:\/\/t.co\/wUgRYSEQzZ https:\/\/t.co\/kdkS9S4D5I",
    "id" : 664906117663866881,
    "created_at" : "2015-11-12 20:42:26 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 664906773674000384,
  "created_at" : "2015-11-12 20:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Devin Wenig",
      "screen_name" : "devinwenig",
      "indices" : [ 3, 14 ],
      "id_str" : "234859616",
      "id" : 234859616
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "eBay",
      "screen_name" : "eBay",
      "indices" : [ 71, 76 ],
      "id_str" : "19709040",
      "id" : 19709040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664892358132133892",
  "text" : "RT @devinwenig: .@POTUS thank you for your message and for encouraging @eBay merchants to learn about TPP and the benefits of export https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "eBay",
        "screen_name" : "eBay",
        "indices" : [ 55, 60 ],
        "id_str" : "19709040",
        "id" : 19709040
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DW0uWeDy6g",
        "expanded_url" : "http:\/\/www.ebaymainstreet.com\/POTUS-TPP-Letter",
        "display_url" : "ebaymainstreet.com\/POTUS-TPP-Lett\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "664833600244727808",
    "text" : ".@POTUS thank you for your message and for encouraging @eBay merchants to learn about TPP and the benefits of export https:\/\/t.co\/DW0uWeDy6g",
    "id" : 664833600244727808,
    "created_at" : "2015-11-12 15:54:16 +0000",
    "user" : {
      "name" : "Devin Wenig",
      "screen_name" : "devinwenig",
      "protected" : false,
      "id_str" : "234859616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788414017882628098\/O_HV0lY9_normal.jpg",
      "id" : 234859616,
      "verified" : true
    }
  },
  "id" : 664892358132133892,
  "created_at" : "2015-11-12 19:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/1nLNx5d7bf",
      "expanded_url" : "http:\/\/snpy.tv\/1MDH3fR",
      "display_url" : "snpy.tv\/1MDH3fR"
    } ]
  },
  "geo" : { },
  "id_str" : "664867846967730180",
  "text" : "\"We honor heroes like Flo\u2014because on his very worst day, he managed to summon his very best.\" \u2014@POTUS #MedalOfHonor https:\/\/t.co\/1nLNx5d7bf",
  "id" : 664867846967730180,
  "created_at" : "2015-11-12 18:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664854614282473472",
  "text" : "RT @POTUS: This is an American hero: Capt. Groberg put it all on the line for his team. On his worst day, he gave us his best. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/664853410135613440\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/WdWAPswJpE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CToIlGpVEAAYn35.jpg",
        "id_str" : "664853328522711040",
        "id" : 664853328522711040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CToIlGpVEAAYn35.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/WdWAPswJpE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664853410135613440",
    "text" : "This is an American hero: Capt. Groberg put it all on the line for his team. On his worst day, he gave us his best. https:\/\/t.co\/WdWAPswJpE",
    "id" : 664853410135613440,
    "created_at" : "2015-11-12 17:13:00 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 664854614282473472,
  "created_at" : "2015-11-12 17:17:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/oC6Z0wNaIj",
      "expanded_url" : "http:\/\/snpy.tv\/1MDHnLm",
      "display_url" : "snpy.tv\/1MDHnLm"
    } ]
  },
  "geo" : { },
  "id_str" : "664851418080280576",
  "text" : "Watch @POTUS award the #MedalOfHonor to U.S. Army Captain Florent Groberg. https:\/\/t.co\/oC6Z0wNaIj",
  "id" : 664851418080280576,
  "created_at" : "2015-11-12 17:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664841293810520064",
  "text" : "\"That is precisely why we honor heroes like Flo \u2013 because on his very worst day, he managed to summon his very best.\" \u2014@POTUS  #MedalOfHonor",
  "id" : 664841293810520064,
  "created_at" : "2015-11-12 16:24:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664840642107961344",
  "text" : "\u201Clike so many of his fellow veterans of our 9\/11 Generation, Flo continues to serve.\u201D  @POTUS on #MedalOfHonor recipient Capt. Groberg",
  "id" : 664840642107961344,
  "created_at" : "2015-11-12 16:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JTFnmLPUXY",
      "expanded_url" : "http:\/\/go.wh.gov\/S7P197",
      "display_url" : "go.wh.gov\/S7P197"
    } ]
  },
  "geo" : { },
  "id_str" : "664839977277243396",
  "text" : "\u201CToday, we honor Flo because his actions prevented an even greater catastrophe.\u201D  @POTUS awarding the #MedalOfHonor: https:\/\/t.co\/JTFnmLPUXY",
  "id" : 664839977277243396,
  "created_at" : "2015-11-12 16:19:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664838739240296448",
  "text" : "\"Training. Guts. Teamwork. What made Flo a great runner also made him a great soldier. \" \u2014@POTUS on #MedalOfHonor recipient Captain Groberg",
  "id" : 664838739240296448,
  "created_at" : "2015-11-12 16:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664838414513135616",
  "text" : "\"A day after Veterans Day, we honor this American veteran\u201D \u2014@POTUS presenting the #MedalOfHonor to U.S. Army Captain Florent Groberg",
  "id" : 664838414513135616,
  "created_at" : "2015-11-12 16:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 35, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/JTFnmLPUXY",
      "expanded_url" : "http:\/\/go.wh.gov\/S7P197",
      "display_url" : "go.wh.gov\/S7P197"
    } ]
  },
  "geo" : { },
  "id_str" : "664838017727729664",
  "text" : "At 11:15am ET, @POTUS presents the #MedalOfHonor to U.S. Army Captain Florent Groberg. Watch \u2192 https:\/\/t.co\/JTFnmLPUXY",
  "id" : 664838017727729664,
  "created_at" : "2015-11-12 16:11:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664836495857971200\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/53oiVDsdco",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTn5RQdWsAAGCzn.jpg",
      "id_str" : "664836494885040128",
      "id" : 664836494885040128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTn5RQdWsAAGCzn.jpg",
      "sizes" : [ {
        "h" : 541,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 541,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/53oiVDsdco"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 6, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/dzLjqld0q1",
      "expanded_url" : "http:\/\/on.fb.me\/1iU2GMF",
      "display_url" : "on.fb.me\/1iU2GMF"
    } ]
  },
  "geo" : { },
  "id_str" : "664836495857971200",
  "text" : "Watch #MedalOfHonor recipient Capt. Groberg share his thoughts ahead of today's ceremony: https:\/\/t.co\/dzLjqld0q1 https:\/\/t.co\/53oiVDsdco",
  "id" : 664836495857971200,
  "created_at" : "2015-11-12 16:05:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 28, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/KrMuuqIbgD",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/feec97ba-aa6e-4586-a99a-cfea8d5f2352",
      "display_url" : "amp.twimg.com\/v\/feec97ba-aa6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664832720392974336",
  "text" : "What goes into awarding the #MedalOfHonor? Take a look behind the scenes before today's ceremony.\nhttps:\/\/t.co\/KrMuuqIbgD",
  "id" : 664832720392974336,
  "created_at" : "2015-11-12 15:50:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664816641084030977\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/tMOtc1gTPK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTnnNj0UsAEzAP4.jpg",
      "id_str" : "664816640152875009",
      "id" : 664816640152875009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTnnNj0UsAEzAP4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tMOtc1gTPK"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/lBJ3UBTlf4",
      "expanded_url" : "http:\/\/go.wh.gov\/HealthyChallenge",
      "display_url" : "go.wh.gov\/HealthyChallen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664816641084030977",
  "text" : "Want @POTUS to visit your city? Join the Healthy Communities Challenge and #GetCovered \u2192 https:\/\/t.co\/lBJ3UBTlf4 https:\/\/t.co\/tMOtc1gTPK",
  "id" : 664816641084030977,
  "created_at" : "2015-11-12 14:46:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664614869979656192\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/UW4HhUPAoe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTkj2ZVWsAA06OK.jpg",
      "id_str" : "664601837434220544",
      "id" : 664601837434220544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTkj2ZVWsAA06OK.jpg",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1801,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UW4HhUPAoe"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/dzLjqld0q1",
      "expanded_url" : "http:\/\/on.fb.me\/1iU2GMF",
      "display_url" : "on.fb.me\/1iU2GMF"
    } ]
  },
  "geo" : { },
  "id_str" : "664614869979656192",
  "text" : "\"I want to thank every single American who has served our country.\" \u2014@POTUS on #VeteransDay https:\/\/t.co\/dzLjqld0q1 https:\/\/t.co\/UW4HhUPAoe",
  "id" : 664614869979656192,
  "created_at" : "2015-11-12 01:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/664601168350416896\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Y9wbHip6sR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTki-8xWsAAEQZe.jpg",
      "id_str" : "664600884874227712",
      "id" : 664600884874227712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTki-8xWsAAEQZe.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Y9wbHip6sR"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 3, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664601168350416896",
  "text" : "On #VeteransDay, we salute every patriot who has ever proudly worn the uniform of the United States of America. https:\/\/t.co\/Y9wbHip6sR",
  "id" : 664601168350416896,
  "created_at" : "2015-11-12 00:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 112, 124 ]
    }, {
      "text" : "YearInSpace",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664553397710749696",
  "text" : "RT @StationCDRKelly: Salute from 250 mi above to all past and present veterans and families. You are my heroes. #VeteransDay #YearInSpace h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StationCDRKelly\/status\/664477445534314496\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1PfxwR3dTP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTiyty8UkAECGvR.jpg",
        "id_str" : "664477444875784193",
        "id" : 664477444875784193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTiyty8UkAECGvR.jpg",
        "sizes" : [ {
          "h" : 1065,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1PfxwR3dTP"
      } ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 91, 103 ]
      }, {
        "text" : "YearInSpace",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664477445534314496",
    "text" : "Salute from 250 mi above to all past and present veterans and families. You are my heroes. #VeteransDay #YearInSpace https:\/\/t.co\/1PfxwR3dTP",
    "id" : 664477445534314496,
    "created_at" : "2015-11-11 16:19:03 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 664553397710749696,
  "created_at" : "2015-11-11 21:20:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664503639117983744",
  "text" : "RT @VP: Of our many commitments, we have one sacred obligation\u2014to prepare those we send to war and care for them when they come home. #Vete\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664500302272471043",
    "text" : "Of our many commitments, we have one sacred obligation\u2014to prepare those we send to war and care for them when they come home. #VeteransDay",
    "id" : 664500302272471043,
    "created_at" : "2015-11-11 17:49:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 664503639117983744,
  "created_at" : "2015-11-11 18:03:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 83, 95 ]
    }, {
      "text" : "HireAVet",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/qqRueIRBKH",
      "expanded_url" : "http:\/\/snpy.tv\/1Y4BLO9",
      "display_url" : "snpy.tv\/1Y4BLO9"
    } ]
  },
  "geo" : { },
  "id_str" : "664491355184304128",
  "text" : "\"My message today is simple: If you want to get the job done, hire a vet.\" \u2014@POTUS #VeteransDay #HireAVet https:\/\/t.co\/qqRueIRBKH",
  "id" : 664491355184304128,
  "created_at" : "2015-11-11 17:14:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 45, 51 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664486723720638464\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/lYzgQnDYaK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTi68tiWcAAePCH.jpg",
      "id_str" : "664486497215737856",
      "id" : 664486497215737856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTi68tiWcAAePCH.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lYzgQnDYaK"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664486723720638464",
  "text" : "\"On this day, and every day, we thank you.\" \u2014@POTUS to the men and women who serve our country #VeteransDay https:\/\/t.co\/lYzgQnDYaK",
  "id" : 664486723720638464,
  "created_at" : "2015-11-11 16:55:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HireAVet",
      "indices" : [ 62, 71 ]
    }, {
      "text" : "VeteransDay",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664485683143118848",
  "text" : "\"My message today is simple: If you want to get the job done, #HireAVet.\" \u2014@POTUS #VeteransDay",
  "id" : 664485683143118848,
  "created_at" : "2015-11-11 16:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 90, 102 ]
    }, {
      "text" : "HireAVet",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664485105759465473",
  "text" : "\"If you can save a life on the battlefield, you can save a life in an ambulance.\" \u2014@POTUS #VeteransDay #HireAVet",
  "id" : 664485105759465473,
  "created_at" : "2015-11-11 16:49:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664484931578408960\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uw8JzNECgt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTi5f8AWIAIC1IO.jpg",
      "id_str" : "664484903371808770",
      "id" : 664484903371808770,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTi5f8AWIAIC1IO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uw8JzNECgt"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664484931578408960",
  "text" : "\"Today, the veterans' unemployment rate is down to 3.9%\u2014even lower than the national average.\" \u2014@POTUS #VeteransDay https:\/\/t.co\/uw8JzNECgt",
  "id" : 664484931578408960,
  "created_at" : "2015-11-11 16:48:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664484775323807744",
  "text" : "\"We\u2019ve helped more than 1.5 million veterans and their families pursue an education under the Post 9\/11 G.I. Bill.\" \u2014@POTUS #VeteransDay",
  "id" : 664484775323807744,
  "created_at" : "2015-11-11 16:48:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664484695883644928",
  "text" : "RT @WHLive: \"We are going to keep investing in the facilities and the physicians and the staff to make sure our veterans get the care you n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 133, 139 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664484667878322176",
    "text" : "\"We are going to keep investing in the facilities and the physicians and the staff to make sure our veterans get the care you need\" \u2014@POTUS",
    "id" : 664484667878322176,
    "created_at" : "2015-11-11 16:47:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 664484695883644928,
  "created_at" : "2015-11-11 16:47:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 55, 61 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/664484476211171328\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/B8yPz2ZRDu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTi5Gw_WcAA6MLs.jpg",
      "id_str" : "664484470918115328",
      "id" : 664484470918115328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTi5Gw_WcAA6MLs.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/B8yPz2ZRDu"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 62, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664484476211171328",
  "text" : "\"We\u2019re reducing the outrage of veterans homelessness\" \u2014@POTUS #VeteransDay https:\/\/t.co\/B8yPz2ZRDu",
  "id" : 664484476211171328,
  "created_at" : "2015-11-11 16:46:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664484332803756033\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/VSjvMBnSiy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTi49mPXIAA1GFE.jpg",
      "id_str" : "664484313413656576",
      "id" : 664484313413656576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTi49mPXIAA1GFE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VSjvMBnSiy"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664484332803756033",
  "text" : "\"We\u2019ve now slashed the disability claims backlog by nearly 90%.\" \u2014@POTUS #VeteransDay https:\/\/t.co\/VSjvMBnSiy",
  "id" : 664484332803756033,
  "created_at" : "2015-11-11 16:46:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 138, 144 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664484144064282624",
  "text" : "\"Our tributes today will ring hollow if we do not ensure that our veterans receive the care that you have earned &amp; that you deserve\" \u2014@POTUS",
  "id" : 664484144064282624,
  "created_at" : "2015-11-11 16:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664483358643122176",
  "text" : "\"Today, we gather once more to salute every patriot who has ever proudly worn the uniform of the United States\" \u2014@POTUS #VeteransDay",
  "id" : 664483358643122176,
  "created_at" : "2015-11-11 16:42:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664483196369633280",
  "text" : "\"You are part of an unbroken chain of patriots who have served this country with honor through the life of our nation.\" \u2014@POTUS #VeteransDay",
  "id" : 664483196369633280,
  "created_at" : "2015-11-11 16:41:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/dzLjqld0q1",
      "expanded_url" : "http:\/\/on.fb.me\/1iU2GMF",
      "display_url" : "on.fb.me\/1iU2GMF"
    } ]
  },
  "geo" : { },
  "id_str" : "664483121652350976",
  "text" : "\"Captain Florent Groberg tomorrow, it will be my honor to present you with the Medal of Honor\" \u2014@POTUS: https:\/\/t.co\/dzLjqld0q1 #VeteransDay",
  "id" : 664483121652350976,
  "created_at" : "2015-11-11 16:41:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/VSyPCY8rhs",
      "expanded_url" : "http:\/\/go.wh.gov\/PStRgH",
      "display_url" : "go.wh.gov\/PStRgH"
    } ]
  },
  "geo" : { },
  "id_str" : "664482839086280704",
  "text" : "RT @WHLive: Watch live: @POTUS speaks at Arlington National Cemetery \u2192 https:\/\/t.co\/VSyPCY8rhs #VeteransDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 12, 18 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 83, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/VSyPCY8rhs",
        "expanded_url" : "http:\/\/go.wh.gov\/PStRgH",
        "display_url" : "go.wh.gov\/PStRgH"
      } ]
    },
    "geo" : { },
    "id_str" : "664482777404866560",
    "text" : "Watch live: @POTUS speaks at Arlington National Cemetery \u2192 https:\/\/t.co\/VSyPCY8rhs #VeteransDay",
    "id" : 664482777404866560,
    "created_at" : "2015-11-11 16:40:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 664482839086280704,
  "created_at" : "2015-11-11 16:40:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664470112615792640\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/7CksBAYthU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTir5PxXAAAyAOs.jpg",
      "id_str" : "664469945011601408",
      "id" : 664469945011601408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTir5PxXAAAyAOs.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/7CksBAYthU"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 34, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/oDulR2Ymf4",
      "expanded_url" : "http:\/\/go.wh.gov\/PStRgH",
      "display_url" : "go.wh.gov\/PStRgH"
    } ]
  },
  "geo" : { },
  "id_str" : "664470112615792640",
  "text" : "At 11:10am ET, @POTUS speaks at a #VeteransDay ceremony at Arlington National Cemetery \u2192 https:\/\/t.co\/oDulR2Ymf4 https:\/\/t.co\/7CksBAYthU",
  "id" : 664470112615792640,
  "created_at" : "2015-11-11 15:49:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664467485379334144",
  "text" : "RT @POTUS: Today, we honor the incredible men and women who have served our country. Their sacrifice and selflessness is second to none.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664466446102216704",
    "text" : "Today, we honor the incredible men and women who have served our country. Their sacrifice and selflessness is second to none.",
    "id" : 664466446102216704,
    "created_at" : "2015-11-11 15:35:20 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 664467485379334144,
  "created_at" : "2015-11-11 15:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664461848364756993\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/4OBdg2SFvl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTij3HlWIAA3MSH.png",
      "id_str" : "664461112360968192",
      "id" : 664461112360968192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTij3HlWIAA3MSH.png",
      "sizes" : [ {
        "h" : 501,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 492
      } ],
      "display_url" : "pic.twitter.com\/4OBdg2SFvl"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/dzLjqld0q1",
      "expanded_url" : "http:\/\/on.fb.me\/1iU2GMF",
      "display_url" : "on.fb.me\/1iU2GMF"
    } ]
  },
  "geo" : { },
  "id_str" : "664461848364756993",
  "text" : "\"These heroes teach us about the best of America.\" \u2014@POTUS: https:\/\/t.co\/dzLjqld0q1 #VeteransDay https:\/\/t.co\/4OBdg2SFvl",
  "id" : 664461848364756993,
  "created_at" : "2015-11-11 15:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 58, 70 ]
    }, {
      "text" : "HireAVet",
      "indices" : [ 104, 113 ]
    }, {
      "text" : "VeteransDay",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/ji9UWMGEWd",
      "expanded_url" : "http:\/\/bit.ly\/20Mbcjf",
      "display_url" : "bit.ly\/20Mbcjf"
    } ]
  },
  "geo" : { },
  "id_str" : "664453350562201601",
  "text" : "RT @ENERGY: 6 ways to recruit and retain veterans to your #CleanEnergy company: https:\/\/t.co\/ji9UWMGEWd #HireAVet #VeteransDay https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ENERGY\/status\/664433941147987968\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/1lIxncA0Oq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTiLJBwUwAASxon.jpg",
        "id_str" : "664433932243353600",
        "id" : 664433932243353600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTiLJBwUwAASxon.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1lIxncA0Oq"
      } ],
      "hashtags" : [ {
        "text" : "CleanEnergy",
        "indices" : [ 46, 58 ]
      }, {
        "text" : "HireAVet",
        "indices" : [ 92, 101 ]
      }, {
        "text" : "VeteransDay",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/ji9UWMGEWd",
        "expanded_url" : "http:\/\/bit.ly\/20Mbcjf",
        "display_url" : "bit.ly\/20Mbcjf"
      } ]
    },
    "geo" : { },
    "id_str" : "664433941147987968",
    "text" : "6 ways to recruit and retain veterans to your #CleanEnergy company: https:\/\/t.co\/ji9UWMGEWd #HireAVet #VeteransDay https:\/\/t.co\/1lIxncA0Oq",
    "id" : 664433941147987968,
    "created_at" : "2015-11-11 13:26:10 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 664453350562201601,
  "created_at" : "2015-11-11 14:43:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 40, 45 ],
      "id_str" : "19103481",
      "id" : 19103481
    }, {
      "name" : "Lyft",
      "screen_name" : "lyft",
      "indices" : [ 52, 57 ],
      "id_str" : "569569550",
      "id" : 569569550
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664236284123217920\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/BdM0aezS4A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTfXC28WsAAm7mH.jpg",
      "id_str" : "664235914168807424",
      "id" : 664235914168807424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTfXC28WsAAm7mH.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BdM0aezS4A"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/K4KhRAsVQn",
      "expanded_url" : "http:\/\/go.wh.gov\/Veterans",
      "display_url" : "go.wh.gov\/Veterans"
    } ]
  },
  "geo" : { },
  "id_str" : "664236284123217920",
  "text" : "RT to spread the word: On #VeteransDay, @Uber &amp; @Lyft are donating free rides for veterans. https:\/\/t.co\/K4KhRAsVQn https:\/\/t.co\/BdM0aezS4A",
  "id" : 664236284123217920,
  "created_at" : "2015-11-11 00:20:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664194984195788800\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/QEZ7EvyRYM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTex0YYUcAAUqbA.jpg",
      "id_str" : "664194983516205056",
      "id" : 664194983516205056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTex0YYUcAAUqbA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/QEZ7EvyRYM"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/lBJ3UCaWDE",
      "expanded_url" : "http:\/\/go.wh.gov\/HealthyChallenge",
      "display_url" : "go.wh.gov\/HealthyChallen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "664194984195788800",
  "text" : ".@POTUS is challenging communities to #GetCovered. Find out if your city is participating \u2192 https:\/\/t.co\/lBJ3UCaWDE https:\/\/t.co\/QEZ7EvyRYM",
  "id" : 664194984195788800,
  "created_at" : "2015-11-10 21:36:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/664172859795767296\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/s5I0zMVzHH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTedPqdWoAA1ous.jpg",
      "id_str" : "664172362481442816",
      "id" : 664172362481442816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTedPqdWoAA1ous.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/s5I0zMVzHH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/pdUdkO6UIu",
      "expanded_url" : "http:\/\/go.wh.gov\/4ccdGq",
      "display_url" : "go.wh.gov\/4ccdGq"
    } ]
  },
  "geo" : { },
  "id_str" : "664172859795767296",
  "text" : "In which one of @POTUS's favorite authors shares what it's like to be interviewed by him: https:\/\/t.co\/pdUdkO6UIu https:\/\/t.co\/s5I0zMVzHH",
  "id" : 664172859795767296,
  "created_at" : "2015-11-10 20:08:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Marines",
      "screen_name" : "USMC",
      "indices" : [ 30, 35 ],
      "id_str" : "10126672",
      "id" : 10126672
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/664152838868705280\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/X8bKGO2Bjs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTeLbidUwAAeDek.jpg",
      "id_str" : "664152775282966528",
      "id" : 664152775282966528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTeLbidUwAAeDek.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/X8bKGO2Bjs"
    } ],
    "hashtags" : [ {
      "text" : "SemperFi",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664155298366558208",
  "text" : "RT @VP: Happy 240th birthday, @USMC. Thank you to all those who protect our nation, and our freedom #SemperFi https:\/\/t.co\/X8bKGO2Bjs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Marines",
        "screen_name" : "USMC",
        "indices" : [ 22, 27 ],
        "id_str" : "10126672",
        "id" : 10126672
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/664152838868705280\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/X8bKGO2Bjs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTeLbidUwAAeDek.jpg",
        "id_str" : "664152775282966528",
        "id" : 664152775282966528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTeLbidUwAAeDek.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/X8bKGO2Bjs"
      } ],
      "hashtags" : [ {
        "text" : "SemperFi",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664152838868705280",
    "text" : "Happy 240th birthday, @USMC. Thank you to all those who protect our nation, and our freedom #SemperFi https:\/\/t.co\/X8bKGO2Bjs",
    "id" : 664152838868705280,
    "created_at" : "2015-11-10 18:49:10 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 664155298366558208,
  "created_at" : "2015-11-10 18:58:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 116, 126 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664149045007421440",
  "text" : "RT @FactsOnClimate: \"Climate change is a threat to the security of the United States &amp;...countries everywhere\" \u2014@JohnKerry #ActOnClimate ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 96, 106 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 107, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/ZxVUULY3jZ",
        "expanded_url" : "http:\/\/snpy.tv\/1kn7bRz",
        "display_url" : "snpy.tv\/1kn7bRz"
      } ]
    },
    "geo" : { },
    "id_str" : "664134965320224768",
    "text" : "\"Climate change is a threat to the security of the United States &amp;...countries everywhere\" \u2014@JohnKerry #ActOnClimate https:\/\/t.co\/ZxVUULY3jZ",
    "id" : 664134965320224768,
    "created_at" : "2015-11-10 17:38:09 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 664149045007421440,
  "created_at" : "2015-11-10 18:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FightFor15",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664136034465087488",
  "text" : "RT @LaborSec: I'm proud to stand w\/ #FightFor15, who are causing 'good trouble' to build a nation where people have voice at work. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/664131685890572290\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ePqj169O2U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTd4P5CWIAA0oyK.jpg",
        "id_str" : "664131684464467968",
        "id" : 664131684464467968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTd4P5CWIAA0oyK.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ePqj169O2U"
      } ],
      "hashtags" : [ {
        "text" : "FightFor15",
        "indices" : [ 22, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "664131685890572290",
    "text" : "I'm proud to stand w\/ #FightFor15, who are causing 'good trouble' to build a nation where people have voice at work. https:\/\/t.co\/ePqj169O2U",
    "id" : 664131685890572290,
    "created_at" : "2015-11-10 17:25:07 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 664136034465087488,
  "created_at" : "2015-11-10 17:42:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 40, 45 ],
      "id_str" : "19103481",
      "id" : 19103481
    }, {
      "name" : "Lyft",
      "screen_name" : "lyft",
      "indices" : [ 50, 55 ],
      "id_str" : "569569550",
      "id" : 569569550
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 110, 124 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 27, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664109201317343232",
  "text" : "RT @FLOTUS: Big news! This #VeteransDay @Uber and @Lyft are donating free rides for veterans. Learn more from @JoiningForces: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Uber",
        "screen_name" : "Uber",
        "indices" : [ 28, 33 ],
        "id_str" : "19103481",
        "id" : 19103481
      }, {
        "name" : "Lyft",
        "screen_name" : "lyft",
        "indices" : [ 38, 43 ],
        "id_str" : "569569550",
        "id" : 569569550
      }, {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 98, 112 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 15, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/7kK74BvyM3",
        "expanded_url" : "http:\/\/go.wh.gov\/Veterans",
        "display_url" : "go.wh.gov\/Veterans"
      } ]
    },
    "geo" : { },
    "id_str" : "664099660751986688",
    "text" : "Big news! This #VeteransDay @Uber and @Lyft are donating free rides for veterans. Learn more from @JoiningForces: https:\/\/t.co\/7kK74BvyM3",
    "id" : 664099660751986688,
    "created_at" : "2015-11-10 15:17:52 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 664109201317343232,
  "created_at" : "2015-11-10 15:55:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Financial Times",
      "screen_name" : "FT",
      "indices" : [ 3, 6 ],
      "id_str" : "18949452",
      "id" : 18949452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/I8Syp9n97g",
      "expanded_url" : "http:\/\/on.ft.com\/1lga7jh",
      "display_url" : "on.ft.com\/1lga7jh"
    } ]
  },
  "geo" : { },
  "id_str" : "664100537420218368",
  "text" : "RT @FT: White House enlists Shakira on early education: 'Just like my hips, the numbers don\u2019t lie' https:\/\/t.co\/I8Syp9n97g https:\/\/t.co\/ryx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FT\/status\/663775584724623360\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ryxsIRqFvl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTY0YHnUwAEuDa5.jpg",
        "id_str" : "663775584049217537",
        "id" : 663775584049217537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTY0YHnUwAEuDa5.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 594
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 594
        } ],
        "display_url" : "pic.twitter.com\/ryxsIRqFvl"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/I8Syp9n97g",
        "expanded_url" : "http:\/\/on.ft.com\/1lga7jh",
        "display_url" : "on.ft.com\/1lga7jh"
      } ]
    },
    "geo" : { },
    "id_str" : "663775584724623360",
    "text" : "White House enlists Shakira on early education: 'Just like my hips, the numbers don\u2019t lie' https:\/\/t.co\/I8Syp9n97g https:\/\/t.co\/ryxsIRqFvl",
    "id" : 663775584724623360,
    "created_at" : "2015-11-09 17:50:06 +0000",
    "user" : {
      "name" : "Financial Times",
      "screen_name" : "FT",
      "protected" : false,
      "id_str" : "18949452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466972537704824832\/eflEColL_normal.png",
      "id" : 18949452,
      "verified" : true
    }
  },
  "id" : 664100537420218368,
  "created_at" : "2015-11-10 15:21:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Out Magazine",
      "screen_name" : "outmagazine",
      "indices" : [ 3, 15 ],
      "id_str" : "21713274",
      "id" : 21713274
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/outmagazine\/status\/664069708208054273\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/89UZytobYP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTc_4NoUYAIbV10.jpg",
      "id_str" : "664069705024430082",
      "id" : 664069705024430082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTc_4NoUYAIbV10.jpg",
      "sizes" : [ {
        "h" : 3263,
        "resize" : "fit",
        "w" : 2408
      }, {
        "h" : 1388,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 461,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/89UZytobYP"
    } ],
    "hashtags" : [ {
      "text" : "BarackObama",
      "indices" : [ 27, 39 ]
    }, {
      "text" : "Out100",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/h9GBgXcoOZ",
      "expanded_url" : "http:\/\/bit.ly\/1GUPDX9",
      "display_url" : "bit.ly\/1GUPDX9"
    } ]
  },
  "geo" : { },
  "id_str" : "664082414310973440",
  "text" : "RT @outmagazine: President #BarackObama is our Ally of the Year and cover of the #Out100: https:\/\/t.co\/h9GBgXcoOZ https:\/\/t.co\/89UZytobYP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/outmagazine\/status\/664069708208054273\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/89UZytobYP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTc_4NoUYAIbV10.jpg",
        "id_str" : "664069705024430082",
        "id" : 664069705024430082,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTc_4NoUYAIbV10.jpg",
        "sizes" : [ {
          "h" : 3263,
          "resize" : "fit",
          "w" : 2408
        }, {
          "h" : 1388,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 813,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/89UZytobYP"
      } ],
      "hashtags" : [ {
        "text" : "BarackObama",
        "indices" : [ 10, 22 ]
      }, {
        "text" : "Out100",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/h9GBgXcoOZ",
        "expanded_url" : "http:\/\/bit.ly\/1GUPDX9",
        "display_url" : "bit.ly\/1GUPDX9"
      } ]
    },
    "geo" : { },
    "id_str" : "664069708208054273",
    "text" : "President #BarackObama is our Ally of the Year and cover of the #Out100: https:\/\/t.co\/h9GBgXcoOZ https:\/\/t.co\/89UZytobYP",
    "id" : 664069708208054273,
    "created_at" : "2015-11-10 13:18:50 +0000",
    "user" : {
      "name" : "Out Magazine",
      "screen_name" : "outmagazine",
      "protected" : false,
      "id_str" : "21713274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789488522566574083\/KurDla8e_normal.jpg",
      "id" : 21713274,
      "verified" : true
    }
  },
  "id" : 664082414310973440,
  "created_at" : "2015-11-10 14:09:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "PM of Israel",
      "screen_name" : "IsraeliPM",
      "indices" : [ 21, 31 ],
      "id_str" : "141084952",
      "id" : 141084952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/HMYN8dPHLa",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/9eb2e21f-a6f0-4840-85b4-098042939f68",
      "display_url" : "amp.twimg.com\/v\/9eb2e21f-a6f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663877237486186497",
  "text" : "Watch @POTUS welcome @IsraeliPM to the Oval Office.\nhttps:\/\/t.co\/HMYN8dPHLa",
  "id" : 663877237486186497,
  "created_at" : "2015-11-10 00:34:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/663868774366380032\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/JkejtYJUwS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTZqI7jWEAAfn9B.jpg",
      "id_str" : "663834696741163008",
      "id" : 663834696741163008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTZqI7jWEAAfn9B.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JkejtYJUwS"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "MadeInAmerica",
      "indices" : [ 16, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/DxG2mXEygp",
      "expanded_url" : "http:\/\/go.wh.gov\/TPPText",
      "display_url" : "go.wh.gov\/TPPText"
    } ]
  },
  "geo" : { },
  "id_str" : "663868774366380032",
  "text" : "#TPP will boost #MadeInAmerica exports abroad while supporting higher-paying jobs at home \u2192 https:\/\/t.co\/DxG2mXEygp https:\/\/t.co\/JkejtYJUwS",
  "id" : 663868774366380032,
  "created_at" : "2015-11-10 00:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "indices" : [ 13, 23 ],
      "id_str" : "1707321486",
      "id" : 1707321486
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/663857383899164673\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mzF7plRt6q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTZv4fyWIAAujv2.jpg",
      "id_str" : "663841011479748608",
      "id" : 663841011479748608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTZv4fyWIAAujv2.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mzF7plRt6q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/DxG2mXEygp",
      "expanded_url" : "http:\/\/go.wh.gov\/TPPText",
      "display_url" : "go.wh.gov\/TPPText"
    } ]
  },
  "geo" : { },
  "id_str" : "663857383899164673",
  "text" : "Take it from @Madeleine: The TPP ensures that America will keep writing the rules on trade. https:\/\/t.co\/DxG2mXEygp https:\/\/t.co\/mzF7plRt6q",
  "id" : 663857383899164673,
  "created_at" : "2015-11-09 23:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/663835658549530624\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Y84neWSOMY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTZrA3gUcAAILHS.jpg",
      "id_str" : "663835657727406080",
      "id" : 663835657727406080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTZrA3gUcAAILHS.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Y84neWSOMY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/DxG2mXEygp",
      "expanded_url" : "http:\/\/go.wh.gov\/TPPText",
      "display_url" : "go.wh.gov\/TPPText"
    } ]
  },
  "geo" : { },
  "id_str" : "663835658549530624",
  "text" : "Read the facts on President Obama's trade deal that puts American workers first \u2192 https:\/\/t.co\/DxG2mXEygp https:\/\/t.co\/Y84neWSOMY",
  "id" : 663835658549530624,
  "created_at" : "2015-11-09 21:48:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "indices" : [ 3, 11 ],
      "id_str" : "3274836392",
      "id" : 3274836392
    }, {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "indices" : [ 112, 122 ],
      "id_str" : "1707321486",
      "id" : 1707321486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 67, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663826615848210432",
  "text" : "RT @Diana44: Questions on how America's leading the world with the #TPP? Take it from former Secretary of State @Madeleine: https:\/\/t.co\/4h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Madeleine Albright",
        "screen_name" : "madeleine",
        "indices" : [ 99, 109 ],
        "id_str" : "1707321486",
        "id" : 1707321486
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Diana44\/status\/663826537691545600\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/4hAPLXr4G3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTZigtiWUAEp_iE.jpg",
        "id_str" : "663826309202726913",
        "id" : 663826309202726913,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTZigtiWUAEp_iE.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4hAPLXr4G3"
      } ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 54, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "663826537691545600",
    "text" : "Questions on how America's leading the world with the #TPP? Take it from former Secretary of State @Madeleine: https:\/\/t.co\/4hAPLXr4G3",
    "id" : 663826537691545600,
    "created_at" : "2015-11-09 21:12:34 +0000",
    "user" : {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "protected" : false,
      "id_str" : "3274836392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671831357371191296\/CQ0VNiYR_normal.jpg",
      "id" : 3274836392,
      "verified" : true
    }
  },
  "id" : 663826615848210432,
  "created_at" : "2015-11-09 21:12:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663814769976066048",
  "text" : "RT @POTUS: I just launched my Facebook page with a video on climate change. America will lead on this. The time to act is now. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/WG5y1FbhIA",
        "expanded_url" : "http:\/\/Facebook.com\/POTUS",
        "display_url" : "Facebook.com\/POTUS"
      } ]
    },
    "geo" : { },
    "id_str" : "663813521289953281",
    "text" : "I just launched my Facebook page with a video on climate change. America will lead on this. The time to act is now. https:\/\/t.co\/WG5y1FbhIA",
    "id" : 663813521289953281,
    "created_at" : "2015-11-09 20:20:51 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 663814769976066048,
  "created_at" : "2015-11-09 20:25:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/663774847596699648\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/p2x96Yjf2n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTYzmnzWEAEUyUF.png",
      "id_str" : "663774733696110593",
      "id" : 663774733696110593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTYzmnzWEAEUyUF.png",
      "sizes" : [ {
        "h" : 304,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 537,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 878,
        "resize" : "fit",
        "w" : 981
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 878,
        "resize" : "fit",
        "w" : 981
      } ],
      "display_url" : "pic.twitter.com\/p2x96Yjf2n"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Pq2X1BVaWU",
      "expanded_url" : "http:\/\/Facebook.com\/POTUS",
      "display_url" : "Facebook.com\/POTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "663774847596699648",
  "text" : "Wanna take a walk with @POTUS in his backyard?\nNow you can on his brand new Facebook page \u2192 https:\/\/t.co\/Pq2X1BVaWU https:\/\/t.co\/p2x96Yjf2n",
  "id" : 663774847596699648,
  "created_at" : "2015-11-09 17:47:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/663768351391490049\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/lo5Dc4IeO5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTYtukLW4AQ94Mm.png",
      "id_str" : "663768273092272132",
      "id" : 663768273092272132,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTYtukLW4AQ94Mm.png",
      "sizes" : [ {
        "h" : 347,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 503,
        "resize" : "fit",
        "w" : 493
      } ],
      "display_url" : "pic.twitter.com\/lo5Dc4IeO5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Pq2X1BVaWU",
      "expanded_url" : "http:\/\/Facebook.com\/POTUS",
      "display_url" : "Facebook.com\/POTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "663768351391490049",
  "text" : "BREAKING: @POTUS just launched his Facebook page!\nTake a walk with him in his backyard at https:\/\/t.co\/Pq2X1BVaWU. https:\/\/t.co\/lo5Dc4IeO5",
  "id" : 663768351391490049,
  "created_at" : "2015-11-09 17:21:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/ns6ZQ2SPHf",
      "expanded_url" : "http:\/\/1.usa.gov\/1XZrX81",
      "display_url" : "1.usa.gov\/1XZrX81"
    } ]
  },
  "geo" : { },
  "id_str" : "663750834027683840",
  "text" : "RT @vj44: My hometown Chicago joined the Healthy Communities Challenge! Join in and #GetCovered before Jan 15 \u2192 https:\/\/t.co\/ns6ZQ2SPHf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 74, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/ns6ZQ2SPHf",
        "expanded_url" : "http:\/\/1.usa.gov\/1XZrX81",
        "display_url" : "1.usa.gov\/1XZrX81"
      } ]
    },
    "geo" : { },
    "id_str" : "663744122323402752",
    "text" : "My hometown Chicago joined the Healthy Communities Challenge! Join in and #GetCovered before Jan 15 \u2192 https:\/\/t.co\/ns6ZQ2SPHf",
    "id" : 663744122323402752,
    "created_at" : "2015-11-09 15:45:05 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 663750834027683840,
  "created_at" : "2015-11-09 16:11:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/WBh81qVRKZ",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/1260f1ae-c748-47f9-a866-6be8c30cc88a",
      "display_url" : "amp.twimg.com\/v\/1260f1ae-c74\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663547114757033984",
  "text" : "Go behind the scenes with @POTUS and see who won this Halloween's \"top prize.\" #WestWingWeek\nhttps:\/\/t.co\/WBh81qVRKZ",
  "id" : 663547114757033984,
  "created_at" : "2015-11-09 02:42:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/663513860708499457\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9IM5JtCvkR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTTbGesW4AAcaOY.jpg",
      "id_str" : "663395949495115776",
      "id" : 663395949495115776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTTbGesW4AAcaOY.jpg",
      "sizes" : [ {
        "h" : 556,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 728,
        "resize" : "fit",
        "w" : 786
      }, {
        "h" : 728,
        "resize" : "fit",
        "w" : 786
      } ],
      "display_url" : "pic.twitter.com\/9IM5JtCvkR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663513860708499457",
  "text" : "\"I have a lot to worry about...good healthcare will not be one of those worries.\" \u2014Phil Viso in a letter to @POTUS: https:\/\/t.co\/9IM5JtCvkR",
  "id" : 663513860708499457,
  "created_at" : "2015-11-09 00:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/YlvjBussy0",
      "expanded_url" : "http:\/\/go.wh.gov\/Qhfoj7",
      "display_url" : "go.wh.gov\/Qhfoj7"
    } ]
  },
  "geo" : { },
  "id_str" : "663491251228905472",
  "text" : "\"You can no longer be charged more just for being a woman.\" \u2014@POTUS #ACAWorks #GetCovered https:\/\/t.co\/YlvjBussy0",
  "id" : 663491251228905472,
  "created_at" : "2015-11-08 23:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/YlvjBussy0",
      "expanded_url" : "http:\/\/go.wh.gov\/Qhfoj7",
      "display_url" : "go.wh.gov\/Qhfoj7"
    } ]
  },
  "geo" : { },
  "id_str" : "663461050717593601",
  "text" : "\"If you\u2019ve got a pre-existing condition...you can no longer be charged more or denied coverage\" \u2014@POTUS #ACAWorks https:\/\/t.co\/YlvjBussy0",
  "id" : 663461050717593601,
  "created_at" : "2015-11-08 21:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/YlvjBussy0",
      "expanded_url" : "http:\/\/go.wh.gov\/Qhfoj7",
      "display_url" : "go.wh.gov\/Qhfoj7"
    } ]
  },
  "geo" : { },
  "id_str" : "663430863028260866",
  "text" : "\"I\u2019ll come visit the city that enrolls the highest percentage of folks who aren\u2019t covered\" \u2014@POTUS #GetCovered https:\/\/t.co\/YlvjBussy0",
  "id" : 663430863028260866,
  "created_at" : "2015-11-08 19:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/663415774476828672\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/si6OAdTCmA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTTa86SXIAAbjIX.jpg",
      "id_str" : "663395785103581184",
      "id" : 663395785103581184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTTa86SXIAAbjIX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 728,
        "resize" : "fit",
        "w" : 786
      }, {
        "h" : 728,
        "resize" : "fit",
        "w" : 786
      } ],
      "display_url" : "pic.twitter.com\/si6OAdTCmA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663415774476828672",
  "text" : "\"I'm still sort of in shock about how great the experience of signing up for healthcare was\" \u2014Phil Viso to @POTUS: https:\/\/t.co\/si6OAdTCmA",
  "id" : 663415774476828672,
  "created_at" : "2015-11-08 18:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/GNfbft9Ewv",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YlvjBuK3WA",
      "expanded_url" : "http:\/\/go.wh.gov\/Qhfoj7",
      "display_url" : "go.wh.gov\/Qhfoj7"
    } ]
  },
  "geo" : { },
  "id_str" : "663393755031031810",
  "text" : "\"Most Americans will find an option that costs less than $75 a month\" \u2014@POTUS on https:\/\/t.co\/GNfbft9Ewv #GetCovered https:\/\/t.co\/YlvjBuK3WA",
  "id" : 663393755031031810,
  "created_at" : "2015-11-08 16:32:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YlvjBussy0",
      "expanded_url" : "http:\/\/go.wh.gov\/Qhfoj7",
      "display_url" : "go.wh.gov\/Qhfoj7"
    } ]
  },
  "geo" : { },
  "id_str" : "663118749042475008",
  "text" : "\"You can compare plans and choose the one that\u2019s right for your family\" \u2014@POTUS: https:\/\/t.co\/GNfbftrfo3 #GetCovered https:\/\/t.co\/YlvjBussy0",
  "id" : 663118749042475008,
  "created_at" : "2015-11-07 22:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/663079809929490432\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/4VDcIUlt15",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTO7iAeWEAAScdm.jpg",
      "id_str" : "663079763070816256",
      "id" : 663079763070816256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTO7iAeWEAAScdm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 728,
        "resize" : "fit",
        "w" : 786
      }, {
        "h" : 728,
        "resize" : "fit",
        "w" : 786
      } ],
      "display_url" : "pic.twitter.com\/4VDcIUlt15"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "663079809929490432",
  "text" : "Phil Viso cut out on his own to start a business. Thanks to https:\/\/t.co\/GNfbftrfo3, he was able to #GetCovered. https:\/\/t.co\/4VDcIUlt15",
  "id" : 663079809929490432,
  "created_at" : "2015-11-07 19:45:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/663073203216973824\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uQrBM8z0gJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTN-xWKWwAAvVZy.jpg",
      "id_str" : "663012956381298688",
      "id" : 663012956381298688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTN-xWKWwAAvVZy.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uQrBM8z0gJ"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/1DGR85TwCV",
      "expanded_url" : "http:\/\/go.wh.gov\/AiDgSq",
      "display_url" : "go.wh.gov\/AiDgSq"
    } ]
  },
  "geo" : { },
  "id_str" : "663073203216973824",
  "text" : "\"For the first time, more than 90% of Americans are covered\" \u2014@POTUS: https:\/\/t.co\/1DGR85TwCV #GetCovered #ACAWorks https:\/\/t.co\/uQrBM8z0gJ",
  "id" : 663073203216973824,
  "created_at" : "2015-11-07 19:19:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/663042743111823361\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Km0UICN5y1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTN-mtIWsAAF5zZ.jpg",
      "id_str" : "663012773568360448",
      "id" : 663012773568360448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTN-mtIWsAAF5zZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Km0UICN5y1"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 88, 99 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/1DGR85TwCV",
      "expanded_url" : "http:\/\/go.wh.gov\/AiDgSq",
      "display_url" : "go.wh.gov\/AiDgSq"
    } ]
  },
  "geo" : { },
  "id_str" : "663042743111823361",
  "text" : "\"Since 2010, the uninsured rate has decreased by 45%.\" \u2014@POTUS: https:\/\/t.co\/1DGR85TwCV #GetCovered #ACAWorks https:\/\/t.co\/Km0UICN5y1",
  "id" : 663042743111823361,
  "created_at" : "2015-11-07 17:18:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/YlvjBussy0",
      "expanded_url" : "http:\/\/go.wh.gov\/Qhfoj7",
      "display_url" : "go.wh.gov\/Qhfoj7"
    } ]
  },
  "geo" : { },
  "id_str" : "663011327795855360",
  "text" : "\"As the Affordable Care Act has taken effect, we\u2019ve covered 17.6 million Americans.\" \u2014@POTUS #GetCovered #ACAWorks https:\/\/t.co\/YlvjBussy0",
  "id" : 663011327795855360,
  "created_at" : "2015-11-07 15:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/yyUhBOEhNy",
      "expanded_url" : "http:\/\/snpy.tv\/1MogGKP",
      "display_url" : "snpy.tv\/1MogGKP"
    } ]
  },
  "geo" : { },
  "id_str" : "662779041045352449",
  "text" : "\"We\u2019ve got to come together...to protect the one planet we\u2019ve got while we still can.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/yyUhBOEhNy",
  "id" : 662779041045352449,
  "created_at" : "2015-11-06 23:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/662755758770159616\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/JiibQ7ykJ7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTKUh6OW4AACser.jpg",
      "id_str" : "662755405462953984",
      "id" : 662755405462953984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTKUh6OW4AACser.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JiibQ7ykJ7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662755758770159616",
  "text" : "FACT: Our businesses added 268,000 jobs last month, marking the strongest 3 years of job growth since 2000. https:\/\/t.co\/JiibQ7ykJ7",
  "id" : 662755758770159616,
  "created_at" : "2015-11-06 22:17:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KeystoneXL",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/yyUhBOVTc8",
      "expanded_url" : "http:\/\/snpy.tv\/1MogGKP",
      "display_url" : "snpy.tv\/1MogGKP"
    } ]
  },
  "geo" : { },
  "id_str" : "662702103253663744",
  "text" : "\"Shipping dirtier crude oil into our country would not increase America\u2019s energy security\" \u2014@POTUS #KeystoneXL https:\/\/t.co\/yyUhBOVTc8",
  "id" : 662702103253663744,
  "created_at" : "2015-11-06 18:44:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662687132662804480\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/C61cTcJOx7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJWKnmWcAEoyDK.jpg",
      "id_str" : "662686835605401601",
      "id" : 662686835605401601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJWKnmWcAEoyDK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C61cTcJOx7"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662687132662804480",
  "text" : "RT if you agree with @POTUS:\nIt's time to protect the one planet we've got while we still can. #ActOnClimate https:\/\/t.co\/C61cTcJOx7",
  "id" : 662687132662804480,
  "created_at" : "2015-11-06 17:44:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/yyUhBOVTc8",
      "expanded_url" : "http:\/\/snpy.tv\/1MogGKP",
      "display_url" : "snpy.tv\/1MogGKP"
    } ]
  },
  "geo" : { },
  "id_str" : "662679812717338624",
  "text" : "\"If we want to prevent the worst effects of climate change before it\u2019s too late, the time to act is now.\" \u2014@POTUS https:\/\/t.co\/yyUhBOVTc8",
  "id" : 662679812717338624,
  "created_at" : "2015-11-06 17:15:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662678828448370688\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/KXP3k18WTs",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CTJO38vWoAI8kT2.png",
      "id_str" : "662678818281398274",
      "id" : 662678818281398274,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CTJO38vWoAI8kT2.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KXP3k18WTs"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662678828448370688",
  "text" : "\"We\u2019ve got to come together...to protect the one planet we\u2019ve got while we still can.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/KXP3k18WTs",
  "id" : 662678828448370688,
  "created_at" : "2015-11-06 17:11:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/662677988518076417\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/sCR6iEtxCW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJOERlWsAAmV3w.jpg",
      "id_str" : "662677930523406336",
      "id" : 662677930523406336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJOERlWsAAmV3w.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sCR6iEtxCW"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662677988518076417",
  "text" : "\"America is leading on climate change with new rules on power plants\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/sCR6iEtxCW",
  "id" : 662677988518076417,
  "created_at" : "2015-11-06 17:08:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662677680169578496\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/iAqieP9RUx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJN0rMWwAAZNsj.jpg",
      "id_str" : "662677662519967744",
      "id" : 662677662519967744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJN0rMWwAAZNsj.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      } ],
      "display_url" : "pic.twitter.com\/iAqieP9RUx"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662677680169578496",
  "text" : "\"America has cut our total carbon pollution more than any other country on Earth.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/iAqieP9RUx",
  "id" : 662677680169578496,
  "created_at" : "2015-11-06 17:07:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662677214530551808\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/K6SIc6cE0o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJNZeEWoAAc94_.jpg",
      "id_str" : "662677195140276224",
      "id" : 662677195140276224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJNZeEWoAAc94_.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/K6SIc6cE0o"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662677214530551808",
  "text" : "\"We've...multiplied the power we generate from the sun 20 times over.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/K6SIc6cE0o",
  "id" : 662677214530551808,
  "created_at" : "2015-11-06 17:05:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662676825869545473",
  "text" : "\"We\u2019ve doubled the distance our cars will go on a gallon of gas by 2025.\" \u2014@POTUS #ActOnClimate",
  "id" : 662676825869545473,
  "created_at" : "2015-11-06 17:04:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662676466367397888",
  "text" : "\"Shipping dirtier crude oil into our country would not increase America\u2019s energy security.\" \u2014@POTUS on rejecting the Keystone XL Pipeline",
  "id" : 662676466367397888,
  "created_at" : "2015-11-06 17:02:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662676381218807808",
  "text" : "\"The pipeline would not lower gas prices for American consumers. In fact, gas prices have already been falling steadily\" \u2014@POTUS on Keystone",
  "id" : 662676381218807808,
  "created_at" : "2015-11-06 17:02:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662676311941521408\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/EJ3cgu1rVk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJMkLRWEAAUyic.jpg",
      "id_str" : "662676279561424896",
      "id" : 662676279561424896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJMkLRWEAAUyic.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EJ3cgu1rVk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662676311941521408",
  "text" : "\"This Congress should pass a serious infrastructure plan, and keep those jobs coming.\" \u2014@POTUS https:\/\/t.co\/EJ3cgu1rVk",
  "id" : 662676311941521408,
  "created_at" : "2015-11-06 17:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662676195427905536\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/cCMl61VaHs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTJMeSuWwAEOwsh.jpg",
      "id_str" : "662676178482937857",
      "id" : 662676178482937857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTJMeSuWwAEOwsh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cCMl61VaHs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662676195427905536",
  "text" : "\"Our businesses created 268,000 new jobs last month...the unemployment rate fell to 5%.\" \u2014@POTUS https:\/\/t.co\/cCMl61VaHs",
  "id" : 662676195427905536,
  "created_at" : "2015-11-06 17:01:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662676098145193984",
  "text" : "\"A bipartisan infrastructure plan...could create more than 30 times as many jobs\/year as the pipeline\" \u2014@POTUS on the Keystone XL Pipeline",
  "id" : 662676098145193984,
  "created_at" : "2015-11-06 17:01:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662675907342163973",
  "text" : "\"The pipeline would not make a meaningful long-term contribution to our economy.\" \u2014@POTUS on rejecting the Keystone XL Pipeline",
  "id" : 662675907342163973,
  "created_at" : "2015-11-06 17:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 5, 15 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662675629914107905",
  "text" : "\"The @StateDept has decided that the Keystone XL Pipeline would not serve the national interest of the United States.\" \u2014@POTUS #ActOnClimate",
  "id" : 662675629914107905,
  "created_at" : "2015-11-06 16:59:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/WjWzi5Yii5",
      "expanded_url" : "http:\/\/go.wh.gov\/X9SSL3",
      "display_url" : "go.wh.gov\/X9SSL3"
    } ]
  },
  "geo" : { },
  "id_str" : "662675483889410048",
  "text" : "Watch live: @POTUS delivers a statement from the White House \u2192 https:\/\/t.co\/WjWzi5Yii5",
  "id" : 662675483889410048,
  "created_at" : "2015-11-06 16:58:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/WjWzi5Yii5",
      "expanded_url" : "http:\/\/go.wh.gov\/X9SSL3",
      "display_url" : "go.wh.gov\/X9SSL3"
    } ]
  },
  "geo" : { },
  "id_str" : "662659023943172096",
  "text" : "At 11:45am ET, @POTUS will deliver a statement from the Roosevelt Room. Watch here \u2192 https:\/\/t.co\/WjWzi5Yii5",
  "id" : 662659023943172096,
  "created_at" : "2015-11-06 15:53:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/662656992650108929\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/j86XsD9kAW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTI6yS2WIAAtp64.jpg",
      "id_str" : "662656730904535040",
      "id" : 662656730904535040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTI6yS2WIAAtp64.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/j86XsD9kAW"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/qrRJ0goLeo",
      "expanded_url" : "http:\/\/go.wh.gov\/OctJobs",
      "display_url" : "go.wh.gov\/OctJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "662656992650108929",
  "text" : "What the longest streak of private-sector job growth on record looks like \u2192 https:\/\/t.co\/qrRJ0goLeo #JobsReport https:\/\/t.co\/j86XsD9kAW",
  "id" : 662656992650108929,
  "created_at" : "2015-11-06 15:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/662649660490784769\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Q1GwYR8cIZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTI0PfQWIAAM63s.jpg",
      "id_str" : "662649535869624320",
      "id" : 662649535869624320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTI0PfQWIAAM63s.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q1GwYR8cIZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/qrRJ0goLeo",
      "expanded_url" : "http:\/\/go.wh.gov\/OctJobs",
      "display_url" : "go.wh.gov\/OctJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "662649660490784769",
  "text" : "Good news: The unemployment rate is at its lowest level since April 2008 \u2192 https:\/\/t.co\/qrRJ0goLeo https:\/\/t.co\/Q1GwYR8cIZ",
  "id" : 662649660490784769,
  "created_at" : "2015-11-06 15:16:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662643478975946752\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/hZcqOQnRVV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTIuemPWwAE943p.jpg",
      "id_str" : "662643198372790273",
      "id" : 662643198372790273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTIuemPWwAE943p.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hZcqOQnRVV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/qrRJ0goLeo",
      "expanded_url" : "http:\/\/go.wh.gov\/OctJobs",
      "display_url" : "go.wh.gov\/OctJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "662643478975946752",
  "text" : "268,000 new private-sector jobs in Oct \u2713\nLowest unemployment rate in more than 7 years \u2713\nhttps:\/\/t.co\/qrRJ0goLeo https:\/\/t.co\/hZcqOQnRVV",
  "id" : 662643478975946752,
  "created_at" : "2015-11-06 14:51:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662642247138152448",
  "text" : "RT @CEAChair: Economy added 271K jobs in October; 8M over past 3 years, fastest pace since \u201800. UR at lowest pt since April \u201908. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/662639678231703552\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/IrdCQ63wDA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTIrRpHVAAALyNQ.png",
        "id_str" : "662639677271244800",
        "id" : 662639677271244800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTIrRpHVAAALyNQ.png",
        "sizes" : [ {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 824,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 743,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/IrdCQ63wDA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662639678231703552",
    "text" : "Economy added 271K jobs in October; 8M over past 3 years, fastest pace since \u201800. UR at lowest pt since April \u201908. https:\/\/t.co\/IrdCQ63wDA",
    "id" : 662639678231703552,
    "created_at" : "2015-11-06 14:36:25 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 662642247138152448,
  "created_at" : "2015-11-06 14:46:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GenIAsksObama",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/C6G92yj0OI",
      "expanded_url" : "http:\/\/snpy.tv\/1kdM18A",
      "display_url" : "snpy.tv\/1kdM18A"
    } ]
  },
  "geo" : { },
  "id_str" : "662443917888118784",
  "text" : "Worth watching: @POTUS sits down for a conversation with Native youth. #GenIAsksObama https:\/\/t.co\/C6G92yj0OI",
  "id" : 662443917888118784,
  "created_at" : "2015-11-06 01:38:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CollegeHumor",
      "screen_name" : "CollegeHumor",
      "indices" : [ 3, 16 ],
      "id_str" : "16825289",
      "id" : 16825289
    }, {
      "name" : "It's On Us",
      "screen_name" : "ItsOnUs",
      "indices" : [ 93, 101 ],
      "id_str" : "2840712124",
      "id" : 2840712124
    }, {
      "name" : "jake johnson",
      "screen_name" : "MrJakeJohnson",
      "indices" : [ 120, 134 ],
      "id_str" : "333574953",
      "id" : 333574953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/LzYWSdAf6t",
      "expanded_url" : "http:\/\/ow.ly\/UiQrv",
      "display_url" : "ow.ly\/UiQrv"
    } ]
  },
  "geo" : { },
  "id_str" : "662407066099806209",
  "text" : "RT @CollegeHumor: What If Bears Killed 1 In 5 People? https:\/\/t.co\/LzYWSdAf6t We partnered w\/@ItsOnUs in a vid starring @MrJakeJohnson http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "It's On Us",
        "screen_name" : "ItsOnUs",
        "indices" : [ 75, 83 ],
        "id_str" : "2840712124",
        "id" : 2840712124
      }, {
        "name" : "jake johnson",
        "screen_name" : "MrJakeJohnson",
        "indices" : [ 102, 116 ],
        "id_str" : "333574953",
        "id" : 333574953
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CollegeHumor\/status\/662376470577324032\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/37xK2avjxE",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CTE747lUAAIMaxk.png",
        "id_str" : "662376469453078530",
        "id" : 662376469453078530,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CTE747lUAAIMaxk.png",
        "sizes" : [ {
          "h" : 199,
          "resize" : "fit",
          "w" : 374
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 374
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 374
        } ],
        "display_url" : "pic.twitter.com\/37xK2avjxE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/LzYWSdAf6t",
        "expanded_url" : "http:\/\/ow.ly\/UiQrv",
        "display_url" : "ow.ly\/UiQrv"
      } ]
    },
    "geo" : { },
    "id_str" : "662376470577324032",
    "text" : "What If Bears Killed 1 In 5 People? https:\/\/t.co\/LzYWSdAf6t We partnered w\/@ItsOnUs in a vid starring @MrJakeJohnson https:\/\/t.co\/37xK2avjxE",
    "id" : 662376470577324032,
    "created_at" : "2015-11-05 21:10:31 +0000",
    "user" : {
      "name" : "CollegeHumor",
      "screen_name" : "CollegeHumor",
      "protected" : false,
      "id_str" : "16825289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423212466315603968\/rg7S67U3_normal.png",
      "id" : 16825289,
      "verified" : true
    }
  },
  "id" : 662407066099806209,
  "created_at" : "2015-11-05 23:12:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662390708939034624",
  "text" : "\u201CIt's not a weakness, it's a strength for you to seek out help when you are suffering from severe depression\u201D \u2014@POTUS on suicide prevention",
  "id" : 662390708939034624,
  "created_at" : "2015-11-05 22:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662387663664766976",
  "text" : "\u201CEducation is not just books.\nEducation is physical fitness.\nAnd the arts.\nAnd dance.\u201D \u2014@POTUS on the importance of a well-rounded education",
  "id" : 662387663664766976,
  "created_at" : "2015-11-05 21:55:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662384874087649280",
  "text" : "\"It\u2019s not acceptable that anybody doesn\u2019t have running water in this country.\" \u2014@POTUS on the issues facing some #TribalNations",
  "id" : 662384874087649280,
  "created_at" : "2015-11-05 21:43:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662382542742532096\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/lnaZR0BD4m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTFBZE-WEAAGy_G.jpg",
      "id_str" : "662382519287943168",
      "id" : 662382519287943168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTFBZE-WEAAGy_G.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lnaZR0BD4m"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/V24SnjIwmW",
      "expanded_url" : "http:\/\/go.wh.gov\/RJvTTL",
      "display_url" : "go.wh.gov\/RJvTTL"
    } ]
  },
  "geo" : { },
  "id_str" : "662382542742532096",
  "text" : "\"Education is really the key to a middle-class life\" \u2014@POTUS: https:\/\/t.co\/V24SnjIwmW https:\/\/t.co\/lnaZR0BD4m",
  "id" : 662382542742532096,
  "created_at" : "2015-11-05 21:34:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adidas",
      "screen_name" : "adidas",
      "indices" : [ 3, 10 ],
      "id_str" : "300114634",
      "id" : 300114634
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 64, 75 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662380729352003584",
  "text" : "RT @adidas: Sports can change lives. We\u2019re honored to visit the @WhiteHouse Tribal Nations Conference today to support high school mascot n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 52, 63 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662253052238409728",
    "text" : "Sports can change lives. We\u2019re honored to visit the @WhiteHouse Tribal Nations Conference today to support high school mascot name changes.",
    "id" : 662253052238409728,
    "created_at" : "2015-11-05 13:00:06 +0000",
    "user" : {
      "name" : "adidas",
      "screen_name" : "adidas",
      "protected" : false,
      "id_str" : "300114634",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794518362650972160\/qHMnRWqI_normal.jpg",
      "id" : 300114634,
      "verified" : true
    }
  },
  "id" : 662380729352003584,
  "created_at" : "2015-11-05 21:27:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662379425552596992",
  "text" : "\"Yet, for all our young people have endured, you give me incredible hope. In you, I see so much promise.\" \u2014@POTUS to Native youth",
  "id" : 662379425552596992,
  "created_at" : "2015-11-05 21:22:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662378305753120768",
  "text" : "\"Many of the young people I\u2019ve met have gone through more than anybody should have to experience in a lifetime\" \u2014@POTUS on Native youth",
  "id" : 662378305753120768,
  "created_at" : "2015-11-05 21:17:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662377944233459712\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/VZt6QVt9mb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTE9OVgXAAAAZvm.jpg",
      "id_str" : "662377936700506112",
      "id" : 662377936700506112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTE9OVgXAAAAZvm.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/VZt6QVt9mb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662377944233459712",
  "text" : "\"In Alaska, I met with native communities &amp; witnessed how climate change threatens their livelihoods\" \u2014@POTUS https:\/\/t.co\/VZt6QVt9mb",
  "id" : 662377944233459712,
  "created_at" : "2015-11-05 21:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/m3IPeXNZyI",
      "expanded_url" : "http:\/\/go.wh.gov\/TribalNations",
      "display_url" : "go.wh.gov\/TribalNations"
    } ]
  },
  "geo" : { },
  "id_str" : "662377130588770304",
  "text" : "\"The success of our tribal communities is tied up with the success of America as a whole\" \u2014@POTUS: https:\/\/t.co\/m3IPeXNZyI #TribalNations",
  "id" : 662377130588770304,
  "created_at" : "2015-11-05 21:13:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/m3IPeXNZyI",
      "expanded_url" : "http:\/\/go.wh.gov\/TribalNations",
      "display_url" : "go.wh.gov\/TribalNations"
    } ]
  },
  "geo" : { },
  "id_str" : "662376560289271809",
  "text" : "Watch live: @POTUS speaks at the #TribalNations conference before his conversation with Native youth \u2192 https:\/\/t.co\/m3IPeXNZyI",
  "id" : 662376560289271809,
  "created_at" : "2015-11-05 21:10:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GenIAsksObama",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/m3IPeXNZyI",
      "expanded_url" : "http:\/\/go.wh.gov\/TribalNations",
      "display_url" : "go.wh.gov\/TribalNations"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/2SFUbMZtmM",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/7dde6146-2cac-4cb2-ad13-e4757df2a854",
      "display_url" : "amp.twimg.com\/v\/7dde6146-2ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "662365554351697920",
  "text" : "Tune in for a conversation between @POTUS and Native youth at 4:15pm ET \u2192 https:\/\/t.co\/m3IPeXNZyI #GenIAsksObama https:\/\/t.co\/2SFUbMZtmM",
  "id" : 662365554351697920,
  "created_at" : "2015-11-05 20:27:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParksforAll",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662355084089663488",
  "text" : "RT @SecretaryJewell: Congress needs to reauth &amp; provide dedicated funding for LWCF. Future gens deserve nothing less.SJ #ParksforAll https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/662354154761900032\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/TF5ULYrr7v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTEnl9WWcAAT8wB.jpg",
        "id_str" : "662354153277124608",
        "id" : 662354153277124608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTEnl9WWcAAT8wB.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2764,
          "resize" : "fit",
          "w" : 4147
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/TF5ULYrr7v"
      } ],
      "hashtags" : [ {
        "text" : "ParksforAll",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662354154761900032",
    "text" : "Congress needs to reauth &amp; provide dedicated funding for LWCF. Future gens deserve nothing less.SJ #ParksforAll https:\/\/t.co\/TF5ULYrr7v",
    "id" : 662354154761900032,
    "created_at" : "2015-11-05 19:41:51 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 662355084089663488,
  "created_at" : "2015-11-05 19:45:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 102, 116 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoodMorning",
      "indices" : [ 84, 96 ]
    }, {
      "text" : "YearInSpace",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662345163273056256",
  "text" : "RT @StationCDRKelly: For an instant before sunrise, the space station glows orange. #GoodMorning from @Space_Station! #YearInSpace https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 81, 95 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/StationCDRKelly\/status\/662269393515204608\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/FEXx8Rezg3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTDagP0VEAAxhEG.jpg",
        "id_str" : "662269392760147968",
        "id" : 662269392760147968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTDagP0VEAAxhEG.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1065,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/FEXx8Rezg3"
      } ],
      "hashtags" : [ {
        "text" : "GoodMorning",
        "indices" : [ 63, 75 ]
      }, {
        "text" : "YearInSpace",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662269393515204608",
    "text" : "For an instant before sunrise, the space station glows orange. #GoodMorning from @Space_Station! #YearInSpace https:\/\/t.co\/FEXx8Rezg3",
    "id" : 662269393515204608,
    "created_at" : "2015-11-05 14:05:02 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 662345163273056256,
  "created_at" : "2015-11-05 19:06:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662312510595420160\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/hZPegijRgo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTEBYR9WsAE2fx5.jpg",
      "id_str" : "662312136849403905",
      "id" : 662312136849403905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTEBYR9WsAE2fx5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hZPegijRgo"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 4, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/DxG2mXmXoR",
      "expanded_url" : "http:\/\/go.wh.gov\/TPPText",
      "display_url" : "go.wh.gov\/TPPText"
    } ]
  },
  "geo" : { },
  "id_str" : "662312510595420160",
  "text" : "The #TPP will ELIMINATE more than 18,000 taxes that various countries put on U.S. products: https:\/\/t.co\/DxG2mXmXoR https:\/\/t.co\/hZPegijRgo",
  "id" : 662312510595420160,
  "created_at" : "2015-11-05 16:56:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662301555606056960",
  "text" : "RT @JohnKerry: #TPP deepens our partnerships &amp; underscores US commitment to the Asia-Pacific. Read the full text here: https:\/\/t.co\/Rmflr17\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/Rmflr17qr8",
        "expanded_url" : "http:\/\/go.wh.gov\/TPPText",
        "display_url" : "go.wh.gov\/TPPText"
      } ]
    },
    "geo" : { },
    "id_str" : "662281203748364289",
    "text" : "#TPP deepens our partnerships &amp; underscores US commitment to the Asia-Pacific. Read the full text here: https:\/\/t.co\/Rmflr17qr8",
    "id" : 662281203748364289,
    "created_at" : "2015-11-05 14:51:58 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 662301555606056960,
  "created_at" : "2015-11-05 16:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662295584892694529\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/VRtbuiSkLZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTDySIHWEAE2XEC.jpg",
      "id_str" : "662295538453319681",
      "id" : 662295538453319681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTDySIHWEAE2XEC.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VRtbuiSkLZ"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 39, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/DxG2mXmXoR",
      "expanded_url" : "http:\/\/go.wh.gov\/TPPText",
      "display_url" : "go.wh.gov\/TPPText"
    } ]
  },
  "geo" : { },
  "id_str" : "662295584892694529",
  "text" : "More exports = higher-paying jobs.\nThe #TPP helps businesses sell more American products \u2192 https:\/\/t.co\/DxG2mXmXoR https:\/\/t.co\/VRtbuiSkLZ",
  "id" : 662295584892694529,
  "created_at" : "2015-11-05 15:49:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662285357891760128\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/okWPhVAQx9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTDo0SkW4AEMM3g.jpg",
      "id_str" : "662285130258636801",
      "id" : 662285130258636801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTDo0SkW4AEMM3g.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/okWPhVAQx9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/DxG2mXEygp",
      "expanded_url" : "http:\/\/go.wh.gov\/TPPText",
      "display_url" : "go.wh.gov\/TPPText"
    } ]
  },
  "geo" : { },
  "id_str" : "662285357891760128",
  "text" : ".@POTUS's trade deal = the strongest environmental standards of any trade agreement ever \u2192 https:\/\/t.co\/DxG2mXEygp https:\/\/t.co\/okWPhVAQx9",
  "id" : 662285357891760128,
  "created_at" : "2015-11-05 15:08:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/VICALY1BON",
      "expanded_url" : "http:\/\/nyti.ms\/1kvfCKi",
      "display_url" : "nyti.ms\/1kvfCKi"
    } ]
  },
  "geo" : { },
  "id_str" : "662278792107421696",
  "text" : "RT @nytimes: In Pacific Trade Deal, Vietnam Agrees to U.S. Terms on Labor Rights https:\/\/t.co\/VICALY1BON",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/VICALY1BON",
        "expanded_url" : "http:\/\/nyti.ms\/1kvfCKi",
        "display_url" : "nyti.ms\/1kvfCKi"
      } ]
    },
    "geo" : { },
    "id_str" : "662196606805155840",
    "text" : "In Pacific Trade Deal, Vietnam Agrees to U.S. Terms on Labor Rights https:\/\/t.co\/VICALY1BON",
    "id" : 662196606805155840,
    "created_at" : "2015-11-05 09:15:48 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 662278792107421696,
  "created_at" : "2015-11-05 14:42:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662269912157671424\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/vJbkYe4dXM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTDa8vtWwAArX0O.jpg",
      "id_str" : "662269882357170176",
      "id" : 662269882357170176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTDa8vtWwAArX0O.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vJbkYe4dXM"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/DxG2mXmXoR",
      "expanded_url" : "http:\/\/go.wh.gov\/TPPText",
      "display_url" : "go.wh.gov\/TPPText"
    } ]
  },
  "geo" : { },
  "id_str" : "662269912157671424",
  "text" : "President Obama's trade deal is a big win for American workers.\nRead the text \u2192 https:\/\/t.co\/DxG2mXmXoR #TPP https:\/\/t.co\/vJbkYe4dXM",
  "id" : 662269912157671424,
  "created_at" : "2015-11-05 14:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/662236740418199552\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mNvSbrGJP8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CTCwy0BWsAAfYbg.jpg",
      "id_str" : "662223532227735552",
      "id" : 662223532227735552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTCwy0BWsAAfYbg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mNvSbrGJP8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/DxG2mXmXoR",
      "expanded_url" : "http:\/\/go.wh.gov\/TPPText",
      "display_url" : "go.wh.gov\/TPPText"
    } ]
  },
  "geo" : { },
  "id_str" : "662236740418199552",
  "text" : "BREAKING: You can read the text of @POTUS's trade deal.\nSee how it puts U.S. workers first: https:\/\/t.co\/DxG2mXmXoR https:\/\/t.co\/mNvSbrGJP8",
  "id" : 662236740418199552,
  "created_at" : "2015-11-05 11:55:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Seth Meyers",
      "screen_name" : "sethmeyers",
      "indices" : [ 48, 59 ],
      "id_str" : "44039298",
      "id" : 44039298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 74, 95 ]
    }, {
      "text" : "HeadsUpAmerica",
      "indices" : [ 97, 112 ]
    }, {
      "text" : "LNSM",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662091451040428032",
  "text" : "RT @DrBiden: This just in... Dr. Biden talks to @SethMeyers tonight about #FreeCommunityCollege. #HeadsUpAmerica #LNSM https:\/\/t.co\/U7YBaWW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Seth Meyers",
        "screen_name" : "sethmeyers",
        "indices" : [ 35, 46 ],
        "id_str" : "44039298",
        "id" : 44039298
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/662081543750467584\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/U7YBaWWj6U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CTAvpH5UwAAYdNO.jpg",
        "id_str" : "662081528764088320",
        "id" : 662081528764088320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CTAvpH5UwAAYdNO.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/U7YBaWWj6U"
      } ],
      "hashtags" : [ {
        "text" : "FreeCommunityCollege",
        "indices" : [ 61, 82 ]
      }, {
        "text" : "HeadsUpAmerica",
        "indices" : [ 84, 99 ]
      }, {
        "text" : "LNSM",
        "indices" : [ 100, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "662081543750467584",
    "text" : "This just in... Dr. Biden talks to @SethMeyers tonight about #FreeCommunityCollege. #HeadsUpAmerica #LNSM https:\/\/t.co\/U7YBaWWj6U",
    "id" : 662081543750467584,
    "created_at" : "2015-11-05 01:38:35 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 662091451040428032,
  "created_at" : "2015-11-05 02:17:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Warner",
      "screen_name" : "MarkWarner",
      "indices" : [ 3, 14 ],
      "id_str" : "7429102",
      "id" : 7429102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "myRA",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662009117356204033",
  "text" : "RT @MarkWarner: As U.S. workforce continues to change, #myRA is a great tool for Americans working outside the traditional 9-5 job  https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "myRA",
        "indices" : [ 39, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/OXDl8LxQUo",
        "expanded_url" : "https:\/\/twitter.com\/Jonnelle\/status\/661949687545659393",
        "display_url" : "twitter.com\/Jonnelle\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661976218040934401",
    "text" : "As U.S. workforce continues to change, #myRA is a great tool for Americans working outside the traditional 9-5 job  https:\/\/t.co\/OXDl8LxQUo",
    "id" : 661976218040934401,
    "created_at" : "2015-11-04 18:40:03 +0000",
    "user" : {
      "name" : "Mark Warner",
      "screen_name" : "MarkWarner",
      "protected" : false,
      "id_str" : "7429102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789477663178125313\/KB4inkXb_normal.jpg",
      "id" : 7429102,
      "verified" : true
    }
  },
  "id" : 662009117356204033,
  "created_at" : "2015-11-04 20:50:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661993830540013570\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/ejdqUECyGu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS_f0AZWIAAbt63.jpg",
      "id_str" : "661993754799251456",
      "id" : 661993754799251456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS_f0AZWIAAbt63.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ejdqUECyGu"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/5r9E9h6WeU",
      "expanded_url" : "http:\/\/go.wh.gov\/GetCovered",
      "display_url" : "go.wh.gov\/GetCovered"
    } ]
  },
  "geo" : { },
  "id_str" : "661993830540013570",
  "text" : "Join the millions who now have access to affordable health coverage. #GetCovered today \u2192 https:\/\/t.co\/5r9E9h6WeU https:\/\/t.co\/ejdqUECyGu",
  "id" : 661993830540013570,
  "created_at" : "2015-11-04 19:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GenIAsksObama",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/2SFUbMHRYc",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/7dde6146-2cac-4cb2-ad13-e4757df2a854",
      "display_url" : "amp.twimg.com\/v\/7dde6146-2ca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661965105781829632",
  "text" : "Have questions for @POTUS on empowering Native youth? Ask with #GenIAsksObama before tomorrow's conversation.\nhttps:\/\/t.co\/2SFUbMHRYc",
  "id" : 661965105781829632,
  "created_at" : "2015-11-04 17:55:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661935458532925440\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/4e67DLmtfI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS-qui-WcAAZiVm.jpg",
      "id_str" : "661935386885779456",
      "id" : 661935386885779456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS-qui-WcAAZiVm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4e67DLmtfI"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/5r9E9h6WeU",
      "expanded_url" : "http:\/\/go.wh.gov\/GetCovered",
      "display_url" : "go.wh.gov\/GetCovered"
    } ]
  },
  "geo" : { },
  "id_str" : "661935458532925440",
  "text" : "Need health coverage? Find a plan that fits your needs and #GetCovered today \u2192 https:\/\/t.co\/5r9E9h6WeU https:\/\/t.co\/4e67DLmtfI",
  "id" : 661935458532925440,
  "created_at" : "2015-11-04 15:58:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Lenny",
      "screen_name" : "lennyletter",
      "indices" : [ 112, 124 ],
      "id_str" : "3240420332",
      "id" : 3240420332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661910948190425088",
  "text" : "RT @vj44: Women shouldn't have to worry about domestic abusers buying guns through gaps in the law. My piece in @lennyletter: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lenny",
        "screen_name" : "lennyletter",
        "indices" : [ 102, 114 ],
        "id_str" : "3240420332",
        "id" : 3240420332
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/eXosc9iTSl",
        "expanded_url" : "http:\/\/bit.ly\/1QbUKEd",
        "display_url" : "bit.ly\/1QbUKEd"
      } ]
    },
    "geo" : { },
    "id_str" : "661902652326981632",
    "text" : "Women shouldn't have to worry about domestic abusers buying guns through gaps in the law. My piece in @lennyletter: https:\/\/t.co\/eXosc9iTSl",
    "id" : 661902652326981632,
    "created_at" : "2015-11-04 13:47:44 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 661910948190425088,
  "created_at" : "2015-11-04 14:20:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661703348899352576\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/tmIC7iQvag",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS7XhUKWsAA04uN.jpg",
      "id_str" : "661703162617835520",
      "id" : 661703162617835520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS7XhUKWsAA04uN.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1728,
        "resize" : "fit",
        "w" : 2304
      } ],
      "display_url" : "pic.twitter.com\/tmIC7iQvag"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/DSsZ0yZPLy",
      "expanded_url" : "http:\/\/go.wh.gov\/PqSzbk",
      "display_url" : "go.wh.gov\/PqSzbk"
    } ]
  },
  "geo" : { },
  "id_str" : "661703348899352576",
  "text" : "Check out how we're encouraging more private investment to protect our natural resources \u2192 https:\/\/t.co\/DSsZ0yZPLy https:\/\/t.co\/tmIC7iQvag",
  "id" : 661703348899352576,
  "created_at" : "2015-11-04 00:35:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 107, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Sj8v1OBgOu",
      "expanded_url" : "http:\/\/HeadsUpAmerica.us\/Act",
      "display_url" : "HeadsUpAmerica.us\/Act"
    } ]
  },
  "geo" : { },
  "id_str" : "661682033224237056",
  "text" : "RT @DrBiden: The average college graduate has $28,000 in debt. Let's change that \u2192 https:\/\/t.co\/Sj8v1OBgOu #FreeCommunityCollege https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreeCommunityCollege",
        "indices" : [ 94, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/Sj8v1OBgOu",
        "expanded_url" : "http:\/\/HeadsUpAmerica.us\/Act",
        "display_url" : "HeadsUpAmerica.us\/Act"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/biAjseVJeB",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/bba215dd-672b-4d30-95e5-7a61cdd28045",
        "display_url" : "amp.twimg.com\/v\/bba215dd-672\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661666840817631232",
    "text" : "The average college graduate has $28,000 in debt. Let's change that \u2192 https:\/\/t.co\/Sj8v1OBgOu #FreeCommunityCollege https:\/\/t.co\/biAjseVJeB",
    "id" : 661666840817631232,
    "created_at" : "2015-11-03 22:10:42 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 661682033224237056,
  "created_at" : "2015-11-03 23:11:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/pdXq1iIKl8",
      "expanded_url" : "http:\/\/tinyurl.com\/om355o3",
      "display_url" : "tinyurl.com\/om355o3"
    } ]
  },
  "geo" : { },
  "id_str" : "661659026011262976",
  "text" : "RT @vj44: Here's how @POTUS is expanding tech training\/jobs for folks w\/ criminal records w\/ TechHire: https:\/\/t.co\/pdXq1iIKl8 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/pdXq1iIKl8",
        "expanded_url" : "http:\/\/tinyurl.com\/om355o3",
        "display_url" : "tinyurl.com\/om355o3"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/CopFf7mHyT",
        "expanded_url" : "https:\/\/twitter.com\/TeresaYHodge\/status\/661642585480536064",
        "display_url" : "twitter.com\/TeresaYHodge\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661644717323501568",
    "text" : "Here's how @POTUS is expanding tech training\/jobs for folks w\/ criminal records w\/ TechHire: https:\/\/t.co\/pdXq1iIKl8 https:\/\/t.co\/CopFf7mHyT",
    "id" : 661644717323501568,
    "created_at" : "2015-11-03 20:42:48 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 661659026011262976,
  "created_at" : "2015-11-03 21:39:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Senator Ron Johnson",
      "screen_name" : "SenRonJohnson",
      "indices" : [ 17, 31 ],
      "id_str" : "233737858",
      "id" : 233737858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 53, 75 ]
    }, {
      "text" : "BanTheBox",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661658457687220225",
  "text" : "RT @vj44: Thanks @SenRonJohnson for your support for #CriminalJusticeReform and #BanTheBox. @POTUS looks fwd to bill signings. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Ron Johnson",
        "screen_name" : "SenRonJohnson",
        "indices" : [ 7, 21 ],
        "id_str" : "233737858",
        "id" : 233737858
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 82, 88 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 43, 65 ]
      }, {
        "text" : "BanTheBox",
        "indices" : [ 70, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/9o29o4JN6h",
        "expanded_url" : "https:\/\/twitter.com\/SenRonJohnson\/status\/661648026579046400",
        "display_url" : "twitter.com\/SenRonJohnson\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661650190990864384",
    "text" : "Thanks @SenRonJohnson for your support for #CriminalJusticeReform and #BanTheBox. @POTUS looks fwd to bill signings. https:\/\/t.co\/9o29o4JN6h",
    "id" : 661650190990864384,
    "created_at" : "2015-11-03 21:04:33 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 661658457687220225,
  "created_at" : "2015-11-03 21:37:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/661642174912688128\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/u8VnksoUx8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS6f9gpWsAEVj18.jpg",
      "id_str" : "661642074354266113",
      "id" : 661642074354266113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS6f9gpWsAEVj18.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/u8VnksoUx8"
    } ],
    "hashtags" : [ {
      "text" : "criminaljusticereform",
      "indices" : [ 53, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661642414961000448",
  "text" : "RT @vj44: Hi everyone! Ready to kick off our chat on #criminaljusticereform. https:\/\/t.co\/u8VnksoUx8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/661642174912688128\/photo\/1",
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/u8VnksoUx8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS6f9gpWsAEVj18.jpg",
        "id_str" : "661642074354266113",
        "id" : 661642074354266113,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS6f9gpWsAEVj18.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/u8VnksoUx8"
      } ],
      "hashtags" : [ {
        "text" : "criminaljusticereform",
        "indices" : [ 43, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661642174912688128",
    "text" : "Hi everyone! Ready to kick off our chat on #criminaljusticereform. https:\/\/t.co\/u8VnksoUx8",
    "id" : 661642174912688128,
    "created_at" : "2015-11-03 20:32:41 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 661642414961000448,
  "created_at" : "2015-11-03 20:33:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jude Schimmel",
      "screen_name" : "JSchim22",
      "indices" : [ 3, 12 ],
      "id_str" : "517777790",
      "id" : 517777790
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661629812910395392",
  "text" : "RT @JSchim22: Excited to announce that I will join a conversation with @POTUS &amp; Native youth on 11\/5. Share your questions with #GenIAsksOb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 57, 63 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GenIAsksObama",
        "indices" : [ 118, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661614228193697792",
    "text" : "Excited to announce that I will join a conversation with @POTUS &amp; Native youth on 11\/5. Share your questions with #GenIAsksObama &amp; tune in!",
    "id" : 661614228193697792,
    "created_at" : "2015-11-03 18:41:38 +0000",
    "user" : {
      "name" : "Jude Schimmel",
      "screen_name" : "JSchim22",
      "protected" : false,
      "id_str" : "517777790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672291779811536896\/Gop-taR0_normal.jpg",
      "id" : 517777790,
      "verified" : false
    }
  },
  "id" : 661629812910395392,
  "created_at" : "2015-11-03 19:43:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Conan O'Brien",
      "screen_name" : "ConanOBrien",
      "indices" : [ 60, 72 ],
      "id_str" : "115485051",
      "id" : 115485051
    }, {
      "name" : "Jimmy Vivino",
      "screen_name" : "JimmyVMusic",
      "indices" : [ 97, 109 ],
      "id_str" : "2901177544",
      "id" : 2901177544
    }, {
      "name" : "Grace Potter",
      "screen_name" : "gracepotter",
      "indices" : [ 111, 123 ],
      "id_str" : "29859415",
      "id" : 29859415
    }, {
      "name" : "John Mulaney",
      "screen_name" : "mulaney",
      "indices" : [ 131, 139 ],
      "id_str" : "72423061",
      "id" : 72423061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661618909443960832",
  "text" : "RT @FLOTUS: So grateful to our troops. That's why I brought @ConanOBrien to Qatar and he brought @JimmyVMusic, @GracePotter, &amp; @Mulaney. Gr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Conan O'Brien",
        "screen_name" : "ConanOBrien",
        "indices" : [ 48, 60 ],
        "id_str" : "115485051",
        "id" : 115485051
      }, {
        "name" : "Jimmy Vivino",
        "screen_name" : "JimmyVMusic",
        "indices" : [ 85, 97 ],
        "id_str" : "2901177544",
        "id" : 2901177544
      }, {
        "name" : "Grace Potter",
        "screen_name" : "gracepotter",
        "indices" : [ 99, 111 ],
        "id_str" : "29859415",
        "id" : 29859415
      }, {
        "name" : "John Mulaney",
        "screen_name" : "mulaney",
        "indices" : [ 119, 127 ],
        "id_str" : "72423061",
        "id" : 72423061
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661618428671717376",
    "text" : "So grateful to our troops. That's why I brought @ConanOBrien to Qatar and he brought @JimmyVMusic, @GracePotter, &amp; @Mulaney. Great show! -mo",
    "id" : 661618428671717376,
    "created_at" : "2015-11-03 18:58:20 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 661618909443960832,
  "created_at" : "2015-11-03 19:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661612395752632324\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/VlA7S19vLu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS6E9K2W4AA9m7D.jpg",
      "id_str" : "661612381689274368",
      "id" : 661612381689274368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS6E9K2W4AA9m7D.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VlA7S19vLu"
    } ],
    "hashtags" : [ {
      "text" : "GenIAsksObama",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/lj7xTS0Dc3",
      "expanded_url" : "http:\/\/go.wh.gov\/generation-indigenous",
      "display_url" : "go.wh.gov\/generation-ind\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661612395752632324",
  "text" : "On Thursday, @POTUS will sit down Native youth.\nJoin the conversation with #GenIAsksObama: https:\/\/t.co\/lj7xTS0Dc3 https:\/\/t.co\/VlA7S19vLu",
  "id" : 661612395752632324,
  "created_at" : "2015-11-03 18:34:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 59, 64 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661600318027898880\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/xV2PNTRDgv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS55-CbWIAQyC2i.jpg",
      "id_str" : "661600301980459012",
      "id" : 661600301980459012,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS55-CbWIAQyC2i.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/xV2PNTRDgv"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 95, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661600318027898880",
  "text" : "Have questions on fixing our criminal justice system?\nJoin @VJ44 for a 3:30pm ET Q&amp;A using #CriminalJusticeReform. https:\/\/t.co\/xV2PNTRDgv",
  "id" : 661600318027898880,
  "created_at" : "2015-11-03 17:46:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Don Beyer",
      "screen_name" : "RepDonBeyer",
      "indices" : [ 3, 15 ],
      "id_str" : "2962868158",
      "id" : 2962868158
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/RepDonBeyer\/status\/661266117898469376\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/mNkd3Fzxyj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS1KB5wWEAAt0Qd.jpg",
      "id_str" : "661266116837249024",
      "id" : 661266116837249024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS1KB5wWEAAt0Qd.jpg",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2259,
        "resize" : "fit",
        "w" : 3029
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mNkd3Fzxyj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661579452715929600",
  "text" : "RT @RepDonBeyer: Thanks @POTUS ! My door is always open if your spell check ever breaks. https:\/\/t.co\/mNkd3Fzxyj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/RepDonBeyer\/status\/661266117898469376\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/mNkd3Fzxyj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS1KB5wWEAAt0Qd.jpg",
        "id_str" : "661266116837249024",
        "id" : 661266116837249024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS1KB5wWEAAt0Qd.jpg",
        "sizes" : [ {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2259,
          "resize" : "fit",
          "w" : 3029
        }, {
          "h" : 447,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/mNkd3Fzxyj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661266117898469376",
    "text" : "Thanks @POTUS ! My door is always open if your spell check ever breaks. https:\/\/t.co\/mNkd3Fzxyj",
    "id" : 661266117898469376,
    "created_at" : "2015-11-02 19:38:22 +0000",
    "user" : {
      "name" : "Rep. Don Beyer",
      "screen_name" : "RepDonBeyer",
      "protected" : false,
      "id_str" : "2962868158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749245008692162561\/rXDh0UQB_normal.jpg",
      "id" : 2962868158,
      "verified" : true
    }
  },
  "id" : 661579452715929600,
  "created_at" : "2015-11-03 16:23:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 53, 65 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661564291024228352",
  "text" : "RT @GinaEPA: Goldman Sachs investing $150 billion in #CleanEnergy. That\u2019s huge &amp; shows it makes good biz sense to #ActOnClimate. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanEnergy",
        "indices" : [ 40, 52 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/Uhg0fakNKg",
        "expanded_url" : "http:\/\/fortune.com\/2015\/11\/02\/goldman-sachs-clean-energy\/",
        "display_url" : "fortune.com\/2015\/11\/02\/gol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "661564100053364738",
    "text" : "Goldman Sachs investing $150 billion in #CleanEnergy. That\u2019s huge &amp; shows it makes good biz sense to #ActOnClimate. https:\/\/t.co\/Uhg0fakNKg",
    "id" : 661564100053364738,
    "created_at" : "2015-11-03 15:22:27 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 661564291024228352,
  "created_at" : "2015-11-03 15:23:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/6EEv86ZTdE",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/70d45a1a-ba0e-4861-acaa-ffce61b65d76",
      "display_url" : "amp.twimg.com\/v\/70d45a1a-ba0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "661550009926553600",
  "text" : "Go behind the scenes with @POTUS as we take you through the last week at the White House. #WestWingWeek\nhttps:\/\/t.co\/6EEv86ZTdE",
  "id" : 661550009926553600,
  "created_at" : "2015-11-03 14:26:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/vNxSjggTsv",
      "expanded_url" : "http:\/\/theatln.tc\/1MbU7sr",
      "display_url" : "theatln.tc\/1MbU7sr"
    } ]
  },
  "geo" : { },
  "id_str" : "661385146554167296",
  "text" : "RT @FLOTUS: We should never have to raise girls in a world that silences their voices: https:\/\/t.co\/vNxSjggTsv #LetGirlsLearn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 99, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/vNxSjggTsv",
        "expanded_url" : "http:\/\/theatln.tc\/1MbU7sr",
        "display_url" : "theatln.tc\/1MbU7sr"
      } ]
    },
    "geo" : { },
    "id_str" : "661367715299373057",
    "text" : "We should never have to raise girls in a world that silences their voices: https:\/\/t.co\/vNxSjggTsv #LetGirlsLearn",
    "id" : 661367715299373057,
    "created_at" : "2015-11-03 02:22:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 661385146554167296,
  "created_at" : "2015-11-03 03:31:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661377494461849600",
  "text" : "RT @vj44: Today @POTUS visited Newark to discuss re-entry. Join me tomorrow at 3:30pm ET to discuss his trip and your ideas on #CriminalJus\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 117, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661367613323239425",
    "text" : "Today @POTUS visited Newark to discuss re-entry. Join me tomorrow at 3:30pm ET to discuss his trip and your ideas on #CriminalJusticeReform",
    "id" : 661367613323239425,
    "created_at" : "2015-11-03 02:21:41 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 661377494461849600,
  "created_at" : "2015-11-03 03:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661350935847903232\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/RrtnBWwnKw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS2W-kyW4AAcFJL.jpg",
      "id_str" : "661350722064277504",
      "id" : 661350722064277504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS2W-kyW4AAcFJL.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/RrtnBWwnKw"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/akiTT5FqTn",
      "expanded_url" : "http:\/\/go.wh.gov\/fmEST7",
      "display_url" : "go.wh.gov\/fmEST7"
    } ]
  },
  "geo" : { },
  "id_str" : "661350935847903232",
  "text" : "70,000 more Montanans now have access to quality, affordable health coverage \u2192 https:\/\/t.co\/akiTT5FqTn #ACAWorks https:\/\/t.co\/RrtnBWwnKw",
  "id" : 661350935847903232,
  "created_at" : "2015-11-03 01:15:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/PSbtHhg1jt",
      "expanded_url" : "http:\/\/bit.ly\/1RqfeaH",
      "display_url" : "bit.ly\/1RqfeaH"
    } ]
  },
  "geo" : { },
  "id_str" : "661345713880739840",
  "text" : "\u201CInstead of peddling the drugs that destroy lives, he\u2019s saving lives.\u201D\n\nWatch @POTUS tell Dquan's story. https:\/\/t.co\/PSbtHhg1jt",
  "id" : 661345713880739840,
  "created_at" : "2015-11-03 00:54:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 117, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/nhVGzYFX2H",
      "expanded_url" : "http:\/\/go.wh.gov\/vRGfLq",
      "display_url" : "go.wh.gov\/vRGfLq"
    } ]
  },
  "geo" : { },
  "id_str" : "661293499434844160",
  "text" : "\"I\u2019m taking action to 'ban the box' for most competitive jobs at federal agencies.\" \u2014@POTUS: https:\/\/t.co\/nhVGzYFX2H #CriminalJusticeReform",
  "id" : 661293499434844160,
  "created_at" : "2015-11-02 21:27:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/9slXM8YtoE",
      "expanded_url" : "http:\/\/go.wh.gov\/FixTheSystem",
      "display_url" : "go.wh.gov\/FixTheSystem"
    } ]
  },
  "geo" : { },
  "id_str" : "661292451454431232",
  "text" : "\"We need to make sure that Americans who have paid their debt to society can earn their second chance.\" \u2014@POTUS: https:\/\/t.co\/9slXM8YtoE",
  "id" : 661292451454431232,
  "created_at" : "2015-11-02 21:23:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 113, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661292353748115456",
  "text" : "RT @WHLive: \"Around 70 million Americans have some sort of criminal record. That\u2019s almost 1 in 5 of us.\" \u2014@POTUS #CriminalJusticeReform",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 94, 100 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 101, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661292331128221700",
    "text" : "\"Around 70 million Americans have some sort of criminal record. That\u2019s almost 1 in 5 of us.\" \u2014@POTUS #CriminalJusticeReform",
    "id" : 661292331128221700,
    "created_at" : "2015-11-02 21:22:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 661292353748115456,
  "created_at" : "2015-11-02 21:22:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/661292170964520960\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/59DZpdEHsr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS1hpaMWoAABUrY.jpg",
      "id_str" : "661292084326998016",
      "id" : 661292084326998016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS1hpaMWoAABUrY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/59DZpdEHsr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/9slXM8YtoE",
      "expanded_url" : "http:\/\/go.wh.gov\/FixTheSystem",
      "display_url" : "go.wh.gov\/FixTheSystem"
    } ]
  },
  "geo" : { },
  "id_str" : "661292170964520960",
  "text" : "\u201CWe account for 5% of the world\u2019s population.\n25% of its inmates.\u201D \u2014@POTUS: https:\/\/t.co\/9slXM8YtoE https:\/\/t.co\/59DZpdEHsr",
  "id" : 661292170964520960,
  "created_at" : "2015-11-02 21:21:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661291839262228480\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/mwHJf6iPsp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS1hZ09WwAEDcEq.jpg",
      "id_str" : "661291816633942017",
      "id" : 661291816633942017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS1hZ09WwAEDcEq.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mwHJf6iPsp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661291839262228480",
  "text" : "\"Right now, there are 2.2 million Americans behind bars. They\u2019re disproportionately black and Latino.\" \u2014@POTUS https:\/\/t.co\/mwHJf6iPsp",
  "id" : 661291839262228480,
  "created_at" : "2015-11-02 21:20:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661291718055174144\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/CiGlgRb4F4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS1hS2HW4AE7NSD.jpg",
      "id_str" : "661291696685244417",
      "id" : 661291696685244417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS1hS2HW4AE7NSD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CiGlgRb4F4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/9slXM8YtoE",
      "expanded_url" : "http:\/\/go.wh.gov\/FixTheSystem",
      "display_url" : "go.wh.gov\/FixTheSystem"
    } ]
  },
  "geo" : { },
  "id_str" : "661291718055174144",
  "text" : "We have to disrupt the pipeline from underfunded schools to overcrowded jails \u2192 https:\/\/t.co\/9slXM8YtoE https:\/\/t.co\/CiGlgRb4F4",
  "id" : 661291718055174144,
  "created_at" : "2015-11-02 21:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/5jLrI4VlS9",
      "expanded_url" : "http:\/\/go.wh.gov\/HqTFUJ",
      "display_url" : "go.wh.gov\/HqTFUJ"
    } ]
  },
  "geo" : { },
  "id_str" : "661290632904839169",
  "text" : "Watch live: @POTUS speaks in Newark on the re-entry process for formerly-incarcerated Americans \u2192 https:\/\/t.co\/5jLrI4VlS9",
  "id" : 661290632904839169,
  "created_at" : "2015-11-02 21:15:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lester Holt",
      "screen_name" : "LesterHoltNBC",
      "indices" : [ 3, 17 ],
      "id_str" : "25300308",
      "id" : 25300308
    }, {
      "name" : "NBC Nightly News",
      "screen_name" : "NBCNightlyNews",
      "indices" : [ 111, 126 ],
      "id_str" : "8839632",
      "id" : 8839632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661278377295413250",
  "text" : "RT @LesterHoltNBC: Just sat down with Pres. Obama to discuss criminal justice reform. The interview tonight on @NBCNightlyNews https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NBC Nightly News",
        "screen_name" : "NBCNightlyNews",
        "indices" : [ 92, 107 ],
        "id_str" : "8839632",
        "id" : 8839632
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LesterHoltNBC\/status\/661271705764143104\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/pN9ONSzdHG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CS1PHG8WcAAas41.jpg",
        "id_str" : "661271703834750976",
        "id" : 661271703834750976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS1PHG8WcAAas41.jpg",
        "sizes" : [ {
          "h" : 3072,
          "resize" : "fit",
          "w" : 5472
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pN9ONSzdHG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "661271705764143104",
    "text" : "Just sat down with Pres. Obama to discuss criminal justice reform. The interview tonight on @NBCNightlyNews https:\/\/t.co\/pN9ONSzdHG",
    "id" : 661271705764143104,
    "created_at" : "2015-11-02 20:00:35 +0000",
    "user" : {
      "name" : "Lester Holt",
      "screen_name" : "LesterHoltNBC",
      "protected" : false,
      "id_str" : "25300308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785506585862893569\/0ft2MbbM_normal.jpg",
      "id" : 25300308,
      "verified" : true
    }
  },
  "id" : 661278377295413250,
  "created_at" : "2015-11-02 20:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/661265717858144256\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/ybyXN5EF4o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS1JowRWsAAz_Xq.jpg",
      "id_str" : "661265684794617856",
      "id" : 661265684794617856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS1JowRWsAAz_Xq.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ybyXN5EF4o"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 64, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/9slXM8GS04",
      "expanded_url" : "http:\/\/go.wh.gov\/FixTheSystem",
      "display_url" : "go.wh.gov\/FixTheSystem"
    } ]
  },
  "geo" : { },
  "id_str" : "661265717858144256",
  "text" : "We spend $80 billion each year on incarcerations.\nIt's time for #CriminalJusticeReform \u2192 https:\/\/t.co\/9slXM8GS04 https:\/\/t.co\/ybyXN5EF4o",
  "id" : 661265717858144256,
  "created_at" : "2015-11-02 19:36:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/nhVGzYFX2H",
      "expanded_url" : "http:\/\/go.wh.gov\/vRGfLq",
      "display_url" : "go.wh.gov\/vRGfLq"
    } ]
  },
  "geo" : { },
  "id_str" : "661249637685293056",
  "text" : "More than 600,000 people are released from state &amp; federal prisons each year.\nLet's help them earn a second chance \u2192 https:\/\/t.co\/nhVGzYFX2H",
  "id" : 661249637685293056,
  "created_at" : "2015-11-02 18:32:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661238068096180224\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/fosBWbDBY8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS0wDyBW4AAE9iH.jpg",
      "id_str" : "661237561818537984",
      "id" : 661237561818537984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS0wDyBW4AAE9iH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fosBWbDBY8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/B9dxCWuNTY",
      "expanded_url" : "http:\/\/go.wh.gov\/BudgetDeal",
      "display_url" : "go.wh.gov\/BudgetDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "661238068096180224",
  "text" : ".@POTUS just signed a budget agreement that creates jobs and keeps America safe \u2192 https:\/\/t.co\/B9dxCWuNTY https:\/\/t.co\/fosBWbDBY8",
  "id" : 661238068096180224,
  "created_at" : "2015-11-02 17:46:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/661219906625650688\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/DtQWCx30j4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CS0fyTOWIAAZPrb.jpg",
      "id_str" : "661219669307695104",
      "id" : 661219669307695104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CS0fyTOWIAAZPrb.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/DtQWCx30j4"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 92, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661219906625650688",
  "text" : "1980: 500,000 people in American jails.\nToday: 2.2 million.\n\nRT if you agree: It's time for #CriminalJusticeReform. https:\/\/t.co\/DtQWCx30j4",
  "id" : 661219906625650688,
  "created_at" : "2015-11-02 16:34:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 52, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661184490849632257",
  "text" : "RT @FLOTUS: I'm sharing stories from my Middle East #LetGirlsLearn trip to inspire U.S. kids to complete their education: https:\/\/t.co\/N2XB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 40, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/N2XBW1MFPe",
        "expanded_url" : "http:\/\/go.wh.gov\/FLOTUSMidEast",
        "display_url" : "go.wh.gov\/FLOTUSMidEast"
      } ]
    },
    "geo" : { },
    "id_str" : "661174348556955650",
    "text" : "I'm sharing stories from my Middle East #LetGirlsLearn trip to inspire U.S. kids to complete their education: https:\/\/t.co\/N2XBW1MFPe -mo",
    "id" : 661174348556955650,
    "created_at" : "2015-11-02 13:33:43 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 661184490849632257,
  "created_at" : "2015-11-02 14:14:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 54, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/UYigivfKR3",
      "expanded_url" : "http:\/\/go.wh.gov\/tRGTPz",
      "display_url" : "go.wh.gov\/tRGTPz"
    } ]
  },
  "geo" : { },
  "id_str" : "660969739657674753",
  "text" : "\"I\u2019ll keep working with people in both parties to get #CriminalJusticeReform bills to my desk\" \u2014@POTUS https:\/\/t.co\/UYigivfKR3",
  "id" : 660969739657674753,
  "created_at" : "2015-11-02 00:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 92, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/UYigivfKR3",
      "expanded_url" : "http:\/\/go.wh.gov\/tRGTPz",
      "display_url" : "go.wh.gov\/tRGTPz"
    } ]
  },
  "geo" : { },
  "id_str" : "660947084820938752",
  "text" : "\"I believe we can help those who have served their time and earned a second chance\" \u2014@POTUS #CriminalJusticeReform https:\/\/t.co\/UYigivfKR3",
  "id" : 660947084820938752,
  "created_at" : "2015-11-01 22:30:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 94, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/UYigivfKR3",
      "expanded_url" : "http:\/\/go.wh.gov\/tRGTPz",
      "display_url" : "go.wh.gov\/tRGTPz"
    } ]
  },
  "geo" : { },
  "id_str" : "660924362900373504",
  "text" : "\"I believe we can disrupt the pipeline from underfunded schools to overcrowded jails\" \u2014@POTUS #CriminalJusticeReform https:\/\/t.co\/UYigivfKR3",
  "id" : 660924362900373504,
  "created_at" : "2015-11-01 21:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660909315994226688\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/oEUgSZlasf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSwEb7lXIAQoFOj.jpg",
      "id_str" : "660908123213996036",
      "id" : 660908123213996036,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSwEb7lXIAQoFOj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oEUgSZlasf"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/5r9E9gPkQk",
      "expanded_url" : "http:\/\/go.wh.gov\/GetCovered",
      "display_url" : "go.wh.gov\/GetCovered"
    } ]
  },
  "geo" : { },
  "id_str" : "660909315994226688",
  "text" : "Need health coverage? Find a plan that fits your needs and #GetCovered starting today \u2192 https:\/\/t.co\/5r9E9gPkQk https:\/\/t.co\/oEUgSZlasf",
  "id" : 660909315994226688,
  "created_at" : "2015-11-01 20:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SEIU",
      "screen_name" : "SEIU",
      "indices" : [ 3, 8 ],
      "id_str" : "14695985",
      "id" : 14695985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    }, {
      "text" : "StayCovered",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/YZWLXR3P0c",
      "expanded_url" : "http:\/\/www.healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "660905186991480832",
  "text" : "RT @SEIU: Today's the day! Shop for the best healthcare option  at https:\/\/t.co\/YZWLXR3P0c to #GetCovered &amp; #StayCovered https:\/\/t.co\/btW4I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SEIU\/status\/660820593105760256\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/btW4ImCIf0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSu00_nUsAIrAFT.jpg",
        "id_str" : "660820592862474242",
        "id" : 660820592862474242,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSu00_nUsAIrAFT.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/btW4ImCIf0"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 84, 95 ]
      }, {
        "text" : "StayCovered",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/YZWLXR3P0c",
        "expanded_url" : "http:\/\/www.healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "660820593105760256",
    "text" : "Today's the day! Shop for the best healthcare option  at https:\/\/t.co\/YZWLXR3P0c to #GetCovered &amp; #StayCovered https:\/\/t.co\/btW4ImCIf0",
    "id" : 660820593105760256,
    "created_at" : "2015-11-01 14:08:01 +0000",
    "user" : {
      "name" : "SEIU",
      "screen_name" : "SEIU",
      "protected" : false,
      "id_str" : "14695985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796464565018103808\/X-vlr5_v_normal.jpg",
      "id" : 14695985,
      "verified" : true
    }
  },
  "id" : 660905186991480832,
  "created_at" : "2015-11-01 19:44:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/VvaQqwRrlE",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "660887796245204993",
  "text" : "RT @SecBurwell: We\u2019re open for business! RT to help us get the word out to #GetCovered now \u2192 https:\/\/t.co\/VvaQqwRrlE. https:\/\/t.co\/3DjqTBgU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecBurwell\/status\/660843176463241216\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/3DjqTBgU9E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSvJXeIUEAApvIG.jpg",
        "id_str" : "660843175402016768",
        "id" : 660843175402016768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSvJXeIUEAApvIG.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3DjqTBgU9E"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 59, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/VvaQqwRrlE",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "660843176463241216",
    "text" : "We\u2019re open for business! RT to help us get the word out to #GetCovered now \u2192 https:\/\/t.co\/VvaQqwRrlE. https:\/\/t.co\/3DjqTBgU9E",
    "id" : 660843176463241216,
    "created_at" : "2015-11-01 15:37:45 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 660887796245204993,
  "created_at" : "2015-11-01 18:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660881303466876928\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/LY98s4AVL8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSvr6YlWUAAdK4b.jpg",
      "id_str" : "660881158603952128",
      "id" : 660881158603952128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSvr6YlWUAAdK4b.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LY98s4AVL8"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/5r9E9h6WeU",
      "expanded_url" : "http:\/\/go.wh.gov\/GetCovered",
      "display_url" : "go.wh.gov\/GetCovered"
    } ]
  },
  "geo" : { },
  "id_str" : "660881303466876928",
  "text" : "RT so your friends know: You can sign up for health coverage starting TODAY \u2192 https:\/\/t.co\/5r9E9h6WeU #GetCovered https:\/\/t.co\/LY98s4AVL8",
  "id" : 660881303466876928,
  "created_at" : "2015-11-01 18:09:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/PJ7xIL6FjY",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "660867697874354176",
  "text" : "RT @POTUS: Every American deserves quality, affordable health care. If you or a friend needs coverage, go to https:\/\/t.co\/PJ7xIL6FjY and si\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/PJ7xIL6FjY",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "660866496474832896",
    "text" : "Every American deserves quality, affordable health care. If you or a friend needs coverage, go to https:\/\/t.co\/PJ7xIL6FjY and sign up now.",
    "id" : 660866496474832896,
    "created_at" : "2015-11-01 17:10:25 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 660867697874354176,
  "created_at" : "2015-11-01 17:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/GhmdrYjj3i",
      "expanded_url" : "http:\/\/go.cms.gov\/1P4ppUE",
      "display_url" : "go.cms.gov\/1P4ppUE"
    } ]
  },
  "geo" : { },
  "id_str" : "660857181382828034",
  "text" : "RT @HealthCareGov: We're open for business! Explore your health care options now and #GetCovered today. https:\/\/t.co\/GhmdrYjj3i https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HealthCareGov\/status\/660818065995624448\/video\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/zzoKfrwRtL",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/660817924718858240\/pu\/img\/CSCMPNXpyoDiEKkS.jpg",
        "id_str" : "660817924718858240",
        "id" : 660817924718858240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/660817924718858240\/pu\/img\/CSCMPNXpyoDiEKkS.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zzoKfrwRtL"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 66, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/GhmdrYjj3i",
        "expanded_url" : "http:\/\/go.cms.gov\/1P4ppUE",
        "display_url" : "go.cms.gov\/1P4ppUE"
      } ]
    },
    "geo" : { },
    "id_str" : "660818065995624448",
    "text" : "We're open for business! Explore your health care options now and #GetCovered today. https:\/\/t.co\/GhmdrYjj3i https:\/\/t.co\/zzoKfrwRtL",
    "id" : 660818065995624448,
    "created_at" : "2015-11-01 13:57:58 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 660857181382828034,
  "created_at" : "2015-11-01 16:33:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]