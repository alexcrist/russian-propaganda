Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418146099669786624",
  "text" : "RT @vj44: Questions re: your Health Marketplace enrollment? Want to make sure u are covered Jan1? Call your insurer or the 24\/7 hotline 1-8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "418108688285433856",
    "text" : "Questions re: your Health Marketplace enrollment? Want to make sure u are covered Jan1? Call your insurer or the 24\/7 hotline 1-800-318-2596",
    "id" : 418108688285433856,
    "created_at" : "2013-12-31 19:57:34 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 418146099669786624,
  "created_at" : "2013-12-31 22:26:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/418132183078166528\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/uI8QYvvdDf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc2BAUcIQAAlIKL.png",
      "id_str" : "418132182901997568",
      "id" : 418132182901997568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc2BAUcIQAAlIKL.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uI8QYvvdDf"
    } ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/L50nYqomS5",
      "expanded_url" : "http:\/\/at.wh.gov\/sbaVc",
      "display_url" : "at.wh.gov\/sbaVc"
    } ]
  },
  "geo" : { },
  "id_str" : "418132183078166528",
  "text" : "That time Bo tried to make fetch happen \u2192 http:\/\/t.co\/L50nYqomS5 #YearInReview, http:\/\/t.co\/uI8QYvvdDf",
  "id" : 418132183078166528,
  "created_at" : "2013-12-31 21:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/XKrBWGsIgS",
      "expanded_url" : "http:\/\/bit.ly\/1hSEEfY",
      "display_url" : "bit.ly\/1hSEEfY"
    } ]
  },
  "geo" : { },
  "id_str" : "418114165132505088",
  "text" : "RT @petesouza: The Year in Photos: http:\/\/t.co\/XKrBWGsIgS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/XKrBWGsIgS",
        "expanded_url" : "http:\/\/bit.ly\/1hSEEfY",
        "display_url" : "bit.ly\/1hSEEfY"
      } ]
    },
    "geo" : { },
    "id_str" : "418070258683895808",
    "text" : "The Year in Photos: http:\/\/t.co\/XKrBWGsIgS",
    "id" : 418070258683895808,
    "created_at" : "2013-12-31 17:24:51 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 418114165132505088,
  "created_at" : "2013-12-31 20:19:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/csbyg1rB7E",
      "expanded_url" : "http:\/\/go.wh.gov\/mZhhj4",
      "display_url" : "go.wh.gov\/mZhhj4"
    }, {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/O7J4XWwYBs",
      "expanded_url" : "http:\/\/vine.co\/v\/htbdjZAPrAX",
      "display_url" : "vine.co\/v\/htbdjZAPrAX"
    } ]
  },
  "geo" : { },
  "id_str" : "418100457685254144",
  "text" : "#YearInReview: Don't miss our favorite online moments of 2013 here at the White House \u2192 http:\/\/t.co\/csbyg1rB7E, http:\/\/t.co\/O7J4XWwYBs",
  "id" : 418100457685254144,
  "created_at" : "2013-12-31 19:24:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/0pPFX6tyxV",
      "expanded_url" : "http:\/\/go.wh.gov\/TKWDV7",
      "display_url" : "go.wh.gov\/TKWDV7"
    } ]
  },
  "geo" : { },
  "id_str" : "418057732965429250",
  "text" : "Signed up for health coverage that starts tomorrow? Here's what you need to know \u2192 http:\/\/t.co\/0pPFX6tyxV #GetCovered",
  "id" : 418057732965429250,
  "created_at" : "2013-12-31 16:35:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/417769990918787072\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/8VjAk2kKB9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcw3l9ZIIAE-9lN.jpg",
      "id_str" : "417769990713253889",
      "id" : 417769990713253889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcw3l9ZIIAE-9lN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/8VjAk2kKB9"
    } ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/pVCMD0Ttql",
      "expanded_url" : "http:\/\/go.wh.gov\/JMSD9x",
      "display_url" : "go.wh.gov\/JMSD9x"
    } ]
  },
  "geo" : { },
  "id_str" : "417769990918787072",
  "text" : "#YearInReview: We're importing less oil than we're producing\u2014and using less overall \u2192 http:\/\/t.co\/pVCMD0Ttql, http:\/\/t.co\/8VjAk2kKB9",
  "id" : 417769990918787072,
  "created_at" : "2013-12-30 21:31:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/417758517114593280\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DULgRVJI5i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcwtKGcCUAAf851.jpg",
      "id_str" : "417758516988760064",
      "id" : 417758516988760064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcwtKGcCUAAf851.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/DULgRVJI5i"
    } ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/7XJVHTVlZp",
      "expanded_url" : "http:\/\/go.wh.gov\/Wst4cp",
      "display_url" : "go.wh.gov\/Wst4cp"
    } ]
  },
  "geo" : { },
  "id_str" : "417758517114593280",
  "text" : "#YearInReview: We've reduced the deficit by more than half since President Obama took office. http:\/\/t.co\/7XJVHTVlZp http:\/\/t.co\/DULgRVJI5i",
  "id" : 417758517114593280,
  "created_at" : "2013-12-30 20:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 107, 118 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BestPractice",
      "indices" : [ 9, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417716440939376640",
  "text" : "RT @gov: #BestPractice: Use a custom timeline to feature tweets from the year on your website. See how the @WhiteHouse did it: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 98, 109 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BestPractice",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ldZwiVndRL",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/12\/26\/year-review-top-whitehouse-tweets-2013",
        "display_url" : "whitehouse.gov\/blog\/2013\/12\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417692821965914113",
    "text" : "#BestPractice: Use a custom timeline to feature tweets from the year on your website. See how the @WhiteHouse did it: http:\/\/t.co\/ldZwiVndRL",
    "id" : 417692821965914113,
    "created_at" : "2013-12-30 16:25:03 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663898965784395776\/rEWW6euI_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 417716440939376640,
  "created_at" : "2013-12-30 17:58:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Robin Roberts",
      "screen_name" : "RobinRoberts",
      "indices" : [ 13, 26 ],
      "id_str" : "267921808",
      "id" : 267921808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417706188822679553",
  "text" : "RT @FLOTUS: .@RobinRoberts, I am so happy for you and Amber! You continue to make us all proud. -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robin Roberts",
        "screen_name" : "RobinRoberts",
        "indices" : [ 1, 14 ],
        "id_str" : "267921808",
        "id" : 267921808
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "417705824417353728",
    "text" : ".@RobinRoberts, I am so happy for you and Amber! You continue to make us all proud. -mo",
    "id" : 417705824417353728,
    "created_at" : "2013-12-30 17:16:43 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 417706188822679553,
  "created_at" : "2013-12-30 17:18:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 3, 13 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/g0VFfYDwK4",
      "expanded_url" : "http:\/\/www.floridatoday.com\/article\/20131230\/NEWS01\/312300025\/Affordable-Care-Act-brings-wave-newly-insured?nclick_check=1",
      "display_url" : "floridatoday.com\/article\/201312\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "417691238284812288",
  "text" : "RT @Racusen44: Front pages in Florida show what Jan 1 will mean for millions -- peace of mind and health security: http:\/\/t.co\/g0VFfYDwK4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/g0VFfYDwK4",
        "expanded_url" : "http:\/\/www.floridatoday.com\/article\/20131230\/NEWS01\/312300025\/Affordable-Care-Act-brings-wave-newly-insured?nclick_check=1",
        "display_url" : "floridatoday.com\/article\/201312\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417681118867881984",
    "text" : "Front pages in Florida show what Jan 1 will mean for millions -- peace of mind and health security: http:\/\/t.co\/g0VFfYDwK4",
    "id" : 417681118867881984,
    "created_at" : "2013-12-30 15:38:33 +0000",
    "user" : {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "protected" : false,
      "id_str" : "1729062162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411689100\/e84b5f12ff73878aa785c296671e9ef8_normal.png",
      "id" : 1729062162,
      "verified" : true
    }
  },
  "id" : 417691238284812288,
  "created_at" : "2013-12-30 16:18:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417674844181110784",
  "text" : "RT @HHSGov: More than 1.1 million people enrolled in health coverage through the Federal Marketplace from Oct 1 to Dec 24: http:\/\/t.co\/XCi8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/XCi8oQjbPy",
        "expanded_url" : "http:\/\/www.hhs.gov\/healthcare\/facts\/blog\/2013\/12\/enrollment-surged.html",
        "display_url" : "hhs.gov\/healthcare\/fac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "417323713411813377",
    "text" : "More than 1.1 million people enrolled in health coverage through the Federal Marketplace from Oct 1 to Dec 24: http:\/\/t.co\/XCi8oQjbPy",
    "id" : 417323713411813377,
    "created_at" : "2013-12-29 15:58:21 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 417674844181110784,
  "created_at" : "2013-12-30 15:13:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/IAQODgwDPe",
      "expanded_url" : "http:\/\/go.wh.gov\/qSHuri",
      "display_url" : "go.wh.gov\/qSHuri"
    } ]
  },
  "geo" : { },
  "id_str" : "417426635558629377",
  "text" : "Watch, as volunteers from across the country transform the White House into a Yuletide masterpiece \u2192 http:\/\/t.co\/IAQODgwDPe",
  "id" : 417426635558629377,
  "created_at" : "2013-12-29 22:47:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 3, 17 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Zkh2JCKQJv",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/FilmFestival",
      "display_url" : "whitehouse.gov\/FilmFestival"
    } ]
  },
  "geo" : { },
  "id_str" : "417402504213987328",
  "text" : "RT @TheScienceGuy: Got something to say? A story to tell? Go for it: http:\/\/t.co\/Zkh2JCKQJv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/Zkh2JCKQJv",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/FilmFestival",
        "display_url" : "whitehouse.gov\/FilmFestival"
      } ]
    },
    "geo" : { },
    "id_str" : "416680795621691392",
    "text" : "Got something to say? A story to tell? Go for it: http:\/\/t.co\/Zkh2JCKQJv",
    "id" : 416680795621691392,
    "created_at" : "2013-12-27 21:23:37 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 417402504213987328,
  "created_at" : "2013-12-29 21:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/c9eeJSIPK9",
      "expanded_url" : "http:\/\/go.wh.gov\/tCXDTf",
      "display_url" : "go.wh.gov\/tCXDTf"
    } ]
  },
  "geo" : { },
  "id_str" : "417361885961269248",
  "text" : "Take a look back at 2013 through our top tweets of the year \u2192 http:\/\/t.co\/c9eeJSIPK9 #YearInReview",
  "id" : 417361885961269248,
  "created_at" : "2013-12-29 18:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417347630503440384",
  "text" : "RT @Simas44: Words from newly insured on being covered: \"relief\" \"dignity\" \"fabulous\" \"excited.\" Word not mentioned: \"politics.\" http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8VYR7iuI6o",
        "expanded_url" : "http:\/\/wapo.st\/1ejzPdb",
        "display_url" : "wapo.st\/1ejzPdb"
      } ]
    },
    "geo" : { },
    "id_str" : "417305784347672576",
    "text" : "Words from newly insured on being covered: \"relief\" \"dignity\" \"fabulous\" \"excited.\" Word not mentioned: \"politics.\" http:\/\/t.co\/8VYR7iuI6o",
    "id" : 417305784347672576,
    "created_at" : "2013-12-29 14:47:06 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 417347630503440384,
  "created_at" : "2013-12-29 17:33:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/6PHEoOUrPC",
      "expanded_url" : "http:\/\/go.wh.gov\/uGdN1j",
      "display_url" : "go.wh.gov\/uGdN1j"
    } ]
  },
  "geo" : { },
  "id_str" : "417339238703579136",
  "text" : "\"Hello everybody, and happy holidays!\" \u2014President Obama in this week's Weekly Address. Watch \u2192 http:\/\/t.co\/6PHEoOUrPC",
  "id" : 417339238703579136,
  "created_at" : "2013-12-29 17:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/F74vn1kyU1",
      "expanded_url" : "http:\/\/go.wh.gov\/vgUNuY",
      "display_url" : "go.wh.gov\/vgUNuY"
    } ]
  },
  "geo" : { },
  "id_str" : "417316586756657152",
  "text" : "Don't miss the top @WhiteHouse tweets of 2013 \u2192 http:\/\/t.co\/F74vn1kyU1 #YearInReview",
  "id" : 417316586756657152,
  "created_at" : "2013-12-29 15:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/apedisBd4n",
      "expanded_url" : "http:\/\/go.wh.gov\/m7egHy",
      "display_url" : "go.wh.gov\/m7egHy"
    } ]
  },
  "geo" : { },
  "id_str" : "417029691392794624",
  "text" : "President Obama: \"We want all of our troops to know that you\u2019re in our thoughts and prayers this holiday season.\" http:\/\/t.co\/apedisBd4n",
  "id" : 417029691392794624,
  "created_at" : "2013-12-28 20:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/417029633393954816\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/XqPXVlZWu7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcmWPfgCEAANRho.jpg",
      "id_str" : "417029633406537728",
      "id" : 417029633406537728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcmWPfgCEAANRho.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XqPXVlZWu7"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417029633393954816",
  "text" : "Extending unemployment insurance is the right thing to do \u2014 for our families AND for our economy. #RenewUI http:\/\/t.co\/XqPXVlZWu7",
  "id" : 417029633393954816,
  "created_at" : "2013-12-28 20:29:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/417007692411334656\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GLKyIo2UpU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcmCSWfIUAADEX_.jpg",
      "id_str" : "417007692293885952",
      "id" : 417007692293885952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcmCSWfIUAADEX_.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/GLKyIo2UpU"
    } ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "MarriageEquality",
      "indices" : [ 99, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/27U8YB2pMD",
      "expanded_url" : "http:\/\/go.wh.gov\/WptFiB",
      "display_url" : "go.wh.gov\/WptFiB"
    } ]
  },
  "geo" : { },
  "id_str" : "417007692411334656",
  "text" : "#YearInReview: More Americans now have the freedom to marry who they love \u2192 http:\/\/t.co\/27U8YB2pMD #MarriageEquality, http:\/\/t.co\/GLKyIo2UpU",
  "id" : 417007692411334656,
  "created_at" : "2013-12-28 19:02:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/l8jbZSbmAX",
      "expanded_url" : "http:\/\/go.wh.gov\/sgCp3q",
      "display_url" : "go.wh.gov\/sgCp3q"
    } ]
  },
  "geo" : { },
  "id_str" : "416996975490236416",
  "text" : "\"We wish you all a blessed and safe holiday season.\" \u2014President Obama in his Weekly Address. Watch \u2192 http:\/\/t.co\/l8jbZSbmAX",
  "id" : 416996975490236416,
  "created_at" : "2013-12-28 18:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/r59BIpzXQF",
      "expanded_url" : "http:\/\/go.wh.gov\/eefEq5",
      "display_url" : "go.wh.gov\/eefEq5"
    } ]
  },
  "geo" : { },
  "id_str" : "416985637498015744",
  "text" : "We made progress in 2013 to grow our economy &amp; strengthen the middle class\u2014but there's more work to do: http:\/\/t.co\/r59BIpzXQF #YearInReview",
  "id" : 416985637498015744,
  "created_at" : "2013-12-28 17:34:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/bksGkCx6OA",
      "expanded_url" : "http:\/\/go.wh.gov\/QuePjz",
      "display_url" : "go.wh.gov\/QuePjz"
    } ]
  },
  "geo" : { },
  "id_str" : "416645665599397888",
  "text" : "This holiday season, we're giving the gift of GIFs. Here are our favorites from 2013 \u2192 http:\/\/t.co\/bksGkCx6OA",
  "id" : 416645665599397888,
  "created_at" : "2013-12-27 19:04:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ZF0Ozo5Fw8",
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/statuses\/367301180910624768",
      "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
    }, {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/AeJfDmu6f6",
      "expanded_url" : "http:\/\/go.wh.gov\/ei45bm",
      "display_url" : "go.wh.gov\/ei45bm"
    } ]
  },
  "geo" : { },
  "id_str" : "416618475159707650",
  "text" : "Remember when Bo tried to make fetch happen? https:\/\/t.co\/ZF0Ozo5Fw8 All this &amp; more in our Top Tweets #YearInReview: http:\/\/t.co\/AeJfDmu6f6",
  "id" : 416618475159707650,
  "created_at" : "2013-12-27 17:15:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/tIEzvbU0jp",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/2013-in-review",
      "display_url" : "whitehouse.gov\/2013-in-review"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/oRe8CqA61z",
      "expanded_url" : "http:\/\/go.wh.gov\/KDAS7W",
      "display_url" : "go.wh.gov\/KDAS7W"
    } ]
  },
  "geo" : { },
  "id_str" : "416592051296149504",
  "text" : "As part of our #YearInReview series \u2014&gt; http:\/\/t.co\/tIEzvbU0jp Don't miss this list of our top tweets of 2013 \u2014&gt; http:\/\/t.co\/oRe8CqA61z",
  "id" : 416592051296149504,
  "created_at" : "2013-12-27 15:30:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Yd7norjFUr",
      "expanded_url" : "http:\/\/go.wh.gov\/wHfzgq",
      "display_url" : "go.wh.gov\/wHfzgq"
    } ]
  },
  "geo" : { },
  "id_str" : "416380654935236608",
  "text" : "#YearInReview: Our top tweets of 2013 \u2014&gt; http:\/\/t.co\/Yd7norjFUr",
  "id" : 416380654935236608,
  "created_at" : "2013-12-27 01:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/efj75M5wGz",
      "expanded_url" : "http:\/\/go.wh.gov\/KqvBbm",
      "display_url" : "go.wh.gov\/KqvBbm"
    } ]
  },
  "geo" : { },
  "id_str" : "416365555029786625",
  "text" : "\"Michelle and I extend our best wishes to all those celebrating Kwanzaa this holiday season.\" \u2014President Obama: http:\/\/t.co\/efj75M5wGz",
  "id" : 416365555029786625,
  "created_at" : "2013-12-27 00:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/tIEzvbU0jp",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/2013-in-review",
      "display_url" : "whitehouse.gov\/2013-in-review"
    }, {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/NJpEI8TPto",
      "expanded_url" : "http:\/\/go.wh.gov\/xSqKTv",
      "display_url" : "go.wh.gov\/xSqKTv"
    } ]
  },
  "geo" : { },
  "id_str" : "416324031411806210",
  "text" : "Don't miss our 2013 #YearInReview page \u2014&gt; http:\/\/t.co\/tIEzvbU0jp Then check out the Top Tweets edition \u2014&gt; http:\/\/t.co\/NJpEI8TPto",
  "id" : 416324031411806210,
  "created_at" : "2013-12-26 21:45:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHoliday",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/tzpp5EMyQu",
      "expanded_url" : "http:\/\/WH.gov\/Holidays",
      "display_url" : "WH.gov\/Holidays"
    } ]
  },
  "geo" : { },
  "id_str" : "416299794080862208",
  "text" : "RT @FLOTUS: Check out behind-the-scenes videos, photos and crafts from this year's #WHHoliday decor: http:\/\/t.co\/tzpp5EMyQu, http:\/\/t.co\/H3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/416299692905881601\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/H3EEb2EI95",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bcb-XWqCcAABMl0.jpg",
        "id_str" : "416299692750696448",
        "id" : 416299692750696448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bcb-XWqCcAABMl0.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 604
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 604
        } ],
        "display_url" : "pic.twitter.com\/H3EEb2EI95"
      } ],
      "hashtags" : [ {
        "text" : "WHHoliday",
        "indices" : [ 71, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/tzpp5EMyQu",
        "expanded_url" : "http:\/\/WH.gov\/Holidays",
        "display_url" : "WH.gov\/Holidays"
      } ]
    },
    "geo" : { },
    "id_str" : "416299692905881601",
    "text" : "Check out behind-the-scenes videos, photos and crafts from this year's #WHHoliday decor: http:\/\/t.co\/tzpp5EMyQu, http:\/\/t.co\/H3EEb2EI95",
    "id" : 416299692905881601,
    "created_at" : "2013-12-26 20:09:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 416299794080862208,
  "created_at" : "2013-12-26 20:09:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInReview",
      "indices" : [ 5, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/HdVfFyOsFq",
      "expanded_url" : "http:\/\/go.wh.gov\/mdJB7g",
      "display_url" : "go.wh.gov\/mdJB7g"
    } ]
  },
  "geo" : { },
  "id_str" : "416268558008471552",
  "text" : "2013 #YearInReview:\n1. Our economy: \u2191\n2. Our deficits: \u2193\n3. + more than 2 million jobs\nBut there's more work to do: http:\/\/t.co\/HdVfFyOsFq",
  "id" : 416268558008471552,
  "created_at" : "2013-12-26 18:05:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/XGmhgurr6F",
      "expanded_url" : "http:\/\/at.wh.gov\/s3DlF",
      "display_url" : "at.wh.gov\/s3DlF"
    } ]
  },
  "geo" : { },
  "id_str" : "416003206515527680",
  "text" : "\"Merry Christmas, from our family to yours.\" \u2014The First Lady: http:\/\/t.co\/XGmhgurr6F",
  "id" : 416003206515527680,
  "created_at" : "2013-12-26 00:31:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 1, 8 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yNwQZi6iSB",
      "expanded_url" : "http:\/\/at.wh.gov\/s3Dh4",
      "display_url" : "at.wh.gov\/s3Dh4"
    } ]
  },
  "geo" : { },
  "id_str" : "415976632210694144",
  "text" : ".@FLOTUS: \"It\u2019s our turn to step up &amp; show our gratitude for the military families who have given us so much.\" http:\/\/t.co\/yNwQZi6iSB",
  "id" : 415976632210694144,
  "created_at" : "2013-12-25 22:45:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/1YZ4aLWYVp",
      "expanded_url" : "http:\/\/at.wh.gov\/s3DdX",
      "display_url" : "at.wh.gov\/s3DdX"
    } ]
  },
  "geo" : { },
  "id_str" : "415950924008669184",
  "text" : "\"We want all of our troops to know that you\u2019re in our thoughts &amp; prayers this holiday season.\" \u2014President Obama: http:\/\/t.co\/1YZ4aLWYVp",
  "id" : 415950924008669184,
  "created_at" : "2013-12-25 21:03:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/UsGUR7i0TI",
      "expanded_url" : "http:\/\/at.wh.gov\/s3D9Z",
      "display_url" : "at.wh.gov\/s3D9Z"
    } ]
  },
  "geo" : { },
  "id_str" : "415927823636127744",
  "text" : "\"We wish you all a blessed and safe holiday season.\" \u2014President Obama &amp; the First Lady: http:\/\/t.co\/UsGUR7i0TI",
  "id" : 415927823636127744,
  "created_at" : "2013-12-25 19:31:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415911026631389185",
  "text" : "RT @FLOTUS: From our family to yours, Merry Christmas everyone! Have a blessed and safe holiday season. -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "415905014482079745",
    "text" : "From our family to yours, Merry Christmas everyone! Have a blessed and safe holiday season. -mo",
    "id" : 415905014482079745,
    "created_at" : "2013-12-25 18:00:57 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 415911026631389185,
  "created_at" : "2013-12-25 18:24:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/415904127722336256\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/SScJ2oy46L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcWWmcGCMAEL3L9.jpg",
      "id_str" : "415904127722336257",
      "id" : 415904127722336257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcWWmcGCMAEL3L9.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SScJ2oy46L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415904127722336256",
  "text" : "Merry Christmas! http:\/\/t.co\/SScJ2oy46L",
  "id" : 415904127722336256,
  "created_at" : "2013-12-25 17:57:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "NORAD Santa",
      "screen_name" : "NoradSanta",
      "indices" : [ 31, 42 ],
      "id_str" : "16460682",
      "id" : 16460682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/4evQFqNecL",
      "expanded_url" : "http:\/\/noradsanta.org",
      "display_url" : "noradsanta.org"
    } ]
  },
  "geo" : { },
  "id_str" : "415610735268360192",
  "text" : "RT @FLOTUS: The First Lady and @NoradSanta are tracking Santa's sleigh. Good news: He's on schedule! http:\/\/t.co\/4evQFqNecL, http:\/\/t.co\/a3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NORAD Santa",
        "screen_name" : "NoradSanta",
        "indices" : [ 19, 30 ],
        "id_str" : "16460682",
        "id" : 16460682
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/415610710622605312\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/a3DmtABQS0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcSLvTxCMAA5pT9.jpg",
        "id_str" : "415610710500978688",
        "id" : 415610710500978688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcSLvTxCMAA5pT9.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/a3DmtABQS0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/4evQFqNecL",
        "expanded_url" : "http:\/\/noradsanta.org",
        "display_url" : "noradsanta.org"
      } ]
    },
    "geo" : { },
    "id_str" : "415610710622605312",
    "text" : "The First Lady and @NoradSanta are tracking Santa's sleigh. Good news: He's on schedule! http:\/\/t.co\/4evQFqNecL, http:\/\/t.co\/a3DmtABQS0",
    "id" : 415610710622605312,
    "created_at" : "2013-12-24 22:31:29 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 415610735268360192,
  "created_at" : "2013-12-24 22:31:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/415545110126800896\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/dQZy9BqEj8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcRQE1nCIAA2j70.jpg",
      "id_str" : "415545109665423360",
      "id" : 415545109665423360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcRQE1nCIAA2j70.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/dQZy9BqEj8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "415545110126800896",
  "text" : "\"I want to wish everybody a Merry Christmas and a joyful holiday season.\" \u2014President Obama http:\/\/t.co\/dQZy9BqEj8",
  "id" : 415545110126800896,
  "created_at" : "2013-12-24 18:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/JyFvBz9cru",
      "expanded_url" : "http:\/\/go.wh.gov\/pzqYNS",
      "display_url" : "go.wh.gov\/pzqYNS"
    } ]
  },
  "geo" : { },
  "id_str" : "415246430467391488",
  "text" : "Go behind the scenes to see how volunteers transformed the White House for the holidays \u2192 http:\/\/t.co\/JyFvBz9cru #WestWingWeek",
  "id" : 415246430467391488,
  "created_at" : "2013-12-23 22:23:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/wXgAInRrAt",
      "expanded_url" : "http:\/\/hc.gov\/gFPoh9",
      "display_url" : "hc.gov\/gFPoh9"
    } ]
  },
  "geo" : { },
  "id_str" : "415212428389920768",
  "text" : "Sign up today for affordable health coverage for you and your family \u2192 http:\/\/t.co\/wXgAInRrAt #GetCovered",
  "id" : 415212428389920768,
  "created_at" : "2013-12-23 20:08:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/k7l8ufoP9h",
      "expanded_url" : "http:\/\/go.wh.gov\/oZQ9ms",
      "display_url" : "go.wh.gov\/oZQ9ms"
    } ]
  },
  "geo" : { },
  "id_str" : "415199099005054976",
  "text" : "Thanks to the ACA, Nancy no longer has to choose between paying her rent and paying for health coverage \u2192 http:\/\/t.co\/k7l8ufoP9h #GetCovered",
  "id" : 415199099005054976,
  "created_at" : "2013-12-23 19:15:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/wXgAInRrAt",
      "expanded_url" : "http:\/\/hc.gov\/gFPoh9",
      "display_url" : "hc.gov\/gFPoh9"
    } ]
  },
  "geo" : { },
  "id_str" : "415187714107912192",
  "text" : "RT to make sure your friends know they can sign up for affordable health coverage right now \u2192 http:\/\/t.co\/wXgAInRrAt #GetCovered",
  "id" : 415187714107912192,
  "created_at" : "2013-12-23 18:30:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/wXgAInRrAt",
      "expanded_url" : "http:\/\/hc.gov\/gFPoh9",
      "display_url" : "hc.gov\/gFPoh9"
    } ]
  },
  "geo" : { },
  "id_str" : "415161350646534145",
  "text" : "If you need affordable health coverage, here's where you can sign up today to #GetCovered starting January 1st \u2192 http:\/\/t.co\/wXgAInRrAt",
  "id" : 415161350646534145,
  "created_at" : "2013-12-23 16:45:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/2GKB9CvsUX",
      "expanded_url" : "http:\/\/www.healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "415151922610733057",
  "text" : "RT @Sebelius: Please RT to help me get the word out: today is the last day to sign up on http:\/\/t.co\/2GKB9CvsUX if you want coverage that b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/2GKB9CvsUX",
        "expanded_url" : "http:\/\/www.healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "415146262921375746",
    "text" : "Please RT to help me get the word out: today is the last day to sign up on http:\/\/t.co\/2GKB9CvsUX if you want coverage that begins Jan. 1!",
    "id" : 415146262921375746,
    "created_at" : "2013-12-23 15:45:56 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 415151922610733057,
  "created_at" : "2013-12-23 16:08:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/eDZTzrk9h3",
      "expanded_url" : "http:\/\/hc.gov\/5884QF",
      "display_url" : "hc.gov\/5884QF"
    } ]
  },
  "geo" : { },
  "id_str" : "415138112428191744",
  "text" : "Spread the word: Today's the last day to sign up for health coverage that starts January 1st. #GetCovered \u2192 http:\/\/t.co\/eDZTzrk9h3",
  "id" : 415138112428191744,
  "created_at" : "2013-12-23 15:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/414976746786549760\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/4yfU0WJND0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcJLJw6CcAAT1fI.png",
      "id_str" : "414976746790744064",
      "id" : 414976746790744064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcJLJw6CcAAT1fI.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4yfU0WJND0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414976746786549760",
  "text" : "Reflecting in the Oval. http:\/\/t.co\/4yfU0WJND0",
  "id" : 414976746786549760,
  "created_at" : "2013-12-23 04:32:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DM4rjDK90j",
      "expanded_url" : "http:\/\/go.wh.gov\/ubGnEQ",
      "display_url" : "go.wh.gov\/ubGnEQ"
    } ]
  },
  "geo" : { },
  "id_str" : "414902808580595712",
  "text" : "Go behind the scenes with President Obama at the White House in the latest #WestWingWeek \u2192 http:\/\/t.co\/DM4rjDK90j",
  "id" : 414902808580595712,
  "created_at" : "2013-12-22 23:38:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/KdXAORgO9o",
      "expanded_url" : "http:\/\/go.wh.gov\/uNkyor",
      "display_url" : "go.wh.gov\/uNkyor"
    } ]
  },
  "geo" : { },
  "id_str" : "414540964045156352",
  "text" : "President Obama's Weekly Address: Working together on behalf of the American people \u2192 http:\/\/t.co\/KdXAORgO9o #ABetterBargain",
  "id" : 414540964045156352,
  "created_at" : "2013-12-21 23:40:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/414513797986930688\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/O25nJ4NJS7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BcCmGmQCUAAeWsH.jpg",
      "id_str" : "414513797995319296",
      "id" : 414513797995319296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcCmGmQCUAAeWsH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1243
      } ],
      "display_url" : "pic.twitter.com\/O25nJ4NJS7"
    } ],
    "hashtags" : [ {
      "text" : "SouthSudan",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414517369571008512",
  "text" : "RT @NSCPress: Readout of President Obama's Updates on #SouthSudan: http:\/\/t.co\/O25nJ4NJS7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/414513797986930688\/photo\/1",
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/O25nJ4NJS7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BcCmGmQCUAAeWsH.jpg",
        "id_str" : "414513797995319296",
        "id" : 414513797995319296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BcCmGmQCUAAeWsH.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 158,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1243
        } ],
        "display_url" : "pic.twitter.com\/O25nJ4NJS7"
      } ],
      "hashtags" : [ {
        "text" : "SouthSudan",
        "indices" : [ 40, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414513797986930688",
    "text" : "Readout of President Obama's Updates on #SouthSudan: http:\/\/t.co\/O25nJ4NJS7",
    "id" : 414513797986930688,
    "created_at" : "2013-12-21 21:52:45 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 414517369571008512,
  "created_at" : "2013-12-21 22:06:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/RdJXxdPh4z",
      "expanded_url" : "http:\/\/go.wh.gov\/hSE8jL",
      "display_url" : "go.wh.gov\/hSE8jL"
    } ]
  },
  "geo" : { },
  "id_str" : "414400403225055232",
  "text" : "\"For the first time in years, both parties came together in the spirit of compromise to pass a budget.\" \u2014Obama: http:\/\/t.co\/RdJXxdPh4z",
  "id" : 414400403225055232,
  "created_at" : "2013-12-21 14:22:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/414183592323842048\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/w6pzeOvwGM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb95yFDCYAA_Bew.png",
      "id_str" : "414183591996710912",
      "id" : 414183591996710912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb95yFDCYAA_Bew.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/w6pzeOvwGM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414183592323842048",
  "text" : "Reflecting in the Oval. http:\/\/t.co\/w6pzeOvwGM",
  "id" : 414183592323842048,
  "created_at" : "2013-12-21 00:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/414169061551906816\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/nNdcHYEDyr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb9skS8CIAEgoem.png",
      "id_str" : "414169061556101121",
      "id" : 414169061556101121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb9skS8CIAEgoem.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 610
      } ],
      "display_url" : "pic.twitter.com\/nNdcHYEDyr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414169061551906816",
  "text" : "Welcome to the Oval Office. http:\/\/t.co\/nNdcHYEDyr",
  "id" : 414169061551906816,
  "created_at" : "2013-12-20 23:02:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Colorado",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414154294108368896",
  "text" : "RT @Interior: Winter is one of the most beautiful times to visit America's public lands like Rocky Mountain NP. #Colorado http:\/\/t.co\/UOJ7r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/414061826163617792\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/UOJ7rMkmVb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb8LCXbIgAARUdx.jpg",
        "id_str" : "414061826016837632",
        "id" : 414061826016837632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb8LCXbIgAARUdx.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UOJ7rMkmVb"
      } ],
      "hashtags" : [ {
        "text" : "Colorado",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414061826163617792",
    "text" : "Winter is one of the most beautiful times to visit America's public lands like Rocky Mountain NP. #Colorado http:\/\/t.co\/UOJ7rMkmVb",
    "id" : 414061826163617792,
    "created_at" : "2013-12-20 15:56:46 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 414154294108368896,
  "created_at" : "2013-12-20 22:04:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/2w1l8SSyyc",
      "expanded_url" : "http:\/\/go.wh.gov\/XSr7iu",
      "display_url" : "go.wh.gov\/XSr7iu"
    } ]
  },
  "geo" : { },
  "id_str" : "414149483375509504",
  "text" : "Doris Kearns Goodwin was one of the first women to become a White House Fellow in 1966. Wanna join the legacy? Apply! http:\/\/t.co\/2w1l8SSyyc",
  "id" : 414149483375509504,
  "created_at" : "2013-12-20 21:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 38, 52 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/aiFBNQbj2T",
      "expanded_url" : "http:\/\/go.usa.gov\/ZDJG",
      "display_url" : "go.usa.gov\/ZDJG"
    } ]
  },
  "geo" : { },
  "id_str" : "414143197871624193",
  "text" : "RT @HHSGov: Have you enrolled through @HealthCareGov? Take a minute and share your #GetCovered story: http:\/\/t.co\/aiFBNQbj2T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 26, 40 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 71, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/aiFBNQbj2T",
        "expanded_url" : "http:\/\/go.usa.gov\/ZDJG",
        "display_url" : "go.usa.gov\/ZDJG"
      } ]
    },
    "geo" : { },
    "id_str" : "414136258265231360",
    "text" : "Have you enrolled through @HealthCareGov? Take a minute and share your #GetCovered story: http:\/\/t.co\/aiFBNQbj2T",
    "id" : 414136258265231360,
    "created_at" : "2013-12-20 20:52:32 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 414143197871624193,
  "created_at" : "2013-12-20 21:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414136093752438784",
  "text" : "RT @Jordan44: Always more to do but w\/budget done, GDP up, jobs #'s up, HC enroll up &amp; deficit down there's some progress to build on next \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414059721189261312",
    "text" : "Always more to do but w\/budget done, GDP up, jobs #'s up, HC enroll up &amp; deficit down there's some progress to build on next year.",
    "id" : 414059721189261312,
    "created_at" : "2013-12-20 15:48:25 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 414136093752438784,
  "created_at" : "2013-12-20 20:51:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "414126649496453120",
  "text" : "President Obama: \u201CI...want to help as many people as possible feel secure that they won\u2019t go broke if they get sick.\u201D http:\/\/t.co\/GNfbftrfo3",
  "id" : 414126649496453120,
  "created_at" : "2013-12-20 20:14:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414123987828875264",
  "text" : "Obama on the ACA: \u201CWe\u2019ve got a couple million people who are going to have health insurance just [from] the first three months.\u201D #GetCovered",
  "id" : 414123987828875264,
  "created_at" : "2013-12-20 20:03:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414114600074752000",
  "text" : "RT @WHLive: Obama: \"This year, we\u2019ve demonstrated that with clear-eyed, principled diplomacy, we can pursue new paths to a world that's mor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414114436429799424",
    "text" : "Obama: \"This year, we\u2019ve demonstrated that with clear-eyed, principled diplomacy, we can pursue new paths to a world that's more secure.\"",
    "id" : 414114436429799424,
    "created_at" : "2013-12-20 19:25:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 414114600074752000,
  "created_at" : "2013-12-20 19:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414114242162196480",
  "text" : "\"The bottom line is, 2014 needs to be a year of action. We have work to do.\" \u2014President Obama #ABetterBargain",
  "id" : 414114242162196480,
  "created_at" : "2013-12-20 19:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414114141113053184",
  "text" : "\"I think we\u2019re a better country than that. We don\u2019t abandon each other when times get tough.\" \u2014Obama on why Congress should #RenewUI",
  "id" : 414114141113053184,
  "created_at" : "2013-12-20 19:24:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414113935931871232",
  "text" : "Obama: \"Because Congress didn\u2019t act, more than one million of their constituents will lose a vital economic lifeline at Christmas.\" #RenewUI",
  "id" : 414113935931871232,
  "created_at" : "2013-12-20 19:23:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414113822350123008",
  "text" : "President Obama: \"For the first time in years, both parties in both houses of Congress came together to pass a budget.\"",
  "id" : 414113822350123008,
  "created_at" : "2013-12-20 19:23:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414113645946101760",
  "text" : "President Obama: \"I firmly believe that 2014 can be a breakthrough year for America.\" #ABetterBargain",
  "id" : 414113645946101760,
  "created_at" : "2013-12-20 19:22:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414113554178924544",
  "text" : "Obama: \"Millions of Americans are now poised to be covered by quality, affordable health insurance come New Year\u2019s Day.\" #GetCovered",
  "id" : 414113554178924544,
  "created_at" : "2013-12-20 19:22:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414113453930856449",
  "text" : "Obama: \"Since October 1st, more than 1 million Americans have selected new health insurance plans through the federal &amp; state marketplaces.\"",
  "id" : 414113453930856449,
  "created_at" : "2013-12-20 19:21:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "414113336645537792",
  "text" : "Obama: \"More than half a million Americans have enrolled through http:\/\/t.co\/GNfbftrfo3 in the first 3 weeks of December alone.\" #GetCovered",
  "id" : 414113336645537792,
  "created_at" : "2013-12-20 19:21:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414113277656825857",
  "text" : "RT @WHLive: Obama: \"Our tax code is fairer &amp; our fiscal situation is firmer\u2014with deficits that are now less than half what they were when I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414113123256123392",
    "text" : "Obama: \"Our tax code is fairer &amp; our fiscal situation is firmer\u2014with deficits that are now less than half what they were when I took office\"",
    "id" : 414113123256123392,
    "created_at" : "2013-12-20 19:20:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 414113277656825857,
  "created_at" : "2013-12-20 19:21:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414113073985634304",
  "text" : "President Obama: \"The unemployment rate has steadily fallen to its lowest point in five years.\" #ABetterBargain",
  "id" : 414113073985634304,
  "created_at" : "2013-12-20 19:20:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414113005178077184",
  "text" : "Obama: \"In 2013, our businesses created another 2 million jobs, adding up to more than 8 million in all over the past 45 months.\"",
  "id" : 414113005178077184,
  "created_at" : "2013-12-20 19:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Q3Is1W1e82",
      "expanded_url" : "http:\/\/go.wh.gov\/1duMpx",
      "display_url" : "go.wh.gov\/1duMpx"
    } ]
  },
  "geo" : { },
  "id_str" : "414112856913625088",
  "text" : "Starting now: President Obama holds a press conference in the White House Briefing Room. Watch \u2192 http:\/\/t.co\/Q3Is1W1e82",
  "id" : 414112856913625088,
  "created_at" : "2013-12-20 19:19:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414100593288835072",
  "text" : "FACT: If Congress doesn't #RenewUI benefits, 1.3 million Americans who are looking for work will lose a vital economic lifeline.",
  "id" : 414100593288835072,
  "created_at" : "2013-12-20 18:30:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/RYT9MJoj50",
      "expanded_url" : "http:\/\/go.wh.gov\/Y9GDe2",
      "display_url" : "go.wh.gov\/Y9GDe2"
    } ]
  },
  "geo" : { },
  "id_str" : "414094299446263808",
  "text" : "Obama: \"I applaud the bipartisan majority of Senators who...confirmed John Koskinen as the next\" IRS commissioner \u2192 http:\/\/t.co\/RYT9MJoj50",
  "id" : 414094299446263808,
  "created_at" : "2013-12-20 18:05:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/t77Zux1o5h",
      "expanded_url" : "http:\/\/go.wh.gov\/xN42of",
      "display_url" : "go.wh.gov\/xN42of"
    } ]
  },
  "geo" : { },
  "id_str" : "414090525143076866",
  "text" : "Here's why renewing unemployment insurance is good for our economy \u2192 http:\/\/t.co\/t77Zux1o5h #RenewUI",
  "id" : 414090525143076866,
  "created_at" : "2013-12-20 17:50:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/raY5nUS243",
      "expanded_url" : "http:\/\/youtu.be\/Q0ObEgk1hUk",
      "display_url" : "youtu.be\/Q0ObEgk1hUk"
    } ]
  },
  "geo" : { },
  "id_str" : "414088046490189824",
  "text" : "RT @Inouye44: Adorable cold open to the latest West Wing Week (12\/20\/13 or \"26 Candles\"):   http:\/\/t.co\/raY5nUS243",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/raY5nUS243",
        "expanded_url" : "http:\/\/youtu.be\/Q0ObEgk1hUk",
        "display_url" : "youtu.be\/Q0ObEgk1hUk"
      } ]
    },
    "geo" : { },
    "id_str" : "414086579825569792",
    "text" : "Adorable cold open to the latest West Wing Week (12\/20\/13 or \"26 Candles\"):   http:\/\/t.co\/raY5nUS243",
    "id" : 414086579825569792,
    "created_at" : "2013-12-20 17:35:08 +0000",
    "user" : {
      "name" : "Shin Inouye",
      "screen_name" : "InouyeUSCIS",
      "protected" : false,
      "id_str" : "1702571186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667848615780446208\/1LoEXwfW_normal.jpg",
      "id" : 1702571186,
      "verified" : true
    }
  },
  "id" : 414088046490189824,
  "created_at" : "2013-12-20 17:40:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 1, 10 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/x6F5IWQdox",
      "expanded_url" : "http:\/\/go.wh.gov\/Cd13qb",
      "display_url" : "go.wh.gov\/Cd13qb"
    } ]
  },
  "geo" : { },
  "id_str" : "414083021617123328",
  "text" : ".@CEAChair breaks down why failing to #RenewUI benefits would hurt 1.3 million Americans looking for work. Watch \u2192 http:\/\/t.co\/x6F5IWQdox",
  "id" : 414083021617123328,
  "created_at" : "2013-12-20 17:21:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/taWHfCxsKd",
      "expanded_url" : "http:\/\/go.wh.gov\/c3xmMx",
      "display_url" : "go.wh.gov\/c3xmMx"
    } ]
  },
  "geo" : { },
  "id_str" : "414077991325417472",
  "text" : "FACT: If Congress fails to #RenewUI benefits, it would reduce demand and cost 240,000 jobs in 2014. http:\/\/t.co\/taWHfCxsKd",
  "id" : 414077991325417472,
  "created_at" : "2013-12-20 17:01:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414070447316025345",
  "text" : "RT if you agree: It's time for Congress to #RenewUI benefits so 1.3 million Americans looking for work don't lose a vital lifeline.",
  "id" : 414070447316025345,
  "created_at" : "2013-12-20 16:31:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Kf9lu7Jd8V",
      "expanded_url" : "http:\/\/go.wh.gov\/oMigiU",
      "display_url" : "go.wh.gov\/oMigiU"
    } ]
  },
  "geo" : { },
  "id_str" : "414065096172650496",
  "text" : "\"These crimes have no place in the greatest military on earth.\" \u2014Obama on eliminating sexual assault: http:\/\/t.co\/Kf9lu7Jd8V",
  "id" : 414065096172650496,
  "created_at" : "2013-12-20 16:09:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/5NTPywco6S",
      "expanded_url" : "http:\/\/go.wh.gov\/baQzcq",
      "display_url" : "go.wh.gov\/baQzcq"
    } ]
  },
  "geo" : { },
  "id_str" : "414051597576970240",
  "text" : "Tune in here for President Obama's press conference at 2pm ET \u2192 http:\/\/t.co\/5NTPywco6S",
  "id" : 414051597576970240,
  "created_at" : "2013-12-20 15:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "414048346131542016",
  "text" : "RT @PressSec: President Obama will hold a news conference at 2 pm EST in the Brady Press Briefing Room today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "414047988797816832",
    "text" : "President Obama will hold a news conference at 2 pm EST in the Brady Press Briefing Room today.",
    "id" : 414047988797816832,
    "created_at" : "2013-12-20 15:01:47 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 414048346131542016,
  "created_at" : "2013-12-20 15:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PCAST",
      "indices" : [ 24, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/m0lxkLQVoP",
      "expanded_url" : "http:\/\/wh.gov\/technology-for-higher-ed",
      "display_url" : "wh.gov\/technology-for\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "414044560709660672",
  "text" : "RT @whitehouseostp: New #PCAST Report: Realizing the Full Potential of Technology in Higher Ed. Learn More \u2192\nhttp:\/\/t.co\/m0lxkLQVoP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PCAST",
        "indices" : [ 4, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/m0lxkLQVoP",
        "expanded_url" : "http:\/\/wh.gov\/technology-for-higher-ed",
        "display_url" : "wh.gov\/technology-for\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413343698743607297",
    "text" : "New #PCAST Report: Realizing the Full Potential of Technology in Higher Ed. Learn More \u2192\nhttp:\/\/t.co\/m0lxkLQVoP",
    "id" : 413343698743607297,
    "created_at" : "2013-12-18 16:23:11 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 414044560709660672,
  "created_at" : "2013-12-20 14:48:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/413836793528991744\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/a0eS3xcJRT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb4-XvgIUAAAMbI.jpg",
      "id_str" : "413836793373806592",
      "id" : 413836793373806592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb4-XvgIUAAAMbI.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/a0eS3xcJRT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413837195443576832",
  "text" : "RT @FLOTUS: The First Lady collects toys from military children for kids in need during a Toys for Tots event in D.C. http:\/\/t.co\/a0eS3xcJRT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/413836793528991744\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/a0eS3xcJRT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb4-XvgIUAAAMbI.jpg",
        "id_str" : "413836793373806592",
        "id" : 413836793373806592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb4-XvgIUAAAMbI.jpg",
        "sizes" : [ {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/a0eS3xcJRT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413836793528991744",
    "text" : "The First Lady collects toys from military children for kids in need during a Toys for Tots event in D.C. http:\/\/t.co\/a0eS3xcJRT",
    "id" : 413836793528991744,
    "created_at" : "2013-12-20 01:02:34 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 413837195443576832,
  "created_at" : "2013-12-20 01:04:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413818802757857283",
  "text" : "RT @Simas44: Love this. Denied by insurance company last year b\/c of diabetes. Now, they cover him and he saves &gt;$3k per year. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/xcMS8ELRau",
        "expanded_url" : "http:\/\/n.pr\/1cUVhq5",
        "display_url" : "n.pr\/1cUVhq5"
      } ]
    },
    "geo" : { },
    "id_str" : "413817353550299136",
    "text" : "Love this. Denied by insurance company last year b\/c of diabetes. Now, they cover him and he saves &gt;$3k per year. http:\/\/t.co\/xcMS8ELRau",
    "id" : 413817353550299136,
    "created_at" : "2013-12-19 23:45:20 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 413818802757857283,
  "created_at" : "2013-12-19 23:51:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "GlacierNationalPark",
      "screen_name" : "GlacierNPS",
      "indices" : [ 24, 35 ],
      "id_str" : "32887168",
      "id" : 32887168
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/413797393113812992\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/ps44tKpWZi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb4aiVjIIAAn3Pm.jpg",
      "id_str" : "413797392967016448",
      "id" : 413797392967016448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb4aiVjIIAAn3Pm.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ps44tKpWZi"
    } ],
    "hashtags" : [ {
      "text" : "Montana",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413799290604355584",
  "text" : "RT @Interior: Ah winter @GlacierNPS. Beautiful isn't it? #Montana http:\/\/t.co\/ps44tKpWZi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GlacierNationalPark",
        "screen_name" : "GlacierNPS",
        "indices" : [ 10, 21 ],
        "id_str" : "32887168",
        "id" : 32887168
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/413797393113812992\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/ps44tKpWZi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb4aiVjIIAAn3Pm.jpg",
        "id_str" : "413797392967016448",
        "id" : 413797392967016448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb4aiVjIIAAn3Pm.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ps44tKpWZi"
      } ],
      "hashtags" : [ {
        "text" : "Montana",
        "indices" : [ 43, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413797393113812992",
    "text" : "Ah winter @GlacierNPS. Beautiful isn't it? #Montana http:\/\/t.co\/ps44tKpWZi",
    "id" : 413797393113812992,
    "created_at" : "2013-12-19 22:26:01 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 413799290604355584,
  "created_at" : "2013-12-19 22:33:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Dick Durbin",
      "screen_name" : "SenatorDurbin",
      "indices" : [ 3, 17 ],
      "id_str" : "247334603",
      "id" : 247334603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413788272289415168",
  "text" : "RT @SenatorDurbin: My message to those in IL who are currently uninsured or just looking for new health coverage options http:\/\/t.co\/wgz4OK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/wgz4OKEoZt",
        "expanded_url" : "http:\/\/1.usa.gov\/IYUTvI",
        "display_url" : "1.usa.gov\/IYUTvI"
      } ]
    },
    "geo" : { },
    "id_str" : "413754082340257792",
    "text" : "My message to those in IL who are currently uninsured or just looking for new health coverage options http:\/\/t.co\/wgz4OKEoZt #GetCovered",
    "id" : 413754082340257792,
    "created_at" : "2013-12-19 19:33:55 +0000",
    "user" : {
      "name" : "Senator Dick Durbin",
      "screen_name" : "SenatorDurbin",
      "protected" : false,
      "id_str" : "247334603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789474472088698880\/1QiXwROv_normal.jpg",
      "id" : 247334603,
      "verified" : true
    }
  },
  "id" : 413788272289415168,
  "created_at" : "2013-12-19 21:49:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413776418774872065",
  "text" : "FACT: Up to 129 million Americans w\/ pre-existing conditions won't have to worry about being denied coverage or charged more. #Obamacare",
  "id" : 413776418774872065,
  "created_at" : "2013-12-19 21:02:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 106, 116 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/vrldxs1ZoO",
      "expanded_url" : "http:\/\/go.wh.gov\/HNRApT",
      "display_url" : "go.wh.gov\/HNRApT"
    } ]
  },
  "geo" : { },
  "id_str" : "413757074028650496",
  "text" : "\"My daughters are just two of the nearly 1 million young Latinos...who have benefitted from\" #Obamacare. \u2014@Cecilia44: http:\/\/t.co\/vrldxs1ZoO",
  "id" : 413757074028650496,
  "created_at" : "2013-12-19 19:45:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/1Li0wy9Z9c",
      "expanded_url" : "http:\/\/go.wh.gov\/r3wncN",
      "display_url" : "go.wh.gov\/r3wncN"
    } ]
  },
  "geo" : { },
  "id_str" : "413745749902389248",
  "text" : "Thanks to #Obamacare, nearly 6 in 10 uninsured Americans can #GetCovered for less than $100\/month \u2192 http:\/\/t.co\/1Li0wy9Z9c",
  "id" : 413745749902389248,
  "created_at" : "2013-12-19 19:00:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/6OBeQW69on",
      "expanded_url" : "http:\/\/wapo.st\/1er1cGK",
      "display_url" : "wapo.st\/1er1cGK"
    } ]
  },
  "geo" : { },
  "id_str" : "413740641860866048",
  "text" : "RT @Jordan44: Who supports raising the minimum wage?:  66% of all Americans (48% strongly support) http:\/\/t.co\/6OBeQW69on",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/6OBeQW69on",
        "expanded_url" : "http:\/\/wapo.st\/1er1cGK",
        "display_url" : "wapo.st\/1er1cGK"
      } ]
    },
    "geo" : { },
    "id_str" : "413718416055218176",
    "text" : "Who supports raising the minimum wage?:  66% of all Americans (48% strongly support) http:\/\/t.co\/6OBeQW69on",
    "id" : 413718416055218176,
    "created_at" : "2013-12-19 17:12:11 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 413740641860866048,
  "created_at" : "2013-12-19 18:40:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413730090065731584",
  "text" : "FACT: 71 million Americans with private insurance have gained access to free preventive care like mammograms and birth control. #Obamacare",
  "id" : 413730090065731584,
  "created_at" : "2013-12-19 17:58:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/GWbf66uKOK",
      "expanded_url" : "http:\/\/go.wh.gov\/KSoPpc",
      "display_url" : "go.wh.gov\/KSoPpc"
    } ]
  },
  "geo" : { },
  "id_str" : "413725967677263872",
  "text" : "RT @WHLive: Happening now: A peek inside the White House holiday decorations via Google+ Hangout: http:\/\/t.co\/GWbf66uKOK Ask a question w\/ \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHangout",
        "indices" : [ 127, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/GWbf66uKOK",
        "expanded_url" : "http:\/\/go.wh.gov\/KSoPpc",
        "display_url" : "go.wh.gov\/KSoPpc"
      } ]
    },
    "geo" : { },
    "id_str" : "413725927088996352",
    "text" : "Happening now: A peek inside the White House holiday decorations via Google+ Hangout: http:\/\/t.co\/GWbf66uKOK Ask a question w\/ #WHHangout",
    "id" : 413725927088996352,
    "created_at" : "2013-12-19 17:42:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 413725967677263872,
  "created_at" : "2013-12-19 17:42:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413715374270476289",
  "text" : "FACT: Up to 17 million kids with pre-existing conditions:\n1. Can't be charged more \u2714\n2. Can't be denied coverage \u2714\n#Obamacare",
  "id" : 413715374270476289,
  "created_at" : "2013-12-19 17:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/1Li0wy9Z9c",
      "expanded_url" : "http:\/\/go.wh.gov\/r3wncN",
      "display_url" : "go.wh.gov\/r3wncN"
    } ]
  },
  "geo" : { },
  "id_str" : "413708478318788608",
  "text" : "Find out how the Affordable Care Act is already benefiting people in your state \u2192 http:\/\/t.co\/1Li0wy9Z9c #Obamacare",
  "id" : 413708478318788608,
  "created_at" : "2013-12-19 16:32:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/413701656124338178\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/aCy6tN0P62",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bb3Dds4IMAAbesw.jpg",
      "id_str" : "413701655818153984",
      "id" : 413701655818153984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bb3Dds4IMAAbesw.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/aCy6tN0P62"
    } ],
    "hashtags" : [ {
      "text" : "WHHoliday",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/T2gpw4KEV3",
      "expanded_url" : "http:\/\/go.wh.gov\/b3MSj9",
      "display_url" : "go.wh.gov\/b3MSj9"
    } ]
  },
  "geo" : { },
  "id_str" : "413701656124338178",
  "text" : "At 12:30pm ET, tour the White House holiday decorations via Google+ Hangout: http:\/\/t.co\/T2gpw4KEV3 #WHHoliday, http:\/\/t.co\/aCy6tN0P62",
  "id" : 413701656124338178,
  "created_at" : "2013-12-19 16:05:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/4Bnq8CkEVA",
      "expanded_url" : "http:\/\/go.wh.gov\/naeG4W",
      "display_url" : "go.wh.gov\/naeG4W"
    } ]
  },
  "geo" : { },
  "id_str" : "413466904959778816",
  "text" : "Obama: \"For the first time in years, both parties in both houses of Congress have come together to pass a budget.\" http:\/\/t.co\/4Bnq8CkEVA",
  "id" : 413466904959778816,
  "created_at" : "2013-12-19 00:32:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413464799272394752",
  "text" : "RT @FLOTUS: Today, the First Lady joined President Obama to meet with moms who are doing great work to help kids #GetCovered. http:\/\/t.co\/7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/413464749192806400\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/7IDmr9vHcM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbzr_6QIMAAzXe3.jpg",
        "id_str" : "413464749012430848",
        "id" : 413464749012430848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbzr_6QIMAAzXe3.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/7IDmr9vHcM"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 101, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413464749192806400",
    "text" : "Today, the First Lady joined President Obama to meet with moms who are doing great work to help kids #GetCovered. http:\/\/t.co\/7IDmr9vHcM",
    "id" : 413464749192806400,
    "created_at" : "2013-12-19 00:24:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 413464799272394752,
  "created_at" : "2013-12-19 00:24:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HealthCareGov\/status\/413437349142753280\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sZUnBRcx5F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbzTFAvIYAACTny.png",
      "id_str" : "413437348861730816",
      "id" : 413437348861730816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbzTFAvIYAACTny.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 808
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 808
      } ],
      "display_url" : "pic.twitter.com\/sZUnBRcx5F"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/zGLCNOOdUv",
      "expanded_url" : "http:\/\/HC.gov",
      "display_url" : "HC.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "413440770159296512",
  "text" : "RT @HealthCareGov: Only 5 days left to sign up for coverage that begins January 1. Visit http:\/\/t.co\/zGLCNOOdUv now! http:\/\/t.co\/sZUnBRcx5F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.wildfireapp.com\/?utm_source=Twitter&utm_medium=Tweet&utm_campaign=via%2BWildfire%2BSuite\" rel=\"nofollow\"\u003EWildfire Suite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HealthCareGov\/status\/413437349142753280\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/sZUnBRcx5F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbzTFAvIYAACTny.png",
        "id_str" : "413437348861730816",
        "id" : 413437348861730816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbzTFAvIYAACTny.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 808
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 808
        } ],
        "display_url" : "pic.twitter.com\/sZUnBRcx5F"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/zGLCNOOdUv",
        "expanded_url" : "http:\/\/HC.gov",
        "display_url" : "HC.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "413437349142753280",
    "text" : "Only 5 days left to sign up for coverage that begins January 1. Visit http:\/\/t.co\/zGLCNOOdUv now! http:\/\/t.co\/sZUnBRcx5F",
    "id" : 413437349142753280,
    "created_at" : "2013-12-18 22:35:19 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 413440770159296512,
  "created_at" : "2013-12-18 22:48:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413436946745012224",
  "text" : "RT @Simas44: Huge #ACA numbers. In CA, 15,000 enrolling per day. In NY, 4500 per day. In CT, 1400 per day and 3000 per day in KY. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 5, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tmF55jrqqm",
        "expanded_url" : "http:\/\/wapo.st\/1eoWitN",
        "display_url" : "wapo.st\/1eoWitN"
      } ]
    },
    "geo" : { },
    "id_str" : "413403178353176576",
    "text" : "Huge #ACA numbers. In CA, 15,000 enrolling per day. In NY, 4500 per day. In CT, 1400 per day and 3000 per day in KY. http:\/\/t.co\/tmF55jrqqm",
    "id" : 413403178353176576,
    "created_at" : "2013-12-18 20:19:33 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 413436946745012224,
  "created_at" : "2013-12-18 22:33:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Uq67KmZJTF",
      "expanded_url" : "http:\/\/hc.gov\/oM43Bx",
      "display_url" : "hc.gov\/oM43Bx"
    } ]
  },
  "geo" : { },
  "id_str" : "413413555795283968",
  "text" : "#GetCovered because\nno one should go broke\nbecause they get hurt or sick.\nhttp:\/\/t.co\/Uq67KmZJTF",
  "id" : 413413555795283968,
  "created_at" : "2013-12-18 21:00:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/Uq67KmZJTF",
      "expanded_url" : "http:\/\/hc.gov\/oM43Bx",
      "display_url" : "hc.gov\/oM43Bx"
    } ]
  },
  "geo" : { },
  "id_str" : "413398454996459520",
  "text" : "#GetCovered because\nit is the smart thing to do\nand saves you money.\nhttp:\/\/t.co\/Uq67KmZJTF",
  "id" : 413398454996459520,
  "created_at" : "2013-12-18 20:00:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Uq67KmZJTF",
      "expanded_url" : "http:\/\/hc.gov\/oM43Bx",
      "display_url" : "hc.gov\/oM43Bx"
    } ]
  },
  "geo" : { },
  "id_str" : "413387127427039232",
  "text" : "#GetCovered because\nyou never know when you'll get\nsick or get injured.\nhttp:\/\/t.co\/Uq67KmZJTF",
  "id" : 413387127427039232,
  "created_at" : "2013-12-18 19:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Uq67KmZJTF",
      "expanded_url" : "http:\/\/hc.gov\/oM43Bx",
      "display_url" : "hc.gov\/oM43Bx"
    } ]
  },
  "geo" : { },
  "id_str" : "413379578535493632",
  "text" : "RT to spread the word: Millions of Americans can #GetCovered through their state's #Obamacare marketplace right now \u2192 http:\/\/t.co\/Uq67KmZJTF",
  "id" : 413379578535493632,
  "created_at" : "2013-12-18 18:45:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/413351128449835008\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/AuzOkQdFau",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbyEqUtCYAAUEhL.jpg",
      "id_str" : "413351128458223616",
      "id" : 413351128458223616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbyEqUtCYAAUEhL.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AuzOkQdFau"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413375681880666112",
  "text" : "RT @NancyPelosi: How the #ACA is giving 3 million young adults\u2014and their parents\u2014some peace of mind: http:\/\/t.co\/AuzOkQdFau",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/413351128449835008\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/AuzOkQdFau",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbyEqUtCYAAUEhL.jpg",
        "id_str" : "413351128458223616",
        "id" : 413351128458223616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbyEqUtCYAAUEhL.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/AuzOkQdFau"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 8, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413351128449835008",
    "text" : "How the #ACA is giving 3 million young adults\u2014and their parents\u2014some peace of mind: http:\/\/t.co\/AuzOkQdFau",
    "id" : 413351128449835008,
    "created_at" : "2013-12-18 16:52:43 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 413375681880666112,
  "created_at" : "2013-12-18 18:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/dx5AtNxp2v",
      "expanded_url" : "http:\/\/bit.ly\/1fn7uDB",
      "display_url" : "bit.ly\/1fn7uDB"
    } ]
  },
  "geo" : { },
  "id_str" : "413370596152467456",
  "text" : "RT @FLOTUS: The First Lady, as a mom, on the importance of making sure all our kids #GetCovered \u2192 http:\/\/t.co\/dx5AtNxp2v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 72, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/dx5AtNxp2v",
        "expanded_url" : "http:\/\/bit.ly\/1fn7uDB",
        "display_url" : "bit.ly\/1fn7uDB"
      } ]
    },
    "geo" : { },
    "id_str" : "413368378355490816",
    "text" : "The First Lady, as a mom, on the importance of making sure all our kids #GetCovered \u2192 http:\/\/t.co\/dx5AtNxp2v",
    "id" : 413368378355490816,
    "created_at" : "2013-12-18 18:01:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 413370596152467456,
  "created_at" : "2013-12-18 18:10:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TZ3qXWkELc",
      "expanded_url" : "http:\/\/cnnmon.ie\/HKq0nB",
      "display_url" : "cnnmon.ie\/HKq0nB"
    } ]
  },
  "geo" : { },
  "id_str" : "413363220284334080",
  "text" : "Thanks to #Obamacare, Sarah A. \"received...coverage just as her kidney was shutting down.\" It helped save her life \u2192 http:\/\/t.co\/TZ3qXWkELc",
  "id" : 413363220284334080,
  "created_at" : "2013-12-18 17:40:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 19, 27 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BidenInAsia",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/MJdcVf5ink",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/photos-and-video\/video\/2013\/12\/18\/board-travels-vice-president-asia",
      "display_url" : "whitehouse.gov\/photos-and-vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413361272340889601",
  "text" : "RT @VP: Watch this @WHVideo --&gt; On Board: Travels with the Vice President in Asia http:\/\/t.co\/MJdcVf5ink #BidenInAsia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Video",
        "screen_name" : "WHVideo",
        "indices" : [ 11, 19 ],
        "id_str" : "1378231782",
        "id" : 1378231782
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BidenInAsia",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/MJdcVf5ink",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/photos-and-video\/video\/2013\/12\/18\/board-travels-vice-president-asia",
        "display_url" : "whitehouse.gov\/photos-and-vid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413356503257468928",
    "text" : "Watch this @WHVideo --&gt; On Board: Travels with the Vice President in Asia http:\/\/t.co\/MJdcVf5ink #BidenInAsia",
    "id" : 413356503257468928,
    "created_at" : "2013-12-18 17:14:04 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 413361272340889601,
  "created_at" : "2013-12-18 17:33:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "indices" : [ 3, 13 ],
      "id_str" : "1712989040",
      "id" : 1712989040
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 33, 40 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NC",
      "indices" : [ 64, 67 ]
    }, {
      "text" : "VA",
      "indices" : [ 68, 71 ]
    }, {
      "text" : "NJ",
      "indices" : [ 72, 75 ]
    }, {
      "text" : "MD",
      "indices" : [ 82, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413355382049103872",
  "text" : "RT @Rosholm44: Today POTUS &amp; @FLOTUS will meet w\/ moms from #NC #VA #NJ &amp; #MD in the Oval to talk abt the role moms play to ensure young ad\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 18, 25 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NC",
        "indices" : [ 49, 52 ]
      }, {
        "text" : "VA",
        "indices" : [ 53, 56 ]
      }, {
        "text" : "NJ",
        "indices" : [ 57, 60 ]
      }, {
        "text" : "MD",
        "indices" : [ 67, 70 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 137, 148 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413353118932287488",
    "text" : "Today POTUS &amp; @FLOTUS will meet w\/ moms from #NC #VA #NJ &amp; #MD in the Oval to talk abt the role moms play to ensure young adults #GetCovered",
    "id" : 413353118932287488,
    "created_at" : "2013-12-18 17:00:37 +0000",
    "user" : {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "protected" : false,
      "id_str" : "1712989040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755544708483538944\/h-5gKL6u_normal.jpg",
      "id" : 1712989040,
      "verified" : true
    }
  },
  "id" : 413355382049103872,
  "created_at" : "2013-12-18 17:09:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/413338447286652928\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xEk0aQmLhX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbx5ILHIYAAUsGP.jpg",
      "id_str" : "413338447139856384",
      "id" : 413338447139856384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbx5ILHIYAAUsGP.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/xEk0aQmLhX"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413348119636484097",
  "text" : "If you're a young adult under 26\u2014#Obamacare lets you stay on your parents' health plan while you pursue your career. http:\/\/t.co\/xEk0aQmLhX",
  "id" : 413348119636484097,
  "created_at" : "2013-12-18 16:40:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/413338447286652928\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/xEk0aQmLhX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbx5ILHIYAAUsGP.jpg",
      "id_str" : "413338447139856384",
      "id" : 413338447139856384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbx5ILHIYAAUsGP.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/xEk0aQmLhX"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 6, 16 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413338447286652928",
  "text" : "FACT: #Obamacare has helped more than 3 million young adults #GetCovered by staying on their parents' plans. http:\/\/t.co\/xEk0aQmLhX",
  "id" : 413338447286652928,
  "created_at" : "2013-12-18 16:02:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/413112034910547968\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/QP9BCroesn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BburNOmIcAAP35h.jpg",
      "id_str" : "413112034579214336",
      "id" : 413112034579214336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BburNOmIcAAP35h.jpg",
      "sizes" : [ {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QP9BCroesn"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/ekpz447xhS",
      "expanded_url" : "http:\/\/hc.gov\/tioV2F",
      "display_url" : "hc.gov\/tioV2F"
    } ]
  },
  "geo" : { },
  "id_str" : "413112034910547968",
  "text" : "#GetCovered because nobody should go broke just because they get sick \u2192 http:\/\/t.co\/ekpz447xhS, http:\/\/t.co\/QP9BCroesn",
  "id" : 413112034910547968,
  "created_at" : "2013-12-18 01:02:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "indices" : [ 3, 14 ],
      "id_str" : "20655674",
      "id" : 20655674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413092286986469376",
  "text" : "RT @ACAstories: FL: Nancy Lewe says the ACA is \"a dream come true.\" She'll be saving $600\/mo for better cvg w\/ a tiny deductible. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/iADjsm5GW3",
        "expanded_url" : "http:\/\/www.hhs.gov\/healthcare\/facts\/blog\/2013\/12\/signing-up-for-health-insurance-in-miami.html",
        "display_url" : "hhs.gov\/healthcare\/fac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412985976152006656",
    "text" : "FL: Nancy Lewe says the ACA is \"a dream come true.\" She'll be saving $600\/mo for better cvg w\/ a tiny deductible. http:\/\/t.co\/iADjsm5GW3",
    "id" : 412985976152006656,
    "created_at" : "2013-12-17 16:41:44 +0000",
    "user" : {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "protected" : false,
      "id_str" : "20655674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442325097731223552\/qhUhX6DV_normal.png",
      "id" : 20655674,
      "verified" : false
    }
  },
  "id" : 413092286986469376,
  "created_at" : "2013-12-17 23:44:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "Erin44",
      "indices" : [ 3, 10 ],
      "id_str" : "41044637",
      "id" : 41044637
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 40, 47 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 68, 73 ],
      "id_str" : "14293310",
      "id" : 14293310
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 80, 90 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Instameet",
      "indices" : [ 23, 33 ]
    }, {
      "text" : "TBT",
      "indices" : [ 48, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/vAzxTZ76nO",
      "expanded_url" : "http:\/\/newsfeed.time.com\/2013\/12\/16\/here-are-the-top-12-moments-on-instagram-in-2013\/",
      "display_url" : "newsfeed.time.com\/2013\/12\/16\/her\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "413085369073012736",
  "text" : "RT @Erin44: The 1st WH #Instameet &amp; @FLOTUS #TBT featured among @TIME's top @Instagram moments of 2013 \u2192 http:\/\/t.co\/vAzxTZ76nO http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 28, 35 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "TIME",
        "screen_name" : "TIME",
        "indices" : [ 56, 61 ],
        "id_str" : "14293310",
        "id" : 14293310
      }, {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 68, 78 ],
        "id_str" : "180505807",
        "id" : 180505807
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Erin44\/status\/413033175070175232\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/ANV6YQsB7Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbtjfADCcAEqSFD.jpg",
        "id_str" : "413033175074369537",
        "id" : 413033175074369537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbtjfADCcAEqSFD.jpg",
        "sizes" : [ {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ANV6YQsB7Y"
      } ],
      "hashtags" : [ {
        "text" : "Instameet",
        "indices" : [ 11, 21 ]
      }, {
        "text" : "TBT",
        "indices" : [ 36, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/vAzxTZ76nO",
        "expanded_url" : "http:\/\/newsfeed.time.com\/2013\/12\/16\/here-are-the-top-12-moments-on-instagram-in-2013\/",
        "display_url" : "newsfeed.time.com\/2013\/12\/16\/her\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "413033175070175232",
    "text" : "The 1st WH #Instameet &amp; @FLOTUS #TBT featured among @TIME's top @Instagram moments of 2013 \u2192 http:\/\/t.co\/vAzxTZ76nO http:\/\/t.co\/ANV6YQsB7Y",
    "id" : 413033175070175232,
    "created_at" : "2013-12-17 19:49:17 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 413085369073012736,
  "created_at" : "2013-12-17 23:16:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/413039840129597440\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/JeoMQxYtTc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbtpi8NCQAAmbj5.jpg",
      "id_str" : "413039839831801856",
      "id" : 413039839831801856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbtpi8NCQAAmbj5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JeoMQxYtTc"
    } ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 63, 68 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/S0VChxLxGO",
      "expanded_url" : "http:\/\/go.wh.gov\/bwUbyy",
      "display_url" : "go.wh.gov\/bwUbyy"
    } ]
  },
  "geo" : { },
  "id_str" : "413073807843139584",
  "text" : "Share the top 5 ways that the Affordable Care Act benefits the #LGBT community \u2192 http:\/\/t.co\/S0VChxLxGO #Obamacare, http:\/\/t.co\/JeoMQxYtTc",
  "id" : 413073807843139584,
  "created_at" : "2013-12-17 22:30:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WrightBrothers",
      "indices" : [ 128, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/qkXF6rXMlO",
      "expanded_url" : "http:\/\/go.wh.gov\/rMu8Ks",
      "display_url" : "go.wh.gov\/rMu8Ks"
    } ]
  },
  "geo" : { },
  "id_str" : "413065488931909632",
  "text" : "\"On Dec 17, 1903\u2014decades of dreaming, experimenting &amp;...engineering culminated in 12 secs of flight\" http:\/\/t.co\/qkXF6rXMlO #WrightBrothers",
  "id" : 413065488931909632,
  "created_at" : "2013-12-17 21:57:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 22, 27 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 85, 95 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/S0VChxLxGO",
      "expanded_url" : "http:\/\/go.wh.gov\/bwUbyy",
      "display_url" : "go.wh.gov\/bwUbyy"
    } ]
  },
  "geo" : { },
  "id_str" : "413054932523032577",
  "text" : "FACT: Legally married #LGBT couples are treated equally when buying coverage through #Obamacare \u2192 http:\/\/t.co\/S0VChxLxGO #GetCovered",
  "id" : 413054932523032577,
  "created_at" : "2013-12-17 21:15:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/S0VChxLxGO",
      "expanded_url" : "http:\/\/go.wh.gov\/bwUbyy",
      "display_url" : "go.wh.gov\/bwUbyy"
    } ]
  },
  "geo" : { },
  "id_str" : "413047382591291392",
  "text" : "FACT: Thanks to #Obamacare, insurers can't discriminate based on sexual orientation or gender identity \u2192 http:\/\/t.co\/S0VChxLxGO #GetCovered",
  "id" : 413047382591291392,
  "created_at" : "2013-12-17 20:45:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/413039840129597440\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/JeoMQxYtTc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbtpi8NCQAAmbj5.jpg",
      "id_str" : "413039839831801856",
      "id" : 413039839831801856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbtpi8NCQAAmbj5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JeoMQxYtTc"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413039840129597440",
  "text" : "Americans who #GetCovered through #Obamacare can't be charged more because of who they are or who they love. http:\/\/t.co\/JeoMQxYtTc",
  "id" : 413039840129597440,
  "created_at" : "2013-12-17 20:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "indices" : [ 3, 14 ],
      "id_str" : "17494010",
      "id" : 17494010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 26, 30 ]
    }, {
      "text" : "getcovered",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413016877628424192",
  "text" : "RT @SenSchumer: Thanks to #ACA, NY seniors already saved an average of $975 per person on prescription drugs this year. #getcovered http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 10, 14 ]
      }, {
        "text" : "getcovered",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/FT0QbXCK4g",
        "expanded_url" : "http:\/\/ow.ly\/i\/43iCJ",
        "display_url" : "ow.ly\/i\/43iCJ"
      } ]
    },
    "geo" : { },
    "id_str" : "413013232845332480",
    "text" : "Thanks to #ACA, NY seniors already saved an average of $975 per person on prescription drugs this year. #getcovered http:\/\/t.co\/FT0QbXCK4g",
    "id" : 413013232845332480,
    "created_at" : "2013-12-17 18:30:02 +0000",
    "user" : {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "protected" : false,
      "id_str" : "17494010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623955176131575808\/zWzgRP4C_normal.jpg",
      "id" : 17494010,
      "verified" : true
    }
  },
  "id" : 413016877628424192,
  "created_at" : "2013-12-17 18:44:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/412972144188878848\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wWZVp3FZdJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbsr-htCEAANbJD.jpg",
      "id_str" : "412972144033665024",
      "id" : 412972144033665024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbsr-htCEAANbJD.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wWZVp3FZdJ"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412983209735888896",
  "text" : "Thanks to #Obamacare, more than 7 million people with Medicare have saved nearly $9 billion on prescription drugs. http:\/\/t.co\/wWZVp3FZdJ",
  "id" : 412983209735888896,
  "created_at" : "2013-12-17 16:30:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/412972144188878848\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/wWZVp3FZdJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbsr-htCEAANbJD.jpg",
      "id_str" : "412972144033665024",
      "id" : 412972144033665024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbsr-htCEAANbJD.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wWZVp3FZdJ"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412972144188878848",
  "text" : "Good news: Seniors are saving billions on prescription drugs thanks to the Affordable Care Act. #Obamacare, http:\/\/t.co\/wWZVp3FZdJ",
  "id" : 412972144188878848,
  "created_at" : "2013-12-17 15:46:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 78, 85 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KPEY1ewqqB",
      "expanded_url" : "http:\/\/go.wh.gov\/hXdJJN",
      "display_url" : "go.wh.gov\/hXdJJN"
    } ]
  },
  "geo" : { },
  "id_str" : "412741243710361600",
  "text" : "Obama: \"I am pleased the Senate has confirmed Jeh Johnson as our next Sec. of @DHSGov with broad bipartisan support\" http:\/\/t.co\/KPEY1ewqqB",
  "id" : 412741243710361600,
  "created_at" : "2013-12-17 00:29:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/iZJY74bMjf",
      "expanded_url" : "http:\/\/go.wh.gov\/1zJ3Ng",
      "display_url" : "go.wh.gov\/1zJ3Ng"
    } ]
  },
  "geo" : { },
  "id_str" : "412734499303067648",
  "text" : "RT @FLOTUS: The First Lady reads \"The Night Before Christmas\" to kids at the Children's National Medical Center \u2192 http:\/\/t.co\/iZJY74bMjf #H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HappyHolidays",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/iZJY74bMjf",
        "expanded_url" : "http:\/\/go.wh.gov\/1zJ3Ng",
        "display_url" : "go.wh.gov\/1zJ3Ng"
      } ]
    },
    "geo" : { },
    "id_str" : "412734137540157440",
    "text" : "The First Lady reads \"The Night Before Christmas\" to kids at the Children's National Medical Center \u2192 http:\/\/t.co\/iZJY74bMjf #HappyHolidays",
    "id" : 412734137540157440,
    "created_at" : "2013-12-17 00:01:01 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 412734499303067648,
  "created_at" : "2013-12-17 00:02:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/412694167244926977\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/UGbez7PZtC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbovKJgCcAAD6kx.jpg",
      "id_str" : "412694167253315584",
      "id" : 412694167253315584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbovKJgCcAAD6kx.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/UGbez7PZtC"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/okCdguMscR",
      "expanded_url" : "http:\/\/go.wh.gov\/oaVSXP",
      "display_url" : "go.wh.gov\/oaVSXP"
    } ]
  },
  "geo" : { },
  "id_str" : "412694167244926977",
  "text" : "Student filmmakers: Submit your 3-min film on using technology to learn for the #WHFilmFest. http:\/\/t.co\/okCdguMscR, http:\/\/t.co\/UGbez7PZtC",
  "id" : 412694167244926977,
  "created_at" : "2013-12-16 21:22:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "CSEdWeek",
      "screen_name" : "CSEdWeek",
      "indices" : [ 27, 36 ],
      "id_str" : "84662571",
      "id" : 84662571
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HourOfCode",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/BtuOwuTziu",
      "expanded_url" : "http:\/\/code.org",
      "display_url" : "code.org"
    } ]
  },
  "geo" : { },
  "id_str" : "412683190877581312",
  "text" : "RT @whitehouseostp: During @csedweek it's estimated that 1 in 5 US students tried an #HourOfCode. Keep it up at http:\/\/t.co\/BtuOwuTziu http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CSEdWeek",
        "screen_name" : "CSEdWeek",
        "indices" : [ 7, 16 ],
        "id_str" : "84662571",
        "id" : 84662571
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HourOfCode",
        "indices" : [ 65, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/BtuOwuTziu",
        "expanded_url" : "http:\/\/code.org",
        "display_url" : "code.org"
      }, {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/2GP4u8Y9v5",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=6XvmhE1J9PY",
        "display_url" : "youtube.com\/watch?v=6XvmhE\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412680737968496640",
    "text" : "During @csedweek it's estimated that 1 in 5 US students tried an #HourOfCode. Keep it up at http:\/\/t.co\/BtuOwuTziu http:\/\/t.co\/2GP4u8Y9v5",
    "id" : 412680737968496640,
    "created_at" : "2013-12-16 20:28:49 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 412683190877581312,
  "created_at" : "2013-12-16 20:38:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "indices" : [ 3, 14 ],
      "id_str" : "20655674",
      "id" : 20655674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412679525987008512",
  "text" : "RT @ACAstories: CA: Biz owner Tonia McMillian was \"just floored\" b\/c ACA wld cover her &amp; her son for ~$180\/mo. \"Extremely affordable\" http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/DgmARdkKrE",
        "expanded_url" : "http:\/\/www.bet.com\/news\/health\/2013\/10\/11\/obamacare-and-me-tonia-mcmillian.html",
        "display_url" : "bet.com\/news\/health\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "412654033627652097",
    "text" : "CA: Biz owner Tonia McMillian was \"just floored\" b\/c ACA wld cover her &amp; her son for ~$180\/mo. \"Extremely affordable\" http:\/\/t.co\/DgmARdkKrE",
    "id" : 412654033627652097,
    "created_at" : "2013-12-16 18:42:43 +0000",
    "user" : {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "protected" : false,
      "id_str" : "20655674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442325097731223552\/qhUhX6DV_normal.png",
      "id" : 20655674,
      "verified" : false
    }
  },
  "id" : 412679525987008512,
  "created_at" : "2013-12-16 20:24:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 61, 64 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/eWlZ8ST2m2",
      "expanded_url" : "http:\/\/go.wh.gov\/nxcB5u",
      "display_url" : "go.wh.gov\/nxcB5u"
    } ]
  },
  "geo" : { },
  "id_str" : "412661080448442369",
  "text" : "Don't miss behind-the-scenes coverage of President Obama and @VP Biden from the past week. Watch \u2192 http:\/\/t.co\/eWlZ8ST2m2 #WestWingWeek",
  "id" : 412661080448442369,
  "created_at" : "2013-12-16 19:10:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YEc5aER98N",
      "expanded_url" : "http:\/\/go.wh.gov\/kE4sB1",
      "display_url" : "go.wh.gov\/kE4sB1"
    } ]
  },
  "geo" : { },
  "id_str" : "412651014676705281",
  "text" : "FACT: Thanks to #Obamacare, 8.5 million Americans received an average refund of $100 per family from their insurers. http:\/\/t.co\/YEc5aER98N",
  "id" : 412651014676705281,
  "created_at" : "2013-12-16 18:30:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412643464564572161",
  "text" : "FACT: Thanks to the Affordable Care Act, nearly 80 million Americans saved $3.4 billion on their premiums in 2012. #Obamacare",
  "id" : 412643464564572161,
  "created_at" : "2013-12-16 18:00:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discovery Education",
      "screen_name" : "DiscoveryEd",
      "indices" : [ 3, 15 ],
      "id_str" : "1665531",
      "id" : 1665531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/vscUOjf3Fb",
      "expanded_url" : "http:\/\/ow.ly\/rOvOE",
      "display_url" : "ow.ly\/rOvOE"
    } ]
  },
  "geo" : { },
  "id_str" : "412643080622575616",
  "text" : "RT @DiscoveryEd: 300,000+ students are signed up for our broadcast from the White House at 1pm ET.  See you there?  http:\/\/t.co\/vscUOjf3Fb \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OfThePeople",
        "indices" : [ 122, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/vscUOjf3Fb",
        "expanded_url" : "http:\/\/ow.ly\/rOvOE",
        "display_url" : "ow.ly\/rOvOE"
      } ]
    },
    "geo" : { },
    "id_str" : "412634653439561728",
    "text" : "300,000+ students are signed up for our broadcast from the White House at 1pm ET.  See you there?  http:\/\/t.co\/vscUOjf3Fb #OfThePeople",
    "id" : 412634653439561728,
    "created_at" : "2013-12-16 17:25:42 +0000",
    "user" : {
      "name" : "Discovery Education",
      "screen_name" : "DiscoveryEd",
      "protected" : false,
      "id_str" : "1665531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605812969688043521\/aKoqrKWQ_normal.jpg",
      "id" : 1665531,
      "verified" : false
    }
  },
  "id" : 412643080622575616,
  "created_at" : "2013-12-16 17:59:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/412631766118064128\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/xe51R2Pu4o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bbn2Z6lCcAAGU6C.jpg",
      "id_str" : "412631765962878976",
      "id" : 412631765962878976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bbn2Z6lCcAAGU6C.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xe51R2Pu4o"
    } ],
    "hashtags" : [ {
      "text" : "ObamacareInThreeWords",
      "indices" : [ 0, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/EaMKHfEFxT",
      "expanded_url" : "http:\/\/go.wh.gov\/AWbczb",
      "display_url" : "go.wh.gov\/AWbczb"
    } ]
  },
  "geo" : { },
  "id_str" : "412631766118064128",
  "text" : "#ObamacareInThreeWords: Saving people money \u2192 http:\/\/t.co\/EaMKHfEFxT, http:\/\/t.co\/xe51R2Pu4o",
  "id" : 412631766118064128,
  "created_at" : "2013-12-16 17:14:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/412620000294236160\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/PTDLc07P6K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbnrtEGCcAExwVr.jpg",
      "id_str" : "412620000306819073",
      "id" : 412620000306819073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbnrtEGCcAExwVr.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PTDLc07P6K"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412620000294236160",
  "text" : "RT to share how the Affordable Care Act is helping consumers get more value for their premium dollars. #Obamacare, http:\/\/t.co\/PTDLc07P6K",
  "id" : 412620000294236160,
  "created_at" : "2013-12-16 16:27:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/412599964598935552\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/uhliY9xNEZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbnZe1TCIAA4rMT.jpg",
      "id_str" : "412599964607324160",
      "id" : 412599964607324160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbnZe1TCIAA4rMT.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/uhliY9xNEZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412599964598935552",
  "text" : "Morning commute. http:\/\/t.co\/uhliY9xNEZ",
  "id" : 412599964598935552,
  "created_at" : "2013-12-16 15:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 3, 15 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Open4Biz",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412591099463880704",
  "text" : "RT @CommerceSec: Don\u2019t forget to join me at 2:15 ET today for a Twitter chat about the #Open4Biz agenda. Send in your questions with #Open4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Open4Biz",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "Open4Biz",
        "indices" : [ 116, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "412568471000850432",
    "text" : "Don\u2019t forget to join me at 2:15 ET today for a Twitter chat about the #Open4Biz agenda. Send in your questions with #Open4Biz hashtag.",
    "id" : 412568471000850432,
    "created_at" : "2013-12-16 13:02:43 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 412591099463880704,
  "created_at" : "2013-12-16 14:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/S8fmVUd2Qp",
      "expanded_url" : "http:\/\/go.wh.gov\/9BWgf9",
      "display_url" : "go.wh.gov\/9BWgf9"
    } ]
  },
  "geo" : { },
  "id_str" : "411933778139807746",
  "text" : "\"Real change won\u2019t come from Washington. It will come the way it\u2019s always come\u2014from you.\" \u2014President Obama: http:\/\/t.co\/S8fmVUd2Qp #Newtown",
  "id" : 411933778139807746,
  "created_at" : "2013-12-14 19:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/VJX038XF8p",
      "expanded_url" : "http:\/\/go.wh.gov\/tMoeoH",
      "display_url" : "go.wh.gov\/tMoeoH"
    } ]
  },
  "geo" : { },
  "id_str" : "411918676158193666",
  "text" : "Obama: \"We have to do everything we can to protect our children from harm &amp; make them feel loved, valued &amp; cared for\" http:\/\/t.co\/VJX038XF8p",
  "id" : 411918676158193666,
  "created_at" : "2013-12-14 18:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandyHook",
      "indices" : [ 65, 75 ]
    }, {
      "text" : "Newtown",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/RwObz4cW5I",
      "expanded_url" : "http:\/\/go.wh.gov\/xJXKRK",
      "display_url" : "go.wh.gov\/xJXKRK"
    } ]
  },
  "geo" : { },
  "id_str" : "411907349884829698",
  "text" : "\"We must treat every child like they\u2019re our child. Like those in #SandyHook, we must choose love.\" \u2014Obama: http:\/\/t.co\/RwObz4cW5I #Newtown",
  "id" : 411907349884829698,
  "created_at" : "2013-12-14 17:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 20, 27 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/411896312594853889\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/NsdhSY0edK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbdZg4UCYAA_SDW.jpg",
      "id_str" : "411896312334802944",
      "id" : 411896312334802944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbdZg4UCYAA_SDW.jpg",
      "sizes" : [ {
        "h" : 1364,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1364,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NsdhSY0edK"
    } ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "SandyHook",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411896312594853889",
  "text" : "President Obama and @FLOTUS light 26 candles in remembrance of the victims of the #Newtown shooting. #SandyHook, http:\/\/t.co\/NsdhSY0edK",
  "id" : 411896312594853889,
  "created_at" : "2013-12-14 16:31:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/rb7j3Ai9Cx",
      "expanded_url" : "http:\/\/go.wh.gov\/8LDdSz",
      "display_url" : "go.wh.gov\/8LDdSz"
    } ]
  },
  "geo" : { },
  "id_str" : "411883930967486464",
  "text" : "\"One year ago today, a quiet, peaceful town was shattered by unspeakable violence.\" \u2014Obama on the #Newtown shooting: http:\/\/t.co\/rb7j3Ai9Cx",
  "id" : 411883930967486464,
  "created_at" : "2013-12-14 15:42:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/8TL5TqSeBU",
      "expanded_url" : "http:\/\/go.wh.gov\/9guhef",
      "display_url" : "go.wh.gov\/9guhef"
    } ]
  },
  "geo" : { },
  "id_str" : "411864567442972672",
  "text" : "Happening at 9:30am ET: Join President Obama for a moment of silence honoring the victims of the Sandy Hook shooting. http:\/\/t.co\/8TL5TqSeBU",
  "id" : 411864567442972672,
  "created_at" : "2013-12-14 14:25:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/b0OxZGYnur",
      "expanded_url" : "http:\/\/go.wh.gov\/mK2je6",
      "display_url" : "go.wh.gov\/mK2je6"
    } ]
  },
  "geo" : { },
  "id_str" : "411858276842606592",
  "text" : "At 9:30am ET, join President Obama for a moment of silence to honor the victims of the Sandy Hook shooting. http:\/\/t.co\/b0OxZGYnur #Newtown",
  "id" : 411858276842606592,
  "created_at" : "2013-12-14 14:00:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/411644088639705088\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/OsgtGhQarl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbZ0Hh4CUAAv6Gv.jpg",
      "id_str" : "411644088652288000",
      "id" : 411644088652288000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbZ0Hh4CUAAv6Gv.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/OsgtGhQarl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411644088639705088",
  "text" : "Tomorrow at 9:30am ET, join President Obama for a moment of silence to honor the victims of the Sandy Hook shooting. http:\/\/t.co\/OsgtGhQarl",
  "id" : 411644088639705088,
  "created_at" : "2013-12-13 23:49:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 20, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/z1dZFFbubY",
      "expanded_url" : "http:\/\/hc.gov\/3hLQ18",
      "display_url" : "hc.gov\/3hLQ18"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HP4WJSprz4",
      "expanded_url" : "http:\/\/go.wh.gov\/2TFw4H",
      "display_url" : "go.wh.gov\/2TFw4H"
    } ]
  },
  "geo" : { },
  "id_str" : "411591513391382530",
  "text" : "Share the 4 ways to #GetCovered:\n1. Visit http:\/\/t.co\/z1dZFFbubY\n2. By mail \u2709\n3. \u260F 1-800-318-2596\n4. In person \u270D\nhttp:\/\/t.co\/HP4WJSprz4",
  "id" : 411591513391382530,
  "created_at" : "2013-12-13 20:20:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "National Guard",
      "screen_name" : "USNationalGuard",
      "indices" : [ 58, 74 ],
      "id_str" : "31310158",
      "id" : 31310158
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411587779294801921",
  "text" : "RT @DrBiden: From our National Guard family to the entire @USNationalGuard family \u2013 Happy 377th Birthday!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Guard",
        "screen_name" : "USNationalGuard",
        "indices" : [ 45, 61 ],
        "id_str" : "31310158",
        "id" : 31310158
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "411585942713929728",
    "text" : "From our National Guard family to the entire @USNationalGuard family \u2013 Happy 377th Birthday!",
    "id" : 411585942713929728,
    "created_at" : "2013-12-13 19:58:30 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 411587779294801921,
  "created_at" : "2013-12-13 20:05:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Equality",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/qdWBFY8GSf",
      "expanded_url" : "http:\/\/go.wh.gov\/zmdvaV",
      "display_url" : "go.wh.gov\/zmdvaV"
    } ]
  },
  "geo" : { },
  "id_str" : "411578298389368832",
  "text" : "Great news: All legal same-sex marriages will now be recognized for federal financial aid purposes \u2192 http:\/\/t.co\/qdWBFY8GSf #Equality",
  "id" : 411578298389368832,
  "created_at" : "2013-12-13 19:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 79, 90 ]
    }, {
      "text" : "EnRollTide",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/VZCEDP3Fn1",
      "expanded_url" : "http:\/\/hc.gov\/HF5Q7q",
      "display_url" : "hc.gov\/HF5Q7q"
    } ]
  },
  "geo" : { },
  "id_str" : "411568863801647104",
  "text" : "Thanks to the Affordable Care Act, 643,000 uninsured Alabamans are eligible to #GetCovered \u2192 http:\/\/t.co\/VZCEDP3Fn1 #EnRollTide",
  "id" : 411568863801647104,
  "created_at" : "2013-12-13 18:50:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Levine",
      "screen_name" : "adamlevine",
      "indices" : [ 39, 50 ],
      "id_str" : "58528137",
      "id" : 58528137
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/gQlA6IDIrc",
      "expanded_url" : "http:\/\/hc.gov\/WKQBuC",
      "display_url" : "hc.gov\/WKQBuC"
    } ]
  },
  "geo" : { },
  "id_str" : "411560055385763840",
  "text" : "Here's how \u2192 http:\/\/t.co\/gQlA6IDIrc MT @AdamLevine: California is where I call home. Now you can #GetCovered if you're a resident. So hurry!",
  "id" : 411560055385763840,
  "created_at" : "2013-12-13 18:15:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/VZCEDP3Fn1",
      "expanded_url" : "http:\/\/hc.gov\/HF5Q7q",
      "display_url" : "hc.gov\/HF5Q7q"
    } ]
  },
  "geo" : { },
  "id_str" : "411551247494176768",
  "text" : "Thanks to the Affordable Care Act, more than 5.5 million uninsured Californians are eligible to #GetCovered \u2014&gt; http:\/\/t.co\/VZCEDP3Fn1",
  "id" : 411551247494176768,
  "created_at" : "2013-12-13 17:40:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/VZCEDP3Fn1",
      "expanded_url" : "http:\/\/hc.gov\/HF5Q7q",
      "display_url" : "hc.gov\/HF5Q7q"
    } ]
  },
  "geo" : { },
  "id_str" : "411544955279003648",
  "text" : "Thanks to the Affordable Care Act, more than 3.5 million uninsured Floridians are eligible to #GetCovered \u2014&gt; http:\/\/t.co\/VZCEDP3Fn1",
  "id" : 411544955279003648,
  "created_at" : "2013-12-13 17:15:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "HookEmHealthCare",
      "indices" : [ 126, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/VZCEDP3Fn1",
      "expanded_url" : "http:\/\/hc.gov\/HF5Q7q",
      "display_url" : "hc.gov\/HF5Q7q"
    } ]
  },
  "geo" : { },
  "id_str" : "411538875329155072",
  "text" : "Thanks to the Affordable Care Act, nearly 5 million uninsured Texans are eligible to #GetCovered \u2014&gt; http:\/\/t.co\/VZCEDP3Fn1 #HookEmHealthCare",
  "id" : 411538875329155072,
  "created_at" : "2013-12-13 16:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/411524510030909440\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Uau2v8MdRQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbYHXH5CQAEAHCu.jpg",
      "id_str" : "411524509787635713",
      "id" : 411524509787635713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbYHXH5CQAEAHCu.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Uau2v8MdRQ"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 28, 38 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411524510030909440",
  "text" : "RT the good news: Thanks to #Obamacare, nearly 6 in 10 uninsured Americans can #GetCovered for $100\/month or less. http:\/\/t.co\/Uau2v8MdRQ",
  "id" : 411524510030909440,
  "created_at" : "2013-12-13 15:54:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/411299698868121600\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/XG4gwPws92",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbU65ZSCcAA_Sr0.jpg",
      "id_str" : "411299698687766528",
      "id" : 411299698687766528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbU65ZSCcAA_Sr0.jpg",
      "sizes" : [ {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XG4gwPws92"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/bjreKFBfQi",
      "expanded_url" : "http:\/\/go.wh.gov\/gGbFXu",
      "display_url" : "go.wh.gov\/gGbFXu"
    } ]
  },
  "geo" : { },
  "id_str" : "411299698868121600",
  "text" : "Nobody\nshould\ngo\nbroke\njust\nbecause\nthey\nget\nsick.\nhttp:\/\/t.co\/bjreKFBfQi\n#GetCovered, http:\/\/t.co\/XG4gwPws92",
  "id" : 411299698868121600,
  "created_at" : "2013-12-13 01:01:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/KIOMt4ajhf",
      "expanded_url" : "http:\/\/go.wh.gov\/JCn5fq",
      "display_url" : "go.wh.gov\/JCn5fq"
    } ]
  },
  "geo" : { },
  "id_str" : "411276509878304768",
  "text" : "Right now, millions of Americans can sign up for affordable health insurance. Let's help them #GetCovered \u2014&gt; http:\/\/t.co\/KIOMt4ajhf",
  "id" : 411276509878304768,
  "created_at" : "2013-12-12 23:28:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Lopez",
      "screen_name" : "georgelopez",
      "indices" : [ 3, 15 ],
      "id_str" : "49717874",
      "id" : 49717874
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 17, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/VSwm845vJe",
      "expanded_url" : "http:\/\/deets.at\/0LDt",
      "display_url" : "deets.at\/0LDt"
    } ]
  },
  "geo" : { },
  "id_str" : "411264714564317184",
  "text" : "RT @georgelopez: #GetCovered at this moment so you put yourself in the best place for the next moment. http:\/\/t.co\/VSwm845vJe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adly.com\" rel=\"nofollow\"\u003EAdly Connect\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/VSwm845vJe",
        "expanded_url" : "http:\/\/deets.at\/0LDt",
        "display_url" : "deets.at\/0LDt"
      } ]
    },
    "geo" : { },
    "id_str" : "411178677117128704",
    "text" : "#GetCovered at this moment so you put yourself in the best place for the next moment. http:\/\/t.co\/VSwm845vJe",
    "id" : 411178677117128704,
    "created_at" : "2013-12-12 17:00:10 +0000",
    "user" : {
      "name" : "George Lopez",
      "screen_name" : "georgelopez",
      "protected" : false,
      "id_str" : "49717874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786174487360212992\/Joit4e_G_normal.jpg",
      "id" : 49717874,
      "verified" : true
    }
  },
  "id" : 411264714564317184,
  "created_at" : "2013-12-12 22:42:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tatyana Ali",
      "screen_name" : "TatyanaAli",
      "indices" : [ 3, 14 ],
      "id_str" : "105001809",
      "id" : 105001809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/j01GVZiGgo",
      "expanded_url" : "http:\/\/deets.at\/0mDt",
      "display_url" : "deets.at\/0mDt"
    } ]
  },
  "geo" : { },
  "id_str" : "411260528951300096",
  "text" : "RT @TatyanaAli: Nothing is more important than our health. Make it your family's top priority and #GetCovered today. http:\/\/t.co\/j01GVZiGgo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adly.com\" rel=\"nofollow\"\u003EAdly Connect\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 82, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/j01GVZiGgo",
        "expanded_url" : "http:\/\/deets.at\/0mDt",
        "display_url" : "deets.at\/0mDt"
      } ]
    },
    "geo" : { },
    "id_str" : "411178680464199680",
    "text" : "Nothing is more important than our health. Make it your family's top priority and #GetCovered today. http:\/\/t.co\/j01GVZiGgo",
    "id" : 411178680464199680,
    "created_at" : "2013-12-12 17:00:11 +0000",
    "user" : {
      "name" : "Tatyana Ali",
      "screen_name" : "TatyanaAli",
      "protected" : false,
      "id_str" : "105001809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774103742887014400\/x5l_R15y_normal.jpg",
      "id" : 105001809,
      "verified" : true
    }
  },
  "id" : 411260528951300096,
  "created_at" : "2013-12-12 22:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/411254585341145088\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/7Ypa3lK5r7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbUR3cwCAAAbdLM.png",
      "id_str" : "411254585282396160",
      "id" : 411254585282396160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbUR3cwCAAAbdLM.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/7Ypa3lK5r7"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "411254585341145088",
  "text" : "#GetCovered because\nit is the smart thing to do\nand saves you money\nhttp:\/\/t.co\/GNfbftrfo3, http:\/\/t.co\/7Ypa3lK5r7",
  "id" : 411254585341145088,
  "created_at" : "2013-12-12 22:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "indices" : [ 3, 19 ],
      "id_str" : "43910797",
      "id" : 43910797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OH",
      "indices" : [ 36, 39 ]
    }, {
      "text" : "ACA",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411250846454644736",
  "text" : "RT @SenSherrodBrown: More than 643k #OH children with pre-existing conditions can no longer be denied health coverage thanks to #ACA http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OH",
        "indices" : [ 15, 18 ]
      }, {
        "text" : "ACA",
        "indices" : [ 107, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/CvpUHqypJM",
        "expanded_url" : "http:\/\/ow.ly\/rImKX",
        "display_url" : "ow.ly\/rImKX"
      } ]
    },
    "geo" : { },
    "id_str" : "411240302784311298",
    "text" : "More than 643k #OH children with pre-existing conditions can no longer be denied health coverage thanks to #ACA http:\/\/t.co\/CvpUHqypJM",
    "id" : 411240302784311298,
    "created_at" : "2013-12-12 21:05:03 +0000",
    "user" : {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "protected" : false,
      "id_str" : "43910797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523158370333638657\/cLmYIfYa_normal.jpeg",
      "id" : 43910797,
      "verified" : true
    }
  },
  "id" : 411250846454644736,
  "created_at" : "2013-12-12 21:46:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/411239384273272832\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/C34q1MWVhJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbUECoCCUAEq0h0.png",
      "id_str" : "411239384126476289",
      "id" : 411239384126476289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbUECoCCUAEq0h0.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/C34q1MWVhJ"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "411239384273272832",
  "text" : "#GetCovered because\nif you don't, one injury\ncould give you huge bills\nhttp:\/\/t.co\/GNfbftrfo3, http:\/\/t.co\/C34q1MWVhJ",
  "id" : 411239384273272832,
  "created_at" : "2013-12-12 21:01:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/411231710227857409\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/AP3HLgeQBV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbT9D8TCYAAF3nI.png",
      "id_str" : "411231710164967424",
      "id" : 411231710164967424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbT9D8TCYAAF3nI.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AP3HLgeQBV"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "411231710227857409",
  "text" : "#GetCovered because\nyour mom will have peace of mind\n(and you will as well).\nhttp:\/\/t.co\/GNfbftrfo3, http:\/\/t.co\/AP3HLgeQBV",
  "id" : 411231710227857409,
  "created_at" : "2013-12-12 20:30:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/411226029881970688\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/xIN98tIxLX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbT35TLCYAAnJ-8.jpg",
      "id_str" : "411226029768728576",
      "id" : 411226029768728576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbT35TLCYAAnJ-8.jpg",
      "sizes" : [ {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xIN98tIxLX"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/eR8TeNMAhp",
      "expanded_url" : "http:\/\/go.wh.gov\/c8nakG",
      "display_url" : "go.wh.gov\/c8nakG"
    } ]
  },
  "geo" : { },
  "id_str" : "411226029881970688",
  "text" : "President Obama: \"#GetCovered because nobody should go broke just because they get sick.\" http:\/\/t.co\/eR8TeNMAhp, http:\/\/t.co\/xIN98tIxLX",
  "id" : 411226029881970688,
  "created_at" : "2013-12-12 20:08:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411199471234449408",
  "text" : "FACT: The House GOP has voted more than 40 times to repeal #Obamacare\u2014which would let insurers deny coverage due to pre-existing conditions.",
  "id" : 411199471234449408,
  "created_at" : "2013-12-12 18:22:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/lNFbAbKn1n",
      "expanded_url" : "http:\/\/go.wh.gov\/B4j25C",
      "display_url" : "go.wh.gov\/B4j25C"
    } ]
  },
  "geo" : { },
  "id_str" : "411187728647069696",
  "text" : "Thanks to #Obamacare, insurers can't deny coverage to kids like Zoie, who has a pre-existing condition: http:\/\/t.co\/lNFbAbKn1n",
  "id" : 411187728647069696,
  "created_at" : "2013-12-12 17:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/411173361767559169\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/fcLBPPFWb4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbTH_m2CYAASjSO.jpg",
      "id_str" : "411173361570439168",
      "id" : 411173361570439168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbTH_m2CYAASjSO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/fcLBPPFWb4"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 88, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "411173361767559169",
  "text" : "Kids with pre-existing conditions:\n1. Can't be denied coverage\n2. Can't be charged more\n#Obamacare, http:\/\/t.co\/fcLBPPFWb4",
  "id" : 411173361767559169,
  "created_at" : "2013-12-12 16:39:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 84, 95 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/78GYCw0n2j",
      "expanded_url" : "http:\/\/go.wh.gov\/MPTT8c",
      "display_url" : "go.wh.gov\/MPTT8c"
    } ]
  },
  "geo" : { },
  "id_str" : "411161703234031617",
  "text" : "FACT: 63% in TN support expanding Medicaid through #Obamacare\u2014which would help 234K #GetCovered: http:\/\/t.co\/78GYCw0n2j #PeopleOverPolitics",
  "id" : 411161703234031617,
  "created_at" : "2013-12-12 15:52:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raisethewage",
      "indices" : [ 40, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/OayJocBQc2",
      "expanded_url" : "http:\/\/wh.gov\/lCJzi",
      "display_url" : "wh.gov\/lCJzi"
    } ]
  },
  "geo" : { },
  "id_str" : "411158552913641472",
  "text" : "RT @Jordan44: And here\u2019s why we need to #raisethewage for our economy http:\/\/t.co\/OayJocBQc2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "raisethewage",
        "indices" : [ 26, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/OayJocBQc2",
        "expanded_url" : "http:\/\/wh.gov\/lCJzi",
        "display_url" : "wh.gov\/lCJzi"
      } ]
    },
    "geo" : { },
    "id_str" : "411145812274458625",
    "text" : "And here\u2019s why we need to #raisethewage for our economy http:\/\/t.co\/OayJocBQc2",
    "id" : 411145812274458625,
    "created_at" : "2013-12-12 14:49:35 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 411158552913641472,
  "created_at" : "2013-12-12 15:40:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/qbHwgxDHvp",
      "expanded_url" : "http:\/\/go.wh.gov\/2hkTVe",
      "display_url" : "go.wh.gov\/2hkTVe"
    } ]
  },
  "geo" : { },
  "id_str" : "411145887889358849",
  "text" : "Obama: \"I thank the Senate for confirming Nina Pillard to be a judge on the U.S. Court of Appeals for the DC Circuit\" http:\/\/t.co\/qbHwgxDHvp",
  "id" : 411145887889358849,
  "created_at" : "2013-12-12 14:49:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410959817596211201\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/XdbPzytVXO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbQFxs-IQAALDAq.jpg",
      "id_str" : "410959817441034240",
      "id" : 410959817441034240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbQFxs-IQAALDAq.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/XdbPzytVXO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410959817596211201",
  "text" : "Holiday hops from the Crenshaw Elite Choir. http:\/\/t.co\/XdbPzytVXO",
  "id" : 410959817596211201,
  "created_at" : "2013-12-12 02:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410944654436487168\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/ASJSUJKB3c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbP3_FJIQAEPGEr.png",
      "id_str" : "410944654105133057",
      "id" : 410944654105133057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbP3_FJIQAEPGEr.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ASJSUJKB3c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410944654436487168",
  "text" : "Happy Holidays from the White House Colonnade! http:\/\/t.co\/ASJSUJKB3c",
  "id" : 410944654436487168,
  "created_at" : "2013-12-12 01:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410927464026607616\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/wnBrOTnLeY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbPoWeaCAAAa9bo.png",
      "id_str" : "410927463837859840",
      "id" : 410927463837859840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbPoWeaCAAAa9bo.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 610
      } ],
      "display_url" : "pic.twitter.com\/wnBrOTnLeY"
    } ],
    "hashtags" : [ {
      "text" : "WHHoliday",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410927464026607616",
  "text" : "Holiday lights in the Rose Garden. #WHHoliday, http:\/\/t.co\/wnBrOTnLeY",
  "id" : 410927464026607616,
  "created_at" : "2013-12-12 00:21:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/HealthCareGov\/status\/410899962533146624\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/X7QIVOo86F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbPPVsGCcAEBfnS.jpg",
      "id_str" : "410899962541535233",
      "id" : 410899962541535233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbPPVsGCcAEBfnS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 810
      }, {
        "h" : 599,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 810
      } ],
      "display_url" : "pic.twitter.com\/X7QIVOo86F"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/vQ74UBBs7F",
      "expanded_url" : "http:\/\/HC.gov",
      "display_url" : "HC.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "410905625976373248",
  "text" : "RT @HealthCareGov: Visit http:\/\/t.co\/vQ74UBBs7F to apply, compare your options and #GetCovered. --&gt; http:\/\/t.co\/X7QIVOo86F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/HealthCareGov\/status\/410899962533146624\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/X7QIVOo86F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbPPVsGCcAEBfnS.jpg",
        "id_str" : "410899962541535233",
        "id" : 410899962541535233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbPPVsGCcAEBfnS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 810
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 810
        } ],
        "display_url" : "pic.twitter.com\/X7QIVOo86F"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 64, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/vQ74UBBs7F",
        "expanded_url" : "http:\/\/HC.gov",
        "display_url" : "HC.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "410899962533146624",
    "text" : "Visit http:\/\/t.co\/vQ74UBBs7F to apply, compare your options and #GetCovered. --&gt; http:\/\/t.co\/X7QIVOo86F",
    "id" : 410899962533146624,
    "created_at" : "2013-12-11 22:32:40 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 410905625976373248,
  "created_at" : "2013-12-11 22:55:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410894956400627712\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ZmueVTerHe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbPKyR7CQAAHBhx.jpg",
      "id_str" : "410894956174131200",
      "id" : 410894956174131200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbPKyR7CQAAHBhx.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/ZmueVTerHe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410894956400627712",
  "text" : "FACT: Community Health Centers employ more than 148,000 Americans\u2014and have added 35,000 jobs over the past 4 years. http:\/\/t.co\/ZmueVTerHe",
  "id" : 410894956400627712,
  "created_at" : "2013-12-11 22:12:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Knoller",
      "screen_name" : "markknoller",
      "indices" : [ 3, 15 ],
      "id_str" : "31127446",
      "id" : 31127446
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 76, 91 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410879313194409984",
  "text" : "RT @markknoller: In online Q&amp;A on immigration reform, VP Biden calls on @SpeakerBoehner to call up the Senate bill for a vote \"and this is \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 59, 74 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410877777399664641",
    "text" : "In online Q&amp;A on immigration reform, VP Biden calls on @SpeakerBoehner to call up the Senate bill for a vote \"and this is over.\"",
    "id" : 410877777399664641,
    "created_at" : "2013-12-11 21:04:30 +0000",
    "user" : {
      "name" : "Mark Knoller",
      "screen_name" : "markknoller",
      "protected" : false,
      "id_str" : "31127446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/137394623\/knoller_normal.jpg",
      "id" : 31127446,
      "verified" : true
    }
  },
  "id" : 410879313194409984,
  "created_at" : "2013-12-11 21:10:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 23, 26 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 33, 43 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "Skype",
      "screen_name" : "Skype",
      "indices" : [ 50, 56 ],
      "id_str" : "2459371",
      "id" : 2459371
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 66, 84 ]
    }, {
      "text" : "AskTheWhiteHouse",
      "indices" : [ 99, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/NjVMpYdNZd",
      "expanded_url" : "http:\/\/go.wh.gov\/NhUX1q",
      "display_url" : "go.wh.gov\/NhUX1q"
    } ]
  },
  "geo" : { },
  "id_str" : "410875205431472128",
  "text" : "Starting now: Join the @VP &amp; @Cecilia44 for a @Skype event on #ImmigrationReform. Ask Q's with #AskTheWhiteHouse: http:\/\/t.co\/NjVMpYdNZd",
  "id" : 410875205431472128,
  "created_at" : "2013-12-11 20:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skype",
      "screen_name" : "Skype",
      "indices" : [ 3, 9 ],
      "id_str" : "2459371",
      "id" : 2459371
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 53, 56 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Skype",
      "indices" : [ 26, 32 ]
    }, {
      "text" : "AskTheWhiteHouse",
      "indices" : [ 84, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/02KL4qNuEI",
      "expanded_url" : "http:\/\/spr.ly\/6016d606",
      "display_url" : "spr.ly\/6016d606"
    } ]
  },
  "geo" : { },
  "id_str" : "410868926394793984",
  "text" : "RT @Skype: Watch the live #Skype video call today w\/ @VP &amp; send questions using #AskTheWhiteHouse. http:\/\/t.co\/02KL4qNuEI http:\/\/t.co\/cIgoe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 42, 45 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Skype\/status\/410816253545418752\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/cIgoegsGGk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbODNK5IcAEQg2N.png",
        "id_str" : "410816253306368001",
        "id" : 410816253306368001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbODNK5IcAEQg2N.png",
        "sizes" : [ {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/cIgoegsGGk"
      } ],
      "hashtags" : [ {
        "text" : "Skype",
        "indices" : [ 15, 21 ]
      }, {
        "text" : "AskTheWhiteHouse",
        "indices" : [ 73, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/02KL4qNuEI",
        "expanded_url" : "http:\/\/spr.ly\/6016d606",
        "display_url" : "spr.ly\/6016d606"
      } ]
    },
    "geo" : { },
    "id_str" : "410816253545418752",
    "text" : "Watch the live #Skype video call today w\/ @VP &amp; send questions using #AskTheWhiteHouse. http:\/\/t.co\/02KL4qNuEI http:\/\/t.co\/cIgoegsGGk",
    "id" : 410816253545418752,
    "created_at" : "2013-12-11 17:00:02 +0000",
    "user" : {
      "name" : "Skype",
      "screen_name" : "Skype",
      "protected" : false,
      "id_str" : "2459371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/699737454375337984\/Vt-S5uEi_normal.png",
      "id" : 2459371,
      "verified" : true
    }
  },
  "id" : 410868926394793984,
  "created_at" : "2013-12-11 20:29:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/N61xf5Mhwy",
      "expanded_url" : "http:\/\/go.wh.gov\/m8xqHd",
      "display_url" : "go.wh.gov\/m8xqHd"
    } ]
  },
  "geo" : { },
  "id_str" : "410863489805066240",
  "text" : "RT to share the 4 ways you can #GetCovered:\n1. http:\/\/t.co\/GNfbftrfo3\n2. By mail\n3. In person\n4. Call 1-800-318-2596\nhttp:\/\/t.co\/N61xf5Mhwy",
  "id" : 410863489805066240,
  "created_at" : "2013-12-11 20:07:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/hgb7ZsmQXm",
      "expanded_url" : "http:\/\/wapo.st\/JeyjQb",
      "display_url" : "wapo.st\/JeyjQb"
    } ]
  },
  "geo" : { },
  "id_str" : "410858019694465024",
  "text" : "RT @ezraklein: Under Obamacare, nearly three times as many women are getting free birth control pills http:\/\/t.co\/hgb7ZsmQXm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/hgb7ZsmQXm",
        "expanded_url" : "http:\/\/wapo.st\/JeyjQb",
        "display_url" : "wapo.st\/JeyjQb"
      } ]
    },
    "geo" : { },
    "id_str" : "410855761661947905",
    "text" : "Under Obamacare, nearly three times as many women are getting free birth control pills http:\/\/t.co\/hgb7ZsmQXm",
    "id" : 410855761661947905,
    "created_at" : "2013-12-11 19:37:01 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 410858019694465024,
  "created_at" : "2013-12-11 19:45:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "Cosmopolitan",
      "screen_name" : "Cosmopolitan",
      "indices" : [ 19, 32 ],
      "id_str" : "23482952",
      "id" : 23482952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 46, 50 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/SOTAYbpwc2",
      "expanded_url" : "http:\/\/bit.ly\/1aVJPG2",
      "display_url" : "bit.ly\/1aVJPG2"
    } ]
  },
  "geo" : { },
  "id_str" : "410854705837772800",
  "text" : "RT @Simas44: Great @Cosmopolitan tips on what #ACA means for women with pre-existing medical conditions. #GetCovered http:\/\/t.co\/SOTAYbpwc2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cosmopolitan",
        "screen_name" : "Cosmopolitan",
        "indices" : [ 6, 19 ],
        "id_str" : "23482952",
        "id" : 23482952
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 33, 37 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 92, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/SOTAYbpwc2",
        "expanded_url" : "http:\/\/bit.ly\/1aVJPG2",
        "display_url" : "bit.ly\/1aVJPG2"
      } ]
    },
    "geo" : { },
    "id_str" : "410853428621885442",
    "text" : "Great @Cosmopolitan tips on what #ACA means for women with pre-existing medical conditions. #GetCovered http:\/\/t.co\/SOTAYbpwc2",
    "id" : 410853428621885442,
    "created_at" : "2013-12-11 19:27:45 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 410854705837772800,
  "created_at" : "2013-12-11 19:32:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "indices" : [ 3, 14 ],
      "id_str" : "20655674",
      "id" : 20655674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410850808641912832",
  "text" : "RT @ACAstories: MT: Mimi Hood Dayhuff &amp; husband are grateful for the ACA, which will save at least $550\/mo. \"Wow, what a blessing!\" http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/Yjxfxxl30S",
        "expanded_url" : "http:\/\/www.bozemandailychronicle.com\/opinions\/letters_to_editor\/article_d95522b2-5dcd-11e3-8347-001a4bcf887a.html",
        "display_url" : "bozemandailychronicle.com\/opinions\/lette\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "410847597973102592",
    "text" : "MT: Mimi Hood Dayhuff &amp; husband are grateful for the ACA, which will save at least $550\/mo. \"Wow, what a blessing!\" http:\/\/t.co\/Yjxfxxl30S",
    "id" : 410847597973102592,
    "created_at" : "2013-12-11 19:04:35 +0000",
    "user" : {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "protected" : false,
      "id_str" : "20655674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442325097731223552\/qhUhX6DV_normal.png",
      "id" : 20655674,
      "verified" : false
    }
  },
  "id" : 410850808641912832,
  "created_at" : "2013-12-11 19:17:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 23, 33 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/410839037705216000\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/4SV9sRa5zG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbOX7YtIgAARoYJ.jpg",
      "id_str" : "410839037520674816",
      "id" : 410839037520674816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbOX7YtIgAARoYJ.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4SV9sRa5zG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410839037705216000",
  "text" : "Happy 70th birthday to @StateDept Secretary John Kerry! http:\/\/t.co\/4SV9sRa5zG",
  "id" : 410839037705216000,
  "created_at" : "2013-12-11 18:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 9, 12 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 19, 29 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410830678633115649\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/EnVVnDly8m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbOQU1KCMAAagVl.jpg",
      "id_str" : "410830678561796096",
      "id" : 410830678561796096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbOQU1KCMAAagVl.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EnVVnDly8m"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 64, 82 ]
    }, {
      "text" : "AskTheWhiteHouse",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410830678633115649",
  "text" : "Join the @VP &amp; @Cecilia44 at 3:45pm ET for a Skype event on #ImmigrationReform. Ask questions w\/ #AskTheWhiteHouse: http:\/\/t.co\/EnVVnDly8m",
  "id" : 410830678633115649,
  "created_at" : "2013-12-11 17:57:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410818402073059328\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/U7eyfiU4kc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbOFKPJCAAAaMu1.jpg",
      "id_str" : "410818401930444800",
      "id" : 410818401930444800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbOFKPJCAAAaMu1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/U7eyfiU4kc"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410818402073059328",
  "text" : "#Obamacare supports &amp; expands Community Health Centers.\nThey provide primary care to more than 21 million Americans. http:\/\/t.co\/U7eyfiU4kc",
  "id" : 410818402073059328,
  "created_at" : "2013-12-11 17:08:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/eYfkLQW7WH",
      "expanded_url" : "http:\/\/huff.to\/IFtaAb",
      "display_url" : "huff.to\/IFtaAb"
    } ]
  },
  "geo" : { },
  "id_str" : "410812971481169920",
  "text" : "RT @Simas44: ACA enrollment surpasses 1 million and growing every single day. #GetCovered  http:\/\/t.co\/eYfkLQW7WH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 65, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/eYfkLQW7WH",
        "expanded_url" : "http:\/\/huff.to\/IFtaAb",
        "display_url" : "huff.to\/IFtaAb"
      } ]
    },
    "geo" : { },
    "id_str" : "410806425376411648",
    "text" : "ACA enrollment surpasses 1 million and growing every single day. #GetCovered  http:\/\/t.co\/eYfkLQW7WH",
    "id" : 410806425376411648,
    "created_at" : "2013-12-11 16:20:58 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 410812971481169920,
  "created_at" : "2013-12-11 16:46:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410806664661446656",
  "text" : "RT @PressSec: FACT: Through November, 2.3 million Americans have already been determined eligible for a plan on the #Obamacare marketplaces\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 102, 112 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410798113272500224",
    "text" : "FACT: Through November, 2.3 million Americans have already been determined eligible for a plan on the #Obamacare marketplaces. #GetCovered",
    "id" : 410798113272500224,
    "created_at" : "2013-12-11 15:47:57 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 410806664661446656,
  "created_at" : "2013-12-11 16:21:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 92, 102 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/yWWMrOLJ8S",
      "expanded_url" : "http:\/\/wapo.st\/JegUah",
      "display_url" : "wapo.st\/JegUah"
    } ]
  },
  "geo" : { },
  "id_str" : "410802598912872448",
  "text" : "FACT: Since October 1st, 1.2 million Americans have signed up for health coverage thanks to #Obamacare \u2014&gt; http:\/\/t.co\/yWWMrOLJ8S #GetCovered",
  "id" : 410802598912872448,
  "created_at" : "2013-12-11 16:05:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 20, 30 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "410794203552047105",
  "text" : "Good news:\nNovember #Obamacare enrollees = 4 x October enrollees.\nLet's help even more Americans #GetCovered \u2014&gt; http:\/\/t.co\/GNfbftrfo3",
  "id" : 410794203552047105,
  "created_at" : "2013-12-11 15:32:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410597426316472320\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/GQdSdMLl8h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbK8LvGIQAAUvkB.jpg",
      "id_str" : "410597425850892288",
      "id" : 410597425850892288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbK8LvGIQAAUvkB.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/GQdSdMLl8h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410597426316472320",
  "text" : "\"We can choose a world defined not by our differences\u2014but by our common hopes.\" \u2014Obama at Mandela's memorial service: http:\/\/t.co\/GQdSdMLl8h",
  "id" : 410597426316472320,
  "created_at" : "2013-12-11 02:30:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Bush",
      "screen_name" : "GeorgeHWBush",
      "indices" : [ 20, 33 ],
      "id_str" : "475988505",
      "id" : 475988505
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/410584823766728704\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/yZtsrI3b4r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbKwuLVIYAArcR-.jpg",
      "id_str" : "410584823406026752",
      "id" : 410584823406026752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbKwuLVIYAArcR-.jpg",
      "sizes" : [ {
        "h" : 473,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 932
      } ],
      "display_url" : "pic.twitter.com\/yZtsrI3b4r"
    } ],
    "hashtags" : [ {
      "text" : "SocksOfTheDay",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410584823766728704",
  "text" : "Welcome to Twitter, @GeorgeHWBush! Can we expect #SocksOfTheDay? http:\/\/t.co\/yZtsrI3b4r",
  "id" : 410584823766728704,
  "created_at" : "2013-12-11 01:40:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/K9nRsR87Jz",
      "expanded_url" : "http:\/\/go.wh.gov\/WcGnYS",
      "display_url" : "go.wh.gov\/WcGnYS"
    } ]
  },
  "geo" : { },
  "id_str" : "410576054072270848",
  "text" : "Obama: \"I want to call on Members of Congress from both parties to take the next step and actually pass a budget.\" http:\/\/t.co\/K9nRsR87Jz",
  "id" : 410576054072270848,
  "created_at" : "2013-12-11 01:05:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410569851652939776\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Pgpvrz1X7H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbKjGtOCIAAb3li.png",
      "id_str" : "410569851657134080",
      "id" : 410569851657134080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbKjGtOCIAAb3li.png",
      "sizes" : [ {
        "h" : 278,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 92,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 1194
      } ],
      "display_url" : "pic.twitter.com\/Pgpvrz1X7H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410569851652939776",
  "text" : "President Obama: Mel Watt is the \"right person to protect Americans who work hard and play by the rules every day.\" http:\/\/t.co\/Pgpvrz1X7H",
  "id" : 410569851652939776,
  "created_at" : "2013-12-11 00:40:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/K9nRsR87Jz",
      "expanded_url" : "http:\/\/go.wh.gov\/WcGnYS",
      "display_url" : "go.wh.gov\/WcGnYS"
    } ]
  },
  "geo" : { },
  "id_str" : "410568107686514688",
  "text" : "\"Today\u2019s bipartisan budget agreement is a good first step.\" \u2014President Obama: http:\/\/t.co\/K9nRsR87Jz",
  "id" : 410568107686514688,
  "created_at" : "2013-12-11 00:33:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 10, 13 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 20, 30 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 39, 57 ]
    }, {
      "text" : "AskTheWhiteHouse",
      "indices" : [ 102, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/MYIeXpEHp4",
      "expanded_url" : "http:\/\/www.bing.com\/whitehouse",
      "display_url" : "bing.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "410549172375281664",
  "text" : "Watch the @VP &amp; @Cecilia44 discuss #ImmigrationReform tomorrow at 3:45pm ET. Tweet your Q's using #AskTheWhiteHouse: http:\/\/t.co\/MYIeXpEHp4",
  "id" : 410549172375281664,
  "created_at" : "2013-12-10 23:18:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410544463732162561\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/NGa0WoO6Yj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbKMA7ZCQAAids3.jpg",
      "id_str" : "410544463614722048",
      "id" : 410544463614722048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbKMA7ZCQAAids3.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/NGa0WoO6Yj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410544463732162561",
  "text" : "President Obama greets Gra\u00E7a Machel, Nelson Mandela's widow, after speaking at today's memorial service. http:\/\/t.co\/NGa0WoO6Yj",
  "id" : 410544463732162561,
  "created_at" : "2013-12-10 23:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/XDYhGIaTpq",
      "expanded_url" : "http:\/\/go.wh.gov\/qPn8ug",
      "display_url" : "go.wh.gov\/qPn8ug"
    } ]
  },
  "geo" : { },
  "id_str" : "410515000109711360",
  "text" : "President Obama on Senate confirmation of Patricia Millett to the D.C. Circuit of the U.S. Court of Appeals \u2014&gt; http:\/\/t.co\/XDYhGIaTpq",
  "id" : 410515000109711360,
  "created_at" : "2013-12-10 21:02:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 55, 63 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 88, 99 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/LEkvXUecoi",
      "expanded_url" : "http:\/\/nyti.ms\/1f2X2AY",
      "display_url" : "nyti.ms\/1f2X2AY"
    } ]
  },
  "geo" : { },
  "id_str" : "410508105374371842",
  "text" : "\"Health care exchange is vastly improved, users say.\" \u2014@NYTimes: http:\/\/t.co\/LEkvXUecoi #GetCovered #Obamacare",
  "id" : 410508105374371842,
  "created_at" : "2013-12-10 20:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410503311012683776",
  "text" : "RT @VP: VP announces $100 million will soon be available to increase access to mental health services &amp; improve facilities: http:\/\/t.co\/ZUF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/ZUFSyuRIf9",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/12\/10\/vice-president-biden-announces-100-million-increase-access-mental-health",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "410496036008775680",
    "text" : "VP announces $100 million will soon be available to increase access to mental health services &amp; improve facilities: http:\/\/t.co\/ZUFSyuRIf9",
    "id" : 410496036008775680,
    "created_at" : "2013-12-10 19:47:36 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 410503311012683776,
  "created_at" : "2013-12-10 20:16:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/aZWGTnNEM6",
      "expanded_url" : "http:\/\/go.wh.gov\/8arETC",
      "display_url" : "go.wh.gov\/8arETC"
    } ]
  },
  "geo" : { },
  "id_str" : "410496779960856577",
  "text" : "\"Nelson Mandela reminds us that it always seems impossible until it is done.\" \u2014President Obama in S. Africa. Watch \u2014&gt; http:\/\/t.co\/aZWGTnNEM6",
  "id" : 410496779960856577,
  "created_at" : "2013-12-10 19:50:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410489777306103809\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/ohnTAiRHwG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbJaRxDCcAE5q1F.jpg",
      "id_str" : "410489777314492417",
      "id" : 410489777314492417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbJaRxDCcAE5q1F.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ohnTAiRHwG"
    } ],
    "hashtags" : [ {
      "text" : "InvestInKids",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410489777306103809",
  "text" : "RT if you agree: It's time to give every kid in America access to high-quality early education. #InvestInKids, http:\/\/t.co\/ohnTAiRHwG",
  "id" : 410489777306103809,
  "created_at" : "2013-12-10 19:22:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410488158027923456",
  "text" : "RT @Simas44: \u201CIt was a great experience\u201D she said. \u201CThe site was running very smoothly. It took about 30 minutes tops\u201D #GetCovered http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Mi0LFrm5BH",
        "expanded_url" : "http:\/\/nyti.ms\/1f4pYbN",
        "display_url" : "nyti.ms\/1f4pYbN"
      } ]
    },
    "geo" : { },
    "id_str" : "410447139341209600",
    "text" : "\u201CIt was a great experience\u201D she said. \u201CThe site was running very smoothly. It took about 30 minutes tops\u201D #GetCovered http:\/\/t.co\/Mi0LFrm5BH",
    "id" : 410447139341209600,
    "created_at" : "2013-12-10 16:33:18 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 410488158027923456,
  "created_at" : "2013-12-10 19:16:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "indices" : [ 3, 14 ],
      "id_str" : "17494010",
      "id" : 17494010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 74, 78 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410481224310738944",
  "text" : "RT @SenSchumer: Each year, 1 in 5 Americans experiences a mental illness. #ACA covers them. #GetCovered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 58, 62 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 76, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410461597786587137",
    "text" : "Each year, 1 in 5 Americans experiences a mental illness. #ACA covers them. #GetCovered",
    "id" : 410461597786587137,
    "created_at" : "2013-12-10 17:30:45 +0000",
    "user" : {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "protected" : false,
      "id_str" : "17494010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623955176131575808\/zWzgRP4C_normal.jpg",
      "id" : 17494010,
      "verified" : true
    }
  },
  "id" : 410481224310738944,
  "created_at" : "2013-12-10 18:48:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410476648719319040",
  "text" : "Starting Jan 1st, insurers won't be able to deny coverage or charge more due to pre-existing conditions\u2014including mental illness. #Obamacare",
  "id" : 410476648719319040,
  "created_at" : "2013-12-10 18:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410469099563544578",
  "text" : "FACT: Thanks to #Obamacare, insurers are required to cover mental health services among 10 categories of essential health benefits.",
  "id" : 410469099563544578,
  "created_at" : "2013-12-10 18:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410463857732116481\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Srz8TjRb8S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbJCtArCAAEaLV3.jpg",
      "id_str" : "410463857086169089",
      "id" : 410463857086169089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbJCtArCAAEaLV3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/Srz8TjRb8S"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410463857732116481",
  "text" : "Thanks to the Affordable Care Act, 60 million Americans have access to expanded mental health benefits. #Obamacare, http:\/\/t.co\/Srz8TjRb8S",
  "id" : 410463857732116481,
  "created_at" : "2013-12-10 17:39:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410459022802685952",
  "text" : "Obama on Mandela: \"South Africa shows we can change, that we can choose a world defined not by our differences, but by our common hopes.\"",
  "id" : 410459022802685952,
  "created_at" : "2013-12-10 17:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410454641525006336",
  "text" : "\"Nelson Mandela reminds us that it always seems impossible until it is done.\" \u2014President Obama in South Africa",
  "id" : 410454641525006336,
  "created_at" : "2013-12-10 17:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410448667397484545",
  "text" : "President Obama: \"It took a man like Madiba to free not just the prisoner, but the jailer as well.\"",
  "id" : 410448667397484545,
  "created_at" : "2013-12-10 16:39:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410441405379518465",
  "text" : "President Obama: \"A boy raised herding cattle...Madiba would emerge as the last great liberator of the 20th century.",
  "id" : 410441405379518465,
  "created_at" : "2013-12-10 16:10:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410437934236459008",
  "text" : "Obama on Mandela: \"His struggle was your struggle. His triumph was your triumph...&amp; your freedom, your democracy is his cherished legacy.\"",
  "id" : 410437934236459008,
  "created_at" : "2013-12-10 15:56:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410434314883452928",
  "text" : "\"To the people of South Africa\u2014people of every race &amp; walk of life\u2014the world thanks you for sharing Nelson Mandela with us\" \u2014President Obama",
  "id" : 410434314883452928,
  "created_at" : "2013-12-10 15:42:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/N5Vx7LhXkS",
      "expanded_url" : "http:\/\/go.wh.gov\/VMrpED",
      "display_url" : "go.wh.gov\/VMrpED"
    } ]
  },
  "geo" : { },
  "id_str" : "410432533231190016",
  "text" : "Read President Obama's full remarks at today's memorial service for Nelson Mandela in South Africa \u2014&gt; http:\/\/t.co\/N5Vx7LhXkS",
  "id" : 410432533231190016,
  "created_at" : "2013-12-10 15:35:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/lDECqkY3di",
      "expanded_url" : "http:\/\/go.wh.gov\/yeb33S",
      "display_url" : "go.wh.gov\/yeb33S"
    } ]
  },
  "geo" : { },
  "id_str" : "410333198757801985",
  "text" : "Starting now: President Obama takes part in the memorial service for Nelson Mandela. Watch \u2014&gt; http:\/\/t.co\/lDECqkY3di",
  "id" : 410333198757801985,
  "created_at" : "2013-12-10 09:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Dq8Me0DS4P",
      "expanded_url" : "http:\/\/go.wh.gov\/rJRoye",
      "display_url" : "go.wh.gov\/rJRoye"
    } ]
  },
  "geo" : { },
  "id_str" : "410235051083702274",
  "text" : "At 4am ET, President Obama takes part in the memorial service for Former South African President Nelson Mandela \u2014&gt; http:\/\/t.co\/Dq8Me0DS4P",
  "id" : 410235051083702274,
  "created_at" : "2013-12-10 02:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "General Motors",
      "screen_name" : "GM",
      "indices" : [ 62, 65 ],
      "id_str" : "10850192",
      "id" : 10850192
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410207399706783745\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/KmGRw8eHQH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbFZdOACYAArK_f.jpg",
      "id_str" : "410207399576756224",
      "id" : 410207399576756224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbFZdOACYAArK_f.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KmGRw8eHQH"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410207399706783745",
  "text" : "In 2009, President Obama bet on American auto workers.\nToday, @GM finished paying that bet back.\n#MadeInAmerica, http:\/\/t.co\/KmGRw8eHQH",
  "id" : 410207399706783745,
  "created_at" : "2013-12-10 00:40:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410203182438969344\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/pjqgdcj9AO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbFVnv-CcAAGhLi.jpg",
      "id_str" : "410203182447357952",
      "id" : 410203182447357952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbFVnv-CcAAGhLi.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/pjqgdcj9AO"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Dc3lQZIdUD",
      "expanded_url" : "http:\/\/go.wh.gov\/bare8d",
      "display_url" : "go.wh.gov\/bare8d"
    } ]
  },
  "geo" : { },
  "id_str" : "410203182438969344",
  "text" : "Calling all student filmmakers: Submit your 3-minute film for the first-ever #WHFilmFest \u2014&gt; http:\/\/t.co\/Dc3lQZIdUD, http:\/\/t.co\/pjqgdcj9AO",
  "id" : 410203182438969344,
  "created_at" : "2013-12-10 00:23:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "GlacierNationalPark",
      "screen_name" : "GlacierNPS",
      "indices" : [ 114, 125 ],
      "id_str" : "32887168",
      "id" : 32887168
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "snow",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410194214681849856",
  "text" : "RT @Interior: Who's ready to enjoy #snow on America's public lands? Here's a cool snow pic: crossing the snowpack @GlacierNPS. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GlacierNationalPark",
        "screen_name" : "GlacierNPS",
        "indices" : [ 100, 111 ],
        "id_str" : "32887168",
        "id" : 32887168
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/410096519170502656\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/jESzwu85R9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbD0nHsIUAI5Ssa.jpg",
        "id_str" : "410096519006932994",
        "id" : 410096519006932994,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbD0nHsIUAI5Ssa.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jESzwu85R9"
      } ],
      "hashtags" : [ {
        "text" : "snow",
        "indices" : [ 21, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410096519170502656",
    "text" : "Who's ready to enjoy #snow on America's public lands? Here's a cool snow pic: crossing the snowpack @GlacierNPS. http:\/\/t.co\/jESzwu85R9",
    "id" : 410096519170502656,
    "created_at" : "2013-12-09 17:20:04 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 410194214681849856,
  "created_at" : "2013-12-09 23:48:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "General Motors",
      "screen_name" : "GM",
      "indices" : [ 91, 94 ],
      "id_str" : "10850192",
      "id" : 10850192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/VZIdj2U63o",
      "expanded_url" : "http:\/\/go.wh.gov\/1GZvTb",
      "display_url" : "go.wh.gov\/1GZvTb"
    } ]
  },
  "geo" : { },
  "id_str" : "410184110770892800",
  "text" : "\"I refused to walk away from American workers &amp; an iconic American industry\" \u2014Obama on @GM repaying its rescue loans: http:\/\/t.co\/VZIdj2U63o",
  "id" : 410184110770892800,
  "created_at" : "2013-12-09 23:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Lewis",
      "screen_name" : "KLewis44",
      "indices" : [ 3, 12 ],
      "id_str" : "1639207880",
      "id" : 1639207880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410169398675398656",
  "text" : "RT @KLewis44: Fact: 95% of eligible Af-Ams could have access to tools that would lower costs if all states expand Medicaid. --&gt;http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/r2oXUFsXx1",
        "expanded_url" : "http:\/\/aspe.hhs.gov\/health\/reports\/2013\/UninsuredAfricanAmericans\/ib_UninsuredAfricanAmericans.cfm",
        "display_url" : "aspe.hhs.gov\/health\/reports\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "410112660428976128",
    "text" : "Fact: 95% of eligible Af-Ams could have access to tools that would lower costs if all states expand Medicaid. --&gt;http:\/\/t.co\/r2oXUFsXx1",
    "id" : 410112660428976128,
    "created_at" : "2013-12-09 18:24:12 +0000",
    "user" : {
      "name" : "Kevin Lewis",
      "screen_name" : "KLewis44",
      "protected" : false,
      "id_str" : "1639207880",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711839771438354432\/NXZNoswc_normal.jpg",
      "id" : 1639207880,
      "verified" : true
    }
  },
  "id" : 410169398675398656,
  "created_at" : "2013-12-09 22:09:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410157536113741824\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/35vIQcTsno",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbEsGyKCUAAAKxY.jpg",
      "id_str" : "410157536122130432",
      "id" : 410157536122130432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbEsGyKCUAAAKxY.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/35vIQcTsno"
    } ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 50, 69 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410157536113741824",
  "text" : "RT if you agree: It's time for every state to put #PeopleOverPolitics &amp; help 5.4 million more Americans #GetCovered. http:\/\/t.co\/35vIQcTsno",
  "id" : 410157536113741824,
  "created_at" : "2013-12-09 21:22:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSEdWeek",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/KYWxvYkQJQ",
      "expanded_url" : "http:\/\/wh.gov\/lqO",
      "display_url" : "wh.gov\/lqO"
    }, {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/SmqeoN2tyL",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=yE6IfCrqg3s",
      "display_url" : "youtube.com\/watch?v=yE6IfC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410139381719371776",
  "text" : "RT @whitehouseostp: Pres. Obama: \"Don\u2019t Just Play on Your Phone, Program It\u201D --&gt; http:\/\/t.co\/KYWxvYkQJQ http:\/\/t.co\/SmqeoN2tyL #CSEdWeek #S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CSEdWeek",
        "indices" : [ 110, 119 ]
      }, {
        "text" : "STEM",
        "indices" : [ 120, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/KYWxvYkQJQ",
        "expanded_url" : "http:\/\/wh.gov\/lqO",
        "display_url" : "wh.gov\/lqO"
      }, {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/SmqeoN2tyL",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=yE6IfCrqg3s",
        "display_url" : "youtube.com\/watch?v=yE6IfC\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "410055082936254464",
    "text" : "Pres. Obama: \"Don\u2019t Just Play on Your Phone, Program It\u201D --&gt; http:\/\/t.co\/KYWxvYkQJQ http:\/\/t.co\/SmqeoN2tyL #CSEdWeek #STEM",
    "id" : 410055082936254464,
    "created_at" : "2013-12-09 14:35:24 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 410139381719371776,
  "created_at" : "2013-12-09 20:10:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410125522258366464\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/V7pVoGEvsI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbEO_UXIMAEwFz0.jpg",
      "id_str" : "410125522027687937",
      "id" : 410125522027687937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbEO_UXIMAEwFz0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/V7pVoGEvsI"
    } ],
    "hashtags" : [ {
      "text" : "WHHoliday",
      "indices" : [ 22, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/hki7UV50Vu",
      "expanded_url" : "http:\/\/wh.gov\/social-apply",
      "display_url" : "wh.gov\/social-apply"
    } ]
  },
  "geo" : { },
  "id_str" : "410125522258366464",
  "text" : "You're invited to the #WHHoliday Social! Apply for your chance to tour the decorations: http:\/\/t.co\/hki7UV50Vu, http:\/\/t.co\/V7pVoGEvsI",
  "id" : 410125522258366464,
  "created_at" : "2013-12-09 19:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/410109725485707264\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/mREwLP5I7a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbEAn1rCMAAe-_I.jpg",
      "id_str" : "410109725489901568",
      "id" : 410109725489901568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbEAn1rCMAAe-_I.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1359,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mREwLP5I7a"
    } ],
    "hashtags" : [ {
      "text" : "woof",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410120822389739521",
  "text" : "RT @StateDept: Back at Main State after another trip - my new sidekick Ben tests the elevator. #woof \u2013JK http:\/\/t.co\/mREwLP5I7a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/410109725485707264\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/mREwLP5I7a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbEAn1rCMAAe-_I.jpg",
        "id_str" : "410109725489901568",
        "id" : 410109725489901568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbEAn1rCMAAe-_I.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1359,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mREwLP5I7a"
      } ],
      "hashtags" : [ {
        "text" : "woof",
        "indices" : [ 80, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "410109725485707264",
    "text" : "Back at Main State after another trip - my new sidekick Ben tests the elevator. #woof \u2013JK http:\/\/t.co\/mREwLP5I7a",
    "id" : 410109725485707264,
    "created_at" : "2013-12-09 18:12:32 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 410120822389739521,
  "created_at" : "2013-12-09 18:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 32, 51 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/tqjrfO8D7J",
      "expanded_url" : "http:\/\/go.wh.gov\/Axf1HZ",
      "display_url" : "go.wh.gov\/Axf1HZ"
    } ]
  },
  "geo" : { },
  "id_str" : "410114253098876929",
  "text" : "It's time for the NC GOP to put #PeopleOverPolitics and help nearly 400,000 #GetCovered by expanding Medicaid: http:\/\/t.co\/tqjrfO8D7J",
  "id" : 410114253098876929,
  "created_at" : "2013-12-09 18:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 86, 96 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/33kTXzgB1D",
      "expanded_url" : "http:\/\/go.wh.gov\/Y57gYA",
      "display_url" : "go.wh.gov\/Y57gYA"
    } ]
  },
  "geo" : { },
  "id_str" : "410106706467635201",
  "text" : "The FL GOP is preventing nearly 1 million people from getting health coverage through #Obamacare: http:\/\/t.co\/33kTXzgB1D #PeopleOverPolitics",
  "id" : 410106706467635201,
  "created_at" : "2013-12-09 18:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 27, 46 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410101668017995776",
  "text" : "FACT: If the Texas GOP put #PeopleOverPolitics and expanded Medicaid, 1.2 million more Texans could get health insurance. #Obamacare",
  "id" : 410101668017995776,
  "created_at" : "2013-12-09 17:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 31, 50 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/SWbHhdmGm0",
      "expanded_url" : "http:\/\/go.wh.gov\/4rGHgs",
      "display_url" : "go.wh.gov\/4rGHgs"
    } ]
  },
  "geo" : { },
  "id_str" : "410095376708825092",
  "text" : "If the remaining 24 states put #PeopleOverPolitics &amp; expanded Medicaid, 5.4 million more Americans could #GetCovered: http:\/\/t.co\/SWbHhdmGm0",
  "id" : 410095376708825092,
  "created_at" : "2013-12-09 17:15:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/410089257483509760\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/q8uLLt4Iaj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbDuAccCIAA-lS0.jpg",
      "id_str" : "410089257491898368",
      "id" : 410089257491898368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbDuAccCIAA-lS0.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/q8uLLt4Iaj"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410089257483509760",
  "text" : "Thanks to #Obamacare, nearly 4.6 million Americans can get health coverage in states that expanded Medicaid. http:\/\/t.co\/q8uLLt4Iaj",
  "id" : 410089257483509760,
  "created_at" : "2013-12-09 16:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "Erin44",
      "indices" : [ 3, 10 ],
      "id_str" : "41044637",
      "id" : 41044637
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 16, 25 ],
      "id_str" : "5695632",
      "id" : 5695632
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 52, 63 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ZHlWsfOHXL",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/hnigatu\/the-45-best-tumblrs-of-2013",
      "display_url" : "buzzfeed.com\/hnigatu\/the-45\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "410061661924782080",
  "text" : "RT @Erin44: Hey @BuzzFeed, thanks for including the @WhiteHouse in your \"45 Best Tumblrs of 2013.\" http:\/\/t.co\/ZHlWsfOHXL\nFollow: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BuzzFeed",
        "screen_name" : "BuzzFeed",
        "indices" : [ 4, 13 ],
        "id_str" : "5695632",
        "id" : 5695632
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 40, 51 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/ZHlWsfOHXL",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/hnigatu\/the-45-best-tumblrs-of-2013",
        "display_url" : "buzzfeed.com\/hnigatu\/the-45\u2026"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xPl1qaEPEo",
        "expanded_url" : "http:\/\/whitehouse.tumblr.com\/",
        "display_url" : "whitehouse.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "409867563691028480",
    "text" : "Hey @BuzzFeed, thanks for including the @WhiteHouse in your \"45 Best Tumblrs of 2013.\" http:\/\/t.co\/ZHlWsfOHXL\nFollow: http:\/\/t.co\/xPl1qaEPEo",
    "id" : 409867563691028480,
    "created_at" : "2013-12-09 02:10:16 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 410061661924782080,
  "created_at" : "2013-12-09 15:01:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/GSKTF3sjKn",
      "expanded_url" : "http:\/\/go.wh.gov\/qEFugv",
      "display_url" : "go.wh.gov\/qEFugv"
    } ]
  },
  "geo" : { },
  "id_str" : "409877689080623106",
  "text" : "\"For 91 years, the National Christmas Tree has stood as a beacon of light and promise.\" \u2014President Obama  http:\/\/t.co\/GSKTF3sjKn",
  "id" : 409877689080623106,
  "created_at" : "2013-12-09 02:50:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/409864731449507840\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ja04WNPgEC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BbAhzSuCMAEhTLE.jpg",
      "id_str" : "409864731172679681",
      "id" : 409864731172679681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbAhzSuCMAEhTLE.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ja04WNPgEC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409864731449507840",
  "text" : "\"We are so glad to be part of this wonderful holiday tradition\" \u2014Obama at the lighting of the National Christmas Tree http:\/\/t.co\/ja04WNPgEC",
  "id" : 409864731449507840,
  "created_at" : "2013-12-09 01:59:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Ik1xTmQVZw",
      "expanded_url" : "http:\/\/go.wh.gov\/P7e4cC",
      "display_url" : "go.wh.gov\/P7e4cC"
    } ]
  },
  "geo" : { },
  "id_str" : "409795523231494144",
  "text" : "Starting at 5:20 ET: President Obama speaks at the Kennedy Center Honors Reception. Watch \u2014&gt; http:\/\/t.co\/Ik1xTmQVZw",
  "id" : 409795523231494144,
  "created_at" : "2013-12-08 21:24:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/K9JYtmJOud",
      "expanded_url" : "http:\/\/go.wh.gov\/8bGJAZ",
      "display_url" : "go.wh.gov\/8bGJAZ"
    } ]
  },
  "geo" : { },
  "id_str" : "409744810904256512",
  "text" : "\"It can be the difference between hardship &amp; catastrophe\" \u2014Obama on extending unemployment insurance: http:\/\/t.co\/K9JYtmJOud #ABetterBargain",
  "id" : 409744810904256512,
  "created_at" : "2013-12-08 18:02:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Wmw8e6tJYX",
      "expanded_url" : "http:\/\/go.wh.gov\/s4dTgc",
      "display_url" : "go.wh.gov\/s4dTgc"
    } ]
  },
  "geo" : { },
  "id_str" : "409714488577753088",
  "text" : "Obama: \"That\u2019s why...we offer temporary unemployment insurance\u2014so that job-seekers don\u2019t fall into poverty.\" http:\/\/t.co\/Wmw8e6tJYX",
  "id" : 409714488577753088,
  "created_at" : "2013-12-08 16:02:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/BIQVEeN4GI",
      "expanded_url" : "http:\/\/go.wh.gov\/WnKqZc",
      "display_url" : "go.wh.gov\/WnKqZc"
    } ]
  },
  "geo" : { },
  "id_str" : "409498685022556160",
  "text" : "President Obama on unemployment insurance in 2012: \"It lifted 2.5 million people out of poverty.\" http:\/\/t.co\/BIQVEeN4GI #ABetterBargain",
  "id" : 409498685022556160,
  "created_at" : "2013-12-08 01:44:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/S0IJUPUMuw",
      "expanded_url" : "http:\/\/go.wh.gov\/hYKQqf",
      "display_url" : "go.wh.gov\/hYKQqf"
    } ]
  },
  "geo" : { },
  "id_str" : "409423186195787776",
  "text" : "Obama: \"Our top priority...should be restoring opportunity and broad-based economic growth for all Americans.\" http:\/\/t.co\/S0IJUPUMuw",
  "id" : 409423186195787776,
  "created_at" : "2013-12-07 20:44:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hhynVCZOSa",
      "expanded_url" : "http:\/\/go.wh.gov\/kLbXpg",
      "display_url" : "go.wh.gov\/kLbXpg"
    } ]
  },
  "geo" : { },
  "id_str" : "409362535406526464",
  "text" : "Obama: \"This holiday season\u2014let\u2019s give our fellow Americans who are desperately looking for work the help they need.\" http:\/\/t.co\/hhynVCZOSa",
  "id" : 409362535406526464,
  "created_at" : "2013-12-07 16:43:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/X6X1jFQ5uv",
      "expanded_url" : "http:\/\/go.wh.gov\/xciXuS",
      "display_url" : "go.wh.gov\/xciXuS"
    } ]
  },
  "geo" : { },
  "id_str" : "409327806024134656",
  "text" : "President Obama's Weekly Address: Why Congress needs to extend unemployment insurance \u2014&gt; http:\/\/t.co\/X6X1jFQ5uv #ABetterBargain",
  "id" : 409327806024134656,
  "created_at" : "2013-12-07 14:25:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409100821628854272",
  "text" : "Obama: \"On behalf of Malia, Sasha, Marian, the First Lady...plus Bo &amp; Sunny\u2014I wish all of you a Merry Christmas &amp; a joyful holiday season!\"",
  "id" : 409100821628854272,
  "created_at" : "2013-12-06 23:23:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/409083076493316096\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/SGb72Smhmc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba1a4_pCEAAYv_q.jpg",
      "id_str" : "409083076363292672",
      "id" : 409083076363292672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba1a4_pCEAAYv_q.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SGb72Smhmc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ACklsFkRPc",
      "expanded_url" : "http:\/\/go.wh.gov\/u1kQpg",
      "display_url" : "go.wh.gov\/u1kQpg"
    } ]
  },
  "geo" : { },
  "id_str" : "409083076493316096",
  "text" : "Starting soon: Watch the First Family light the National Christmas Tree \u2014&gt; http:\/\/t.co\/ACklsFkRPc, http:\/\/t.co\/SGb72Smhmc",
  "id" : 409083076493316096,
  "created_at" : "2013-12-06 22:13:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/409070677363130368\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/2GayjIq7ZX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba1PnQ8CUAAFv_L.jpg",
      "id_str" : "409070677140852736",
      "id" : 409070677140852736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba1PnQ8CUAAFv_L.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2GayjIq7ZX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/9TxldQGG2E",
      "expanded_url" : "http:\/\/go.wh.gov\/ehCcBC",
      "display_url" : "go.wh.gov\/ehCcBC"
    } ]
  },
  "geo" : { },
  "id_str" : "409070677363130368",
  "text" : "Don't miss the First Family at the National Christmas Tree lighting! Watch here at 5pm ET \u2014&gt; http:\/\/t.co\/9TxldQGG2E, http:\/\/t.co\/2GayjIq7ZX",
  "id" : 409070677363130368,
  "created_at" : "2013-12-06 21:23:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QD2iDfrIgy",
      "expanded_url" : "http:\/\/go.wh.gov\/CBvuEe",
      "display_url" : "go.wh.gov\/CBvuEe"
    } ]
  },
  "geo" : { },
  "id_str" : "409059994022060032",
  "text" : "RT @FLOTUS: \"All of us can learn important lessons from his struggle.\" \u2014First Lady Michelle Obama on Nelson Mandela: http:\/\/t.co\/QD2iDfrIgy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/QD2iDfrIgy",
        "expanded_url" : "http:\/\/go.wh.gov\/CBvuEe",
        "display_url" : "go.wh.gov\/CBvuEe"
      } ]
    },
    "geo" : { },
    "id_str" : "409051566423805952",
    "text" : "\"All of us can learn important lessons from his struggle.\" \u2014First Lady Michelle Obama on Nelson Mandela: http:\/\/t.co\/QD2iDfrIgy",
    "id" : 409051566423805952,
    "created_at" : "2013-12-06 20:07:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 409059994022060032,
  "created_at" : "2013-12-06 20:41:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Maya Angelou",
      "screen_name" : "DrMayaAngelou",
      "indices" : [ 24, 38 ],
      "id_str" : "146099195",
      "id" : 146099195
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mandela",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/muxmkoRsW8",
      "expanded_url" : "http:\/\/youtu.be\/PqQzjit7b1w",
      "display_url" : "youtu.be\/PqQzjit7b1w"
    } ]
  },
  "geo" : { },
  "id_str" : "409055411560407040",
  "text" : "RT @macon44: Don't miss @DrMayaAngelou's powerful poem about Nelson #Mandela. Watch, reflect &amp; share: http:\/\/t.co\/muxmkoRsW8 #RIPNelsonMand\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maya Angelou",
        "screen_name" : "DrMayaAngelou",
        "indices" : [ 11, 25 ],
        "id_str" : "146099195",
        "id" : 146099195
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mandela",
        "indices" : [ 55, 63 ]
      }, {
        "text" : "RIPNelsonMandela",
        "indices" : [ 116, 133 ]
      }, {
        "text" : "Madiba",
        "indices" : [ 134, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/muxmkoRsW8",
        "expanded_url" : "http:\/\/youtu.be\/PqQzjit7b1w",
        "display_url" : "youtu.be\/PqQzjit7b1w"
      } ]
    },
    "geo" : { },
    "id_str" : "409051894158741504",
    "text" : "Don't miss @DrMayaAngelou's powerful poem about Nelson #Mandela. Watch, reflect &amp; share: http:\/\/t.co\/muxmkoRsW8 #RIPNelsonMandela #Madiba",
    "id" : 409051894158741504,
    "created_at" : "2013-12-06 20:09:06 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 409055411560407040,
  "created_at" : "2013-12-06 20:23:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIPNelsonMandela",
      "indices" : [ 127, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Td3uoq66MV",
      "expanded_url" : "http:\/\/go.wh.gov\/dxDNnC",
      "display_url" : "go.wh.gov\/dxDNnC"
    } ]
  },
  "geo" : { },
  "id_str" : "409048628603281409",
  "text" : "\u201CWe will remember &amp; be glad\nthat you lived among us,\nthat you taught us,\nand that you loved us\u2014all\u201D\nhttp:\/\/t.co\/Td3uoq66MV\n#RIPNelsonMandela",
  "id" : 409048628603281409,
  "created_at" : "2013-12-06 19:56:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/409033138405261312\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/wDBh8DNtNp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba0teN2CQAAOOKt.jpg",
      "id_str" : "409033138296209408",
      "id" : 409033138296209408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba0teN2CQAAOOKt.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/wDBh8DNtNp"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409033138405261312",
  "text" : "Good news: Health care costs are growing at the slowest pace in 50 years. #Obamacare, http:\/\/t.co\/wDBh8DNtNp",
  "id" : 409033138405261312,
  "created_at" : "2013-12-06 18:54:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/RkoQbIbBZZ",
      "expanded_url" : "http:\/\/go.wh.gov\/5B3jpM",
      "display_url" : "go.wh.gov\/5B3jpM"
    } ]
  },
  "geo" : { },
  "id_str" : "409017918207188992",
  "text" : "FACT: Our manufacturers added 27,000 jobs last month\u2014and 554,000 jobs since February 2010. http:\/\/t.co\/RkoQbIbBZZ #MadeInAmerica",
  "id" : 409017918207188992,
  "created_at" : "2013-12-06 17:54:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "indices" : [ 3, 16 ],
      "id_str" : "15442036",
      "id" : 15442036
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "minimumwage",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409012001667825664",
  "text" : "RT @SenatorBoxer: Solid jobs report. Now let\u2019s raise the #minimumwage and make sure our workers don\u2019t live in poverty.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "minimumwage",
        "indices" : [ 39, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408992153390436352",
    "text" : "Solid jobs report. Now let\u2019s raise the #minimumwage and make sure our workers don\u2019t live in poverty.",
    "id" : 408992153390436352,
    "created_at" : "2013-12-06 16:11:42 +0000",
    "user" : {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "protected" : false,
      "id_str" : "15442036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464147946934517760\/EZ8huLG8_normal.png",
      "id" : 15442036,
      "verified" : true
    }
  },
  "id" : 409012001667825664,
  "created_at" : "2013-12-06 17:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 15, 24 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 36, 43 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "409008487335612417",
  "text" : "RT @NSCPress: .@PressSec: POTUS and @FLOTUS will go to S. Africa next week to pay respects to memory of Nelson Mandela &amp; participate in mem\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 1, 10 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 22, 29 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "409000201458683905",
    "text" : ".@PressSec: POTUS and @FLOTUS will go to S. Africa next week to pay respects to memory of Nelson Mandela &amp; participate in memorial events.",
    "id" : 409000201458683905,
    "created_at" : "2013-12-06 16:43:41 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 409008487335612417,
  "created_at" : "2013-12-06 17:16:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408998441063161856",
  "text" : "RT @CEAChair: Solid job growth in Nov but still too many looking for jobs for 27+ wks; why Congress needs to extend emergency UI http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CEAChair\/status\/408990760499806210\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/EXcG00Oa0J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba0G7gSCAAAj5kC.jpg",
        "id_str" : "408990760508194816",
        "id" : 408990760508194816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba0G7gSCAAAj5kC.jpg",
        "sizes" : [ {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 659,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 659,
          "resize" : "fit",
          "w" : 910
        } ],
        "display_url" : "pic.twitter.com\/EXcG00Oa0J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408990760499806210",
    "text" : "Solid job growth in Nov but still too many looking for jobs for 27+ wks; why Congress needs to extend emergency UI http:\/\/t.co\/EXcG00Oa0J",
    "id" : 408990760499806210,
    "created_at" : "2013-12-06 16:06:10 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 408998441063161856,
  "created_at" : "2013-12-06 16:36:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/408993095012073472\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/JwY93YKTxT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba0JDX7IYAAl_BY.jpg",
      "id_str" : "408993094726868992",
      "id" : 408993094726868992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba0JDX7IYAAl_BY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JwY93YKTxT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Iu1fQmFvXj",
      "expanded_url" : "http:\/\/go.wh.gov\/KMEGvR",
      "display_url" : "go.wh.gov\/KMEGvR"
    } ]
  },
  "geo" : { },
  "id_str" : "408993095012073472",
  "text" : "FACT: Our economy continues to add jobs at a pace of more than 2 million per year \u2014&gt; http:\/\/t.co\/Iu1fQmFvXj, http:\/\/t.co\/JwY93YKTxT",
  "id" : 408993095012073472,
  "created_at" : "2013-12-06 16:15:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/408984323132375041\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/kdXUMbvGvK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ba0BEyhCQAABbBa.jpg",
      "id_str" : "408984322952019968",
      "id" : 408984322952019968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ba0BEyhCQAABbBa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kdXUMbvGvK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408984323132375041",
  "text" : "Good news.\nOur economy added:\n1. 196,000 private-sector jobs last month\n2. 8.1 million jobs over 45 straight months http:\/\/t.co\/kdXUMbvGvK",
  "id" : 408984323132375041,
  "created_at" : "2013-12-06 15:40:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/UWNRXTatH0",
      "expanded_url" : "http:\/\/go.wh.gov\/XyrgqD",
      "display_url" : "go.wh.gov\/XyrgqD"
    } ]
  },
  "geo" : { },
  "id_str" : "408796556515491840",
  "text" : "Watch President Obama\u2019s full statement on the passing of Nelson Mandela \u2014&gt; http:\/\/t.co\/UWNRXTatH0",
  "id" : 408796556515491840,
  "created_at" : "2013-12-06 03:14:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408758021800472576",
  "text" : "RT @FLOTUS: We will forever draw strength and inspiration from Nelson Mandela\u2019s extraordinary example of moral courage, kindness, and humil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408757738773049344",
    "text" : "We will forever draw strength and inspiration from Nelson Mandela\u2019s extraordinary example of moral courage, kindness, and humility. \u2013mo",
    "id" : 408757738773049344,
    "created_at" : "2013-12-06 00:40:13 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 408758021800472576,
  "created_at" : "2013-12-06 00:41:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/408734525615640577\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/4qlqsXLp6e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bawd4q8CEAEZL4v.jpg",
      "id_str" : "408734525619834881",
      "id" : 408734525619834881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bawd4q8CEAEZL4v.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4qlqsXLp6e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408734525615640577",
  "text" : "Rest in peace, Nelson Mandela. http:\/\/t.co\/4qlqsXLp6e",
  "id" : 408734525615640577,
  "created_at" : "2013-12-05 23:07:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408725341696315392",
  "text" : "President Obama on Nelson Mandela: \"A man who took history in his hands, and bent the arc of the moral universe toward justice.\"",
  "id" : 408725341696315392,
  "created_at" : "2013-12-05 22:31:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408725036342583296",
  "text" : "President Obama: \"We will not see the likes of Nelson Mandela again. It falls to us to carry forward the example that he set.\"",
  "id" : 408725036342583296,
  "created_at" : "2013-12-05 22:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724940829892608",
  "text" : "President Obama: \"A free South Africa at peace with itself, an example to the world \u2013 that is Madiba\u2019s legacy to the nation he loved.\"",
  "id" : 408724940829892608,
  "created_at" : "2013-12-05 22:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724768787939331",
  "text" : "RT @WHLive: President Obama: \"Like so many around the globe, I cannot fully imagine my own life without the example set by Nelson Mandela.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408724658351906816",
    "text" : "President Obama: \"Like so many around the globe, I cannot fully imagine my own life without the example set by Nelson Mandela.\"",
    "id" : 408724658351906816,
    "created_at" : "2013-12-05 22:28:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408724768787939331,
  "created_at" : "2013-12-05 22:29:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724581390626816",
  "text" : "Obama: \"The day...he was released from prison gave me a sense of what human beings can do when...guided by their hopes rather than...fears\"",
  "id" : 408724581390626816,
  "created_at" : "2013-12-05 22:28:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724561601916928",
  "text" : "RT @WHLive: President Obama on Nelson Mandela: \"My first political action was a protest against apartheid. I studied his words and his writ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408724481411006464",
    "text" : "President Obama on Nelson Mandela: \"My first political action was a protest against apartheid. I studied his words and his writings.\"",
    "id" : 408724481411006464,
    "created_at" : "2013-12-05 22:28:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408724561601916928,
  "created_at" : "2013-12-05 22:28:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724413828194304",
  "text" : "President Obama: \"I am one of the countless millions who drew inspiration from Nelson Mandela's life.\"",
  "id" : 408724413828194304,
  "created_at" : "2013-12-05 22:27:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724374309466112",
  "text" : "Obama on Mandela: \"His commitment to transfer power &amp; reconcile with those who jailed him set an example that all humanity should aspire to\"",
  "id" : 408724374309466112,
  "created_at" : "2013-12-05 22:27:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724329128394752",
  "text" : "Obama on Mandela: \"His journey from a prisoner to a President embodied the promise that human beings\u2014&amp; countries\u2014can change for the better.\"",
  "id" : 408724329128394752,
  "created_at" : "2013-12-05 22:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724280608694272",
  "text" : "RT @WHLive: Obama: \"Through his fierce dignity &amp; unbending will to sacrifice his own freedom for the freedom of others\u2014Madiba transformed S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408724210450587648",
    "text" : "Obama: \"Through his fierce dignity &amp; unbending will to sacrifice his own freedom for the freedom of others\u2014Madiba transformed South Africa.\"",
    "id" : 408724210450587648,
    "created_at" : "2013-12-05 22:27:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408724280608694272,
  "created_at" : "2013-12-05 22:27:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724146588098560",
  "text" : "\"He no longer belongs to us\u2014he belongs to the ages.\" \u2014President Obama on Nelson Mandela",
  "id" : 408724146588098560,
  "created_at" : "2013-12-05 22:26:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724098231988224",
  "text" : "Obama on Mandela: \"We have lost one of the most influential, courageous &amp; profoundly good human beings that any of us will share time with.\"",
  "id" : 408724098231988224,
  "created_at" : "2013-12-05 22:26:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408724030741438464",
  "text" : "Nelson Mandela \"achieved more than could be expected of any man.\" \u2014President Obama",
  "id" : 408724030741438464,
  "created_at" : "2013-12-05 22:26:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/WvvrcdHqMc",
      "expanded_url" : "http:\/\/go.wh.gov\/Ux8AEx",
      "display_url" : "go.wh.gov\/Ux8AEx"
    } ]
  },
  "geo" : { },
  "id_str" : "408723979117928448",
  "text" : "Watch now: President Obama delivers a statement on the passing of Nelson Mandela \u2014&gt; http:\/\/t.co\/WvvrcdHqMc",
  "id" : 408723979117928448,
  "created_at" : "2013-12-05 22:26:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/hkR254IvbZ",
      "expanded_url" : "http:\/\/go.wh.gov\/8HtaRt",
      "display_url" : "go.wh.gov\/8HtaRt"
    } ]
  },
  "geo" : { },
  "id_str" : "408719060474408960",
  "text" : "At 5:20pm ET, President Obama will deliver a statement on the passing of Nelson Mandela. Watch \u2014&gt; http:\/\/t.co\/hkR254IvbZ",
  "id" : 408719060474408960,
  "created_at" : "2013-12-05 22:06:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/408710344542928896\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Te7fDKXq9b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BawH5JICUAAc4pj.jpg",
      "id_str" : "408710344467435520",
      "id" : 408710344467435520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BawH5JICUAAc4pj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Te7fDKXq9b"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408710344542928896",
  "text" : "Starting in Jan, insurers can't deny you coverage or charge you more for a pre-existing condition. #Obamacare, http:\/\/t.co\/Te7fDKXq9b",
  "id" : 408710344542928896,
  "created_at" : "2013-12-05 21:31:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgivukkah",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408708053765066752",
  "text" : "RT @WHLive: Obama: \"The 1st day of Hanukkah &amp; Thanksgiving won\u2019t overlap again for more than 70,000 years.\" #Thanksgivukkah",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Thanksgivukkah",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408707948911673344",
    "text" : "Obama: \"The 1st day of Hanukkah &amp; Thanksgiving won\u2019t overlap again for more than 70,000 years.\" #Thanksgivukkah",
    "id" : 408707948911673344,
    "created_at" : "2013-12-05 21:22:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408708053765066752,
  "created_at" : "2013-12-05 21:22:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hanukkah",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/rDIK3VWvuJ",
      "expanded_url" : "http:\/\/go.wh.gov\/6nhxSw",
      "display_url" : "go.wh.gov\/6nhxSw"
    } ]
  },
  "geo" : { },
  "id_str" : "408705834391068672",
  "text" : "Right now: President Obama and the First Lady host a #Hanukkah reception at the White House. Watch: http:\/\/t.co\/rDIK3VWvuJ",
  "id" : 408705834391068672,
  "created_at" : "2013-12-05 21:13:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "indices" : [ 3, 14 ],
      "id_str" : "20655674",
      "id" : 20655674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408692645603860480",
  "text" : "RT @ACAstories: TX: 27yo Micheal Biggerstaff was \"thrilled\" abt his ACA options, decided on $29\/mo plan w\/ lower deductibles &amp; copays http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/I5MZdTTtF5",
        "expanded_url" : "http:\/\/www.khou.com\/news\/national\/234325241.html",
        "display_url" : "khou.com\/news\/national\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408651085776031744",
    "text" : "TX: 27yo Micheal Biggerstaff was \"thrilled\" abt his ACA options, decided on $29\/mo plan w\/ lower deductibles &amp; copays http:\/\/t.co\/I5MZdTTtF5",
    "id" : 408651085776031744,
    "created_at" : "2013-12-05 17:36:25 +0000",
    "user" : {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "protected" : false,
      "id_str" : "20655674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442325097731223552\/qhUhX6DV_normal.png",
      "id" : 20655674,
      "verified" : false
    }
  },
  "id" : 408692645603860480,
  "created_at" : "2013-12-05 20:21:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "indices" : [ 3, 11 ],
      "id_str" : "1881128166",
      "id" : 1881128166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Texas",
      "indices" : [ 16, 22 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408683920742694912",
  "text" : "RT @Maley44: In #Texas,10.6 million people w\/ pre-existing conditions can no longer be denied health insurance coverage thx to #Obamacare #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Texas",
        "indices" : [ 3, 9 ]
      }, {
        "text" : "Obamacare",
        "indices" : [ 114, 124 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408676937184190464",
    "text" : "In #Texas,10.6 million people w\/ pre-existing conditions can no longer be denied health insurance coverage thx to #Obamacare #GetCovered",
    "id" : 408676937184190464,
    "created_at" : "2013-12-05 19:19:09 +0000",
    "user" : {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "protected" : false,
      "id_str" : "1881128166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725086933961957376\/v5WvYCOW_normal.jpg",
      "id" : 1881128166,
      "verified" : true
    }
  },
  "id" : 408683920742694912,
  "created_at" : "2013-12-05 19:46:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 83, 93 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ICA4eRb1P5",
      "expanded_url" : "http:\/\/go.wh.gov\/C1WuTh",
      "display_url" : "go.wh.gov\/C1WuTh"
    } ]
  },
  "geo" : { },
  "id_str" : "408672164888334336",
  "text" : "Insurers denied Odessa coverage 3 times due to a pre-existing condition. Thanks to #Obamacare, she can #GetCovered: http:\/\/t.co\/ICA4eRb1P5",
  "id" : 408672164888334336,
  "created_at" : "2013-12-05 19:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/84vP3pRhty",
      "expanded_url" : "http:\/\/go.wh.gov\/cPCq2j",
      "display_url" : "go.wh.gov\/cPCq2j"
    } ]
  },
  "geo" : { },
  "id_str" : "408656411548065792",
  "text" : "\u201CIt shouldn\u2019t have happened to me\u2014but it did\u201D \u2014Michael on how #Obamacare helps millions of cancer survivors like him: http:\/\/t.co\/84vP3pRhty",
  "id" : 408656411548065792,
  "created_at" : "2013-12-05 17:57:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408644437565116416",
  "text" : "Nearly 1 in 2 Americans has a pre-existing condition. Starting Jan 1, they:\n1. Can\u2019t be denied coverage\n2. Can\u2019t be charged more\n#Obamacare",
  "id" : 408644437565116416,
  "created_at" : "2013-12-05 17:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/408634324183838720\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ZEAXaNGInn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BavCwLECAAAJss2.jpg",
      "id_str" : "408634324066369536",
      "id" : 408634324066369536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BavCwLECAAAJss2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ZEAXaNGInn"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408634324183838720",
  "text" : "Thanks to #Obamacare, up to 129 million Americans with pre-existing conditions can no longer be denied coverage. http:\/\/t.co\/ZEAXaNGInn",
  "id" : 408634324183838720,
  "created_at" : "2013-12-05 16:29:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 19, 27 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/2jOz7DEz7Z",
      "expanded_url" : "http:\/\/nyti.ms\/1eQTqlt",
      "display_url" : "nyti.ms\/1eQTqlt"
    } ]
  },
  "geo" : { },
  "id_str" : "408630701315997698",
  "text" : "Worth sharing: The @NYTimes on how President Obama is fighting to give more Americans a chance to succeed \u2014&gt; http:\/\/t.co\/2jOz7DEz7Z",
  "id" : 408630701315997698,
  "created_at" : "2013-12-05 16:15:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 133, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/oJ73908mjh",
      "expanded_url" : "http:\/\/go.wh.gov\/r9brUp",
      "display_url" : "go.wh.gov\/r9brUp"
    } ]
  },
  "geo" : { },
  "id_str" : "408622625418534913",
  "text" : "If Congress doesn\u2019t act, 1.3 million Americans will lose unemployment benefits at the end of this month \u2014&gt; http:\/\/t.co\/oJ73908mjh #JustVote",
  "id" : 408622625418534913,
  "created_at" : "2013-12-05 15:43:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/vQ74UBBs7F",
      "expanded_url" : "http:\/\/HC.gov",
      "display_url" : "HC.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "408613741761396736",
  "text" : "RT @HealthCareGov: More than 820k visits to http:\/\/t.co\/vQ74UBBs7F yesterday. Site stable. Supporting lots seeking affordable health care.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/vQ74UBBs7F",
        "expanded_url" : "http:\/\/HC.gov",
        "display_url" : "HC.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "408588173493547008",
    "text" : "More than 820k visits to http:\/\/t.co\/vQ74UBBs7F yesterday. Site stable. Supporting lots seeking affordable health care.",
    "id" : 408588173493547008,
    "created_at" : "2013-12-05 13:26:26 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 408613741761396736,
  "created_at" : "2013-12-05 15:08:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/408400477429436417\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/c0HLhhRH1w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaruEfuIgAA6Tfw.jpg",
      "id_str" : "408400477232332800",
      "id" : 408400477232332800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaruEfuIgAA6Tfw.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/c0HLhhRH1w"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408400477429436417",
  "text" : "Every hardworking kid in America deserves the chance to succeed. #ABetterBargain, http:\/\/t.co\/c0HLhhRH1w",
  "id" : 408400477429436417,
  "created_at" : "2013-12-05 01:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaisetheWage",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/mrGhG0lAxq",
      "expanded_url" : "http:\/\/huff.to\/1kckv3K",
      "display_url" : "huff.to\/1kckv3K"
    } ]
  },
  "geo" : { },
  "id_str" : "408395712896856064",
  "text" : "RT @LaborSec: It's time to raise the minimum wage. http:\/\/t.co\/mrGhG0lAxq #RaisetheWage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaisetheWage",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/mrGhG0lAxq",
        "expanded_url" : "http:\/\/huff.to\/1kckv3K",
        "display_url" : "huff.to\/1kckv3K"
      } ]
    },
    "geo" : { },
    "id_str" : "408395358436593664",
    "text" : "It's time to raise the minimum wage. http:\/\/t.co\/mrGhG0lAxq #RaisetheWage",
    "id" : 408395358436593664,
    "created_at" : "2013-12-05 00:40:15 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 408395712896856064,
  "created_at" : "2013-12-05 00:41:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewUSCitizens",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408390791959035905",
  "text" : "RT @AmbassadorPower: I remember entering this very courthouse an Irish citizen, knowing I'd walk out an American. Congrats #NewUSCitizens! \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmbassadorPower\/status\/408385624136101888\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/tTlcory2eG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bargj7rCMAAS8I8.jpg",
        "id_str" : "408385624148684800",
        "id" : 408385624148684800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bargj7rCMAAS8I8.jpg",
        "sizes" : [ {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 1846
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tTlcory2eG"
      } ],
      "hashtags" : [ {
        "text" : "NewUSCitizens",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408385624136101888",
    "text" : "I remember entering this very courthouse an Irish citizen, knowing I'd walk out an American. Congrats #NewUSCitizens! http:\/\/t.co\/tTlcory2eG",
    "id" : 408385624136101888,
    "created_at" : "2013-12-05 00:01:35 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 408390791959035905,
  "created_at" : "2013-12-05 00:22:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/sKPJTIyWCj",
      "expanded_url" : "http:\/\/wapo.st\/1iAd6jm",
      "display_url" : "wapo.st\/1iAd6jm"
    } ]
  },
  "geo" : { },
  "id_str" : "408385306359242752",
  "text" : "RT @ezraklein: This is the best speech Obama has given on the economy: http:\/\/t.co\/sKPJTIyWCj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/sKPJTIyWCj",
        "expanded_url" : "http:\/\/wapo.st\/1iAd6jm",
        "display_url" : "wapo.st\/1iAd6jm"
      } ]
    },
    "geo" : { },
    "id_str" : "408337822593331201",
    "text" : "This is the best speech Obama has given on the economy: http:\/\/t.co\/sKPJTIyWCj",
    "id" : 408337822593331201,
    "created_at" : "2013-12-04 20:51:38 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 408385306359242752,
  "created_at" : "2013-12-05 00:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "indices" : [ 3, 13 ],
      "id_str" : "1712989040",
      "id" : 1712989040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Charlottesville",
      "indices" : [ 38, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/AHNGD6XnWh",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kVYoHas2-k8",
      "display_url" : "youtube.com\/watch?v=kVYoHa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408383038671040512",
  "text" : "RT @Rosholm44: WATCH Molly -- 23 from #Charlottesville, VA -- tell her enrollment story ---&gt; http:\/\/t.co\/AHNGD6XnWh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Charlottesville",
        "indices" : [ 23, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/AHNGD6XnWh",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kVYoHas2-k8",
        "display_url" : "youtube.com\/watch?v=kVYoHa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408374222063284224",
    "text" : "WATCH Molly -- 23 from #Charlottesville, VA -- tell her enrollment story ---&gt; http:\/\/t.co\/AHNGD6XnWh",
    "id" : 408374222063284224,
    "created_at" : "2013-12-04 23:16:16 +0000",
    "user" : {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "protected" : false,
      "id_str" : "1712989040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755544708483538944\/h-5gKL6u_normal.jpg",
      "id" : 1712989040,
      "verified" : true
    }
  },
  "id" : 408383038671040512,
  "created_at" : "2013-12-04 23:51:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 88, 98 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/OjsiwMHMTV",
      "expanded_url" : "http:\/\/go.wh.gov\/hkP6CV",
      "display_url" : "go.wh.gov\/hkP6CV"
    } ]
  },
  "geo" : { },
  "id_str" : "408377772440944640",
  "text" : "Carissa from WA couldn't afford health coverage.\nNow she qualifies for Medicaid through #Obamacare \u2014&gt;\nhttp:\/\/t.co\/OjsiwMHMTV #GetCovered",
  "id" : 408377772440944640,
  "created_at" : "2013-12-04 23:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 3, 15 ],
      "id_str" : "17004618",
      "id" : 17004618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/icWJ7WIsAL",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/12\/04\/remarks-president-economic-mobility",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "408364920540250112",
  "text" : "RT @NickKristof: Obama's speech today on economic inequality is really excellent. Here's the text: http:\/\/t.co\/icWJ7WIsAL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/icWJ7WIsAL",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/12\/04\/remarks-president-economic-mobility",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "408358523333251072",
    "text" : "Obama's speech today on economic inequality is really excellent. Here's the text: http:\/\/t.co\/icWJ7WIsAL",
    "id" : 408358523333251072,
    "created_at" : "2013-12-04 22:13:53 +0000",
    "user" : {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "protected" : false,
      "id_str" : "17004618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680936862387589120\/DfkrlW27_normal.jpg",
      "id" : 17004618,
      "verified" : true
    }
  },
  "id" : 408364920540250112,
  "created_at" : "2013-12-04 22:39:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/OjsiwMHMTV",
      "expanded_url" : "http:\/\/go.wh.gov\/hkP6CV",
      "display_url" : "go.wh.gov\/hkP6CV"
    } ]
  },
  "geo" : { },
  "id_str" : "408360692593328128",
  "text" : "Thanks to the Affordable Care Act, Deborah from Portsmouth, NH is saving $550\/month on coverage \u2014&gt; http:\/\/t.co\/OjsiwMHMTV #GetCovered",
  "id" : 408360692593328128,
  "created_at" : "2013-12-04 22:22:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 3, 19 ],
      "id_str" : "234141596",
      "id" : 234141596
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 55, 66 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408348291035054080",
  "text" : "RT @GovMalloyOffice: It's time for Congress to work w\/ @WhiteHouse to reduce inequality, build middle class, provide more ladders of opport\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 34, 45 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408342558415142917",
    "text" : "It's time for Congress to work w\/ @WhiteHouse to reduce inequality, build middle class, provide more ladders of opportunity. #ABetterBargain",
    "id" : 408342558415142917,
    "created_at" : "2013-12-04 21:10:27 +0000",
    "user" : {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "protected" : false,
      "id_str" : "234141596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738519424223858688\/_0xQvvKS_normal.jpg",
      "id" : 234141596,
      "verified" : true
    }
  },
  "id" : 408348291035054080,
  "created_at" : "2013-12-04 21:33:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/408340240760184833\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/uk2vQSBZoM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Baq3SRaCIAILEtn.jpg",
      "id_str" : "408340240768573442",
      "id" : 408340240768573442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Baq3SRaCIAILEtn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uk2vQSBZoM"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/OjsiwMHMTV",
      "expanded_url" : "http:\/\/go.wh.gov\/hkP6CV",
      "display_url" : "go.wh.gov\/hkP6CV"
    } ]
  },
  "geo" : { },
  "id_str" : "408340240760184833",
  "text" : "Thanks to the Affordable Care Act, Phil insured his family of 4 for $123\/month: http:\/\/t.co\/OjsiwMHMTV #GetCovered, http:\/\/t.co\/uk2vQSBZoM",
  "id" : 408340240760184833,
  "created_at" : "2013-12-04 21:01:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/408334916548837377\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Tbspo6THDu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaqycVrIIAAK1WC.jpg",
      "id_str" : "408334916154564608",
      "id" : 408334916154564608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaqycVrIIAAK1WC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Tbspo6THDu"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 57, 67 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408334916548837377",
  "text" : "Mary used to be denied coverage due to asthma.\nThanks to #Obamacare, she got affordable insurance.\n#GetCovered, http:\/\/t.co\/Tbspo6THDu",
  "id" : 408334916548837377,
  "created_at" : "2013-12-04 20:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Rq2oJSzuDM",
      "expanded_url" : "http:\/\/go.wh.gov\/3kKLjk",
      "display_url" : "go.wh.gov\/3kKLjk"
    } ]
  },
  "geo" : { },
  "id_str" : "408330009804169218",
  "text" : "More than 500,000 Americans have already signed up for coverage through #Obamacare. Share your story: http:\/\/t.co\/Rq2oJSzuDM #GetCovered",
  "id" : 408330009804169218,
  "created_at" : "2013-12-04 20:20:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/408322576096571392\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6V8QecfF8t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaqnOCyCEAAuVXp.jpg",
      "id_str" : "408322575937179648",
      "id" : 408322575937179648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaqnOCyCEAAuVXp.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/6V8QecfF8t"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408322576096571392",
  "text" : "FACT: Thanks to #Obamacare, 105 million Americans have gained access to free preventive care like cancer screenings. http:\/\/t.co\/6V8QecfF8t",
  "id" : 408322576096571392,
  "created_at" : "2013-12-04 19:51:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 32, 43 ]
    }, {
      "text" : "WHYouthSummit",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408315501366874112",
  "text" : "Obama: \u201CTweet using the hashtag #GetCovered. Do whatever you can to help make sure people have the information they need.\u201D #WHYouthSummit",
  "id" : 408315501366874112,
  "created_at" : "2013-12-04 19:22:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408315226317025280",
  "text" : "\u201CI know people call this law #Obamacare, and that\u2019s ok, because I do care. I care about you.\u201D \u2014President Obama",
  "id" : 408315226317025280,
  "created_at" : "2013-12-04 19:21:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408314436903243776",
  "text" : "RT @WHLive: \"This is 'a big deal', to quote Joe Biden.\" \u2014President Obama on helping millions of Americans get affordable health coverage #O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408314410227478529",
    "text" : "\"This is 'a big deal', to quote Joe Biden.\" \u2014President Obama on helping millions of Americans get affordable health coverage #Obamacare",
    "id" : 408314410227478529,
    "created_at" : "2013-12-04 19:18:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408314436903243776,
  "created_at" : "2013-12-04 19:18:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 131, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408313466907557888",
  "text" : "Obama: \"That\u2019s what this law is about: Health care that\u2019s there when you need it. Financial protection for you &amp; your family.\" #Obamacare",
  "id" : 408313466907557888,
  "created_at" : "2013-12-04 19:14:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHYouthSummit",
      "indices" : [ 68, 82 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Sl66DYXEdY",
      "expanded_url" : "http:\/\/go.wh.gov\/8qopTW",
      "display_url" : "go.wh.gov\/8qopTW"
    } ]
  },
  "geo" : { },
  "id_str" : "408312615241527296",
  "text" : "Right now: President Obama speaks on the Affordable Care Act at the #WHYouthSummit. Watch \u2014&gt; http:\/\/t.co\/Sl66DYXEdY #GetCovered",
  "id" : 408312615241527296,
  "created_at" : "2013-12-04 19:11:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHYouthSummit",
      "indices" : [ 71, 85 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/tUW9FYyO7i",
      "expanded_url" : "http:\/\/go.wh.gov\/8qopTW",
      "display_url" : "go.wh.gov\/8qopTW"
    } ]
  },
  "geo" : { },
  "id_str" : "408309447543365632",
  "text" : "At 2:05pm ET, President Obama speaks on the Affordable Care Act at the #WHYouthSummit. Watch \u2014&gt; http:\/\/t.co\/tUW9FYyO7i #GetCovered",
  "id" : 408309447543365632,
  "created_at" : "2013-12-04 18:58:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/408301702266109952\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FGKEEyol2t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaqUPByCEAAL11Q.jpg",
      "id_str" : "408301702127685632",
      "id" : 408301702127685632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaqUPByCEAAL11Q.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/FGKEEyol2t"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408301702266109952",
  "text" : "Covered thanks to the Affordable Care Act:\n1. Cancer screenings \u2714\n2. Birth control \u2714\n3. Peace of mind \u2714\n#Obamacare, http:\/\/t.co\/FGKEEyol2t",
  "id" : 408301702266109952,
  "created_at" : "2013-12-04 18:28:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHoliday",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/aJ5BRyrUmh",
      "expanded_url" : "http:\/\/wh.gov\/holidays",
      "display_url" : "wh.gov\/holidays"
    } ]
  },
  "geo" : { },
  "id_str" : "408299740824993792",
  "text" : "RT @FLOTUS: Don't miss the First Lady unveil the 2013 @WhiteHouse holiday decorations at 1:30pm ET \u2014&gt; http:\/\/t.co\/aJ5BRyrUmh #WHHoliday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 42, 53 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHoliday",
        "indices" : [ 116, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/aJ5BRyrUmh",
        "expanded_url" : "http:\/\/wh.gov\/holidays",
        "display_url" : "wh.gov\/holidays"
      } ]
    },
    "geo" : { },
    "id_str" : "408299434024640512",
    "text" : "Don't miss the First Lady unveil the 2013 @WhiteHouse holiday decorations at 1:30pm ET \u2014&gt; http:\/\/t.co\/aJ5BRyrUmh #WHHoliday",
    "id" : 408299434024640512,
    "created_at" : "2013-12-04 18:19:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 408299740824993792,
  "created_at" : "2013-12-04 18:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408284892535873537",
  "text" : "Obama: \"If we refocus our energies on building an economy that grows for everybody...I\u2019m confident that the future still looks brighter.\"",
  "id" : 408284892535873537,
  "created_at" : "2013-12-04 17:21:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408284482374873088",
  "text" : "Obama to Congressional Republicans: \"You owe it to the American people to tell us what you are for, not just what you\u2019re against.\"",
  "id" : 408284482374873088,
  "created_at" : "2013-12-04 17:19:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408284071068827648",
  "text" : "Obama: \"As I keep offering my own ideas for expanding opportunity, I\u2019ll also keep challenging those who oppose my ideas to offer their own.\"",
  "id" : 408284071068827648,
  "created_at" : "2013-12-04 17:18:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408283177405267968",
  "text" : "President Obama: \"100 million Americans...gained the right to free preventive care like mammograms and contraception.\" #Obamacare",
  "id" : 408283177405267968,
  "created_at" : "2013-12-04 17:14:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408282617327259648",
  "text" : "Obama: \"Christmas is no time for Congress to tell more than 1 million of these Americans that they\u2019ll lose this insurance.\" #ABetterBargain",
  "id" : 408282617327259648,
  "created_at" : "2013-12-04 17:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408282381376692224",
  "text" : "RT @WHLive: Obama: \"That\u2019s why we have unemployment insurance\u2014because it makes a difference for a father who lost his job and is looking fo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408282294323912704",
    "text" : "Obama: \"That\u2019s why we have unemployment insurance\u2014because it makes a difference for a father who lost his job and is looking for a new one.\"",
    "id" : 408282294323912704,
    "created_at" : "2013-12-04 17:10:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408282381376692224,
  "created_at" : "2013-12-04 17:11:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SNAP",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408282129143828480",
  "text" : "RT @WHLive: Obama on #SNAP: \"It makes a difference for a mother who\u2019s working, but just having a hard time putting food on the table for he\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SNAP",
        "indices" : [ 9, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408282083459866624",
    "text" : "Obama on #SNAP: \"It makes a difference for a mother who\u2019s working, but just having a hard time putting food on the table for her kids.\"",
    "id" : 408282083459866624,
    "created_at" : "2013-12-04 17:10:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408282129143828480,
  "created_at" : "2013-12-04 17:10:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408281382658396160",
  "text" : "Obama: \"I\u2019m going to keep pushing until we get a higher minimum wage for hard-working Americans across the entire country.\" #RaiseTheWage",
  "id" : 408281382658396160,
  "created_at" : "2013-12-04 17:07:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/408280856189362177\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/HCz2K7cTJ7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaqBRoLCcAAM_m3.jpg",
      "id_str" : "408280856071925760",
      "id" : 408280856071925760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaqBRoLCcAAM_m3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HCz2K7cTJ7"
    } ],
    "hashtags" : [ {
      "text" : "ENDA",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408280856189362177",
  "text" : "President Obama: \"It\u2019s time to pass #ENDA, so workers can\u2019t be fired for who they are or who they love.\" http:\/\/t.co\/HCz2K7cTJ7",
  "id" : 408280856189362177,
  "created_at" : "2013-12-04 17:05:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408280541197131778",
  "text" : "Obama: \"It\u2019s time to ensure that unions have a level playing field to organize for a better deal for workers &amp; better wages\" #ABetterBargain",
  "id" : 408280541197131778,
  "created_at" : "2013-12-04 17:04:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408280031551442944",
  "text" : "RT @WHLive: Obama: \"Next week, Michelle &amp; I will bring together college presidents and non-profits...to help more low-income students atten\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408280003688685568",
    "text" : "Obama: \"Next week, Michelle &amp; I will bring together college presidents and non-profits...to help more low-income students attend...college.\"",
    "id" : 408280003688685568,
    "created_at" : "2013-12-04 17:01:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408280031551442944,
  "created_at" : "2013-12-04 17:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408279501265588224",
  "text" : "President Obama: \"Step two is making sure we empower more Americans with the skills and education they need to compete.\" #ABetterBargain",
  "id" : 408279501265588224,
  "created_at" : "2013-12-04 16:59:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408279225544626176",
  "text" : "President Obama: \"We\u2019ve got to grow the economy faster &amp; keep working to make America a magnet for good, middle-class jobs.\" #ABetterBargain",
  "id" : 408279225544626176,
  "created_at" : "2013-12-04 16:58:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408279008963354625",
  "text" : "Obama: \"What drives me...is to make sure that every striving, hardworking...kid in America has the same chance this country gave me.\"",
  "id" : 408279008963354625,
  "created_at" : "2013-12-04 16:57:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408278412990484481",
  "text" : "President Obama: \"Before Medicare, only half of all seniors had some form of health insurance. Today, virtually all do.\" #ABetterBargain",
  "id" : 408278412990484481,
  "created_at" : "2013-12-04 16:55:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408278180588294144",
  "text" : "President Obama: \"Without Social Security, nearly half of seniors would be living in poverty. Today, fewer than 1 in 10 do.\" #ABetterBargain",
  "id" : 408278180588294144,
  "created_at" : "2013-12-04 16:54:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408277981488898049",
  "text" : "RT @WHLive: Obama: \"We need to dispel the myth that the goals of growing the economy &amp; reducing inequality are necessarily in conflict.\" #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 129, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408277904800219136",
    "text" : "Obama: \"We need to dispel the myth that the goals of growing the economy &amp; reducing inequality are necessarily in conflict.\" #ABetterBargain",
    "id" : 408277904800219136,
    "created_at" : "2013-12-04 16:53:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408277981488898049,
  "created_at" : "2013-12-04 16:53:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408277751049633794",
  "text" : "Obama: \"If we are to take on growing inequality, we have to move beyond the false notion that this is...of exclusively minority concern.\"",
  "id" : 408277751049633794,
  "created_at" : "2013-12-04 16:52:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408277150827958272",
  "text" : "President Obama: \"Women still make 77 cents on the dollar compared to men. So we\u2019ll still need anti-discrimination laws.\" #EqualPay",
  "id" : 408277150827958272,
  "created_at" : "2013-12-04 16:50:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408276730533531648",
  "text" : "Obama: \"The majority of Americans agree that our number one priority is to restore opportunity and broad-based growth for all Americans.\"",
  "id" : 408276730533531648,
  "created_at" : "2013-12-04 16:48:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408276039131860992",
  "text" : "President Obama: \"The idea that so many children are born into poverty in the wealthiest nation on Earth is heartbreaking.\"",
  "id" : 408276039131860992,
  "created_at" : "2013-12-04 16:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408275591788363778",
  "text" : "Obama on why we need to reduce income inequality: \"A family in the top 1% has a net worth 288 times higher than the typical family.\"",
  "id" : 408275591788363778,
  "created_at" : "2013-12-04 16:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408274232473178112",
  "text" : "President Obama: \"Together, we forged a New Deal, declared a War on Poverty, built a ladder of opportunity to climb.\" #ABetterBargain",
  "id" : 408274232473178112,
  "created_at" : "2013-12-04 16:38:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408273780109099008",
  "text" : "President Obama: \"While we don\u2019t promise equal outcomes, we have strived to deliver equal opportunity.\" #ABetterBargain",
  "id" : 408273780109099008,
  "created_at" : "2013-12-04 16:37:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408273703537889281",
  "text" : "RT @WHLive: \"It drives everything I do in this office.\" \u2014President Obama on helping hardworking Americans succeed #ABetterBargain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408273599779196929",
    "text" : "\"It drives everything I do in this office.\" \u2014President Obama on helping hardworking Americans succeed #ABetterBargain",
    "id" : 408273599779196929,
    "created_at" : "2013-12-04 16:36:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 408273703537889281,
  "created_at" : "2013-12-04 16:36:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 120, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408273363744722944",
  "text" : "Obama: \"I believe this is the defining challenge of our time\u2014making sure our economy works for every working American.\" #ABetterBargain",
  "id" : 408273363744722944,
  "created_at" : "2013-12-04 16:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/C7KdubHkMx",
      "expanded_url" : "http:\/\/go.wh.gov\/aEhqEo",
      "display_url" : "go.wh.gov\/aEhqEo"
    } ]
  },
  "geo" : { },
  "id_str" : "408272796616114178",
  "text" : "Right now: President Obama speaks on increasing economic mobility and helping more Americans succeed: http:\/\/t.co\/C7KdubHkMx #ABetterBargain",
  "id" : 408272796616114178,
  "created_at" : "2013-12-04 16:33:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408260680802770944",
  "text" : "What drives me is making sure every hardworking kid in America has the same chance this country gave me. About to speak on how we can. \u2013bo",
  "id" : 408260680802770944,
  "created_at" : "2013-12-04 15:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/vQ74UBBs7F",
      "expanded_url" : "http:\/\/HC.gov",
      "display_url" : "HC.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "408249484314173440",
  "text" : "RT @HealthCareGov: More than 950k visits to http:\/\/t.co\/vQ74UBBs7F yesterday. Site stable. Shoppers applying and enrolling in affordable he\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/vQ74UBBs7F",
        "expanded_url" : "http:\/\/HC.gov",
        "display_url" : "HC.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "408213089335533568",
    "text" : "More than 950k visits to http:\/\/t.co\/vQ74UBBs7F yesterday. Site stable. Shoppers applying and enrolling in affordable health care.",
    "id" : 408213089335533568,
    "created_at" : "2013-12-04 12:35:59 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 408249484314173440,
  "created_at" : "2013-12-04 15:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 60, 71 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/408042297335369729\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/3vrzaxShmR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BamoTqsCYAAoVT8.jpg",
      "id_str" : "408042297083715584",
      "id" : 408042297083715584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BamoTqsCYAAoVT8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3vrzaxShmR"
    } ],
    "hashtags" : [ {
      "text" : "WHHoliday",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "408043114889097216",
  "text" : "RT @FLOTUS: Behind the scenes: Volunteers help decorate the @WhiteHouse for the holidays. #WHHoliday, http:\/\/t.co\/3vrzaxShmR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 48, 59 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/408042297335369729\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/3vrzaxShmR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BamoTqsCYAAoVT8.jpg",
        "id_str" : "408042297083715584",
        "id" : 408042297083715584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BamoTqsCYAAoVT8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3vrzaxShmR"
      } ],
      "hashtags" : [ {
        "text" : "WHHoliday",
        "indices" : [ 78, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "408042297335369729",
    "text" : "Behind the scenes: Volunteers help decorate the @WhiteHouse for the holidays. #WHHoliday, http:\/\/t.co\/3vrzaxShmR",
    "id" : 408042297335369729,
    "created_at" : "2013-12-04 01:17:19 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 408043114889097216,
  "created_at" : "2013-12-04 01:20:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 11, 22 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/nzlwMd37O5",
      "expanded_url" : "http:\/\/go.wh.gov\/xWeDsJ",
      "display_url" : "go.wh.gov\/xWeDsJ"
    } ]
  },
  "geo" : { },
  "id_str" : "408019353309687809",
  "text" : "Before you #GetCovered at http:\/\/t.co\/uvXCniOFSK, check out pricing info for health plans in your state \u2014&gt; http:\/\/t.co\/nzlwMd37O5 #Obamacare",
  "id" : 408019353309687809,
  "created_at" : "2013-12-03 23:46:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 117, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/JG2zlKoFwi",
      "expanded_url" : "http:\/\/go.wh.gov\/XRTSwR",
      "display_url" : "go.wh.gov\/XRTSwR"
    } ]
  },
  "geo" : { },
  "id_str" : "407995010403946496",
  "text" : "FACT: Nearly 1.5 million more Americans are eligible for coverage through Medicaid next year: http:\/\/t.co\/JG2zlKoFwi #PeopleOverPolitics",
  "id" : 407995010403946496,
  "created_at" : "2013-12-03 22:09:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/407987598183776256\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/r7260wO78X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bal2jw-CAAAq1UL.jpg",
      "id_str" : "407987598066319360",
      "id" : 407987598066319360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bal2jw-CAAAq1UL.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/r7260wO78X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407987598183776256",
  "text" : "Tomorrow, President Obama will speak on increasing economic mobility &amp; helping every hardworking American succeed: http:\/\/t.co\/r7260wO78X",
  "id" : 407987598183776256,
  "created_at" : "2013-12-03 21:39:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storify",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "bideninasia",
      "indices" : [ 70, 82 ]
    }, {
      "text" : "tokyo",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/CCKpy2L3uL",
      "expanded_url" : "http:\/\/sfy.co\/iXHF",
      "display_url" : "sfy.co\/iXHF"
    } ]
  },
  "geo" : { },
  "id_str" : "407986066495651840",
  "text" : "Vice President Biden's 2013 Asia Trip http:\/\/t.co\/CCKpy2L3uL #storify #bideninasia #tokyo",
  "id" : 407986066495651840,
  "created_at" : "2013-12-03 21:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "407962558285348864",
  "text" : "President Obama: \"Let\u2019s help our fellow Americans #GetCovered.\" \u2014&gt; http:\/\/t.co\/GNfbftrfo3 #Obamacare",
  "id" : 407962558285348864,
  "created_at" : "2013-12-03 20:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "407962241221148672",
  "text" : "Obama: \"I need you to spread the word about this law, about its benefits...and how folks can sign up.\" http:\/\/t.co\/GNfbftrfo3 #Obamacare",
  "id" : 407962241221148672,
  "created_at" : "2013-12-03 19:59:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407961513853333504",
  "text" : "President Obama: \"I\u2019ll work with anyone to implement and improve this law, but we\u2019re not repealing it.\" #Obamacare",
  "id" : 407961513853333504,
  "created_at" : "2013-12-03 19:56:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407961211091701760",
  "text" : "\"My main message today is, 'we\u2019re not going back.'\" \u2014President Obama on helping millions of Americans afford health insurance #Obamacare",
  "id" : 407961211091701760,
  "created_at" : "2013-12-03 19:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407960434809901057",
  "text" : "Obama: \"More than 100 million Americans with insurance have gained access to recommended preventive care like mammograms.\" #Obamacare",
  "id" : 407960434809901057,
  "created_at" : "2013-12-03 19:52:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407959956818636801",
  "text" : "President Obama: \"About a half million people are poised to gain health care coverage...and that number...will keep on growing.\" #Obamacare",
  "id" : 407959956818636801,
  "created_at" : "2013-12-03 19:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/DYW1NiL4gD",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "407959647799095296",
  "text" : "RT @WHLive: Obama on http:\/\/t.co\/DYW1NiL4gD: \"More problems may pop up, as they always do when you\u2019re launching something new &amp; we\u2019ll fix t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/DYW1NiL4gD",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "407959598679601152",
    "text" : "Obama on http:\/\/t.co\/DYW1NiL4gD: \"More problems may pop up, as they always do when you\u2019re launching something new &amp; we\u2019ll fix those, too.\"",
    "id" : 407959598679601152,
    "created_at" : "2013-12-03 19:48:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 407959647799095296,
  "created_at" : "2013-12-03 19:48:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "407959484355452928",
  "text" : "President Obama: \"Today, the website is working well for the vast majority of users.\" http:\/\/t.co\/GNfbftrfo3 #GetCovered",
  "id" : 407959484355452928,
  "created_at" : "2013-12-03 19:48:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407959398091218944",
  "text" : "Obama: \"Nobody should have to choose between putting food on their kids\u2019 table or taking them to see a doctor.\" #Obamacare",
  "id" : 407959398091218944,
  "created_at" : "2013-12-03 19:47:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407959265379250176",
  "text" : "Obama: \"We took up this fight because...in America, nobody should have to worry about going broke just because...they get sick.\" #Obamacare",
  "id" : 407959265379250176,
  "created_at" : "2013-12-03 19:47:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/gL9JBJhjO3",
      "expanded_url" : "http:\/\/go.wh.gov\/CB8YRH",
      "display_url" : "go.wh.gov\/CB8YRH"
    } ]
  },
  "geo" : { },
  "id_str" : "407958931491655680",
  "text" : "Starting now: President Obama speaks on how the Affordable Care Act is benefiting millions of Americans \u2014&gt; http:\/\/t.co\/gL9JBJhjO3 #Obamacare",
  "id" : 407958931491655680,
  "created_at" : "2013-12-03 19:46:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/gL9JBJhjO3",
      "expanded_url" : "http:\/\/go.wh.gov\/CB8YRH",
      "display_url" : "go.wh.gov\/CB8YRH"
    } ]
  },
  "geo" : { },
  "id_str" : "407954202959151105",
  "text" : "Don\u2019t miss President Obama speak on how the Affordable Care Act is benefiting millions of Americans at 2:30pm ET: http:\/\/t.co\/gL9JBJhjO3",
  "id" : 407954202959151105,
  "created_at" : "2013-12-03 19:27:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407952211717918721",
  "text" : "RT @jesseclee44: As Rs throw rocks, 1000s of Americans getting coverage every day, many for 1st time. Many insurance co. abuses coming to a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407945729550716928",
    "text" : "As Rs throw rocks, 1000s of Americans getting coverage every day, many for 1st time. Many insurance co. abuses coming to an end. #Obamacare",
    "id" : 407945729550716928,
    "created_at" : "2013-12-03 18:53:35 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 407952211717918721,
  "created_at" : "2013-12-03 19:19:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kliff",
      "screen_name" : "sarahkliff",
      "indices" : [ 3, 14 ],
      "id_str" : "19734832",
      "id" : 19734832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/hPxlU8XUhr",
      "expanded_url" : "http:\/\/www.medicaid.gov\/AffordableCareAct\/Medicaid-Moving-Forward-2014\/Downloads\/Medicaid-CHIP-Monthly-Enrollment-Report.pdf",
      "display_url" : "medicaid.gov\/AffordableCare\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "407946523482550272",
  "text" : "RT @sarahkliff: In states expanding Medicaid, there was a 15 percent spike last month in Medicaid applications. http:\/\/t.co\/hPxlU8XUhr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/hPxlU8XUhr",
        "expanded_url" : "http:\/\/www.medicaid.gov\/AffordableCareAct\/Medicaid-Moving-Forward-2014\/Downloads\/Medicaid-CHIP-Monthly-Enrollment-Report.pdf",
        "display_url" : "medicaid.gov\/AffordableCare\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "407942758209318913",
    "text" : "In states expanding Medicaid, there was a 15 percent spike last month in Medicaid applications. http:\/\/t.co\/hPxlU8XUhr",
    "id" : 407942758209318913,
    "created_at" : "2013-12-03 18:41:47 +0000",
    "user" : {
      "name" : "Sarah Kliff",
      "screen_name" : "sarahkliff",
      "protected" : false,
      "id_str" : "19734832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765529412301455361\/_faRepBm_normal.jpg",
      "id" : 19734832,
      "verified" : true
    }
  },
  "id" : 407946523482550272,
  "created_at" : "2013-12-03 18:56:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/1MVLQtMu72",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "407932803171762176",
  "text" : "RT @HealthCareGov: More than 380k visits to http:\/\/t.co\/1MVLQtMu72 as of noon, EST. Site stable, high traffic, no queuing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/1MVLQtMu72",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "407924528388378624",
    "text" : "More than 380k visits to http:\/\/t.co\/1MVLQtMu72 as of noon, EST. Site stable, high traffic, no queuing.",
    "id" : 407924528388378624,
    "created_at" : "2013-12-03 17:29:21 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 407932803171762176,
  "created_at" : "2013-12-03 18:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/G7NVGGjuC4",
      "expanded_url" : "http:\/\/go.wh.gov\/9xtKMG",
      "display_url" : "go.wh.gov\/9xtKMG"
    } ]
  },
  "geo" : { },
  "id_str" : "407926742062346240",
  "text" : "RT to share the 4 ways you can #GetCovered:\n1. http:\/\/t.co\/uvXCniOFSK\n2. By mail\n3. In person\n4. Call 1-800-318-2596\nhttp:\/\/t.co\/G7NVGGjuC4",
  "id" : 407926742062346240,
  "created_at" : "2013-12-03 17:38:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Eliseo Medina",
      "screen_name" : "SEIU_Eliseo",
      "indices" : [ 31, 43 ],
      "id_str" : "432799563",
      "id" : 432799563
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fast4Families",
      "indices" : [ 128, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407921807530815488",
  "text" : "RT @FLOTUS: So humbled to meet @SEIU_Eliseo. Thank you for your dedication &amp; leadership. We're with you &amp; all those who #Fast4Families. #Ac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eliseo Medina",
        "screen_name" : "SEIU_Eliseo",
        "indices" : [ 19, 31 ],
        "id_str" : "432799563",
        "id" : 432799563
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Fast4Families",
        "indices" : [ 116, 130 ]
      }, {
        "text" : "ActOnReform",
        "indices" : [ 132, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407921474960642048",
    "text" : "So humbled to meet @SEIU_Eliseo. Thank you for your dedication &amp; leadership. We're with you &amp; all those who #Fast4Families. #ActOnReform \u2013mo",
    "id" : 407921474960642048,
    "created_at" : "2013-12-03 17:17:13 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 407921807530815488,
  "created_at" : "2013-12-03 17:18:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BidenInAsia",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407909812173676545",
  "text" : "RT @VP: \u201CIt\u2019s overwhelmingly in the security interest &amp; economic interest of the U.S. for Japan to do well\u201D \u2014VP #BidenInAsia: http:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BidenInAsia",
        "indices" : [ 108, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/iIpryihJpp",
        "expanded_url" : "http:\/\/instagram.com\/p\/hdpo20wihs\/",
        "display_url" : "instagram.com\/p\/hdpo20wihs\/"
      } ]
    },
    "geo" : { },
    "id_str" : "407902096952799233",
    "text" : "\u201CIt\u2019s overwhelmingly in the security interest &amp; economic interest of the U.S. for Japan to do well\u201D \u2014VP #BidenInAsia: http:\/\/t.co\/iIpryihJpp",
    "id" : 407902096952799233,
    "created_at" : "2013-12-03 16:00:13 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 407909812173676545,
  "created_at" : "2013-12-03 16:30:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407896984943861760",
  "text" : "RT @Sebelius: Good news: 1.46 million people have been found eligible for Medicaid &amp; CHIP in the 1st month of open enrollment. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/dmPH0ViFiG",
        "expanded_url" : "http:\/\/go.usa.gov\/WFFm",
        "display_url" : "go.usa.gov\/WFFm"
      } ]
    },
    "geo" : { },
    "id_str" : "407894163661668352",
    "text" : "Good news: 1.46 million people have been found eligible for Medicaid &amp; CHIP in the 1st month of open enrollment. http:\/\/t.co\/dmPH0ViFiG",
    "id" : 407894163661668352,
    "created_at" : "2013-12-03 15:28:41 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 407896984943861760,
  "created_at" : "2013-12-03 15:39:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/vQ74UBBs7F",
      "expanded_url" : "http:\/\/HC.gov",
      "display_url" : "HC.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "407891556893356032",
  "text" : "RT @HealthCareGov: 1 million visits to http:\/\/t.co\/vQ74UBBs7F yesterday. Site stable, faster for users.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/vQ74UBBs7F",
        "expanded_url" : "http:\/\/HC.gov",
        "display_url" : "HC.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "407877028084342784",
    "text" : "1 million visits to http:\/\/t.co\/vQ74UBBs7F yesterday. Site stable, faster for users.",
    "id" : 407877028084342784,
    "created_at" : "2013-12-03 14:20:36 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 407891556893356032,
  "created_at" : "2013-12-03 15:18:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GivingTuesday",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/RpMb61Y7sY",
      "expanded_url" : "http:\/\/go.wh.gov\/4oHLeN",
      "display_url" : "go.wh.gov\/4oHLeN"
    } ]
  },
  "geo" : { },
  "id_str" : "407881207548878848",
  "text" : "\u201CPeople everywhere can find their own ways to celebrate their common bond of community.\u201D \u2014&gt; http:\/\/t.co\/RpMb61Y7sY #GivingTuesday",
  "id" : 407881207548878848,
  "created_at" : "2013-12-03 14:37:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/407691206152699904\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/753orFpdDx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Baho_eeIUAAGQMe.jpg",
      "id_str" : "407691205997514752",
      "id" : 407691205997514752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Baho_eeIUAAGQMe.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/753orFpdDx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/ixsA8PV71p",
      "expanded_url" : "http:\/\/go.wh.gov\/ggRbix",
      "display_url" : "go.wh.gov\/ggRbix"
    } ]
  },
  "geo" : { },
  "id_str" : "407691206152699904",
  "text" : "Here\u2019s an update on the progress we\u2019ve made to reduce gun violence and protect our kids \u2014&gt; http:\/\/t.co\/ixsA8PV71p, http:\/\/t.co\/753orFpdDx",
  "id" : 407691206152699904,
  "created_at" : "2013-12-03 02:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Kal Penn",
      "screen_name" : "kalpenn",
      "indices" : [ 46, 54 ],
      "id_str" : "24024778",
      "id" : 24024778
    }, {
      "name" : "YI",
      "screen_name" : "YI_Care",
      "indices" : [ 56, 64 ],
      "id_str" : "2510807636",
      "id" : 2510807636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHYouthSummit",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407680538846044160",
  "text" : "RT @WHLive: Right now: Join a G+ Hangout with @KalPenn, @YI_Care, and WH Staff on health care. Ask your Q's using #WHYouthSummit: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kal Penn",
        "screen_name" : "kalpenn",
        "indices" : [ 34, 42 ],
        "id_str" : "24024778",
        "id" : 24024778
      }, {
        "name" : "YI",
        "screen_name" : "YI_Care",
        "indices" : [ 44, 52 ],
        "id_str" : "2510807636",
        "id" : 2510807636
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHYouthSummit",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/3bp1wbvmxG",
        "expanded_url" : "http:\/\/go.wh.gov\/e8wXse",
        "display_url" : "go.wh.gov\/e8wXse"
      } ]
    },
    "geo" : { },
    "id_str" : "407678668031266816",
    "text" : "Right now: Join a G+ Hangout with @KalPenn, @YI_Care, and WH Staff on health care. Ask your Q's using #WHYouthSummit: http:\/\/t.co\/3bp1wbvmxG",
    "id" : 407678668031266816,
    "created_at" : "2013-12-03 01:12:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 407680538846044160,
  "created_at" : "2013-12-03 01:19:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/407672565939720192\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/HEAshPTzXy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BahYCe3CUAAbGAw.jpg",
      "id_str" : "407672565943914496",
      "id" : 407672565943914496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BahYCe3CUAAbGAw.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/HEAshPTzXy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407672565939720192",
  "text" : "Happy birthday to President Obama\u2019s Chief of Staff, Denis McDonough! http:\/\/t.co\/HEAshPTzXy",
  "id" : 407672565939720192,
  "created_at" : "2013-12-03 00:48:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/1MVLQtMu72",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "407664022524534785",
  "text" : "RT @HealthCareGov: http:\/\/t.co\/1MVLQtMu72 high volume \u2013 750k visitors as of 5:30pm, no queuing now, site fast w\/ low error rate.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/1MVLQtMu72",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "407638462443962368",
    "text" : "http:\/\/t.co\/1MVLQtMu72 high volume \u2013 750k visitors as of 5:30pm, no queuing now, site fast w\/ low error rate.",
    "id" : 407638462443962368,
    "created_at" : "2013-12-02 22:32:37 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 407664022524534785,
  "created_at" : "2013-12-03 00:14:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kal Penn",
      "screen_name" : "kalpenn",
      "indices" : [ 52, 60 ],
      "id_str" : "24024778",
      "id" : 24024778
    }, {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 62, 77 ],
      "id_str" : "9448842",
      "id" : 9448842
    }, {
      "name" : "YI",
      "screen_name" : "YI_Care",
      "indices" : [ 84, 92 ],
      "id_str" : "2510807636",
      "id" : 2510807636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHYouthSummit",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/fNsgIB1pFc",
      "expanded_url" : "http:\/\/go.wh.gov\/xFUXvm",
      "display_url" : "go.wh.gov\/xFUXvm"
    } ]
  },
  "geo" : { },
  "id_str" : "407652892703596544",
  "text" : "Tune in at 8pm ET for a health care G+ Hangout with @KalPenn, @HealthCareTara &amp; @YI_Care. Ask Q\u2019s w\/ #WHYouthSummit: http:\/\/t.co\/fNsgIB1pFc",
  "id" : 407652892703596544,
  "created_at" : "2013-12-02 23:29:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "indices" : [ 3, 14 ],
      "id_str" : "20655674",
      "id" : 20655674
    }, {
      "name" : "Nick Hennen",
      "screen_name" : "tweetbrk",
      "indices" : [ 36, 45 ],
      "id_str" : "15542781",
      "id" : 15542781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407652265026387968",
  "text" : "RT @ACAstories: ND: Nancy Hennen MT @Tweetbrk yes, I signed up this weekend from North Dakota. Surprised how easy it was. Took about 1\/2 hr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Hennen",
        "screen_name" : "tweetbrk",
        "indices" : [ 20, 29 ],
        "id_str" : "15542781",
        "id" : 15542781
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "407543433847255040",
    "geo" : { },
    "id_str" : "407578265864261633",
    "in_reply_to_user_id" : 15542781,
    "text" : "ND: Nancy Hennen MT @Tweetbrk yes, I signed up this weekend from North Dakota. Surprised how easy it was. Took about 1\/2 hr. Cost affordable",
    "id" : 407578265864261633,
    "in_reply_to_status_id" : 407543433847255040,
    "created_at" : "2013-12-02 18:33:25 +0000",
    "in_reply_to_screen_name" : "tweetbrk",
    "in_reply_to_user_id_str" : "15542781",
    "user" : {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "protected" : false,
      "id_str" : "20655674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442325097731223552\/qhUhX6DV_normal.png",
      "id" : 20655674,
      "verified" : false
    }
  },
  "id" : 407652265026387968,
  "created_at" : "2013-12-02 23:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmithsonianPanda",
      "indices" : [ 76, 93 ]
    }, {
      "text" : "TeamBaoBao",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/l7nHlpcDZ4",
      "expanded_url" : "http:\/\/go.wh.gov\/nZmLWU",
      "display_url" : "go.wh.gov\/nZmLWU"
    } ]
  },
  "geo" : { },
  "id_str" : "407624087490396160",
  "text" : "RT @FLOTUS: \u201CN\u01D0 h\u01CEo!\u201D \u2014The First Lady gives a shout out to Bao Bao\u2014the baby #SmithsonianPanda: http:\/\/t.co\/l7nHlpcDZ4 #TeamBaoBao",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmithsonianPanda",
        "indices" : [ 64, 81 ]
      }, {
        "text" : "TeamBaoBao",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/l7nHlpcDZ4",
        "expanded_url" : "http:\/\/go.wh.gov\/nZmLWU",
        "display_url" : "go.wh.gov\/nZmLWU"
      } ]
    },
    "geo" : { },
    "id_str" : "407603369251848192",
    "text" : "\u201CN\u01D0 h\u01CEo!\u201D \u2014The First Lady gives a shout out to Bao Bao\u2014the baby #SmithsonianPanda: http:\/\/t.co\/l7nHlpcDZ4 #TeamBaoBao",
    "id" : 407603369251848192,
    "created_at" : "2013-12-02 20:13:10 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 407624087490396160,
  "created_at" : "2013-12-02 21:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Capitol",
      "screen_name" : "uscapitol",
      "indices" : [ 3, 13 ],
      "id_str" : "17539497",
      "id" : 17539497
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uscapitol\/status\/407495551153082368\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/BeBFlspplK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bae3C2pIAAAyQuM.jpg",
      "id_str" : "407495550955945984",
      "id" : 407495550955945984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bae3C2pIAAAyQuM.jpg",
      "sizes" : [ {
        "h" : 198,
        "resize" : "fit",
        "w" : 309
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 309
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 309
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 309
      } ],
      "display_url" : "pic.twitter.com\/BeBFlspplK"
    } ],
    "hashtags" : [ {
      "text" : "CapitolDome",
      "indices" : [ 55, 67 ]
    }, {
      "text" : "OnThisDay",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407617445927845888",
  "text" : "RT @uscapitol: The moment Statue of Freedom topped the #CapitolDome #OnThisDay 1863: http:\/\/t.co\/BeBFlspplK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/uscapitol\/status\/407495551153082368\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/BeBFlspplK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bae3C2pIAAAyQuM.jpg",
        "id_str" : "407495550955945984",
        "id" : 407495550955945984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bae3C2pIAAAyQuM.jpg",
        "sizes" : [ {
          "h" : 198,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 309
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 309
        } ],
        "display_url" : "pic.twitter.com\/BeBFlspplK"
      } ],
      "hashtags" : [ {
        "text" : "CapitolDome",
        "indices" : [ 40, 52 ]
      }, {
        "text" : "OnThisDay",
        "indices" : [ 53, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407495551153082368",
    "text" : "The moment Statue of Freedom topped the #CapitolDome #OnThisDay 1863: http:\/\/t.co\/BeBFlspplK",
    "id" : 407495551153082368,
    "created_at" : "2013-12-02 13:04:44 +0000",
    "user" : {
      "name" : "U.S. Capitol",
      "screen_name" : "uscapitol",
      "protected" : false,
      "id_str" : "17539497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1519382481\/AOC_Logo_Black_web_normal.jpg",
      "id" : 17539497,
      "verified" : true
    }
  },
  "id" : 407617445927845888,
  "created_at" : "2013-12-02 21:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kal Penn",
      "screen_name" : "kalpenn",
      "indices" : [ 16, 24 ],
      "id_str" : "24024778",
      "id" : 24024778
    }, {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 26, 41 ],
      "id_str" : "9448842",
      "id" : 9448842
    }, {
      "name" : "YI",
      "screen_name" : "YI_Care",
      "indices" : [ 48, 56 ],
      "id_str" : "2510807636",
      "id" : 2510807636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 93, 103 ]
    }, {
      "text" : "WHYouth",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/5B72JkuHRh",
      "expanded_url" : "http:\/\/go.wh.gov\/AZjAxB",
      "display_url" : "go.wh.gov\/AZjAxB"
    } ]
  },
  "geo" : { },
  "id_str" : "407613456158687232",
  "text" : "At 8pm ET, join @KalPenn, @HealthCareTara &amp; @YI_Care for a Hangout on young people &amp; #Obamacare. Ask Qs w\/ #WHYouth: http:\/\/t.co\/5B72JkuHRh",
  "id" : 407613456158687232,
  "created_at" : "2013-12-02 20:53:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 16, 24 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407602477782302720",
  "text" : "RT @DagVega44: .@Simas44: \"This is about making sure anyone who wants quality health insurance can get it at an affordable price.\" http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Simas",
        "screen_name" : "Simas44",
        "indices" : [ 1, 9 ],
        "id_str" : "1135399020",
        "id" : 1135399020
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/fgrvvlVd11",
        "expanded_url" : "http:\/\/on.msnbc.com\/1bdxaOx",
        "display_url" : "on.msnbc.com\/1bdxaOx"
      } ]
    },
    "geo" : { },
    "id_str" : "407584960795533312",
    "text" : ".@Simas44: \"This is about making sure anyone who wants quality health insurance can get it at an affordable price.\" http:\/\/t.co\/fgrvvlVd11",
    "id" : 407584960795533312,
    "created_at" : "2013-12-02 19:00:01 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 407602477782302720,
  "created_at" : "2013-12-02 20:09:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/407591393801293824\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/hyH5E2Ae7C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BagONokIMAAFQuc.jpg",
      "id_str" : "407591393667067904",
      "id" : 407591393667067904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BagONokIMAAFQuc.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hyH5E2Ae7C"
    } ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407591393801293824",
  "text" : "We\u2019ve come a long way since the early days of the AIDS epidemic\u2014but we\u2019ve still got more work to do. #WorldAIDSDay, http:\/\/t.co\/hyH5E2Ae7C",
  "id" : 407591393801293824,
  "created_at" : "2013-12-02 19:25:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/vQ74UBBs7F",
      "expanded_url" : "http:\/\/HC.gov",
      "display_url" : "HC.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "407587180086059008",
  "text" : "RT @HealthCareGov: Lots of demand at http:\/\/t.co\/vQ74UBBs7F . More than 375k visitors so far today as of noon EDT.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/vQ74UBBs7F",
        "expanded_url" : "http:\/\/HC.gov",
        "display_url" : "HC.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "407586232110030848",
    "text" : "Lots of demand at http:\/\/t.co\/vQ74UBBs7F . More than 375k visitors so far today as of noon EDT.",
    "id" : 407586232110030848,
    "created_at" : "2013-12-02 19:05:04 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 407587180086059008,
  "created_at" : "2013-12-02 19:08:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407578919479422976",
  "text" : "Obama: \"An AIDS-free generation: That\u2019s the world I want for my daughters. That\u2019s the world we want for all our families.\" #WorldAIDSDay",
  "id" : 407578919479422976,
  "created_at" : "2013-12-02 18:36:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407577927975333888",
  "text" : "RT @WHLive: Obama: \"We\u2019ve helped 6.7 million people receive life-saving treatment, and we\u2019re going to keep at it.\" #WorldAIDSDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldAIDSDay",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407577906538246144",
    "text" : "Obama: \"We\u2019ve helped 6.7 million people receive life-saving treatment, and we\u2019re going to keep at it.\" #WorldAIDSDay",
    "id" : 407577906538246144,
    "created_at" : "2013-12-02 18:32:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 407577927975333888,
  "created_at" : "2013-12-02 18:32:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407577214297722880",
  "text" : "RT @WHLive: Obama: \"We\u2019re making progress. But we\u2019re all here today because we know our work is far from finished.\" #WorldAIDSDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldAIDSDay",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407577143581741057",
    "text" : "Obama: \"We\u2019re making progress. But we\u2019re all here today because we know our work is far from finished.\" #WorldAIDSDay",
    "id" : 407577143581741057,
    "created_at" : "2013-12-02 18:28:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 407577214297722880,
  "created_at" : "2013-12-02 18:29:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 110, 123 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407576747769491456",
  "text" : "Obama: \"Beginning in January, no American will again be denied health insurance because of their HIV status.\" #WorldAIDSDay #Obamacare",
  "id" : 407576747769491456,
  "created_at" : "2013-12-02 18:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 116, 129 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407576557679419392",
  "text" : "Obama: \"Thanks to the Affordable Care Act\u2014millions of insured Americans will be able to get tested free of charge.\" #WorldAIDSDay #Obamacare",
  "id" : 407576557679419392,
  "created_at" : "2013-12-02 18:26:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407576350728265728",
  "text" : "President Obama: \"The disease that was once a death sentence now comes with a good chance at a healthy and productive life.\" #WorldAIDSDay",
  "id" : 407576350728265728,
  "created_at" : "2013-12-02 18:25:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407576279009878016",
  "text" : "President Obama: \"Awareness soared. Research surged. Prevention, treatment and care are now saving millions of lives.\" #WorldAIDSDay",
  "id" : 407576279009878016,
  "created_at" : "2013-12-02 18:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407576169433673728",
  "text" : "President Obama: \"This is a moment to reflect on how far we\u2019ve come since the early days of the AIDS epidemic.\" #WorldAIDSDay",
  "id" : 407576169433673728,
  "created_at" : "2013-12-02 18:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/1ZeSJXjNXQ",
      "expanded_url" : "http:\/\/go.wh.gov\/JiirjC",
      "display_url" : "go.wh.gov\/JiirjC"
    } ]
  },
  "geo" : { },
  "id_str" : "407575396532498432",
  "text" : "Right now: President Obama speaks at the White House observation of #WorldAIDSDay \u2014&gt; http:\/\/t.co\/1ZeSJXjNXQ",
  "id" : 407575396532498432,
  "created_at" : "2013-12-02 18:22:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 44, 55 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/1ZeSJXjNXQ",
      "expanded_url" : "http:\/\/go.wh.gov\/JiirjC",
      "display_url" : "go.wh.gov\/JiirjC"
    } ]
  },
  "geo" : { },
  "id_str" : "407571900638851072",
  "text" : "At 1:20pm ET, President Obama speaks at the @WhiteHouse observation of #WorldAIDSDay. Watch \u2014&gt; http:\/\/t.co\/1ZeSJXjNXQ",
  "id" : 407571900638851072,
  "created_at" : "2013-12-02 18:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "indices" : [ 3, 14 ],
      "id_str" : "20655674",
      "id" : 20655674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/TZ4SU9Z9Id",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "407565206626504704",
  "text" : "RT @ACAstories: PA: Vickie Fleisher-Gann just signed up 4 ACA via the vastly improved http:\/\/t.co\/TZ4SU9Z9Id site. \"I am so relieved\" http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/TZ4SU9Z9Id",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/qTIyeNaI8G",
        "expanded_url" : "http:\/\/capsules.kaiserhealthnews.org\/index.php\/2013\/12\/many-consumers-report-improvements-with-healthcare-gov\/",
        "display_url" : "capsules.kaiserhealthnews.org\/index.php\/2013\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "407559876244541441",
    "text" : "PA: Vickie Fleisher-Gann just signed up 4 ACA via the vastly improved http:\/\/t.co\/TZ4SU9Z9Id site. \"I am so relieved\" http:\/\/t.co\/qTIyeNaI8G",
    "id" : 407559876244541441,
    "created_at" : "2013-12-02 17:20:21 +0000",
    "user" : {
      "name" : "ACA Stories",
      "screen_name" : "ACAstories",
      "protected" : false,
      "id_str" : "20655674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442325097731223552\/qhUhX6DV_normal.png",
      "id" : 20655674,
      "verified" : false
    }
  },
  "id" : 407565206626504704,
  "created_at" : "2013-12-02 17:41:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 27, 31 ],
      "id_str" : "14615871",
      "id" : 14615871
    }, {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 40, 48 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EPAProgress",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/aA4fZSEiQZ",
      "expanded_url" : "http:\/\/huff.to\/1chil1O",
      "display_url" : "huff.to\/1chil1O"
    } ]
  },
  "geo" : { },
  "id_str" : "407561222704230400",
  "text" : "Happy 43rd birthday to the @EPA! Here's @GinaEPA on the progress we\u2019ve made to protect our environment: http:\/\/t.co\/aA4fZSEiQZ #EPAProgress",
  "id" : 407561222704230400,
  "created_at" : "2013-12-02 17:25:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/zGh0BmAqq7",
      "expanded_url" : "http:\/\/cnn.it\/1b4p6Q0",
      "display_url" : "cnn.it\/1b4p6Q0"
    } ]
  },
  "geo" : { },
  "id_str" : "407544361530843136",
  "text" : "\u201CA bill that would bring relief to millions of\u2026families\u2026isn't even being brought up for a vote.\u201D http:\/\/t.co\/zGh0BmAqq7 #ImmigrationReform",
  "id" : 407544361530843136,
  "created_at" : "2013-12-02 16:18:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PEPFAR",
      "screen_name" : "PEPFAR",
      "indices" : [ 3, 10 ],
      "id_str" : "69091913",
      "id" : 69091913
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PEPFAR\/status\/407292383857225728\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/6ipkMdOJLa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bab-Q9fIMAArpfK.jpg",
      "id_str" : "407292383660093440",
      "id" : 407292383660093440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bab-Q9fIMAArpfK.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6ipkMdOJLa"
    } ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407533799174852608",
  "text" : "RT @PEPFAR: .@WhiteHouse shows it\u2019s support for #WorldAIDSDay by hanging a giant red AIDS ribbon! AP photo http:\/\/t.co\/6ipkMdOJLa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PEPFAR\/status\/407292383857225728\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/6ipkMdOJLa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bab-Q9fIMAArpfK.jpg",
        "id_str" : "407292383660093440",
        "id" : 407292383660093440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bab-Q9fIMAArpfK.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6ipkMdOJLa"
      } ],
      "hashtags" : [ {
        "text" : "WorldAIDSDay",
        "indices" : [ 36, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407292383857225728",
    "text" : ".@WhiteHouse shows it\u2019s support for #WorldAIDSDay by hanging a giant red AIDS ribbon! AP photo http:\/\/t.co\/6ipkMdOJLa",
    "id" : 407292383857225728,
    "created_at" : "2013-12-01 23:37:26 +0000",
    "user" : {
      "name" : "PEPFAR",
      "screen_name" : "PEPFAR",
      "protected" : false,
      "id_str" : "69091913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719590176289193984\/r0UMCuIN_normal.jpg",
      "id" : 69091913,
      "verified" : true
    }
  },
  "id" : 407533799174852608,
  "created_at" : "2013-12-02 15:36:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "407517072001085440",
  "text" : "RT @AmbassadorRice: We must press ahead until we have seen the last AIDS-related death and no child is born infected with HIV. #WorldAIDSDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldAIDSDay",
        "indices" : [ 107, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "407293322554650625",
    "text" : "We must press ahead until we have seen the last AIDS-related death and no child is born infected with HIV. #WorldAIDSDay",
    "id" : 407293322554650625,
    "created_at" : "2013-12-01 23:41:09 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 407517072001085440,
  "created_at" : "2013-12-02 14:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/qFAvJc6ukt",
      "expanded_url" : "http:\/\/go.wh.gov\/SHUHqp",
      "display_url" : "go.wh.gov\/SHUHqp"
    } ]
  },
  "geo" : { },
  "id_str" : "407335901744742400",
  "text" : "Sally Ride \"could use space\u2026as a way to get kids &amp; teachers more interested in #STEM.\u201D \u2014Tam O\u2019 Shaugnessy: http:\/\/t.co\/qFAvJc6ukt",
  "id" : 407335901744742400,
  "created_at" : "2013-12-02 02:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sandovalarturo1",
      "screen_name" : "sandovalarturo1",
      "indices" : [ 82, 98 ],
      "id_str" : "152920910",
      "id" : 152920910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/PgLzhxy5it",
      "expanded_url" : "http:\/\/go.wh.gov\/WXbE7i",
      "display_url" : "go.wh.gov\/WXbE7i"
    } ]
  },
  "geo" : { },
  "id_str" : "407320548490760192",
  "text" : "\u201CFreedom...the most important word in the whole dictionary\u2026no freedom, no life.\u201D \u2014@SandovalArturo1: http:\/\/t.co\/PgLzhxy5it #MedalOfFreedom",
  "id" : 407320548490760192,
  "created_at" : "2013-12-02 01:29:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gloria Steinem",
      "screen_name" : "GloriaSteinem",
      "indices" : [ 69, 83 ],
      "id_str" : "48269483",
      "id" : 48269483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/EbZVjOVoFe",
      "expanded_url" : "http:\/\/go.wh.gov\/rkdbVU",
      "display_url" : "go.wh.gov\/rkdbVU"
    } ]
  },
  "geo" : { },
  "id_str" : "407304945830871040",
  "text" : "\u201CWhat makes this medal mean so much is that it\u2019s for waging peace.\u201D \u2014@GloriaSteinem. Watch \u2014&gt;  http:\/\/t.co\/EbZVjOVoFe #MedalOfFreedom",
  "id" : 407304945830871040,
  "created_at" : "2013-12-02 00:27:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/pMTUW7DGoN",
      "expanded_url" : "http:\/\/go.wh.gov\/f4jrxs",
      "display_url" : "go.wh.gov\/f4jrxs"
    } ]
  },
  "geo" : { },
  "id_str" : "407289594116194304",
  "text" : "\u201CGet out here and do something. That\u2019s my message to young people.\u201D \u2014Ernie Banks: http:\/\/t.co\/pMTUW7DGoN #MedalOfFreedom",
  "id" : 407289594116194304,
  "created_at" : "2013-12-01 23:26:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 93, 99 ],
      "id_str" : "19397785",
      "id" : 19397785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/sfxXPgxoMR",
      "expanded_url" : "http:\/\/go.wh.gov\/Xd3V1g",
      "display_url" : "go.wh.gov\/Xd3V1g"
    } ]
  },
  "geo" : { },
  "id_str" : "407273992873967616",
  "text" : "\u201CThe real work is to discover who you are, and to use who you are in service to the world.\u201D \u2014@Oprah: http:\/\/t.co\/sfxXPgxoMR #MedalOfFreedom",
  "id" : 407273992873967616,
  "created_at" : "2013-12-01 22:24:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 54, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/iuCCxZkGgU",
      "expanded_url" : "http:\/\/go.wh.gov\/XrUcMi",
      "display_url" : "go.wh.gov\/XrUcMi"
    } ]
  },
  "geo" : { },
  "id_str" : "407258935435862016",
  "text" : "Worth watching: Go behind-the-scenes with this year\u2019s #MedalOfFreedom recipients \u2014&gt; http:\/\/t.co\/iuCCxZkGgU",
  "id" : 407258935435862016,
  "created_at" : "2013-12-01 21:24:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]