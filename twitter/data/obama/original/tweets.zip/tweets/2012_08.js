Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 78, 97 ]
    }, {
      "text" : "healthreform",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/sNJdFVni",
      "expanded_url" : "http:\/\/on.wh.gov\/Ux4ugVk",
      "display_url" : "on.wh.gov\/Ux4ugVk"
    } ]
  },
  "geo" : { },
  "id_str" : "241736312376393729",
  "text" : "West Wing Week: It's Summer Mailbag Time! @whitehouse staff answer your ?s on #MiddleClassTaxCuts #healthreform &amp; more: http:\/\/t.co\/sNJdFVni",
  "id" : 241736312376393729,
  "created_at" : "2012-09-01 03:16:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "milfams",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/g135w2VM",
      "expanded_url" : "http:\/\/on.wh.gov\/HXaNREu",
      "display_url" : "on.wh.gov\/HXaNREu"
    } ]
  },
  "geo" : { },
  "id_str" : "241652787820253184",
  "text" : "Today President Obama signed an EO that will give our #veterans, troops &amp; #milfams better access to mental health care: http:\/\/t.co\/g135w2VM",
  "id" : 241652787820253184,
  "created_at" : "2012-08-31 21:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241618424722227200",
  "text" : "RT @WHLive: Obama: \"I\u2019m again calling on Congress to act. Pass the Veterans Jobs Corps so we can put more vets to work protecting &amp;  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241618261295378433",
    "text" : "Obama: \"I\u2019m again calling on Congress to act. Pass the Veterans Jobs Corps so we can put more vets to work protecting &amp; rebuilding America\"",
    "id" : 241618261295378433,
    "created_at" : "2012-08-31 19:27:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 241618424722227200,
  "created_at" : "2012-08-31 19:28:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241616068114792449",
  "text" : "RT @WHLive: Obama: \"Now, when I was here last, I made you a pledge...I\u2019ll insist that America serves you &amp; your families as well as  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241616025236410368",
    "text" : "Obama: \"Now, when I was here last, I made you a pledge...I\u2019ll insist that America serves you &amp; your families as well as you have served us\"",
    "id" : 241616025236410368,
    "created_at" : "2012-08-31 19:18:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 241616068114792449,
  "created_at" : "2012-08-31 19:18:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241614478947532800",
  "text" : "RT @WHLive: Obama: \"This past December...the last American troops came home...You left Iraq, with honor, your mission complete, your hea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241614405886955521",
    "text" : "Obama: \"This past December...the last American troops came home...You left Iraq, with honor, your mission complete, your heads held high\"",
    "id" : 241614405886955521,
    "created_at" : "2012-08-31 19:12:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 241614478947532800,
  "created_at" : "2012-08-31 19:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "241613312809373696",
  "text" : "RT @WHLive: President Obama: \"Hello Team Bliss!\" Watch: http:\/\/t.co\/g5icuVZL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "241613162883993601",
    "text" : "President Obama: \"Hello Team Bliss!\" Watch: http:\/\/t.co\/g5icuVZL",
    "id" : 241613162883993601,
    "created_at" : "2012-08-31 19:07:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 241613312809373696,
  "created_at" : "2012-08-31 19:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 112, 119 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteTroops",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "241612086021611520",
  "text" : "Happening now: President Obama speaks to troops at Fort Bliss, Texas. Watch: http:\/\/t.co\/u95tzH8r &amp; follow: @WHLive #SaluteTroops",
  "id" : 241612086021611520,
  "created_at" : "2012-08-31 19:03:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteTroops",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241590331227906048",
  "text" : "RT @AmbassadorRice: To all of you who served and are serving: we thank you for your bravery and sacrifice. #SaluteTroops",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SaluteTroops",
        "indices" : [ 87, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241581947690835968",
    "text" : "To all of you who served and are serving: we thank you for your bravery and sacrifice. #SaluteTroops",
    "id" : 241581947690835968,
    "created_at" : "2012-08-31 17:03:19 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 241590331227906048,
  "created_at" : "2012-08-31 17:36:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteTroops",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/is4l6SiX",
      "expanded_url" : "http:\/\/on.wh.gov\/XDQdMsJ",
      "display_url" : "on.wh.gov\/XDQdMsJ"
    } ]
  },
  "geo" : { },
  "id_str" : "241583566230798336",
  "text" : "At 3ET President Obama will speak to troops at Fort Bliss. WH Natl Security Advisor Ben Rhodes previews: http:\/\/t.co\/is4l6SiX #SaluteTroops",
  "id" : 241583566230798336,
  "created_at" : "2012-08-31 17:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/241567241034952704\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/N360E7JR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1o4IDfCcAEK9O1.jpg",
      "id_str" : "241567241043341313",
      "id" : 241567241043341313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1o4IDfCcAEK9O1.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/N360E7JR"
    } ],
    "hashtags" : [ {
      "text" : "SaluteTroops",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/GZJ0IBoZ",
      "expanded_url" : "http:\/\/on.wh.gov\/cF0KUID",
      "display_url" : "on.wh.gov\/cF0KUID"
    } ]
  },
  "geo" : { },
  "id_str" : "241567241034952704",
  "text" : "President Obama to troops: \"All of you represent what is best in America\" Join us &amp; #SaluteTroops: http:\/\/t.co\/GZJ0IBoZ http:\/\/t.co\/N360E7JR",
  "id" : 241567241034952704,
  "created_at" : "2012-08-31 16:04:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christi Hogin",
      "screen_name" : "ChristiHogin",
      "indices" : [ 3, 16 ],
      "id_str" : "30400612",
      "id" : 30400612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteTroops",
      "indices" : [ 18, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241565111595188225",
  "text" : "RT @ChristiHogin: #SaluteTroops Thanks to our USA troops and their families for their sacrifice and commitment",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SaluteTroops",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241555880062103552",
    "text" : "#SaluteTroops Thanks to our USA troops and their families for their sacrifice and commitment",
    "id" : 241555880062103552,
    "created_at" : "2012-08-31 15:19:44 +0000",
    "user" : {
      "name" : "Christi Hogin",
      "screen_name" : "ChristiHogin",
      "protected" : false,
      "id_str" : "30400612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1568546655\/_endof_rainbow_normal.jpg",
      "id" : 30400612,
      "verified" : false
    }
  },
  "id" : 241565111595188225,
  "created_at" : "2012-08-31 15:56:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteTroops",
      "indices" : [ 59, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/9JJFwjsL",
      "expanded_url" : "http:\/\/on.wh.gov\/LRx9Euz",
      "display_url" : "on.wh.gov\/LRx9Euz"
    } ]
  },
  "geo" : { },
  "id_str" : "241543024939761666",
  "text" : "Today marks two years since the end of combat in Iraq. Use #SaluteTroops to say thanks to our troops &amp; their families: http:\/\/t.co\/9JJFwjsL",
  "id" : 241543024939761666,
  "created_at" : "2012-08-31 14:28:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteTroops",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/y691z2wG",
      "expanded_url" : "http:\/\/on.wh.gov\/etz9wMs",
      "display_url" : "on.wh.gov\/etz9wMs"
    } ]
  },
  "geo" : { },
  "id_str" : "241312191385579520",
  "text" : "On 8\/31\/10 President Obama traveled to Ft Bliss to mark the end of combat in Iraq. Tomorrow he'll return: http:\/\/t.co\/y691z2wG #SaluteTroops",
  "id" : 241312191385579520,
  "created_at" : "2012-08-30 23:11:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241296816723873792",
  "text" : "Photo of the Day: President Obama greets people in Charlottesville, Virginia &amp; reacts after recognizing actress Sissy Spacek in the crowd:",
  "id" : 241296816723873792,
  "created_at" : "2012-08-30 22:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteTroops",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/QFWFu8vm",
      "expanded_url" : "http:\/\/on.wh.gov\/AmWNstZ",
      "display_url" : "on.wh.gov\/AmWNstZ"
    } ]
  },
  "geo" : { },
  "id_str" : "241280946505129985",
  "text" : "Salute the Troops: Two Years After the End of Combat Missions in Iraq: http:\/\/t.co\/QFWFu8vm Share your message of thanks w\/ #SaluteTroops",
  "id" : 241280946505129985,
  "created_at" : "2012-08-30 21:07:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/Q9pZEFJu",
      "expanded_url" : "http:\/\/at.wh.gov\/dm0NG",
      "display_url" : "at.wh.gov\/dm0NG"
    } ]
  },
  "geo" : { },
  "id_str" : "241245445781876736",
  "text" : "RT @JoiningForces: Say thanks &amp; show your support for those that serve &amp; their families: http:\/\/t.co\/Q9pZEFJu Share your message ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SaluteTroops",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/Q9pZEFJu",
        "expanded_url" : "http:\/\/at.wh.gov\/dm0NG",
        "display_url" : "at.wh.gov\/dm0NG"
      } ]
    },
    "geo" : { },
    "id_str" : "241240544804737025",
    "text" : "Say thanks &amp; show your support for those that serve &amp; their families: http:\/\/t.co\/Q9pZEFJu Share your message with #SaluteTroops",
    "id" : 241240544804737025,
    "created_at" : "2012-08-30 18:26:42 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 241245445781876736,
  "created_at" : "2012-08-30 18:46:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 1, 13 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Insourcing",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/1NiShUWU",
      "expanded_url" : "http:\/\/on.wh.gov\/lQnN684",
      "display_url" : "on.wh.gov\/lQnN684"
    } ]
  },
  "geo" : { },
  "id_str" : "241185474188812288",
  "text" : ".@CommerceGov Acting Secretary Blank Talks #Insourcing &amp; Job Creation at Economic Development Forum: http:\/\/t.co\/1NiShUWU",
  "id" : 241185474188812288,
  "created_at" : "2012-08-30 14:47:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 3, 10 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241027429358006273",
  "text" : "MT @DHSgov: Phone lines may be congested during\/after #Isaac. Let loved ones know you're OK by sending a text or updating social networks.",
  "id" : 241027429358006273,
  "created_at" : "2012-08-30 04:19:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Paralympics",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240930130690703360",
  "text" : "To all our athletes competing at the London 2012 #Paralympics, our country could not be prouder of you. -mo",
  "id" : 240930130690703360,
  "created_at" : "2012-08-29 21:53:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "London 2012",
      "screen_name" : "London2012",
      "indices" : [ 45, 56 ],
      "id_str" : "19900778",
      "id" : 19900778
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Paralympics",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240929422591528960",
  "text" : "RT @VP: Best wishes to athletes competing in @London2012 #Paralympics &amp; thank you for showing us what it looks like to triumph over  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "London 2012",
        "screen_name" : "London2012",
        "indices" : [ 37, 48 ],
        "id_str" : "19900778",
        "id" : 19900778
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Paralympics",
        "indices" : [ 49, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "240918439894601728",
    "text" : "Best wishes to athletes competing in @London2012 #Paralympics &amp; thank you for showing us what it looks like to triumph over adversity.\u2013Dr. B",
    "id" : 240918439894601728,
    "created_at" : "2012-08-29 21:06:46 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 240929422591528960,
  "created_at" : "2012-08-29 21:50:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 67, 78 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/240896616830222337\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/FpaS4UV3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1fWMloCQAEuA0v.jpg",
      "id_str" : "240896616834416641",
      "id" : 240896616834416641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1fWMloCQAEuA0v.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FpaS4UV3"
    } ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240896616830222337",
  "text" : "Photo of the Day: President Obama walks along the Colonnade of the @whitehouse before speaking on #Isaac: http:\/\/t.co\/FpaS4UV3",
  "id" : 240896616830222337,
  "created_at" : "2012-08-29 19:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "NOLA Ready",
      "screen_name" : "nolaready",
      "indices" : [ 19, 29 ],
      "id_str" : "70535360",
      "id" : 70535360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240875018844790784",
  "text" : "RT @fema: 8\/29 via @nolaready: Call 311 for questions\/non-emergency issues like downed lines\/trees, flooding. Call 911 for emergencies # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NOLA Ready",
        "screen_name" : "nolaready",
        "indices" : [ 9, 19 ],
        "id_str" : "70535360",
        "id" : 70535360
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Isaac",
        "indices" : [ 125, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "240816648213368833",
    "text" : "8\/29 via @nolaready: Call 311 for questions\/non-emergency issues like downed lines\/trees, flooding. Call 911 for emergencies #Isaac",
    "id" : 240816648213368833,
    "created_at" : "2012-08-29 14:22:17 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 240875018844790784,
  "created_at" : "2012-08-29 18:14:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/61oibJjP",
      "expanded_url" : "http:\/\/on.wh.gov\/IyBDSnd",
      "display_url" : "on.wh.gov\/IyBDSnd"
    } ]
  },
  "geo" : { },
  "id_str" : "240864212627386371",
  "text" : "Update on Hurricane #Isaac: More information about the ongoing response efforts &amp; useful safety information: http:\/\/t.co\/61oibJjP",
  "id" : 240864212627386371,
  "created_at" : "2012-08-29 17:31:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/Qm0TrSQ9",
      "expanded_url" : "http:\/\/on.wh.gov\/nKo6I8s",
      "display_url" : "on.wh.gov\/nKo6I8s"
    } ]
  },
  "geo" : { },
  "id_str" : "240843374213619714",
  "text" : "Update on Hurricane #Isaac: More information about the ongoing response efforts &amp; useful safety information: http:\/\/t.co\/Qm0TrSQ9",
  "id" : 240843374213619714,
  "created_at" : "2012-08-29 16:08:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 10, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240822717220274176",
  "text" : "RT @fema: #Isaac Let friends\/family know you're OK by sending a text or updating your social networks. Limit voice calls to emergencies  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Isaac",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "240613693979758592",
    "text" : "#Isaac Let friends\/family know you're OK by sending a text or updating your social networks. Limit voice calls to emergencies only.",
    "id" : 240613693979758592,
    "created_at" : "2012-08-29 00:55:49 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 240822717220274176,
  "created_at" : "2012-08-29 14:46:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "readydotgov",
      "screen_name" : "Readydotgov",
      "indices" : [ 48, 60 ],
      "id_str" : "1454016942",
      "id" : 1454016942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/3YB7UaTy",
      "expanded_url" : "http:\/\/on.wh.gov\/3k90GKD",
      "display_url" : "on.wh.gov\/3k90GKD"
    } ]
  },
  "geo" : { },
  "id_str" : "240794453965680641",
  "text" : "Hurricane safety tips: http:\/\/t.co\/3YB7UaTy via @ReadydotGov",
  "id" : 240794453965680641,
  "created_at" : "2012-08-29 12:54:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "readydotgov",
      "screen_name" : "Readydotgov",
      "indices" : [ 108, 120 ],
      "id_str" : "1454016942",
      "id" : 1454016942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/NBY7Ty45",
      "expanded_url" : "http:\/\/on.wh.gov\/wOjMDCD",
      "display_url" : "on.wh.gov\/wOjMDCD"
    }, {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/MareMkYv",
      "expanded_url" : "http:\/\/on.wh.gov\/7csDq2d",
      "display_url" : "on.wh.gov\/7csDq2d"
    } ]
  },
  "geo" : { },
  "id_str" : "240661462002044928",
  "text" : "President Obama discusses preparations for Hurricane #Isaac: http:\/\/t.co\/NBY7Ty45 &amp; see safety tips via @ReadydotGov: http:\/\/t.co\/MareMkYv",
  "id" : 240661462002044928,
  "created_at" : "2012-08-29 04:05:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/240588201411084288\/photo\/1",
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/bTiAY7EF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1a9scqCAAAnkcK.jpg",
      "id_str" : "240588201415278592",
      "id" : 240588201415278592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1a9scqCAAAnkcK.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1021,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 697,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/bTiAY7EF"
    } ],
    "hashtags" : [ {
      "text" : "efficiency",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/3ELaZRFG",
      "expanded_url" : "http:\/\/on.wh.gov\/ql2SWVP",
      "display_url" : "on.wh.gov\/ql2SWVP"
    } ]
  },
  "geo" : { },
  "id_str" : "240588201411084288",
  "text" : "Obama Admin finalizes historic fuel #efficiency standards for cars &amp; light trucks: http:\/\/t.co\/3ELaZRFG Infographic: http:\/\/t.co\/bTiAY7EF",
  "id" : 240588201411084288,
  "created_at" : "2012-08-28 23:14:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 33, 40 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/vNdf4CQ5",
      "expanded_url" : "http:\/\/at.wh.gov\/dinwY",
      "display_url" : "at.wh.gov\/dinwY"
    } ]
  },
  "geo" : { },
  "id_str" : "240527938917892097",
  "text" : "Share Your Small Business Story: @SBAgov's new online feature highlights the voices of #smallbiz owners: http:\/\/t.co\/vNdf4CQ5",
  "id" : 240527938917892097,
  "created_at" : "2012-08-28 19:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 24, 35 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "emissions",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240502738285379585",
  "text" : "RT @RayLaHood: Historic @whitehouse fuel efficiency rule for cars, light trucks will save families $$, reduce #emissions http:\/\/t.co\/9N6 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 9, 20 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "emissions",
        "indices" : [ 95, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/9N6sGBZ8",
        "expanded_url" : "http:\/\/1.usa.gov\/POp3j1",
        "display_url" : "1.usa.gov\/POp3j1"
      } ]
    },
    "geo" : { },
    "id_str" : "240496054678728704",
    "text" : "Historic @whitehouse fuel efficiency rule for cars, light trucks will save families $$, reduce #emissions http:\/\/t.co\/9N6sGBZ8",
    "id" : 240496054678728704,
    "created_at" : "2012-08-28 17:08:22 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 240502738285379585,
  "created_at" : "2012-08-28 17:34:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "readydotgov",
      "screen_name" : "Readydotgov",
      "indices" : [ 104, 116 ],
      "id_str" : "1454016942",
      "id" : 1454016942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/NoMjgyX8",
      "expanded_url" : "http:\/\/at.wh.gov\/di8jd",
      "display_url" : "at.wh.gov\/di8jd"
    }, {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/B8wonLfJ",
      "expanded_url" : "http:\/\/Ready.gov",
      "display_url" : "Ready.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "240486928175210496",
  "text" : "Watch: President Obama discusses preparations for Tropical Storm #Isaac: http:\/\/t.co\/NoMjgyX8 More info @readydotgov &amp; http:\/\/t.co\/B8wonLfJ",
  "id" : 240486928175210496,
  "created_at" : "2012-08-28 16:32:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 132, 139 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/Gn5oCP2p",
      "expanded_url" : "http:\/\/on.wh.gov\/eSoiPKh",
      "display_url" : "on.wh.gov\/eSoiPKh"
    } ]
  },
  "geo" : { },
  "id_str" : "240451260573179905",
  "text" : "Happening now: President Obama delivers a statement on Tropical Storm #Isaac from the WH. Watch: http:\/\/t.co\/Gn5oCP2p &amp; follow: @WHLive",
  "id" : 240451260573179905,
  "created_at" : "2012-08-28 14:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 126, 133 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/cUoOJ7ic",
      "expanded_url" : "http:\/\/on.wh.gov\/P8gEw1A",
      "display_url" : "on.wh.gov\/P8gEw1A"
    } ]
  },
  "geo" : { },
  "id_str" : "240446669412503552",
  "text" : "Happening at 10:00ET: President Obama delivers a statement on Tropical Storm #Isaac. Watch live: http:\/\/t.co\/cUoOJ7ic Follow: @whlive",
  "id" : 240446669412503552,
  "created_at" : "2012-08-28 13:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "readydotgov",
      "screen_name" : "Readydotgov",
      "indices" : [ 107, 119 ],
      "id_str" : "1454016942",
      "id" : 1454016942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/wChf73WO",
      "expanded_url" : "http:\/\/on.wh.gov\/5TLOjP4",
      "display_url" : "on.wh.gov\/5TLOjP4"
    }, {
      "indices" : [ 126, 146 ],
      "url" : "http:\/\/t.co\/B8wonLfJ",
      "expanded_url" : "http:\/\/Ready.gov",
      "display_url" : "Ready.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "240237422925996032",
  "text" : "Preparing for #Isaac: http:\/\/t.co\/wChf73WO You can learn what to do before, during &amp; after a hurricane @ReadydotGov &amp; http:\/\/t.co\/B8wonLfJ",
  "id" : 240237422925996032,
  "created_at" : "2012-08-28 00:00:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/240182661774192640\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/bTu0VZ09",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1VM27yCMAEGmq7.jpg",
      "id_str" : "240182661778386945",
      "id" : 240182661778386945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1VM27yCMAEGmq7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/bTu0VZ09"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/696SvzOX",
      "expanded_url" : "http:\/\/on.wh.gov\/mxluGhK",
      "display_url" : "on.wh.gov\/mxluGhK"
    } ]
  },
  "geo" : { },
  "id_str" : "240182661774192640",
  "text" : "Photo Gallery: Remembering Neil Armstrong: http:\/\/t.co\/696SvzOX Photo: Armstrong after his historic moonwalk: http:\/\/t.co\/bTu0VZ09",
  "id" : 240182661774192640,
  "created_at" : "2012-08-27 20:23:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/EwS3WZJy",
      "expanded_url" : "http:\/\/go.nasa.gov\/Pn9Zbn",
      "display_url" : "go.nasa.gov\/Pn9Zbn"
    } ]
  },
  "geo" : { },
  "id_str" : "240141843025784833",
  "text" : "RT @NASA: A @whitehouse\u00A0flags flown at half-staff proclamation was issued on the passing of Neil Armstrong. http:\/\/t.co\/EwS3WZJy #WinkAt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 2, 13 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WinkAtTheMoon",
        "indices" : [ 119, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/EwS3WZJy",
        "expanded_url" : "http:\/\/go.nasa.gov\/Pn9Zbn",
        "display_url" : "go.nasa.gov\/Pn9Zbn"
      } ]
    },
    "geo" : { },
    "id_str" : "240141620400500736",
    "text" : "A @whitehouse\u00A0flags flown at half-staff proclamation was issued on the passing of Neil Armstrong. http:\/\/t.co\/EwS3WZJy #WinkAtTheMoon",
    "id" : 240141620400500736,
    "created_at" : "2012-08-27 17:39:58 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 240141843025784833,
  "created_at" : "2012-08-27 17:40:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "readydotgov",
      "screen_name" : "Readydotgov",
      "indices" : [ 3, 15 ],
      "id_str" : "1454016942",
      "id" : 1454016942
    }, {
      "name" : "NOLA Ready",
      "screen_name" : "nolaready",
      "indices" : [ 50, 60 ],
      "id_str" : "70535360",
      "id" : 70535360
    }, {
      "name" : "Louisiana GOHSEP",
      "screen_name" : "GOHSEP",
      "indices" : [ 116, 123 ],
      "id_str" : "41351252",
      "id" : 41351252
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/91fg059v",
      "expanded_url" : "http:\/\/ready.nola.gov",
      "display_url" : "ready.nola.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "240135763788959746",
  "text" : "RT @ReadydotGov: For those in New Orleans, follow @nolaready &amp; visit http:\/\/t.co\/91fg059v for #Isaac updates cc @GOHSEP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NOLA Ready",
        "screen_name" : "nolaready",
        "indices" : [ 33, 43 ],
        "id_str" : "70535360",
        "id" : 70535360
      }, {
        "name" : "Louisiana GOHSEP",
        "screen_name" : "GOHSEP",
        "indices" : [ 99, 106 ],
        "id_str" : "41351252",
        "id" : 41351252
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Isaac",
        "indices" : [ 81, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/91fg059v",
        "expanded_url" : "http:\/\/ready.nola.gov",
        "display_url" : "ready.nola.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "240128001071804416",
    "text" : "For those in New Orleans, follow @nolaready &amp; visit http:\/\/t.co\/91fg059v for #Isaac updates cc @GOHSEP",
    "id" : 240128001071804416,
    "created_at" : "2012-08-27 16:45:51 +0000",
    "user" : {
      "name" : "Readygov",
      "screen_name" : "Readygov",
      "protected" : false,
      "id_str" : "16028241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646417752811532288\/D4M4w2f0_normal.jpg",
      "id" : 16028241,
      "verified" : true
    }
  },
  "id" : 240135763788959746,
  "created_at" : "2012-08-27 17:16:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 29, 41 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/Np2Upqiw",
      "expanded_url" : "http:\/\/on.wh.gov\/DYSI4JM",
      "display_url" : "on.wh.gov\/DYSI4JM"
    } ]
  },
  "geo" : { },
  "id_str" : "239707516144070657",
  "text" : "We the Coders: Open-Sourcing @WethePeople, the White House's Online Petitions System: http:\/\/t.co\/Np2Upqiw",
  "id" : 239707516144070657,
  "created_at" : "2012-08-26 12:55:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/239505971305668609\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/VTfzvACN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1LlaXWCYAAadZe.jpg",
      "id_str" : "239505971309862912",
      "id" : 239505971309862912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1LlaXWCYAAadZe.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 525
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VTfzvACN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/2Ho0ybDG",
      "expanded_url" : "http:\/\/on.wh.gov\/yqvhNCJ",
      "display_url" : "on.wh.gov\/yqvhNCJ"
    } ]
  },
  "geo" : { },
  "id_str" : "239505971305668609",
  "text" : "\"Today, Neil's spirit of discovery lives on\" -President Obama http:\/\/t.co\/2Ho0ybDG Pic w\/ Apollo 11 astronauts in '09: http:\/\/t.co\/VTfzvACN",
  "id" : 239505971305668609,
  "created_at" : "2012-08-25 23:34:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239497824465727488",
  "text" : "RT @VP: \"There may be no American who taught us more about ourselves, and what we are capable of achieving, than Neil Armstrong.\"  --VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "239497399981195265",
    "text" : "\"There may be no American who taught us more about ourselves, and what we are capable of achieving, than Neil Armstrong.\"  --VP",
    "id" : 239497399981195265,
    "created_at" : "2012-08-25 23:00:04 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 239497824465727488,
  "created_at" : "2012-08-25 23:01:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/yVzyOVGQ",
      "expanded_url" : "http:\/\/on.wh.gov\/4KZLX4J",
      "display_url" : "on.wh.gov\/4KZLX4J"
    } ]
  },
  "geo" : { },
  "id_str" : "239490146465107968",
  "text" : "Neil Armstrong \"was among the greatest of American heroes - not just of his time, but of all time\" -President Obama: http:\/\/t.co\/yVzyOVGQ",
  "id" : 239490146465107968,
  "created_at" : "2012-08-25 22:31:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Medicare",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 128, 148 ],
      "url" : "http:\/\/t.co\/LsXHLwK0",
      "expanded_url" : "http:\/\/on.wh.gov\/VzqTn1y",
      "display_url" : "on.wh.gov\/VzqTn1y"
    } ]
  },
  "geo" : { },
  "id_str" : "239420007518457856",
  "text" : "President Obama speaks about the critical need to strengthen &amp; preserve #Medicare for our seniors &amp; future generations: http:\/\/t.co\/LsXHLwK0",
  "id" : 239420007518457856,
  "created_at" : "2012-08-25 17:52:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/239355308319842304\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/1OYZ5fqA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1JcYoGCIAAMvse.jpg",
      "id_str" : "239355308353396736",
      "id" : 239355308353396736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1JcYoGCIAAMvse.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1OYZ5fqA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/OWSPNbFV",
      "expanded_url" : "http:\/\/on.wh.gov\/0ZxzFUr",
      "display_url" : "on.wh.gov\/0ZxzFUr"
    } ]
  },
  "geo" : { },
  "id_str" : "239355308319842304",
  "text" : "\"It's my honor to be here with you\" -First Lady Michelle Obama visits Sikh Community in Wisconsin: http:\/\/t.co\/OWSPNbFV http:\/\/t.co\/1OYZ5fqA",
  "id" : 239355308319842304,
  "created_at" : "2012-08-25 13:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 66, 75 ]
    }, {
      "text" : "JoiningForces",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/vZGE8KDQ",
      "expanded_url" : "http:\/\/on.wh.gov\/W1AcIIs",
      "display_url" : "on.wh.gov\/W1AcIIs"
    } ]
  },
  "geo" : { },
  "id_str" : "239203141038534656",
  "text" : "Go behind-the-scenes: First Lady Michelle Obama announces 125,000 #veterans hired through #JoiningForces: http:\/\/t.co\/vZGE8KDQ",
  "id" : 239203141038534656,
  "created_at" : "2012-08-25 03:30:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 61, 72 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 36, 52 ]
    }, {
      "text" : "innovategov",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/IPXsuu7i",
      "expanded_url" : "http:\/\/on.wh.gov\/ROAZ6it",
      "display_url" : "on.wh.gov\/ROAZ6it"
    } ]
  },
  "geo" : { },
  "id_str" : "239155025610428416",
  "text" : "This week, @whitehouse held the 1st #KidsStateDinner; hosted @AmeriCorps, launched #innovategov fellows &amp; more. Watch: http:\/\/t.co\/IPXsuu7i",
  "id" : 239155025610428416,
  "created_at" : "2012-08-25 00:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/239081945827516416\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/pNjufQue",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1Fjw1XCIAAULE4.jpg",
      "id_str" : "239081945835905024",
      "id" : 239081945835905024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1Fjw1XCIAAULE4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1209,
        "resize" : "fit",
        "w" : 1813
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pNjufQue"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239081945827516416",
  "text" : "Photo of the Day: President Obama walks from the Oval Office w\/ Chief of Staff Jack Lew &amp; Sr Advisor David Plouffe: http:\/\/t.co\/pNjufQue",
  "id" : 239081945827516416,
  "created_at" : "2012-08-24 19:29:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "AAPD",
      "screen_name" : "AAPD",
      "indices" : [ 32, 37 ],
      "id_str" : "16026940",
      "id" : 16026940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239074945433485312",
  "text" : "RT @vj44: President Obama met w @AAPD interns to hear thoughts on policy that could positively impact people w disabilities Watch http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AAPD",
        "screen_name" : "AAPD",
        "indices" : [ 22, 27 ],
        "id_str" : "16026940",
        "id" : 16026940
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/WBxXv88M",
        "expanded_url" : "http:\/\/wh.gov\/TA52",
        "display_url" : "wh.gov\/TA52"
      } ]
    },
    "geo" : { },
    "id_str" : "239049931573297152",
    "text" : "President Obama met w @AAPD interns to hear thoughts on policy that could positively impact people w disabilities Watch http:\/\/t.co\/WBxXv88M",
    "id" : 239049931573297152,
    "created_at" : "2012-08-24 17:21:59 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 239074945433485312,
  "created_at" : "2012-08-24 19:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "TODAYMoney",
      "screen_name" : "TODAYmoney",
      "indices" : [ 75, 86 ],
      "id_str" : "191103309",
      "id" : 191103309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/3pAEwmCj",
      "expanded_url" : "http:\/\/on.today.com\/PzOtnF",
      "display_url" : "on.today.com\/PzOtnF"
    } ]
  },
  "geo" : { },
  "id_str" : "238996196956454912",
  "text" : "RT @arneduncan: Join me today at 11ET for a chat on the cost of college w\/ @todaymoney. Ask your Qs here: http:\/\/t.co\/3pAEwmCj\u00A0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TODAYMoney",
        "screen_name" : "TODAYmoney",
        "indices" : [ 59, 70 ],
        "id_str" : "191103309",
        "id" : 191103309
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/3pAEwmCj",
        "expanded_url" : "http:\/\/on.today.com\/PzOtnF",
        "display_url" : "on.today.com\/PzOtnF"
      } ]
    },
    "geo" : { },
    "id_str" : "238995358959673344",
    "text" : "Join me today at 11ET for a chat on the cost of college w\/ @todaymoney. Ask your Qs here: http:\/\/t.co\/3pAEwmCj\u00A0",
    "id" : 238995358959673344,
    "created_at" : "2012-08-24 13:45:08 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 238996196956454912,
  "created_at" : "2012-08-24 13:48:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 70, 84 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/238974763446452224\/photo\/1",
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/1GACtBM4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1ECR_3CQAA-xx7.jpg",
      "id_str" : "238974763450646528",
      "id" : 238974763450646528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1ECR_3CQAA-xx7.jpg",
      "sizes" : [ {
        "h" : 1212,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 426
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 241
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1212,
        "resize" : "fit",
        "w" : 430
      } ],
      "display_url" : "pic.twitter.com\/1GACtBM4"
    } ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238974763446452224",
  "text" : "Infographic: 125,000+ #veterans &amp; military families hired through @JoiningForces: http:\/\/t.co\/1GACtBM4",
  "id" : 238974763446452224,
  "created_at" : "2012-08-24 12:23:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 43, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/mKtFUJ7G",
      "expanded_url" : "http:\/\/on.wh.gov\/tVD6k5",
      "display_url" : "on.wh.gov\/tVD6k5"
    } ]
  },
  "geo" : { },
  "id_str" : "238803605266767872",
  "text" : "First Lady Michelle Obama hosts first-ever #KidsStateDinner with 54 young chefs representing all US states: http:\/\/t.co\/mKtFUJ7G",
  "id" : 238803605266767872,
  "created_at" : "2012-08-24 01:03:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 31, 43 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/ae7HpeVt",
      "expanded_url" : "http:\/\/wh.gov\/4y9b",
      "display_url" : "wh.gov\/4y9b"
    } ]
  },
  "geo" : { },
  "id_str" : "238791425519661056",
  "text" : "RT @PressSec: Got a Q today on @wethepeople petition asking us to share WH beer recipe: http:\/\/t.co\/ae7HpeVt If it reaches the threshold ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 17, 29 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/ae7HpeVt",
        "expanded_url" : "http:\/\/wh.gov\/4y9b",
        "display_url" : "wh.gov\/4y9b"
      } ]
    },
    "geo" : { },
    "id_str" : "238787131328299008",
    "text" : "Got a Q today on @wethepeople petition asking us to share WH beer recipe: http:\/\/t.co\/ae7HpeVt If it reaches the threshold, we'll release it",
    "id" : 238787131328299008,
    "created_at" : "2012-08-23 23:57:43 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 238791425519661056,
  "created_at" : "2012-08-24 00:14:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 85, 97 ],
      "id_str" : "369507958",
      "id" : 369507958
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 120, 127 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/MjbHdu6I",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/08\/23\/open-sourcing-we-the-people",
      "display_url" : "whitehouse.gov\/blog\/2012\/08\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "238760894518153216",
  "text" : "RT @macon44: So very excited about what will come from publishing the source code of @wethepeople: http:\/\/t.co\/MjbHdu6I @Github: https:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 72, 84 ],
        "id_str" : "369507958",
        "id" : 369507958
      }, {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 107, 114 ],
        "id_str" : "13334762",
        "id" : 13334762
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/MjbHdu6I",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/08\/23\/open-sourcing-we-the-people",
        "display_url" : "whitehouse.gov\/blog\/2012\/08\/2\u2026"
      }, {
        "indices" : [ 116, 137 ],
        "url" : "https:\/\/t.co\/0BpuxZDN",
        "expanded_url" : "https:\/\/github.com\/WhiteHouse\/petition",
        "display_url" : "github.com\/WhiteHouse\/pet\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "238757700245278720",
    "text" : "So very excited about what will come from publishing the source code of @wethepeople: http:\/\/t.co\/MjbHdu6I @Github: https:\/\/t.co\/0BpuxZDN",
    "id" : 238757700245278720,
    "created_at" : "2012-08-23 22:00:46 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 238760894518153216,
  "created_at" : "2012-08-23 22:13:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 27, 37 ],
      "id_str" : "200176600",
      "id" : 200176600
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 44, 52 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovateGov",
      "indices" : [ 71, 83 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238746069838753792",
  "text" : "RT @WHLive: Happening now: @todd_park &amp; @macon44 answer your Qs on #InnovateGov. Ask now with #WHChat   Pic in action: http:\/\/t.co\/C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Todd Park",
        "screen_name" : "todd_park",
        "indices" : [ 15, 25 ],
        "id_str" : "200176600",
        "id" : 200176600
      }, {
        "name" : "former Macon44",
        "screen_name" : "macon44",
        "indices" : [ 32, 40 ],
        "id_str" : "776593497122082820",
        "id" : 776593497122082820
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/238745932127141888\/photo\/1",
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/CMeFWJYS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A1AyKQxCAAAxg5l.jpg",
        "id_str" : "238745932131336192",
        "id" : 238745932131336192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1AyKQxCAAAxg5l.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CMeFWJYS"
      } ],
      "hashtags" : [ {
        "text" : "InnovateGov",
        "indices" : [ 59, 71 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 86, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238745932127141888",
    "text" : "Happening now: @todd_park &amp; @macon44 answer your Qs on #InnovateGov. Ask now with #WHChat   Pic in action: http:\/\/t.co\/CMeFWJYS",
    "id" : 238745932127141888,
    "created_at" : "2012-08-23 21:14:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 238746069838753792,
  "created_at" : "2012-08-23 21:14:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 111, 121 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovateGov",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/f1KyuNhW",
      "expanded_url" : "http:\/\/on.wh.gov\/58t7UNC",
      "display_url" : "on.wh.gov\/58t7UNC"
    } ]
  },
  "geo" : { },
  "id_str" : "238736295353016320",
  "text" : "Got questions on the Presidential #InnovateGov Fellows? Ask now w\/ #WHChat &amp; join Office Hrs at 5ET w\/ CTO @Todd_Park: http:\/\/t.co\/f1KyuNhW",
  "id" : 238736295353016320,
  "created_at" : "2012-08-23 20:35:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovategov",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238718551404445697",
  "text" : "RT @vj44: I just met with Presidential Innovation Fellows; can't wait to hear about their work over next 6 months! #innovategov http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/238716001733189632\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/YttTcJbO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A1AW8FYCIAA4dNy.jpg",
        "id_str" : "238716001741578240",
        "id" : 238716001741578240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1AW8FYCIAA4dNy.jpg",
        "sizes" : [ {
          "h" : 544,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 319,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1087,
          "resize" : "fit",
          "w" : 2047
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/YttTcJbO"
      } ],
      "hashtags" : [ {
        "text" : "innovategov",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238716001733189632",
    "text" : "I just met with Presidential Innovation Fellows; can't wait to hear about their work over next 6 months! #innovategov http:\/\/t.co\/YttTcJbO",
    "id" : 238716001733189632,
    "created_at" : "2012-08-23 19:15:05 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 238718551404445697,
  "created_at" : "2012-08-23 19:25:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovategov",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/vu6coZfB",
      "expanded_url" : "http:\/\/on.wh.gov\/N59r9Uj",
      "display_url" : "on.wh.gov\/N59r9Uj"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/igkakhXS",
      "expanded_url" : "http:\/\/on.wh.gov\/ZqQY4r2",
      "display_url" : "on.wh.gov\/ZqQY4r2"
    } ]
  },
  "geo" : { },
  "id_str" : "238658529400070144",
  "text" : "Congrats to the 1st class of Presidential Innovation Fellows! Meet #innovategov Fellows: http:\/\/t.co\/vu6coZfB Watch: http:\/\/t.co\/igkakhXS",
  "id" : 238658529400070144,
  "created_at" : "2012-08-23 15:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Project MyGov",
      "screen_name" : "ProjectMyGov",
      "indices" : [ 3, 16 ],
      "id_str" : "1148446873",
      "id" : 1148446873
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyGov",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238653111059763200",
  "text" : "RT @ProjectMyGov: Ready to help reimagine the relationship between people and government? It\u2019s time for Project #MyGov. Let\u2019s do this. h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyGov",
        "indices" : [ 94, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/SLAVbAeE",
        "expanded_url" : "http:\/\/bit.ly\/mygov01",
        "display_url" : "bit.ly\/mygov01"
      } ]
    },
    "geo" : { },
    "id_str" : "238649320960835585",
    "text" : "Ready to help reimagine the relationship between people and government? It\u2019s time for Project #MyGov. Let\u2019s do this. http:\/\/t.co\/SLAVbAeE",
    "id" : 238649320960835585,
    "created_at" : "2012-08-23 14:50:06 +0000",
    "user" : {
      "name" : "MyUSA",
      "screen_name" : "MyUSA",
      "protected" : false,
      "id_str" : "588309140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618246685777633281\/tQgeszvZ_normal.png",
      "id" : 588309140,
      "verified" : true
    }
  },
  "id" : 238653111059763200,
  "created_at" : "2012-08-23 15:05:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238642177662668800",
  "text" : "RT @macon44: Such an impressive &amp; humbling lineup of Americans ready 2 serve as Presidential Innovation Fellows. Watch: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "innovategov",
        "indices" : [ 132, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/d6ORQoJo",
        "expanded_url" : "http:\/\/WH.gov\/live",
        "display_url" : "WH.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "238641400667860992",
    "text" : "Such an impressive &amp; humbling lineup of Americans ready 2 serve as Presidential Innovation Fellows. Watch: http:\/\/t.co\/d6ORQoJo #innovategov",
    "id" : 238641400667860992,
    "created_at" : "2012-08-23 14:18:38 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 238642177662668800,
  "created_at" : "2012-08-23 14:21:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 13, 23 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238640668166193152",
  "text" : "RT @WHLive: .@Todd_Park \u201CWe\u2019ve come together today to celebrate the launch... of the Presidential Innovation Fellows\u201D http:\/\/t.co\/g5icuV ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Todd Park",
        "screen_name" : "todd_park",
        "indices" : [ 1, 11 ],
        "id_str" : "200176600",
        "id" : 200176600
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "innovategov",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "238639124532314112",
    "text" : ".@Todd_Park \u201CWe\u2019ve come together today to celebrate the launch... of the Presidential Innovation Fellows\u201D http:\/\/t.co\/g5icuVZL #innovategov",
    "id" : 238639124532314112,
    "created_at" : "2012-08-23 14:09:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 238640668166193152,
  "created_at" : "2012-08-23 14:15:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 123, 130 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovategov",
      "indices" : [ 131, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/7CvhyFLm",
      "expanded_url" : "http:\/\/on.wh.gov\/EWa5iYi",
      "display_url" : "on.wh.gov\/EWa5iYi"
    } ]
  },
  "geo" : { },
  "id_str" : "238638297117765632",
  "text" : "Happening now: @WhiteHouse launches Presidential Innovation Fellows program. Watch live: http:\/\/t.co\/7CvhyFLm &amp; follow @WHLive #innovategov",
  "id" : 238638297117765632,
  "created_at" : "2012-08-23 14:06:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 3, 13 ],
      "id_str" : "6708952",
      "id" : 6708952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/okl2zfzW",
      "expanded_url" : "http:\/\/ow.ly\/daOOF",
      "display_url" : "ow.ly\/daOOF"
    } ]
  },
  "geo" : { },
  "id_str" : "238633263793569792",
  "text" : "RT @SteveCase: Presidential Innovation Fellows: top innovators collaborate to deliver results in 6 months http:\/\/t.co\/okl2zfzW @WhiteHou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 112, 123 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "innovategov",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/okl2zfzW",
        "expanded_url" : "http:\/\/ow.ly\/daOOF",
        "display_url" : "ow.ly\/daOOF"
      } ]
    },
    "geo" : { },
    "id_str" : "238620374567383041",
    "text" : "Presidential Innovation Fellows: top innovators collaborate to deliver results in 6 months http:\/\/t.co\/okl2zfzW @WhiteHouse #innovategov",
    "id" : 238620374567383041,
    "created_at" : "2012-08-23 12:55:05 +0000",
    "user" : {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "protected" : false,
      "id_str" : "6708952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708164499014987780\/w8TcvuF0_normal.jpg",
      "id" : 6708952,
      "verified" : true
    }
  },
  "id" : 238633263793569792,
  "created_at" : "2012-08-23 13:46:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/238601179721003008\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/vdZAzK94",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0-ugkCCcAAtxsf.jpg",
      "id_str" : "238601179725197312",
      "id" : 238601179725197312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0-ugkCCcAAtxsf.jpg",
      "sizes" : [ {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      } ],
      "display_url" : "pic.twitter.com\/vdZAzK94"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/6SIxLo5G",
      "expanded_url" : "http:\/\/on.wh.gov\/wRLP9A",
      "display_url" : "on.wh.gov\/wRLP9A"
    } ]
  },
  "geo" : { },
  "id_str" : "238601179721003008",
  "text" : "11 facts about the tax debate: http:\/\/t.co\/6SIxLo5G Republicans' plan would add $1 trillion to the deficit over 10 yrs: http:\/\/t.co\/vdZAzK94",
  "id" : 238601179721003008,
  "created_at" : "2012-08-23 11:38:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 80, 94 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/238406056164872192\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/fn9JpPF0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A079C4JCUAE0VNa.jpg",
      "id_str" : "238406056169066497",
      "id" : 238406056169066497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A079C4JCUAE0VNa.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fn9JpPF0"
    } ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/wwEgbYKL",
      "expanded_url" : "http:\/\/on.wh.gov\/hmZNPe0",
      "display_url" : "on.wh.gov\/hmZNPe0"
    } ]
  },
  "geo" : { },
  "id_str" : "238406056164872192",
  "text" : "The First Lady announces 125,000 #veterans &amp; military spouses hired through @JoiningForces: http:\/\/t.co\/wwEgbYKL Pic: http:\/\/t.co\/fn9JpPF0",
  "id" : 238406056164872192,
  "created_at" : "2012-08-22 22:43:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    }, {
      "name" : "GLEE",
      "screen_name" : "GLEEonFOX",
      "indices" : [ 23, 33 ],
      "id_str" : "30104231",
      "id" : 30104231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "safety",
      "indices" : [ 56, 63 ]
    }, {
      "text" : "distracteddriving",
      "indices" : [ 86, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/c7fns0zg",
      "expanded_url" : "http:\/\/1.usa.gov\/SnnM6P",
      "display_url" : "1.usa.gov\/SnnM6P"
    } ]
  },
  "geo" : { },
  "id_str" : "238388237155053570",
  "text" : "RT @RayLaHood: Cast of @GLEEonFOX delivers powerful DOT #safety message on dangers of #distracteddriving. http:\/\/t.co\/c7fns0zg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GLEE",
        "screen_name" : "GLEEonFOX",
        "indices" : [ 8, 18 ],
        "id_str" : "30104231",
        "id" : 30104231
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "safety",
        "indices" : [ 41, 48 ]
      }, {
        "text" : "distracteddriving",
        "indices" : [ 71, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/c7fns0zg",
        "expanded_url" : "http:\/\/1.usa.gov\/SnnM6P",
        "display_url" : "1.usa.gov\/SnnM6P"
      } ]
    },
    "geo" : { },
    "id_str" : "238265591272706049",
    "text" : "Cast of @GLEEonFOX delivers powerful DOT #safety message on dangers of #distracteddriving. http:\/\/t.co\/c7fns0zg",
    "id" : 238265591272706049,
    "created_at" : "2012-08-22 13:25:18 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 238388237155053570,
  "created_at" : "2012-08-22 21:32:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 27, 41 ]
    }, {
      "text" : "vets",
      "indices" : [ 50, 55 ]
    }, {
      "text" : "milspouses",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238335677392121856",
  "text" : "RT @JoiningForces: Through #JoiningForces 125,000 #vets &amp; #milspouses have been hired or trained- this video shares some of their st ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 8, 22 ]
      }, {
        "text" : "vets",
        "indices" : [ 31, 36 ]
      }, {
        "text" : "milspouses",
        "indices" : [ 43, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/UmktV65z",
        "expanded_url" : "http:\/\/youtu.be\/owLK7ZJYKGU",
        "display_url" : "youtu.be\/owLK7ZJYKGU"
      } ]
    },
    "geo" : { },
    "id_str" : "238334636911108096",
    "text" : "Through #JoiningForces 125,000 #vets &amp; #milspouses have been hired or trained- this video shares some of their stories: http:\/\/t.co\/UmktV65z",
    "id" : 238334636911108096,
    "created_at" : "2012-08-22 17:59:40 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 238335677392121856,
  "created_at" : "2012-08-22 18:03:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 79, 88 ]
    }, {
      "text" : "milspouses",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238329624562634752",
  "text" : "RT @JoiningForces: First Lady: As of today, they have hired or trained 125,000 #veterans &amp; #milspouses \u2026 more than a year ahead of s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 60, 69 ]
      }, {
        "text" : "milspouses",
        "indices" : [ 76, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "238329575854198785",
    "text" : "First Lady: As of today, they have hired or trained 125,000 #veterans &amp; #milspouses \u2026 more than a year ahead of schedule",
    "id" : 238329575854198785,
    "created_at" : "2012-08-22 17:39:33 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 238329624562634752,
  "created_at" : "2012-08-22 17:39:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 108, 122 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 56, 65 ]
    }, {
      "text" : "milspouse",
      "indices" : [ 72, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/NJtB2Zhs",
      "expanded_url" : "http:\/\/on.wh.gov\/fovAW33",
      "display_url" : "on.wh.gov\/fovAW33"
    } ]
  },
  "geo" : { },
  "id_str" : "238329055026479104",
  "text" : "Watch live: First Lady Michelle Obama announces a major #veterans &amp; #milspouse employment milestone for @JoiningForces: http:\/\/t.co\/NJtB2Zhs",
  "id" : 238329055026479104,
  "created_at" : "2012-08-22 17:37:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "veterans",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/TnHsKmZl",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "238328584131973121",
  "text" : "RT @JoiningForces: Happening now: Watch First Lady Michelle Obama speak about #jobs for #veterans http:\/\/t.co\/TnHsKmZl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 59, 64 ]
      }, {
        "text" : "veterans",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/TnHsKmZl",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "238325955238707200",
    "text" : "Happening now: Watch First Lady Michelle Obama speak about #jobs for #veterans http:\/\/t.co\/TnHsKmZl",
    "id" : 238325955238707200,
    "created_at" : "2012-08-22 17:25:10 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 238328584131973121,
  "created_at" : "2012-08-22 17:35:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 16, 21 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/m7wHG834",
      "expanded_url" : "http:\/\/www.nasa.gov\/ntv",
      "display_url" : "nasa.gov\/ntv"
    } ]
  },
  "geo" : { },
  "id_str" : "238303045597929473",
  "text" : "RT @NASA: Watch @NASA social media followers ask questions to the space station crew at 12:45p ET on NASA TV. http:\/\/t.co\/m7wHG834 #NASA ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 6, 11 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NASASocial",
        "indices" : [ 121, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/m7wHG834",
        "expanded_url" : "http:\/\/www.nasa.gov\/ntv",
        "display_url" : "nasa.gov\/ntv"
      } ]
    },
    "geo" : { },
    "id_str" : "238298223628914689",
    "text" : "Watch @NASA social media followers ask questions to the space station crew at 12:45p ET on NASA TV. http:\/\/t.co\/m7wHG834 #NASASocial",
    "id" : 238298223628914689,
    "created_at" : "2012-08-22 15:34:58 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 238303045597929473,
  "created_at" : "2012-08-22 15:54:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 52, 62 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovategov",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/d9iwSFKf",
      "expanded_url" : "http:\/\/on.wh.gov\/WVtzAZO",
      "display_url" : "on.wh.gov\/WVtzAZO"
    } ]
  },
  "geo" : { },
  "id_str" : "238004174674075651",
  "text" : "What's the Presidential Innovation Fellows Program? @Todd_Park highlights new steps to #innovategov: http:\/\/t.co\/d9iwSFKf",
  "id" : 238004174674075651,
  "created_at" : "2012-08-21 20:06:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/237953000059068416\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/0fI8uvee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A01g_ioCYAArzDz.jpg",
      "id_str" : "237953000063262720",
      "id" : 237953000063262720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A01g_ioCYAArzDz.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0fI8uvee"
    } ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 74, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/JB7AAYjK",
      "expanded_url" : "http:\/\/on.wh.gov\/nhcbthJ",
      "display_url" : "on.wh.gov\/nhcbthJ"
    } ]
  },
  "geo" : { },
  "id_str" : "237953000059068416",
  "text" : "PHOTO: President Obama samples a baked zucchini fry after dropping by the #KidsStateDinner: http:\/\/t.co\/JB7AAYjK http:\/\/t.co\/0fI8uvee",
  "id" : 237953000059068416,
  "created_at" : "2012-08-21 16:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VisitUS",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/Uwa4i2B8",
      "expanded_url" : "http:\/\/on.wh.gov\/xzJLLS",
      "display_url" : "on.wh.gov\/xzJLLS"
    }, {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/po43ubqe",
      "expanded_url" : "http:\/\/on.wh.gov\/vPYYRn",
      "display_url" : "on.wh.gov\/vPYYRn"
    } ]
  },
  "geo" : { },
  "id_str" : "237698843104387072",
  "text" : "RT @Interior: VIDEO: See all the great places you can visit through the newly redesigned http:\/\/t.co\/Uwa4i2B8 http:\/\/t.co\/po43ubqe #VisitUS",
  "id" : 237698843104387072,
  "created_at" : "2012-08-20 23:53:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/237658153393737728\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/iMl15Qcl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0xU1NNCUAEmwil.jpg",
      "id_str" : "237658153397932033",
      "id" : 237658153397932033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0xU1NNCUAEmwil.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iMl15Qcl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237658153393737728",
  "text" : "Photo of the Day: The President, First Lady and daughters Malia &amp; Sasha walk to St. John's Episcopal Church in D.C. http:\/\/t.co\/iMl15Qcl",
  "id" : 237658153393737728,
  "created_at" : "2012-08-20 21:11:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refi",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237606073484328961",
  "text" : "RT @macon44: POTUS just mentioned housing #refi plan that Congress could pass when they come back - lots more about that here: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "refi",
        "indices" : [ 29, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/pZzg5IXc",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/refi",
        "display_url" : "whitehouse.gov\/refi"
      } ]
    },
    "geo" : { },
    "id_str" : "237605729534619648",
    "text" : "POTUS just mentioned housing #refi plan that Congress could pass when they come back - lots more about that here: http:\/\/t.co\/pZzg5IXc",
    "id" : 237605729534619648,
    "created_at" : "2012-08-20 17:43:15 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 237606073484328961,
  "created_at" : "2012-08-20 17:44:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "237604084859940864",
  "text" : "RT @WHLive: President Obama is speaking at press briefing now. Watch live: http:\/\/t.co\/g5icuVZL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "237603526119923712",
    "text" : "President Obama is speaking at press briefing now. Watch live: http:\/\/t.co\/g5icuVZL",
    "id" : 237603526119923712,
    "created_at" : "2012-08-20 17:34:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 237604084859940864,
  "created_at" : "2012-08-20 17:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/xFp2YL7O",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "237602469440532480",
  "text" : "RT @jesseclee44: Obama speaking at press briefing now: http:\/\/t.co\/xFp2YL7O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/xFp2YL7O",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "237601949330046977",
    "text" : "Obama speaking at press briefing now: http:\/\/t.co\/xFp2YL7O",
    "id" : 237601949330046977,
    "created_at" : "2012-08-20 17:28:13 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 237602469440532480,
  "created_at" : "2012-08-20 17:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237602438935359491",
  "text" : "RT @pfeiffer44: President Obama just popped into the briefing room to take some questions from the White House press corps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237602107174309888",
    "text" : "President Obama just popped into the briefing room to take some questions from the White House press corps",
    "id" : 237602107174309888,
    "created_at" : "2012-08-20 17:28:51 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 237602438935359491,
  "created_at" : "2012-08-20 17:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/letsmove\/status\/237595024831950848\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/18O34dmm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0wbapBCMAA3RJe.jpg",
      "id_str" : "237595024844533760",
      "id" : 237595024844533760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0wbapBCMAA3RJe.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 765
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/18O34dmm"
    } ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237597756229820416",
  "text" : "RT @letsmove: \"We're so proud of you\" -First Lady Michelle Obama to young chefs at the #KidsStateDinner http:\/\/t.co\/18O34dmm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/letsmove\/status\/237595024831950848\/photo\/1",
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/18O34dmm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A0wbapBCMAA3RJe.jpg",
        "id_str" : "237595024844533760",
        "id" : 237595024844533760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0wbapBCMAA3RJe.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 765
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/18O34dmm"
      } ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 73, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237595024831950848",
    "text" : "\"We're so proud of you\" -First Lady Michelle Obama to young chefs at the #KidsStateDinner http:\/\/t.co\/18O34dmm",
    "id" : 237595024831950848,
    "created_at" : "2012-08-20 17:00:43 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 237597756229820416,
  "created_at" : "2012-08-20 17:11:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Big Time Rush",
      "screen_name" : "bigtimerush",
      "indices" : [ 26, 38 ],
      "id_str" : "79536438",
      "id" : 79536438
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/237591766721773568\/photo\/1",
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/ZHE41Ik7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0wYc_mCQAAx2Ic.jpg",
      "id_str" : "237591766730162176",
      "id" : 237591766730162176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0wYc_mCQAAx2Ic.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZHE41Ik7"
    } ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 62, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/4WaOTqyg",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "237592605838422017",
  "text" : "RT @letsmove: Watch live: @bigtimerush takes the stage at the #KidsStateDinner: http:\/\/t.co\/4WaOTqyg http:\/\/t.co\/ZHE41Ik7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Big Time Rush",
        "screen_name" : "bigtimerush",
        "indices" : [ 12, 24 ],
        "id_str" : "79536438",
        "id" : 79536438
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/237591766721773568\/photo\/1",
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/ZHE41Ik7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A0wYc_mCQAAx2Ic.jpg",
        "id_str" : "237591766730162176",
        "id" : 237591766730162176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0wYc_mCQAAx2Ic.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZHE41Ik7"
      } ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 48, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/4WaOTqyg",
        "expanded_url" : "http:\/\/WH.gov\/live",
        "display_url" : "WH.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "237591766721773568",
    "text" : "Watch live: @bigtimerush takes the stage at the #KidsStateDinner: http:\/\/t.co\/4WaOTqyg http:\/\/t.co\/ZHE41Ik7",
    "id" : 237591766721773568,
    "created_at" : "2012-08-20 16:47:46 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 237592605838422017,
  "created_at" : "2012-08-20 16:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 46, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/O6TJuiOT",
      "expanded_url" : "http:\/\/www.letsmove.gov\/kids-state-dinner",
      "display_url" : "letsmove.gov\/kids-state-din\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "237582594231898113",
  "text" : "Surprise! President Obama just stopped by the #KidsStateDinner. Watch now: http:\/\/t.co\/O6TJuiOT",
  "id" : 237582594231898113,
  "created_at" : "2012-08-20 16:11:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 107, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237578911561682945",
  "text" : "RT @letsmove: First Lady Michelle Obama: \"To our 54 Healthy Lunchtime Challenge winners -congratulations!\" #KidsStateDinner",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 93, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237578580207480832",
    "text" : "First Lady Michelle Obama: \"To our 54 Healthy Lunchtime Challenge winners -congratulations!\" #KidsStateDinner",
    "id" : 237578580207480832,
    "created_at" : "2012-08-20 15:55:22 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 237578911561682945,
  "created_at" : "2012-08-20 15:56:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 78, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/O6TJuiOT",
      "expanded_url" : "http:\/\/www.letsmove.gov\/kids-state-dinner",
      "display_url" : "letsmove.gov\/kids-state-din\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "237576088371462144",
  "text" : "Watch live: First Lady Michelle Obama welcomes 54 young chefs to the 1st ever #KidsStateDinner at the White House: http:\/\/t.co\/O6TJuiOT",
  "id" : 237576088371462144,
  "created_at" : "2012-08-20 15:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 63, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/mZYa7adV",
      "expanded_url" : "http:\/\/ow.ly\/d5Fz7",
      "display_url" : "ow.ly\/d5Fz7"
    } ]
  },
  "geo" : { },
  "id_str" : "237552705734860800",
  "text" : "Starting now: 54 young chefs attend the first-ever White House #KidsStateDinner. Learn more &amp; watch live at: http:\/\/t.co\/mZYa7adV",
  "id" : 237552705734860800,
  "created_at" : "2012-08-20 14:12:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 120, 129 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 45, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237548206727241728",
  "text" : "Today I'm hosting the first-ever White House #KidsStateDinner! Excited to meet 54 young chefs &amp; taste their healthy @LetsMove recipes! \u2013mo",
  "id" : 237548206727241728,
  "created_at" : "2012-08-20 13:54:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237339965523107840",
  "text" : "RT @letsmove: Tomorrow at 10 am ET: First Lady Michelle Obama hosts the first-ever #KidsStateDinner. Learn more &amp; watch live: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 69, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/mzwDvtB5",
        "expanded_url" : "http:\/\/1.usa.gov\/LIuGe4",
        "display_url" : "1.usa.gov\/LIuGe4"
      } ]
    },
    "geo" : { },
    "id_str" : "237285347342548992",
    "text" : "Tomorrow at 10 am ET: First Lady Michelle Obama hosts the first-ever #KidsStateDinner. Learn more &amp; watch live: http:\/\/t.co\/mzwDvtB5",
    "id" : 237285347342548992,
    "created_at" : "2012-08-19 20:30:10 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 237339965523107840,
  "created_at" : "2012-08-20 00:07:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 71, 82 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidStatesDinner",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236909664246300672",
  "text" : "RT @letsmove: Go behind the scenes during the preparation for Monday's @WhiteHouse #KidStatesDinner hosted by the First Lady. http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 57, 68 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidStatesDinner",
        "indices" : [ 69, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/v5WSsqjM",
        "expanded_url" : "http:\/\/youtu.be\/H2t5EcrP0dQ",
        "display_url" : "youtu.be\/H2t5EcrP0dQ"
      } ]
    },
    "geo" : { },
    "id_str" : "236899290914623488",
    "text" : "Go behind the scenes during the preparation for Monday's @WhiteHouse #KidStatesDinner hosted by the First Lady. http:\/\/t.co\/v5WSsqjM",
    "id" : 236899290914623488,
    "created_at" : "2012-08-18 18:56:06 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 236909664246300672,
  "created_at" : "2012-08-18 19:37:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/v5rntHxF",
      "expanded_url" : "http:\/\/on.wh.gov\/hionY1",
      "display_url" : "on.wh.gov\/hionY1"
    } ]
  },
  "geo" : { },
  "id_str" : "236848273686667264",
  "text" : "\"There's nothing more important to our future than the education we give our kids\" -President Obama Weekly Address: http:\/\/t.co\/v5rntHxF",
  "id" : 236848273686667264,
  "created_at" : "2012-08-18 15:33:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/TtWcZ9eE",
      "expanded_url" : "http:\/\/on.wh.gov\/JBumE6",
      "display_url" : "on.wh.gov\/JBumE6"
    } ]
  },
  "geo" : { },
  "id_str" : "236821465939464192",
  "text" : "Weekly Address: Congress Should Back Plan to Hire Teachers Watch: http:\/\/t.co\/TtWcZ9eE",
  "id" : 236821465939464192,
  "created_at" : "2012-08-18 13:46:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 40, 43 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 58, 68 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/236568278074540032\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/fzinBqEC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0h1mHTCQAECspR.jpg",
      "id_str" : "236568278091317249",
      "id" : 236568278091317249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0h1mHTCQAECspR.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fzinBqEC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236568278074540032",
  "text" : "Photo of the day: President Obama &amp; @VP Biden meet w\/ @StateDept Sec. Clinton &amp; Tom Donilon in the Oval Office. http:\/\/t.co\/fzinBqEC",
  "id" : 236568278074540032,
  "created_at" : "2012-08-17 21:00:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeCantWait",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/oIgYojMZ",
      "expanded_url" : "http:\/\/bit.ly\/Pr0bPM",
      "display_url" : "bit.ly\/Pr0bPM"
    } ]
  },
  "geo" : { },
  "id_str" : "236516574520033280",
  "text" : "RT @RayLaHood: Obama Administration says #WeCantWait, tells states to use idle earmarks to improve transportation. http:\/\/t.co\/oIgYojMZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeCantWait",
        "indices" : [ 26, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/oIgYojMZ",
        "expanded_url" : "http:\/\/bit.ly\/Pr0bPM",
        "display_url" : "bit.ly\/Pr0bPM"
      } ]
    },
    "geo" : { },
    "id_str" : "236510542712406016",
    "text" : "Obama Administration says #WeCantWait, tells states to use idle earmarks to improve transportation. http:\/\/t.co\/oIgYojMZ",
    "id" : 236510542712406016,
    "created_at" : "2012-08-17 17:11:22 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 236516574520033280,
  "created_at" : "2012-08-17 17:35:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalPTA",
      "screen_name" : "NationalPTA",
      "indices" : [ 29, 41 ],
      "id_str" : "14407823",
      "id" : 14407823
    }, {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 59, 73 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/8dqNPoEj",
      "expanded_url" : "http:\/\/on.wh.gov\/BKXsTG",
      "display_url" : "on.wh.gov\/BKXsTG"
    } ]
  },
  "geo" : { },
  "id_str" : "236513839099822080",
  "text" : "West Wing Week 8\/17\/12: From @NationalPTA Day to a call to @MarsCuriosity's team your guide to this week at 1600 Penn: http:\/\/t.co\/8dqNPoEj",
  "id" : 236513839099822080,
  "created_at" : "2012-08-17 17:24:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 54, 65 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/p1kHjRoC",
      "expanded_url" : "http:\/\/on.wh.gov\/PRMFPU",
      "display_url" : "on.wh.gov\/PRMFPU"
    } ]
  },
  "geo" : { },
  "id_str" : "236484395610042372",
  "text" : "Today at 12ET: Join us for a WH Google+ Hangout about @Americorps.  Watch live at: http:\/\/t.co\/p1kHjRoC.  Ask Qs now w\/ #WHHangout.",
  "id" : 236484395610042372,
  "created_at" : "2012-08-17 15:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Spencer",
      "screen_name" : "WendyCNCS",
      "indices" : [ 73, 83 ],
      "id_str" : "29519977",
      "id" : 29519977
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 90, 98 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Americorps",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "WHHangout",
      "indices" : [ 134, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/SwI6NIuM",
      "expanded_url" : "http:\/\/on.wh.gov\/ahxZOV",
      "display_url" : "on.wh.gov\/ahxZOV"
    } ]
  },
  "geo" : { },
  "id_str" : "236473986047938560",
  "text" : "Have Qs about #Americorps? Today @ 12ET join a Google+ Hangout w\/ CNCS's @WendyCNCS &amp; @Macon44 http:\/\/t.co\/SwI6NIuM Ask Qs now w\/ #WHHangout",
  "id" : 236473986047938560,
  "created_at" : "2012-08-17 14:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/236246656100749312\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/jmM6o88P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0dRFQDCUAEqcv-.jpg",
      "id_str" : "236246656109137921",
      "id" : 236246656109137921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0dRFQDCUAEqcv-.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      } ],
      "display_url" : "pic.twitter.com\/jmM6o88P"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/SpfTsuSj",
      "expanded_url" : "http:\/\/on.wh.gov\/SaBYDk",
      "display_url" : "on.wh.gov\/SaBYDk"
    } ]
  },
  "geo" : { },
  "id_str" : "236246656100749312",
  "text" : "President Obama wants to extend tax cuts for 98% of American families. Get the facts: http:\/\/t.co\/SpfTsuSj http:\/\/t.co\/jmM6o88P",
  "id" : 236246656100749312,
  "created_at" : "2012-08-16 23:42:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/236230333530517504\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/YQZuwDy6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0dCPJuCMAAE6FA.jpg",
      "id_str" : "236230333534711808",
      "id" : 236230333534711808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0dCPJuCMAAE6FA.jpg",
      "sizes" : [ {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      } ],
      "display_url" : "pic.twitter.com\/YQZuwDy6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/Zi3SsOmv",
      "expanded_url" : "http:\/\/on.wh.gov\/wE6wHq",
      "display_url" : "on.wh.gov\/wE6wHq"
    } ]
  },
  "geo" : { },
  "id_str" : "236230333530517504",
  "text" : "11 Facts about the tax debate: http:\/\/t.co\/Zi3SsOmv Find out what's at stake for middle-class families: http:\/\/t.co\/YQZuwDy6",
  "id" : 236230333530517504,
  "created_at" : "2012-08-16 22:37:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/236214678508953600\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/1hl69yRI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0cz_6QCYAA_Si9.jpg",
      "id_str" : "236214678521536512",
      "id" : 236214678521536512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0cz_6QCYAA_Si9.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      } ],
      "display_url" : "pic.twitter.com\/1hl69yRI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/nNqwtaj7",
      "expanded_url" : "http:\/\/on.wh.gov\/rWzYVW",
      "display_url" : "on.wh.gov\/rWzYVW"
    } ]
  },
  "geo" : { },
  "id_str" : "236214678508953600",
  "text" : "By the Numbers: 1.16: http:\/\/t.co\/nNqwtaj7 President Obama's tax plan would save $1.16 trillion over the next 10 yrs. http:\/\/t.co\/1hl69yRI",
  "id" : 236214678508953600,
  "created_at" : "2012-08-16 21:35:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy Spencer",
      "screen_name" : "WendyCNCS",
      "indices" : [ 30, 40 ],
      "id_str" : "29519977",
      "id" : 29519977
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 47, 55 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 84, 95 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/uGcj1Mz7",
      "expanded_url" : "http:\/\/on.wh.gov\/YJ94tO",
      "display_url" : "on.wh.gov\/YJ94tO"
    } ]
  },
  "geo" : { },
  "id_str" : "236186388536647680",
  "text" : "On 8\/17 at 12ET join CNCS CEO @WendyCNCS &amp; @Macon44 for a Google+ Hangout about @Americorps: http:\/\/t.co\/uGcj1Mz7. Ask Qs w\/ #WHHangout",
  "id" : 236186388536647680,
  "created_at" : "2012-08-16 19:43:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/236131105307230210\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/iV3ndxmC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0bn_T0CAAAuKrk.jpg",
      "id_str" : "236131105319813120",
      "id" : 236131105319813120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0bn_T0CAAAuKrk.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/iV3ndxmC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/eJsU764M",
      "expanded_url" : "http:\/\/on.wh.gov\/QMktRg",
      "display_url" : "on.wh.gov\/QMktRg"
    } ]
  },
  "geo" : { },
  "id_str" : "236131105307230210",
  "text" : "10 things you didn't know about wind: http:\/\/t.co\/eJsU764M  #1: 20% of U.S. electricity could come from wind by 2030 http:\/\/t.co\/iV3ndxmC",
  "id" : 236131105307230210,
  "created_at" : "2012-08-16 16:03:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236121036142284800",
  "text" : "RT @VP: Today\u2019s White House photo of the day: VP Biden visits memorial for the Virginia Tech shooting. (WH Photo-D. Lienemann) http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/235874169311621120\/photo\/1",
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/NCtmGBwK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A0X-TqnCcAE5tSZ.jpg",
        "id_str" : "235874169315815425",
        "id" : 235874169315815425,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0X-TqnCcAE5tSZ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NCtmGBwK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "235874169311621120",
    "text" : "Today\u2019s White House photo of the day: VP Biden visits memorial for the Virginia Tech shooting. (WH Photo-D. Lienemann) http:\/\/t.co\/NCtmGBwK",
    "id" : 235874169311621120,
    "created_at" : "2012-08-15 23:02:40 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 236121036142284800,
  "created_at" : "2012-08-16 15:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/235873619404800000\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/VusSWchQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0X9zqDCQAEcMAs.jpg",
      "id_str" : "235873619408994305",
      "id" : 235873619408994305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0X9zqDCQAEcMAs.jpg",
      "sizes" : [ {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      } ],
      "display_url" : "pic.twitter.com\/VusSWchQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/TjGnucAZ",
      "expanded_url" : "http:\/\/on.wh.gov\/OCvn74",
      "display_url" : "on.wh.gov\/OCvn74"
    } ]
  },
  "geo" : { },
  "id_str" : "235873619404800000",
  "text" : "11 facts about the tax debate: http:\/\/t.co\/TjGnucAZ Republicans' plan would add $1 trillion to the deficit over 10 yrs: http:\/\/t.co\/VusSWchQ",
  "id" : 235873619404800000,
  "created_at" : "2012-08-15 23:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USCIS",
      "screen_name" : "USCIS",
      "indices" : [ 7, 13 ],
      "id_str" : "14625398",
      "id" : 14625398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/BrMEuR5F",
      "expanded_url" : "http:\/\/on.wh.gov\/ZZMjVO",
      "display_url" : "on.wh.gov\/ZZMjVO"
    } ]
  },
  "geo" : { },
  "id_str" : "235858255350489088",
  "text" : "Today, @USCIS began accepting requests for deferred action for childhood arrivals. Who can be considered? Find out: http:\/\/t.co\/BrMEuR5F",
  "id" : 235858255350489088,
  "created_at" : "2012-08-15 21:59:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 76, 87 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "PBS Food",
      "screen_name" : "PBSFood",
      "indices" : [ 115, 123 ],
      "id_str" : "104257930",
      "id" : 104257930
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JuliaChild",
      "indices" : [ 34, 45 ]
    }, {
      "text" : "CookforJulia",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/SP5UFcs5",
      "expanded_url" : "http:\/\/on.wh.gov\/RSS3mT",
      "display_url" : "on.wh.gov\/RSS3mT"
    } ]
  },
  "geo" : { },
  "id_str" : "235842729886752768",
  "text" : "WH Pastry Chef Bill Yosses wishes #JuliaChild Happy 100th Birthday from the @Whitehouse   http:\/\/t.co\/SP5UFcs5 via @PBSFood #CookforJulia",
  "id" : 235842729886752768,
  "created_at" : "2012-08-15 20:57:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/235814537499123712\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/2oRndYoV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0XIEo5CIAAdcL8.jpg",
      "id_str" : "235814537528483840",
      "id" : 235814537528483840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0XIEo5CIAAdcL8.jpg",
      "sizes" : [ {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 317
      }, {
        "h" : 1103,
        "resize" : "fit",
        "w" : 515
      } ],
      "display_url" : "pic.twitter.com\/2oRndYoV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/oSlouUuI",
      "expanded_url" : "http:\/\/on.wh.gov\/Hte4gm",
      "display_url" : "on.wh.gov\/Hte4gm"
    } ]
  },
  "geo" : { },
  "id_str" : "235814537499123712",
  "text" : "We should prevent taxes from going up on 98% of American families: http:\/\/t.co\/oSlouUuI 11 facts you should know: http:\/\/t.co\/2oRndYoV",
  "id" : 235814537499123712,
  "created_at" : "2012-08-15 19:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 10, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/eVFCfpxb",
      "expanded_url" : "http:\/\/on.wh.gov\/mQETK8",
      "display_url" : "on.wh.gov\/mQETK8"
    } ]
  },
  "geo" : { },
  "id_str" : "235553871135649792",
  "text" : "Extending #MiddleClassTaxCuts is the right thing to do. See the infographic: http:\/\/t.co\/eVFCfpxb &amp; RT if you agree.",
  "id" : 235553871135649792,
  "created_at" : "2012-08-15 01:49:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 4, 11 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/235473274266583040\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/dVsKG7IL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0SRsgMCAAALIUn.jpg",
      "id_str" : "235473274270777344",
      "id" : 235473274270777344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0SRsgMCAAALIUn.jpg",
      "sizes" : [ {
        "h" : 2636,
        "resize" : "fit",
        "w" : 745
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 339
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 192
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 579
      } ],
      "display_url" : "pic.twitter.com\/dVsKG7IL"
    } ],
    "hashtags" : [ {
      "text" : "wind",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/QGmrH1gn",
      "expanded_url" : "http:\/\/on.wh.gov\/qU5nYx",
      "display_url" : "on.wh.gov\/qU5nYx"
    } ]
  },
  "geo" : { },
  "id_str" : "235473274266583040",
  "text" : "MT \u200F@ENERGY Why 2011 was a banner year for #wind energy in America: http:\/\/t.co\/QGmrH1gn Infographic: http:\/\/t.co\/dVsKG7IL",
  "id" : 235473274266583040,
  "created_at" : "2012-08-14 20:29:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/235428201944461312\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/ucTEoxqY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0Ros8uCMAAH0d8.jpg",
      "id_str" : "235428201952849920",
      "id" : 235428201952849920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0Ros8uCMAAH0d8.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/ucTEoxqY"
    } ],
    "hashtags" : [ {
      "text" : "drought",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/6NHFGQs6",
      "expanded_url" : "http:\/\/on.wh.gov\/DJog1X",
      "display_url" : "on.wh.gov\/DJog1X"
    } ]
  },
  "geo" : { },
  "id_str" : "235428201944461312",
  "text" : "Yesterday, President Obama toured a family farm affected by the #drought in IA. More info: http:\/\/t.co\/6NHFGQs6 Photo: http:\/\/t.co\/ucTEoxqY",
  "id" : 235428201944461312,
  "created_at" : "2012-08-14 17:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Long",
      "screen_name" : "JessicaLong",
      "indices" : [ 9, 21 ],
      "id_str" : "254074448",
      "id" : 254074448
    }, {
      "name" : "Maya Moore",
      "screen_name" : "MooreMaya",
      "indices" : [ 22, 32 ],
      "id_str" : "277700210",
      "id" : 277700210
    }, {
      "name" : "Bernard Lagat",
      "screen_name" : "Lagat1500",
      "indices" : [ 33, 43 ],
      "id_str" : "36422065",
      "id" : 36422065
    }, {
      "name" : "Natalie Coughlin",
      "screen_name" : "NatalieCoughlin",
      "indices" : [ 44, 60 ],
      "id_str" : "26593416",
      "id" : 26593416
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 121, 130 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235192308788772864",
  "text" : "Congrats @JessicaLong @MooreMaya @Lagat1500 @NatalieCoughlin @JohnW_Orozco! Thanks for inspiring kids to get moving with @LetsMove! \u2013mo",
  "id" : 235192308788772864,
  "created_at" : "2012-08-14 01:53:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 29, 43 ],
      "id_str" : "15473958",
      "id" : 15473958
    }, {
      "name" : "Bobak Ferdowsi",
      "screen_name" : "tweetsoutloud",
      "indices" : [ 109, 123 ],
      "id_str" : "61306578",
      "id" : 61306578
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/235157250476498944\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/4PHbJe9P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0NyRf1CYAEfIdE.jpg",
      "id_str" : "235157250480693249",
      "id" : 235157250480693249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0NyRf1CYAEfIdE.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/4PHbJe9P"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/f8odYym5",
      "expanded_url" : "http:\/\/on.wh.gov\/ZSTY9Z",
      "display_url" : "on.wh.gov\/ZSTY9Z"
    } ]
  },
  "geo" : { },
  "id_str" : "235157250476498944",
  "text" : "President Obama calls NASA's @MarsCuriosity team to say congrats &amp; talk mohawks http:\/\/t.co\/f8odYym5 cc: @tweetsoutloud http:\/\/t.co\/4PHbJe9P",
  "id" : 235157250476498944,
  "created_at" : "2012-08-13 23:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ramadan",
      "indices" : [ 55, 63 ]
    }, {
      "text" : "Iftar",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/3Vh6ZoRu",
      "expanded_url" : "http:\/\/on.wh.gov\/Mx1C8S",
      "display_url" : "on.wh.gov\/Mx1C8S"
    } ]
  },
  "geo" : { },
  "id_str" : "235142106421796864",
  "text" : "\"To the more than 1 billion Muslims around the world - #Ramadan Kareem\"-President Obama at the WH #Iftar Dinner. VIDEO: http:\/\/t.co\/3Vh6ZoRu",
  "id" : 235142106421796864,
  "created_at" : "2012-08-13 22:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 8, 19 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 83, 91 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 118, 126 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/WOh3SVKH",
      "expanded_url" : "http:\/\/on.wh.gov\/vKk6TQ",
      "display_url" : "on.wh.gov\/vKk6TQ"
    } ]
  },
  "geo" : { },
  "id_str" : "235126451119214592",
  "text" : "See how @WhiteHouse has been celebrating the #London2012 #Olympics and #TeamUSA on @Twitter: http:\/\/t.co\/WOh3SVKH via @Storify",
  "id" : 235126451119214592,
  "created_at" : "2012-08-13 21:31:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 45, 56 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSL",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/83HFCxXU",
      "expanded_url" : "http:\/\/www.ustream.tv\/recorded\/24681663",
      "display_url" : "ustream.tv\/recorded\/24681\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235070047456989184",
  "text" : "RT @MarsCuriosity: Interplanetary fist bump: @whitehouse called to congratulate my team today. Watch the video: http:\/\/t.co\/83HFCxXU #MSL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 26, 37 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MSL",
        "indices" : [ 114, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/83HFCxXU",
        "expanded_url" : "http:\/\/www.ustream.tv\/recorded\/24681663",
        "display_url" : "ustream.tv\/recorded\/24681\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "235044898632507392",
    "text" : "Interplanetary fist bump: @whitehouse called to congratulate my team today. Watch the video: http:\/\/t.co\/83HFCxXU #MSL",
    "id" : 235044898632507392,
    "created_at" : "2012-08-13 16:07:25 +0000",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2793288186\/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 235070047456989184,
  "created_at" : "2012-08-13 17:47:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 85, 99 ],
      "id_str" : "15473958",
      "id" : 15473958
    }, {
      "name" : "NASA JPL",
      "screen_name" : "NASAJPL",
      "indices" : [ 105, 113 ],
      "id_str" : "19802879",
      "id" : 19802879
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/vJE0DTWg",
      "expanded_url" : "http:\/\/twitpic.com\/aiz0r8",
      "display_url" : "twitpic.com\/aiz0r8"
    } ]
  },
  "geo" : { },
  "id_str" : "235034272635969536",
  "text" : "RT @NASA: \"It's really mind-boggling what you've accomplished.\" - President Obama to @MarsCuriosity team @NASAJPL.\u00A0 http:\/\/t.co\/vJE0DTWg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Curiosity Rover",
        "screen_name" : "MarsCuriosity",
        "indices" : [ 75, 89 ],
        "id_str" : "15473958",
        "id" : 15473958
      }, {
        "name" : "NASA JPL",
        "screen_name" : "NASAJPL",
        "indices" : [ 95, 103 ],
        "id_str" : "19802879",
        "id" : 19802879
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/vJE0DTWg",
        "expanded_url" : "http:\/\/twitpic.com\/aiz0r8",
        "display_url" : "twitpic.com\/aiz0r8"
      } ]
    },
    "geo" : { },
    "id_str" : "235031151599820802",
    "text" : "\"It's really mind-boggling what you've accomplished.\" - President Obama to @MarsCuriosity team @NASAJPL.\u00A0 http:\/\/t.co\/vJE0DTWg",
    "id" : 235031151599820802,
    "created_at" : "2012-08-13 15:12:47 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 235034272635969536,
  "created_at" : "2012-08-13 15:25:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 29, 43 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/m7wHG834",
      "expanded_url" : "http:\/\/www.nasa.gov\/ntv",
      "display_url" : "nasa.gov\/ntv"
    } ]
  },
  "geo" : { },
  "id_str" : "235014463219191809",
  "text" : "RT @NASA: Congratulations to @MarsCuriosity team from President Obama at 11am ET today. Watch live on NASA TV: http:\/\/t.co\/m7wHG834",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Curiosity Rover",
        "screen_name" : "MarsCuriosity",
        "indices" : [ 19, 33 ],
        "id_str" : "15473958",
        "id" : 15473958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/m7wHG834",
        "expanded_url" : "http:\/\/www.nasa.gov\/ntv",
        "display_url" : "nasa.gov\/ntv"
      } ]
    },
    "geo" : { },
    "id_str" : "234999761013465090",
    "text" : "Congratulations to @MarsCuriosity team from President Obama at 11am ET today. Watch live on NASA TV: http:\/\/t.co\/m7wHG834",
    "id" : 234999761013465090,
    "created_at" : "2012-08-13 13:08:03 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 235014463219191809,
  "created_at" : "2012-08-13 14:06:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 45, 55 ],
      "id_str" : "23083404",
      "id" : 23083404
    }, {
      "name" : "USA Basketball",
      "screen_name" : "usabasketball",
      "indices" : [ 92, 106 ],
      "id_str" : "17049258",
      "id" : 17049258
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/234849790305906688\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/1AyCjfXu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0Jao9dCMAAekdk.jpg",
      "id_str" : "234849790314295296",
      "id" : 234849790314295296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0Jao9dCMAAekdk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1AyCjfXu"
    } ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234849790305906688",
  "text" : "Photo: First Lady Michelle Obama hugs LeBron @KingJames after the #TeamUSA vs. France men's @USABasketball game: http:\/\/t.co\/1AyCjfXu",
  "id" : 234849790305906688,
  "created_at" : "2012-08-13 03:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234798064995536897",
  "text" : "To all of our Olympic athletes - thank you. #TeamUSA has truly inspired us all &amp; we could not be prouder. -mo",
  "id" : 234798064995536897,
  "created_at" : "2012-08-12 23:46:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "Team GB",
      "screen_name" : "TeamGB",
      "indices" : [ 93, 100 ],
      "id_str" : "27660239",
      "id" : 27660239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234783703556055040",
  "text" : "RT @AmbassadorRice: On behalf of President Obama &amp; the U.S.: congrats to the organizers, @TeamGB &amp; the people of London on your  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Team GB",
        "screen_name" : "TeamGB",
        "indices" : [ 73, 80 ],
        "id_str" : "27660239",
        "id" : 27660239
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234779623148380160",
    "text" : "On behalf of President Obama &amp; the U.S.: congrats to the organizers, @TeamGB &amp; the people of London on your many successes at these Games!",
    "id" : 234779623148380160,
    "created_at" : "2012-08-12 22:33:18 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 234783703556055040,
  "created_at" : "2012-08-12 22:49:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234761900691423233",
  "text" : "We're so proud of you @JohnW_Orozco. You are an inspiration. We'll be cheering for you for a long time to come. -mo",
  "id" : 234761900691423233,
  "created_at" : "2012-08-12 21:22:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 3, 15 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234750482617348096",
  "text" : "RT @Number10gov: President Obama has called the PM to congratulate the UK on a brilliant Olympics, praising the organisation of the Game ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Team GB",
        "screen_name" : "TeamGB",
        "indices" : [ 125, 132 ],
        "id_str" : "27660239",
        "id" : 27660239
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234748068023660546",
    "text" : "President Obama has called the PM to congratulate the UK on a brilliant Olympics, praising the organisation of the Games and @TeamGB medals",
    "id" : 234748068023660546,
    "created_at" : "2012-08-12 20:27:55 +0000",
    "user" : {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "protected" : false,
      "id_str" : "14224719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798111635206508544\/qPVyTQI-_normal.jpg",
      "id" : 14224719,
      "verified" : true
    }
  },
  "id" : 234750482617348096,
  "created_at" : "2012-08-12 20:37:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Olympics",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/vESe1EVB",
      "expanded_url" : "http:\/\/twitpic.com\/aindtp",
      "display_url" : "twitpic.com\/aindtp"
    } ]
  },
  "geo" : { },
  "id_str" : "234742035184250880",
  "text" : "RT @AmbassadorRice: So honored to be here to represent the President at the Closing Ceremony of the #Olympics.  http:\/\/t.co\/vESe1EVB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Olympics",
        "indices" : [ 80, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/vESe1EVB",
        "expanded_url" : "http:\/\/twitpic.com\/aindtp",
        "display_url" : "twitpic.com\/aindtp"
      } ]
    },
    "geo" : { },
    "id_str" : "234741126530228224",
    "text" : "So honored to be here to represent the President at the Closing Ceremony of the #Olympics.  http:\/\/t.co\/vESe1EVB",
    "id" : 234741126530228224,
    "created_at" : "2012-08-12 20:00:20 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 234742035184250880,
  "created_at" : "2012-08-12 20:03:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 18, 28 ],
      "id_str" : "23083404",
      "id" : 23083404
    }, {
      "name" : "Kevin Durant",
      "screen_name" : "KDTrey5",
      "indices" : [ 30, 38 ],
      "id_str" : "35936474",
      "id" : 35936474
    }, {
      "name" : "Kevin Love",
      "screen_name" : "kevinlove",
      "indices" : [ 40, 50 ],
      "id_str" : "217160945",
      "id" : 217160945
    }, {
      "name" : "Chris Paul",
      "screen_name" : "CP3",
      "indices" : [ 52, 56 ],
      "id_str" : "53853197",
      "id" : 53853197
    }, {
      "name" : "USA Basketball",
      "screen_name" : "usabasketball",
      "indices" : [ 79, 93 ],
      "id_str" : "17049258",
      "id" : 17049258
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234699571639508992",
  "text" : "Congrats Coach K, @KingJames, @KDTrey5, @kevinlove, @CP3, Kobe &amp; the men's @usabasketball team. Amazing game! So proud! -mo",
  "id" : 234699571639508992,
  "created_at" : "2012-08-12 17:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JayLenoTonight",
      "screen_name" : "JayLenoTonight",
      "indices" : [ 24, 39 ],
      "id_str" : "19316817",
      "id" : 19316817
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 77, 86 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Olympics",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/cyOnvcSv",
      "expanded_url" : "http:\/\/on.wh.gov\/MVXB",
      "display_url" : "on.wh.gov\/MVXB"
    } ]
  },
  "geo" : { },
  "id_str" : "234633927543894016",
  "text" : "I can't wait to stop by @JayLenoTonight on 8\/13 to talk about the #Olympics, @LetsMove &amp; how this happened: http:\/\/t.co\/cyOnvcSv -mo",
  "id" : 234633927543894016,
  "created_at" : "2012-08-12 12:54:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 65, 68 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "USA Basketball",
      "screen_name" : "usabasketball",
      "indices" : [ 85, 99 ],
      "id_str" : "17049258",
      "id" : 17049258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 9, 17 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/ljkvhXlD",
      "expanded_url" : "http:\/\/on.wh.gov\/CPod",
      "display_url" : "on.wh.gov\/CPod"
    } ]
  },
  "geo" : { },
  "id_str" : "234493568104931329",
  "text" : "Congrats #TeamUSA! Go behind-the-scenes as President Obama &amp; @VP Biden meet with @USABasketball before the #Olympics: http:\/\/t.co\/ljkvhXlD",
  "id" : 234493568104931329,
  "created_at" : "2012-08-12 03:36:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Basketball",
      "screen_name" : "usabasketball",
      "indices" : [ 29, 43 ],
      "id_str" : "17049258",
      "id" : 17049258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoTeamUSA",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234380385541312513",
  "text" : "I'm cheering for the women's @USABasketball team today. Are you? Join &amp; say #GoTeamUSA! -mo",
  "id" : 234380385541312513,
  "created_at" : "2012-08-11 20:06:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allyson Felix",
      "screen_name" : "allysonfelix",
      "indices" : [ 9, 22 ],
      "id_str" : "24485503",
      "id" : 24485503
    }, {
      "name" : "Carmelita Jeter",
      "screen_name" : "CarmelitaJeter",
      "indices" : [ 23, 38 ],
      "id_str" : "390911317",
      "id" : 390911317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234365213711945729",
  "text" : "Congrats @AllysonFelix @CarmelitaJeter @TeamTianna &amp; @MidKnightDreams on bringing home Olympic gold &amp; a new WR! We're so proud of you. -mo",
  "id" : 234365213711945729,
  "created_at" : "2012-08-11 19:06:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/234331930349432832\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/82jZLzHe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0CDpiyCcAAr7dw.jpg",
      "id_str" : "234331930357821440",
      "id" : 234331930357821440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0CDpiyCcAAr7dw.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/82jZLzHe"
    } ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 49, 57 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/UorAgFMY",
      "expanded_url" : "http:\/\/on.wh.gov\/Hp8u",
      "display_url" : "on.wh.gov\/Hp8u"
    } ]
  },
  "geo" : { },
  "id_str" : "234331930349432832",
  "text" : "Photo Gallery: Celebrating the Servicemembers on #TeamUSA at the #Olympics: http:\/\/t.co\/UorAgFMY SPC @LesterToLondon: http:\/\/t.co\/82jZLzHe",
  "id" : 234331930349432832,
  "created_at" : "2012-08-11 16:54:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Drought",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/VdqKMaes",
      "expanded_url" : "http:\/\/on.wh.gov\/SmKX",
      "display_url" : "on.wh.gov\/SmKX"
    }, {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/SxDdVsWP",
      "expanded_url" : "http:\/\/on.wh.gov\/ACNh",
      "display_url" : "on.wh.gov\/ACNh"
    } ]
  },
  "geo" : { },
  "id_str" : "234278441254547456",
  "text" : "Weekly Address: All-Hands-On-Deck Response to the #Drought: http:\/\/t.co\/VdqKMaes More on drought response &amp; resources: http:\/\/t.co\/SxDdVsWP",
  "id" : 234278441254547456,
  "created_at" : "2012-08-11 13:21:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/W3fKUkHA",
      "expanded_url" : "http:\/\/on.wh.gov\/TIkh",
      "display_url" : "on.wh.gov\/TIkh"
    } ]
  },
  "geo" : { },
  "id_str" : "234141394422345728",
  "text" : "Fact Sheet: New Executive Order on Preventing and Responding to Violence Against Women and Girls Globally http:\/\/t.co\/W3fKUkHA",
  "id" : 234141394422345728,
  "created_at" : "2012-08-11 04:17:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "234085486187134977",
  "text" : "Happening now on http:\/\/t.co\/u95tzH8r: President Obama Hosts an Iftar Dinner Celebrating Ramadan",
  "id" : 234085486187134977,
  "created_at" : "2012-08-11 00:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/234060797750435842\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/mOUoIfhC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Az-NDjJCYAAeeX4.jpg",
      "id_str" : "234060797758824448",
      "id" : 234060797758824448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Az-NDjJCYAAeeX4.jpg",
      "sizes" : [ {
        "h" : 534,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/mOUoIfhC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/COjkqnjb",
      "expanded_url" : "http:\/\/on.wh.gov\/tVgp",
      "display_url" : "on.wh.gov\/tVgp"
    } ]
  },
  "geo" : { },
  "id_str" : "234060797750435842",
  "text" : "New behind the scenes pics from July 2012: http:\/\/t.co\/COjkqnjb. Includes President Obama being chased by adorable kid http:\/\/t.co\/mOUoIfhC",
  "id" : 234060797750435842,
  "created_at" : "2012-08-10 22:56:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "NationalPTA",
      "screen_name" : "NationalPTA",
      "indices" : [ 31, 43 ],
      "id_str" : "14407823",
      "id" : 14407823
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 99, 110 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHPTA",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "234041351266783232",
  "text" : "RT @arneduncan: Huge thanks to @NationalPTA &amp; state PTA leaders for spending #WHPTA Day at the @whitehouse. Keep advocating for our  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalPTA",
        "screen_name" : "NationalPTA",
        "indices" : [ 15, 27 ],
        "id_str" : "14407823",
        "id" : 14407823
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 83, 94 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHPTA",
        "indices" : [ 65, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "234040181819318272",
    "text" : "Huge thanks to @NationalPTA &amp; state PTA leaders for spending #WHPTA Day at the @whitehouse. Keep advocating for our nation's children!",
    "id" : 234040181819318272,
    "created_at" : "2012-08-10 21:35:02 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 234041351266783232,
  "created_at" : "2012-08-10 21:39:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/233974994802188288\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/eoYsA1sG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Az8_BKQCIAAn-Dt.jpg",
      "id_str" : "233974994810576896",
      "id" : 233974994810576896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Az8_BKQCIAAn-Dt.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eoYsA1sG"
    } ],
    "hashtags" : [ {
      "text" : "Olympic",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233974994802188288",
  "text" : "Photo of the Day: President Obama talks with paralympic athletes at the U.S. #Olympic Training Facility in C.O. http:\/\/t.co\/eoYsA1sG",
  "id" : 233974994802188288,
  "created_at" : "2012-08-10 17:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betsy Landers",
      "screen_name" : "PTABetsy",
      "indices" : [ 91, 100 ],
      "id_str" : "745232227",
      "id" : 745232227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHPTA",
      "indices" : [ 135, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "233958504396898304",
  "text" : "Happening now on http:\/\/t.co\/u95tzH8r: \"Open for Questions\" live Q&amp;A on education with @PTABetsy. Watch &amp; ask questions now w\/ #WHPTA",
  "id" : 233958504396898304,
  "created_at" : "2012-08-10 16:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/wBGLofQR",
      "expanded_url" : "http:\/\/on.wh.gov\/qvEj",
      "display_url" : "on.wh.gov\/qvEj"
    } ]
  },
  "geo" : { },
  "id_str" : "233945358202437632",
  "text" : "West Wing Week 8\/10\/12: Your behind the scenes guide to this week at 1600 Pennsylvania Ave. VIDEO: http:\/\/t.co\/wBGLofQR",
  "id" : 233945358202437632,
  "created_at" : "2012-08-10 15:18:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 105, 115 ]
    }, {
      "text" : "WHPTA",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/dfEWfXpi",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "233923177204563969",
  "text" : "Happening Now on http:\/\/t.co\/dfEWfXpi: It's PTA Day at the White House. Have Q's on the administration's #education policy? Ask w\/ #WHPTA.",
  "id" : 233923177204563969,
  "created_at" : "2012-08-10 13:50:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Census Bureau",
      "screen_name" : "uscensusbureau",
      "indices" : [ 3, 18 ],
      "id_str" : "23092890",
      "id" : 23092890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Economy",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/9jKAiXKF",
      "expanded_url" : "http:\/\/on.wh.gov\/kA21",
      "display_url" : "on.wh.gov\/kA21"
    } ]
  },
  "geo" : { },
  "id_str" : "233903017257209856",
  "text" : "RT @uscensusbureau: Census Bureau Releases Its First Mobile App, Providing Real-Time Statistics on U.S. #Economy: http:\/\/t.co\/9jKAiXKF",
  "id" : 233903017257209856,
  "created_at" : "2012-08-10 12:29:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ClaressaT-rexShields",
      "screen_name" : "Claressashields",
      "indices" : [ 61, 77 ],
      "id_str" : "420654392",
      "id" : 420654392
    }, {
      "name" : "USA Water Polo",
      "screen_name" : "USAWP",
      "indices" : [ 78, 84 ],
      "id_str" : "26553971",
      "id" : 26553971
    }, {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 85, 98 ],
      "id_str" : "133448051",
      "id" : 133448051
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 36, 44 ]
    }, {
      "text" : "golden",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233700021072175104",
  "text" : "Amazing performance by the women of #TeamUSA today. Congrats @Claressashields @USAWP @ussoccer_wnt. You all are #golden! -mo",
  "id" : 233700021072175104,
  "created_at" : "2012-08-09 23:03:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 51, 61 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 95, 106 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/vbm4ok9N",
      "expanded_url" : "http:\/\/on.wh.gov\/cZru",
      "display_url" : "on.wh.gov\/cZru"
    } ]
  },
  "geo" : { },
  "id_str" : "233684645089271808",
  "text" : "Check out the latest behind-the-scenes photos from @PeteSouza, including the First Lady at the #London2012 #Olympics: http:\/\/t.co\/vbm4ok9N",
  "id" : 233684645089271808,
  "created_at" : "2012-08-09 22:02:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Putman",
      "screen_name" : "DrJeffreyP",
      "indices" : [ 3, 14 ],
      "id_str" : "260479987",
      "id" : 260479987
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 116, 121 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 122, 130 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233683963661656065",
  "text" : "RT @DrJeffreyP: Excited to see my name on @WhiteHouse visitor access records. Open government at work. Thanks again @KS44 @macon44 http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 26, 37 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Kori Schulman",
        "screen_name" : "ks44",
        "indices" : [ 100, 105 ],
        "id_str" : "369246180",
        "id" : 369246180
      }, {
        "name" : "former Macon44",
        "screen_name" : "macon44",
        "indices" : [ 106, 114 ],
        "id_str" : "776593497122082820",
        "id" : 776593497122082820
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/PzkrRobM",
        "expanded_url" : "http:\/\/twitpic.com\/ahd162",
        "display_url" : "twitpic.com\/ahd162"
      } ]
    },
    "geo" : { },
    "id_str" : "233595484420329473",
    "text" : "Excited to see my name on @WhiteHouse visitor access records. Open government at work. Thanks again @KS44 @macon44 http:\/\/t.co\/PzkrRobM",
    "id" : 233595484420329473,
    "created_at" : "2012-08-09 16:07:58 +0000",
    "user" : {
      "name" : "Jeffrey Putman",
      "screen_name" : "DrJeffreyP",
      "protected" : false,
      "id_str" : "260479987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738852440657793024\/OV4G2hyi_normal.jpg",
      "id" : 260479987,
      "verified" : false
    }
  },
  "id" : 233683963661656065,
  "created_at" : "2012-08-09 21:59:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalPTA",
      "screen_name" : "NationalPTA",
      "indices" : [ 3, 15 ],
      "id_str" : "14407823",
      "id" : 14407823
    }, {
      "name" : "Betsy Landers",
      "screen_name" : "PTABetsy",
      "indices" : [ 80, 89 ],
      "id_str" : "745232227",
      "id" : 745232227
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 96, 107 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whpta",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233675334535483392",
  "text" : "RT @NationalPTA: Join us tomorrow, 8\/10 at  12 ET for a live Q&amp;A session w\/ @PTABetsy &amp; @WhiteHouse - ask your Q's w\/ #whpta: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Betsy Landers",
        "screen_name" : "PTABetsy",
        "indices" : [ 63, 72 ],
        "id_str" : "745232227",
        "id" : 745232227
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 79, 90 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whpta",
        "indices" : [ 109, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/Veyj3dF0",
        "expanded_url" : "http:\/\/wh.gov\/YQV0",
        "display_url" : "wh.gov\/YQV0"
      } ]
    },
    "geo" : { },
    "id_str" : "233541850894585856",
    "text" : "Join us tomorrow, 8\/10 at  12 ET for a live Q&amp;A session w\/ @PTABetsy &amp; @WhiteHouse - ask your Q's w\/ #whpta: http:\/\/t.co\/Veyj3dF0",
    "id" : 233541850894585856,
    "created_at" : "2012-08-09 12:34:50 +0000",
    "user" : {
      "name" : "NationalPTA",
      "screen_name" : "NationalPTA",
      "protected" : false,
      "id_str" : "14407823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758745624154025987\/Y4kO8bXD_normal.jpg",
      "id" : 14407823,
      "verified" : false
    }
  },
  "id" : 233675334535483392,
  "created_at" : "2012-08-09 21:25:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PMO India",
      "screen_name" : "PMOIndia",
      "indices" : [ 23, 32 ],
      "id_str" : "471741741",
      "id" : 471741741
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/233657359682129920\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/suM8g5PZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Az4eIXQCUAAbG1w.jpg",
      "id_str" : "233657359698907136",
      "id" : 233657359698907136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Az4eIXQCUAAbG1w.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/suM8g5PZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/OAL7BFdN",
      "expanded_url" : "http:\/\/on.wh.gov\/2R74",
      "display_url" : "on.wh.gov\/2R74"
    } ]
  },
  "geo" : { },
  "id_str" : "233657359682129920",
  "text" : "President Obama called @PMOIndia Dr. Singh to discuss the shooting at a Sikh temple in WI: http:\/\/t.co\/OAL7BFdN Photo: http:\/\/t.co\/suM8g5PZ",
  "id" : 233657359682129920,
  "created_at" : "2012-08-09 20:13:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 65, 78 ],
      "id_str" : "133448051",
      "id" : 133448051
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USWNT",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233642170073116672",
  "text" : "We're so proud of the US women's soccer team #USWNT! Congrats to @ussoccer_wnt. We are cheering for you today! -mo",
  "id" : 233642170073116672,
  "created_at" : "2012-08-09 19:13:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wallace spearmon jr",
      "screen_name" : "PrinceSpearmon",
      "indices" : [ 23, 38 ],
      "id_str" : "185566116",
      "id" : 185566116
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 88, 97 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Olympics",
      "indices" : [ 67, 76 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233629643343794176",
  "text" : "We're cheering for you @princespearmon! Thanks for kicking off the #Olympics with us at @LetsMove London. Let's go #TeamUSA! -mo",
  "id" : 233629643343794176,
  "created_at" : "2012-08-09 18:23:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/233613901084909568\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/DtPWED4B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Az32mvVCYAALoKf.jpg",
      "id_str" : "233613901093298176",
      "id" : 233613901093298176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Az32mvVCYAALoKf.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 416
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 236
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 710
      }, {
        "h" : 8154,
        "resize" : "fit",
        "w" : 2825
      } ],
      "display_url" : "pic.twitter.com\/DtPWED4B"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/xbhuY5Dl",
      "expanded_url" : "http:\/\/on.wh.gov\/GxVo",
      "display_url" : "on.wh.gov\/GxVo"
    } ]
  },
  "geo" : { },
  "id_str" : "233613901084909568",
  "text" : "Infographic: Extending tax cuts for 98% of American families is the right thing to do: http:\/\/t.co\/xbhuY5Dl http:\/\/t.co\/DtPWED4B",
  "id" : 233613901084909568,
  "created_at" : "2012-08-09 17:21:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Misty May-Treanor",
      "screen_name" : "MistyMayTreanor",
      "indices" : [ 48, 64 ],
      "id_str" : "72509949",
      "id" : 72509949
    }, {
      "name" : "Kerri Walsh Jennings",
      "screen_name" : "kerrileewalsh",
      "indices" : [ 65, 79 ],
      "id_str" : "104063340",
      "id" : 104063340
    }, {
      "name" : "Jennifer Kessy",
      "screen_name" : "JenniferKessy",
      "indices" : [ 95, 109 ],
      "id_str" : "156770861",
      "id" : 156770861
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233600996616589313",
  "text" : "Congratulations #TeamUSA beach volleyball stars @MistyMayTreanor @kerrileewalsh @BeachProApril @JenniferKessy! You women are amazing. -mo",
  "id" : 233600996616589313,
  "created_at" : "2012-08-09 16:29:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allyson Felix",
      "screen_name" : "allysonfelix",
      "indices" : [ 3, 16 ],
      "id_str" : "24485503",
      "id" : 24485503
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Allyson Felix",
      "screen_name" : "allysonfelix",
      "indices" : [ 49, 62 ],
      "id_str" : "24485503",
      "id" : 24485503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233587009057329153",
  "text" : "RT @allysonfelix: My pleasure! RT@whitehouse:Yay @allysonfelix! Congrats on winning GOLD! Thx for making us proud &amp;for all you do w\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 15, 26 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Allyson Felix",
        "screen_name" : "allysonfelix",
        "indices" : [ 31, 44 ],
        "id_str" : "24485503",
        "id" : 24485503
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233580611837767680",
    "text" : "My pleasure! RT@whitehouse:Yay @allysonfelix! Congrats on winning GOLD! Thx for making us proud &amp;for all you do w\/ @FitnessGov@LetsMove \u2013mo",
    "id" : 233580611837767680,
    "created_at" : "2012-08-09 15:08:52 +0000",
    "user" : {
      "name" : "Allyson Felix",
      "screen_name" : "allysonfelix",
      "protected" : false,
      "id_str" : "24485503",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764214105225986048\/3zY2j8Vg_normal.jpg",
      "id" : 24485503,
      "verified" : true
    }
  },
  "id" : 233587009057329153,
  "created_at" : "2012-08-09 15:34:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allyson Felix",
      "screen_name" : "allysonfelix",
      "indices" : [ 4, 17 ],
      "id_str" : "24485503",
      "id" : 24485503
    }, {
      "name" : "President's Council",
      "screen_name" : "FitnessGov",
      "indices" : [ 105, 116 ],
      "id_str" : "374019904",
      "id" : 374019904
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 123, 132 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233567267185651712",
  "text" : "Yay @allysonfelix! Congratulations on winning GOLD! Thanks for making us proud &amp; for all you do with @FitnessGov &amp; @LetsMove \u2013mo",
  "id" : 233567267185651712,
  "created_at" : "2012-08-09 14:15:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 90, 99 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/JRqj0nNu",
      "expanded_url" : "http:\/\/on.wh.gov\/78WA",
      "display_url" : "on.wh.gov\/78WA"
    } ]
  },
  "geo" : { },
  "id_str" : "233552014662053888",
  "text" : "Behind the Scenes: First Lady Michelle Obama &amp; the Presidential Olympic Delegation at @LetsMove! London: http:\/\/t.co\/JRqj0nNu",
  "id" : 233552014662053888,
  "created_at" : "2012-08-09 13:15:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Basketball",
      "screen_name" : "usabasketball",
      "indices" : [ 59, 73 ],
      "id_str" : "17049258",
      "id" : 17049258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 50, 58 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/tRk3oWcI",
      "expanded_url" : "http:\/\/on.wh.gov\/tFuT",
      "display_url" : "on.wh.gov\/tFuT"
    } ]
  },
  "geo" : { },
  "id_str" : "233373399769022464",
  "text" : "Go behind the scenes: President Obama visits with #TeamUSA @USABasketball leading up to the #Olympics: http:\/\/t.co\/tRk3oWcI",
  "id" : 233373399769022464,
  "created_at" : "2012-08-09 01:25:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betsy Landers",
      "screen_name" : "PTABetsy",
      "indices" : [ 86, 95 ],
      "id_str" : "745232227",
      "id" : 745232227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHPTA",
      "indices" : [ 137, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/ttZtBvVb",
      "expanded_url" : "http:\/\/on.wh.gov\/eVNg",
      "display_url" : "on.wh.gov\/eVNg"
    } ]
  },
  "geo" : { },
  "id_str" : "233320735408529408",
  "text" : "On 8\/10 at 12ET: Join an \"Open for Questions\" live chat with WH's Cecilia Munoz &amp; @PTABetsy Landers: http:\/\/t.co\/ttZtBvVb  Ask Qs w\/ #WHPTA",
  "id" : 233320735408529408,
  "created_at" : "2012-08-08 21:56:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/233305154764554240\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/cZ0VlQKx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzzdzVsCQAADwxW.jpg",
      "id_str" : "233305154781331456",
      "id" : 233305154781331456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzzdzVsCQAADwxW.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cZ0VlQKx"
    } ],
    "hashtags" : [ {
      "text" : "drought",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/jMh4rFgH",
      "expanded_url" : "http:\/\/on.wh.gov\/bzbj",
      "display_url" : "on.wh.gov\/bzbj"
    } ]
  },
  "geo" : { },
  "id_str" : "233305154764554240",
  "text" : "Photo of the Day: The President meets w\/ his Rural Council to discuss #drought response. More http:\/\/t.co\/jMh4rFgH Pic: http:\/\/t.co\/cZ0VlQKx",
  "id" : 233305154764554240,
  "created_at" : "2012-08-08 20:54:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 147 ],
      "url" : "http:\/\/t.co\/VRviwc9y",
      "expanded_url" : "http:\/\/on.wh.gov\/LgWg",
      "display_url" : "on.wh.gov\/LgWg"
    } ]
  },
  "geo" : { },
  "id_str" : "233282157798383616",
  "text" : "We're back on the WH White Board to explain how smarter regulation protects health &amp; safety &amp; promotes economic goals: http:\/\/t.co\/VRviwc9y",
  "id" : 233282157798383616,
  "created_at" : "2012-08-08 19:22:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bullying",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233280465853878272",
  "text" : "RT @arneduncan: Take the Stop #Bullying Video Challenge &amp; tell us how you can be more than a bystander &amp; help kids http:\/\/t.co\/w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bullying",
        "indices" : [ 14, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/wQARYsWx",
        "expanded_url" : "http:\/\/stopbullying.challenge.gov\/",
        "display_url" : "stopbullying.challenge.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "233209734071742466",
    "text" : "Take the Stop #Bullying Video Challenge &amp; tell us how you can be more than a bystander &amp; help kids http:\/\/t.co\/wQARYsWx",
    "id" : 233209734071742466,
    "created_at" : "2012-08-08 14:35:08 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 233280465853878272,
  "created_at" : "2012-08-08 19:16:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "#CountryOfKindness",
      "screen_name" : "ladygaga",
      "indices" : [ 36, 45 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/4bRbkzSX",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/08\/08\/empowering-young-people-build-kinder-braver-world",
      "display_url" : "whitehouse.gov\/blog\/2012\/08\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233223970613239808",
  "text" : "RT @vj44: Together let\u2019s build what @LadyGaga and her mother Cynthia call \u201Ca kinder, braver world\u201D Read more: http:\/\/t.co\/4bRbkzSX cc: @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#CountryOfKindness",
        "screen_name" : "ladygaga",
        "indices" : [ 26, 35 ],
        "id_str" : "14230524",
        "id" : 14230524
      }, {
        "name" : "Born This Way",
        "screen_name" : "BTWFoundation",
        "indices" : [ 125, 139 ],
        "id_str" : "388521369",
        "id" : 388521369
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/4bRbkzSX",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/08\/08\/empowering-young-people-build-kinder-braver-world",
        "display_url" : "whitehouse.gov\/blog\/2012\/08\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "233209472586248193",
    "text" : "Together let\u2019s build what @LadyGaga and her mother Cynthia call \u201Ca kinder, braver world\u201D Read more: http:\/\/t.co\/4bRbkzSX cc: @BTWFoundation",
    "id" : 233209472586248193,
    "created_at" : "2012-08-08 14:34:05 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 233223970613239808,
  "created_at" : "2012-08-08 15:31:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drought",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/uZAkAJYf",
      "expanded_url" : "http:\/\/on.wh.gov\/PHe7",
      "display_url" : "on.wh.gov\/PHe7"
    } ]
  },
  "geo" : { },
  "id_str" : "233175061547343872",
  "text" : "The U.S. is facing the worst #drought in decades. Find out what the Administration is doing to help those affected: http:\/\/t.co\/uZAkAJYf",
  "id" : 233175061547343872,
  "created_at" : "2012-08-08 12:17:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincent Hancock",
      "screen_name" : "Vincent_hancock",
      "indices" : [ 3, 19 ],
      "id_str" : "386257670",
      "id" : 386257670
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233018047252791296",
  "text" : "RT @Vincent_hancock: @whitehouse Thank you for your support. It is truly a honor to represent my country and my fellow soldiers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "232967232278380544",
    "geo" : { },
    "id_str" : "232982198733656064",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Thank you for your support. It is truly a honor to represent my country and my fellow soldiers.",
    "id" : 232982198733656064,
    "in_reply_to_status_id" : 232967232278380544,
    "created_at" : "2012-08-07 23:30:59 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Vincent Hancock",
      "screen_name" : "Vincent_hancock",
      "protected" : false,
      "id_str" : "386257670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760999734433767424\/WjA3BywW_normal.jpg",
      "id" : 386257670,
      "verified" : true
    }
  },
  "id" : 233018047252791296,
  "created_at" : "2012-08-08 01:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincent Hancock",
      "screen_name" : "Vincent_hancock",
      "indices" : [ 21, 37 ],
      "id_str" : "386257670",
      "id" : 386257670
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USArmy",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232967232278380544",
  "text" : "Congrats #USArmy Sgt @Vincent_hancock on winning Olympic gold! Thank you for your service &amp; your patriotism. We're proud of you. -mo",
  "id" : 232967232278380544,
  "created_at" : "2012-08-07 22:31:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/6LTboPoT",
      "expanded_url" : "http:\/\/on.wh.gov\/XufA",
      "display_url" : "on.wh.gov\/XufA"
    }, {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/2WrPuUEY",
      "expanded_url" : "http:\/\/on.wh.gov\/iCsn",
      "display_url" : "on.wh.gov\/iCsn"
    } ]
  },
  "geo" : { },
  "id_str" : "232951882581176320",
  "text" : "WH Champions of Change: honoring everyday Americans doing extraordinary things: http:\/\/t.co\/6LTboPoT Watch: http:\/\/t.co\/2WrPuUEY #WHChamps",
  "id" : 232951882581176320,
  "created_at" : "2012-08-07 21:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/232936562386673664\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/gGxXimMQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzuOkcCCIAAp8yc.jpg",
      "id_str" : "232936562390867968",
      "id" : 232936562390867968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzuOkcCCIAAp8yc.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gGxXimMQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/mZmdx63z",
      "expanded_url" : "http:\/\/on.wh.gov\/9h1J",
      "display_url" : "on.wh.gov\/9h1J"
    } ]
  },
  "geo" : { },
  "id_str" : "232936562386673664",
  "text" : "Photo of the Day: President Obama talks with advisors in the Oval Office. More pics: http:\/\/t.co\/mZmdx63z Photo: http:\/\/t.co\/gGxXimMQ",
  "id" : 232936562386673664,
  "created_at" : "2012-08-07 20:29:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent Pliskow",
      "screen_name" : "bpliskow",
      "indices" : [ 3, 12 ],
      "id_str" : "97792247",
      "id" : 97792247
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 27, 38 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowWH",
      "indices" : [ 16, 25 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "WHTweetup",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/gwA8EoUb",
      "expanded_url" : "http:\/\/brent.pliskow.com\/blog\/2012\/01\/27\/my-visit-to-the-white-house-for-the-sotu-whtweetup\/",
      "display_url" : "brent.pliskow.com\/blog\/2012\/01\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232868418691424257",
  "text" : "RT @bpliskow: I #FollowWH (@whitehouse) to discover once-in-a-lifetime experiences like the #SOTU #WHTweetup! http:\/\/t.co\/gwA8EoUb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 13, 24 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FollowWH",
        "indices" : [ 2, 11 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 78, 83 ]
      }, {
        "text" : "WHTweetup",
        "indices" : [ 84, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/gwA8EoUb",
        "expanded_url" : "http:\/\/brent.pliskow.com\/blog\/2012\/01\/27\/my-visit-to-the-white-house-for-the-sotu-whtweetup\/",
        "display_url" : "brent.pliskow.com\/blog\/2012\/01\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "232865535279386625",
    "text" : "I #FollowWH (@whitehouse) to discover once-in-a-lifetime experiences like the #SOTU #WHTweetup! http:\/\/t.co\/gwA8EoUb",
    "id" : 232865535279386625,
    "created_at" : "2012-08-07 15:47:24 +0000",
    "user" : {
      "name" : "Brent Pliskow",
      "screen_name" : "bpliskow",
      "protected" : false,
      "id_str" : "97792247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527191290832633856\/OrwCZPwF_normal.jpeg",
      "id" : 97792247,
      "verified" : false
    }
  },
  "id" : 232868418691424257,
  "created_at" : "2012-08-07 15:58:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "American Red Cross",
      "screen_name" : "RedCross",
      "indices" : [ 28, 37 ],
      "id_str" : "6519522",
      "id" : 6519522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hurricane",
      "indices" : [ 38, 48 ]
    }, {
      "text" : "NatlPrep",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/02YdgG0L",
      "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/hurricane-by-american-red\/id545689128?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/hurrica\u2026"
    }, {
      "indices" : [ 93, 114 ],
      "url" : "https:\/\/t.co\/pzqA4pg8",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.cube.arc.hfa",
      "display_url" : "play.google.com\/store\/apps\/det\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232867249046822912",
  "text" : "RT @fema: Check out the new @RedCross #hurricane app for iPhone http:\/\/t.co\/02YdgG0L Android https:\/\/t.co\/pzqA4pg8 #NatlPrep",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "American Red Cross",
        "screen_name" : "RedCross",
        "indices" : [ 18, 27 ],
        "id_str" : "6519522",
        "id" : 6519522
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hurricane",
        "indices" : [ 28, 38 ]
      }, {
        "text" : "NatlPrep",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/02YdgG0L",
        "expanded_url" : "http:\/\/itunes.apple.com\/us\/app\/hurricane-by-american-red\/id545689128?mt=8",
        "display_url" : "itunes.apple.com\/us\/app\/hurrica\u2026"
      }, {
        "indices" : [ 83, 104 ],
        "url" : "https:\/\/t.co\/pzqA4pg8",
        "expanded_url" : "https:\/\/play.google.com\/store\/apps\/details?id=com.cube.arc.hfa",
        "display_url" : "play.google.com\/store\/apps\/det\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "232866318301401088",
    "text" : "Check out the new @RedCross #hurricane app for iPhone http:\/\/t.co\/02YdgG0L Android https:\/\/t.co\/pzqA4pg8 #NatlPrep",
    "id" : 232866318301401088,
    "created_at" : "2012-08-07 15:50:31 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 232867249046822912,
  "created_at" : "2012-08-07 15:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 22, 25 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/232683586510286848\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/XktjBhNq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzqofTdCcAIW6uR.jpg",
      "id_str" : "232683586514481154",
      "id" : 232683586514481154,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzqofTdCcAIW6uR.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/XktjBhNq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/kfA200pJ",
      "expanded_url" : "http:\/\/on.wh.gov\/Tu4h",
      "display_url" : "on.wh.gov\/Tu4h"
    } ]
  },
  "geo" : { },
  "id_str" : "232683586510286848",
  "text" : "President Obama &amp; @VP Biden pose with the full Cabinet for the latest official group photo:  http:\/\/t.co\/kfA200pJ Pic: http:\/\/t.co\/XktjBhNq",
  "id" : 232683586510286848,
  "created_at" : "2012-08-07 03:44:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/232644822954020864\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/KH2ZIV83",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzqFO99CEAAU8Dl.jpg",
      "id_str" : "232644822958215168",
      "id" : 232644822958215168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzqFO99CEAAU8Dl.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/KH2ZIV83"
    } ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/yvgfwb7q",
      "expanded_url" : "http:\/\/on.wh.gov\/SSCw",
      "display_url" : "on.wh.gov\/SSCw"
    } ]
  },
  "geo" : { },
  "id_str" : "232644822954020864",
  "text" : "VA Employee &amp; medal winning Olympian @NatalieSDell on #veterans and never giving up: http:\/\/t.co\/yvgfwb7q Photo: http:\/\/t.co\/KH2ZIV83",
  "id" : 232644822954020864,
  "created_at" : "2012-08-07 01:10:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232629230603755520",
  "text" : "Welcome home Katie Ledecky! You are a true inspiration to young people everywhere. Congrats! -mo",
  "id" : 232629230603755520,
  "created_at" : "2012-08-07 00:08:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/232601189345267712\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/UADguw9L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzpdjKHCEAAsmGD.jpg",
      "id_str" : "232601189353656320",
      "id" : 232601189353656320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzpdjKHCEAAsmGD.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/UADguw9L"
    } ],
    "hashtags" : [ {
      "text" : "Veterans",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/7geJChgr",
      "expanded_url" : "http:\/\/on.wh.gov\/z9YI",
      "display_url" : "on.wh.gov\/z9YI"
    } ]
  },
  "geo" : { },
  "id_str" : "232601189345267712",
  "text" : "President Obama signs Honoring America's #Veterans &amp; Caring for Camp Lejeune Families Act: http:\/\/t.co\/7geJChgr  Photo: http:\/\/t.co\/UADguw9L",
  "id" : 232601189345267712,
  "created_at" : "2012-08-06 22:17:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Serena Williams",
      "screen_name" : "serenawilliams",
      "indices" : [ 9, 24 ],
      "id_str" : "26589987",
      "id" : 26589987
    }, {
      "name" : "Venus Williams",
      "screen_name" : "Venuseswilliams",
      "indices" : [ 31, 47 ],
      "id_str" : "50725573",
      "id" : 50725573
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232585821205721089",
  "text" : "Congrats @SerenaWilliams &amp; @VenusesWilliams! Seeing you play together is awe inspiring! We're so proud of you! \u2013mo",
  "id" : 232585821205721089,
  "created_at" : "2012-08-06 21:15:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/7xa81Aue",
      "expanded_url" : "http:\/\/on.wh.gov\/ActJ",
      "display_url" : "on.wh.gov\/ActJ"
    } ]
  },
  "geo" : { },
  "id_str" : "232570208760516608",
  "text" : "President Obama orders US flags to be flown at half-staff in honor of the Oak Creek victims. Presidential Proclamation: http:\/\/t.co\/7xa81Aue",
  "id" : 232570208760516608,
  "created_at" : "2012-08-06 20:13:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 108, 113 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 114, 128 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Curiosity",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/Yyx9CvwE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/08\/06\/statement-president-curiosity-landing-mars",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232469867847114752",
  "text" : "RT @whitehouseostp: Statement by the President on Curiosity Landing on Mars http:\/\/t.co\/Yyx9CvwE #Curiosity @NASA @MarsCuriosity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 88, 93 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "Curiosity Rover",
        "screen_name" : "MarsCuriosity",
        "indices" : [ 94, 108 ],
        "id_str" : "15473958",
        "id" : 15473958
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Curiosity",
        "indices" : [ 77, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/Yyx9CvwE",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/08\/06\/statement-president-curiosity-landing-mars",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "232467977121959937",
    "text" : "Statement by the President on Curiosity Landing on Mars http:\/\/t.co\/Yyx9CvwE #Curiosity @NASA @MarsCuriosity",
    "id" : 232467977121959937,
    "created_at" : "2012-08-06 13:27:39 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 232469867847114752,
  "created_at" : "2012-08-06 13:35:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/Z0zYHvDh",
      "expanded_url" : "http:\/\/on.wh.gov\/Tw1g",
      "display_url" : "on.wh.gov\/Tw1g"
    } ]
  },
  "geo" : { },
  "id_str" : "232271213358092289",
  "text" : "\"The people of Oak Creek must know that the American people have them in our thoughts &amp; prayers\" -President Obama: http:\/\/t.co\/Z0zYHvDh",
  "id" : 232271213358092289,
  "created_at" : "2012-08-06 00:25:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/acDfU2Vc",
      "expanded_url" : "http:\/\/on.wh.gov\/1IQa",
      "display_url" : "on.wh.gov\/1IQa"
    } ]
  },
  "geo" : { },
  "id_str" : "232224279855509504",
  "text" : "\"Michelle &amp; I were deeply saddened\" -Statement by President Obama on the shooting in Wisconsin: http:\/\/t.co\/acDfU2Vc",
  "id" : 232224279855509504,
  "created_at" : "2012-08-05 21:19:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 96, 107 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/WRtnSetq",
      "expanded_url" : "http:\/\/on.wh.gov\/z62l",
      "display_url" : "on.wh.gov\/z62l"
    } ]
  },
  "geo" : { },
  "id_str" : "232098679719329792",
  "text" : "\"These games remind us that for all our differences, we're Americans first\" -President Obama on #London2012 #Olympics: http:\/\/t.co\/WRtnSetq",
  "id" : 232098679719329792,
  "created_at" : "2012-08-05 13:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/231930822553382912\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/jPxgvnTY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Azf72rMCMAAM-au.jpg",
      "id_str" : "231930822557577216",
      "id" : 231930822557577216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Azf72rMCMAAM-au.jpg",
      "sizes" : [ {
        "h" : 699,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jPxgvnTY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/4iXdBEJU",
      "expanded_url" : "http:\/\/on.wh.gov\/hkkE",
      "display_url" : "on.wh.gov\/hkkE"
    } ]
  },
  "geo" : { },
  "id_str" : "231930822553382912",
  "text" : "Happy Birthday, President Obama: http:\/\/t.co\/4iXdBEJU In honor of the President's 51st, we share 51 favorite photos: http:\/\/t.co\/jPxgvnTY",
  "id" : 231930822553382912,
  "created_at" : "2012-08-05 01:53:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Phelps",
      "screen_name" : "MichaelPhelps",
      "indices" : [ 4, 18 ],
      "id_str" : "225539878",
      "id" : 225539878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231893070990426112",
  "text" : "Wow @MichaelPhelps! Barack &amp; I have been cheering you on! We're so proud of you &amp; what you've accomplished. -mo",
  "id" : 231893070990426112,
  "created_at" : "2012-08-04 23:23:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Douglas",
      "screen_name" : "gabrielledoug",
      "indices" : [ 1, 15 ],
      "id_str" : "279319647",
      "id" : 279319647
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231821020942708736",
  "text" : ".@gabrielledoug I'm so proud of you! As a military daughter, thank you for your service &amp; sacrifice. Let's go #TeamUSA! -mo",
  "id" : 231821020942708736,
  "created_at" : "2012-08-04 18:36:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "storify",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "FollowWH",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/c2Kh9GW2",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/08\/04\/celebrating-3000000-whitehouse-twitter-followers",
      "display_url" : "whitehouse.gov\/blog\/2012\/08\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "231809622112100353",
  "text" : "RT @gov: The @whitehouse hits 3M followers and posts #storify of its history on Twitter, asking \"Why do you #FollowWH?\" http:\/\/t.co\/c2Kh9GW2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "storify",
        "indices" : [ 44, 52 ]
      }, {
        "text" : "FollowWH",
        "indices" : [ 99, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/c2Kh9GW2",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/08\/04\/celebrating-3000000-whitehouse-twitter-followers",
        "display_url" : "whitehouse.gov\/blog\/2012\/08\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "231787463541129216",
    "text" : "The @whitehouse hits 3M followers and posts #storify of its history on Twitter, asking \"Why do you #FollowWH?\" http:\/\/t.co\/c2Kh9GW2",
    "id" : 231787463541129216,
    "created_at" : "2012-08-04 16:23:32 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663898965784395776\/rEWW6euI_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 231809622112100353,
  "created_at" : "2012-08-04 17:51:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Serena Williams",
      "screen_name" : "serenawilliams",
      "indices" : [ 15, 30 ],
      "id_str" : "26589987",
      "id" : 26589987
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231767703386480642",
  "text" : "RT @letsmove: .@SerenaWilliams: Congrats on winning gold -- we are so proud of you!!! Let's go #TeamUSA! -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Serena Williams",
        "screen_name" : "serenawilliams",
        "indices" : [ 1, 16 ],
        "id_str" : "26589987",
        "id" : 26589987
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 81, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231765708030214144",
    "text" : ".@SerenaWilliams: Congrats on winning gold -- we are so proud of you!!! Let's go #TeamUSA! -mo",
    "id" : 231765708030214144,
    "created_at" : "2012-08-04 14:57:05 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 231767703386480642,
  "created_at" : "2012-08-04 15:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/gckV7iTs",
      "expanded_url" : "http:\/\/on.wh.gov\/QXud",
      "display_url" : "on.wh.gov\/QXud"
    } ]
  },
  "geo" : { },
  "id_str" : "231758682495545344",
  "text" : "\"Your country could not be prouder of you\" -President Obama to all Olympic &amp; Paralympic athletes: http:\/\/t.co\/gckV7iTs",
  "id" : 231758682495545344,
  "created_at" : "2012-08-04 14:29:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowWH",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231699738116898816",
  "text" : "RT @carmeena_m: @whitehouse Better question-why would you not #FollowWH? The President represents all Americans on the world stage, so I ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FollowWH",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "231689487292452865",
    "geo" : { },
    "id_str" : "231694687969357824",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Better question-why would you not #FollowWH? The President represents all Americans on the world stage, so I'm def keeping up!",
    "id" : 231694687969357824,
    "in_reply_to_status_id" : 231689487292452865,
    "created_at" : "2012-08-04 10:14:52 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Carmen Mitchell",
      "screen_name" : "carmenrmitchell",
      "protected" : false,
      "id_str" : "589489333",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752607942302662656\/WwVAFJNI_normal.jpg",
      "id" : 589489333,
      "verified" : false
    }
  },
  "id" : 231699738116898816,
  "created_at" : "2012-08-04 10:34:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Bernal",
      "screen_name" : "2Jarhead",
      "indices" : [ 3, 12 ],
      "id_str" : "289586387",
      "id" : 289586387
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowWH",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231699070425640960",
  "text" : "RT @2Jarhead: @whitehouse To keep updated with the happening being overseas its difficult sometimes #FollowWH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FollowWH",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "231689487292452865",
    "geo" : { },
    "id_str" : "231692691958792192",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse To keep updated with the happening being overseas its difficult sometimes #FollowWH",
    "id" : 231692691958792192,
    "in_reply_to_status_id" : 231689487292452865,
    "created_at" : "2012-08-04 10:06:57 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Jose Bernal",
      "screen_name" : "2Jarhead",
      "protected" : false,
      "id_str" : "289586387",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675443734759231488\/DkZqcriS_normal.jpg",
      "id" : 289586387,
      "verified" : false
    }
  },
  "id" : 231699070425640960,
  "created_at" : "2012-08-04 10:32:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ImAWitchyWoman",
      "screen_name" : "spinningcastle",
      "indices" : [ 3, 18 ],
      "id_str" : "38981727",
      "id" : 38981727
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231698642107498496",
  "text" : "RT @spinningcastle: .@whitehouse It's quickest &amp; most direct way to know what The Prez is doing on DAILY basis. #improvesmysmartquot ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "improvesmysmartquota",
        "indices" : [ 96, 117 ]
      }, {
        "text" : "FollowWH",
        "indices" : [ 118, 127 ]
      }, {
        "text" : "BEinformed",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "231689487292452865",
    "geo" : { },
    "id_str" : "231694429193388032",
    "in_reply_to_user_id" : 30313925,
    "text" : ".@whitehouse It's quickest &amp; most direct way to know what The Prez is doing on DAILY basis. #improvesmysmartquota #FollowWH #BEinformed",
    "id" : 231694429193388032,
    "in_reply_to_status_id" : 231689487292452865,
    "created_at" : "2012-08-04 10:13:51 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "ImAWitchyWoman",
      "screen_name" : "spinningcastle",
      "protected" : false,
      "id_str" : "38981727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797641511944994816\/9q3VhT2-_normal.jpg",
      "id" : 38981727,
      "verified" : false
    }
  },
  "id" : 231698642107498496,
  "created_at" : "2012-08-04 10:30:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 1, 12 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 31, 39 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/231689487292452865\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/OxD060T0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzcgXHTCUAAY-tn.jpg",
      "id_str" : "231689487300841472",
      "id" : 231689487300841472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzcgXHTCUAAY-tn.jpg",
      "sizes" : [ {
        "h" : 289,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/OxD060T0"
    } ],
    "hashtags" : [ {
      "text" : "FollowWH",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/Dc7U16lS",
      "expanded_url" : "http:\/\/on.wh.gov\/US9D",
      "display_url" : "on.wh.gov\/US9D"
    } ]
  },
  "geo" : { },
  "id_str" : "231689487292452865",
  "text" : ".@whitehouse reaches 3 million @twitter followers! http:\/\/t.co\/Dc7U16lS We want to hear from you: why do you #FollowWH? http:\/\/t.co\/OxD060T0",
  "id" : 231689487292452865,
  "created_at" : "2012-08-04 09:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/231560556400758787\/photo\/1",
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/cMorG7w2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzarGWSCUAAVlgi.jpg",
      "id_str" : "231560556404953088",
      "id" : 231560556404953088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzarGWSCUAAVlgi.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cMorG7w2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231560556400758787",
  "text" : "Photo of the Day: President Obama walks in the White House Kitchen Garden on the South Lawn: http:\/\/t.co\/cMorG7w2",
  "id" : 231560556400758787,
  "created_at" : "2012-08-04 01:21:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/K9Iq996w",
      "expanded_url" : "http:\/\/on.wh.gov\/NreW",
      "display_url" : "on.wh.gov\/NreW"
    } ]
  },
  "geo" : { },
  "id_str" : "231492398889451520",
  "text" : "Wanna help find solutions to the world's humanitarian challenges? Check out Patents for Humanity: http:\/\/t.co\/K9Iq996w",
  "id" : 231492398889451520,
  "created_at" : "2012-08-03 20:51:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/nUsGv2ox",
      "expanded_url" : "http:\/\/on.wh.gov\/wUBX",
      "display_url" : "on.wh.gov\/wUBX"
    } ]
  },
  "geo" : { },
  "id_str" : "231472906947932161",
  "text" : "VIDEO: Your behind the scenes guide to this week at 1600 Pennsylvania Ave: West Wing Week 08\/03\/12 or \"98 &amp; 98\": http:\/\/t.co\/nUsGv2ox",
  "id" : 231472906947932161,
  "created_at" : "2012-08-03 19:33:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231421795960496128",
  "text" : "RT @WHLive: Obama: \"If Congress sends me a clean bill extending the tax cuts on the first $250,000 of every family\u2019s income, I will sign ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231421750204829697",
    "text" : "Obama: \"If Congress sends me a clean bill extending the tax cuts on the first $250,000 of every family\u2019s income, I will sign it right away\"",
    "id" : 231421750204829697,
    "created_at" : "2012-08-03 16:10:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 231421795960496128,
  "created_at" : "2012-08-03 16:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231421167016218625",
  "text" : "RT @WHLive: President Obama: \"The people standing behind me shouldn\u2019t have to pay more just so that the wealthiest Americans can pay less\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231421128495755264",
    "text" : "President Obama: \"The people standing behind me shouldn\u2019t have to pay more just so that the wealthiest Americans can pay less\"",
    "id" : 231421128495755264,
    "created_at" : "2012-08-03 16:07:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 231421167016218625,
  "created_at" : "2012-08-03 16:08:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "231420404244303872",
  "text" : "President Obama: \"Rebuilding a strong economy begins with rebuilding a strong middle class.\" http:\/\/t.co\/u95tzH8r",
  "id" : 231420404244303872,
  "created_at" : "2012-08-03 16:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 114, 121 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 41, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/pX3nWkNC",
      "expanded_url" : "http:\/\/on.wh.gov\/qFVy",
      "display_url" : "on.wh.gov\/qFVy"
    } ]
  },
  "geo" : { },
  "id_str" : "231419472395784193",
  "text" : "Happening now: President Obama speaks on #MiddleClassTaxCuts. Watch live: http:\/\/t.co\/pX3nWkNC Follow on Twitter: @WHLive",
  "id" : 231419472395784193,
  "created_at" : "2012-08-03 16:01:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 120, 127 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 58, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/dZ3g4680",
      "expanded_url" : "http:\/\/on.wh.gov\/1dp6",
      "display_url" : "on.wh.gov\/1dp6"
    } ]
  },
  "geo" : { },
  "id_str" : "231408703092453376",
  "text" : "Happening at 11:45 a.m. ET: President Obama speaks on the #MiddleClassTaxCuts. Watch live: http:\/\/t.co\/dZ3g4680 Follow: @whlive",
  "id" : 231408703092453376,
  "created_at" : "2012-08-03 15:18:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 23, 28 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "NASA Commercial Crew",
      "screen_name" : "Commercial_Crew",
      "indices" : [ 110, 126 ],
      "id_str" : "376819015",
      "id" : 376819015
    }, {
      "name" : "The Boeing Company",
      "screen_name" : "Boeing",
      "indices" : [ 127, 134 ],
      "id_str" : "25103967",
      "id" : 25103967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/6oUGjsgt",
      "expanded_url" : "http:\/\/go.nasa.gov\/RhjsFE",
      "display_url" : "go.nasa.gov\/RhjsFE"
    } ]
  },
  "geo" : { },
  "id_str" : "231390995491717121",
  "text" : "RT @whitehouseostp: MT @NASA Announces Next Steps in Launching Americans from U.S. Soil  http:\/\/t.co\/6oUGjsgt @Commercial_Crew @Boeing @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 3, 8 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "NASA Commercial Crew",
        "screen_name" : "Commercial_Crew",
        "indices" : [ 90, 106 ],
        "id_str" : "376819015",
        "id" : 376819015
      }, {
        "name" : "The Boeing Company",
        "screen_name" : "Boeing",
        "indices" : [ 107, 114 ],
        "id_str" : "25103967",
        "id" : 25103967
      }, {
        "name" : "SpaceX",
        "screen_name" : "SpaceX",
        "indices" : [ 115, 122 ],
        "id_str" : "34743251",
        "id" : 34743251
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SierraNevada",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/6oUGjsgt",
        "expanded_url" : "http:\/\/go.nasa.gov\/RhjsFE",
        "display_url" : "go.nasa.gov\/RhjsFE"
      } ]
    },
    "geo" : { },
    "id_str" : "231387922606215168",
    "text" : "MT @NASA Announces Next Steps in Launching Americans from U.S. Soil  http:\/\/t.co\/6oUGjsgt @Commercial_Crew @Boeing @SpaceX #SierraNevada",
    "id" : 231387922606215168,
    "created_at" : "2012-08-03 13:55:54 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 231390995491717121,
  "created_at" : "2012-08-03 14:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/231192788086165504\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/hW0pSIwS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzVcnakCEAAfHGL.jpg",
      "id_str" : "231192788094554112",
      "id" : 231192788094554112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzVcnakCEAAfHGL.jpg",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1285,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hW0pSIwS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231192788086165504",
  "text" : "Photo of the Day: President Obama talks with patrons at Lechonera El Barrio, a local restaurant in Orlando, Florida: http:\/\/t.co\/hW0pSIwS",
  "id" : 231192788086165504,
  "created_at" : "2012-08-03 01:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 105, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/WxGqOm7N",
      "expanded_url" : "http:\/\/on.wh.gov\/er8B",
      "display_url" : "on.wh.gov\/er8B"
    } ]
  },
  "geo" : { },
  "id_str" : "231177283593969664",
  "text" : "President Obama is talking taxes tomorrow. Watch live on Friday 8\/3 at 11:45 am ET: http:\/\/t.co\/WxGqOm7N #MiddleClassTaxCuts",
  "id" : 231177283593969664,
  "created_at" : "2012-08-02 23:58:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WTCProgress",
      "screen_name" : "WTCProgress",
      "indices" : [ 104, 116 ],
      "id_str" : "223976521",
      "id" : 223976521
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/231142731890716673\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/zBsU6kSQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzUvFwtCcAEypEU.jpg",
      "id_str" : "231142731899105281",
      "id" : 231142731899105281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzUvFwtCcAEypEU.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zBsU6kSQ"
    } ],
    "hashtags" : [ {
      "text" : "OneWTC",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/0BGXzdpZ",
      "expanded_url" : "http:\/\/on.wh.gov\/v4tY",
      "display_url" : "on.wh.gov\/v4tY"
    } ]
  },
  "geo" : { },
  "id_str" : "231142731890716673",
  "text" : "The beam signed by President Obama was installed at #OneWTC today. Learn more: http:\/\/t.co\/0BGXzdpZ Pic @WTCProgress: http:\/\/t.co\/zBsU6kSQ",
  "id" : 231142731890716673,
  "created_at" : "2012-08-02 21:41:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 119, 126 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 147 ],
      "url" : "http:\/\/t.co\/H1O3uRZ9",
      "expanded_url" : "http:\/\/on.wh.gov\/CkzM",
      "display_url" : "on.wh.gov\/CkzM"
    } ]
  },
  "geo" : { },
  "id_str" : "231117483761868800",
  "text" : "At 5ET: Join a Twitter Q&amp;A on preventive care benefits for women. Ask your questions w\/ #WHChat &amp; follow along @WHLive http:\/\/t.co\/H1O3uRZ9",
  "id" : 231117483761868800,
  "created_at" : "2012-08-02 20:01:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WTCProgress",
      "screen_name" : "WTCProgress",
      "indices" : [ 124, 136 ],
      "id_str" : "223976521",
      "id" : 223976521
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WTCProgress\/status\/231072528959946752\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/GmsOdjHk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzTvPaaCQAEpYnz.jpg",
      "id_str" : "231072528968335361",
      "id" : 231072528968335361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzTvPaaCQAEpYnz.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1362,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GmsOdjHk"
    } ],
    "hashtags" : [ {
      "text" : "WTC",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231077346038382592",
  "text" : "We remember. We rebuild. We come back stronger. Proud as the final beam is installed atop One #WTC -bo http:\/\/t.co\/GmsOdjHk @WTCProgress",
  "id" : 231077346038382592,
  "created_at" : "2012-08-02 17:21:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "USA Swimming",
      "screen_name" : "USA_Swimming",
      "indices" : [ 24, 37 ],
      "id_str" : "2830301540",
      "id" : 2830301540
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 73, 84 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231069040095944705",
  "text" : "RT @VP: Congratulations @USA_Swimming for all your success so far at the #London2012 #Olympics.  Go #TeamUSA ! --VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA Swimming",
        "screen_name" : "USA_Swimming",
        "indices" : [ 16, 29 ],
        "id_str" : "2830301540",
        "id" : 2830301540
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "London2012",
        "indices" : [ 65, 76 ]
      }, {
        "text" : "Olympics",
        "indices" : [ 77, 86 ]
      }, {
        "text" : "TeamUSA",
        "indices" : [ 92, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231066415841558529",
    "text" : "Congratulations @USA_Swimming for all your success so far at the #London2012 #Olympics.  Go #TeamUSA ! --VP",
    "id" : 231066415841558529,
    "created_at" : "2012-08-02 16:38:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 231069040095944705,
  "created_at" : "2012-08-02 16:48:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/xP9WLlW0",
      "expanded_url" : "http:\/\/on.wh.gov\/TV4Y",
      "display_url" : "on.wh.gov\/TV4Y"
    } ]
  },
  "geo" : { },
  "id_str" : "231044716001636352",
  "text" : "Today at 5 ET join WH Office Hours on new women's preventive care benefits. Ask questions now using #WHChat. More info: http:\/\/t.co\/xP9WLlW0",
  "id" : 231044716001636352,
  "created_at" : "2012-08-02 15:12:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/230845810273837056\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/3fHGv875",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzQhCpfCYAAdf8A.jpg",
      "id_str" : "230845810282225664",
      "id" : 230845810282225664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzQhCpfCYAAdf8A.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3fHGv875"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/o88B7M7E",
      "expanded_url" : "http:\/\/on.wh.gov\/j5WS",
      "display_url" : "on.wh.gov\/j5WS"
    } ]
  },
  "geo" : { },
  "id_str" : "230845810273837056",
  "text" : "President Obama meets with Vice President Biden in the Oval Office, July 31, 2012. More pics: http:\/\/t.co\/o88B7M7E http:\/\/t.co\/3fHGv875",
  "id" : 230845810273837056,
  "created_at" : "2012-08-02 02:01:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/230824999605391360\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Kak3qAwz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzQOHTtCUAA8NHr.jpg",
      "id_str" : "230824999613779968",
      "id" : 230824999613779968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzQOHTtCUAA8NHr.jpg",
      "sizes" : [ {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Kak3qAwz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230824999605391360",
  "text" : "\"You guys amaze us the most\" -President Obama calls to congratulate the US Olympic women's gymnastics team from AF1: http:\/\/t.co\/Kak3qAwz",
  "id" : 230824999605391360,
  "created_at" : "2012-08-02 00:39:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/230809760004440066\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/8pXqSJrQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzQAQPzCAAAtVmk.jpg",
      "id_str" : "230809760021217280",
      "id" : 230809760021217280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzQAQPzCAAAtVmk.jpg",
      "sizes" : [ {
        "h" : 816,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/8pXqSJrQ"
    } ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 74, 78 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/GD2aank5",
      "expanded_url" : "http:\/\/on.wh.gov\/ES1f",
      "display_url" : "on.wh.gov\/ES1f"
    } ]
  },
  "geo" : { },
  "id_str" : "230809760004440066",
  "text" : "Tomorrow at 5 ET: Join WH Office Hours on preventive care for women &amp; #HCR: http:\/\/t.co\/GD2aank5 Ask Q's now w\/ #WHChat http:\/\/t.co\/8pXqSJrQ",
  "id" : 230809760004440066,
  "created_at" : "2012-08-01 23:38:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/KfGj5fpQ",
      "expanded_url" : "http:\/\/on.wh.gov\/C7cO",
      "display_url" : "on.wh.gov\/C7cO"
    } ]
  },
  "geo" : { },
  "id_str" : "230792000700551169",
  "text" : "13 million Americans will receive more than $1 billion from insurance companies this summer. Find out why: http:\/\/t.co\/KfGj5fpQ",
  "id" : 230792000700551169,
  "created_at" : "2012-08-01 22:27:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/230776412355842048\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/cxL8AL4p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzPh7KGCUAEcjS7.jpg",
      "id_str" : "230776412364230657",
      "id" : 230776412364230657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzPh7KGCUAEcjS7.jpg",
      "sizes" : [ {
        "h" : 816,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/cxL8AL4p"
    } ],
    "hashtags" : [ {
      "text" : "healthreform",
      "indices" : [ 75, 88 ]
    }, {
      "text" : "hcr",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/i8Amv4Co",
      "expanded_url" : "http:\/\/on.wh.gov\/wKCn",
      "display_url" : "on.wh.gov\/wKCn"
    } ]
  },
  "geo" : { },
  "id_str" : "230776412355842048",
  "text" : "Check out 8 new free preventive care services available to women thanks to #healthreform: http:\/\/t.co\/i8Amv4Co #hcr http:\/\/t.co\/cxL8AL4p",
  "id" : 230776412355842048,
  "created_at" : "2012-08-01 21:25:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/230764892053970945\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/iYeZYlPK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzPXcloCIAAj0cU.jpg",
      "id_str" : "230764892062359552",
      "id" : 230764892062359552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzPXcloCIAAj0cU.jpg",
      "sizes" : [ {
        "h" : 816,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/iYeZYlPK"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "herhealth",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/VF3OkTgZ",
      "expanded_url" : "http:\/\/on.wh.gov\/taHM",
      "display_url" : "on.wh.gov\/taHM"
    } ]
  },
  "geo" : { },
  "id_str" : "230764892053970945",
  "text" : "8 preventative care services now free for women thanks to #ACA: http:\/\/t.co\/VF3OkTgZ RT to spread the word. #herhealth http:\/\/t.co\/iYeZYlPK",
  "id" : 230764892053970945,
  "created_at" : "2012-08-01 20:40:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyla Ross",
      "screen_name" : "kyla_ross96",
      "indices" : [ 3, 15 ],
      "id_str" : "528717274",
      "id" : 528717274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230743479746166784",
  "text" : "RT @kyla_ross96: Such an honor getting to talking to the President on the phone!!!! Thanks for supporting us!\uD83C\uDDFA\uD83C\uDDF8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230685061211639808",
    "text" : "Such an honor getting to talking to the President on the phone!!!! Thanks for supporting us!\uD83C\uDDFA\uD83C\uDDF8",
    "id" : 230685061211639808,
    "created_at" : "2012-08-01 15:22:59 +0000",
    "user" : {
      "name" : "Kyla Ross",
      "screen_name" : "kyla_ross96",
      "protected" : false,
      "id_str" : "528717274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720113959114772480\/XTSAkdAg_normal.jpg",
      "id" : 528717274,
      "verified" : true
    }
  },
  "id" : 230743479746166784,
  "created_at" : "2012-08-01 19:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McKayla Maroney",
      "screen_name" : "McKaylaMaroney",
      "indices" : [ 3, 18 ],
      "id_str" : "375383001",
      "id" : 375383001
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whaaaat",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "ProudToBeAnAmerican",
      "indices" : [ 116, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230743434460270592",
  "text" : "RT @McKaylaMaroney: Just talked to the President of the United States..\uD83C\uDDFA\uD83C\uDDF8 #whaaaat So grateful!! That was amazing!! #ProudToBeAnAmerican",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whaaaat",
        "indices" : [ 54, 62 ]
      }, {
        "text" : "ProudToBeAnAmerican",
        "indices" : [ 96, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230681860873785345",
    "text" : "Just talked to the President of the United States..\uD83C\uDDFA\uD83C\uDDF8 #whaaaat So grateful!! That was amazing!! #ProudToBeAnAmerican",
    "id" : 230681860873785345,
    "created_at" : "2012-08-01 15:10:16 +0000",
    "user" : {
      "name" : "McKayla Maroney",
      "screen_name" : "McKaylaMaroney",
      "protected" : false,
      "id_str" : "375383001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785233815442554880\/5hg0XZST_normal.jpg",
      "id" : 375383001,
      "verified" : true
    }
  },
  "id" : 230743434460270592,
  "created_at" : "2012-08-01 19:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Douglas",
      "screen_name" : "gabrielledoug",
      "indices" : [ 3, 17 ],
      "id_str" : "279319647",
      "id" : 279319647
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankyou",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230742929084391424",
  "text" : "RT @gabrielledoug: Just talked to the President of the United States!!! WOW such and honor and a amazing feeling!! \uD83C\uDDFA\uD83C\uDDF8\uD83D\uDE04 #thankyou",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thankyou",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230684596054933504",
    "text" : "Just talked to the President of the United States!!! WOW such and honor and a amazing feeling!! \uD83C\uDDFA\uD83C\uDDF8\uD83D\uDE04 #thankyou",
    "id" : 230684596054933504,
    "created_at" : "2012-08-01 15:21:08 +0000",
    "user" : {
      "name" : "Gabrielle Douglas",
      "screen_name" : "gabrielledoug",
      "protected" : false,
      "id_str" : "279319647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788218088785227776\/KtcsHeJb_normal.jpg",
      "id" : 279319647,
      "verified" : true
    }
  },
  "id" : 230742929084391424,
  "created_at" : "2012-08-01 19:12:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandra Raisman",
      "screen_name" : "Aly_Raisman",
      "indices" : [ 3, 15 ],
      "id_str" : "372891057",
      "id" : 372891057
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 17, 29 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230742815204851712",
  "text" : "RT @Aly_Raisman: @BarackObama So nice of you to talk to all of us!!! So honored to be able to speak to you on the phone! Thank you for e ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 0, 12 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "230681303157186560",
    "in_reply_to_user_id" : 813286,
    "text" : "@BarackObama So nice of you to talk to all of us!!! So honored to be able to speak to you on the phone! Thank you for everything! :)",
    "id" : 230681303157186560,
    "created_at" : "2012-08-01 15:08:03 +0000",
    "in_reply_to_screen_name" : "BarackObama",
    "in_reply_to_user_id_str" : "813286",
    "user" : {
      "name" : "Alexandra Raisman",
      "screen_name" : "Aly_Raisman",
      "protected" : false,
      "id_str" : "372891057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770653602771677184\/F2K8uqAS_normal.jpg",
      "id" : 372891057,
      "verified" : true
    }
  },
  "id" : 230742815204851712,
  "created_at" : "2012-08-01 19:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandra Raisman",
      "screen_name" : "Aly_Raisman",
      "indices" : [ 49, 61 ],
      "id_str" : "372891057",
      "id" : 372891057
    }, {
      "name" : "Gabrielle Douglas",
      "screen_name" : "gabrielledoug",
      "indices" : [ 62, 76 ],
      "id_str" : "279319647",
      "id" : 279319647
    }, {
      "name" : "Jordyn Wieber",
      "screen_name" : "jordyn_wieber",
      "indices" : [ 77, 91 ],
      "id_str" : "35364809",
      "id" : 35364809
    }, {
      "name" : "McKayla Maroney",
      "screen_name" : "McKaylaMaroney",
      "indices" : [ 92, 107 ],
      "id_str" : "375383001",
      "id" : 375383001
    }, {
      "name" : "Kyla Ross",
      "screen_name" : "kyla_ross96",
      "indices" : [ 108, 120 ],
      "id_str" : "528717274",
      "id" : 528717274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230742188559060992",
  "text" : "Today President Obama called \u201CFab Five\u201D gymnasts @Aly_Raisman @GabrielleDoug @Jordyn_Wieber @McKaylaMaroney @Kyla_Ross96 to say congrats",
  "id" : 230742188559060992,
  "created_at" : "2012-08-01 19:09:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    }, {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 72, 78 ],
      "id_str" : "25928253",
      "id" : 25928253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womenshealth",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230695694611148801",
  "text" : "RT @HealthCareGov: JOIN online chat today, 1:30pm w\/ Sec Sebelius &amp; @WebMD on #womenshealth &amp; new preventive benefits. http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WebMD",
        "screen_name" : "WebMD",
        "indices" : [ 53, 59 ],
        "id_str" : "25928253",
        "id" : 25928253
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womenshealth",
        "indices" : [ 63, 76 ]
      }, {
        "text" : "herhealth",
        "indices" : [ 129, 139 ]
      }, {
        "text" : "ACA",
        "indices" : [ 140, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/CHANfty9",
        "expanded_url" : "http:\/\/1.usa.gov\/Mh5nHy",
        "display_url" : "1.usa.gov\/Mh5nHy"
      } ]
    },
    "geo" : { },
    "id_str" : "230639289019535360",
    "text" : "JOIN online chat today, 1:30pm w\/ Sec Sebelius &amp; @WebMD on #womenshealth &amp; new preventive benefits. http:\/\/t.co\/CHANfty9 #herhealth #ACA",
    "id" : 230639289019535360,
    "created_at" : "2012-08-01 12:21:06 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 230695694611148801,
  "created_at" : "2012-08-01 16:05:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/GiLSU1Ew",
      "expanded_url" : "http:\/\/on.wh.gov\/zPeU",
      "display_url" : "on.wh.gov\/zPeU"
    } ]
  },
  "geo" : { },
  "id_str" : "230651659578122240",
  "text" : ".@VP Biden: An Issue Beyond Debate: Congress Should Act Now to Protect Women: http:\/\/t.co\/GiLSU1Ew #VAWA",
  "id" : 230651659578122240,
  "created_at" : "2012-08-01 13:10:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]