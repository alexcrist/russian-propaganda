Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President's Council",
      "screen_name" : "FitnessGov",
      "indices" : [ 3, 14 ],
      "id_str" : "374019904",
      "id" : 374019904
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 26, 33 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Nick Offerman",
      "screen_name" : "Nick_Offerman",
      "indices" : [ 40, 54 ],
      "id_str" : "502135911",
      "id" : 502135911
    }, {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "indices" : [ 62, 73 ],
      "id_str" : "15693493",
      "id" : 15693493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "0to60",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ybMBlvqsz2",
      "expanded_url" : "http:\/\/bit.ly\/2ca1R0Z",
      "display_url" : "bit.ly\/2ca1R0Z"
    } ]
  },
  "geo" : { },
  "id_str" : "771127043392147456",
  "text" : "RT @FitnessGov: Check out @FLOTUS &amp; @Nick_Offerman in new @funnyordie \u201CHistory of Exercise\u201D video: https:\/\/t.co\/ybMBlvqsz2 #0to60 https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 10, 17 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Nick Offerman",
        "screen_name" : "Nick_Offerman",
        "indices" : [ 24, 38 ],
        "id_str" : "502135911",
        "id" : 502135911
      }, {
        "name" : "Funny Or Die",
        "screen_name" : "funnyordie",
        "indices" : [ 46, 57 ],
        "id_str" : "15693493",
        "id" : 15693493
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FitnessGov\/status\/770992744034623488\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/qN8Qwa05CZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrMdwZgWYAAwJn9.jpg",
        "id_str" : "770992678527983616",
        "id" : 770992678527983616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrMdwZgWYAAwJn9.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/qN8Qwa05CZ"
      } ],
      "hashtags" : [ {
        "text" : "0to60",
        "indices" : [ 111, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/ybMBlvqsz2",
        "expanded_url" : "http:\/\/bit.ly\/2ca1R0Z",
        "display_url" : "bit.ly\/2ca1R0Z"
      } ]
    },
    "geo" : { },
    "id_str" : "770992744034623488",
    "text" : "Check out @FLOTUS &amp; @Nick_Offerman in new @funnyordie \u201CHistory of Exercise\u201D video: https:\/\/t.co\/ybMBlvqsz2 #0to60 https:\/\/t.co\/qN8Qwa05CZ",
    "id" : 770992744034623488,
    "created_at" : "2016-08-31 14:32:49 +0000",
    "user" : {
      "name" : "President's Council",
      "screen_name" : "FitnessGov",
      "protected" : false,
      "id_str" : "374019904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1544099616\/President_s_Council_Fitness_Sports_Nutrition_3Color_Logo_V2_normal.png",
      "id" : 374019904,
      "verified" : true
    }
  },
  "id" : 771127043392147456,
  "created_at" : "2016-08-31 23:26:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PQ8NoDGaUZ",
      "expanded_url" : "http:\/\/snpy.tv\/2bTf0xa",
      "display_url" : "snpy.tv\/2bTf0xa"
    } ]
  },
  "geo" : { },
  "id_str" : "771124679444660224",
  "text" : "RT if you agree with @POTUS: It's time to #ActOnClimate so future generations can enjoy America\u2019s greatest treasures https:\/\/t.co\/PQ8NoDGaUZ",
  "id" : 771124679444660224,
  "created_at" : "2016-08-31 23:17:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/NlJAGgFH0F",
      "expanded_url" : "http:\/\/snpy.tv\/2bWdrxN",
      "display_url" : "snpy.tv\/2bWdrxN"
    } ]
  },
  "geo" : { },
  "id_str" : "771114122750550016",
  "text" : "\u201CWe\u2019ve proven that the choice between our environment, our economy, and our health is a false one.\u201D \u2014@POTUS https:\/\/t.co\/NlJAGgFH0F",
  "id" : 771114122750550016,
  "created_at" : "2016-08-31 22:35:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/9ZO3VibeP7",
      "expanded_url" : "http:\/\/snpy.tv\/2bWdrxN",
      "display_url" : "snpy.tv\/2bWdrxN"
    } ]
  },
  "geo" : { },
  "id_str" : "771109534622416897",
  "text" : "RT @FactsOnClimate: \"What happens to the land, also happens to the people.\" -\u2014@POTUS on why we need to #ActOnClimate https:\/\/t.co\/9ZO3VibeP7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 58, 64 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 83, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/9ZO3VibeP7",
        "expanded_url" : "http:\/\/snpy.tv\/2bWdrxN",
        "display_url" : "snpy.tv\/2bWdrxN"
      } ]
    },
    "geo" : { },
    "id_str" : "771109426069512193",
    "text" : "\"What happens to the land, also happens to the people.\" -\u2014@POTUS on why we need to #ActOnClimate https:\/\/t.co\/9ZO3VibeP7",
    "id" : 771109426069512193,
    "created_at" : "2016-08-31 22:16:28 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 771109534622416897,
  "created_at" : "2016-08-31 22:16:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/F0E84MBT92",
      "expanded_url" : "http:\/\/snpy.tv\/2cfx8Cu",
      "display_url" : "snpy.tv\/2cfx8Cu"
    } ]
  },
  "geo" : { },
  "id_str" : "771106109062950912",
  "text" : "\"The overwhelming body of scientific evidence shows us that climate change is caused by human activity.\u201D \u2014@POTUS https:\/\/t.co\/F0E84MBT92",
  "id" : 771106109062950912,
  "created_at" : "2016-08-31 22:03:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771103140376616960",
  "text" : "\u201CThe most important office in a democracy is the office of citizen. Change happens because of you\u201D. \u2014@POTUS on how we can #ActOnClimate",
  "id" : 771103140376616960,
  "created_at" : "2016-08-31 21:51:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771102340401262593",
  "text" : "\"It won\u2019t happen if we just pay lip service to conservation but then refuse to do what\u2019s needed.\" \u2014@POTUS on why it's time to #ActOnClimate",
  "id" : 771102340401262593,
  "created_at" : "2016-08-31 21:48:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/771101399774035972\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/HT6OFCVyBX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrOAdzqWgAANCme.jpg",
      "id_str" : "771101210782892032",
      "id" : 771101210782892032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrOAdzqWgAANCme.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/HT6OFCVyBX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771101399774035972",
  "text" : "\"During the first half of this year, carbon pollution hit its lowest level in a quarter century.\" \u2014@POTUS https:\/\/t.co\/HT6OFCVyBX",
  "id" : 771101399774035972,
  "created_at" : "2016-08-31 21:44:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/771100924509089792\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/b8BxZvFFlW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrOABtHWAAEuJIB.jpg",
      "id_str" : "771100727989108737",
      "id" : 771100727989108737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrOABtHWAAEuJIB.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/b8BxZvFFlW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771100924509089792",
  "text" : "\"We\u2019ve worked to generate more clean energy, use less dirty energy, and waste less energy overall.\" \u2014@POTUS https:\/\/t.co\/b8BxZvFFlW",
  "id" : 771100924509089792,
  "created_at" : "2016-08-31 21:42:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/771100466155515905\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/br9TZ6Q1E7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrN_vGXXYAACqe4.jpg",
      "id_str" : "771100408349679616",
      "id" : 771100408349679616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrN_vGXXYAACqe4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/br9TZ6Q1E7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/dKYTycKNTb",
      "expanded_url" : "http:\/\/go.wh.gov\/KZMGc2",
      "display_url" : "go.wh.gov\/KZMGc2"
    } ]
  },
  "geo" : { },
  "id_str" : "771100466155515905",
  "text" : "\"Last week alone, we protected land, water, and wildlife from Maine to Hawaii\" \u2014@POTUS: https:\/\/t.co\/dKYTycKNTb https:\/\/t.co\/br9TZ6Q1E7",
  "id" : 771100466155515905,
  "created_at" : "2016-08-31 21:40:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/771100288677769216\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Y3rWDbo71r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrN_lz1WYAArwgF.jpg",
      "id_str" : "771100248756346880",
      "id" : 771100248756346880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrN_lz1WYAArwgF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Y3rWDbo71r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771100288677769216",
  "text" : "\u201CWe\u2019ve protected more acres of public lands and water than any administration in history.\" \u2014@POTUS https:\/\/t.co\/Y3rWDbo71r",
  "id" : 771100288677769216,
  "created_at" : "2016-08-31 21:40:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771100179214770176",
  "text" : "\u201C2014 was the warmest year on record until\u20262015\u2014and 2016 is on pace to be even hotter.\" \u2014@POTUS",
  "id" : 771100179214770176,
  "created_at" : "2016-08-31 21:39:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 108, 121 ]
    }, {
      "text" : "TahoeSummit",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771099687516508165",
  "text" : "\u201CWe\u2019ve proven that the choice between our environment, our economy, and our health is a false one.\u201D \u2014@POTUS #ActOnClimate #TahoeSummit",
  "id" : 771099687516508165,
  "created_at" : "2016-08-31 21:37:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771099478816268288",
  "text" : "\"We do it to free more of our communities and plant and animal species from wildfires, droughts, and displacement.\u201D \u2014@POTUS on conservation",
  "id" : 771099478816268288,
  "created_at" : "2016-08-31 21:36:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771099305033736192",
  "text" : "\u201CThe overwhelming body of scientific evidence shows us that climate change is caused by human activity.\u201D \u2014@POTUS #ActOnClimate",
  "id" : 771099305033736192,
  "created_at" : "2016-08-31 21:36:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TahoeSummit",
      "indices" : [ 111, 123 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/dKYTycKNTb",
      "expanded_url" : "http:\/\/go.wh.gov\/KZMGc2",
      "display_url" : "go.wh.gov\/KZMGc2"
    } ]
  },
  "geo" : { },
  "id_str" : "771099034404655104",
  "text" : "\u201CThe challenges of conservation and combating climate change are connected.\" \u2014@POTUS: https:\/\/t.co\/dKYTycKNTb  #TahoeSummit #ActOnClimate",
  "id" : 771099034404655104,
  "created_at" : "2016-08-31 21:35:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/dKYTycKNTb",
      "expanded_url" : "http:\/\/go.wh.gov\/KZMGc2",
      "display_url" : "go.wh.gov\/KZMGc2"
    } ]
  },
  "geo" : { },
  "id_str" : "771087902835142656",
  "text" : "Tune in at 5:00pm ET: @POTUS speaks on combating climate change and protecting our natural treasures: https:\/\/t.co\/dKYTycKNTb #ActOnClimate",
  "id" : 771087902835142656,
  "created_at" : "2016-08-31 20:50:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opioid",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771079967706869760",
  "text" : "RT @SecBurwell: We\u2019ve asked Congress for $1.1B to fight the #opioid epidemic. Need these funds to help more people access treatment. #Overd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opioid",
        "indices" : [ 44, 51 ]
      }, {
        "text" : "OverdoseAware2016",
        "indices" : [ 117, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771021681116737536",
    "text" : "We\u2019ve asked Congress for $1.1B to fight the #opioid epidemic. Need these funds to help more people access treatment. #OverdoseAware2016",
    "id" : 771021681116737536,
    "created_at" : "2016-08-31 16:27:48 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 771079967706869760,
  "created_at" : "2016-08-31 20:19:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/771050167688507392\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/b8Ch9j5xdP",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CrNRBr_WYAAaTUk.jpg",
      "id_str" : "771049050640637952",
      "id" : 771049050640637952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CrNRBr_WYAAaTUk.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/b8Ch9j5xdP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/NxFFBwX8d5",
      "expanded_url" : "http:\/\/go.wh.gov\/t4ZDNV",
      "display_url" : "go.wh.gov\/t4ZDNV"
    } ]
  },
  "geo" : { },
  "id_str" : "771050167688507392",
  "text" : "The first scheduled flight from the U.S. to Cuba in over 50 years took off today. Read more: https:\/\/t.co\/NxFFBwX8d5 https:\/\/t.co\/b8Ch9j5xdP",
  "id" : 771050167688507392,
  "created_at" : "2016-08-31 18:21:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771036682649034752",
  "text" : "RT @PressSec: Today, a U.S. scheduled flight landed in Cuba for 1st time in over 50 years. Reminds me of another historic moment: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/711669087349432321\/video\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/IM4lvhzlos",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/711668944961024000\/pu\/img\/1r_iSygQfzl1uyPU.jpg",
        "id_str" : "711668944961024000",
        "id" : 711668944961024000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/711668944961024000\/pu\/img\/1r_iSygQfzl1uyPU.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IM4lvhzlos"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "771031252891734016",
    "text" : "Today, a U.S. scheduled flight landed in Cuba for 1st time in over 50 years. Reminds me of another historic moment: https:\/\/t.co\/IM4lvhzlos",
    "id" : 771031252891734016,
    "created_at" : "2016-08-31 17:05:50 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 771036682649034752,
  "created_at" : "2016-08-31 17:27:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "Steve Williams",
      "screen_name" : "HuntingtonMayor",
      "indices" : [ 39, 55 ],
      "id_str" : "701450964",
      "id" : 701450964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OverdoseAwarenessDay",
      "indices" : [ 16, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/mp8GXUY09Q",
      "expanded_url" : "http:\/\/www.wvgazettemail.com\/news-health\/20160831\/huntington-mayor-calls-on-congress-to-combat-opioid-epidemic-",
      "display_url" : "wvgazettemail.com\/news-health\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "771035505278451712",
  "text" : "RT @Denis44: On #OverdoseAwarenessDay, @HuntingtonMayor calls on Congress to fund treatment for opioid addiction. https:\/\/t.co\/mp8GXUY09Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Williams",
        "screen_name" : "HuntingtonMayor",
        "indices" : [ 26, 42 ],
        "id_str" : "701450964",
        "id" : 701450964
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OverdoseAwarenessDay",
        "indices" : [ 3, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/mp8GXUY09Q",
        "expanded_url" : "http:\/\/www.wvgazettemail.com\/news-health\/20160831\/huntington-mayor-calls-on-congress-to-combat-opioid-epidemic-",
        "display_url" : "wvgazettemail.com\/news-health\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771032482380591104",
    "text" : "On #OverdoseAwarenessDay, @HuntingtonMayor calls on Congress to fund treatment for opioid addiction. https:\/\/t.co\/mp8GXUY09Q",
    "id" : 771032482380591104,
    "created_at" : "2016-08-31 17:10:43 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 771035505278451712,
  "created_at" : "2016-08-31 17:22:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "TransportationGov",
      "screen_name" : "USDOT",
      "indices" : [ 121, 127 ],
      "id_str" : "393562221",
      "id" : 393562221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771024745080971266",
  "text" : "RT @rhodes44: Today the 1st commercial flight in \u2191 50 years flew from Ft Lauderdale, FL to Santa Clara, Cuba. Good work, @USDOT! \nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TransportationGov",
        "screen_name" : "USDOT",
        "indices" : [ 107, 113 ],
        "id_str" : "393562221",
        "id" : 393562221
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/Sx72BCkOln",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wl4ChnqMA1c",
        "display_url" : "youtube.com\/watch?v=wl4Chn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771023853526978560",
    "text" : "Today the 1st commercial flight in \u2191 50 years flew from Ft Lauderdale, FL to Santa Clara, Cuba. Good work, @USDOT! \nhttps:\/\/t.co\/Sx72BCkOln",
    "id" : 771023853526978560,
    "created_at" : "2016-08-31 16:36:26 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 771024745080971266,
  "created_at" : "2016-08-31 16:39:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/nqzIJWmDD0",
      "expanded_url" : "http:\/\/snpy.tv\/1XHtRJz",
      "display_url" : "snpy.tv\/1XHtRJz"
    } ]
  },
  "geo" : { },
  "id_str" : "771021210033369088",
  "text" : "Take a look back at another historic flight when Air Force One touched down in Cuba for the first time ever: https:\/\/t.co\/nqzIJWmDD0",
  "id" : 771021210033369088,
  "created_at" : "2016-08-31 16:25:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Nick Offerman",
      "screen_name" : "Nick_Offerman",
      "indices" : [ 24, 38 ],
      "id_str" : "502135911",
      "id" : 502135911
    }, {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "indices" : [ 45, 56 ],
      "id_str" : "15693493",
      "id" : 15693493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "0to60",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771020878217940992",
  "text" : "RT @FLOTUS: So much fun @Nick_Offerman &amp; @FunnyOrDie! \n\nAnd no. We need you to bring it ALL back...EXCEPT the spandex.\uD83C\uDFCB #0to60  https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nick Offerman",
        "screen_name" : "Nick_Offerman",
        "indices" : [ 12, 26 ],
        "id_str" : "502135911",
        "id" : 502135911
      }, {
        "name" : "Funny Or Die",
        "screen_name" : "funnyordie",
        "indices" : [ 33, 44 ],
        "id_str" : "15693493",
        "id" : 15693493
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "0to60",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/arZVzLjC6g",
        "expanded_url" : "https:\/\/twitter.com\/nick_offerman\/status\/771002177481498624",
        "display_url" : "twitter.com\/nick_offerman\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "771016092416413696",
    "text" : "So much fun @Nick_Offerman &amp; @FunnyOrDie! \n\nAnd no. We need you to bring it ALL back...EXCEPT the spandex.\uD83C\uDFCB #0to60  https:\/\/t.co\/arZVzLjC6g",
    "id" : 771016092416413696,
    "created_at" : "2016-08-31 16:05:35 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 771020878217940992,
  "created_at" : "2016-08-31 16:24:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/771017202082295808\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/6NG11xQy8J",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CrMz5qbUAAAJ9jM.jpg",
      "id_str" : "771017026944892928",
      "id" : 771017026944892928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CrMz5qbUAAAJ9jM.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6NG11xQy8J"
    } ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771017202082295808",
  "text" : "A year after changing course in Cuba, the first scheduled flight from the US in over 50 years landed in #Cuba today. https:\/\/t.co\/6NG11xQy8J",
  "id" : 771017202082295808,
  "created_at" : "2016-08-31 16:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 3, 15 ],
      "id_str" : "67378554",
      "id" : 67378554
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 99, 104 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/iXybZNpB2J",
      "expanded_url" : "https:\/\/www.fema.gov\/mobile-app",
      "display_url" : "fema.gov\/mobile-app"
    } ]
  },
  "geo" : { },
  "id_str" : "771009116613509120",
  "text" : "RT @CraigatFEMA: Hurricanes, Wildfires, Floods, Heat Waves. What are you waiting for? download the @FEMA app https:\/\/t.co\/iXybZNpB2J https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 82, 87 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CraigatFEMA\/status\/771004538870435840\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/M5daK7Gon7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrMoiMrUMAARAF_.jpg",
        "id_str" : "771004529194053632",
        "id" : 771004529194053632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrMoiMrUMAARAF_.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/M5daK7Gon7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/iXybZNpB2J",
        "expanded_url" : "https:\/\/www.fema.gov\/mobile-app",
        "display_url" : "fema.gov\/mobile-app"
      } ]
    },
    "geo" : { },
    "id_str" : "771004538870435840",
    "text" : "Hurricanes, Wildfires, Floods, Heat Waves. What are you waiting for? download the @FEMA app https:\/\/t.co\/iXybZNpB2J https:\/\/t.co\/M5daK7Gon7",
    "id" : 771004538870435840,
    "created_at" : "2016-08-31 15:19:41 +0000",
    "user" : {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "protected" : false,
      "id_str" : "67378554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522052690138763264\/isW58OSG_normal.jpeg",
      "id" : 67378554,
      "verified" : true
    }
  },
  "id" : 771009116613509120,
  "created_at" : "2016-08-31 15:37:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Readygov",
      "screen_name" : "Readygov",
      "indices" : [ 3, 12 ],
      "id_str" : "16028241",
      "id" : 16028241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/AMLHg8smmv",
      "expanded_url" : "http:\/\/www.ready.gov\/make-a-plan",
      "display_url" : "ready.gov\/make-a-plan"
    } ]
  },
  "geo" : { },
  "id_str" : "771007544324136960",
  "text" : "RT @Readygov: If wind, rain, or hurricanes are in your forecast -- make an emergency plan now: https:\/\/t.co\/AMLHg8smmv https:\/\/t.co\/2LOD9oh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Readygov\/status\/770768465737154560\/video\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/2LOD9ohK5I",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/770768347663335424\/pu\/img\/YhDZOKnr_7o4vFB_.jpg",
        "id_str" : "770768347663335424",
        "id" : 770768347663335424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/770768347663335424\/pu\/img\/YhDZOKnr_7o4vFB_.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2LOD9ohK5I"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/AMLHg8smmv",
        "expanded_url" : "http:\/\/www.ready.gov\/make-a-plan",
        "display_url" : "ready.gov\/make-a-plan"
      } ]
    },
    "geo" : { },
    "id_str" : "770768465737154560",
    "text" : "If wind, rain, or hurricanes are in your forecast -- make an emergency plan now: https:\/\/t.co\/AMLHg8smmv https:\/\/t.co\/2LOD9ohK5I",
    "id" : 770768465737154560,
    "created_at" : "2016-08-30 23:41:37 +0000",
    "user" : {
      "name" : "Readygov",
      "screen_name" : "Readygov",
      "protected" : false,
      "id_str" : "16028241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646417752811532288\/D4M4w2f0_normal.jpg",
      "id" : 16028241,
      "verified" : true
    }
  },
  "id" : 771007544324136960,
  "created_at" : "2016-08-31 15:31:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771001644498710528",
  "text" : "RT @JohnKerry: 8\/31\/2016:The 1st US commercial flight to #Cuba since 1961, just over a year after raising the flag at US Embassy Havana. An\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 42, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770895899580964864",
    "text" : "8\/31\/2016:The 1st US commercial flight to #Cuba since 1961, just over a year after raising the flag at US Embassy Havana. Another step fwd.",
    "id" : 770895899580964864,
    "created_at" : "2016-08-31 08:07:59 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 771001644498710528,
  "created_at" : "2016-08-31 15:08:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 111, 119 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770984450561863680",
  "text" : "RT @PressSec: What journalists should note about the most transparent White House in history: My letter to the @nytimes editor \u2192 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 97, 105 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/DWUfpJBHaM",
        "expanded_url" : "http:\/\/nyti.ms\/2bBwwHB",
        "display_url" : "nyti.ms\/2bBwwHB"
      } ]
    },
    "geo" : { },
    "id_str" : "770983463440777216",
    "text" : "What journalists should note about the most transparent White House in history: My letter to the @nytimes editor \u2192 https:\/\/t.co\/DWUfpJBHaM",
    "id" : 770983463440777216,
    "created_at" : "2016-08-31 13:55:56 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 770984450561863680,
  "created_at" : "2016-08-31 13:59:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/770754761670979585\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/yJoR2i2A6v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrJFAvaWAAQXFBw.jpg",
      "id_str" : "770754365263052804",
      "id" : 770754365263052804,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrJFAvaWAAQXFBw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/yJoR2i2A6v"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/eNv6u25429",
      "expanded_url" : "http:\/\/go.wh.gov\/clemency",
      "display_url" : "go.wh.gov\/clemency"
    } ]
  },
  "geo" : { },
  "id_str" : "770754761670979585",
  "text" : "America is a nation of second chances. Today, @POTUS granted clemency to 111 men and women: https:\/\/t.co\/eNv6u25429 https:\/\/t.co\/yJoR2i2A6v",
  "id" : 770754761670979585,
  "created_at" : "2016-08-30 22:47:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "indices" : [ 16, 32 ],
      "id_str" : "43910797",
      "id" : 43910797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 102, 107 ]
    }, {
      "text" : "AtoZika",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770747386691981312",
  "text" : "RT @Schultz44: .@SenSherrodBrown local officials are on the front lines. They need resources to fight #Zika. #AtoZika https:\/\/t.co\/NnApnzmo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter QandA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sherrod Brown",
        "screen_name" : "SenSherrodBrown",
        "indices" : [ 1, 17 ],
        "id_str" : "43910797",
        "id" : 43910797
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/770740223118565377\/video\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/NnApnzmoWE",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/770740135856107521\/pu\/img\/stbxPrP45kzAOSB5.jpg",
        "id_str" : "770740135856107521",
        "id" : 770740135856107521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/770740135856107521\/pu\/img\/stbxPrP45kzAOSB5.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NnApnzmoWE"
      } ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 87, 92 ]
      }, {
        "text" : "AtoZika",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "770712672044257280",
    "geo" : { },
    "id_str" : "770740223118565377",
    "in_reply_to_user_id" : 43910797,
    "text" : ".@SenSherrodBrown local officials are on the front lines. They need resources to fight #Zika. #AtoZika https:\/\/t.co\/NnApnzmoWE",
    "id" : 770740223118565377,
    "in_reply_to_status_id" : 770712672044257280,
    "created_at" : "2016-08-30 21:49:23 +0000",
    "in_reply_to_screen_name" : "SenSherrodBrown",
    "in_reply_to_user_id_str" : "43910797",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 770747386691981312,
  "created_at" : "2016-08-30 22:17:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR",
      "screen_name" : "NPR",
      "indices" : [ 3, 7 ],
      "id_str" : "5392522",
      "id" : 5392522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Sam8jqjWVD",
      "expanded_url" : "http:\/\/n.pr\/2c68fpo",
      "display_url" : "n.pr\/2c68fpo"
    } ]
  },
  "geo" : { },
  "id_str" : "770745482758979584",
  "text" : "RT @NPR: This White House has now granted 673 commutations, more than the past 10 presidents combined. https:\/\/t.co\/Sam8jqjWVD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/Sam8jqjWVD",
        "expanded_url" : "http:\/\/n.pr\/2c68fpo",
        "display_url" : "n.pr\/2c68fpo"
      } ]
    },
    "in_reply_to_status_id_str" : "770700955327291393",
    "geo" : { },
    "id_str" : "770702254202621957",
    "in_reply_to_user_id" : 5392522,
    "text" : "This White House has now granted 673 commutations, more than the past 10 presidents combined. https:\/\/t.co\/Sam8jqjWVD",
    "id" : 770702254202621957,
    "in_reply_to_status_id" : 770700955327291393,
    "created_at" : "2016-08-30 19:18:31 +0000",
    "in_reply_to_screen_name" : "NPR",
    "in_reply_to_user_id_str" : "5392522",
    "user" : {
      "name" : "NPR",
      "screen_name" : "NPR",
      "protected" : false,
      "id_str" : "5392522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722199003845304320\/s2zwEoao_normal.jpg",
      "id" : 5392522,
      "verified" : true
    }
  },
  "id" : 770745482758979584,
  "created_at" : "2016-08-30 22:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/sTHkwyYhua",
      "expanded_url" : "http:\/\/go.wh.gov\/n5KQMY",
      "display_url" : "go.wh.gov\/n5KQMY"
    } ]
  },
  "geo" : { },
  "id_str" : "770741628550209538",
  "text" : ".@POTUS commuted the sentences of 111 largely nonviolent drug offenders\u201435 of which were serving life sentences: https:\/\/t.co\/sTHkwyYhua",
  "id" : 770741628550209538,
  "created_at" : "2016-08-30 21:54:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joi Ito",
      "screen_name" : "Joi",
      "indices" : [ 3, 7 ],
      "id_str" : "691353",
      "id" : 691353
    }, {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 46, 52 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WIREDxPOTUS",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/yvSHEP5BLa",
      "expanded_url" : "http:\/\/www.wired.com\/2016\/08\/president-barack-obama-will-guest-edit-wireds-november-issue\/?mbid=social_twitter",
      "display_url" : "wired.com\/2016\/08\/presid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "770738428132687873",
  "text" : "RT @Joi: Thrilled to be part of this issue of @WIRED (photo by Samantha Appleton) https:\/\/t.co\/yvSHEP5BLa #WIREDxPOTUS https:\/\/t.co\/OR2oiwz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WIRED",
        "screen_name" : "WIRED",
        "indices" : [ 37, 43 ],
        "id_str" : "1344951",
        "id" : 1344951
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Joi\/status\/770737669689278464\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/OR2oiwzX8e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrI1WJrWYAAUM4s.jpg",
        "id_str" : "770737140904910848",
        "id" : 770737140904910848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrI1WJrWYAAUM4s.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2730,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/OR2oiwzX8e"
      } ],
      "hashtags" : [ {
        "text" : "WIREDxPOTUS",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/yvSHEP5BLa",
        "expanded_url" : "http:\/\/www.wired.com\/2016\/08\/president-barack-obama-will-guest-edit-wireds-november-issue\/?mbid=social_twitter",
        "display_url" : "wired.com\/2016\/08\/presid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770737669689278464",
    "text" : "Thrilled to be part of this issue of @WIRED (photo by Samantha Appleton) https:\/\/t.co\/yvSHEP5BLa #WIREDxPOTUS https:\/\/t.co\/OR2oiwzX8e",
    "id" : 770737669689278464,
    "created_at" : "2016-08-30 21:39:14 +0000",
    "user" : {
      "name" : "Joi Ito",
      "screen_name" : "Joi",
      "protected" : false,
      "id_str" : "691353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083551051\/headshotColor180_normal.jpg",
      "id" : 691353,
      "verified" : true
    }
  },
  "id" : 770738428132687873,
  "created_at" : "2016-08-30 21:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/770715902639763456\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/J4cL84Yjyc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrIh_q_W8AQJ3IB.jpg",
      "id_str" : "770715863989284868",
      "id" : 770715863989284868,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrIh_q_W8AQJ3IB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/J4cL84Yjyc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/eNv6u25429",
      "expanded_url" : "http:\/\/go.wh.gov\/clemency",
      "display_url" : "go.wh.gov\/clemency"
    } ]
  },
  "geo" : { },
  "id_str" : "770715902639763456",
  "text" : ".@POTUS cannot do it alone. Congress must act to enact a fairer federal sentencing system: https:\/\/t.co\/eNv6u25429 https:\/\/t.co\/J4cL84Yjyc",
  "id" : 770715902639763456,
  "created_at" : "2016-08-30 20:12:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/770713169757081600\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bBDAUzLBXt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrIfc0EWEAAgWfZ.jpg",
      "id_str" : "770713066107441152",
      "id" : 770713066107441152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrIfc0EWEAAgWfZ.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/bBDAUzLBXt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "770699150484701184",
  "geo" : { },
  "id_str" : "770713169757081600",
  "in_reply_to_user_id" : 30313925,
  "text" : "[CHART CORRECTION] @POTUS just commuted 111 people, bringing the total to more than the past 10 presidents combined. https:\/\/t.co\/bBDAUzLBXt",
  "id" : 770713169757081600,
  "in_reply_to_status_id" : 770699150484701184,
  "created_at" : "2016-08-30 20:01:53 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/770699150484701184\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/cwRfjozpAH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrISkYkXEAArAQj.jpg",
      "id_str" : "770698902513324032",
      "id" : 770698902513324032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrISkYkXEAArAQj.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/cwRfjozpAH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770699150484701184",
  "text" : "BREAKING: @POTUS just commuted 111 people, bringing the total to more than the past 10 presidents combined. https:\/\/t.co\/cwRfjozpAH",
  "id" : 770699150484701184,
  "created_at" : "2016-08-30 19:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carnegie Mellon",
      "screen_name" : "CarnegieMellon",
      "indices" : [ 3, 18 ],
      "id_str" : "17631078",
      "id" : 17631078
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770644130930290688",
  "text" : "RT @CarnegieMellon: .@POTUS is coming to CMU to speak at a conference on pushing the boundaries of science and technology. https:\/\/t.co\/Dni\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/Dni9UcBK6k",
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/770628047301062656",
        "display_url" : "twitter.com\/whitehouseostp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770628486079930368",
    "text" : ".@POTUS is coming to CMU to speak at a conference on pushing the boundaries of science and technology. https:\/\/t.co\/Dni9UcBK6k",
    "id" : 770628486079930368,
    "created_at" : "2016-08-30 14:25:23 +0000",
    "user" : {
      "name" : "Carnegie Mellon",
      "screen_name" : "CarnegieMellon",
      "protected" : false,
      "id_str" : "17631078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583587004316647424\/2pjjWvhP_normal.png",
      "id" : 17631078,
      "verified" : true
    }
  },
  "id" : 770644130930290688,
  "created_at" : "2016-08-30 15:27:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFrontiers",
      "indices" : [ 70, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ddWRBURl2I",
      "expanded_url" : "http:\/\/wh.gov\/frontiers",
      "display_url" : "wh.gov\/frontiers"
    } ]
  },
  "geo" : { },
  "id_str" : "770637064824061952",
  "text" : "We're bringing together some of the world\u2019s leading innovators at the #WHFrontiers Conference. How you can join \u2192 https:\/\/t.co\/ddWRBURl2I",
  "id" : 770637064824061952,
  "created_at" : "2016-08-30 14:59:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WIREDxPOTUS",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/bzw9WNgK54",
      "expanded_url" : "http:\/\/bit.ly\/2bOtVpI",
      "display_url" : "bit.ly\/2bOtVpI"
    } ]
  },
  "geo" : { },
  "id_str" : "770627059492261888",
  "text" : "RT @WIRED: Barack Obama (@POTUS) will serve as guest editor of WIRED\u2019s November issue. https:\/\/t.co\/bzw9WNgK54 #WIREDxPOTUS https:\/\/t.co\/Oe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 14, 20 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WIRED\/status\/770622703321640961\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/OeGL84Uz8k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrHNQyEXYAEEbN-.jpg",
        "id_str" : "770622699458748417",
        "id" : 770622699458748417,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrHNQyEXYAEEbN-.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/OeGL84Uz8k"
      } ],
      "hashtags" : [ {
        "text" : "WIREDxPOTUS",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/bzw9WNgK54",
        "expanded_url" : "http:\/\/bit.ly\/2bOtVpI",
        "display_url" : "bit.ly\/2bOtVpI"
      } ]
    },
    "geo" : { },
    "id_str" : "770622703321640961",
    "text" : "Barack Obama (@POTUS) will serve as guest editor of WIRED\u2019s November issue. https:\/\/t.co\/bzw9WNgK54 #WIREDxPOTUS https:\/\/t.co\/OeGL84Uz8k",
    "id" : 770622703321640961,
    "created_at" : "2016-08-30 14:02:24 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 770627059492261888,
  "created_at" : "2016-08-30 14:19:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770621177840734208",
  "text" : "RT @PressSec: FACT: Under #ACA, everyone's insurance got upgraded &amp; most can find a plan on the marketplace for $75\/month or less. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 12, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/Jwgk1Ps2pQ",
        "expanded_url" : "http:\/\/snpy.tv\/2copBTe",
        "display_url" : "snpy.tv\/2copBTe"
      } ]
    },
    "geo" : { },
    "id_str" : "770619953288388609",
    "text" : "FACT: Under #ACA, everyone's insurance got upgraded &amp; most can find a plan on the marketplace for $75\/month or less. https:\/\/t.co\/Jwgk1Ps2pQ",
    "id" : 770619953288388609,
    "created_at" : "2016-08-30 13:51:28 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 770621177840734208,
  "created_at" : "2016-08-30 13:56:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/770397397537198081\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/YvvrJu0Gzu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrEABijWAAAbZLC.jpg",
      "id_str" : "770397037711982592",
      "id" : 770397037711982592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrEABijWAAAbZLC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/YvvrJu0Gzu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/1HwsI2MVd5",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "770397397537198081",
  "text" : "Today, the 10,000th Syrian refugee will arrive in the US. Find out how you can help at https:\/\/t.co\/1HwsI2MVd5: https:\/\/t.co\/YvvrJu0Gzu",
  "id" : 770397397537198081,
  "created_at" : "2016-08-29 23:07:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 3, 10 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 114, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770395543600242689",
  "text" : "RT @DHSgov: This is the United States of America. Taking in refugees at times of crisis is the right thing to do. #RefugeesWelcome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RefugeesWelcome",
        "indices" : [ 102, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770372301187493888",
    "text" : "This is the United States of America. Taking in refugees at times of crisis is the right thing to do. #RefugeesWelcome",
    "id" : 770372301187493888,
    "created_at" : "2016-08-29 21:27:24 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 770395543600242689,
  "created_at" : "2016-08-29 22:59:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marine Corps Reserve",
      "screen_name" : "MarForRes",
      "indices" : [ 13, 23 ],
      "id_str" : "80568825",
      "id" : 80568825
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/770391315582418944\/photo\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/RuTNUTnVxd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrD6llHXYAIYwal.jpg",
      "id_str" : "770391059805462530",
      "id" : 770391059805462530,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrD6llHXYAIYwal.jpg",
      "sizes" : [ {
        "h" : 1337,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 783,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1337,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/RuTNUTnVxd"
    } ],
    "hashtags" : [ {
      "text" : "SemperFi",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770391315582418944",
  "text" : "Happy 100th, @MarForRes! #SemperFi https:\/\/t.co\/RuTNUTnVxd",
  "id" : 770391315582418944,
  "created_at" : "2016-08-29 22:42:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770351052013068288",
  "text" : "RT @Denis44: In Sept, POTUS pledged to admit 10,000 Syrian refugees. This afternoon, 10,000th Syrian refugee will reach USA. https:\/\/t.co\/T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/TxkhSrp4kQ",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/29\/statement-national-security-advisor-susan-e-rice-syrian-refugee",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770345314939117568",
    "text" : "In Sept, POTUS pledged to admit 10,000 Syrian refugees. This afternoon, 10,000th Syrian refugee will reach USA. https:\/\/t.co\/TxkhSrp4kQ",
    "id" : 770345314939117568,
    "created_at" : "2016-08-29 19:40:10 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 770351052013068288,
  "created_at" : "2016-08-29 20:02:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "AtoZika",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770348820714561536",
  "text" : "RT @gov: Now's your chance to ask your #Zika questions &amp; hear from top US health experts. Tweet your questions with #AtoZika. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gov\/status\/770317620021170176\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/DCLEhy64EW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CrC3P9dW8AAqR1n.jpg",
        "id_str" : "770317021103976448",
        "id" : 770317021103976448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrC3P9dW8AAqR1n.jpg",
        "sizes" : [ {
          "h" : 518,
          "resize" : "fit",
          "w" : 921
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 921
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 921
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/DCLEhy64EW"
      } ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 30, 35 ]
      }, {
        "text" : "AtoZika",
        "indices" : [ 111, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770317620021170176",
    "text" : "Now's your chance to ask your #Zika questions &amp; hear from top US health experts. Tweet your questions with #AtoZika. https:\/\/t.co\/DCLEhy64EW",
    "id" : 770317620021170176,
    "created_at" : "2016-08-29 17:50:07 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663898965784395776\/rEWW6euI_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 770348820714561536,
  "created_at" : "2016-08-29 19:54:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/770323005968908288\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/355XTv2Hq2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrC8jQNWgAAMPom.jpg",
      "id_str" : "770322850112765952",
      "id" : 770322850112765952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrC8jQNWgAAMPom.jpg",
      "sizes" : [ {
        "h" : 131,
        "resize" : "fit",
        "w" : 878
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 878
      }, {
        "h" : 101,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 131,
        "resize" : "crop",
        "w" : 131
      }, {
        "h" : 131,
        "resize" : "fit",
        "w" : 878
      } ],
      "display_url" : "pic.twitter.com\/355XTv2Hq2"
    } ],
    "hashtags" : [ {
      "text" : "JuanGabriel",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770323005968908288",
  "text" : "\"His spirit will live on...in the hearts of the fans who love him\" \u2014@POTUS on Mexican musician #JuanGabriel: https:\/\/t.co\/355XTv2Hq2",
  "id" : 770323005968908288,
  "created_at" : "2016-08-29 18:11:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JourneyToMars",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ll0bOmLF7A",
      "expanded_url" : "http:\/\/www.nasa.gov\/journeytomars",
      "display_url" : "nasa.gov\/journeytomars"
    } ]
  },
  "geo" : { },
  "id_str" : "770309131244679168",
  "text" : "RT @NASA: Thank you, @POTUS! Every day we make progress toward sending humans on a #JourneyToMars: https:\/\/t.co\/ll0bOmLF7A https:\/\/t.co\/TRS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JourneyToMars",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/ll0bOmLF7A",
        "expanded_url" : "http:\/\/www.nasa.gov\/journeytomars",
        "display_url" : "nasa.gov\/journeytomars"
      }, {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/TRSbaopNTa",
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/770297035274584068",
        "display_url" : "twitter.com\/POTUS\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "770307882231488512",
    "text" : "Thank you, @POTUS! Every day we make progress toward sending humans on a #JourneyToMars: https:\/\/t.co\/ll0bOmLF7A https:\/\/t.co\/TRSbaopNTa",
    "id" : 770307882231488512,
    "created_at" : "2016-08-29 17:11:25 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 770309131244679168,
  "created_at" : "2016-08-29 17:16:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/770302059673427968\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/qjz9zxdVms",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrCpZcrWcAAo124.jpg",
      "id_str" : "770301790940196864",
      "id" : 770301790940196864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrCpZcrWcAAo124.jpg",
      "sizes" : [ {
        "h" : 348,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 1150
      } ],
      "display_url" : "pic.twitter.com\/qjz9zxdVms"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770302059673427968",
  "text" : "11 months ago, @POTUS set a goal of admitting 10K Syrian refugees. Today, the 10,000th refugee arrives in America: https:\/\/t.co\/qjz9zxdVms",
  "id" : 770302059673427968,
  "created_at" : "2016-08-29 16:48:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770297373566210049",
  "text" : "RT @POTUS: Congrats to NASA and the scientists taking us a step closer to Mars. Now enjoy Hawaii and get a shave ice! https:\/\/t.co\/lFZjSnn3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/lFZjSnn38x",
        "expanded_url" : "http:\/\/usat.ly\/2c79F6j",
        "display_url" : "usat.ly\/2c79F6j"
      } ]
    },
    "geo" : { },
    "id_str" : "770297035274584068",
    "text" : "Congrats to NASA and the scientists taking us a step closer to Mars. Now enjoy Hawaii and get a shave ice! https:\/\/t.co\/lFZjSnn38x",
    "id" : 770297035274584068,
    "created_at" : "2016-08-29 16:28:19 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 770297373566210049,
  "created_at" : "2016-08-29 16:29:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 64, 80 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 85, 92 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/HN0iJutED8",
      "expanded_url" : "http:\/\/snpy.tv\/2bDaakZ",
      "display_url" : "snpy.tv\/2bDaakZ"
    } ]
  },
  "geo" : { },
  "id_str" : "770062187469701121",
  "text" : "This month, we celebrate 100 years of \u201CAmerica\u2019s best idea\u201D\u2014the @NatlParkService. \uD83C\uDF82  #NPS100 #FindYourPark https:\/\/t.co\/HN0iJutED8",
  "id" : 770062187469701121,
  "created_at" : "2016-08-29 00:55:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770050547336511488",
  "text" : "RT @POTUS: Congratulations to Maine-Endwell, Little League World Series Champs and still undefeated! Proud of you and the sportsmanship you\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "770050438578184192",
    "text" : "Congratulations to Maine-Endwell, Little League World Series Champs and still undefeated! Proud of you and the sportsmanship you showed.",
    "id" : 770050438578184192,
    "created_at" : "2016-08-29 00:08:26 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 770050547336511488,
  "created_at" : "2016-08-29 00:08:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/3orxZnKw0j",
      "expanded_url" : "http:\/\/go.wh.gov\/AdZwxR",
      "display_url" : "go.wh.gov\/AdZwxR"
    } ]
  },
  "geo" : { },
  "id_str" : "770028217868484608",
  "text" : "\"A fraction of the funding won\u2019t get the job done. You can\u2019t solve a fraction of a disease.\" \u2014@POTUS on #Zika: https:\/\/t.co\/3orxZnKw0j",
  "id" : 770028217868484608,
  "created_at" : "2016-08-28 22:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/769928891980996608\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/KO3YzpjuZG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq9WKYrW8AAF6D1.jpg",
      "id_str" : "769928797726633984",
      "id" : 769928797726633984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq9WKYrW8AAF6D1.jpg",
      "sizes" : [ {
        "h" : 1279,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1279,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/KO3YzpjuZG"
    } ],
    "hashtags" : [ {
      "text" : "GoodTrouble",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "770024143794372608",
  "text" : "RT @repjohnlewis: 53 years ago today, we Marched on Washington for Jobs and Freedom. #GoodTrouble https:\/\/t.co\/KO3YzpjuZG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/769928891980996608\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/KO3YzpjuZG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq9WKYrW8AAF6D1.jpg",
        "id_str" : "769928797726633984",
        "id" : 769928797726633984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq9WKYrW8AAF6D1.jpg",
        "sizes" : [ {
          "h" : 1279,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1279,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/KO3YzpjuZG"
      } ],
      "hashtags" : [ {
        "text" : "GoodTrouble",
        "indices" : [ 67, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769928891980996608",
    "text" : "53 years ago today, we Marched on Washington for Jobs and Freedom. #GoodTrouble https:\/\/t.co\/KO3YzpjuZG",
    "id" : 769928891980996608,
    "created_at" : "2016-08-28 16:05:27 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 770024143794372608,
  "created_at" : "2016-08-28 22:23:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/3orxZnKw0j",
      "expanded_url" : "http:\/\/go.wh.gov\/AdZwxR",
      "display_url" : "go.wh.gov\/AdZwxR"
    } ]
  },
  "geo" : { },
  "id_str" : "769980475364421632",
  "text" : "\"Republicans in Congress should treat Zika like the threat that it is and make this their first order of business\" https:\/\/t.co\/3orxZnKw0j",
  "id" : 769980475364421632,
  "created_at" : "2016-08-28 19:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/p52BXAyC59",
      "expanded_url" : "http:\/\/go.wh.gov\/mMMk5k",
      "display_url" : "go.wh.gov\/mMMk5k"
    } ]
  },
  "geo" : { },
  "id_str" : "769961531882602496",
  "text" : "\"My foremost priority is the health &amp; safety of Americans\" \u2014@POTUS responding to a pregnant woman's letter on #Zika: https:\/\/t.co\/p52BXAyC59",
  "id" : 769961531882602496,
  "created_at" : "2016-08-28 18:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/3orxZnKw0j",
      "expanded_url" : "http:\/\/go.wh.gov\/AdZwxR",
      "display_url" : "go.wh.gov\/AdZwxR"
    } ]
  },
  "geo" : { },
  "id_str" : "769950265793359872",
  "text" : "\"Every day that Republican leaders in Congress wait to do their job...has real life consequences.\" \u2014@POTUS on #Zika: https:\/\/t.co\/3orxZnKw0j",
  "id" : 769950265793359872,
  "created_at" : "2016-08-28 17:30:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769930430917316608\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/gP8bk3aCts",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq9XUFeXYAEuu94.jpg",
      "id_str" : "769930063882182657",
      "id" : 769930063882182657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq9XUFeXYAEuu94.jpg",
      "sizes" : [ {
        "h" : 551,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 972,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 972,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 972,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/gP8bk3aCts"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769930430917316608\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/gP8bk3aCts",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq9XUJUWAAAeqyp.jpg",
      "id_str" : "769930064913891328",
      "id" : 769930064913891328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq9XUJUWAAAeqyp.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1060
      }, {
        "h" : 1358,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 601
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1358,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/gP8bk3aCts"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 67, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/p52BXAQdtJ",
      "expanded_url" : "http:\/\/go.wh.gov\/mMMk5k",
      "display_url" : "go.wh.gov\/mMMk5k"
    } ]
  },
  "geo" : { },
  "id_str" : "769930430917316608",
  "text" : ".@POTUS responds to a letter from a pregnant woman concerned about #Zika: https:\/\/t.co\/p52BXAQdtJ https:\/\/t.co\/gP8bk3aCts",
  "id" : 769930430917316608,
  "created_at" : "2016-08-28 16:11:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 9, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/3orxZo27oT",
      "expanded_url" : "http:\/\/go.wh.gov\/AdZwxR",
      "display_url" : "go.wh.gov\/AdZwxR"
    } ]
  },
  "geo" : { },
  "id_str" : "769911516569141248",
  "text" : "\"Because #Zika can be spread through unprotected sex, it\u2019s not just women who need to be careful\u2014men do too\" \u2014@POTUS https:\/\/t.co\/3orxZo27oT",
  "id" : 769911516569141248,
  "created_at" : "2016-08-28 14:56:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/4XKolIdxgO",
      "expanded_url" : "http:\/\/snpy.tv\/2bOx7nk",
      "display_url" : "snpy.tv\/2bOx7nk"
    } ]
  },
  "geo" : { },
  "id_str" : "769670957367562240",
  "text" : "\"America is not going to forget about...Louisiana. We're going to be here for the long haul.\" \u2014@POTUS #WestWingWeek: https:\/\/t.co\/4XKolIdxgO",
  "id" : 769670957367562240,
  "created_at" : "2016-08-27 23:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 1, 8 ],
      "id_str" : "146569971",
      "id" : 146569971
    }, {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 10, 14 ],
      "id_str" : "15134240",
      "id" : 15134240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 54, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/3orxZnKw0j",
      "expanded_url" : "http:\/\/go.wh.gov\/AdZwxR",
      "display_url" : "go.wh.gov\/AdZwxR"
    } ]
  },
  "geo" : { },
  "id_str" : "769648303596195842",
  "text" : ".@CDCgov, @NIH, &amp; others are working to develop a #Zika vaccine &amp; prevent infection. Here's what you should know: https:\/\/t.co\/3orxZnKw0j",
  "id" : 769648303596195842,
  "created_at" : "2016-08-27 21:30:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 3, 16 ],
      "id_str" : "426909329",
      "id" : 426909329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "pregnant",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/mNNBxLRmj2",
      "expanded_url" : "http:\/\/bit.ly\/2bxHtrv",
      "display_url" : "bit.ly\/2bxHtrv"
    } ]
  },
  "geo" : { },
  "id_str" : "769633379256045568",
  "text" : "RT @DrFriedenCDC: #Zika can be scary, but there are basic steps #pregnant women can take to protect themselves. https:\/\/t.co\/mNNBxLRmj2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "pregnant",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/mNNBxLRmj2",
        "expanded_url" : "http:\/\/bit.ly\/2bxHtrv",
        "display_url" : "bit.ly\/2bxHtrv"
      } ]
    },
    "geo" : { },
    "id_str" : "769270869688479745",
    "text" : "#Zika can be scary, but there are basic steps #pregnant women can take to protect themselves. https:\/\/t.co\/mNNBxLRmj2",
    "id" : 769270869688479745,
    "created_at" : "2016-08-26 20:30:42 +0000",
    "user" : {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "protected" : false,
      "id_str" : "426909329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1677474099\/Frieden-88_-_1200x1200_normal.jpg",
      "id" : 426909329,
      "verified" : true
    }
  },
  "id" : 769633379256045568,
  "created_at" : "2016-08-27 20:31:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 23, 39 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/A2AZSWGCRM",
      "expanded_url" : "http:\/\/snpy.tv\/2bOo0CX",
      "display_url" : "snpy.tv\/2bOo0CX"
    } ]
  },
  "geo" : { },
  "id_str" : "769610571322757121",
  "text" : "Watch @POTUS honor the @NatlParkService staff who've dedicated their careers to maintaining the grounds of the WH: https:\/\/t.co\/A2AZSWGCRM",
  "id" : 769610571322757121,
  "created_at" : "2016-08-27 19:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 4, 20 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/A2AZSWGCRM",
      "expanded_url" : "http:\/\/snpy.tv\/2bOo0CX",
      "display_url" : "snpy.tv\/2bOo0CX"
    } ]
  },
  "geo" : { },
  "id_str" : "769594099712204801",
  "text" : "The @NatlParkService takes care of 18 acres here at the WH. Meet the staff who make it possible: https:\/\/t.co\/A2AZSWGCRM",
  "id" : 769594099712204801,
  "created_at" : "2016-08-27 17:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/3orxZnKw0j",
      "expanded_url" : "http:\/\/go.wh.gov\/AdZwxR",
      "display_url" : "go.wh.gov\/AdZwxR"
    } ]
  },
  "geo" : { },
  "id_str" : "769576520599818245",
  "text" : "Congressional inaction on #Zika means we're using resources we need to fight Ebola, cancer, and other diseases: https:\/\/t.co\/3orxZnKw0j",
  "id" : 769576520599818245,
  "created_at" : "2016-08-27 16:45:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/3orxZnKw0j",
      "expanded_url" : "http:\/\/go.wh.gov\/AdZwxR",
      "display_url" : "go.wh.gov\/AdZwxR"
    } ]
  },
  "geo" : { },
  "id_str" : "769556342847574016",
  "text" : "\"I asked Congress for the emergency resources that public health experts say we need...They said no.\" \u2014@POTUS #Zika https:\/\/t.co\/3orxZnKw0j",
  "id" : 769556342847574016,
  "created_at" : "2016-08-27 15:25:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/3orxZo27oT",
      "expanded_url" : "http:\/\/go.wh.gov\/AdZwxR",
      "display_url" : "go.wh.gov\/AdZwxR"
    } ]
  },
  "geo" : { },
  "id_str" : "769527208847310848",
  "text" : "Watch @POTUS discuss our response to #Zika\u2014and how we can keep protecting public health: https:\/\/t.co\/3orxZo27oT",
  "id" : 769527208847310848,
  "created_at" : "2016-08-27 13:29:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769329065492873221\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/skcD6Hnpsi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq00oqyUMAARmdD.jpg",
      "id_str" : "769328984634961920",
      "id" : 769328984634961920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq00oqyUMAARmdD.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/skcD6Hnpsi"
    } ],
    "hashtags" : [ {
      "text" : "NationalDogDay",
      "indices" : [ 6, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769329065492873221",
  "text" : "Happy #NationalDogDay! https:\/\/t.co\/skcD6Hnpsi",
  "id" : 769329065492873221,
  "created_at" : "2016-08-27 00:21:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Amtrak",
      "screen_name" : "Amtrak",
      "indices" : [ 73, 80 ],
      "id_str" : "119166791",
      "id" : 119166791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769310726389456896",
  "text" : "RT @VP: Back at Biden Station but not to catch a train. Here to announce @Amtrak investment to strengthen infrastructure: https:\/\/t.co\/LaQu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amtrak",
        "screen_name" : "Amtrak",
        "indices" : [ 65, 72 ],
        "id_str" : "119166791",
        "id" : 119166791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/LaQub4TLds",
        "expanded_url" : "http:\/\/go.wh.gov\/bicEfa",
        "display_url" : "go.wh.gov\/bicEfa"
      } ]
    },
    "geo" : { },
    "id_str" : "769261336991821828",
    "text" : "Back at Biden Station but not to catch a train. Here to announce @Amtrak investment to strengthen infrastructure: https:\/\/t.co\/LaQub4TLds",
    "id" : 769261336991821828,
    "created_at" : "2016-08-26 19:52:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 769310726389456896,
  "created_at" : "2016-08-26 23:09:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769300372854861824\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/qBSbJuQd0J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq0Y_8SWcAA4vep.jpg",
      "id_str" : "769298598144143360",
      "id" : 769298598144143360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq0Y_8SWcAA4vep.jpg",
      "sizes" : [ {
        "h" : 1035,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1035,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 1035,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/qBSbJuQd0J"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769300372854861824\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/qBSbJuQd0J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq0Zf5iWAAILZyI.jpg",
      "id_str" : "769299147161731074",
      "id" : 769299147161731074,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq0Zf5iWAAILZyI.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 922
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1654,
        "resize" : "fit",
        "w" : 1271
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 523
      }, {
        "h" : 1654,
        "resize" : "fit",
        "w" : 1271
      } ],
      "display_url" : "pic.twitter.com\/qBSbJuQd0J"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/nUARmzXGf5",
      "expanded_url" : "http:\/\/go.wh.gov\/tNqJHb",
      "display_url" : "go.wh.gov\/tNqJHb"
    } ]
  },
  "geo" : { },
  "id_str" : "769300372854861824",
  "text" : "\u201CDear Delaney\u2026Girls can change the world.\u201D \u2014@POTUS responds to a letter from 3 young women: https:\/\/t.co\/nUARmzXGf5 https:\/\/t.co\/qBSbJuQd0J",
  "id" : 769300372854861824,
  "created_at" : "2016-08-26 22:27:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenEqualityDay",
      "indices" : [ 90, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/NEEu9ybQfn",
      "expanded_url" : "http:\/\/snpy.tv\/2c2A5X2",
      "display_url" : "snpy.tv\/2c2A5X2"
    } ]
  },
  "geo" : { },
  "id_str" : "769296402258206720",
  "text" : "\"Women fought for equality. It was not just given to them.\" \u2014@POTUS\n\nLet's keep fighting. #WomenEqualityDay\nhttps:\/\/t.co\/NEEu9ybQfn",
  "id" : 769296402258206720,
  "created_at" : "2016-08-26 22:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769277295244808196\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/DSH15UmuAB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cq0FkbkUMAACwuR.jpg",
      "id_str" : "769277234783727616",
      "id" : 769277234783727616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cq0FkbkUMAACwuR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/DSH15UmuAB"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 1, 10 ]
    }, {
      "text" : "WomensEqualityDay",
      "indices" : [ 87, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769277295244808196",
  "text" : "\"#EqualPay for equal work should be a fundamental principle of our economy\" \u2014@POTUS on #WomensEqualityDay https:\/\/t.co\/DSH15UmuAB",
  "id" : 769277295244808196,
  "created_at" : "2016-08-26 20:56:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769269765378572289\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/oPawf5Kwni",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqz-mziWIAARtRB.jpg",
      "id_str" : "769269578996260864",
      "id" : 769269578996260864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqz-mziWIAARtRB.jpg",
      "sizes" : [ {
        "h" : 562,
        "resize" : "fit",
        "w" : 1180
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 1180
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 1180
      } ],
      "display_url" : "pic.twitter.com\/oPawf5Kwni"
    } ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 3, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/fQFGEKmFaW",
      "expanded_url" : "http:\/\/go.wh.gov\/aYxVtY",
      "display_url" : "go.wh.gov\/aYxVtY"
    } ]
  },
  "geo" : { },
  "id_str" : "769269765378572289",
  "text" : "On #WomensEqualityDay, we recommit ourselves to keep building a more equal America: https:\/\/t.co\/fQFGEKmFaW https:\/\/t.co\/oPawf5Kwni",
  "id" : 769269765378572289,
  "created_at" : "2016-08-26 20:26:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769259451278725121\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/YMSuxzZTp4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqzx8wXWgAQz_G8.jpg",
      "id_str" : "769255662450802692",
      "id" : 769255662450802692,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqzx8wXWgAQz_G8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/YMSuxzZTp4"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/LJDhdj97N9",
      "expanded_url" : "http:\/\/go.wh.gov\/J2GeYn",
      "display_url" : "go.wh.gov\/J2GeYn"
    } ]
  },
  "geo" : { },
  "id_str" : "769259451278725121",
  "text" : "More than 50 businesses answered @POTUS call to advance #EqualPay in the workplace: https:\/\/t.co\/LJDhdj97N9 https:\/\/t.co\/YMSuxzZTp4",
  "id" : 769259451278725121,
  "created_at" : "2016-08-26 19:45:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769255491558055936\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/w6P9x67rKF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqzxsATWcAEU9Lm.jpg",
      "id_str" : "769255374671212545",
      "id" : 769255374671212545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqzxsATWcAEU9Lm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/w6P9x67rKF"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/LJDhdjqJbJ",
      "expanded_url" : "http:\/\/go.wh.gov\/J2GeYn",
      "display_url" : "go.wh.gov\/J2GeYn"
    } ]
  },
  "geo" : { },
  "id_str" : "769255491558055936",
  "text" : "#EqualPay has been a priority for @POTUS since day 1. Here's how businesses are joining in: https:\/\/t.co\/LJDhdjqJbJ https:\/\/t.co\/w6P9x67rKF",
  "id" : 769255491558055936,
  "created_at" : "2016-08-26 19:29:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/U7rKosWc3L",
      "expanded_url" : "http:\/\/go.wh.gov\/uQtUgi",
      "display_url" : "go.wh.gov\/uQtUgi"
    }, {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/UG2fEXEDyz",
      "expanded_url" : "http:\/\/go.wh.gov\/Pa7PUG",
      "display_url" : "go.wh.gov\/Pa7PUG"
    } ]
  },
  "geo" : { },
  "id_str" : "769241314156277760",
  "text" : "RT @PressSec: Papah\u0101naumoku\u0101kea: \nWhat it is \u2192 https:\/\/t.co\/U7rKosWc3L \nHow to pronounce it  \u2192 https:\/\/t.co\/UG2fEXEDyz https:\/\/t.co\/NLluJdY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/769238111041773572\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/NLluJdYrVE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqzh9gkUsAAOiBF.jpg",
        "id_str" : "769238083204067328",
        "id" : 769238083204067328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqzh9gkUsAAOiBF.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/NLluJdYrVE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/U7rKosWc3L",
        "expanded_url" : "http:\/\/go.wh.gov\/uQtUgi",
        "display_url" : "go.wh.gov\/uQtUgi"
      }, {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/UG2fEXEDyz",
        "expanded_url" : "http:\/\/go.wh.gov\/Pa7PUG",
        "display_url" : "go.wh.gov\/Pa7PUG"
      } ]
    },
    "geo" : { },
    "id_str" : "769238111041773572",
    "text" : "Papah\u0101naumoku\u0101kea: \nWhat it is \u2192 https:\/\/t.co\/U7rKosWc3L \nHow to pronounce it  \u2192 https:\/\/t.co\/UG2fEXEDyz https:\/\/t.co\/NLluJdYrVE",
    "id" : 769238111041773572,
    "created_at" : "2016-08-26 18:20:32 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 769241314156277760,
  "created_at" : "2016-08-26 18:33:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769205495672569861",
  "text" : "RT @POTUS: Nearly 100 years ago, women broke down barriers to the ballot box, moving us closer to a more equal nation. Let's finish what th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769204867235667969",
    "text" : "Nearly 100 years ago, women broke down barriers to the ballot box, moving us closer to a more equal nation. Let's finish what they started.",
    "id" : 769204867235667969,
    "created_at" : "2016-08-26 16:08:26 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 769205495672569861,
  "created_at" : "2016-08-26 16:10:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769199221325099009\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/214It9sL4n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqy-fOlWcAAXK-0.jpg",
      "id_str" : "769199080073490432",
      "id" : 769199080073490432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqy-fOlWcAAXK-0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/214It9sL4n"
    } ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 3, 21 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/LJDhdjqJbJ",
      "expanded_url" : "http:\/\/go.wh.gov\/J2GeYn",
      "display_url" : "go.wh.gov\/J2GeYn"
    } ]
  },
  "geo" : { },
  "id_str" : "769199221325099009",
  "text" : "On #WomensEqualityDay, businesses across the country are committing to advance #EqualPay: https:\/\/t.co\/LJDhdjqJbJ https:\/\/t.co\/214It9sL4n",
  "id" : 769199221325099009,
  "created_at" : "2016-08-26 15:46:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 23, 41 ]
    }, {
      "text" : "EqualPayPledge",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/tdTHHXBXQI",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/26\/its-all-about-tubmans-important-step-toward-equal-pay-womens-equality-day",
      "display_url" : "whitehouse.gov\/blog\/2016\/08\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769191187064446976",
  "text" : "RT @Cecilia44: On this #WomensEqualityDay, we know equality means equal pay for equal work. #EqualPayPledge https:\/\/t.co\/tdTHHXBXQI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 8, 26 ]
      }, {
        "text" : "EqualPayPledge",
        "indices" : [ 77, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/tdTHHXBXQI",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/26\/its-all-about-tubmans-important-step-toward-equal-pay-womens-equality-day",
        "display_url" : "whitehouse.gov\/blog\/2016\/08\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769183681231675392",
    "text" : "On this #WomensEqualityDay, we know equality means equal pay for equal work. #EqualPayPledge https:\/\/t.co\/tdTHHXBXQI",
    "id" : 769183681231675392,
    "created_at" : "2016-08-26 14:44:15 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 769191187064446976,
  "created_at" : "2016-08-26 15:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 16, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769185815595474944",
  "text" : "RT @vj44: Happy #WomensEqualityDay! Excited for today's Twitter Q&amp;A on equal pay + women's opportunity - now starting at 12:30pm ET. See yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 6, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "769185538834329605",
    "text" : "Happy #WomensEqualityDay! Excited for today's Twitter Q&amp;A on equal pay + women's opportunity - now starting at 12:30pm ET. See you then!",
    "id" : 769185538834329605,
    "created_at" : "2016-08-26 14:51:37 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 769185815595474944,
  "created_at" : "2016-08-26 14:52:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Taraji P. Henson",
      "screen_name" : "TherealTaraji",
      "indices" : [ 83, 97 ],
      "id_str" : "84358766",
      "id" : 84358766
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyBirthdayKatherineJohnson",
      "indices" : [ 18, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "769184103736438788",
  "text" : "RT @NASA: Wishing #HappyBirthdayKatherineJohnson, legendary NASA mathematician, as @TheRealTaraji talks her life in numbers:\nhttps:\/\/t.co\/6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Taraji P. Henson",
        "screen_name" : "TherealTaraji",
        "indices" : [ 73, 87 ],
        "id_str" : "84358766",
        "id" : 84358766
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HappyBirthdayKatherineJohnson",
        "indices" : [ 8, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/6u6r4Rn3vq",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/75358f71-92d8-4a85-8749-c678909effc1",
        "display_url" : "amp.twimg.com\/v\/75358f71-92d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769168858401812480",
    "text" : "Wishing #HappyBirthdayKatherineJohnson, legendary NASA mathematician, as @TheRealTaraji talks her life in numbers:\nhttps:\/\/t.co\/6u6r4Rn3vq",
    "id" : 769168858401812480,
    "created_at" : "2016-08-26 13:45:20 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 769184103736438788,
  "created_at" : "2016-08-26 14:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/769183091969712128\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/TVHeEOoy4e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqyv2ozWcAAbWJE.jpg",
      "id_str" : "769182989574107136",
      "id" : 769182989574107136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqyv2ozWcAAbWJE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/TVHeEOoy4e"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/VWh0PfJANY",
      "expanded_url" : "http:\/\/go.wh.gov\/uQtUgi",
      "display_url" : "go.wh.gov\/uQtUgi"
    } ]
  },
  "geo" : { },
  "id_str" : "769183091969712128",
  "text" : "RT to share the good news: @POTUS just created the world's largest marine protected area. https:\/\/t.co\/VWh0PfJANY https:\/\/t.co\/TVHeEOoy4e",
  "id" : 769183091969712128,
  "created_at" : "2016-08-26 14:41:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/rlmF5ZC7Ze",
      "expanded_url" : "http:\/\/on.natgeo.com\/2bEaxf1",
      "display_url" : "on.natgeo.com\/2bEaxf1"
    } ]
  },
  "geo" : { },
  "id_str" : "769167130227011584",
  "text" : "RT @NatGeo: President Obama just quadrupled the size of a national marine monument off northwestern Hawaii. https:\/\/t.co\/rlmF5ZC7Ze",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/rlmF5ZC7Ze",
        "expanded_url" : "http:\/\/on.natgeo.com\/2bEaxf1",
        "display_url" : "on.natgeo.com\/2bEaxf1"
      } ]
    },
    "geo" : { },
    "id_str" : "769024811024654336",
    "text" : "President Obama just quadrupled the size of a national marine monument off northwestern Hawaii. https:\/\/t.co\/rlmF5ZC7Ze",
    "id" : 769024811024654336,
    "created_at" : "2016-08-26 04:12:57 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798181194202566656\/U8QbCBdH_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 769167130227011584,
  "created_at" : "2016-08-26 13:38:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/8Dlx3RavSo",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/26\/presidential-proclamation-papahanaumokuakea-marine-national-monument",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "769164292927217664",
  "text" : "RT @Deese44: It's official: Papah\u0101naumoku\u0101kea has been expanded-now world's largest marine protected area https:\/\/t.co\/8Dlx3RavSo https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/769163888902361088\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rAU0TtRTwI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyUseDVIAAKleY.jpg",
        "id_str" : "769153128075698176",
        "id" : 769153128075698176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyUseDVIAAKleY.jpg",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 993,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1455,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 582,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/rAU0TtRTwI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/769163888902361088\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rAU0TtRTwI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqyU9UZVUAA6JfQ.jpg",
        "id_str" : "769153417541406720",
        "id" : 769153417541406720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqyU9UZVUAA6JfQ.jpg",
        "sizes" : [ {
          "h" : 1501,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2312,
          "resize" : "fit",
          "w" : 3155
        }, {
          "h" : 498,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 879,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/rAU0TtRTwI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/769163888902361088\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rAU0TtRTwI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqydV8rUAAA2ikx.jpg",
        "id_str" : "769162636764119040",
        "id" : 769162636764119040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqydV8rUAAA2ikx.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 801,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1401,
          "resize" : "fit",
          "w" : 2100
        } ],
        "display_url" : "pic.twitter.com\/rAU0TtRTwI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/8Dlx3RavSo",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/26\/presidential-proclamation-papahanaumokuakea-marine-national-monument",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "769163888902361088",
    "text" : "It's official: Papah\u0101naumoku\u0101kea has been expanded-now world's largest marine protected area https:\/\/t.co\/8Dlx3RavSo https:\/\/t.co\/rAU0TtRTwI",
    "id" : 769163888902361088,
    "created_at" : "2016-08-26 13:25:36 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 769164292927217664,
  "created_at" : "2016-08-26 13:27:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/768963827044085761\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/AGGuupN1bS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqvobuaWcAECo-T.jpg",
      "id_str" : "768963724409466881",
      "id" : 768963724409466881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqvobuaWcAECo-T.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/AGGuupN1bS"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 87, 91 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/WymE8KrYex",
      "expanded_url" : "http:\/\/go.wh.gov\/POTUSinParks",
      "display_url" : "go.wh.gov\/POTUSinParks"
    } ]
  },
  "geo" : { },
  "id_str" : "768963827044085761",
  "text" : ".@POTUS shares some family time in Great Falls Park, Virginia: https:\/\/t.co\/WymE8KrYex #TBT #FindYourPark https:\/\/t.co\/AGGuupN1bS",
  "id" : 768963827044085761,
  "created_at" : "2016-08-26 00:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 38, 54 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/Jy8mbvLoh9",
      "expanded_url" : "https:\/\/www.npca.org\/articles\/1258-a-park-loving-justice",
      "display_url" : "npca.org\/articles\/1258-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768958822903746560",
  "text" : "RT @SCOTUSnom: Judge Garland is a big @NatlParkService fan\u2014in honor of #NPS100, check out his favorites: https:\/\/t.co\/Jy8mbvLoh9 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 23, 39 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/768913182073188352\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/ZhrXyMap2f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqu6b-MXEAEGRNO.jpg",
        "id_str" : "768913151110877185",
        "id" : 768913151110877185,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqu6b-MXEAEGRNO.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 505
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 570
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 570
        } ],
        "display_url" : "pic.twitter.com\/ZhrXyMap2f"
      } ],
      "hashtags" : [ {
        "text" : "NPS100",
        "indices" : [ 56, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/Jy8mbvLoh9",
        "expanded_url" : "https:\/\/www.npca.org\/articles\/1258-a-park-loving-justice",
        "display_url" : "npca.org\/articles\/1258-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768913182073188352",
    "text" : "Judge Garland is a big @NatlParkService fan\u2014in honor of #NPS100, check out his favorites: https:\/\/t.co\/Jy8mbvLoh9 https:\/\/t.co\/ZhrXyMap2f",
    "id" : 768913182073188352,
    "created_at" : "2016-08-25 20:49:22 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 768958822903746560,
  "created_at" : "2016-08-25 23:50:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 17, 27 ],
      "id_str" : "18215973",
      "id" : 18215973
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 55, 61 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/768953053848412160\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/l3zxfdWwt0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqvem8_WIAA8MSj.jpg",
      "id_str" : "768952922185015296",
      "id" : 768952922185015296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqvem8_WIAA8MSj.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/l3zxfdWwt0"
    } ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 8, 15 ]
    }, {
      "text" : "TBT",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/WymE8KrYex",
      "expanded_url" : "http:\/\/go.wh.gov\/POTUSinParks",
      "display_url" : "go.wh.gov\/POTUSinParks"
    } ]
  },
  "geo" : { },
  "id_str" : "768953053848412160",
  "text" : "To mark #NPS100, @PeteSouza chose some highlights from @POTUS\u2019s visits to our parks: https:\/\/t.co\/WymE8KrYex #TBT https:\/\/t.co\/l3zxfdWwt0",
  "id" : 768953053848412160,
  "created_at" : "2016-08-25 23:27:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768950629809225728",
  "text" : "RT @Denis44: In 2013, enough opioid prescriptions were written for every adult in the US. Health care professionals, check out https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/h4T8kYDBAF",
        "expanded_url" : "http:\/\/TurnTheTideRx.org\/join",
        "display_url" : "TurnTheTideRx.org\/join"
      } ]
    },
    "geo" : { },
    "id_str" : "768949670051581952",
    "text" : "In 2013, enough opioid prescriptions were written for every adult in the US. Health care professionals, check out https:\/\/t.co\/h4T8kYDBAF",
    "id" : 768949670051581952,
    "created_at" : "2016-08-25 23:14:22 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 768950629809225728,
  "created_at" : "2016-08-25 23:18:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 60, 72 ],
      "id_str" : "18726942",
      "id" : 18726942
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/768900515812020224\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/eUAx3i81rP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cquu4WoWEAA3xPB.jpg",
      "id_str" : "768900444567506944",
      "id" : 768900444567506944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cquu4WoWEAA3xPB.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/eUAx3i81rP"
    } ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/TxZFL1vRAt",
      "expanded_url" : "http:\/\/go.wh.gov\/PtRer",
      "display_url" : "go.wh.gov\/PtRer"
    } ]
  },
  "geo" : { },
  "id_str" : "768900515812020224",
  "text" : "In honor of #NPS100, you can see what it's like to stand in @YosemiteNPS with @POTUS: https:\/\/t.co\/TxZFL1vRAt https:\/\/t.co\/eUAx3i81rP",
  "id" : 768900515812020224,
  "created_at" : "2016-08-25 19:59:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 16, 32 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/HN0iJuc3ey",
      "expanded_url" : "http:\/\/snpy.tv\/2bDaakZ",
      "display_url" : "snpy.tv\/2bDaakZ"
    } ]
  },
  "geo" : { },
  "id_str" : "768886976766369792",
  "text" : "Happy birthday, @NatlParkService! Our national parks belong to all of us\u2014here's to their next 100 years. #NPS100 https:\/\/t.co\/HN0iJuc3ey",
  "id" : 768886976766369792,
  "created_at" : "2016-08-25 19:05:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 46, 62 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768872678015004672",
  "text" : "RT @POTUS: 100 years and going strong. Thanks @NatlParkService for your service, so our kids enjoy our parks as much as we have https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 35, 51 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/768871824885026817\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/1v3W2HLD6f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CquTLgLXYAApMAT.jpg",
        "id_str" : "768869987222249472",
        "id" : 768869987222249472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CquTLgLXYAApMAT.jpg",
        "sizes" : [ {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/1v3W2HLD6f"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768871824885026817",
    "text" : "100 years and going strong. Thanks @NatlParkService for your service, so our kids enjoy our parks as much as we have https:\/\/t.co\/1v3W2HLD6f",
    "id" : 768871824885026817,
    "created_at" : "2016-08-25 18:05:02 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 768872678015004672,
  "created_at" : "2016-08-25 18:08:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 29, 45 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 105, 118 ]
    }, {
      "text" : "NPS100",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768870421009723392",
  "text" : "RT @Interior: Happy birthday @NatlParkService! Thanks for all you do to protect America's special places #FindYourPark #NPS100\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 15, 31 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 91, 104 ]
      }, {
        "text" : "NPS100",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/BalBIrH9Xo",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/0146cf52-c95f-4049-8107-52adb4556ec3",
        "display_url" : "amp.twimg.com\/v\/0146cf52-c95\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768819432072228864",
    "text" : "Happy birthday @NatlParkService! Thanks for all you do to protect America's special places #FindYourPark #NPS100\nhttps:\/\/t.co\/BalBIrH9Xo",
    "id" : 768819432072228864,
    "created_at" : "2016-08-25 14:36:51 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 768870421009723392,
  "created_at" : "2016-08-25 17:59:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Manuel Santos",
      "screen_name" : "JuanManSantos",
      "indices" : [ 3, 17 ],
      "id_str" : "64839766",
      "id" : 64839766
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768856767166083073",
  "text" : "RT @JuanManSantos: Thank you, @POTUS. En nombre de Colombia, agradezco por su constante apoyo y el de EE UU para construir nuestra paz http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/LotfZ7U3XH",
        "expanded_url" : "https:\/\/twitter.com\/potus\/status\/768833523729903618",
        "display_url" : "twitter.com\/potus\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768854228928462848",
    "text" : "Thank you, @POTUS. En nombre de Colombia, agradezco por su constante apoyo y el de EE UU para construir nuestra paz https:\/\/t.co\/LotfZ7U3XH",
    "id" : 768854228928462848,
    "created_at" : "2016-08-25 16:55:07 +0000",
    "user" : {
      "name" : "Juan Manuel Santos",
      "screen_name" : "JuanManSantos",
      "protected" : false,
      "id_str" : "64839766",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729542031987646464\/cOZ2NYqa_normal.jpg",
      "id" : 64839766,
      "verified" : true
    }
  },
  "id" : 768856767166083073,
  "created_at" : "2016-08-25 17:05:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 99, 115 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768843880351559680",
  "text" : "RT @FLOTUS: 100 years of helping families create memories across our beautiful country. Thank you, @NatlParkService! #NPS100 https:\/\/t.co\/T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 87, 103 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/768833425692172288\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/TWqpqvaZn1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqtx5LMUEAIg-oQ.jpg",
        "id_str" : "768833388467720194",
        "id" : 768833388467720194,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqtx5LMUEAIg-oQ.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/TWqpqvaZn1"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/768833425692172288\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/TWqpqvaZn1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqtx5OwVYAATfoL.jpg",
        "id_str" : "768833389424107520",
        "id" : 768833389424107520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqtx5OwVYAATfoL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/TWqpqvaZn1"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/768833425692172288\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/TWqpqvaZn1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqtx5PBVIAADAr4.jpg",
        "id_str" : "768833389495394304",
        "id" : 768833389495394304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqtx5PBVIAADAr4.jpg",
        "sizes" : [ {
          "h" : 1336,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1336,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 802,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/TWqpqvaZn1"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/768833425692172288\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/TWqpqvaZn1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqtx5PAVMAQ-G7n.jpg",
        "id_str" : "768833389491204100",
        "id" : 768833389491204100,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqtx5PAVMAQ-G7n.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/TWqpqvaZn1"
      } ],
      "hashtags" : [ {
        "text" : "NPS100",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768833425692172288",
    "text" : "100 years of helping families create memories across our beautiful country. Thank you, @NatlParkService! #NPS100 https:\/\/t.co\/TWqpqvaZn1",
    "id" : 768833425692172288,
    "created_at" : "2016-08-25 15:32:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 768843880351559680,
  "created_at" : "2016-08-25 16:14:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Juan Manuel Santos",
      "screen_name" : "JuanManSantos",
      "indices" : [ 27, 41 ],
      "id_str" : "64839766",
      "id" : 64839766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768834104896913408",
  "text" : "RT @POTUS: Felicitaciones, @JuanManSantos and Colombia. After decades of war, we stand with you in building a future of peace. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juan Manuel Santos",
        "screen_name" : "JuanManSantos",
        "indices" : [ 16, 30 ],
        "id_str" : "64839766",
        "id" : 64839766
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/haXJaqgS9f",
        "expanded_url" : "https:\/\/twitter.com\/JuanManSantos\/status\/768614115019489281",
        "display_url" : "twitter.com\/JuanManSantos\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768833523729903618",
    "text" : "Felicitaciones, @JuanManSantos and Colombia. After decades of war, we stand with you in building a future of peace. https:\/\/t.co\/haXJaqgS9f",
    "id" : 768833523729903618,
    "created_at" : "2016-08-25 15:32:50 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 768834104896913408,
  "created_at" : "2016-08-25 15:35:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 3, 19 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/wNTTQ8gPmT",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/c85cef01-9e1f-4949-a8e6-56e22bddec3c",
      "display_url" : "amp.twimg.com\/v\/c85cef01-9e1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768824143550701568",
  "text" : "RT @NatlParkService: They belong to you. Join us in celebrating them! #NPS100 #FindYourPark\nhttps:\/\/t.co\/wNTTQ8gPmT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NPS100",
        "indices" : [ 49, 56 ]
      }, {
        "text" : "FindYourPark",
        "indices" : [ 57, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/wNTTQ8gPmT",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/c85cef01-9e1f-4949-a8e6-56e22bddec3c",
        "display_url" : "amp.twimg.com\/v\/c85cef01-9e1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768796426948141056",
    "text" : "They belong to you. Join us in celebrating them! #NPS100 #FindYourPark\nhttps:\/\/t.co\/wNTTQ8gPmT",
    "id" : 768796426948141056,
    "created_at" : "2016-08-25 13:05:26 +0000",
    "user" : {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "protected" : false,
      "id_str" : "36771809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179200522\/NPS_SocialMediaProfilePic_Blue_normal.png",
      "id" : 36771809,
      "verified" : true
    }
  },
  "id" : 768824143550701568,
  "created_at" : "2016-08-25 14:55:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 22, 38 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768816607154081792",
  "text" : "RT @SecretaryJewell: .@NatlParkService \uD83D\uDCAF bday is a great time to look to next century\u2014connecting all Americans to parks &amp; conservation.SJ h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 1, 17 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/dfSXAmpCTm",
        "expanded_url" : "https:\/\/medium.com\/@Interior\/celebrating-100-years-of-the-national-park-service-6a9705e8b7c0#.qvwcjm9r5",
        "display_url" : "medium.com\/@Interior\/cele\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767446416016961536",
    "text" : ".@NatlParkService \uD83D\uDCAF bday is a great time to look to next century\u2014connecting all Americans to parks &amp; conservation.SJ https:\/\/t.co\/dfSXAmpCTm",
    "id" : 767446416016961536,
    "created_at" : "2016-08-21 19:40:58 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 768816607154081792,
  "created_at" : "2016-08-25 14:25:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/eedRwpspli",
      "expanded_url" : "http:\/\/snpy.tv\/2bBbvZs",
      "display_url" : "snpy.tv\/2bBbvZs"
    } ]
  },
  "geo" : { },
  "id_str" : "768602509921386496",
  "text" : "\"You're not alone on this.\"\nWatch as @POTUS meets with families and first responders affected by the #LAflood: https:\/\/t.co\/eedRwpspli",
  "id" : 768602509921386496,
  "created_at" : "2016-08-25 00:14:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Juan Manuel Santos",
      "screen_name" : "JuanManSantos",
      "indices" : [ 62, 76 ],
      "id_str" : "64839766",
      "id" : 64839766
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/768595238000599041\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/VJa9xn2qoV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqqV9O8UAAASFlK.jpg",
      "id_str" : "768591565635715072",
      "id" : 768591565635715072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqqV9O8UAAASFlK.jpg",
      "sizes" : [ {
        "h" : 274,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 923
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 923
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 923
      } ],
      "display_url" : "pic.twitter.com\/VJa9xn2qoV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768595387548508160",
  "text" : "RT @Price44: Readout of @POTUS' Call with Colombian President @JuanManSantos https:\/\/t.co\/VJa9xn2qoV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Juan Manuel Santos",
        "screen_name" : "JuanManSantos",
        "indices" : [ 49, 63 ],
        "id_str" : "64839766",
        "id" : 64839766
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/768595238000599041\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/VJa9xn2qoV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqqV9O8UAAASFlK.jpg",
        "id_str" : "768591565635715072",
        "id" : 768591565635715072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqqV9O8UAAASFlK.jpg",
        "sizes" : [ {
          "h" : 274,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 923
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 923
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 923
        } ],
        "display_url" : "pic.twitter.com\/VJa9xn2qoV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768595238000599041",
    "text" : "Readout of @POTUS' Call with Colombian President @JuanManSantos https:\/\/t.co\/VJa9xn2qoV",
    "id" : 768595238000599041,
    "created_at" : "2016-08-24 23:45:59 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 768595387548508160,
  "created_at" : "2016-08-24 23:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/MJVquf0ZQ4",
      "expanded_url" : "http:\/\/go.wh.gov\/moysMZ",
      "display_url" : "go.wh.gov\/moysMZ"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/51AjtMLAZ3",
      "expanded_url" : "http:\/\/snpy.tv\/2c6ywbI",
      "display_url" : "snpy.tv\/2c6ywbI"
    } ]
  },
  "geo" : { },
  "id_str" : "768584101599338497",
  "text" : ".@POTUS has conserved more land and water than any other president in history: https:\/\/t.co\/MJVquf0ZQ4 #NPS100 https:\/\/t.co\/51AjtMLAZ3",
  "id" : 768584101599338497,
  "created_at" : "2016-08-24 23:01:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768569479970361344",
  "text" : "RT @FactsOnClimate: #NPS100 is more than a celebration. It's a chance to \"recommit to national parks, America's cathedrals.\" \u2192 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NPS100",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/nhGAH6sPBu",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/opinions\/we-must-recommit-to-national-parks-americas-cathedrals\/2016\/08\/24\/52e803ba-5b5a-11e6-831d-0324760ca856_story.html",
        "display_url" : "washingtonpost.com\/opinions\/we-mu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768560808980652032",
    "text" : "#NPS100 is more than a celebration. It's a chance to \"recommit to national parks, America's cathedrals.\" \u2192 https:\/\/t.co\/nhGAH6sPBu",
    "id" : 768560808980652032,
    "created_at" : "2016-08-24 21:29:10 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 768569479970361344,
  "created_at" : "2016-08-24 22:03:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/768561777248305153\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/3YJbJS5kMI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqp617pVMAAzSpE.jpg",
      "id_str" : "768561753382793216",
      "id" : 768561753382793216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqp617pVMAAzSpE.jpg",
      "sizes" : [ {
        "h" : 328,
        "resize" : "fit",
        "w" : 919
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 919
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 919
      } ],
      "display_url" : "pic.twitter.com\/3YJbJS5kMI"
    } ],
    "hashtags" : [ {
      "text" : "Kabul",
      "indices" : [ 50, 56 ]
    }, {
      "text" : "Afghanistan",
      "indices" : [ 58, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768562282372534273",
  "text" : "RT @Price44: Statement on the Terrorist Attack in #Kabul, #Afghanistan https:\/\/t.co\/3YJbJS5kMI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/768561777248305153\/photo\/1",
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/3YJbJS5kMI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqp617pVMAAzSpE.jpg",
        "id_str" : "768561753382793216",
        "id" : 768561753382793216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqp617pVMAAzSpE.jpg",
        "sizes" : [ {
          "h" : 328,
          "resize" : "fit",
          "w" : 919
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 919
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 919
        } ],
        "display_url" : "pic.twitter.com\/3YJbJS5kMI"
      } ],
      "hashtags" : [ {
        "text" : "Kabul",
        "indices" : [ 37, 43 ]
      }, {
        "text" : "Afghanistan",
        "indices" : [ 45, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768561777248305153",
    "text" : "Statement on the Terrorist Attack in #Kabul, #Afghanistan https:\/\/t.co\/3YJbJS5kMI",
    "id" : 768561777248305153,
    "created_at" : "2016-08-24 21:33:01 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 768562282372534273,
  "created_at" : "2016-08-24 21:35:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/768542774526406656\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ENAmAwdfVt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqppTrEUkAAO-t5.jpg",
      "id_str" : "768542473119371264",
      "id" : 768542473119371264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqppTrEUkAAO-t5.jpg",
      "sizes" : [ {
        "h" : 202,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 884
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 884
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 884
      } ],
      "display_url" : "pic.twitter.com\/ENAmAwdfVt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768542774526406656",
  "text" : "Today, @POTUS spoke with President Mattarella of Italy to offer condolences and support following the earthquake: https:\/\/t.co\/ENAmAwdfVt",
  "id" : 768542774526406656,
  "created_at" : "2016-08-24 20:17:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/768526656013148161\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/5hEohzeHQk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqpa55oUAAAtLcw.jpg",
      "id_str" : "768526637189038080",
      "id" : 768526637189038080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqpa55oUAAAtLcw.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 915
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 915
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 915
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/5hEohzeHQk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/BgUJomzas2",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/24\/statement-president-25th-anniversary-ukrainian-independence",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "768527189092409344",
  "text" : "RT @NSC44: Statement by @POTUS on the 25th Anniversary of Ukrainian Independence: https:\/\/t.co\/BgUJomzas2 https:\/\/t.co\/5hEohzeHQk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/768526656013148161\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/5hEohzeHQk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqpa55oUAAAtLcw.jpg",
        "id_str" : "768526637189038080",
        "id" : 768526637189038080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqpa55oUAAAtLcw.jpg",
        "sizes" : [ {
          "h" : 405,
          "resize" : "fit",
          "w" : 915
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 915
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 915
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/5hEohzeHQk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/BgUJomzas2",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/24\/statement-president-25th-anniversary-ukrainian-independence",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768526656013148161",
    "text" : "Statement by @POTUS on the 25th Anniversary of Ukrainian Independence: https:\/\/t.co\/BgUJomzas2 https:\/\/t.co\/5hEohzeHQk",
    "id" : 768526656013148161,
    "created_at" : "2016-08-24 19:13:27 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 768527189092409344,
  "created_at" : "2016-08-24 19:15:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Maine",
      "indices" : [ 97, 103 ]
    }, {
      "text" : "findyourpark",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768472914492620800",
  "text" : "RT @Interior: Our nation's newest national monument: The stunning Katahdin Woods &amp; Waters in #Maine #findyourpark \uD83D\uDCF8:Bill Duffy https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/768464795418910721\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/VEpM4RbO05",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqoipUNXYAEsPaj.jpg",
        "id_str" : "768464779614838785",
        "id" : 768464779614838785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqoipUNXYAEsPaj.jpg",
        "sizes" : [ {
          "h" : 1625,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 945
        }, {
          "h" : 1625,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 536
        } ],
        "display_url" : "pic.twitter.com\/VEpM4RbO05"
      } ],
      "hashtags" : [ {
        "text" : "Maine",
        "indices" : [ 83, 89 ]
      }, {
        "text" : "findyourpark",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768464795418910721",
    "text" : "Our nation's newest national monument: The stunning Katahdin Woods &amp; Waters in #Maine #findyourpark \uD83D\uDCF8:Bill Duffy https:\/\/t.co\/VEpM4RbO05",
    "id" : 768464795418910721,
    "created_at" : "2016-08-24 15:07:39 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 768472914492620800,
  "created_at" : "2016-08-24 15:39:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/768466910459621377\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/NR5Kwly7mx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqoj8cYXEAALMGZ.jpg",
      "id_str" : "768466207737581568",
      "id" : 768466207737581568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqoj8cYXEAALMGZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/NR5Kwly7mx"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 95, 108 ]
    }, {
      "text" : "NPS100",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/MJVquf0ZQ4",
      "expanded_url" : "http:\/\/go.wh.gov\/moysMZ",
      "display_url" : "go.wh.gov\/moysMZ"
    } ]
  },
  "geo" : { },
  "id_str" : "768466910459621377",
  "text" : "Meet our newest National Monument: Katahdin Woods and Waters in Maine: https:\/\/t.co\/MJVquf0ZQ4 #FindYourPark #NPS100 https:\/\/t.co\/NR5Kwly7mx",
  "id" : 768466910459621377,
  "created_at" : "2016-08-24 15:16:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768463093072560128",
  "text" : "RT @SecretaryJewell: Nice work @POTUS for protecting Katahdin Woods &amp; Waters Natl Monument for future gens!SJ #FindYourPark \uD83D\uDCF8:Scot Miller h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/768462715979374592\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/Pp1gxLmcKh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqogsbBWYAAsCy3.jpg",
        "id_str" : "768462633959841792",
        "id" : 768462633959841792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqogsbBWYAAsCy3.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 544
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1638
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 2400,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/Pp1gxLmcKh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/768462715979374592\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/Pp1gxLmcKh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqogsGZXEAAkj7m.jpg",
        "id_str" : "768462628423405568",
        "id" : 768462628423405568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqogsGZXEAAkj7m.jpg",
        "sizes" : [ {
          "h" : 2381,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1625,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 952,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Pp1gxLmcKh"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/768462715979374592\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/Pp1gxLmcKh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqogsGaWEAE1DHe.jpg",
        "id_str" : "768462628427534337",
        "id" : 768462628427534337,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqogsGaWEAE1DHe.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1361
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 797
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 452
        }, {
          "h" : 3000,
          "resize" : "fit",
          "w" : 1993
        } ],
        "display_url" : "pic.twitter.com\/Pp1gxLmcKh"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 93, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768462715979374592",
    "text" : "Nice work @POTUS for protecting Katahdin Woods &amp; Waters Natl Monument for future gens!SJ #FindYourPark \uD83D\uDCF8:Scot Miller https:\/\/t.co\/Pp1gxLmcKh",
    "id" : 768462715979374592,
    "created_at" : "2016-08-24 14:59:23 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 768463093072560128,
  "created_at" : "2016-08-24 15:00:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/MJVquf0ZQ4",
      "expanded_url" : "http:\/\/go.wh.gov\/moysMZ",
      "display_url" : "go.wh.gov\/moysMZ"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/51AjtMLAZ3",
      "expanded_url" : "http:\/\/snpy.tv\/2c6ywbI",
      "display_url" : "snpy.tv\/2c6ywbI"
    } ]
  },
  "geo" : { },
  "id_str" : "768460269441978370",
  "text" : "Breaking: @POTUS just designated the Katahdin Woods and Waters National Monument in Maine \u2192 https:\/\/t.co\/MJVquf0ZQ4 https:\/\/t.co\/51AjtMLAZ3",
  "id" : 768460269441978370,
  "created_at" : "2016-08-24 14:49:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    }, {
      "name" : "The Advocate",
      "screen_name" : "theadvocatebr",
      "indices" : [ 109, 123 ],
      "id_str" : "3983511",
      "id" : 3983511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768218844083159040",
  "text" : "RT @JFriedman44: \"President Obama meets with Louisiana flood victims: 'It shows he hasn't forgotten us'\" via @theadvocatebr https:\/\/t.co\/05\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Advocate",
        "screen_name" : "theadvocatebr",
        "indices" : [ 92, 106 ],
        "id_str" : "3983511",
        "id" : 3983511
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/05dIeErsE0",
        "expanded_url" : "http:\/\/www.theadvocate.com\/louisiana_flood_2016\/article_ae37b308-6962-11e6-bd2e-e367c96fc1dd.html?utm_medium=social&utm_source=twitter&utm_campaign=user-share",
        "display_url" : "theadvocate.com\/louisiana_floo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "768200897516023808",
    "text" : "\"President Obama meets with Louisiana flood victims: 'It shows he hasn't forgotten us'\" via @theadvocatebr https:\/\/t.co\/05dIeErsE0",
    "id" : 768200897516023808,
    "created_at" : "2016-08-23 21:39:01 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 768218844083159040,
  "created_at" : "2016-08-23 22:50:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768165135936618496",
  "text" : "RT @PressSec: In driveway of flooded LA home, @POTUS says fed govt will be here for the long haul to help ppl rebuild. https:\/\/t.co\/UAzRRKk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 32, 38 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/768149185325436928\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/UAzRRKknem",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqkDlx4VMAA3Noc.jpg",
        "id_str" : "768149159023030272",
        "id" : 768149159023030272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqkDlx4VMAA3Noc.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/UAzRRKknem"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768149185325436928",
    "text" : "In driveway of flooded LA home, @POTUS says fed govt will be here for the long haul to help ppl rebuild. https:\/\/t.co\/UAzRRKknem",
    "id" : 768149185325436928,
    "created_at" : "2016-08-23 18:13:31 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 768165135936618496,
  "created_at" : "2016-08-23 19:16:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/6Uet2HpPXI",
      "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
      "display_url" : "go.wh.gov\/LAflood"
    }, {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/d5yjHs8t9I",
      "expanded_url" : "http:\/\/snpy.tv\/2btlkLI",
      "display_url" : "snpy.tv\/2btlkLI"
    } ]
  },
  "geo" : { },
  "id_str" : "768153041287675904",
  "text" : "\"What I want the people of Louisiana to know is this\u2014you\u2019re not alone.\"\u2014@POTUS: https:\/\/t.co\/6Uet2HpPXI https:\/\/t.co\/d5yjHs8t9I",
  "id" : 768153041287675904,
  "created_at" : "2016-08-23 18:28:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/6YAdzn0btu",
      "expanded_url" : "http:\/\/VolunteerLouisiana.gov",
      "display_url" : "VolunteerLouisiana.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "768150804243046400",
  "text" : "RT to spread the word: \"If you want to help, Governor Edwards has put together some ways to start at https:\/\/t.co\/6YAdzn0btu.\" \u2014@POTUS",
  "id" : 768150804243046400,
  "created_at" : "2016-08-23 18:19:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/768149974316089344\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/sTd7EyQWZs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqkEQj1XEAAa15o.jpg",
      "id_str" : "768149893986848768",
      "id" : 768149893986848768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqkEQj1XEAAa15o.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/sTd7EyQWZs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768149974316089344",
  "text" : "\"I\u2019m asking every American to do what you can to help families and local businesses get back on their feet.\" \u2014@POTUS https:\/\/t.co\/sTd7EyQWZs",
  "id" : 768149974316089344,
  "created_at" : "2016-08-23 18:16:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 87, 92 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/OmtI817295",
      "expanded_url" : "http:\/\/www.disasterassistance.gov",
      "display_url" : "disasterassistance.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "768149153432137729",
  "text" : "RT @NSC44: Any Louisianan who needs help in the wake of the #LAflood can get info from @fema at https:\/\/t.co\/OmtI817295. https:\/\/t.co\/RbQcN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 76, 81 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/768148069623881728\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/RbQcNtp5cD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqkCMrqUAAAC017.jpg",
        "id_str" : "768147628345262080",
        "id" : 768147628345262080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqkCMrqUAAAC017.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/RbQcNtp5cD"
      } ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 49, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/OmtI817295",
        "expanded_url" : "http:\/\/www.disasterassistance.gov",
        "display_url" : "disasterassistance.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "768148069623881728",
    "text" : "Any Louisianan who needs help in the wake of the #LAflood can get info from @fema at https:\/\/t.co\/OmtI817295. https:\/\/t.co\/RbQcNtp5cD",
    "id" : 768148069623881728,
    "created_at" : "2016-08-23 18:09:05 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 768149153432137729,
  "created_at" : "2016-08-23 18:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 1, 6 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768148636043575300",
  "text" : "\"@FEMA is working with Louisiana around the clock to help people displaced by the floods find temporary housing.\" \u2014@POTUS",
  "id" : 768148636043575300,
  "created_at" : "2016-08-23 18:11:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768147539015106560",
  "text" : "\"More than 100,000 people have applied for federal assistance...as of today, federal support has now reached 127 million dollars.\" \u2014@POTUS",
  "id" : 768147539015106560,
  "created_at" : "2016-08-23 18:06:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768147317295841280",
  "text" : "RT @NSC44: \"I want to thank all the first responders, the National Guard, all the good neighbors...for their heroism\"-@POTUS on the #LAfloo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 107, 113 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 121, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768147167613562880",
    "text" : "\"I want to thank all the first responders, the National Guard, all the good neighbors...for their heroism\"-@POTUS on the #LAflood.",
    "id" : 768147167613562880,
    "created_at" : "2016-08-23 18:05:30 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 768147317295841280,
  "created_at" : "2016-08-23 18:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/768147285138149378\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/wEsEL5QRlQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqkB3w4WcAAymc7.jpg",
      "id_str" : "768147268969066496",
      "id" : 768147268969066496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqkB3w4WcAAymc7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/wEsEL5QRlQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768147285138149378",
  "text" : "I directed the federal government to mobilize and do everything we can to help.\u201D  \u2014@POTUS in Baton Rouge https:\/\/t.co\/wEsEL5QRlQ",
  "id" : 768147285138149378,
  "created_at" : "2016-08-23 18:05:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/6Uet2HpPXI",
      "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
      "display_url" : "go.wh.gov\/LAflood"
    } ]
  },
  "geo" : { },
  "id_str" : "768147114820075520",
  "text" : "\"What I want the people of Louisiana to know is this\u2014you\u2019re not alone.\"\u2014@POTUS in Baton Rouge: https:\/\/t.co\/6Uet2HpPXI #LAflood",
  "id" : 768147114820075520,
  "created_at" : "2016-08-23 18:05:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/TptW4lmhe9",
      "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
      "display_url" : "go.wh.gov\/LAflood"
    } ]
  },
  "geo" : { },
  "id_str" : "768146642704949248",
  "text" : "RT @WHLive: \u201CI just had a chance to see some of the damage from the historic floods here in Louisiana\" \u2014@POTUS: https:\/\/t.co\/TptW4lmhe9 #LA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 92, 98 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 124, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/TptW4lmhe9",
        "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
        "display_url" : "go.wh.gov\/LAflood"
      } ]
    },
    "geo" : { },
    "id_str" : "768146568289652736",
    "text" : "\u201CI just had a chance to see some of the damage from the historic floods here in Louisiana\" \u2014@POTUS: https:\/\/t.co\/TptW4lmhe9 #LAflood",
    "id" : 768146568289652736,
    "created_at" : "2016-08-23 18:03:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 768146642704949248,
  "created_at" : "2016-08-23 18:03:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/TptW4lmhe9",
      "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
      "display_url" : "go.wh.gov\/LAflood"
    } ]
  },
  "geo" : { },
  "id_str" : "768145366814457856",
  "text" : "RT @WHLive: Today @POTUS is in Baton Rouge to see the federal response efforts first hand. Watch live: https:\/\/t.co\/TptW4lmhe9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/TptW4lmhe9",
        "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
        "display_url" : "go.wh.gov\/LAflood"
      } ]
    },
    "geo" : { },
    "id_str" : "768145285419761664",
    "text" : "Today @POTUS is in Baton Rouge to see the federal response efforts first hand. Watch live: https:\/\/t.co\/TptW4lmhe9",
    "id" : 768145285419761664,
    "created_at" : "2016-08-23 17:58:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 768145366814457856,
  "created_at" : "2016-08-23 17:58:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/768143792599920640\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/4QotSuVzS1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqj-hY-WEAAIa3d.jpg",
      "id_str" : "768143586059751424",
      "id" : 768143586059751424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqj-hY-WEAAIa3d.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/4QotSuVzS1"
    } ],
    "hashtags" : [ {
      "text" : "LAfloods",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/6Uet2HpPXI",
      "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
      "display_url" : "go.wh.gov\/LAflood"
    } ]
  },
  "geo" : { },
  "id_str" : "768143792599920640",
  "text" : "At 1:55pm ET, watch @POTUS speak live from Louisiana on the impact of the #LAfloods: https:\/\/t.co\/6Uet2HpPXI https:\/\/t.co\/4QotSuVzS1",
  "id" : 768143792599920640,
  "created_at" : "2016-08-23 17:52:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Gov John Bel Edwards",
      "screen_name" : "LouisianaGov",
      "indices" : [ 94, 107 ],
      "id_str" : "166374616",
      "id" : 166374616
    }, {
      "name" : "Billy Nungesser",
      "screen_name" : "BillyNungesser",
      "indices" : [ 117, 132 ],
      "id_str" : "177664331",
      "id" : 177664331
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768134142668185602",
  "text" : "RT @PressSec: Arriving in Baton Rouge to view govt response to historic floods, @POTUS greets @LouisianaGov &amp; LG @BillyNungesser https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 66, 72 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Gov John Bel Edwards",
        "screen_name" : "LouisianaGov",
        "indices" : [ 80, 93 ],
        "id_str" : "166374616",
        "id" : 166374616
      }, {
        "name" : "Billy Nungesser",
        "screen_name" : "BillyNungesser",
        "indices" : [ 103, 118 ],
        "id_str" : "177664331",
        "id" : 177664331
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/768131823750656000\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/Wj00upmctN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqjzz1bVMAArB7K.jpg",
        "id_str" : "768131808307261440",
        "id" : 768131808307261440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqjzz1bVMAArB7K.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/Wj00upmctN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768131823750656000",
    "text" : "Arriving in Baton Rouge to view govt response to historic floods, @POTUS greets @LouisianaGov &amp; LG @BillyNungesser https:\/\/t.co\/Wj00upmctN",
    "id" : 768131823750656000,
    "created_at" : "2016-08-23 17:04:32 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 768134142668185602,
  "created_at" : "2016-08-23 17:13:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/768132229147000833\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/boO4GX7mZt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqjqR86WgAAvj9m.jpg",
      "id_str" : "768121330596216832",
      "id" : 768121330596216832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqjqR86WgAAvj9m.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/boO4GX7mZt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/6Uet2HpPXI",
      "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
      "display_url" : "go.wh.gov\/LAflood"
    } ]
  },
  "geo" : { },
  "id_str" : "768132229147000833",
  "text" : "Today @POTUS is in Baton Rouge to meet local officials amid response and recovery efforts: https:\/\/t.co\/6Uet2HpPXI https:\/\/t.co\/boO4GX7mZt",
  "id" : 768132229147000833,
  "created_at" : "2016-08-23 17:06:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fema\/status\/768088172420968448\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/V1RUvys5tp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqjMGwuUMAA7IF8.jpg",
      "id_str" : "768088152997113856",
      "id" : 768088152997113856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqjMGwuUMAA7IF8.jpg",
      "sizes" : [ {
        "h" : 1361,
        "resize" : "fit",
        "w" : 2045
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1361,
        "resize" : "fit",
        "w" : 2045
      } ],
      "display_url" : "pic.twitter.com\/V1RUvys5tp"
    } ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768091464534466560",
  "text" : "RT @fema: Today, financial support to #LAflood survivors reached $127 million. https:\/\/t.co\/V1RUvys5tp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fema\/status\/768088172420968448\/photo\/1",
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/V1RUvys5tp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqjMGwuUMAA7IF8.jpg",
        "id_str" : "768088152997113856",
        "id" : 768088152997113856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqjMGwuUMAA7IF8.jpg",
        "sizes" : [ {
          "h" : 1361,
          "resize" : "fit",
          "w" : 2045
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1361,
          "resize" : "fit",
          "w" : 2045
        } ],
        "display_url" : "pic.twitter.com\/V1RUvys5tp"
      } ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 28, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "768088172420968448",
    "text" : "Today, financial support to #LAflood survivors reached $127 million. https:\/\/t.co\/V1RUvys5tp",
    "id" : 768088172420968448,
    "created_at" : "2016-08-23 14:11:05 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 768091464534466560,
  "created_at" : "2016-08-23 14:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767860410435375105",
  "text" : "RT @VP: This week, I'll travel to Ankara to underscore America's solidarity with the Turkish people in the wake of tragic attacks and coup\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "767859143214559233",
    "geo" : { },
    "id_str" : "767859402040864776",
    "in_reply_to_user_id" : 325830217,
    "text" : "This week, I'll travel to Ankara to underscore America's solidarity with the Turkish people in the wake of tragic attacks and coup attempt.",
    "id" : 767859402040864776,
    "in_reply_to_status_id" : 767859143214559233,
    "created_at" : "2016-08-22 23:02:02 +0000",
    "in_reply_to_screen_name" : "VP",
    "in_reply_to_user_id_str" : "325830217",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 767860410435375105,
  "created_at" : "2016-08-22 23:06:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767860371784867843",
  "text" : "RT @VP: Barbaric attack on a wedding using a child to kill more than 50, 29 of whom are kids. Another 66 injured. We stand with our Turkish\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767859143214559233",
    "text" : "Barbaric attack on a wedding using a child to kill more than 50, 29 of whom are kids. Another 66 injured. We stand with our Turkish allies.",
    "id" : 767859143214559233,
    "created_at" : "2016-08-22 23:01:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 767860371784867843,
  "created_at" : "2016-08-22 23:05:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/767859108917682176\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Is7j7zdOwx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqf7tq0WcAMzUP0.jpg",
      "id_str" : "767859023496507395",
      "id" : 767859023496507395,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqf7tq0WcAMzUP0.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Is7j7zdOwx"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/767859108917682176\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Is7j7zdOwx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cqf7trTWEAEdebs.jpg",
      "id_str" : "767859023626506241",
      "id" : 767859023626506241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cqf7trTWEAEdebs.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Is7j7zdOwx"
    } ],
    "hashtags" : [ {
      "text" : "Rio2016",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/G6iq5occa4",
      "expanded_url" : "http:\/\/go.wh.gov\/yKD6cp",
      "display_url" : "go.wh.gov\/yKD6cp"
    } ]
  },
  "geo" : { },
  "id_str" : "767859108917682176",
  "text" : "ICYMI: Go behind the scenes with the the U.S. delegation at the #Rio2016 Closing Ceremony: https:\/\/t.co\/G6iq5occa4 https:\/\/t.co\/Is7j7zdOwx",
  "id" : 767859108917682176,
  "created_at" : "2016-08-22 23:00:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAfloods",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Sty8sv9zAR",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/17\/live-updates-what-you-need-know-about-flooding-louisiana",
      "display_url" : "whitehouse.gov\/blog\/2016\/08\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767841377912778752",
  "text" : "RT @NSC44: Get the latest on how the federal government is taking action in response to the #LAfloods: https:\/\/t.co\/Sty8sv9zAR https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/767830475851243520\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/ydRiHtTDG8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqfXpb7UsAA3ojI.jpg",
        "id_str" : "767819368361144320",
        "id" : 767819368361144320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqfXpb7UsAA3ojI.jpg",
        "sizes" : [ {
          "h" : 457,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 819
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 819
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 819
        } ],
        "display_url" : "pic.twitter.com\/ydRiHtTDG8"
      } ],
      "hashtags" : [ {
        "text" : "LAfloods",
        "indices" : [ 81, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/Sty8sv9zAR",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/17\/live-updates-what-you-need-know-about-flooding-louisiana",
        "display_url" : "whitehouse.gov\/blog\/2016\/08\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767830475851243520",
    "text" : "Get the latest on how the federal government is taking action in response to the #LAfloods: https:\/\/t.co\/Sty8sv9zAR https:\/\/t.co\/ydRiHtTDG8",
    "id" : 767830475851243520,
    "created_at" : "2016-08-22 21:07:05 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 767841377912778752,
  "created_at" : "2016-08-22 21:50:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/NXMmr44Lpn",
      "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
      "display_url" : "go.wh.gov\/LAflood"
    } ]
  },
  "geo" : { },
  "id_str" : "767813436784910336",
  "text" : "RT @PressSec: Tomorrow, @POTUS will be in Baton Rouge to review response and recovery efforts. Get the latest here: https:\/\/t.co\/NXMmr44Lpn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/NXMmr44Lpn",
        "expanded_url" : "http:\/\/go.wh.gov\/LAflood",
        "display_url" : "go.wh.gov\/LAflood"
      } ]
    },
    "geo" : { },
    "id_str" : "767809844166348800",
    "text" : "Tomorrow, @POTUS will be in Baton Rouge to review response and recovery efforts. Get the latest here: https:\/\/t.co\/NXMmr44Lpn",
    "id" : 767809844166348800,
    "created_at" : "2016-08-22 19:45:06 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 767813436784910336,
  "created_at" : "2016-08-22 19:59:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 31, 40 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 56, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767806472763736064",
  "text" : "RT @JFriedman44: Reminder from @PressSec today: we need #TPP to avoid a vacuum that China will fill, leaving U.S. workers unprotected https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 14, 23 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 39, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ptWAFk7z49",
        "expanded_url" : "http:\/\/snpy.tv\/2bZz2Iw",
        "display_url" : "snpy.tv\/2bZz2Iw"
      } ]
    },
    "geo" : { },
    "id_str" : "767805718120402946",
    "text" : "Reminder from @PressSec today: we need #TPP to avoid a vacuum that China will fill, leaving U.S. workers unprotected https:\/\/t.co\/ptWAFk7z49",
    "id" : 767805718120402946,
    "created_at" : "2016-08-22 19:28:42 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 767806472763736064,
  "created_at" : "2016-08-22 19:31:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 3, 16 ],
      "id_str" : "426909329",
      "id" : 426909329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flood",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/4U2qmjMY0n",
      "expanded_url" : "http:\/\/1.usa.gov\/27vVHzj",
      "display_url" : "1.usa.gov\/27vVHzj"
    } ]
  },
  "geo" : { },
  "id_str" : "767735767737176064",
  "text" : "RT @DrFriedenCDC: Read important  safety tips to protect yourself and your family during and after a #flood: https:\/\/t.co\/4U2qmjMY0n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "flood",
        "indices" : [ 83, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/4U2qmjMY0n",
        "expanded_url" : "http:\/\/1.usa.gov\/27vVHzj",
        "display_url" : "1.usa.gov\/27vVHzj"
      } ]
    },
    "geo" : { },
    "id_str" : "767724317643837440",
    "text" : "Read important  safety tips to protect yourself and your family during and after a #flood: https:\/\/t.co\/4U2qmjMY0n",
    "id" : 767724317643837440,
    "created_at" : "2016-08-22 14:05:15 +0000",
    "user" : {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "protected" : false,
      "id_str" : "426909329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1677474099\/Frieden-88_-_1200x1200_normal.jpg",
      "id" : 426909329,
      "verified" : true
    }
  },
  "id" : 767735767737176064,
  "created_at" : "2016-08-22 14:50:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simone Biles",
      "screen_name" : "Simone_Biles",
      "indices" : [ 3, 16 ],
      "id_str" : "173677727",
      "id" : 173677727
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767727409311453184",
  "text" : "RT @Simone_Biles: @POTUS Thank You! Such a huge honor! GO USA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "767528566099701760",
    "geo" : { },
    "id_str" : "767549327979995136",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS Thank You! Such a huge honor! GO USA",
    "id" : 767549327979995136,
    "in_reply_to_status_id" : 767528566099701760,
    "created_at" : "2016-08-22 02:29:54 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Simone Biles",
      "screen_name" : "Simone_Biles",
      "protected" : false,
      "id_str" : "173677727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792573650067197952\/gIzhpbr2_normal.jpg",
      "id" : 173677727,
      "verified" : true
    }
  },
  "id" : 767727409311453184,
  "created_at" : "2016-08-22 14:17:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767529720367820800",
  "text" : "RT @POTUS: Couldn't be prouder of #TeamUSA. Your determination and passion inspired so many of us. You carried that flag high tonight, @Sim\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simone Biles",
        "screen_name" : "Simone_Biles",
        "indices" : [ 124, 137 ],
        "id_str" : "173677727",
        "id" : 173677727
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 23, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "767528566099701760",
    "text" : "Couldn't be prouder of #TeamUSA. Your determination and passion inspired so many of us. You carried that flag high tonight, @Simone_Biles!",
    "id" : 767528566099701760,
    "created_at" : "2016-08-22 01:07:24 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 767529720367820800,
  "created_at" : "2016-08-22 01:12:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 24, 32 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/767492925827592192\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/rwMdVrQuEm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqauulDUsAAFg1j.jpg",
      "id_str" : "767492901756514304",
      "id" : 767492901756514304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqauulDUsAAFg1j.jpg",
      "sizes" : [ {
        "h" : 446,
        "resize" : "fit",
        "w" : 556
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 556
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 556
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 556
      } ],
      "display_url" : "pic.twitter.com\/rwMdVrQuEm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/BrAT3oZ1dZ",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/21\/statement-nsc-spokesperson-ned-price-terrorist-attack-puntland-somalia",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767493392830005249",
  "text" : "RT @NSC44: Statement by @Price44 on the Terrorist Attack in Puntland, Somalia: https:\/\/t.co\/BrAT3oZ1dZ https:\/\/t.co\/rwMdVrQuEm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ned Price",
        "screen_name" : "Price44",
        "indices" : [ 13, 21 ],
        "id_str" : "4518870555",
        "id" : 4518870555
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/767492925827592192\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/rwMdVrQuEm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqauulDUsAAFg1j.jpg",
        "id_str" : "767492901756514304",
        "id" : 767492901756514304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqauulDUsAAFg1j.jpg",
        "sizes" : [ {
          "h" : 446,
          "resize" : "fit",
          "w" : 556
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 556
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 556
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 556
        } ],
        "display_url" : "pic.twitter.com\/rwMdVrQuEm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/BrAT3oZ1dZ",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/21\/statement-nsc-spokesperson-ned-price-terrorist-attack-puntland-somalia",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767492925827592192",
    "text" : "Statement by @Price44 on the Terrorist Attack in Puntland, Somalia: https:\/\/t.co\/BrAT3oZ1dZ https:\/\/t.co\/rwMdVrQuEm",
    "id" : 767492925827592192,
    "created_at" : "2016-08-21 22:45:47 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 767493392830005249,
  "created_at" : "2016-08-21 22:47:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "Volunteer Louisiana",
      "screen_name" : "volunteer_la",
      "indices" : [ 66, 79 ],
      "id_str" : "282703963",
      "id" : 282703963
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/u4kxODjWAr",
      "expanded_url" : "http:\/\/www.volunteerlouisiana.gov\/disaster-services\/donate\/",
      "display_url" : "volunteerlouisiana.gov\/disaster-servi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767472804639965184",
  "text" : "RT @fema: Want to help people affected by the #LAflood? Check out @volunteer_la's helpful links: https:\/\/t.co\/u4kxODjWAr https:\/\/t.co\/ub178\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Volunteer Louisiana",
        "screen_name" : "volunteer_la",
        "indices" : [ 56, 69 ],
        "id_str" : "282703963",
        "id" : 282703963
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fema\/status\/767419422684217344\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/ub178dcOUF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqZq4nGVYAE6y-O.jpg",
        "id_str" : "767418307314016257",
        "id" : 767418307314016257,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqZq4nGVYAE6y-O.jpg",
        "sizes" : [ {
          "h" : 850,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1450,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1510,
          "resize" : "fit",
          "w" : 2133
        } ],
        "display_url" : "pic.twitter.com\/ub178dcOUF"
      } ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 36, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/u4kxODjWAr",
        "expanded_url" : "http:\/\/www.volunteerlouisiana.gov\/disaster-services\/donate\/",
        "display_url" : "volunteerlouisiana.gov\/disaster-servi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767419422684217344",
    "text" : "Want to help people affected by the #LAflood? Check out @volunteer_la's helpful links: https:\/\/t.co\/u4kxODjWAr https:\/\/t.co\/ub178dcOUF",
    "id" : 767419422684217344,
    "created_at" : "2016-08-21 17:53:42 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 767472804639965184,
  "created_at" : "2016-08-21 21:25:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/446yeUHR6Q",
      "expanded_url" : "http:\/\/EveryKidInAPark.org",
      "display_url" : "EveryKidInAPark.org"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mguWAY8Ovm",
      "expanded_url" : "http:\/\/go.wh.gov\/NPS100",
      "display_url" : "go.wh.gov\/NPS100"
    } ]
  },
  "geo" : { },
  "id_str" : "767436345337753600",
  "text" : "\"If you've got a 4th grader in your family, you can get a free pass\" \u2014@POTUS: https:\/\/t.co\/446yeUHR6Q #FindYourPark https:\/\/t.co\/mguWAY8Ovm",
  "id" : 767436345337753600,
  "created_at" : "2016-08-21 19:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/mguWAY8Ovm",
      "expanded_url" : "http:\/\/go.wh.gov\/NPS100",
      "display_url" : "go.wh.gov\/NPS100"
    } ]
  },
  "geo" : { },
  "id_str" : "767419770283057153",
  "text" : "FACT: @POTUS has protected more than 265 million acres of public lands &amp; waters\u2014more than any other U.S. president: https:\/\/t.co\/mguWAY8Ovm",
  "id" : 767419770283057153,
  "created_at" : "2016-08-21 17:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 24, 32 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/767405393685286912\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/xapm5eInvc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqZfH1gUIAAR-MU.jpg",
      "id_str" : "767405374739587072",
      "id" : 767405374739587072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqZfH1gUIAAR-MU.jpg",
      "sizes" : [ {
        "h" : 366,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 366,
        "resize" : "fit",
        "w" : 718
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/xapm5eInvc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/igpvVq57Kp",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/21\/statement-nsc-spokesperson-ned-price-terrorist-attack-gaziantep-turkey",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767405935950258176",
  "text" : "RT @NSC44: Statement by @Price44 on the Terrorist Attack in Gaziantep, Turkey: https:\/\/t.co\/igpvVq57Kp https:\/\/t.co\/xapm5eInvc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ned Price",
        "screen_name" : "Price44",
        "indices" : [ 13, 21 ],
        "id_str" : "4518870555",
        "id" : 4518870555
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/767405393685286912\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/xapm5eInvc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqZfH1gUIAAR-MU.jpg",
        "id_str" : "767405374739587072",
        "id" : 767405374739587072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqZfH1gUIAAR-MU.jpg",
        "sizes" : [ {
          "h" : 366,
          "resize" : "fit",
          "w" : 718
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 718
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 718
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/xapm5eInvc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/igpvVq57Kp",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/21\/statement-nsc-spokesperson-ned-price-terrorist-attack-gaziantep-turkey",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767405393685286912",
    "text" : "Statement by @Price44 on the Terrorist Attack in Gaziantep, Turkey: https:\/\/t.co\/igpvVq57Kp https:\/\/t.co\/xapm5eInvc",
    "id" : 767405393685286912,
    "created_at" : "2016-08-21 16:57:58 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 767405935950258176,
  "created_at" : "2016-08-21 17:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/mguWAY8Ovm",
      "expanded_url" : "http:\/\/go.wh.gov\/NPS100",
      "display_url" : "go.wh.gov\/NPS100"
    } ]
  },
  "geo" : { },
  "id_str" : "767397874174791681",
  "text" : "We\u2019ve done a lot to preserve our lands, culture, and history.\nAnd we're not done yet. #NPS100 https:\/\/t.co\/mguWAY8Ovm",
  "id" : 767397874174791681,
  "created_at" : "2016-08-21 16:28:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/767385808328286209\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ceA8gHeyLu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqZF_Y6XgAEtVvl.jpg",
      "id_str" : "767377741834584065",
      "id" : 767377741834584065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqZF_Y6XgAEtVvl.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ceA8gHeyLu"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 62, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/HMWfJkhJ7r",
      "expanded_url" : "http:\/\/findyourpark.com\/",
      "display_url" : "findyourpark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "767385808328286209",
  "text" : ".@POTUS's conservation of public lands is downright historic. #FindYourPark \u2192 https:\/\/t.co\/HMWfJkhJ7r https:\/\/t.co\/ceA8gHeyLu",
  "id" : 767385808328286209,
  "created_at" : "2016-08-21 15:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christy Goldfuss",
      "screen_name" : "Goldfuss44",
      "indices" : [ 3, 14 ],
      "id_str" : "2377561969",
      "id" : 2377561969
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767381721063026688",
  "text" : "RT @Goldfuss44: \"These parks belong to all of us...they\u2019re worth celebrating\u2014not just this year, but every year.\" \u2014@POTUS #NPS100 https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 99, 105 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NPS100",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/iUy5UBUd31",
        "expanded_url" : "http:\/\/go.wh.gov\/NPS100",
        "display_url" : "go.wh.gov\/NPS100"
      } ]
    },
    "geo" : { },
    "id_str" : "767360741007515648",
    "text" : "\"These parks belong to all of us...they\u2019re worth celebrating\u2014not just this year, but every year.\" \u2014@POTUS #NPS100 https:\/\/t.co\/iUy5UBUd31",
    "id" : 767360741007515648,
    "created_at" : "2016-08-21 14:00:32 +0000",
    "user" : {
      "name" : "Christy Goldfuss",
      "screen_name" : "Goldfuss44",
      "protected" : false,
      "id_str" : "2377561969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668926989940727809\/WeMBK__c_normal.jpg",
      "id" : 2377561969,
      "verified" : true
    }
  },
  "id" : 767381721063026688,
  "created_at" : "2016-08-21 15:23:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 61, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/T7cLNK2dmH",
      "expanded_url" : "http:\/\/go.wh.gov\/4ETx12",
      "display_url" : "go.wh.gov\/4ETx12"
    }, {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/mguWAYqpTW",
      "expanded_url" : "http:\/\/go.wh.gov\/NPS100",
      "display_url" : "go.wh.gov\/NPS100"
    } ]
  },
  "geo" : { },
  "id_str" : "767377374333788160",
  "text" : "Celebrate the 100th anniversary of the National Park Service\u2014#FindYourPark: https:\/\/t.co\/T7cLNK2dmH https:\/\/t.co\/mguWAYqpTW",
  "id" : 767377374333788160,
  "created_at" : "2016-08-21 15:06:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 85, 92 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/lHUcDrbzPq",
      "expanded_url" : "http:\/\/snpy.tv\/2bo4f32",
      "display_url" : "snpy.tv\/2bo4f32"
    } ]
  },
  "geo" : { },
  "id_str" : "767126755530334208",
  "text" : "Happy birthday Bei Bei! \uD83D\uDC3C  We're continuing the celebration with this throwback from @FLOTUS's trip to China: https:\/\/t.co\/lHUcDrbzPq",
  "id" : 767126755530334208,
  "created_at" : "2016-08-20 22:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 35, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/mguWAY8Ovm",
      "expanded_url" : "http:\/\/go.wh.gov\/NPS100",
      "display_url" : "go.wh.gov\/NPS100"
    } ]
  },
  "geo" : { },
  "id_str" : "767111695915372544",
  "text" : "\"I want to encourage all of you to #FindYourPark so that you and your family can experience these sacred places\" https:\/\/t.co\/mguWAY8Ovm",
  "id" : 767111695915372544,
  "created_at" : "2016-08-20 21:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 81, 88 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/mguWAY8Ovm",
      "expanded_url" : "http:\/\/go.wh.gov\/NPS100",
      "display_url" : "go.wh.gov\/NPS100"
    } ]
  },
  "geo" : { },
  "id_str" : "767094580634202112",
  "text" : "\"As FDR once said: 'There is nothing so American as our national parks'\" \u2014@POTUS #NPS100 #FindYourPark https:\/\/t.co\/mguWAY8Ovm",
  "id" : 767094580634202112,
  "created_at" : "2016-08-20 20:22:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DidYouKnow",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767035929198460928",
  "text" : "RT @Interior: #DidYouKnow: You can visit all national parks for free Aug 25-28. Please RT to spread the word! #FindYourPark https:\/\/t.co\/H5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/766412783206404096\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/H5KbzTsZED",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqLYXJ2WAAAPTAS.jpg",
        "id_str" : "766412778898849792",
        "id" : 766412778898849792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqLYXJ2WAAAPTAS.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/H5KbzTsZED"
      } ],
      "hashtags" : [ {
        "text" : "DidYouKnow",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "FindYourPark",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766412783206404096",
    "text" : "#DidYouKnow: You can visit all national parks for free Aug 25-28. Please RT to spread the word! #FindYourPark https:\/\/t.co\/H5KbzTsZED",
    "id" : 766412783206404096,
    "created_at" : "2016-08-18 23:13:41 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 767035929198460928,
  "created_at" : "2016-08-20 16:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/eF6F90m3fX",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/6bb51640-87dd-4f13-8474-fd5be84329f7",
      "display_url" : "amp.twimg.com\/v\/6bb51640-87d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "767031704150212608",
  "text" : "RT @gov: Congrats, @POTUS! To celebrate 10 million followers, we took a look back at some of your best Tweets. \uD83C\uDF89\nhttps:\/\/t.co\/eF6F90m3fX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/eF6F90m3fX",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/6bb51640-87dd-4f13-8474-fd5be84329f7",
        "display_url" : "amp.twimg.com\/v\/6bb51640-87d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "767028486565343232",
    "text" : "Congrats, @POTUS! To celebrate 10 million followers, we took a look back at some of your best Tweets. \uD83C\uDF89\nhttps:\/\/t.co\/eF6F90m3fX",
    "id" : 767028486565343232,
    "created_at" : "2016-08-20 16:00:16 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663898965784395776\/rEWW6euI_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 767031704150212608,
  "created_at" : "2016-08-20 16:13:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/mguWAYqpTW",
      "expanded_url" : "http:\/\/go.wh.gov\/NPS100",
      "display_url" : "go.wh.gov\/NPS100"
    } ]
  },
  "geo" : { },
  "id_str" : "767028462423044096",
  "text" : "\"No camera...can fully capture the beauty and majesty of America\u2019s national parks.\" \u2014@POTUS #NPS100 https:\/\/t.co\/mguWAYqpTW",
  "id" : 767028462423044096,
  "created_at" : "2016-08-20 16:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPS100",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/mguWAY8Ovm",
      "expanded_url" : "http:\/\/go.wh.gov\/NPS100",
      "display_url" : "go.wh.gov\/NPS100"
    } ]
  },
  "geo" : { },
  "id_str" : "767014626114490368",
  "text" : "\"These parks belong to all of us...they\u2019re worth celebrating\u2014not just this year, but every year.\" \u2014@POTUS #NPS100 https:\/\/t.co\/mguWAY8Ovm",
  "id" : 767014626114490368,
  "created_at" : "2016-08-20 15:05:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "National Zoo",
      "screen_name" : "NationalZoo",
      "indices" : [ 35, 47 ],
      "id_str" : "17045060",
      "id" : 17045060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "767014301706006530",
  "text" : "RT @FLOTUS: Today we celebrate the @NationalZoo's \"precious treasure\" as he turns one year old. Happy birthday, Bei Bei! -mo https:\/\/t.co\/D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Zoo",
        "screen_name" : "NationalZoo",
        "indices" : [ 23, 35 ],
        "id_str" : "17045060",
        "id" : 17045060
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/766966636645679104\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/DqpXhqG9rt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqTP7tKXYAAn4id.jpg",
        "id_str" : "766966461202128896",
        "id" : 766966461202128896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqTP7tKXYAAn4id.jpg",
        "sizes" : [ {
          "h" : 814,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1899,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 1389,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/DqpXhqG9rt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766966636645679104",
    "text" : "Today we celebrate the @NationalZoo's \"precious treasure\" as he turns one year old. Happy birthday, Bei Bei! -mo https:\/\/t.co\/DqpXhqG9rt",
    "id" : 766966636645679104,
    "created_at" : "2016-08-20 11:54:30 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 767014301706006530,
  "created_at" : "2016-08-20 15:03:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAfloods",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Sty8sv9zAR",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/17\/live-updates-what-you-need-know-about-flooding-louisiana",
      "display_url" : "whitehouse.gov\/blog\/2016\/08\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766742567451037696",
  "text" : "RT @NSC44: Here's how the federal government is taking action in areas affected by #LAfloods: https:\/\/t.co\/Sty8sv9zAR https:\/\/t.co\/OC988s6B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/766723110737326080\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/OC988s6BbB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqPq3m1VMAAq9v7.jpg",
        "id_str" : "766714602621054976",
        "id" : 766714602621054976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqPq3m1VMAAq9v7.jpg",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 836
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 836
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 836
        } ],
        "display_url" : "pic.twitter.com\/OC988s6BbB"
      } ],
      "hashtags" : [ {
        "text" : "LAfloods",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/Sty8sv9zAR",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/17\/live-updates-what-you-need-know-about-flooding-louisiana",
        "display_url" : "whitehouse.gov\/blog\/2016\/08\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766723110737326080",
    "text" : "Here's how the federal government is taking action in areas affected by #LAfloods: https:\/\/t.co\/Sty8sv9zAR https:\/\/t.co\/OC988s6BbB",
    "id" : 766723110737326080,
    "created_at" : "2016-08-19 19:46:49 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 766742567451037696,
  "created_at" : "2016-08-19 21:04:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/766727351715725313\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/79F22EAcMq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqP2JTyVIAAYG6O.jpg",
      "id_str" : "766727001373745152",
      "id" : 766727001373745152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqP2JTyVIAAYG6O.jpg",
      "sizes" : [ {
        "h" : 304,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 878
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 878
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 878
      } ],
      "display_url" : "pic.twitter.com\/79F22EAcMq"
    } ],
    "hashtags" : [ {
      "text" : "LAfloods",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/g7j1hLHfNu",
      "expanded_url" : "http:\/\/go.wh.gov\/bJDr8A",
      "display_url" : "go.wh.gov\/bJDr8A"
    } ]
  },
  "geo" : { },
  "id_str" : "766727351715725313",
  "text" : "On Tuesday, @POTUS will head to Baton Rouge to see the impact of the devastating #LAfloods: https:\/\/t.co\/g7j1hLHfNu https:\/\/t.co\/79F22EAcMq",
  "id" : 766727351715725313,
  "created_at" : "2016-08-19 20:03:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID\/OFDA",
      "screen_name" : "theOFDA",
      "indices" : [ 3, 11 ],
      "id_str" : "514033223",
      "id" : 514033223
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldHumanitarianDay",
      "indices" : [ 16, 37 ]
    }, {
      "text" : "HumanityActs",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766697073752367109",
  "text" : "RT @theOFDA: On #WorldHumanitarianDay, we pay tribute to aid workers who risk their lives helping others globally. #HumanityActs https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/theOFDA\/status\/766605741495029760\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/r5uDK5zE45",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqOHoMzWEAQLuEr.jpg",
        "id_str" : "766605486284214276",
        "id" : 766605486284214276,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqOHoMzWEAQLuEr.jpg",
        "sizes" : [ {
          "h" : 273,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 550
        } ],
        "display_url" : "pic.twitter.com\/r5uDK5zE45"
      } ],
      "hashtags" : [ {
        "text" : "WorldHumanitarianDay",
        "indices" : [ 3, 24 ]
      }, {
        "text" : "HumanityActs",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766605741495029760",
    "text" : "On #WorldHumanitarianDay, we pay tribute to aid workers who risk their lives helping others globally. #HumanityActs https:\/\/t.co\/r5uDK5zE45",
    "id" : 766605741495029760,
    "created_at" : "2016-08-19 12:00:26 +0000",
    "user" : {
      "name" : "USAID\/OFDA",
      "screen_name" : "theOFDA",
      "protected" : false,
      "id_str" : "514033223",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727552386273796097\/M5uMvmjf_normal.jpg",
      "id" : 514033223,
      "verified" : true
    }
  },
  "id" : 766697073752367109,
  "created_at" : "2016-08-19 18:03:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fusion",
      "screen_name" : "Fusion",
      "indices" : [ 3, 10 ],
      "id_str" : "121817564",
      "id" : 121817564
    }, {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 16, 32 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766688538616274944",
  "text" : "RT @Fusion: The @Surgeon_General says pregnant women can help avoid #Zika in Miami by wearing repellant and long sleeves: \nhttps:\/\/t.co\/aRV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Surgeon General",
        "screen_name" : "Surgeon_General",
        "indices" : [ 4, 20 ],
        "id_str" : "455024343",
        "id" : 455024343
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 56, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/aRVjVt5Br9",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/be58a28f-fc34-4a49-ac2f-e6fce207be43",
        "display_url" : "amp.twimg.com\/v\/be58a28f-fc3\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "766681609441386497",
    "geo" : { },
    "id_str" : "766682476496289792",
    "in_reply_to_user_id" : 121817564,
    "text" : "The @Surgeon_General says pregnant women can help avoid #Zika in Miami by wearing repellant and long sleeves: \nhttps:\/\/t.co\/aRVjVt5Br9",
    "id" : 766682476496289792,
    "in_reply_to_status_id" : 766681609441386497,
    "created_at" : "2016-08-19 17:05:21 +0000",
    "in_reply_to_screen_name" : "Fusion",
    "in_reply_to_user_id_str" : "121817564",
    "user" : {
      "name" : "Fusion",
      "screen_name" : "Fusion",
      "protected" : false,
      "id_str" : "121817564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738697994216710145\/LcfV6jBt_normal.jpg",
      "id" : 121817564,
      "verified" : true
    }
  },
  "id" : 766688538616274944,
  "created_at" : "2016-08-19 17:29:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AmbassadorRice\/status\/766676170540580865\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/elTLD0MsYt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqPH4z0WYAAUE_K.jpg",
      "id_str" : "766676140379496448",
      "id" : 766676140379496448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqPH4z0WYAAUE_K.jpg",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 494,
        "resize" : "fit",
        "w" : 1784
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 494,
        "resize" : "fit",
        "w" : 1784
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/elTLD0MsYt"
    } ],
    "hashtags" : [ {
      "text" : "WorldHumanitarianDay",
      "indices" : [ 36, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766680589651116032",
  "text" : "RT @AmbassadorRice: My Statement on #WorldHumanitarianDay https:\/\/t.co\/elTLD0MsYt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmbassadorRice\/status\/766676170540580865\/photo\/1",
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/elTLD0MsYt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqPH4z0WYAAUE_K.jpg",
        "id_str" : "766676140379496448",
        "id" : 766676140379496448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqPH4z0WYAAUE_K.jpg",
        "sizes" : [ {
          "h" : 332,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 1784
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 494,
          "resize" : "fit",
          "w" : 1784
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/elTLD0MsYt"
      } ],
      "hashtags" : [ {
        "text" : "WorldHumanitarianDay",
        "indices" : [ 16, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766676170540580865",
    "text" : "My Statement on #WorldHumanitarianDay https:\/\/t.co\/elTLD0MsYt",
    "id" : 766676170540580865,
    "created_at" : "2016-08-19 16:40:17 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 766680589651116032,
  "created_at" : "2016-08-19 16:57:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766660017068146688",
  "text" : "RT @DrBiden: These inspiring Olympians are showing the world how small acts of kindness can make a difference. Shine on! \u2014Jill https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/gDyCD64JXw",
        "expanded_url" : "http:\/\/nymag.com\/thecut\/2016\/08\/shine-theory-rio-olympics-gymnastics-track.html?linkId=27821749",
        "display_url" : "nymag.com\/thecut\/2016\/08\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766659442725249024",
    "text" : "These inspiring Olympians are showing the world how small acts of kindness can make a difference. Shine on! \u2014Jill https:\/\/t.co\/gDyCD64JXw",
    "id" : 766659442725249024,
    "created_at" : "2016-08-19 15:33:49 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 766660017068146688,
  "created_at" : "2016-08-19 15:36:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 26, 30 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/1Va9cs0ZAm",
      "expanded_url" : "http:\/\/on.wsj.com\/2bBe534",
      "display_url" : "on.wsj.com\/2bBe534"
    } ]
  },
  "geo" : { },
  "id_str" : "766644273324392448",
  "text" : "RT @Deese44: Check out my @WSJ piece with Jeff Zients: Enlist the market in the climate-change fight https:\/\/t.co\/1Va9cs0ZAm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 13, 17 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/1Va9cs0ZAm",
        "expanded_url" : "http:\/\/on.wsj.com\/2bBe534",
        "display_url" : "on.wsj.com\/2bBe534"
      } ]
    },
    "geo" : { },
    "id_str" : "766453219627184128",
    "text" : "Check out my @WSJ piece with Jeff Zients: Enlist the market in the climate-change fight https:\/\/t.co\/1Va9cs0ZAm",
    "id" : 766453219627184128,
    "created_at" : "2016-08-19 01:54:22 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 766644273324392448,
  "created_at" : "2016-08-19 14:33:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Helen Maroulis",
      "screen_name" : "helen_maroulis",
      "indices" : [ 76, 91 ],
      "id_str" : "238321550",
      "id" : 238321550
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 12, 20 ]
    }, {
      "text" : "Rio2016",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/H7T7N8iw2Z",
      "expanded_url" : "https:\/\/twitter.com\/usawrestling\/status\/766371413435486208",
      "display_url" : "twitter.com\/usawrestling\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766380928956559360",
  "text" : "RT @FLOTUS: #TeamUSA continues to make history! Way to bring home the gold, @Helen_Maroulis. \uD83C\uDDFA\uD83C\uDDF8 #Rio2016 https:\/\/t.co\/H7T7N8iw2Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Helen Maroulis",
        "screen_name" : "helen_maroulis",
        "indices" : [ 64, 79 ],
        "id_str" : "238321550",
        "id" : 238321550
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "Rio2016",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/H7T7N8iw2Z",
        "expanded_url" : "https:\/\/twitter.com\/usawrestling\/status\/766371413435486208",
        "display_url" : "twitter.com\/usawrestling\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766378030872797184",
    "text" : "#TeamUSA continues to make history! Way to bring home the gold, @Helen_Maroulis. \uD83C\uDDFA\uD83C\uDDF8 #Rio2016 https:\/\/t.co\/H7T7N8iw2Z",
    "id" : 766378030872797184,
    "created_at" : "2016-08-18 20:55:35 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 766380928956559360,
  "created_at" : "2016-08-18 21:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Price44\/status\/766363400079220737\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/QEWKyRQtlo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqKq-0jUIAAql2s.jpg",
      "id_str" : "766362882841780224",
      "id" : 766362882841780224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqKq-0jUIAAql2s.jpg",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 1862
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 1862
      }, {
        "h" : 155,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/QEWKyRQtlo"
    } ],
    "hashtags" : [ {
      "text" : "Turkey",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766363484451897344",
  "text" : "RT @Price44: Statement on the Terrorist Attacks in #Turkey https:\/\/t.co\/QEWKyRQtlo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Price44\/status\/766363400079220737\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/QEWKyRQtlo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqKq-0jUIAAql2s.jpg",
        "id_str" : "766362882841780224",
        "id" : 766362882841780224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqKq-0jUIAAql2s.jpg",
        "sizes" : [ {
          "h" : 424,
          "resize" : "fit",
          "w" : 1862
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 1862
        }, {
          "h" : 155,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/QEWKyRQtlo"
      } ],
      "hashtags" : [ {
        "text" : "Turkey",
        "indices" : [ 38, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766363400079220737",
    "text" : "Statement on the Terrorist Attacks in #Turkey https:\/\/t.co\/QEWKyRQtlo",
    "id" : 766363400079220737,
    "created_at" : "2016-08-18 19:57:27 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 766363484451897344,
  "created_at" : "2016-08-18 19:57:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 3, 10 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/7DoqsOydOW",
      "expanded_url" : "http:\/\/bit.ly\/2bwynd4",
      "display_url" : "bit.ly\/2bwynd4"
    } ]
  },
  "geo" : { },
  "id_str" : "766351993313062912",
  "text" : "RT @DHSgov: Listen to Secretary Johnson discuss the response efforts in Louisiana \u2192 https:\/\/t.co\/7DoqsOydOW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/7DoqsOydOW",
        "expanded_url" : "http:\/\/bit.ly\/2bwynd4",
        "display_url" : "bit.ly\/2bwynd4"
      } ]
    },
    "geo" : { },
    "id_str" : "766350061022416897",
    "text" : "Listen to Secretary Johnson discuss the response efforts in Louisiana \u2192 https:\/\/t.co\/7DoqsOydOW",
    "id" : 766350061022416897,
    "created_at" : "2016-08-18 19:04:27 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 766351993313062912,
  "created_at" : "2016-08-18 19:12:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/aHPoGTwLd8",
      "expanded_url" : "http:\/\/volunteerlouisiana.gov",
      "display_url" : "volunteerlouisiana.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "766345719376510978",
  "text" : "RT @fema: Thank you for the outpouring of support for #LAflood recovery. Please remember cash is best. https:\/\/t.co\/aHPoGTwLd8 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/fema\/status\/766314535489765376\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/W7kbz8N4Xm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqJ-zoIW8AA6Jec.jpg",
        "id_str" : "766314312017309696",
        "id" : 766314312017309696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqJ-zoIW8AA6Jec.jpg",
        "sizes" : [ {
          "h" : 850,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1450,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1510,
          "resize" : "fit",
          "w" : 2133
        } ],
        "display_url" : "pic.twitter.com\/W7kbz8N4Xm"
      } ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 44, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/aHPoGTwLd8",
        "expanded_url" : "http:\/\/volunteerlouisiana.gov",
        "display_url" : "volunteerlouisiana.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "766314535489765376",
    "text" : "Thank you for the outpouring of support for #LAflood recovery. Please remember cash is best. https:\/\/t.co\/aHPoGTwLd8 https:\/\/t.co\/W7kbz8N4Xm",
    "id" : 766314535489765376,
    "created_at" : "2016-08-18 16:43:17 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 766345719376510978,
  "created_at" : "2016-08-18 18:47:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/gf1wlaOrFv",
      "expanded_url" : "http:\/\/go.wh.gov\/mj6nRJ",
      "display_url" : "go.wh.gov\/mj6nRJ"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/m5pyGoCgFo",
      "expanded_url" : "http:\/\/snpy.tv\/2aZGIJo",
      "display_url" : "snpy.tv\/2aZGIJo"
    } ]
  },
  "geo" : { },
  "id_str" : "766340875957964800",
  "text" : "Watch former White House interns on the impact of their time in the Obama Administration: https:\/\/t.co\/gf1wlaOrFv https:\/\/t.co\/m5pyGoCgFo",
  "id" : 766340875957964800,
  "created_at" : "2016-08-18 18:27:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NASAMarsDay",
      "indices" : [ 16, 28 ]
    }, {
      "text" : "JourneytoMars",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766319011030245376",
  "text" : "RT @NASA: Happy #NASAMarsDay! Join us all day as we explore the steps we're taking to send humans on a #JourneytoMars! https:\/\/t.co\/JxGIEyT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/766251554047422465\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/JxGIEyTlKz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqJFuhUXYAIeXCj.jpg",
        "id_str" : "766251552126492674",
        "id" : 766251552126492674,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqJFuhUXYAIeXCj.jpg",
        "sizes" : [ {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 509,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/JxGIEyTlKz"
      } ],
      "hashtags" : [ {
        "text" : "NASAMarsDay",
        "indices" : [ 6, 18 ]
      }, {
        "text" : "JourneytoMars",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766251554047422465",
    "text" : "Happy #NASAMarsDay! Join us all day as we explore the steps we're taking to send humans on a #JourneytoMars! https:\/\/t.co\/JxGIEyTlKz",
    "id" : 766251554047422465,
    "created_at" : "2016-08-18 12:33:01 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 766319011030245376,
  "created_at" : "2016-08-18 17:01:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/766308315450126336\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/0O0aHLH3ru",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqJ5QxkUAAAy9hF.jpg",
      "id_str" : "766308215696916480",
      "id" : 766308215696916480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqJ5QxkUAAAy9hF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/0O0aHLH3ru"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766308708515139584",
  "text" : "RT @PressSec: Here's what @POTUS will be doing on his trip to China and Laos in September. https:\/\/t.co\/0O0aHLH3ru",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 12, 18 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/766308315450126336\/photo\/1",
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/0O0aHLH3ru",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqJ5QxkUAAAy9hF.jpg",
        "id_str" : "766308215696916480",
        "id" : 766308215696916480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqJ5QxkUAAAy9hF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 942
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 942
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 942
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/0O0aHLH3ru"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766308315450126336",
    "text" : "Here's what @POTUS will be doing on his trip to China and Laos in September. https:\/\/t.co\/0O0aHLH3ru",
    "id" : 766308315450126336,
    "created_at" : "2016-08-18 16:18:34 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 766308708515139584,
  "created_at" : "2016-08-18 16:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Brianna Rollins",
      "screen_name" : "Bri_Rollin",
      "indices" : [ 44, 55 ],
      "id_str" : "424300606",
      "id" : 424300606
    }, {
      "name" : "Kristi Castlin",
      "screen_name" : "KristiHollywood",
      "indices" : [ 57, 73 ],
      "id_str" : "261461590",
      "id" : 261461590
    }, {
      "name" : "Nia Ali",
      "screen_name" : "ItsPooda",
      "indices" : [ 79, 88 ],
      "id_str" : "57832798",
      "id" : 57832798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "100mHurdles",
      "indices" : [ 90, 102 ]
    }, {
      "text" : "Rio2016",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766288715878662144",
  "text" : "RT @FLOTUS: 1, 2, 3, sweep! So proud of you @Bri_Rollin, @KristiHollywood, and @ItsPooda. #100mHurdles #Rio2016 -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brianna Rollins",
        "screen_name" : "Bri_Rollin",
        "indices" : [ 32, 43 ],
        "id_str" : "424300606",
        "id" : 424300606
      }, {
        "name" : "Kristi Castlin",
        "screen_name" : "KristiHollywood",
        "indices" : [ 45, 61 ],
        "id_str" : "261461590",
        "id" : 261461590
      }, {
        "name" : "Nia Ali",
        "screen_name" : "ItsPooda",
        "indices" : [ 67, 76 ],
        "id_str" : "57832798",
        "id" : 57832798
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "100mHurdles",
        "indices" : [ 78, 90 ]
      }, {
        "text" : "Rio2016",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "766278898023792640",
    "text" : "1, 2, 3, sweep! So proud of you @Bri_Rollin, @KristiHollywood, and @ItsPooda. #100mHurdles #Rio2016 -mo",
    "id" : 766278898023792640,
    "created_at" : "2016-08-18 14:21:40 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 766288715878662144,
  "created_at" : "2016-08-18 15:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    }, {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 14, 29 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Uz9aKpEZgz",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/8\/18\/12387600\/susan-rice-vox",
      "display_url" : "vox.com\/2016\/8\/18\/1238\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766276143620120576",
  "text" : "RT @Price44: .@AmbassadorRice on the state of the world &amp; our efforts to protect &amp; promote U.S. interests: https:\/\/t.co\/Uz9aKpEZgz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Rice",
        "screen_name" : "AmbassadorRice",
        "indices" : [ 1, 16 ],
        "id_str" : "19674502",
        "id" : 19674502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/Uz9aKpEZgz",
        "expanded_url" : "http:\/\/www.vox.com\/2016\/8\/18\/12387600\/susan-rice-vox",
        "display_url" : "vox.com\/2016\/8\/18\/1238\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "766274719708385280",
    "text" : ".@AmbassadorRice on the state of the world &amp; our efforts to protect &amp; promote U.S. interests: https:\/\/t.co\/Uz9aKpEZgz",
    "id" : 766274719708385280,
    "created_at" : "2016-08-18 14:05:04 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 766276143620120576,
  "created_at" : "2016-08-18 14:10:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/g7j1hLHfNu",
      "expanded_url" : "http:\/\/go.wh.gov\/bJDr8A",
      "display_url" : "go.wh.gov\/bJDr8A"
    } ]
  },
  "geo" : { },
  "id_str" : "766070535780442112",
  "text" : "Get the latest on how we're supporting those impacted by the #LAflood\u2014and learn what you can do to be prepared \u2192 https:\/\/t.co\/g7j1hLHfNu",
  "id" : 766070535780442112,
  "created_at" : "2016-08-18 00:33:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/766042445918326784\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/PB7vczX1Yi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqF_aLvXYAAmlSV.jpg",
      "id_str" : "766033499434475520",
      "id" : 766033499434475520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqF_aLvXYAAmlSV.jpg",
      "sizes" : [ {
        "h" : 520,
        "resize" : "fit",
        "w" : 1040
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 1040
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 1040
      } ],
      "display_url" : "pic.twitter.com\/PB7vczX1Yi"
    } ],
    "hashtags" : [ {
      "text" : "windenergy",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/3QGaummOv5",
      "expanded_url" : "http:\/\/energy.gov\/windreport",
      "display_url" : "energy.gov\/windreport"
    } ]
  },
  "geo" : { },
  "id_str" : "766057997726519296",
  "text" : "RT @ENERGY: New reports track U.S. #windenergy industry's strong 2015 growth: https:\/\/t.co\/3QGaummOv5 https:\/\/t.co\/PB7vczX1Yi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dashboard.twitter.com\" rel=\"nofollow\"\u003ETwitter Business Experience\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/766042445918326784\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/PB7vczX1Yi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqF_aLvXYAAmlSV.jpg",
        "id_str" : "766033499434475520",
        "id" : 766033499434475520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqF_aLvXYAAmlSV.jpg",
        "sizes" : [ {
          "h" : 520,
          "resize" : "fit",
          "w" : 1040
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 1040
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 1040
        } ],
        "display_url" : "pic.twitter.com\/PB7vczX1Yi"
      } ],
      "hashtags" : [ {
        "text" : "windenergy",
        "indices" : [ 23, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/3QGaummOv5",
        "expanded_url" : "http:\/\/energy.gov\/windreport",
        "display_url" : "energy.gov\/windreport"
      } ]
    },
    "geo" : { },
    "id_str" : "766042445918326784",
    "text" : "New reports track U.S. #windenergy industry's strong 2015 growth: https:\/\/t.co\/3QGaummOv5 https:\/\/t.co\/PB7vczX1Yi",
    "id" : 766042445918326784,
    "created_at" : "2016-08-17 22:42:06 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 766057997726519296,
  "created_at" : "2016-08-17 23:43:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOAA NCEI Climate",
      "screen_name" : "NOAANCEIclimate",
      "indices" : [ 3, 19 ],
      "id_str" : "916735110",
      "id" : 916735110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfClimate",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/WRhkazdafY",
      "expanded_url" : "http:\/\/bit.ly\/2aWWiE5",
      "display_url" : "bit.ly\/2aWWiE5"
    } ]
  },
  "geo" : { },
  "id_str" : "766050789550948354",
  "text" : "RT @NOAANCEIclimate: July 2016 avg global temperature was record warm at 1.57\u00B0F above avg: https:\/\/t.co\/WRhkazdafY #StateOfClimate https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NOAANCEIclimate\/status\/765928435336278016\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/eil8Dfq8gk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqEf2iEXYAA5C8y.jpg",
        "id_str" : "765928433348206592",
        "id" : 765928433348206592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqEf2iEXYAA5C8y.jpg",
        "sizes" : [ {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        } ],
        "display_url" : "pic.twitter.com\/eil8Dfq8gk"
      } ],
      "hashtags" : [ {
        "text" : "StateOfClimate",
        "indices" : [ 94, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/WRhkazdafY",
        "expanded_url" : "http:\/\/bit.ly\/2aWWiE5",
        "display_url" : "bit.ly\/2aWWiE5"
      } ]
    },
    "geo" : { },
    "id_str" : "765928435336278016",
    "text" : "July 2016 avg global temperature was record warm at 1.57\u00B0F above avg: https:\/\/t.co\/WRhkazdafY #StateOfClimate https:\/\/t.co\/eil8Dfq8gk",
    "id" : 765928435336278016,
    "created_at" : "2016-08-17 15:09:03 +0000",
    "user" : {
      "name" : "NOAA NCEI Climate",
      "screen_name" : "NOAANCEIclimate",
      "protected" : false,
      "id_str" : "916735110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590917629642084354\/NswGA2rK_normal.png",
      "id" : 916735110,
      "verified" : true
    }
  },
  "id" : 766050789550948354,
  "created_at" : "2016-08-17 23:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandra Raisman",
      "screen_name" : "Aly_Raisman",
      "indices" : [ 3, 15 ],
      "id_str" : "372891057",
      "id" : 372891057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/XfcH7rqhAZ",
      "expanded_url" : "https:\/\/twitter.com\/flotus\/status\/765969194097733632",
      "display_url" : "twitter.com\/flotus\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "766015818257747969",
  "text" : "RT @Aly_Raisman: Salmon, avocado, whole wheat bread, almonds, pineapples &amp; Greek yogurt \uD83D\uDE0A\uD83D\uDC4C\uD83C\uDFFB\uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/XfcH7rqhAZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/XfcH7rqhAZ",
        "expanded_url" : "https:\/\/twitter.com\/flotus\/status\/765969194097733632",
        "display_url" : "twitter.com\/flotus\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765993804289761280",
    "text" : "Salmon, avocado, whole wheat bread, almonds, pineapples &amp; Greek yogurt \uD83D\uDE0A\uD83D\uDC4C\uD83C\uDFFB\uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/XfcH7rqhAZ",
    "id" : 765993804289761280,
    "created_at" : "2016-08-17 19:28:49 +0000",
    "user" : {
      "name" : "Alexandra Raisman",
      "screen_name" : "Aly_Raisman",
      "protected" : false,
      "id_str" : "372891057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770653602771677184\/F2K8uqAS_normal.jpg",
      "id" : 372891057,
      "verified" : true
    }
  },
  "id" : 766015818257747969,
  "created_at" : "2016-08-17 20:56:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765999317001859076",
  "text" : "RT @JFriedman44: Today @POTUS received an update on the resources that have been provided\nto support the #LAflood response &amp; recovery https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JFriedman44\/status\/765998920774410241\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/4lF2tcjItk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqFf75JWAAA02QE.jpg",
        "id_str" : "765998894186627072",
        "id" : 765998894186627072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqFf75JWAAA02QE.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 1034
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 1034
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 1034
        }, {
          "h" : 149,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/4lF2tcjItk"
      } ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765998920774410241",
    "text" : "Today @POTUS received an update on the resources that have been provided\nto support the #LAflood response &amp; recovery https:\/\/t.co\/4lF2tcjItk",
    "id" : 765998920774410241,
    "created_at" : "2016-08-17 19:49:08 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 765999317001859076,
  "created_at" : "2016-08-17 19:50:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "indices" : [ 3, 8 ],
      "id_str" : "14342564",
      "id" : 14342564
    }, {
      "name" : "NOAA NCEI Climate",
      "screen_name" : "NOAANCEIclimate",
      "indices" : [ 57, 73 ],
      "id_str" : "916735110",
      "id" : 916735110
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NOAA\/status\/765926869493579776\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/rXA2ItaHDu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqEeXGVWEAEVdRQ.jpg",
      "id_str" : "765926793815658497",
      "id" : 765926793815658497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqEeXGVWEAEVdRQ.jpg",
      "sizes" : [ {
        "h" : 766,
        "resize" : "fit",
        "w" : 990
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 990
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 990
      } ],
      "display_url" : "pic.twitter.com\/rXA2ItaHDu"
    } ],
    "hashtags" : [ {
      "text" : "StateOfClimate",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/yfJUYpFugi",
      "expanded_url" : "http:\/\/bit.ly\/2aWWiE5",
      "display_url" : "bit.ly\/2aWWiE5"
    } ]
  },
  "geo" : { },
  "id_str" : "765991749265137664",
  "text" : "RT @NOAA: Jan\u2013July 2016 was record warm for the globe -- @NOAANCEIclimate https:\/\/t.co\/yfJUYpFugi #StateOfClimate https:\/\/t.co\/rXA2ItaHDu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NOAA NCEI Climate",
        "screen_name" : "NOAANCEIclimate",
        "indices" : [ 47, 63 ],
        "id_str" : "916735110",
        "id" : 916735110
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NOAA\/status\/765926869493579776\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/rXA2ItaHDu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqEeXGVWEAEVdRQ.jpg",
        "id_str" : "765926793815658497",
        "id" : 765926793815658497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqEeXGVWEAEVdRQ.jpg",
        "sizes" : [ {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 766,
          "resize" : "fit",
          "w" : 990
        } ],
        "display_url" : "pic.twitter.com\/rXA2ItaHDu"
      } ],
      "hashtags" : [ {
        "text" : "StateOfClimate",
        "indices" : [ 88, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/yfJUYpFugi",
        "expanded_url" : "http:\/\/bit.ly\/2aWWiE5",
        "display_url" : "bit.ly\/2aWWiE5"
      } ]
    },
    "geo" : { },
    "id_str" : "765926869493579776",
    "text" : "Jan\u2013July 2016 was record warm for the globe -- @NOAANCEIclimate https:\/\/t.co\/yfJUYpFugi #StateOfClimate https:\/\/t.co\/rXA2ItaHDu",
    "id" : 765926869493579776,
    "created_at" : "2016-08-17 15:02:50 +0000",
    "user" : {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "protected" : false,
      "id_str" : "14342564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529277799018676225\/MOsMKe14_normal.jpeg",
      "id" : 14342564,
      "verified" : true
    }
  },
  "id" : 765991749265137664,
  "created_at" : "2016-08-17 19:20:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 44, 56 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765981907423203328",
  "text" : "RT @NSC44: On the #LAflood, @POTUS directed @CraigatFEMA to utilize all resources available to assist in response and recovery.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 17, 23 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Craig Fugate",
        "screen_name" : "CraigatFEMA",
        "indices" : [ 33, 45 ],
        "id_str" : "67378554",
        "id" : 67378554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 7, 15 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "765979662199693312",
    "geo" : { },
    "id_str" : "765979900054495232",
    "in_reply_to_user_id" : 369245377,
    "text" : "On the #LAflood, @POTUS directed @CraigatFEMA to utilize all resources available to assist in response and recovery.",
    "id" : 765979900054495232,
    "in_reply_to_status_id" : 765979662199693312,
    "created_at" : "2016-08-17 18:33:34 +0000",
    "in_reply_to_screen_name" : "NSC44",
    "in_reply_to_user_id_str" : "369245377",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 765981907423203328,
  "created_at" : "2016-08-17 18:41:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 103, 108 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765981890910294018",
  "text" : "RT @NSC44: This morning @POTUS received the latest in a series of regular updates on the #LAflood from @FEMA Administrator Craig Fugate.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 92, 97 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 78, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765979662199693312",
    "text" : "This morning @POTUS received the latest in a series of regular updates on the #LAflood from @FEMA Administrator Craig Fugate.",
    "id" : 765979662199693312,
    "created_at" : "2016-08-17 18:32:37 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 765981890910294018,
  "created_at" : "2016-08-17 18:41:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA Climate",
      "screen_name" : "NASAClimate",
      "indices" : [ 3, 15 ],
      "id_str" : "15461733",
      "id" : 15461733
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthRightNow",
      "indices" : [ 108, 122 ]
    }, {
      "text" : "globalwarming",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/fXDaxFDSqx",
      "expanded_url" : "http:\/\/climate.nasa.gov\/news\/2479\/nasa-analysis-finds-july-2016-is-warmest-on-record",
      "display_url" : "climate.nasa.gov\/news\/2479\/nasa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765959830590910464",
  "text" : "RT @NASAClimate: July 2016 was warmest month in 136 years of modern record-keeping. https:\/\/t.co\/fXDaxFDSqx #EarthRightNow #globalwarming",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EarthRightNow",
        "indices" : [ 91, 105 ]
      }, {
        "text" : "globalwarming",
        "indices" : [ 106, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/fXDaxFDSqx",
        "expanded_url" : "http:\/\/climate.nasa.gov\/news\/2479\/nasa-analysis-finds-july-2016-is-warmest-on-record",
        "display_url" : "climate.nasa.gov\/news\/2479\/nasa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765647766299082753",
    "text" : "July 2016 was warmest month in 136 years of modern record-keeping. https:\/\/t.co\/fXDaxFDSqx #EarthRightNow #globalwarming",
    "id" : 765647766299082753,
    "created_at" : "2016-08-16 20:33:47 +0000",
    "user" : {
      "name" : "NASA Climate",
      "screen_name" : "NASAClimate",
      "protected" : false,
      "id_str" : "15461733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460810073661378560\/b7WVZjGJ_normal.jpeg",
      "id" : 15461733,
      "verified" : true
    }
  },
  "id" : 765959830590910464,
  "created_at" : "2016-08-17 17:13:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/765941174620286976\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Cm4TTwtOoe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqErSg7WEAAHQY2.jpg",
      "id_str" : "765941008706179072",
      "id" : 765941008706179072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqErSg7WEAAHQY2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Cm4TTwtOoe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765941174620286976",
  "text" : "Businesses are answering @POTUS's call to give Americans with a criminal record a fair chance at a job and a future. https:\/\/t.co\/Cm4TTwtOoe",
  "id" : 765941174620286976,
  "created_at" : "2016-08-17 15:59:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "USA Gymnastics",
      "screen_name" : "USAGym",
      "indices" : [ 59, 66 ],
      "id_str" : "43124180",
      "id" : 43124180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765752383725047812",
  "text" : "RT @FLOTUS: Incredible\u2014and inspiring! The men and women of @USAGym are a testament to the power of perseverance and dedication. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA Gymnastics",
        "screen_name" : "USAGym",
        "indices" : [ 47, 54 ],
        "id_str" : "43124180",
        "id" : 43124180
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/TYaPB3vzw4",
        "expanded_url" : "https:\/\/twitter.com\/GMA\/status\/765655533177085953",
        "display_url" : "twitter.com\/GMA\/status\/765\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765746811315388417",
    "text" : "Incredible\u2014and inspiring! The men and women of @USAGym are a testament to the power of perseverance and dedication. https:\/\/t.co\/TYaPB3vzw4",
    "id" : 765746811315388417,
    "created_at" : "2016-08-17 03:07:21 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 765752383725047812,
  "created_at" : "2016-08-17 03:29:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765657408249159680",
  "text" : "RT @PressSec: In fact, even as our economy grows, carbon pollution from our energy sector has hit its lowest level in 25 years! https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/765655793366470656\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/1vCKbtTKyf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CqAn2aAUEAAZG2C.jpg",
        "id_str" : "765655752300040192",
        "id" : 765655752300040192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqAn2aAUEAAZG2C.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/1vCKbtTKyf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "765655412498583552",
    "geo" : { },
    "id_str" : "765655793366470656",
    "in_reply_to_user_id" : 113420831,
    "text" : "In fact, even as our economy grows, carbon pollution from our energy sector has hit its lowest level in 25 years! https:\/\/t.co\/1vCKbtTKyf",
    "id" : 765655793366470656,
    "in_reply_to_status_id" : 765655412498583552,
    "created_at" : "2016-08-16 21:05:40 +0000",
    "in_reply_to_screen_name" : "PressSec",
    "in_reply_to_user_id_str" : "113420831",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 765657408249159680,
  "created_at" : "2016-08-16 21:12:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/knYGWZZ8cY",
      "expanded_url" : "http:\/\/go.wh.gov\/dUZfK3",
      "display_url" : "go.wh.gov\/dUZfK3"
    } ]
  },
  "geo" : { },
  "id_str" : "765657139998253056",
  "text" : "RT @PressSec: Today, we took another step to reduce carbon pollution on our roads &amp; fight climate change: https:\/\/t.co\/knYGWZZ8cY https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/765655412498583552\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/53VgJr0zaz",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CqAnfB7UEAA3tFL.jpg",
        "id_str" : "765655350699626496",
        "id" : 765655350699626496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CqAnfB7UEAA3tFL.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/53VgJr0zaz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/knYGWZZ8cY",
        "expanded_url" : "http:\/\/go.wh.gov\/dUZfK3",
        "display_url" : "go.wh.gov\/dUZfK3"
      } ]
    },
    "geo" : { },
    "id_str" : "765655412498583552",
    "text" : "Today, we took another step to reduce carbon pollution on our roads &amp; fight climate change: https:\/\/t.co\/knYGWZZ8cY https:\/\/t.co\/53VgJr0zaz",
    "id" : 765655412498583552,
    "created_at" : "2016-08-16 21:04:10 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 765657139998253056,
  "created_at" : "2016-08-16 21:11:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/765638825703903232\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/wH491Qvcxm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqARl3cUIAAP6D0.jpg",
      "id_str" : "765631278888525824",
      "id" : 765631278888525824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqARl3cUIAAP6D0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/wH491Qvcxm"
    } ],
    "hashtags" : [ {
      "text" : "FairChancePledge",
      "indices" : [ 12, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/VSODJrpC5j",
      "expanded_url" : "http:\/\/wh.gov\/fairchancepledge",
      "display_url" : "wh.gov\/fairchancepled\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765638825703903232",
  "text" : "Joining the #FairChancePledge means offering a future to Americans with a criminal record \u2192 https:\/\/t.co\/VSODJrpC5j https:\/\/t.co\/wH491Qvcxm",
  "id" : 765638825703903232,
  "created_at" : "2016-08-16 19:58:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/765631087867367426\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/O8c9ElYkWw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqARPRbVUAAs1VU.jpg",
      "id_str" : "765630890726739968",
      "id" : 765630890726739968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqARPRbVUAAs1VU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/O8c9ElYkWw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765631087867367426",
  "text" : "Good news: 185 businesses answered @POTUS's call to give Americans with a criminal record a fair chance at a future. https:\/\/t.co\/O8c9ElYkWw",
  "id" : 765631087867367426,
  "created_at" : "2016-08-16 19:27:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 89, 105 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765627339694673920",
  "text" : "RT @HHSGov: What are the signs and symptoms of the #Zika virus? How severe is the virus? @Surgeon_General has answers.\nhttps:\/\/t.co\/Uo74H6y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Surgeon General",
        "screen_name" : "Surgeon_General",
        "indices" : [ 77, 93 ],
        "id_str" : "455024343",
        "id" : 455024343
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 39, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/Uo74H6yy9L",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/2e449a65-0774-4b27-991a-ef1e3c63b691",
        "display_url" : "amp.twimg.com\/v\/2e449a65-077\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765617311784931328",
    "text" : "What are the signs and symptoms of the #Zika virus? How severe is the virus? @Surgeon_General has answers.\nhttps:\/\/t.co\/Uo74H6yy9L",
    "id" : 765617311784931328,
    "created_at" : "2016-08-16 18:32:46 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 765627339694673920,
  "created_at" : "2016-08-16 19:12:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/765618149576146944\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/JFvIc9LZ5V",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CqABGmfXEAE1hid.jpg",
      "id_str" : "765613149575909377",
      "id" : 765613149575909377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CqABGmfXEAE1hid.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JFvIc9LZ5V"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/WoV9454Y4B",
      "expanded_url" : "http:\/\/go.wh.gov\/dUZfK3",
      "display_url" : "go.wh.gov\/dUZfK3"
    } ]
  },
  "geo" : { },
  "id_str" : "765618149576146944",
  "text" : "Here's how today's new actions will spur innovation and promote more efficient vehicles: https:\/\/t.co\/WoV9454Y4B https:\/\/t.co\/JFvIc9LZ5V",
  "id" : 765618149576146944,
  "created_at" : "2016-08-16 18:36:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 75, 88 ]
    }, {
      "text" : "SuperTruck",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/l9DMOs74fs",
      "expanded_url" : "http:\/\/energy.gov\/articles\/energy-department-announces-137-million-investment-commercial-and-passenger-vehicle",
      "display_url" : "energy.gov\/articles\/energ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765614048452997127",
  "text" : "RT @ErnestMoniz: Doubling efficiency of big rigs like this is a key way to #ActOnClimate \u27A4 https:\/\/t.co\/l9DMOs74fs #SuperTruck https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/765611879175782400\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/vxwgp5eygp",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cp_9Uu_WAAAl3oL.jpg",
        "id_str" : "765608994329198592",
        "id" : 765608994329198592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cp_9Uu_WAAAl3oL.jpg",
        "sizes" : [ {
          "h" : 248,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vxwgp5eygp"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 58, 71 ]
      }, {
        "text" : "SuperTruck",
        "indices" : [ 98, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/l9DMOs74fs",
        "expanded_url" : "http:\/\/energy.gov\/articles\/energy-department-announces-137-million-investment-commercial-and-passenger-vehicle",
        "display_url" : "energy.gov\/articles\/energ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765611879175782400",
    "text" : "Doubling efficiency of big rigs like this is a key way to #ActOnClimate \u27A4 https:\/\/t.co\/l9DMOs74fs #SuperTruck https:\/\/t.co\/vxwgp5eygp",
    "id" : 765611879175782400,
    "created_at" : "2016-08-16 18:11:11 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 765614048452997127,
  "created_at" : "2016-08-16 18:19:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 34, 48 ],
      "id_str" : "43920155",
      "id" : 43920155
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 54, 58 ],
      "id_str" : "14615871",
      "id" : 14615871
    }, {
      "name" : "NHTSA",
      "screen_name" : "NHTSAgov",
      "indices" : [ 65, 74 ],
      "id_str" : "49706919",
      "id" : 49706919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765610348443500544",
  "text" : "RT @GinaEPA: Proud to announce w\/ @SecretaryFoxx that @EPA &amp; @NHTSAgov finalized standards for medium &amp; heavy-duty vehicles! https:\/\/t.co\/h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anthony Foxx",
        "screen_name" : "SecretaryFoxx",
        "indices" : [ 21, 35 ],
        "id_str" : "43920155",
        "id" : 43920155
      }, {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 41, 45 ],
        "id_str" : "14615871",
        "id" : 14615871
      }, {
        "name" : "NHTSA",
        "screen_name" : "NHTSAgov",
        "indices" : [ 52, 61 ],
        "id_str" : "49706919",
        "id" : 49706919
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/hkAiRIJ2rr",
        "expanded_url" : "https:\/\/www.epa.gov\/newsreleases\/epa-and-dot-finalize-greenhouse-gas-and-fuel-efficiency-standards-heavy-duty-trucks-0",
        "display_url" : "epa.gov\/newsreleases\/e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765587314349334528",
    "text" : "Proud to announce w\/ @SecretaryFoxx that @EPA &amp; @NHTSAgov finalized standards for medium &amp; heavy-duty vehicles! https:\/\/t.co\/hkAiRIJ2rr",
    "id" : 765587314349334528,
    "created_at" : "2016-08-16 16:33:34 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 765610348443500544,
  "created_at" : "2016-08-16 18:05:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765603923042369536",
  "text" : "RT @FactsOnClimate: FACT: In the first 6 months of 2016, carbon pollution from the U.S. energy sector has hit its lowest level in 25 yrs ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/765602851397701632\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/SqjMP0hiT9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp_3qfrUIAIJl9x.jpg",
        "id_str" : "765602771106013186",
        "id" : 765602771106013186,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp_3qfrUIAIJl9x.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/SqjMP0hiT9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765602851397701632",
    "text" : "FACT: In the first 6 months of 2016, carbon pollution from the U.S. energy sector has hit its lowest level in 25 yrs https:\/\/t.co\/SqjMP0hiT9",
    "id" : 765602851397701632,
    "created_at" : "2016-08-16 17:35:18 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 765603923042369536,
  "created_at" : "2016-08-16 17:39:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/765596205007138816\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/1OtuMi7gnx",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cp_w77NUkAEbKQ7.jpg",
      "id_str" : "765595373972787201",
      "id" : 765595373972787201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cp_w77NUkAEbKQ7.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1OtuMi7gnx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/WoV945mztb",
      "expanded_url" : "http:\/\/go.wh.gov\/dUZfK3",
      "display_url" : "go.wh.gov\/dUZfK3"
    } ]
  },
  "geo" : { },
  "id_str" : "765596205007138816",
  "text" : "Big news: We just took new steps to cut carbon pollution and save consumers money \u2192\n https:\/\/t.co\/WoV945mztb https:\/\/t.co\/1OtuMi7gnx",
  "id" : 765596205007138816,
  "created_at" : "2016-08-16 17:08:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EPAair",
      "screen_name" : "EPAair",
      "indices" : [ 3, 10 ],
      "id_str" : "753692879499976705",
      "id" : 753692879499976705
    }, {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 19, 27 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 32, 46 ],
      "id_str" : "43920155",
      "id" : 43920155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765589816603992064",
  "text" : "RT @EPAair: Today, @GinaEPA and @SecretaryFoxx jointly finalized greenhouse gas standards for medium and heavy duty vehicles: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina McCarthy",
        "screen_name" : "GinaEPA",
        "indices" : [ 7, 15 ],
        "id_str" : "1530850933",
        "id" : 1530850933
      }, {
        "name" : "Anthony Foxx",
        "screen_name" : "SecretaryFoxx",
        "indices" : [ 20, 34 ],
        "id_str" : "43920155",
        "id" : 43920155
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EPAair\/status\/765580258384965633\/video\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/6mSqLaTlcY",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/765580209886203904\/pu\/img\/cHa-9eGpEBxZTMQm.jpg",
        "id_str" : "765580209886203904",
        "id" : 765580209886203904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/765580209886203904\/pu\/img\/cHa-9eGpEBxZTMQm.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6mSqLaTlcY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765580258384965633",
    "text" : "Today, @GinaEPA and @SecretaryFoxx jointly finalized greenhouse gas standards for medium and heavy duty vehicles: https:\/\/t.co\/6mSqLaTlcY",
    "id" : 765580258384965633,
    "created_at" : "2016-08-16 16:05:32 +0000",
    "user" : {
      "name" : "EPAair",
      "screen_name" : "EPAair",
      "protected" : false,
      "id_str" : "753692879499976705",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753694773693845505\/rESCYs40_normal.jpg",
      "id" : 753692879499976705,
      "verified" : true
    }
  },
  "id" : 765589816603992064,
  "created_at" : "2016-08-16 16:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army Reserve",
      "screen_name" : "USArmyReserve",
      "indices" : [ 3, 17 ],
      "id_str" : "21213276",
      "id" : 21213276
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 90, 98 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "armyolympian",
      "indices" : [ 42, 55 ]
    }, {
      "text" : "usarmyreserve",
      "indices" : [ 71, 85 ]
    }, {
      "text" : "JumpSamJump",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765566118606012416",
  "text" : "RT @USArmyReserve: Earning Bronze. A real #armyolympian serving in the #usarmyreserve and @TeamUSA athlete! #JumpSamJump https:\/\/t.co\/kPjRd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Olympic Team",
        "screen_name" : "TeamUSA",
        "indices" : [ 71, 79 ],
        "id_str" : "21870081",
        "id" : 21870081
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USArmyReserve\/status\/765396537593716736\/video\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/kPjRdxLSUZ",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/765396449551147008\/pu\/img\/SXz7P4DCoagmqjxp.jpg",
        "id_str" : "765396449551147008",
        "id" : 765396449551147008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/765396449551147008\/pu\/img\/SXz7P4DCoagmqjxp.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kPjRdxLSUZ"
      } ],
      "hashtags" : [ {
        "text" : "armyolympian",
        "indices" : [ 23, 36 ]
      }, {
        "text" : "usarmyreserve",
        "indices" : [ 52, 66 ]
      }, {
        "text" : "JumpSamJump",
        "indices" : [ 89, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765396537593716736",
    "text" : "Earning Bronze. A real #armyolympian serving in the #usarmyreserve and @TeamUSA athlete! #JumpSamJump https:\/\/t.co\/kPjRdxLSUZ",
    "id" : 765396537593716736,
    "created_at" : "2016-08-16 03:55:29 +0000",
    "user" : {
      "name" : "U.S. Army Reserve",
      "screen_name" : "USArmyReserve",
      "protected" : false,
      "id_str" : "21213276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2239301903\/Minuteman_Logo_normal.jpg",
      "id" : 21213276,
      "verified" : true
    }
  },
  "id" : 765566118606012416,
  "created_at" : "2016-08-16 15:09:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnviroEd",
      "indices" : [ 89, 98 ]
    }, {
      "text" : "PEYA",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/M54KOxgzU5",
      "expanded_url" : "https:\/\/www.epa.gov\/newsreleases\/white-house-epa-honor-environmental-educators-and-student-award-winners",
      "display_url" : "epa.gov\/newsreleases\/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765560924631658497",
  "text" : "RT @EPA: A vertical greenhouse, a semiconductor, aquaponics &amp; more - congrats to our #EnviroEd award winners! https:\/\/t.co\/M54KOxgzU5 #PEYA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EnviroEd",
        "indices" : [ 80, 89 ]
      }, {
        "text" : "PEYA",
        "indices" : [ 129, 134 ]
      }, {
        "text" : "PIAEE",
        "indices" : [ 135, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/M54KOxgzU5",
        "expanded_url" : "https:\/\/www.epa.gov\/newsreleases\/white-house-epa-honor-environmental-educators-and-student-award-winners",
        "display_url" : "epa.gov\/newsreleases\/w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765534985424175104",
    "text" : "A vertical greenhouse, a semiconductor, aquaponics &amp; more - congrats to our #EnviroEd award winners! https:\/\/t.co\/M54KOxgzU5 #PEYA #PIAEE",
    "id" : 765534985424175104,
    "created_at" : "2016-08-16 13:05:38 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 765560924631658497,
  "created_at" : "2016-08-16 14:48:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NWS",
      "screen_name" : "NWS",
      "indices" : [ 3, 7 ],
      "id_str" : "454313925",
      "id" : 454313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765236601802797056",
  "text" : "RT @NWS: Is your area threatened by flash flooding today?Flooded roadways should be taken seriously.\nTURN AROUND,DON'T DROWN! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NWS\/status\/765157302613618688\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/GSQdcxsuGC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp5igeVUMAAJDOL.jpg",
        "id_str" : "765157296737366016",
        "id" : 765157296737366016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp5igeVUMAAJDOL.jpg",
        "sizes" : [ {
          "h" : 451,
          "resize" : "fit",
          "w" : 433
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 433
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 433
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 433
        } ],
        "display_url" : "pic.twitter.com\/GSQdcxsuGC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "765157302613618688",
    "text" : "Is your area threatened by flash flooding today?Flooded roadways should be taken seriously.\nTURN AROUND,DON'T DROWN! https:\/\/t.co\/GSQdcxsuGC",
    "id" : 765157302613618688,
    "created_at" : "2016-08-15 12:04:51 +0000",
    "user" : {
      "name" : "NWS",
      "screen_name" : "NWS",
      "protected" : false,
      "id_str" : "454313925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795652515496792065\/UugYndR1_normal.jpg",
      "id" : 454313925,
      "verified" : true
    }
  },
  "id" : 765236601802797056,
  "created_at" : "2016-08-15 17:19:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAflood",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/mSsI4eEQev",
      "expanded_url" : "http:\/\/disasterassistance.gov",
      "display_url" : "disasterassistance.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "765230152758550528",
  "text" : "RT @fema: If you were affected by the #LAflood, apply for assistance at https:\/\/t.co\/mSsI4eEQev or call 800-621-3362. https:\/\/t.co\/PdXAvF2O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fema\/status\/765191577731997696\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/PdXAvF2Ohc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp6BdPXWgAAtmYx.png",
        "id_str" : "765191326040227840",
        "id" : 765191326040227840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp6BdPXWgAAtmYx.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1091
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 618
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1862
        }, {
          "h" : 2062,
          "resize" : "fit",
          "w" : 1875
        } ],
        "display_url" : "pic.twitter.com\/PdXAvF2Ohc"
      } ],
      "hashtags" : [ {
        "text" : "LAflood",
        "indices" : [ 28, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/mSsI4eEQev",
        "expanded_url" : "http:\/\/disasterassistance.gov",
        "display_url" : "disasterassistance.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "765191577731997696",
    "text" : "If you were affected by the #LAflood, apply for assistance at https:\/\/t.co\/mSsI4eEQev or call 800-621-3362. https:\/\/t.co\/PdXAvF2Ohc",
    "id" : 765191577731997696,
    "created_at" : "2016-08-15 14:21:03 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 765230152758550528,
  "created_at" : "2016-08-15 16:54:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "indices" : [ 3, 10 ],
      "id_str" : "2151620534",
      "id" : 2151620534
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/Dmt091ZiNm",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/12\/presidents-summer-reading-list",
      "display_url" : "whitehouse.gov\/blog\/2016\/08\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "765202424554553344",
  "text" : "RT @Hill44: Putting together your beach reading list? Here are @POTUS' picks: https:\/\/t.co\/Dmt091ZiNm.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 51, 57 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/Dmt091ZiNm",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/12\/presidents-summer-reading-list",
        "display_url" : "whitehouse.gov\/blog\/2016\/08\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "765197156718219264",
    "text" : "Putting together your beach reading list? Here are @POTUS' picks: https:\/\/t.co\/Dmt091ZiNm.",
    "id" : 765197156718219264,
    "created_at" : "2016-08-15 14:43:13 +0000",
    "user" : {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "protected" : false,
      "id_str" : "2151620534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658658579142959104\/85LEK24P_normal.jpg",
      "id" : 2151620534,
      "verified" : true
    }
  },
  "id" : 765202424554553344,
  "created_at" : "2016-08-15 15:04:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Gov John Bel Edwards",
      "screen_name" : "LouisianaGov",
      "indices" : [ 40, 53 ],
      "id_str" : "166374616",
      "id" : 166374616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "765011711329828864",
  "text" : "RT @JFriedman44: Today, @POTUS spoke to @LouisianaGov Edwards and ordered federal aid for flood response and recovery efforts:  https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Gov John Bel Edwards",
        "screen_name" : "LouisianaGov",
        "indices" : [ 23, 36 ],
        "id_str" : "166374616",
        "id" : 166374616
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/TaC7kJfiqy",
        "expanded_url" : "http:\/\/go.wh.gov\/xsrwG4",
        "display_url" : "go.wh.gov\/xsrwG4"
      } ]
    },
    "geo" : { },
    "id_str" : "765011641507471360",
    "text" : "Today, @POTUS spoke to @LouisianaGov Edwards and ordered federal aid for flood response and recovery efforts:  https:\/\/t.co\/TaC7kJfiqy",
    "id" : 765011641507471360,
    "created_at" : "2016-08-15 02:26:03 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 765011711329828864,
  "created_at" : "2016-08-15 02:26:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 48, 56 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/764982598347071488\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/0Y0k9sPnTq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp3DhU1UIAARICI.jpg",
      "id_str" : "764982489018277888",
      "id" : 764982489018277888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp3DhU1UIAARICI.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/0Y0k9sPnTq"
    } ],
    "hashtags" : [ {
      "text" : "Rio2016",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/ZNDz6h7JsA",
      "expanded_url" : "http:\/\/go.wh.gov\/qYFSxY",
      "display_url" : "go.wh.gov\/qYFSxY"
    } ]
  },
  "geo" : { },
  "id_str" : "764982598347071488",
  "text" : "\u201CThere\u2019s nothing quite like the pride of seeing @TeamUSA.\u201D Behind the scenes of #Rio2016: https:\/\/t.co\/ZNDz6h7JsA https:\/\/t.co\/0Y0k9sPnTq",
  "id" : 764982598347071488,
  "created_at" : "2016-08-15 00:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764962086489251840",
  "text" : "RT @POTUS: Final win for Phelps. World record for Ledecky. 3 #1 finishes for Biles. That's how #TeamUSA gets America to 1000 golds-way to m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764961309767131136",
    "text" : "Final win for Phelps. World record for Ledecky. 3 #1 finishes for Biles. That's how #TeamUSA gets America to 1000 golds-way to make history.",
    "id" : 764961309767131136,
    "created_at" : "2016-08-14 23:06:03 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 764962086489251840,
  "created_at" : "2016-08-14 23:09:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/jCMTjXEnSQ",
      "expanded_url" : "http:\/\/snpy.tv\/2b9uT2E",
      "display_url" : "snpy.tv\/2b9uT2E"
    } ]
  },
  "geo" : { },
  "id_str" : "764937205869453312",
  "text" : "\"Together, we can leave a better, cleaner, safer future for our children.\" \u2014@POTUS #ActOnClimate: https:\/\/t.co\/jCMTjXEnSQ",
  "id" : 764937205869453312,
  "created_at" : "2016-08-14 21:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/764906140257837056\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pf8l9FPOzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cp19Oy7UkAA0Vg9.jpg",
      "id_str" : "764905204865077248",
      "id" : 764905204865077248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cp19Oy7UkAA0Vg9.jpg",
      "sizes" : [ {
        "h" : 1682,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 1682,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1141
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/pf8l9FPOzR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/7O19ngIayo",
      "expanded_url" : "http:\/\/go.wh.gov\/LilyLetter",
      "display_url" : "go.wh.gov\/LilyLetter"
    } ]
  },
  "geo" : { },
  "id_str" : "764906140257837056",
  "text" : "\"My dad is in the Air Force and that inspired me to have my back up job be president\" \u2014Lily: https:\/\/t.co\/7O19ngIayo https:\/\/t.co\/pf8l9FPOzR",
  "id" : 764906140257837056,
  "created_at" : "2016-08-14 19:26:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jCMTjXEnSQ",
      "expanded_url" : "http:\/\/snpy.tv\/2b9uT2E",
      "display_url" : "snpy.tv\/2b9uT2E"
    } ]
  },
  "geo" : { },
  "id_str" : "764888152263622656",
  "text" : "High standards for fuel efficiency are working:\n\n100 new standard-ready vehicles\nA boom in electric vehicles\n\nWatch: https:\/\/t.co\/jCMTjXEnSQ",
  "id" : 764888152263622656,
  "created_at" : "2016-08-14 18:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/jCMTjXVZhq",
      "expanded_url" : "http:\/\/snpy.tv\/2b9uT2E",
      "display_url" : "snpy.tv\/2b9uT2E"
    } ]
  },
  "geo" : { },
  "id_str" : "764855671753961472",
  "text" : "\"We'll take steps...to achieve 50 percent clean power across North America by 2025.\" \u2014@POTUS #ActOnClimate: https:\/\/t.co\/jCMTjXVZhq",
  "id" : 764855671753961472,
  "created_at" : "2016-08-14 16:06:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Phelps",
      "screen_name" : "MichaelPhelps",
      "indices" : [ 51, 65 ],
      "id_str" : "225539878",
      "id" : 225539878
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 107, 115 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764653644138450945",
  "text" : "Hard work, focus, and a dream\u2014that\u2019s the spirit of @MichaelPhelps. Tonight, we congratulate him and all of @TeamUSA on making history.",
  "id" : 764653644138450945,
  "created_at" : "2016-08-14 02:43:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jCMTjXEnSQ",
      "expanded_url" : "http:\/\/snpy.tv\/2b9uT2E",
      "display_url" : "snpy.tv\/2b9uT2E"
    } ]
  },
  "geo" : { },
  "id_str" : "764573523713011713",
  "text" : "\"We've set the first-ever national standards limiting the amount of carbon pollution power plants\" can emit \u2014@POTUS: https:\/\/t.co\/jCMTjXEnSQ",
  "id" : 764573523713011713,
  "created_at" : "2016-08-13 21:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/jCMTjXEnSQ",
      "expanded_url" : "http:\/\/snpy.tv\/2b9uT2E",
      "display_url" : "snpy.tv\/2b9uT2E"
    } ]
  },
  "geo" : { },
  "id_str" : "764540929642332160",
  "text" : "\"We've invested in energy efficiency...saving families money on their energy bills.\" \u2014@POTUS #ActOnClimate \u2192 https:\/\/t.co\/jCMTjXEnSQ",
  "id" : 764540929642332160,
  "created_at" : "2016-08-13 19:15:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/jCMTjXEnSQ",
      "expanded_url" : "http:\/\/snpy.tv\/2b9uT2E",
      "display_url" : "snpy.tv\/2b9uT2E"
    } ]
  },
  "geo" : { },
  "id_str" : "764514565048508417",
  "text" : "2016 is on pace to be the hottest year on record. Here\u2019s how @POTUS is acting to combat climate change: https:\/\/t.co\/jCMTjXEnSQ",
  "id" : 764514565048508417,
  "created_at" : "2016-08-13 17:30:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 55, 63 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rio2016",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764503485329137664",
  "text" : "RT @FLOTUS: Congrats Michelle Carter AKA Shot Diva! Go @TeamUSA Track &amp; Field! #Rio2016 -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Olympic Team",
        "screen_name" : "TeamUSA",
        "indices" : [ 43, 51 ],
        "id_str" : "21870081",
        "id" : 21870081
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Rio2016",
        "indices" : [ 71, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "764491186191081473",
    "text" : "Congrats Michelle Carter AKA Shot Diva! Go @TeamUSA Track &amp; Field! #Rio2016 -mo",
    "id" : 764491186191081473,
    "created_at" : "2016-08-13 15:57:57 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 764503485329137664,
  "created_at" : "2016-08-13 16:46:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764496112300331008",
  "text" : "RT @JFriedman44: Since @POTUS took office:\n\nWind power: \u2191 3x\nSolar power: \u2191 30x\nCarbon pollution from energy sector: \u2193 to 25 year low https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/4YgONvxVh8",
        "expanded_url" : "http:\/\/snpy.tv\/2b9uT2E",
        "display_url" : "snpy.tv\/2b9uT2E"
      } ]
    },
    "geo" : { },
    "id_str" : "764456346964127744",
    "text" : "Since @POTUS took office:\n\nWind power: \u2191 3x\nSolar power: \u2191 30x\nCarbon pollution from energy sector: \u2193 to 25 year low https:\/\/t.co\/4YgONvxVh8",
    "id" : 764456346964127744,
    "created_at" : "2016-08-13 13:39:30 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 764496112300331008,
  "created_at" : "2016-08-13 16:17:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/jCMTjXEnSQ",
      "expanded_url" : "http:\/\/snpy.tv\/2b9uT2E",
      "display_url" : "snpy.tv\/2b9uT2E"
    } ]
  },
  "geo" : { },
  "id_str" : "764473554431725568",
  "text" : "We've only got one planet. Watch @POTUS share the progress we've made to protect it. #ActOnClimate https:\/\/t.co\/jCMTjXEnSQ",
  "id" : 764473554431725568,
  "created_at" : "2016-08-13 14:47:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/QutByoHKET",
      "expanded_url" : "http:\/\/go.wh.gov\/Pct9Xo",
      "display_url" : "go.wh.gov\/Pct9Xo"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/fMu4mUVnFv",
      "expanded_url" : "http:\/\/snpy.tv\/2blT2Rn",
      "display_url" : "snpy.tv\/2blT2Rn"
    } ]
  },
  "geo" : { },
  "id_str" : "764214165330206721",
  "text" : "\"Orient yourself towards having an impact and making a difference.\" \u2014@POTUS offers advice: https:\/\/t.co\/QutByoHKET https:\/\/t.co\/fMu4mUVnFv",
  "id" : 764214165330206721,
  "created_at" : "2016-08-12 21:37:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/3AXQtz4cGz",
      "expanded_url" : "http:\/\/go.wh.gov\/VPSummer2016",
      "display_url" : "go.wh.gov\/VPSummer2016"
    } ]
  },
  "geo" : { },
  "id_str" : "764202885383122945",
  "text" : "RT @VP: From Jill and me, here is the soundtrack to our summer days and nights, past and present. https:\/\/t.co\/3AXQtz4cGz https:\/\/t.co\/e2zp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/764192794361540608\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/e2zpQO684p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpr1PRGUkAABw6v.jpg",
        "id_str" : "764192729429479424",
        "id" : 764192729429479424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpr1PRGUkAABw6v.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/e2zpQO684p"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/3AXQtz4cGz",
        "expanded_url" : "http:\/\/go.wh.gov\/VPSummer2016",
        "display_url" : "go.wh.gov\/VPSummer2016"
      } ]
    },
    "geo" : { },
    "id_str" : "764192794361540608",
    "text" : "From Jill and me, here is the soundtrack to our summer days and nights, past and present. https:\/\/t.co\/3AXQtz4cGz https:\/\/t.co\/e2zpQO684p",
    "id" : 764192794361540608,
    "created_at" : "2016-08-12 20:12:14 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 764202885383122945,
  "created_at" : "2016-08-12 20:52:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/764192292672376832\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/PHNYfxijp9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CprwfX6XEAAz67y.jpg",
      "id_str" : "764187508578127872",
      "id" : 764187508578127872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CprwfX6XEAAz67y.jpg",
      "sizes" : [ {
        "h" : 1682,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 1682,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1141
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/PHNYfxijp9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/7O19ngIayo",
      "expanded_url" : "http:\/\/go.wh.gov\/LilyLetter",
      "display_url" : "go.wh.gov\/LilyLetter"
    } ]
  },
  "geo" : { },
  "id_str" : "764192292672376832",
  "text" : "Lily is 8 years old. Her dad serves in the Air Force. She wrote to @POTUS with some advice. https:\/\/t.co\/7O19ngIayo https:\/\/t.co\/PHNYfxijp9",
  "id" : 764192292672376832,
  "created_at" : "2016-08-12 20:10:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerReadingList",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EAjpzTpPmr",
      "expanded_url" : "http:\/\/go.wh.gov\/ut58mm",
      "display_url" : "go.wh.gov\/ut58mm"
    } ]
  },
  "geo" : { },
  "id_str" : "764178660072968192",
  "text" : "Pulitzer Prize-winning surf memoir\u2713\nPsychological thriller\u2713\nSci-fi novel\u2713\n \nHere's @POTUS's 2016 #SummerReadingList: https:\/\/t.co\/EAjpzTpPmr",
  "id" : 764178660072968192,
  "created_at" : "2016-08-12 19:16:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Ashe",
      "screen_name" : "DirectorDanAshe",
      "indices" : [ 3, 19 ],
      "id_str" : "490859038",
      "id" : 490859038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldElephantDay",
      "indices" : [ 24, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Jsj4XOp4UA",
      "expanded_url" : "http:\/\/huff.to\/2bm7rO2",
      "display_url" : "huff.to\/2bm7rO2"
    } ]
  },
  "geo" : { },
  "id_str" : "764175962292494336",
  "text" : "RT @DirectorDanAshe: On #WorldElephantDay, lets celebrate these amazing animals, &amp; fight to secure their future! https:\/\/t.co\/Jsj4XOp4UA ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DirectorDanAshe\/status\/764160145022709760\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/Q7coTHrToC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CprXeTNXEAAAkKs.jpg",
        "id_str" : "764160002345078784",
        "id" : 764160002345078784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CprXeTNXEAAAkKs.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2592,
          "resize" : "fit",
          "w" : 3888
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Q7coTHrToC"
      } ],
      "hashtags" : [ {
        "text" : "WorldElephantDay",
        "indices" : [ 3, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/Jsj4XOp4UA",
        "expanded_url" : "http:\/\/huff.to\/2bm7rO2",
        "display_url" : "huff.to\/2bm7rO2"
      } ]
    },
    "geo" : { },
    "id_str" : "764160145022709760",
    "text" : "On #WorldElephantDay, lets celebrate these amazing animals, &amp; fight to secure their future! https:\/\/t.co\/Jsj4XOp4UA https:\/\/t.co\/Q7coTHrToC",
    "id" : 764160145022709760,
    "created_at" : "2016-08-12 18:02:30 +0000",
    "user" : {
      "name" : "Dan Ashe",
      "screen_name" : "DirectorDanAshe",
      "protected" : false,
      "id_str" : "490859038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1823713517\/FotoFlexer_Photo_normal.jpg",
      "id" : 490859038,
      "verified" : true
    }
  },
  "id" : 764175962292494336,
  "created_at" : "2016-08-12 19:05:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/764173525636841473\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/ghinlLbTHj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CprjpYTUsAAgZLw.jpg",
      "id_str" : "764173386830360576",
      "id" : 764173386830360576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CprjpYTUsAAgZLw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ghinlLbTHj"
    } ],
    "hashtags" : [ {
      "text" : "SummerReadingList",
      "indices" : [ 33, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/EAjpzTHqL1",
      "expanded_url" : "http:\/\/go.wh.gov\/ut58mm",
      "display_url" : "go.wh.gov\/ut58mm"
    } ]
  },
  "geo" : { },
  "id_str" : "764173525636841473",
  "text" : ".@POTUS just shared his official #SummerReadingList\u2014check it out \u2192 https:\/\/t.co\/EAjpzTHqL1 https:\/\/t.co\/ghinlLbTHj",
  "id" : 764173525636841473,
  "created_at" : "2016-08-12 18:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/sVKStPoW4P",
      "expanded_url" : "https:\/\/twitter.com\/Simone_Biles\/status\/764153195048398849",
      "display_url" : "twitter.com\/Simone_Biles\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764169528066531328",
  "text" : "RT @FLOTUS: You've made us proud! \uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/sVKStPoW4P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/sVKStPoW4P",
        "expanded_url" : "https:\/\/twitter.com\/Simone_Biles\/status\/764153195048398849",
        "display_url" : "twitter.com\/Simone_Biles\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764169263716282368",
    "text" : "You've made us proud! \uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/sVKStPoW4P",
    "id" : 764169263716282368,
    "created_at" : "2016-08-12 18:38:44 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 764169528066531328,
  "created_at" : "2016-08-12 18:39:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/764158239089029120\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/a5TOXPn28e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CprVufSVYAAkfWr.jpg",
      "id_str" : "764158081441816576",
      "id" : 764158081441816576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CprVufSVYAAkfWr.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/a5TOXPn28e"
    } ],
    "hashtags" : [ {
      "text" : "YouthDay",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/1c3jrHRLy2",
      "expanded_url" : "http:\/\/go.wh.gov\/o2LeNV",
      "display_url" : "go.wh.gov\/o2LeNV"
    } ]
  },
  "geo" : { },
  "id_str" : "764158239089029120",
  "text" : "Young people have the power and potential to change the world. Happy #YouthDay! https:\/\/t.co\/1c3jrHRLy2 https:\/\/t.co\/a5TOXPn28e",
  "id" : 764158239089029120,
  "created_at" : "2016-08-12 17:54:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/F028D1Mrp5",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/asked-and-answered-this-country-needs-more-spunk-3c12647cd791#.25iofqg58",
      "display_url" : "medium.com\/@WhiteHouse\/as\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "764150378082566144",
  "text" : "RT @Simas44: Love this letter from Lily (8 year old) to @POTUS. She has a great backup plan!\n\nhttps:\/\/t.co\/F028D1Mrp5 https:\/\/t.co\/YDeNun9s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 43, 49 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/764143441341059072\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/YDeNun9s1F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CprICZ7VYAEYQUa.jpg",
        "id_str" : "764143030437765121",
        "id" : 764143030437765121,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CprICZ7VYAEYQUa.jpg",
        "sizes" : [ {
          "h" : 146,
          "resize" : "fit",
          "w" : 734
        }, {
          "h" : 135,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 146,
          "resize" : "fit",
          "w" : 734
        }, {
          "h" : 146,
          "resize" : "fit",
          "w" : 734
        }, {
          "h" : 146,
          "resize" : "crop",
          "w" : 146
        } ],
        "display_url" : "pic.twitter.com\/YDeNun9s1F"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/F028D1Mrp5",
        "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/asked-and-answered-this-country-needs-more-spunk-3c12647cd791#.25iofqg58",
        "display_url" : "medium.com\/@WhiteHouse\/as\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "764143441341059072",
    "text" : "Love this letter from Lily (8 year old) to @POTUS. She has a great backup plan!\n\nhttps:\/\/t.co\/F028D1Mrp5 https:\/\/t.co\/YDeNun9s1F",
    "id" : 764143441341059072,
    "created_at" : "2016-08-12 16:56:08 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 764150378082566144,
  "created_at" : "2016-08-12 17:23:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/764142643584512000\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/TgUdWYqTOA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CprHWLHXYAQb8bo.jpg",
      "id_str" : "764142270547451908",
      "id" : 764142270547451908,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CprHWLHXYAQb8bo.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 647
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1141
      }, {
        "h" : 2139,
        "resize" : "fit",
        "w" : 2034
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1947
      } ],
      "display_url" : "pic.twitter.com\/TgUdWYqTOA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/7O19ngIayo",
      "expanded_url" : "http:\/\/go.wh.gov\/LilyLetter",
      "display_url" : "go.wh.gov\/LilyLetter"
    } ]
  },
  "geo" : { },
  "id_str" : "764142643584512000",
  "text" : "\"This country needs more spunk.\" \u2014Lily, 8 years old. Read her letter to @POTUS: https:\/\/t.co\/7O19ngIayo https:\/\/t.co\/TgUdWYqTOA",
  "id" : 764142643584512000,
  "created_at" : "2016-08-12 16:52:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Fanning",
      "screen_name" : "SECARMY",
      "indices" : [ 3, 11 ],
      "id_str" : "4377108801",
      "id" : 4377108801
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 69, 76 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnergyExchange",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "764105446021935104",
  "text" : "RT @SECARMY: Thanks to @POTUS's challenge, I just announced that the @USArmy has partnered to hit $1B to date. #EnergyExchange https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 56, 63 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SECARMY\/status\/763764700064673792\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/7fYsxSdMHQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cplv8GYWEAAJk1j.jpg",
        "id_str" : "763764690111565824",
        "id" : 763764690111565824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cplv8GYWEAAJk1j.jpg",
        "sizes" : [ {
          "h" : 431,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 726,
          "resize" : "fit",
          "w" : 1145
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 726,
          "resize" : "fit",
          "w" : 1145
        }, {
          "h" : 726,
          "resize" : "fit",
          "w" : 1145
        } ],
        "display_url" : "pic.twitter.com\/7fYsxSdMHQ"
      } ],
      "hashtags" : [ {
        "text" : "EnergyExchange",
        "indices" : [ 98, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763764700064673792",
    "text" : "Thanks to @POTUS's challenge, I just announced that the @USArmy has partnered to hit $1B to date. #EnergyExchange https:\/\/t.co\/7fYsxSdMHQ",
    "id" : 763764700064673792,
    "created_at" : "2016-08-11 15:51:09 +0000",
    "user" : {
      "name" : "Eric Fanning",
      "screen_name" : "SECARMY",
      "protected" : false,
      "id_str" : "4377108801",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797613267455610880\/KJSeRgYE_normal.jpg",
      "id" : 4377108801,
      "verified" : true
    }
  },
  "id" : 764105446021935104,
  "created_at" : "2016-08-12 14:25:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corinne Bailey Rae",
      "screen_name" : "CorinneBRae",
      "indices" : [ 3, 15 ],
      "id_str" : "84122625",
      "id" : 84122625
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 76, 84 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/1bYUwKebff",
      "expanded_url" : "http:\/\/spoti.fi\/POTUSNight",
      "display_url" : "spoti.fi\/POTUSNight"
    } ]
  },
  "geo" : { },
  "id_str" : "763795862447284225",
  "text" : "RT @CorinneBRae: What an honor! \"Green Aphrodisiac\" is featured on @POTUS's @Spotify Summer Playlist! \uD83D\uDC9A \uD83D\uDC99 \u2764\uFE0F  https:\/\/t.co\/1bYUwKebff https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 50, 56 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Spotify",
        "screen_name" : "Spotify",
        "indices" : [ 59, 67 ],
        "id_str" : "17230018",
        "id" : 17230018
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/1bYUwKebff",
        "expanded_url" : "http:\/\/spoti.fi\/POTUSNight",
        "display_url" : "spoti.fi\/POTUSNight"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/eZjzBU99R4",
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/763744742072913920",
        "display_url" : "twitter.com\/POTUS\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763790333872214016",
    "text" : "What an honor! \"Green Aphrodisiac\" is featured on @POTUS's @Spotify Summer Playlist! \uD83D\uDC9A \uD83D\uDC99 \u2764\uFE0F  https:\/\/t.co\/1bYUwKebff https:\/\/t.co\/eZjzBU99R4",
    "id" : 763790333872214016,
    "created_at" : "2016-08-11 17:33:00 +0000",
    "user" : {
      "name" : "Corinne Bailey Rae",
      "screen_name" : "CorinneBRae",
      "protected" : false,
      "id_str" : "84122625",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703113014694678528\/XPwq0IWW_normal.jpg",
      "id" : 84122625,
      "verified" : true
    }
  },
  "id" : 763795862447284225,
  "created_at" : "2016-08-11 17:54:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billie Holiday",
      "screen_name" : "BillieHolidayHQ",
      "indices" : [ 3, 19 ],
      "id_str" : "1534597442",
      "id" : 1534597442
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LadyDay",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/iexix5Fgev",
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/763744742072913920",
      "display_url" : "twitter.com\/POTUS\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763793895842914304",
  "text" : "RT @BillieHolidayHQ: #LadyDay makes the @POTUS list two years in a row! https:\/\/t.co\/iexix5Fgev",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 19, 25 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LadyDay",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/iexix5Fgev",
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/763744742072913920",
        "display_url" : "twitter.com\/POTUS\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763793169188126720",
    "text" : "#LadyDay makes the @POTUS list two years in a row! https:\/\/t.co\/iexix5Fgev",
    "id" : 763793169188126720,
    "created_at" : "2016-08-11 17:44:16 +0000",
    "user" : {
      "name" : "Billie Holiday",
      "screen_name" : "BillieHolidayHQ",
      "protected" : false,
      "id_str" : "1534597442",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718126077357350912\/EusCQaob_normal.jpg",
      "id" : 1534597442,
      "verified" : true
    }
  },
  "id" : 763793895842914304,
  "created_at" : "2016-08-11 17:47:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBeachBoys",
      "screen_name" : "TheBeachBoys",
      "indices" : [ 3, 16 ],
      "id_str" : "491715731",
      "id" : 491715731
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerPlaylist",
      "indices" : [ 73, 88 ]
    }, {
      "text" : "GoodVibrations50",
      "indices" : [ 105, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763788117258240000",
  "text" : "RT @TheBeachBoys: We're pickin' up good vibrations today with this great #SummerPlaylist from @POTUS! \uD83C\uDFB6 \n#GoodVibrations50  https:\/\/t.co\/GP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 76, 82 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SummerPlaylist",
        "indices" : [ 55, 70 ]
      }, {
        "text" : "GoodVibrations50",
        "indices" : [ 87, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/GPfQJkr7Kr",
        "expanded_url" : "https:\/\/twitter.com\/potus\/status\/763744742072913920",
        "display_url" : "twitter.com\/potus\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763777456780169216",
    "text" : "We're pickin' up good vibrations today with this great #SummerPlaylist from @POTUS! \uD83C\uDFB6 \n#GoodVibrations50  https:\/\/t.co\/GPfQJkr7Kr",
    "id" : 763777456780169216,
    "created_at" : "2016-08-11 16:41:50 +0000",
    "user" : {
      "name" : "TheBeachBoys",
      "screen_name" : "TheBeachBoys",
      "protected" : false,
      "id_str" : "491715731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733044489627951104\/Zd09jsBh_normal.jpg",
      "id" : 491715731,
      "verified" : true
    }
  },
  "id" : 763788117258240000,
  "created_at" : "2016-08-11 17:24:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jidenna",
      "screen_name" : "Jidenna",
      "indices" : [ 3, 11 ],
      "id_str" : "233755897",
      "id" : 233755897
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "classicman",
      "indices" : [ 87, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763778485269700609",
  "text" : "RT @Jidenna: Wow. Swank you Mr. President. I'd like to imagine that @POTUS suits up to #classicman before boarding Air Force 1 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 55, 61 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "classicman",
        "indices" : [ 74, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/NCVzhVOkAf",
        "expanded_url" : "https:\/\/twitter.com\/potus\/status\/763744742072913920",
        "display_url" : "twitter.com\/potus\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763773104204251136",
    "text" : "Wow. Swank you Mr. President. I'd like to imagine that @POTUS suits up to #classicman before boarding Air Force 1 https:\/\/t.co\/NCVzhVOkAf",
    "id" : 763773104204251136,
    "created_at" : "2016-08-11 16:24:32 +0000",
    "user" : {
      "name" : "Jidenna",
      "screen_name" : "Jidenna",
      "protected" : false,
      "id_str" : "233755897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/756275088874504192\/Vjf9PUof_normal.jpg",
      "id" : 233755897,
      "verified" : true
    }
  },
  "id" : 763778485269700609,
  "created_at" : "2016-08-11 16:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Bareilles",
      "screen_name" : "SaraBareilles",
      "indices" : [ 3, 17 ],
      "id_str" : "6211972",
      "id" : 6211972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "daytime",
      "indices" : [ 40, 48 ]
    }, {
      "text" : "potus",
      "indices" : [ 49, 55 ]
    }, {
      "text" : "goodcompany",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/4Sm64HTYyn",
      "expanded_url" : "https:\/\/twitter.com\/potus\/status\/763744742072913920",
      "display_url" : "twitter.com\/potus\/status\/7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763776977664966656",
  "text" : "RT @SaraBareilles: No big deaaaaaaaaal. #daytime #potus #goodcompany  https:\/\/t.co\/4Sm64HTYyn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "daytime",
        "indices" : [ 21, 29 ]
      }, {
        "text" : "potus",
        "indices" : [ 30, 36 ]
      }, {
        "text" : "goodcompany",
        "indices" : [ 37, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/4Sm64HTYyn",
        "expanded_url" : "https:\/\/twitter.com\/potus\/status\/763744742072913920",
        "display_url" : "twitter.com\/potus\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763757952490676226",
    "text" : "No big deaaaaaaaaal. #daytime #potus #goodcompany  https:\/\/t.co\/4Sm64HTYyn",
    "id" : 763757952490676226,
    "created_at" : "2016-08-11 15:24:20 +0000",
    "user" : {
      "name" : "Sara Bareilles",
      "screen_name" : "SaraBareilles",
      "protected" : false,
      "id_str" : "6211972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741382319467040768\/vHhYTIHR_normal.jpg",
      "id" : 6211972,
      "verified" : true
    }
  },
  "id" : 763776977664966656,
  "created_at" : "2016-08-11 16:39:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wale",
      "screen_name" : "Wale",
      "indices" : [ 3, 8 ],
      "id_str" : "17929027",
      "id" : 17929027
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763762452588789760",
  "text" : "RT @Wale: POTUS knows. # 1 \u201C@POTUS: Been waiting to drop this: summer playlist, the encore. What's everybody listening to? https:\/\/t.co\/thK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 18, 24 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/763744742072913920\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/thKoXMZPHW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cplc_Y9UkAAabrS.jpg",
        "id_str" : "763743855917174784",
        "id" : 763743855917174784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cplc_Y9UkAAabrS.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/thKoXMZPHW"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/763744742072913920\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/thKoXMZPHW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpldBtJVMAE57rj.jpg",
        "id_str" : "763743895695994881",
        "id" : 763743895695994881,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpldBtJVMAE57rj.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/thKoXMZPHW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "763744742072913920",
    "geo" : { },
    "id_str" : "763758677362737154",
    "in_reply_to_user_id" : 1536791610,
    "text" : "POTUS knows. # 1 \u201C@POTUS: Been waiting to drop this: summer playlist, the encore. What's everybody listening to? https:\/\/t.co\/thKoXMZPHW\u201D",
    "id" : 763758677362737154,
    "in_reply_to_status_id" : 763744742072913920,
    "created_at" : "2016-08-11 15:27:13 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Wale",
      "screen_name" : "Wale",
      "protected" : false,
      "id_str" : "17929027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778677671056158721\/Fzco7e-O_normal.jpg",
      "id" : 17929027,
      "verified" : true
    }
  },
  "id" : 763762452588789760,
  "created_at" : "2016-08-11 15:42:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Neville",
      "screen_name" : "aaronneville",
      "indices" : [ 3, 16 ],
      "id_str" : "35089990",
      "id" : 35089990
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "50YearsofTellItLikeItIs",
      "indices" : [ 106, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763755946908672001",
  "text" : "RT @aaronneville: Wow, I'm honored to be included on the official @POTUS Nighttime playlist. Nice choice! #50YearsofTellItLikeItIs https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 48, 54 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "50YearsofTellItLikeItIs",
        "indices" : [ 88, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/YGhnLul8Bg",
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/763744742072913920",
        "display_url" : "twitter.com\/POTUS\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763754367715536896",
    "text" : "Wow, I'm honored to be included on the official @POTUS Nighttime playlist. Nice choice! #50YearsofTellItLikeItIs https:\/\/t.co\/YGhnLul8Bg",
    "id" : 763754367715536896,
    "created_at" : "2016-08-11 15:10:05 +0000",
    "user" : {
      "name" : "Aaron Neville",
      "screen_name" : "aaronneville",
      "protected" : false,
      "id_str" : "35089990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753804132998230027\/ZaCBqNk8_normal.jpg",
      "id" : 35089990,
      "verified" : true
    }
  },
  "id" : 763755946908672001,
  "created_at" : "2016-08-11 15:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 8, 14 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerPlaylist",
      "indices" : [ 55, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/t3MhjavVyg",
      "expanded_url" : "http:\/\/spoti.fi\/POTUSDay",
      "display_url" : "spoti.fi\/POTUSDay"
    }, {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/j3mi0dRlMr",
      "expanded_url" : "http:\/\/spoti.fi\/POTUSNight",
      "display_url" : "spoti.fi\/POTUSNight"
    } ]
  },
  "geo" : { },
  "id_str" : "763754097895886853",
  "text" : "What is @POTUS listening to this summer? Check out his #SummerPlaylist:\n\u2600 https:\/\/t.co\/t3MhjavVyg \n\uD83C\uDF19 https:\/\/t.co\/j3mi0dRlMr",
  "id" : 763754097895886853,
  "created_at" : "2016-08-11 15:09:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 3, 11 ],
      "id_str" : "17230018",
      "id" : 17230018
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Spotify\/status\/763745379405881345\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/3fS7s1LT4g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpleX7SUMAAmhS-.jpg",
      "id_str" : "763745376960524288",
      "id" : 763745376960524288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpleX7SUMAAmhS-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3fS7s1LT4g"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Sc7x0ERrCs",
      "expanded_url" : "http:\/\/spoti.fi\/POTUSDay",
      "display_url" : "spoti.fi\/POTUSDay"
    } ]
  },
  "geo" : { },
  "id_str" : "763749347498614784",
  "text" : "RT @Spotify: Want to feel like @POTUS for the day? Check out his \u2600\uFE0F playlist now: https:\/\/t.co\/Sc7x0ERrCs https:\/\/t.co\/3fS7s1LT4g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 18, 24 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Spotify\/status\/763745379405881345\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/3fS7s1LT4g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpleX7SUMAAmhS-.jpg",
        "id_str" : "763745376960524288",
        "id" : 763745376960524288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpleX7SUMAAmhS-.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/3fS7s1LT4g"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/Sc7x0ERrCs",
        "expanded_url" : "http:\/\/spoti.fi\/POTUSDay",
        "display_url" : "spoti.fi\/POTUSDay"
      } ]
    },
    "geo" : { },
    "id_str" : "763745379405881345",
    "text" : "Want to feel like @POTUS for the day? Check out his \u2600\uFE0F playlist now: https:\/\/t.co\/Sc7x0ERrCs https:\/\/t.co\/3fS7s1LT4g",
    "id" : 763745379405881345,
    "created_at" : "2016-08-11 14:34:22 +0000",
    "user" : {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "protected" : false,
      "id_str" : "17230018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753188521540714497\/ge3tfN8Z_normal.jpg",
      "id" : 17230018,
      "verified" : true
    }
  },
  "id" : 763749347498614784,
  "created_at" : "2016-08-11 14:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/763747768158588932\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/OrkQEeT6LT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CplgF8tWYAEIF95.jpg",
      "id_str" : "763747267127959553",
      "id" : 763747267127959553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CplgF8tWYAEIF95.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/OrkQEeT6LT"
    } ],
    "hashtags" : [ {
      "text" : "SummerPlaylist",
      "indices" : [ 39, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/uDTEaNcMl6",
      "expanded_url" : "http:\/\/go.wh.gov\/SummerPlaylist",
      "display_url" : "go.wh.gov\/SummerPlaylist"
    } ]
  },
  "geo" : { },
  "id_str" : "763747768158588932",
  "text" : "It's here! Listen now to @POTUS's 2016 #SummerPlaylist \uD83C\uDFB5 \u2192 https:\/\/t.co\/uDTEaNcMl6 https:\/\/t.co\/OrkQEeT6LT",
  "id" : 763747768158588932,
  "created_at" : "2016-08-11 14:43:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/763744742072913920\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/mqh1YVrycj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cplc_Y9UkAAabrS.jpg",
      "id_str" : "763743855917174784",
      "id" : 763743855917174784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cplc_Y9UkAAabrS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/mqh1YVrycj"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/763744742072913920\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/mqh1YVrycj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpldBtJVMAE57rj.jpg",
      "id_str" : "763743895695994881",
      "id" : 763743895695994881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpldBtJVMAE57rj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/mqh1YVrycj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763745160836636672",
  "text" : "RT @POTUS: Been waiting to drop this: summer playlist, the encore. What's everybody listening to? https:\/\/t.co\/mqh1YVrycj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/763744742072913920\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/mqh1YVrycj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cplc_Y9UkAAabrS.jpg",
        "id_str" : "763743855917174784",
        "id" : 763743855917174784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cplc_Y9UkAAabrS.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/mqh1YVrycj"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/763744742072913920\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/mqh1YVrycj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpldBtJVMAE57rj.jpg",
        "id_str" : "763743895695994881",
        "id" : 763743895695994881,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpldBtJVMAE57rj.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/mqh1YVrycj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763744742072913920",
    "text" : "Been waiting to drop this: summer playlist, the encore. What's everybody listening to? https:\/\/t.co\/mqh1YVrycj",
    "id" : 763744742072913920,
    "created_at" : "2016-08-11 14:31:50 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 763745160836636672,
  "created_at" : "2016-08-11 14:33:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "indices" : [ 3, 14 ],
      "id_str" : "562385224",
      "id" : 562385224
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763716415790514176",
  "text" : "RT @Abramson44: To date, 300+ police depts have attended a @whitehouse briefing. Want to join? Check out Jerry's blog to learn more: https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 43, 54 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/hNwml85gve",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/10\/bringing-our-nations-law-enforcement-officials-together-conversation-community",
        "display_url" : "whitehouse.gov\/blog\/2016\/08\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763511708824600576",
    "text" : "To date, 300+ police depts have attended a @whitehouse briefing. Want to join? Check out Jerry's blog to learn more: https:\/\/t.co\/hNwml85gve",
    "id" : 763511708824600576,
    "created_at" : "2016-08-10 23:05:51 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 763716415790514176,
  "created_at" : "2016-08-11 12:39:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 122, 130 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FinalFive",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763579840150642689",
  "text" : "RT @FLOTUS: Congrats to the #FinalFive on winning gold last night! Excited to watch the Individual All-Around tomorrow\u2014go @TeamUSA! #Rio201\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Olympic Team",
        "screen_name" : "TeamUSA",
        "indices" : [ 110, 118 ],
        "id_str" : "21870081",
        "id" : 21870081
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FinalFive",
        "indices" : [ 16, 26 ]
      }, {
        "text" : "Rio2016",
        "indices" : [ 120, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763548318177828865",
    "text" : "Congrats to the #FinalFive on winning gold last night! Excited to watch the Individual All-Around tomorrow\u2014go @TeamUSA! #Rio2016 -mo",
    "id" : 763548318177828865,
    "created_at" : "2016-08-11 01:31:19 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 763579840150642689,
  "created_at" : "2016-08-11 03:36:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/763502713468366850\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/mf1WtrfaGW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpiBfqpUEAAW5Ki.jpg",
      "id_str" : "763502517862797312",
      "id" : 763502517862797312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpiBfqpUEAAW5Ki.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 1540
      }, {
        "h" : 113,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 1540
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/mf1WtrfaGW"
    } ],
    "hashtags" : [ {
      "text" : "Turkey",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763537359669456896",
  "text" : "RT @Price44: Statement on the Terrorist Attacks in #Turkey: https:\/\/t.co\/mf1WtrfaGW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/763502713468366850\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/mf1WtrfaGW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpiBfqpUEAAW5Ki.jpg",
        "id_str" : "763502517862797312",
        "id" : 763502517862797312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpiBfqpUEAAW5Ki.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 1540
        }, {
          "h" : 113,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 1540
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/mf1WtrfaGW"
      } ],
      "hashtags" : [ {
        "text" : "Turkey",
        "indices" : [ 38, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763502713468366850",
    "text" : "Statement on the Terrorist Attacks in #Turkey: https:\/\/t.co\/mf1WtrfaGW",
    "id" : 763502713468366850,
    "created_at" : "2016-08-10 22:30:06 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 763537359669456896,
  "created_at" : "2016-08-11 00:47:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "religiousfreedom",
      "indices" : [ 54, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763478893655306240",
  "text" : "RT @NSC44: Here's how the Administration has promoted #religiousfreedom as a fundamental human right around the world: https:\/\/t.co\/BRTm6m7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "religiousfreedom",
        "indices" : [ 43, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/BRTm6m7wtI",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/08\/10\/fact-sheet-promoting-and-protecting-religious-freedom-around-globe",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763470005421813761",
    "text" : "Here's how the Administration has promoted #religiousfreedom as a fundamental human right around the world: https:\/\/t.co\/BRTm6m7wtI",
    "id" : 763470005421813761,
    "created_at" : "2016-08-10 20:20:08 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 763478893655306240,
  "created_at" : "2016-08-10 20:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/763409960382394368\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/GH00VX45Um",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpgtKWeUMAAptNW.jpg",
      "id_str" : "763409792693972992",
      "id" : 763409792693972992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpgtKWeUMAAptNW.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GH00VX45Um"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/N5GoAEPFT0",
      "expanded_url" : "http:\/\/wh.gov\/chat",
      "display_url" : "wh.gov\/chat"
    } ]
  },
  "geo" : { },
  "id_str" : "763409960382394368",
  "text" : "Good news: Now you can message @POTUS on Facebook. Here's how \u2192 https:\/\/t.co\/N5GoAEPFT0 https:\/\/t.co\/GH00VX45Um",
  "id" : 763409960382394368,
  "created_at" : "2016-08-10 16:21:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "indices" : [ 3, 15 ],
      "id_str" : "2735591",
      "id" : 2735591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/BZRwW3iQLJ",
      "expanded_url" : "http:\/\/buff.ly\/2aLMlMw",
      "display_url" : "buff.ly\/2aLMlMw"
    } ]
  },
  "geo" : { },
  "id_str" : "763400615011680256",
  "text" : "RT @FastCompany: The White House's new Facebook Messenger bot makes it easy to send a message to Obama https:\/\/t.co\/BZRwW3iQLJ https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FastCompany\/status\/763397063006679041\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/eEMkYwEQW7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpghlPmWYAAeAH1.jpg",
        "id_str" : "763397060565557248",
        "id" : 763397060565557248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpghlPmWYAAeAH1.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/eEMkYwEQW7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/BZRwW3iQLJ",
        "expanded_url" : "http:\/\/buff.ly\/2aLMlMw",
        "display_url" : "buff.ly\/2aLMlMw"
      } ]
    },
    "geo" : { },
    "id_str" : "763397063006679041",
    "text" : "The White House's new Facebook Messenger bot makes it easy to send a message to Obama https:\/\/t.co\/BZRwW3iQLJ https:\/\/t.co\/eEMkYwEQW7",
    "id" : 763397063006679041,
    "created_at" : "2016-08-10 15:30:17 +0000",
    "user" : {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "protected" : false,
      "id_str" : "2735591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552466516851957760\/4cONiOi4_normal.jpeg",
      "id" : 2735591,
      "verified" : true
    }
  },
  "id" : 763400615011680256,
  "created_at" : "2016-08-10 15:44:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/VADQG3dwiB",
      "expanded_url" : "http:\/\/go.wh.gov\/chat",
      "display_url" : "go.wh.gov\/chat"
    } ]
  },
  "geo" : { },
  "id_str" : "763397713845157888",
  "text" : "RT @Goldman44: It\u2019s our latest way to meet people where they are. Learn more about how you can message @POTUS: https:\/\/t.co\/VADQG3dwiB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 88, 94 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/VADQG3dwiB",
        "expanded_url" : "http:\/\/go.wh.gov\/chat",
        "display_url" : "go.wh.gov\/chat"
      } ]
    },
    "in_reply_to_status_id_str" : "763389998716497920",
    "geo" : { },
    "id_str" : "763397662351601664",
    "in_reply_to_user_id" : 131144091,
    "text" : "It\u2019s our latest way to meet people where they are. Learn more about how you can message @POTUS: https:\/\/t.co\/VADQG3dwiB",
    "id" : 763397662351601664,
    "in_reply_to_status_id" : 763389998716497920,
    "created_at" : "2016-08-10 15:32:40 +0000",
    "in_reply_to_screen_name" : "Goldman44",
    "in_reply_to_user_id_str" : "131144091",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 763397713845157888,
  "created_at" : "2016-08-10 15:32:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/763393511681056768\/video\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/xRt7oRNXAz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cpgd60qWYAApgp2.jpg",
      "id_str" : "763392826486956032",
      "id" : 763392826486956032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cpgd60qWYAApgp2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/xRt7oRNXAz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/N5GoAEPFT0",
      "expanded_url" : "http:\/\/wh.gov\/chat",
      "display_url" : "wh.gov\/chat"
    } ]
  },
  "geo" : { },
  "id_str" : "763393511681056768",
  "text" : "1801: \uD83D\uDCEC \u2192 1880: \u260E \u2192 1994: \uD83D\uDCBB \u2192 2016:\uD83D\uDCF1\n\nNow, it's easier than ever to contact us: https:\/\/t.co\/N5GoAEPFT0 https:\/\/t.co\/xRt7oRNXAz",
  "id" : 763393511681056768,
  "created_at" : "2016-08-10 15:16:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/8ta8LoOKEa",
      "expanded_url" : "http:\/\/WhiteHouse.gov\/chat",
      "display_url" : "WhiteHouse.gov\/chat"
    } ]
  },
  "geo" : { },
  "id_str" : "763390280242499584",
  "text" : "RT @Goldman44: Got a message for @POTUS? For the first time ever, you can now send it on Facebook \u2192  https:\/\/t.co\/8ta8LoOKEa https:\/\/t.co\/T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 18, 24 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Goldman44\/status\/763389998716497920\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/TSIJGuGPlR",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpgPiqiUAAAhyEa.jpg",
        "id_str" : "763377225047474176",
        "id" : 763377225047474176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpgPiqiUAAAhyEa.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TSIJGuGPlR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/8ta8LoOKEa",
        "expanded_url" : "http:\/\/WhiteHouse.gov\/chat",
        "display_url" : "WhiteHouse.gov\/chat"
      } ]
    },
    "geo" : { },
    "id_str" : "763389998716497920",
    "text" : "Got a message for @POTUS? For the first time ever, you can now send it on Facebook \u2192  https:\/\/t.co\/8ta8LoOKEa https:\/\/t.co\/TSIJGuGPlR",
    "id" : 763389998716497920,
    "created_at" : "2016-08-10 15:02:13 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 763390280242499584,
  "created_at" : "2016-08-10 15:03:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763130045355417601",
  "text" : "RT @LaborSec: No one should have to choose between the job they need &amp; the family they love. That's why we need paid family leave: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/2o0fTAvU3u",
        "expanded_url" : "https:\/\/blog.dol.gov\/2016\/08\/09\/what-weve-learned-from-the-paid-leave-grant-program\/",
        "display_url" : "blog.dol.gov\/2016\/08\/09\/wha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763086284118196228",
    "text" : "No one should have to choose between the job they need &amp; the family they love. That's why we need paid family leave: https:\/\/t.co\/2o0fTAvU3u",
    "id" : 763086284118196228,
    "created_at" : "2016-08-09 18:55:22 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 763130045355417601,
  "created_at" : "2016-08-09 21:49:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 12, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/qzQZX1XguJ",
      "expanded_url" : "http:\/\/62milliongirls.com\/",
      "display_url" : "62milliongirls.com"
    } ]
  },
  "geo" : { },
  "id_str" : "763120846357532672",
  "text" : "RT @FLOTUS: #LetGirlsLearn is helping break down barriers for girls around the world. Here's how: https:\/\/t.co\/qzQZX1XguJ https:\/\/t.co\/Xuaw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/qzQZX1XguJ",
        "expanded_url" : "http:\/\/62milliongirls.com\/",
        "display_url" : "62milliongirls.com"
      }, {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/XuawRyshuX",
        "expanded_url" : "http:\/\/snpy.tv\/2b0MAi7",
        "display_url" : "snpy.tv\/2b0MAi7"
      } ]
    },
    "geo" : { },
    "id_str" : "763116535313465344",
    "text" : "#LetGirlsLearn is helping break down barriers for girls around the world. Here's how: https:\/\/t.co\/qzQZX1XguJ https:\/\/t.co\/XuawRyshuX",
    "id" : 763116535313465344,
    "created_at" : "2016-08-09 20:55:34 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 763120846357532672,
  "created_at" : "2016-08-09 21:12:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 14, 21 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 84, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/p2YKF9yZhl",
      "expanded_url" : "http:\/\/go.wh.gov\/olympics",
      "display_url" : "go.wh.gov\/olympics"
    }, {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/cIOY5K7KAj",
      "expanded_url" : "http:\/\/snpy.tv\/2b98HEh",
      "display_url" : "snpy.tv\/2b98HEh"
    } ]
  },
  "geo" : { },
  "id_str" : "763095784774438913",
  "text" : ".@POTUS &amp; @FLOTUS team up to share their favorite Olympic memories\u2014and cheer on #TeamUSA: https:\/\/t.co\/p2YKF9yZhl https:\/\/t.co\/cIOY5K7KAj",
  "id" : 763095784774438913,
  "created_at" : "2016-08-09 19:33:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 38, 45 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/p2YKF9QAFV",
      "expanded_url" : "http:\/\/go.wh.gov\/olympics",
      "display_url" : "go.wh.gov\/olympics"
    }, {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/xVpTmjMiFU",
      "expanded_url" : "http:\/\/snpy.tv\/2b98Heh",
      "display_url" : "snpy.tv\/2b98Heh"
    } ]
  },
  "geo" : { },
  "id_str" : "763088746875064320",
  "text" : "As we cheer on #TeamUSA, @POTUS &amp; @FLOTUS team up to share their favorite Olympic memories: https:\/\/t.co\/p2YKF9QAFV https:\/\/t.co\/xVpTmjMiFU",
  "id" : 763088746875064320,
  "created_at" : "2016-08-09 19:05:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "indices" : [ 3, 14 ],
      "id_str" : "562385224",
      "id" : 562385224
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763082755278245888",
  "text" : "RT @Abramson44: This just in: @POTUS' final Tribal Nations Conference will take place on Sept 26 w leaders from 567 federally recognized tr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 14, 20 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "763082319976509440",
    "text" : "This just in: @POTUS' final Tribal Nations Conference will take place on Sept 26 w leaders from 567 federally recognized tribes. Stay tuned!",
    "id" : 763082319976509440,
    "created_at" : "2016-08-09 18:39:37 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 763082755278245888,
  "created_at" : "2016-08-09 18:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "indices" : [ 3, 8 ],
      "id_str" : "2983206962",
      "id" : 2983206962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763065257841524737",
  "text" : "RT @USDS: On Thursday, USDS turns 2! \uD83C\uDF89\uD83C\uDF88 \n\nToday, we're having an early slice of cake and looking back on the last 2 years:\n\nhttps:\/\/t.co\/rS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/rS8pEZvOnT",
        "expanded_url" : "https:\/\/medium.com\/@USDigitalService\/two-years-of-the-u-s-digital-service-e14af5ce713b#.lpf5eldi5",
        "display_url" : "medium.com\/@USDigitalServ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763014527252242432",
    "text" : "On Thursday, USDS turns 2! \uD83C\uDF89\uD83C\uDF88 \n\nToday, we're having an early slice of cake and looking back on the last 2 years:\n\nhttps:\/\/t.co\/rS8pEZvOnT",
    "id" : 763014527252242432,
    "created_at" : "2016-08-09 14:10:14 +0000",
    "user" : {
      "name" : "U.S. Digital Service",
      "screen_name" : "USDS",
      "protected" : false,
      "id_str" : "2983206962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/557352808672817152\/HWxVbTrV_normal.png",
      "id" : 2983206962,
      "verified" : true
    }
  },
  "id" : 763065257841524737,
  "created_at" : "2016-08-09 17:31:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 81, 88 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/p2YKF9yZhl",
      "expanded_url" : "http:\/\/go.wh.gov\/olympics",
      "display_url" : "go.wh.gov\/olympics"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/cIOY5K7KAj",
      "expanded_url" : "http:\/\/snpy.tv\/2b98HEh",
      "display_url" : "snpy.tv\/2b98HEh"
    } ]
  },
  "geo" : { },
  "id_str" : "762793077509464064",
  "text" : "\"If you could compete in any Olympic event, what would you choose?\" \u2014@POTUS asks @FLOTUS: https:\/\/t.co\/p2YKF9yZhl https:\/\/t.co\/cIOY5K7KAj",
  "id" : 762793077509464064,
  "created_at" : "2016-08-08 23:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 17, 24 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/p2YKF9yZhl",
      "expanded_url" : "http:\/\/go.wh.gov\/olympics",
      "display_url" : "go.wh.gov\/olympics"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/cIOY5K7KAj",
      "expanded_url" : "http:\/\/snpy.tv\/2b98HEh",
      "display_url" : "snpy.tv\/2b98HEh"
    } ]
  },
  "geo" : { },
  "id_str" : "762775964224847872",
  "text" : "Watch @POTUS and @FLOTUS share their favorite Olympic memories\u2014and cheer on #TeamUSA: https:\/\/t.co\/p2YKF9yZhl https:\/\/t.co\/cIOY5K7KAj",
  "id" : 762775964224847872,
  "created_at" : "2016-08-08 22:22:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "Senate Republicans",
      "screen_name" : "SenateGOP",
      "indices" : [ 108, 118 ],
      "id_str" : "14344823",
      "id" : 14344823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762758579124314112",
  "text" : "RT @SCOTUSnom: \"A historically unprecedented and constitutionally unconscionable approach\" \u2014One law prof on @SenateGOP obstruction. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senate Republicans",
        "screen_name" : "SenateGOP",
        "indices" : [ 93, 103 ],
        "id_str" : "14344823",
        "id" : 14344823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ynaIbrcqF0",
        "expanded_url" : "http:\/\/www.attn.com\/stories\/10268\/what-scotus-nomination-delay-means-america",
        "display_url" : "attn.com\/stories\/10268\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "762663010166906880",
    "text" : "\"A historically unprecedented and constitutionally unconscionable approach\" \u2014One law prof on @SenateGOP obstruction. https:\/\/t.co\/ynaIbrcqF0",
    "id" : 762663010166906880,
    "created_at" : "2016-08-08 14:53:25 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 762758579124314112,
  "created_at" : "2016-08-08 21:13:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 1, 10 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/762719387665076225\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/u8NkEo0ZBK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpW3ohlWgAA1_MV.jpg",
      "id_str" : "762717618746851328",
      "id" : 762717618746851328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpW3ohlWgAA1_MV.jpg",
      "sizes" : [ {
        "h" : 205,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 885
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 885
      }, {
        "h" : 267,
        "resize" : "fit",
        "w" : 885
      } ],
      "display_url" : "pic.twitter.com\/u8NkEo0ZBK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762719387665076225",
  "text" : ".@PressSec on the terrorist attack in Quetta, Pakistan: https:\/\/t.co\/u8NkEo0ZBK",
  "id" : 762719387665076225,
  "created_at" : "2016-08-08 18:37:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bicycling Magazine",
      "screen_name" : "BicyclingMag",
      "indices" : [ 3, 16 ],
      "id_str" : "17900130",
      "id" : 17900130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/LWXQyD0mzK",
      "expanded_url" : "http:\/\/spr.ly\/6017B0vT7",
      "display_url" : "spr.ly\/6017B0vT7"
    } ]
  },
  "geo" : { },
  "id_str" : "762658551063994368",
  "text" : "RT @BicyclingMag: How the White House chief of staff convinced Obama to let him ride to work: https:\/\/t.co\/LWXQyD0mzK https:\/\/t.co\/N9M5IDU6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BicyclingMag\/status\/762303791697915904\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/N9M5IDU6vl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpQ_QbiWEAAv_yi.jpg",
        "id_str" : "762303788434722816",
        "id" : 762303788434722816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpQ_QbiWEAAv_yi.jpg",
        "sizes" : [ {
          "h" : 413,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 413,
          "resize" : "fit",
          "w" : 650
        } ],
        "display_url" : "pic.twitter.com\/N9M5IDU6vl"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/LWXQyD0mzK",
        "expanded_url" : "http:\/\/spr.ly\/6017B0vT7",
        "display_url" : "spr.ly\/6017B0vT7"
      } ]
    },
    "geo" : { },
    "id_str" : "762303791697915904",
    "text" : "How the White House chief of staff convinced Obama to let him ride to work: https:\/\/t.co\/LWXQyD0mzK https:\/\/t.co\/N9M5IDU6vl",
    "id" : 762303791697915904,
    "created_at" : "2016-08-07 15:06:01 +0000",
    "user" : {
      "name" : "Bicycling Magazine",
      "screen_name" : "BicyclingMag",
      "protected" : false,
      "id_str" : "17900130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596705203358801920\/mQ6ZGz9R_normal.jpg",
      "id" : 17900130,
      "verified" : true
    }
  },
  "id" : 762658551063994368,
  "created_at" : "2016-08-08 14:35:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/j87neGrjMT",
      "expanded_url" : "https:\/\/twitter.com\/GretchenBleiler\/status\/762626864036843520",
      "display_url" : "twitter.com\/GretchenBleile\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "762646854404374528",
  "text" : "Tweet your questions using #ActOnClimate https:\/\/t.co\/j87neGrjMT",
  "id" : 762646854404374528,
  "created_at" : "2016-08-08 13:49:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/SqeomsL0hY",
      "expanded_url" : "http:\/\/go.wh.gov\/qRR8Lz",
      "display_url" : "go.wh.gov\/qRR8Lz"
    } ]
  },
  "geo" : { },
  "id_str" : "762400733916299265",
  "text" : "\"We\u2019ll cheer on athletes\u2026who personify endurance.\" \u2014@POTUS on the first-ever Olympic Refugee Team: https:\/\/t.co\/SqeomsL0hY",
  "id" : 762400733916299265,
  "created_at" : "2016-08-07 21:31:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rio2016",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/SqeomsL0hY",
      "expanded_url" : "http:\/\/go.wh.gov\/qRR8Lz",
      "display_url" : "go.wh.gov\/qRR8Lz"
    } ]
  },
  "geo" : { },
  "id_str" : "762383171040124928",
  "text" : "\"Let\u2019s honor the courage it takes...merely to stand in the starting blocks.\u201D \u2014@POTUS on #Rio2016 athletes: https:\/\/t.co\/SqeomsL0hY",
  "id" : 762383171040124928,
  "created_at" : "2016-08-07 20:21:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "Ovie Mughelli",
      "screen_name" : "oviemughelli34",
      "indices" : [ 101, 116 ],
      "id_str" : "268312376",
      "id" : 268312376
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 45, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762341458661679108",
  "text" : "RT @FactsOnClimate: Qs on climate? Ask using #ActOnClimate! We'll answer tomorrow at 12:00pm ET with @oviemughelli34 &amp; Olympian @GretchenBl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ovie Mughelli",
        "screen_name" : "oviemughelli34",
        "indices" : [ 81, 96 ],
        "id_str" : "268312376",
        "id" : 268312376
      }, {
        "name" : "Gretchen Bleiler",
        "screen_name" : "GretchenBleiler",
        "indices" : [ 112, 128 ],
        "id_str" : "41182107",
        "id" : 41182107
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 25, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762340173111713793",
    "text" : "Qs on climate? Ask using #ActOnClimate! We'll answer tomorrow at 12:00pm ET with @oviemughelli34 &amp; Olympian @GretchenBleiler.",
    "id" : 762340173111713793,
    "created_at" : "2016-08-07 17:30:35 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 762341458661679108,
  "created_at" : "2016-08-07 17:35:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rio2016",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/SqeomsL0hY",
      "expanded_url" : "http:\/\/go.wh.gov\/qRR8Lz",
      "display_url" : "go.wh.gov\/qRR8Lz"
    } ]
  },
  "geo" : { },
  "id_str" : "762330940823605248",
  "text" : "\"We\u2019ll be singing the National Anthem\u2014and maybe even shedding a tear\u2014right alongside you.\" \u2014@POTUS on #Rio2016 \u2192 https:\/\/t.co\/SqeomsL0hY",
  "id" : 762330940823605248,
  "created_at" : "2016-08-07 16:53:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Elena Delle Donne",
      "screen_name" : "De11eDonne",
      "indices" : [ 18, 29 ],
      "id_str" : "609476852",
      "id" : 609476852
    }, {
      "name" : "USA Basketball",
      "screen_name" : "usabasketball",
      "indices" : [ 34, 48 ],
      "id_str" : "17049258",
      "id" : 17049258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USABWNT",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "Rio2016",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762305856625147904",
  "text" : "RT @VP: Good luck @De11eDonne and @usabasketball on your game today. #USABWNT #Rio2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elena Delle Donne",
        "screen_name" : "De11eDonne",
        "indices" : [ 10, 21 ],
        "id_str" : "609476852",
        "id" : 609476852
      }, {
        "name" : "USA Basketball",
        "screen_name" : "usabasketball",
        "indices" : [ 26, 40 ],
        "id_str" : "17049258",
        "id" : 17049258
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USABWNT",
        "indices" : [ 61, 69 ]
      }, {
        "text" : "Rio2016",
        "indices" : [ 70, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762301471295668225",
    "text" : "Good luck @De11eDonne and @usabasketball on your game today. #USABWNT #Rio2016",
    "id" : 762301471295668225,
    "created_at" : "2016-08-07 14:56:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 762305856625147904,
  "created_at" : "2016-08-07 15:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 86, 94 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762300435768176641",
  "text" : "RT @JohnKerry: Had a great time representing the U.S. in Rio &amp; mtg w\/ many of our @TeamUSA athletes. Wishing you all good luck! https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Olympic Team",
        "screen_name" : "TeamUSA",
        "indices" : [ 71, 79 ],
        "id_str" : "21870081",
        "id" : 21870081
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/762097678557646848\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rzgxSVIjzy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpODj7jVMAEQ0Js.jpg",
        "id_str" : "762097415260286977",
        "id" : 762097415260286977,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpODj7jVMAEQ0Js.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rzgxSVIjzy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762097678557646848",
    "text" : "Had a great time representing the U.S. in Rio &amp; mtg w\/ many of our @TeamUSA athletes. Wishing you all good luck! https:\/\/t.co\/rzgxSVIjzy",
    "id" : 762097678557646848,
    "created_at" : "2016-08-07 01:27:00 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 762300435768176641,
  "created_at" : "2016-08-07 14:52:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Sqeomstpqq",
      "expanded_url" : "http:\/\/go.wh.gov\/qRR8Lz",
      "display_url" : "go.wh.gov\/qRR8Lz"
    } ]
  },
  "geo" : { },
  "id_str" : "762299012192079873",
  "text" : "\u201CJust hard work, focus, and a dream. That\u2019s the Olympic spirit \u2013 and it\u2019s the American spirit, too.\u201D \u2014@POTUS: https:\/\/t.co\/Sqeomstpqq",
  "id" : 762299012192079873,
  "created_at" : "2016-08-07 14:47:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "762033642688380928",
  "text" : "RT @POTUS: The struggle for the Voting Rights Act taught us that people who love this country can change it. Don't give away your power - g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "762030430954684416",
    "text" : "The struggle for the Voting Rights Act taught us that people who love this country can change it. Don't give away your power - go vote.",
    "id" : 762030430954684416,
    "created_at" : "2016-08-06 20:59:47 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 762033642688380928,
  "created_at" : "2016-08-06 21:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 101, 109 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/SqeomsL0hY",
      "expanded_url" : "http:\/\/go.wh.gov\/qRR8Lz",
      "display_url" : "go.wh.gov\/qRR8Lz"
    } ]
  },
  "geo" : { },
  "id_str" : "762023206769221632",
  "text" : "\u201CIt\u2019s about the character it takes to train your heart out, even when no one\u2019s watching.\u201D \u2014@POTUS on @TeamUSA https:\/\/t.co\/SqeomsL0hY",
  "id" : 762023206769221632,
  "created_at" : "2016-08-06 20:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 104, 112 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Sqeomstpqq",
      "expanded_url" : "http:\/\/go.wh.gov\/qRR8Lz",
      "display_url" : "go.wh.gov\/qRR8Lz"
    } ]
  },
  "geo" : { },
  "id_str" : "761999790892806144",
  "text" : "\u201COur team boasts the most women who have ever competed for any nation at any Olympic Games.\u201D \u2014@POTUS on @TeamUSA: https:\/\/t.co\/Sqeomstpqq",
  "id" : 761999790892806144,
  "created_at" : "2016-08-06 18:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/09K9N3PZOV",
      "expanded_url" : "http:\/\/snpy.tv\/2aOlJps",
      "display_url" : "snpy.tv\/2aOlJps"
    } ]
  },
  "geo" : { },
  "id_str" : "761960584216588290",
  "text" : "\"We\u2019re all one team. We believe in taking care of each other and in lifting each other up\" \u2014@POTUS in #WestWingWeek: https:\/\/t.co\/09K9N3PZOV",
  "id" : 761960584216588290,
  "created_at" : "2016-08-06 16:22:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 54, 62 ],
      "id_str" : "21870081",
      "id" : 21870081
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rio2016",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Sqeomstpqq",
      "expanded_url" : "http:\/\/go.wh.gov\/qRR8Lz",
      "display_url" : "go.wh.gov\/qRR8Lz"
    } ]
  },
  "geo" : { },
  "id_str" : "761949771988959232",
  "text" : "Jesse Owens.\nBob Beamon.\nKerri Strug.\nCassius Clay.\n \n@TeamUSA inspires us time and again. Watch @POTUS on #Rio2016: https:\/\/t.co\/Sqeomstpqq",
  "id" : 761949771988959232,
  "created_at" : "2016-08-06 15:39:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/SqeomsL0hY",
      "expanded_url" : "http:\/\/go.wh.gov\/qRR8Lz",
      "display_url" : "go.wh.gov\/qRR8Lz"
    } ]
  },
  "geo" : { },
  "id_str" : "761922805910818816",
  "text" : "In this week\u2019s address, @POTUS cheers on the 2016 USA Olympic Team. Let\u2019s go #TeamUSA: https:\/\/t.co\/SqeomsL0hY",
  "id" : 761922805910818816,
  "created_at" : "2016-08-06 13:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamRefugees",
      "indices" : [ 35, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761705560446210048",
  "text" : "RT @POTUS: Tonight, the first-ever #TeamRefugees will also stand before the world and prove that you can succeed no matter where you're fro\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamRefugees",
        "indices" : [ 24, 37 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "761703659411345408",
    "geo" : { },
    "id_str" : "761703867402686464",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Tonight, the first-ever #TeamRefugees will also stand before the world and prove that you can succeed no matter where you're from.",
    "id" : 761703867402686464,
    "in_reply_to_status_id" : 761703659411345408,
    "created_at" : "2016-08-05 23:22:08 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 761705560446210048,
  "created_at" : "2016-08-05 23:28:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761705543098572800",
  "text" : "RT @POTUS: Ready to root on #TeamUSA! Our team's unity and diversity makes us so proud - and reminds the world why America sets the gold st\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 17, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761703659411345408",
    "text" : "Ready to root on #TeamUSA! Our team's unity and diversity makes us so proud - and reminds the world why America sets the gold standard.",
    "id" : 761703659411345408,
    "created_at" : "2016-08-05 23:21:18 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 761705543098572800,
  "created_at" : "2016-08-05 23:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamRefugees",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761687147627814913",
  "text" : "RT @AmbassadorPower: This team is showing the world the face of the global refugee crisis. My msg on historic, inspiring #TeamRefugees:\nhtt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamRefugees",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/HftMh8NXLB",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/011a56ea-8e4c-4f2b-bc09-7992632c9305",
        "display_url" : "amp.twimg.com\/v\/011a56ea-8e4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761647748571541504",
    "text" : "This team is showing the world the face of the global refugee crisis. My msg on historic, inspiring #TeamRefugees:\nhttps:\/\/t.co\/HftMh8NXLB",
    "id" : 761647748571541504,
    "created_at" : "2016-08-05 19:39:08 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 761687147627814913,
  "created_at" : "2016-08-05 22:15:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761681529588318208",
  "text" : "RT @Schultz44: .@POTUS is focused on fighting #Zika, I'll let GOPers in Congress answer for why they're failing to do the same. 7\/7 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Schultz44\/status\/761678538902638592\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/JRohUTQZb7",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpIGiU8UAAA5AFa.jpg",
        "id_str" : "761678473786032128",
        "id" : 761678473786032128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpIGiU8UAAA5AFa.jpg",
        "sizes" : [ {
          "h" : 674,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JRohUTQZb7"
      } ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 31, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761678538902638592",
    "text" : ".@POTUS is focused on fighting #Zika, I'll let GOPers in Congress answer for why they're failing to do the same. 7\/7 https:\/\/t.co\/JRohUTQZb7",
    "id" : 761678538902638592,
    "created_at" : "2016-08-05 21:41:29 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 761681529588318208,
  "created_at" : "2016-08-05 21:53:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 67, 75 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpeningCeremony",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/NoPgF3p10T",
      "expanded_url" : "http:\/\/snpy.tv\/2aH9jiE",
      "display_url" : "snpy.tv\/2aH9jiE"
    } ]
  },
  "geo" : { },
  "id_str" : "761671328415952896",
  "text" : "\"Bring home the gold for the Red, White, and Blue\" \u2014@POTUS wishing @TeamUSA luck ahead of the #OpeningCeremony https:\/\/t.co\/NoPgF3p10T",
  "id" : 761671328415952896,
  "created_at" : "2016-08-05 21:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Glamour",
      "screen_name" : "glamourmag",
      "indices" : [ 114, 125 ],
      "id_str" : "19247844",
      "id" : 19247844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761664611229790212",
  "text" : "RT @vj44: \"It's important...their dad is a feminist, because now that's what they expect from all men\" \u2014@POTUS to @GlamourMag https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 94, 100 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Glamour",
        "screen_name" : "glamourmag",
        "indices" : [ 104, 115 ],
        "id_str" : "19247844",
        "id" : 19247844
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/rcbnSIcqPv",
        "expanded_url" : "http:\/\/bit.ly\/2aVuLW5",
        "display_url" : "bit.ly\/2aVuLW5"
      } ]
    },
    "geo" : { },
    "id_str" : "761661243576848384",
    "text" : "\"It's important...their dad is a feminist, because now that's what they expect from all men\" \u2014@POTUS to @GlamourMag https:\/\/t.co\/rcbnSIcqPv",
    "id" : 761661243576848384,
    "created_at" : "2016-08-05 20:32:46 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 761664611229790212,
  "created_at" : "2016-08-05 20:46:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761641380472954880",
  "text" : "RT @POTUS: Longest streak of total job growth on record, wages rising at fastest pace in 7 years. We've come a long way, America\u2014let's keep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761640808009302016",
    "text" : "Longest streak of total job growth on record, wages rising at fastest pace in 7 years. We've come a long way, America\u2014let's keep it going.",
    "id" : 761640808009302016,
    "created_at" : "2016-08-05 19:11:33 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 761641380472954880,
  "created_at" : "2016-08-05 19:13:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "Rio2016",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761636524119068673",
  "text" : "RT @JohnKerry: Very proud of the amazing athletes on #TeamUSA. Honored to show our support &amp; cheer them on at #Rio2016 https:\/\/t.co\/hnhu4wV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/761626705702232064\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/hnhu4wVbWO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHXbmxVIAAIw4g.jpg",
        "id_str" : "761626681266216960",
        "id" : 761626681266216960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHXbmxVIAAIw4g.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/hnhu4wVbWO"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/761626705702232064\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/hnhu4wVbWO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpHXbmxVMAAjG8L.jpg",
        "id_str" : "761626681266221056",
        "id" : 761626681266221056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpHXbmxVMAAjG8L.jpg",
        "sizes" : [ {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/hnhu4wVbWO"
      } ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 38, 46 ]
      }, {
        "text" : "Rio2016",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761626705702232064",
    "text" : "Very proud of the amazing athletes on #TeamUSA. Honored to show our support &amp; cheer them on at #Rio2016 https:\/\/t.co\/hnhu4wVbWO",
    "id" : 761626705702232064,
    "created_at" : "2016-08-05 18:15:31 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 761636524119068673,
  "created_at" : "2016-08-05 18:54:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadWhereYouAre",
      "indices" : [ 109, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761635643386540032",
  "text" : "RT @usedgov: Who's reading today? We are! Show us your favorite summer reading spot and tag your photos with #ReadWhereYouAre \uD83D\uDCDA https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/761563933828194305\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/X6H4xznlph",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co9PelBWEAA3K3H.jpg",
        "id_str" : "760914248801325056",
        "id" : 760914248801325056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co9PelBWEAA3K3H.jpg",
        "sizes" : [ {
          "h" : 1920,
          "resize" : "fit",
          "w" : 2560
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/X6H4xznlph"
      } ],
      "hashtags" : [ {
        "text" : "ReadWhereYouAre",
        "indices" : [ 96, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761563933828194305",
    "text" : "Who's reading today? We are! Show us your favorite summer reading spot and tag your photos with #ReadWhereYouAre \uD83D\uDCDA https:\/\/t.co\/X6H4xznlph",
    "id" : 761563933828194305,
    "created_at" : "2016-08-05 14:06:05 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 761635643386540032,
  "created_at" : "2016-08-05 18:51:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/C8P76lnNkb",
      "expanded_url" : "http:\/\/go.wh.gov\/JulyJobs",
      "display_url" : "go.wh.gov\/JulyJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "761618587442438146",
  "text" : "The economy added 255,000 jobs in July\u2014extending the longest streak of total job growth on record:  https:\/\/t.co\/C8P76lnNkb #JobsReport",
  "id" : 761618587442438146,
  "created_at" : "2016-08-05 17:43:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "indices" : [ 3, 14 ],
      "id_str" : "562456722",
      "id" : 562456722
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 51, 61 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 72, 80 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761616559626260480",
  "text" : "RT @LizAllen44: Happening now in Rio: Joining Sec. @JohnKerry meet with @TeamUSA - so exciting to meet our incredible athletes \uD83C\uDFC5\uD83C\uDFC5\uD83C\uDFC5 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 35, 45 ],
        "id_str" : "15007149",
        "id" : 15007149
      }, {
        "name" : "U.S. Olympic Team",
        "screen_name" : "TeamUSA",
        "indices" : [ 56, 64 ],
        "id_str" : "21870081",
        "id" : 21870081
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LizAllen44\/status\/761592908176908288\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/DyYjNrXFps",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpG4ol8WgAAWZ77.jpg",
        "id_str" : "761592819521847296",
        "id" : 761592819521847296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpG4ol8WgAAWZ77.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/DyYjNrXFps"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761592908176908288",
    "text" : "Happening now in Rio: Joining Sec. @JohnKerry meet with @TeamUSA - so exciting to meet our incredible athletes \uD83C\uDFC5\uD83C\uDFC5\uD83C\uDFC5 https:\/\/t.co\/DyYjNrXFps",
    "id" : 761592908176908288,
    "created_at" : "2016-08-05 16:01:13 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 761616559626260480,
  "created_at" : "2016-08-05 17:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/761596821701529601\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/erXP4sSOsd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpG8MFUUkAAMOqt.jpg",
      "id_str" : "761596727774187520",
      "id" : 761596727774187520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpG8MFUUkAAMOqt.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/erXP4sSOsd"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/C8P76lnNkb",
      "expanded_url" : "http:\/\/go.wh.gov\/JulyJobs",
      "display_url" : "go.wh.gov\/JulyJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "761596821701529601",
  "text" : "FACT: Wages are rising at the fastest pace in 7 years \u2192 https:\/\/t.co\/C8P76lnNkb #JobsReport https:\/\/t.co\/erXP4sSOsd",
  "id" : 761596821701529601,
  "created_at" : "2016-08-05 16:16:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "It's On Us",
      "screen_name" : "ItsOnUs",
      "indices" : [ 3, 11 ],
      "id_str" : "2840712124",
      "id" : 2840712124
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 31, 34 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 18, 26 ]
    }, {
      "text" : "ItsOnUs",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/n18cRx4EbB",
      "expanded_url" : "http:\/\/itsonus.org\/#pledge",
      "display_url" : "itsonus.org\/#pledge"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/dWYVzRu5C7",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/dd0cd24f-8acd-4a8c-8434-7c1315dbe57e",
      "display_url" : "amp.twimg.com\/v\/dd0cd24f-8ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761584625437306880",
  "text" : "RT @ItsOnUs: Join #TeamUSA and @VP Joe Biden in the #ItsOnUs movement by taking the pledge \u2192 https:\/\/t.co\/n18cRx4EbB\nhttps:\/\/t.co\/dWYVzRu5C7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 18, 21 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 5, 13 ]
      }, {
        "text" : "ItsOnUs",
        "indices" : [ 39, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/n18cRx4EbB",
        "expanded_url" : "http:\/\/itsonus.org\/#pledge",
        "display_url" : "itsonus.org\/#pledge"
      }, {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/dWYVzRu5C7",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/dd0cd24f-8acd-4a8c-8434-7c1315dbe57e",
        "display_url" : "amp.twimg.com\/v\/dd0cd24f-8ac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761578683979042816",
    "text" : "Join #TeamUSA and @VP Joe Biden in the #ItsOnUs movement by taking the pledge \u2192 https:\/\/t.co\/n18cRx4EbB\nhttps:\/\/t.co\/dWYVzRu5C7",
    "id" : 761578683979042816,
    "created_at" : "2016-08-05 15:04:42 +0000",
    "user" : {
      "name" : "It's On Us",
      "screen_name" : "ItsOnUs",
      "protected" : false,
      "id_str" : "2840712124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666281106770173952\/tPVjIzos_normal.png",
      "id" : 2840712124,
      "verified" : false
    }
  },
  "id" : 761584625437306880,
  "created_at" : "2016-08-05 15:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 96, 98 ]
    }, {
      "text" : "askpresssec",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761579329654394882",
  "text" : "RT @PressSec: As I fight off the remnants of my cold, I am ready to take your q's on strong job #s or anything else. #askpresssec https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/761572355244167168\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/TnsZA5UBhW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpGlwCLUEAAHuQ4.jpg",
        "id_str" : "761572056638951424",
        "id" : 761572056638951424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpGlwCLUEAAHuQ4.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/TnsZA5UBhW"
      } ],
      "hashtags" : [ {
        "text" : "s",
        "indices" : [ 82, 84 ]
      }, {
        "text" : "askpresssec",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761572355244167168",
    "text" : "As I fight off the remnants of my cold, I am ready to take your q's on strong job #s or anything else. #askpresssec https:\/\/t.co\/TnsZA5UBhW",
    "id" : 761572355244167168,
    "created_at" : "2016-08-05 14:39:33 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 761579329654394882,
  "created_at" : "2016-08-05 15:07:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/761573188543229952\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/p0SH7Jne5n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpGml8EWgAAU8vU.jpg",
      "id_str" : "761572982712074240",
      "id" : 761572982712074240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpGml8EWgAAU8vU.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/p0SH7Jne5n"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/C8P76l6bVB",
      "expanded_url" : "http:\/\/go.wh.gov\/JulyJobs",
      "display_url" : "go.wh.gov\/JulyJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "761573188543229952",
  "text" : "Good news: Our businesses have added 15 million jobs over the past 77 months \u2192 https:\/\/t.co\/C8P76l6bVB https:\/\/t.co\/p0SH7Jne5n",
  "id" : 761573188543229952,
  "created_at" : "2016-08-05 14:42:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/761381302260031489\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/TgQWxfpkOe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpDvnvEWgAAYSuk.jpg",
      "id_str" : "761371802954268672",
      "id" : 761371802954268672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpDvnvEWgAAYSuk.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/TgQWxfpkOe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761381302260031489",
  "text" : "Happy birthday, @POTUS! https:\/\/t.co\/TgQWxfpkOe",
  "id" : 761381302260031489,
  "created_at" : "2016-08-05 02:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 85, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/gSGjvndtSa",
      "expanded_url" : "http:\/\/snpy.tv\/2aZ6qv8",
      "display_url" : "snpy.tv\/2aZ6qv8"
    } ]
  },
  "geo" : { },
  "id_str" : "761355585724055553",
  "text" : "Every summer since taking office, our interns surprised @POTUS with a birthday card. #TBT to the 1st one from 2009: https:\/\/t.co\/gSGjvndtSa",
  "id" : 761355585724055553,
  "created_at" : "2016-08-05 00:18:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/HXfcnpbpkp",
      "expanded_url" : "http:\/\/snpy.tv\/2aDXKsf",
      "display_url" : "snpy.tv\/2aDXKsf"
    } ]
  },
  "geo" : { },
  "id_str" : "761344123257298944",
  "text" : "\"They are raising their kids with love of country and a rejection of violence.\" \u2014@POTUS on Muslim Americans: https:\/\/t.co\/HXfcnpbpkp",
  "id" : 761344123257298944,
  "created_at" : "2016-08-04 23:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 92, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/bZgWTG5k5e",
      "expanded_url" : "http:\/\/snpy.tv\/2aYJyw4",
      "display_url" : "snpy.tv\/2aYJyw4"
    } ]
  },
  "geo" : { },
  "id_str" : "761338694951239680",
  "text" : "This week, @POTUS commuted the sentences of 214 Americans. Here's why he's taking action on #CriminalJusticeReform: https:\/\/t.co\/bZgWTG5k5e",
  "id" : 761338694951239680,
  "created_at" : "2016-08-04 23:11:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/V7kRL4pcKX",
      "expanded_url" : "http:\/\/go.wh.gov\/StartupDay",
      "display_url" : "go.wh.gov\/StartupDay"
    } ]
  },
  "geo" : { },
  "id_str" : "761335395963506693",
  "text" : "RT @VP: Fuel innovation.\nCreate jobs.\nMake our country better.\n\nHere's how \u2192 https:\/\/t.co\/V7kRL4pcKX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/V7kRL4pcKX",
        "expanded_url" : "http:\/\/go.wh.gov\/StartupDay",
        "display_url" : "go.wh.gov\/StartupDay"
      } ]
    },
    "geo" : { },
    "id_str" : "761334773235068929",
    "text" : "Fuel innovation.\nCreate jobs.\nMake our country better.\n\nHere's how \u2192 https:\/\/t.co\/V7kRL4pcKX",
    "id" : 761334773235068929,
    "created_at" : "2016-08-04 22:55:29 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 761335395963506693,
  "created_at" : "2016-08-04 22:57:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/G900peFaXT",
      "expanded_url" : "http:\/\/go.wh.gov\/zika",
      "display_url" : "go.wh.gov\/zika"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/RlY2zoCr4y",
      "expanded_url" : "http:\/\/snpy.tv\/2aYDiV6",
      "display_url" : "snpy.tv\/2aYDiV6"
    } ]
  },
  "geo" : { },
  "id_str" : "761332389670977536",
  "text" : "\u201CCongress needs to do its job. Fighting #Zika costs money.\u201D \u2014@POTUS. Learn more: https:\/\/t.co\/G900peFaXT https:\/\/t.co\/RlY2zoCr4y",
  "id" : 761332389670977536,
  "created_at" : "2016-08-04 22:46:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 37, 43 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761330092194881536",
  "text" : "RT @NSC44: Today @POTUS convened his @NSC44 at the Pentagon for a regular meeting on efforts to degrade &amp; destroy ISIL.\nhttps:\/\/t.co\/XhNlSM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "WH National Security",
        "screen_name" : "NSC44",
        "indices" : [ 26, 32 ],
        "id_str" : "369245377",
        "id" : 369245377
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/XhNlSMdNfj",
        "expanded_url" : "http:\/\/snpy.tv\/2b6q87s",
        "display_url" : "snpy.tv\/2b6q87s"
      } ]
    },
    "geo" : { },
    "id_str" : "761306844321185792",
    "text" : "Today @POTUS convened his @NSC44 at the Pentagon for a regular meeting on efforts to degrade &amp; destroy ISIL.\nhttps:\/\/t.co\/XhNlSMdNfj",
    "id" : 761306844321185792,
    "created_at" : "2016-08-04 21:04:30 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 761330092194881536,
  "created_at" : "2016-08-04 22:36:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761328695931965444",
  "text" : "RT @PressSec: Bringing the briefing to Twitter tomorrow at 10:30am ET. Got a question? Use #AskPressSec and I'll be here to answer. Looking\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 77, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761328630949478400",
    "text" : "Bringing the briefing to Twitter tomorrow at 10:30am ET. Got a question? Use #AskPressSec and I'll be here to answer. Looking forward to it!",
    "id" : 761328630949478400,
    "created_at" : "2016-08-04 22:31:05 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 761328695931965444,
  "created_at" : "2016-08-04 22:31:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/761307597198790657\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/R9hMIBqCZ7",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpC0-n0UEAEgObl.jpg",
      "id_str" : "761307324958904321",
      "id" : 761307324958904321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpC0-n0UEAEgObl.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R9hMIBqCZ7"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 1, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/92mo7Zg2k7",
      "expanded_url" : "http:\/\/cdc.gov\/zika",
      "display_url" : "cdc.gov\/zika"
    } ]
  },
  "geo" : { },
  "id_str" : "761307597198790657",
  "text" : "\"#Zika is a serious threat to Americans, especially babies.\" \u2014@POTUS. Get the facts: https:\/\/t.co\/92mo7Zg2k7 https:\/\/t.co\/R9hMIBqCZ7",
  "id" : 761307597198790657,
  "created_at" : "2016-08-04 21:07:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/761306525633802240\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/y8RkiK5zFe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpCz6TEWgAAexMb.jpg",
      "id_str" : "761306151157923840",
      "id" : 761306151157923840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpCz6TEWgAAexMb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/y8RkiK5zFe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761306525633802240",
  "text" : "\u201CThey left for summer recess without passing any new funds for the fight against Zika\u201D \u2014@POTUS on the GOP\u2019s inaction https:\/\/t.co\/y8RkiK5zFe",
  "id" : 761306525633802240,
  "created_at" : "2016-08-04 21:03:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/hbF6epNBC0",
      "expanded_url" : "http:\/\/cdc.gov",
      "display_url" : "cdc.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "761306095788908544",
  "text" : "\u201CI again want to encourage every American to learn what they can do to help stop #Zika by going to https:\/\/t.co\/hbF6epNBC0\" \u2014@POTUS",
  "id" : 761306095788908544,
  "created_at" : "2016-08-04 21:01:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/761305807740932097\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/eDDVQ47f97",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpCzgXVWEAAjPk8.jpg",
      "id_str" : "761305705626341376",
      "id" : 761305705626341376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpCzgXVWEAAjPk8.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eDDVQ47f97"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761305807740932097",
  "text" : "\u201CWe are now seeing the first locally transmitted cases of the #Zika virus\u2026in the continental United States.\u201D \u2014@POTUS https:\/\/t.co\/eDDVQ47f97",
  "id" : 761305807740932097,
  "created_at" : "2016-08-04 21:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 146, 152 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761305496582287360",
  "text" : "\u201CWe refuse to let terrorists &amp; voices of division undermine the unity &amp; values of diversity &amp; pluralism that keep our nation strong\u201D \u2014@POTUS",
  "id" : 761305496582287360,
  "created_at" : "2016-08-04 20:59:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761305168117989376",
  "text" : "RT @NSC44: \u201CBeyond Syria &amp; Iraq, we\u2019ll keep working with allies &amp; partners to go after ISIL wherever it tries to spread\u201D-@POTUS https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 118, 124 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/761304962680758272\/photo\/1",
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/xpbf52Nr2E",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpCy0ZNUsAAlGDq.jpg",
        "id_str" : "761304950215323648",
        "id" : 761304950215323648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpCy0ZNUsAAlGDq.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xpbf52Nr2E"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761304962680758272",
    "text" : "\u201CBeyond Syria &amp; Iraq, we\u2019ll keep working with allies &amp; partners to go after ISIL wherever it tries to spread\u201D-@POTUS https:\/\/t.co\/xpbf52Nr2E",
    "id" : 761304962680758272,
    "created_at" : "2016-08-04 20:57:02 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 761305168117989376,
  "created_at" : "2016-08-04 20:57:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761304538498433024",
  "text" : "\u201CI want to repeat\u2014ISIL has not had a major successful offensive operation in either Syria or Iraq in a full year.\u201D \u2014@POTUS",
  "id" : 761304538498433024,
  "created_at" : "2016-08-04 20:55:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761303943548993536",
  "text" : "RT @NSC44: ISIL continues to lose senior commanders, &amp; territory in both Iraq &amp; Syria. The US will continue this progress. https:\/\/t.co\/orT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NSC44\/status\/761303829115641856\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/orTGSHWrgn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpCxxQCVYAA5Hi4.jpg",
        "id_str" : "761303796702076928",
        "id" : 761303796702076928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpCxxQCVYAA5Hi4.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/orTGSHWrgn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761303829115641856",
    "text" : "ISIL continues to lose senior commanders, &amp; territory in both Iraq &amp; Syria. The US will continue this progress. https:\/\/t.co\/orTGSHWrgn",
    "id" : 761303829115641856,
    "created_at" : "2016-08-04 20:52:31 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 761303943548993536,
  "created_at" : "2016-08-04 20:52:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761303688329789440",
  "text" : "\u201CWith our extraordinary technologies, we\u2019re conducting the most precise air campaign in history.\u201D \u2014@POTUS",
  "id" : 761303688329789440,
  "created_at" : "2016-08-04 20:51:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/761303643261992960\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/8Mzt5WjBoI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpCxkxNXEAAXdNb.jpg",
      "id_str" : "761303582268395520",
      "id" : 761303582268395520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpCxkxNXEAAXdNb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8Mzt5WjBoI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761303643261992960",
  "text" : "\u201COur air campaign continues to hammer ISIL targets. More than 14,000 strikes so far.\u201D \u2014@POTUS on combating ISIL https:\/\/t.co\/8Mzt5WjBoI",
  "id" : 761303643261992960,
  "created_at" : "2016-08-04 20:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/761303512131182592\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/zOytm74RiV",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpCxfGhXYAA5vbc.jpg",
      "id_str" : "761303484910231552",
      "id" : 761303484910231552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpCxfGhXYAA5vbc.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zOytm74RiV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761303512131182592",
  "text" : "\u201CWe\u2019re going to keep going after ISIL, aggressively, across every front of this campaign.\u201D \u2014@POTUS https:\/\/t.co\/zOytm74RiV",
  "id" : 761303512131182592,
  "created_at" : "2016-08-04 20:51:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/761303064389226496\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/dTkCryTqnp",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CpCxEARWAAAu519.jpg",
      "id_str" : "761303019375951872",
      "id" : 761303019375951872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CpCxEARWAAAu519.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dTkCryTqnp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "761303064389226496",
  "text" : "Watch live: @POTUS speaks on our progress in the fight against ISIL \u2192 https:\/\/t.co\/oDIQ2UMleK https:\/\/t.co\/dTkCryTqnp",
  "id" : 761303064389226496,
  "created_at" : "2016-08-04 20:49:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/L5JPW5mlmY",
      "expanded_url" : "http:\/\/go.wh.gov\/3X9GAR",
      "display_url" : "go.wh.gov\/3X9GAR"
    } ]
  },
  "geo" : { },
  "id_str" : "761289905435648000",
  "text" : "Tune in at 4:15pm ET: @POTUS speaks on our progress in the fight against ISIL \u2192 https:\/\/t.co\/L5JPW5mlmY",
  "id" : 761289905435648000,
  "created_at" : "2016-08-04 19:57:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/761253705341480962\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/uNsxouTKOO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpCEGe7WcAA0WNb.jpg",
      "id_str" : "761253583941693440",
      "id" : 761253583941693440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpCEGe7WcAA0WNb.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/uNsxouTKOO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761253904680189952",
  "text" : "RT @VP: Happy 55th, Barack! A brother to me, a best friend forever. https:\/\/t.co\/uNsxouTKOO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/761253705341480962\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/uNsxouTKOO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpCEGe7WcAA0WNb.jpg",
        "id_str" : "761253583941693440",
        "id" : 761253583941693440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpCEGe7WcAA0WNb.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/uNsxouTKOO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761253705341480962",
    "text" : "Happy 55th, Barack! A brother to me, a best friend forever. https:\/\/t.co\/uNsxouTKOO",
    "id" : 761253705341480962,
    "created_at" : "2016-08-04 17:33:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 761253904680189952,
  "created_at" : "2016-08-04 17:34:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761241146337001472",
  "text" : "RT @vj44: .@POTUS describes why it's an extraordinary time to be a woman-not just as President, but also as a feminist https:\/\/t.co\/m3bE50v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/m3bE50vDFx",
        "expanded_url" : "http:\/\/www.glamour.com\/story\/glamour-exclusive-president-barack-obama-says-this-is-what-a-feminist-looks-like",
        "display_url" : "glamour.com\/story\/glamour-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "761230445329743874",
    "text" : ".@POTUS describes why it's an extraordinary time to be a woman-not just as President, but also as a feminist https:\/\/t.co\/m3bE50vDFx",
    "id" : 761230445329743874,
    "created_at" : "2016-08-04 16:00:55 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 761241146337001472,
  "created_at" : "2016-08-04 16:43:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "indices" : [ 3, 14 ],
      "id_str" : "562456722",
      "id" : 562456722
    }, {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "indices" : [ 94, 102 ],
      "id_str" : "21870081",
      "id" : 21870081
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/LizAllen44\/status\/761228467597873152\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/XGaQ3KIGB5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpBtJezUEAE9iZY.jpg",
      "id_str" : "761228346680152065",
      "id" : 761228346680152065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpBtJezUEAE9iZY.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/XGaQ3KIGB5"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/LizAllen44\/status\/761228467597873152\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/XGaQ3KIGB5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpBtJe0VIAE2h2i.jpg",
      "id_str" : "761228346684416001",
      "id" : 761228346684416001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpBtJe0VIAE2h2i.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/XGaQ3KIGB5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761235247782465536",
  "text" : "RT @LizAllen44: Touched down in Rio this AM - first stopping by USA House, which supports the @TeamUSA community https:\/\/t.co\/XGaQ3KIGB5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Olympic Team",
        "screen_name" : "TeamUSA",
        "indices" : [ 78, 86 ],
        "id_str" : "21870081",
        "id" : 21870081
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/LizAllen44\/status\/761228467597873152\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/XGaQ3KIGB5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpBtJezUEAE9iZY.jpg",
        "id_str" : "761228346680152065",
        "id" : 761228346680152065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpBtJezUEAE9iZY.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/XGaQ3KIGB5"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/LizAllen44\/status\/761228467597873152\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/XGaQ3KIGB5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpBtJe0VIAE2h2i.jpg",
        "id_str" : "761228346684416001",
        "id" : 761228346684416001,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpBtJe0VIAE2h2i.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/XGaQ3KIGB5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761228467597873152",
    "text" : "Touched down in Rio this AM - first stopping by USA House, which supports the @TeamUSA community https:\/\/t.co\/XGaQ3KIGB5",
    "id" : 761228467597873152,
    "created_at" : "2016-08-04 15:53:04 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 761235247782465536,
  "created_at" : "2016-08-04 16:20:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "indices" : [ 3, 16 ],
      "id_str" : "44873497",
      "id" : 44873497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachthebabies",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761220748090478592",
  "text" : "RT @JohnKingatED: So proud of the gains that we've made to expand high quality PreK to our youngest learners. #teachthebabies https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKingatED\/status\/760974810058989572\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/aWHP0rFJEY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co-GiOfXEAA8L_B.jpg",
        "id_str" : "760974784612208640",
        "id" : 760974784612208640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co-GiOfXEAA8L_B.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/aWHP0rFJEY"
      } ],
      "hashtags" : [ {
        "text" : "teachthebabies",
        "indices" : [ 92, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760974810058989572",
    "text" : "So proud of the gains that we've made to expand high quality PreK to our youngest learners. #teachthebabies https:\/\/t.co\/aWHP0rFJEY",
    "id" : 760974810058989572,
    "created_at" : "2016-08-03 23:05:07 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 761220748090478592,
  "created_at" : "2016-08-04 15:22:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 69, 73 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateAction",
      "indices" : [ 27, 41 ]
    }, {
      "text" : "CleanPowerPlan",
      "indices" : [ 48, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761213366496964608",
  "text" : "RT @GinaEPA: 1 year later: #ClimateAction &amp; #CleanPowerPlan. How @EPA keeps working to safeguard public health &amp; the environment. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 56, 60 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ClimateAction",
        "indices" : [ 14, 28 ]
      }, {
        "text" : "CleanPowerPlan",
        "indices" : [ 35, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/bJclKecAnh",
        "expanded_url" : "https:\/\/blog.epa.gov\/blog\/2016\/08\/climate-action-and-the-clean-power-plan",
        "display_url" : "blog.epa.gov\/blog\/2016\/08\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760824597306544128",
    "text" : "1 year later: #ClimateAction &amp; #CleanPowerPlan. How @EPA keeps working to safeguard public health &amp; the environment. https:\/\/t.co\/bJclKecAnh",
    "id" : 760824597306544128,
    "created_at" : "2016-08-03 13:08:14 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 761213366496964608,
  "created_at" : "2016-08-04 14:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/761208600450719744\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/RbrZ7YTyc8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpBbLXmVUAAopM9.jpg",
      "id_str" : "761208587897098240",
      "id" : 761208587897098240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpBbLXmVUAAopM9.jpg",
      "sizes" : [ {
        "h" : 1592,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1592,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 933,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/RbrZ7YTyc8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761208986381148160",
  "text" : "RT @FLOTUS: 55 years young and that smile still gets me every single day. Happy birthday, Barack. I love you. -mo https:\/\/t.co\/RbrZ7YTyc8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/761208600450719744\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/RbrZ7YTyc8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpBbLXmVUAAopM9.jpg",
        "id_str" : "761208587897098240",
        "id" : 761208587897098240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpBbLXmVUAAopM9.jpg",
        "sizes" : [ {
          "h" : 1592,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1592,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 933,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/RbrZ7YTyc8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761208600450719744",
    "text" : "55 years young and that smile still gets me every single day. Happy birthday, Barack. I love you. -mo https:\/\/t.co\/RbrZ7YTyc8",
    "id" : 761208600450719744,
    "created_at" : "2016-08-04 14:34:07 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 761208986381148160,
  "created_at" : "2016-08-04 14:35:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/761202295078023168\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/XfX7W3weV5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CpBVaRAW8AAyXCS.jpg",
      "id_str" : "761202246755479552",
      "id" : 761202246755479552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpBVaRAW8AAyXCS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/XfX7W3weV5"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 33, 55 ]
    }, {
      "text" : "CriminalJusticeReform",
      "indices" : [ 86, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761203571060797445",
  "text" : "RT @vj44: Qs on commutations and #CriminalJusticeReform? Ask today by 4:30pm ET using #CriminalJusticeReform https:\/\/t.co\/XfX7W3weV5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/761202295078023168\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/XfX7W3weV5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpBVaRAW8AAyXCS.jpg",
        "id_str" : "761202246755479552",
        "id" : 761202246755479552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpBVaRAW8AAyXCS.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/XfX7W3weV5"
      } ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 23, 45 ]
      }, {
        "text" : "CriminalJusticeReform",
        "indices" : [ 76, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "761202295078023168",
    "text" : "Qs on commutations and #CriminalJusticeReform? Ask today by 4:30pm ET using #CriminalJusticeReform https:\/\/t.co\/XfX7W3weV5",
    "id" : 761202295078023168,
    "created_at" : "2016-08-04 14:09:04 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 761203571060797445,
  "created_at" : "2016-08-04 14:14:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Glamour",
      "screen_name" : "glamourmag",
      "indices" : [ 104, 115 ],
      "id_str" : "19247844",
      "id" : 19247844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YFuqozXcXd",
      "expanded_url" : "http:\/\/glmr.co\/DxSS0vP",
      "display_url" : "glmr.co\/DxSS0vP"
    } ]
  },
  "geo" : { },
  "id_str" : "761200708053966848",
  "text" : "\"It\u2019s important that their dad is a feminist because now that\u2019s what they expect of all men\" \u2014@POTUS in @GlamourMag: https:\/\/t.co\/YFuqozXcXd",
  "id" : 761200708053966848,
  "created_at" : "2016-08-04 14:02:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glamour",
      "screen_name" : "glamourmag",
      "indices" : [ 3, 14 ],
      "id_str" : "19247844",
      "id" : 19247844
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 110, 121 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/OlB6RnrKLF",
      "expanded_url" : "http:\/\/glmr.co\/DxSS0vP",
      "display_url" : "glmr.co\/DxSS0vP"
    } ]
  },
  "geo" : { },
  "id_str" : "761195785346088960",
  "text" : "RT @glamourmag: EXCLUSIVE! This is what feminism looks like, according to the @POTUS: https:\/\/t.co\/OlB6RnrKLF @WhiteHouse https:\/\/t.co\/SSPu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 62, 68 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 94, 105 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/glamourmag\/status\/761170349157482496\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/SSPuwdnOnN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CpA4ZdBWIAA3AfU.jpg",
        "id_str" : "761170346963771392",
        "id" : 761170346963771392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CpA4ZdBWIAA3AfU.jpg",
        "sizes" : [ {
          "h" : 778,
          "resize" : "fit",
          "w" : 1166
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 778,
          "resize" : "fit",
          "w" : 1166
        }, {
          "h" : 778,
          "resize" : "fit",
          "w" : 1166
        } ],
        "display_url" : "pic.twitter.com\/SSPuwdnOnN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/OlB6RnrKLF",
        "expanded_url" : "http:\/\/glmr.co\/DxSS0vP",
        "display_url" : "glmr.co\/DxSS0vP"
      } ]
    },
    "geo" : { },
    "id_str" : "761170349157482496",
    "text" : "EXCLUSIVE! This is what feminism looks like, according to the @POTUS: https:\/\/t.co\/OlB6RnrKLF @WhiteHouse https:\/\/t.co\/SSPuwdnOnN",
    "id" : 761170349157482496,
    "created_at" : "2016-08-04 12:02:07 +0000",
    "user" : {
      "name" : "Glamour",
      "screen_name" : "glamourmag",
      "protected" : false,
      "id_str" : "19247844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717339198500573184\/bZAoy48W_normal.jpg",
      "id" : 19247844,
      "verified" : true
    }
  },
  "id" : 761195785346088960,
  "created_at" : "2016-08-04 13:43:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/QjNeSAgGjx",
      "expanded_url" : "http:\/\/snpy.tv\/2aOjWmN",
      "display_url" : "snpy.tv\/2aOjWmN"
    } ]
  },
  "geo" : { },
  "id_str" : "760975492761739264",
  "text" : "Norman served 20 years of his life sentence before @POTUS granted him clemency. Here are a few lessons he's learned: https:\/\/t.co\/QjNeSAgGjx",
  "id" : 760975492761739264,
  "created_at" : "2016-08-03 23:07:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/o0VQ91erKH",
      "expanded_url" : "http:\/\/go.wh.gov\/V3FxS9",
      "display_url" : "go.wh.gov\/V3FxS9"
    } ]
  },
  "geo" : { },
  "id_str" : "760970610872901632",
  "text" : "RT @petesouza: Slide show from yesterday's State Arrival and Dinner for PM Lee of Singapore:  https:\/\/t.co\/o0VQ91erKH https:\/\/t.co\/SblN6BPU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/760970441137717249\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/SblN6BPUbj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co-Ck5iXgAADvom.jpg",
        "id_str" : "760970432480772096",
        "id" : 760970432480772096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co-Ck5iXgAADvom.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/SblN6BPUbj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/o0VQ91erKH",
        "expanded_url" : "http:\/\/go.wh.gov\/V3FxS9",
        "display_url" : "go.wh.gov\/V3FxS9"
      } ]
    },
    "geo" : { },
    "id_str" : "760970441137717249",
    "text" : "Slide show from yesterday's State Arrival and Dinner for PM Lee of Singapore:  https:\/\/t.co\/o0VQ91erKH https:\/\/t.co\/SblN6BPUbj",
    "id" : 760970441137717249,
    "created_at" : "2016-08-03 22:47:45 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 760970610872901632,
  "created_at" : "2016-08-03 22:48:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760965967958671361\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/uCv8idtr4h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co9-clNUsAQ18yb.jpg",
      "id_str" : "760965891538333700",
      "id" : 760965891538333700,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co9-clNUsAQ18yb.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/uCv8idtr4h"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760965967958671361\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/uCv8idtr4h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co9-clmUAAEeSgY.jpg",
      "id_str" : "760965891643146241",
      "id" : 760965891643146241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co9-clmUAAEeSgY.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/uCv8idtr4h"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760965967958671361\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/uCv8idtr4h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co9-claUAAAV0bA.jpg",
      "id_str" : "760965891592814592",
      "id" : 760965891592814592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co9-claUAAAV0bA.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/uCv8idtr4h"
    } ],
    "hashtags" : [ {
      "text" : "SingaporeVisit",
      "indices" : [ 37, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/DMBPn3rx4M",
      "expanded_url" : "http:\/\/go.wh.gov\/8GUcMS",
      "display_url" : "go.wh.gov\/8GUcMS"
    } ]
  },
  "geo" : { },
  "id_str" : "760965967958671361",
  "text" : "In photos: Get an inside look at the #SingaporeVisit and State Dinner \u2192 https:\/\/t.co\/DMBPn3rx4M https:\/\/t.co\/uCv8idtr4h",
  "id" : 760965967958671361,
  "created_at" : "2016-08-03 22:29:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2016",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/JXajz0cqXI",
      "expanded_url" : "http:\/\/snpy.tv\/2aUi8XZ",
      "display_url" : "snpy.tv\/2aUi8XZ"
    } ]
  },
  "geo" : { },
  "id_str" : "760952182350897152",
  "text" : "Ahead of @POTUS's birthday tomorrow, young leaders sing happy birthday\nduring the #YALI2016 Town Hall: https:\/\/t.co\/JXajz0cqXI",
  "id" : 760952182350897152,
  "created_at" : "2016-08-03 21:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/9CfRfMXfEz",
      "expanded_url" : "http:\/\/snpy.tv\/2aCypiT",
      "display_url" : "snpy.tv\/2aCypiT"
    } ]
  },
  "geo" : { },
  "id_str" : "760948886252818432",
  "text" : "Watch @POTUS give advice to\nyoung African leaders about writing the next chapter of their history: https:\/\/t.co\/9CfRfMXfEz",
  "id" : 760948886252818432,
  "created_at" : "2016-08-03 21:22:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2016",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/fzoAbTCnxB",
      "expanded_url" : "http:\/\/snpy.tv\/2amcuvq",
      "display_url" : "snpy.tv\/2amcuvq"
    } ]
  },
  "geo" : { },
  "id_str" : "760943539383521280",
  "text" : "\"Worry less about what you want to be, worry more about what you want to do.\" \u2014@POTUS to young leaders #YALI2016 https:\/\/t.co\/fzoAbTCnxB",
  "id" : 760943539383521280,
  "created_at" : "2016-08-03 21:00:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2016",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/MmgUUgN1oR",
      "expanded_url" : "http:\/\/snpy.tv\/2aNT869",
      "display_url" : "snpy.tv\/2aNT869"
    } ]
  },
  "geo" : { },
  "id_str" : "760930067266625536",
  "text" : "\"I\u2019ve worked to transform America\u2019s relationship with Africa\u2014so that we\u2019re equal partners.\" \u2014@POTUS #YALI2016 https:\/\/t.co\/MmgUUgN1oR",
  "id" : 760930067266625536,
  "created_at" : "2016-08-03 20:07:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2016",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760921957655257088",
  "text" : "\"We\u2019re doing even more to support American companies that are interested in doing business in Africa\" \u2014@POTUS at #YALI2016 Town Hall",
  "id" : 760921957655257088,
  "created_at" : "2016-08-03 19:35:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760921550967177216",
  "text" : "\"Over the past seven and a half years, I\u2019ve worked to transform America\u2019s relationship with Africa \u2013 so that we\u2019re equal partners.\" \u2014@POTUS",
  "id" : 760921550967177216,
  "created_at" : "2016-08-03 19:33:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760919767964327936\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/Z838oKCwS6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co9UX6EXYAE39CL.jpg",
      "id_str" : "760919631750193153",
      "id" : 760919631750193153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co9UX6EXYAE39CL.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Z838oKCwS6"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760919767964327936\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/Z838oKCwS6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co9UX_CWEAAYRt0.jpg",
      "id_str" : "760919633083895808",
      "id" : 760919633083895808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co9UX_CWEAAYRt0.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      } ],
      "display_url" : "pic.twitter.com\/Z838oKCwS6"
    } ],
    "hashtags" : [ {
      "text" : "YALI2016",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/xEEYyx8tT9",
      "expanded_url" : "http:\/\/go.wh.gov\/YALI",
      "display_url" : "go.wh.gov\/YALI"
    } ]
  },
  "geo" : { },
  "id_str" : "760919767964327936",
  "text" : "Meet Emmanuel Odama from Uganda: Here's why he's introducing @POTUS at #YALI2016 \u2192 https:\/\/t.co\/xEEYyx8tT9 https:\/\/t.co\/Z838oKCwS6",
  "id" : 760919767964327936,
  "created_at" : "2016-08-03 19:26:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YALI2016",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/xEEYywQSuz",
      "expanded_url" : "http:\/\/go.wh.gov\/YALI",
      "display_url" : "go.wh.gov\/YALI"
    } ]
  },
  "geo" : { },
  "id_str" : "760917392901808128",
  "text" : "At 3:20pm ET, watch @POTUS participate in a town hall with young African leaders: https:\/\/t.co\/xEEYywQSuz #YALI2016",
  "id" : 760917392901808128,
  "created_at" : "2016-08-03 19:16:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760913461182214144\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/uvDIX5S4ZN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co9Arr5WEAAbYlf.jpg",
      "id_str" : "760897981310701568",
      "id" : 760897981310701568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co9Arr5WEAAbYlf.jpg",
      "sizes" : [ {
        "h" : 570,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/uvDIX5S4ZN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/eNv6u2mETH",
      "expanded_url" : "http:\/\/go.wh.gov\/clemency",
      "display_url" : "go.wh.gov\/clemency"
    } ]
  },
  "geo" : { },
  "id_str" : "760913461182214144",
  "text" : "FACT: @POTUS has commuted the sentences of more people than the past 9 presidents combined: https:\/\/t.co\/eNv6u2mETH https:\/\/t.co\/uvDIX5S4ZN",
  "id" : 760913461182214144,
  "created_at" : "2016-08-03 19:01:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760906004338872321\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/5FNwTo2lan",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co9Aj7gXYAQjlPP.jpg",
      "id_str" : "760897848061943812",
      "id" : 760897848061943812,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co9Aj7gXYAQjlPP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 558
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 558
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 558
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 542
      } ],
      "display_url" : "pic.twitter.com\/5FNwTo2lan"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/2CzoA4CDRt",
      "expanded_url" : "http:\/\/go.wh.gov\/w3Gvx1",
      "display_url" : "go.wh.gov\/w3Gvx1"
    } ]
  },
  "geo" : { },
  "id_str" : "760906004338872321",
  "text" : "\"This is a country that believes in second chances.\" \u2014@POTUS on granting clemency: https:\/\/t.co\/2CzoA4CDRt https:\/\/t.co\/5FNwTo2lan",
  "id" : 760906004338872321,
  "created_at" : "2016-08-03 18:31:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blavity",
      "screen_name" : "Blavity",
      "indices" : [ 3, 11 ],
      "id_str" : "2466899838",
      "id" : 2466899838
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 91, 102 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/tCRoWU3pyg",
      "expanded_url" : "http:\/\/bit.ly\/2aJ2rDq",
      "display_url" : "bit.ly\/2aJ2rDq"
    } ]
  },
  "geo" : { },
  "id_str" : "760904612945727488",
  "text" : "RT @Blavity: Exclusive: @POTUS just commuted 214 people \u2014 here's one former inmate's story @whitehouse https:\/\/t.co\/tCRoWU3pyg https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 78, 89 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Blavity\/status\/760896919266811904\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/L1wu1a6DK2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8_to3WIAA_f8f.jpg",
        "id_str" : "760896915345121280",
        "id" : 760896915345121280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8_to3WIAA_f8f.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 873,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 818,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 873,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/L1wu1a6DK2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/tCRoWU3pyg",
        "expanded_url" : "http:\/\/bit.ly\/2aJ2rDq",
        "display_url" : "bit.ly\/2aJ2rDq"
      } ]
    },
    "geo" : { },
    "id_str" : "760896919266811904",
    "text" : "Exclusive: @POTUS just commuted 214 people \u2014 here's one former inmate's story @whitehouse https:\/\/t.co\/tCRoWU3pyg https:\/\/t.co\/L1wu1a6DK2",
    "id" : 760896919266811904,
    "created_at" : "2016-08-03 17:55:36 +0000",
    "user" : {
      "name" : "Blavity",
      "screen_name" : "Blavity",
      "protected" : false,
      "id_str" : "2466899838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671707874524053504\/xUBCl5Dn_normal.png",
      "id" : 2466899838,
      "verified" : false
    }
  },
  "id" : 760904612945727488,
  "created_at" : "2016-08-03 18:26:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/eNv6u2mETH",
      "expanded_url" : "http:\/\/go.wh.gov\/clemency",
      "display_url" : "go.wh.gov\/clemency"
    } ]
  },
  "geo" : { },
  "id_str" : "760900596417241091",
  "text" : "Today @POTUS commuted the sentences of 214 people\u2014the most grants in a single day since at least 1900: https:\/\/t.co\/eNv6u2mETH",
  "id" : 760900596417241091,
  "created_at" : "2016-08-03 18:10:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 45, 51 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760896469188706304\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/AM74zZh97u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8-t3FXYAAv27r.jpg",
      "id_str" : "760895819650392064",
      "id" : 760895819650392064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8-t3FXYAAv27r.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/AM74zZh97u"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/eNv6u25429",
      "expanded_url" : "http:\/\/go.wh.gov\/clemency",
      "display_url" : "go.wh.gov\/clemency"
    } ]
  },
  "geo" : { },
  "id_str" : "760896469188706304",
  "text" : "America is a nation of second chances. Today @POTUS granted clemency to 214 men and women: https:\/\/t.co\/eNv6u25429 https:\/\/t.co\/AM74zZh97u",
  "id" : 760896469188706304,
  "created_at" : "2016-08-03 17:53:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760892710731517953\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/mpr78ANJvX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co87b6sWIAAcfVo.jpg",
      "id_str" : "760892212846665728",
      "id" : 760892212846665728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co87b6sWIAAcfVo.jpg",
      "sizes" : [ {
        "h" : 570,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 570,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/mpr78ANJvX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760892710731517953",
  "text" : "BREAKING: @POTUS just commuted the sentences of 214 additional people, surpassing the past 9 presidents combined. https:\/\/t.co\/mpr78ANJvX",
  "id" : 760892710731517953,
  "created_at" : "2016-08-03 17:38:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 11, 22 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/760883719297232896\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/rIFHHdMbjA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co8zbgJXEAALd-s.jpg",
      "id_str" : "760883409627582464",
      "id" : 760883409627582464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co8zbgJXEAALd-s.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/rIFHHdMbjA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/ZxTvfEbNmi",
      "expanded_url" : "http:\/\/go.wh.gov\/tuKBf4",
      "display_url" : "go.wh.gov\/tuKBf4"
    } ]
  },
  "geo" : { },
  "id_str" : "760883719297232896",
  "text" : "Good news: @USTreasury just took action to ensure our tax code helps middle-class Americans: https:\/\/t.co\/ZxTvfEbNmi https:\/\/t.co\/rIFHHdMbjA",
  "id" : 760883719297232896,
  "created_at" : "2016-08-03 17:03:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "indices" : [ 3, 13 ],
      "id_str" : "4796005523",
      "id" : 4796005523
    }, {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 27, 38 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760850265356443653",
  "text" : "RT @Charlie44: Good stuff! @USTreasury cracks down on estate tax loophole that allows wealthy to avoid paying their fair share: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Treasury Department",
        "screen_name" : "USTreasury",
        "indices" : [ 12, 23 ],
        "id_str" : "120176950",
        "id" : 120176950
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/K9dubi0qfQ",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/08\/03\/closing-estate-tax-loophole-wealthiest-few-what-you-need-know",
        "display_url" : "whitehouse.gov\/blog\/2016\/08\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760848663467859969",
    "text" : "Good stuff! @USTreasury cracks down on estate tax loophole that allows wealthy to avoid paying their fair share: https:\/\/t.co\/K9dubi0qfQ",
    "id" : 760848663467859969,
    "created_at" : "2016-08-03 14:43:51 +0000",
    "user" : {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "protected" : false,
      "id_str" : "4796005523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689598827691520000\/6gRd26qn_normal.jpg",
      "id" : 4796005523,
      "verified" : true
    }
  },
  "id" : 760850265356443653,
  "created_at" : "2016-08-03 14:50:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Futurism",
      "screen_name" : "futurism",
      "indices" : [ 3, 12 ],
      "id_str" : "2557446343",
      "id" : 2557446343
    }, {
      "name" : "National Science Fdn",
      "screen_name" : "NSF",
      "indices" : [ 18, 22 ],
      "id_str" : "16245822",
      "id" : 16245822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/futurism\/status\/760615016194199552\/video\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/yHXvsxs3dl",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760614089039065088\/pu\/img\/zXHYJZEPjH_IQ6L7.jpg",
      "id_str" : "760614089039065088",
      "id" : 760614089039065088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760614089039065088\/pu\/img\/zXHYJZEPjH_IQ6L7.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yHXvsxs3dl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760621703449849856",
  "text" : "RT @futurism: The @NSF will invest $35 million to help advance and integrate drones into our everyday lives. https:\/\/t.co\/yHXvsxs3dl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Science Fdn",
        "screen_name" : "NSF",
        "indices" : [ 4, 8 ],
        "id_str" : "16245822",
        "id" : 16245822
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/futurism\/status\/760615016194199552\/video\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/yHXvsxs3dl",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760614089039065088\/pu\/img\/zXHYJZEPjH_IQ6L7.jpg",
        "id_str" : "760614089039065088",
        "id" : 760614089039065088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/760614089039065088\/pu\/img\/zXHYJZEPjH_IQ6L7.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/yHXvsxs3dl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760615016194199552",
    "text" : "The @NSF will invest $35 million to help advance and integrate drones into our everyday lives. https:\/\/t.co\/yHXvsxs3dl",
    "id" : 760615016194199552,
    "created_at" : "2016-08-02 23:15:26 +0000",
    "user" : {
      "name" : "Futurism",
      "screen_name" : "futurism",
      "protected" : false,
      "id_str" : "2557446343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735546307021033477\/v2U3XIrD_normal.jpg",
      "id" : 2557446343,
      "verified" : true
    }
  },
  "id" : 760621703449849856,
  "created_at" : "2016-08-02 23:42:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 17, 24 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Lee Hsien Loong",
      "screen_name" : "leehsienloong",
      "indices" : [ 46, 60 ],
      "id_str" : "34568673",
      "id" : 34568673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/aD1dNCsn9e",
      "expanded_url" : "http:\/\/snpy.tv\/2aydmh8",
      "display_url" : "snpy.tv\/2aydmh8"
    } ]
  },
  "geo" : { },
  "id_str" : "760613240577622016",
  "text" : "Watch @POTUS and @FLOTUS welcome Singapore PM @leehsienloong and Mrs. Lee for tonight's State Dinner: https:\/\/t.co\/aD1dNCsn9e",
  "id" : 760613240577622016,
  "created_at" : "2016-08-02 23:08:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 20, 27 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Lee Hsien Loong",
      "screen_name" : "leehsienloong",
      "indices" : [ 47, 61 ],
      "id_str" : "34568673",
      "id" : 34568673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/JBVNESR5V1",
      "expanded_url" : "http:\/\/go.wh.gov\/zDrrgh",
      "display_url" : "go.wh.gov\/zDrrgh"
    } ]
  },
  "geo" : { },
  "id_str" : "760610905734443008",
  "text" : "Tune in: @POTUS and @FLOTUS greet Singapore PM @leehsienloong and Mrs. Lee ahead of tonight's State Dinner \u2192 https:\/\/t.co\/JBVNESR5V1",
  "id" : 760610905734443008,
  "created_at" : "2016-08-02 22:59:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760601897510121472\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/7IT3sy6cM6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co4ySRuUsAESO1R.jpg",
      "id_str" : "760600676648923137",
      "id" : 760600676648923137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co4ySRuUsAESO1R.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/7IT3sy6cM6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ReMTYGgSdD",
      "expanded_url" : "http:\/\/go.wh.gov\/drones",
      "display_url" : "go.wh.gov\/drones"
    } ]
  },
  "geo" : { },
  "id_str" : "760601897510121472",
  "text" : "Today, we announced new actions to help America\u2019s commercial drone industry take flight: https:\/\/t.co\/ReMTYGgSdD https:\/\/t.co\/7IT3sy6cM6",
  "id" : 760601897510121472,
  "created_at" : "2016-08-02 22:23:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760586471573037056",
  "text" : "RT @FLOTUS: Dear Major Haynes: You\u2019re Invited. Read the story of two special guests at tonight\u2019s Singapore State Dinner:  https:\/\/t.co\/LZVu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/LZVu0MOcjq",
        "expanded_url" : "http:\/\/go.wh.gov\/k6txuv",
        "display_url" : "go.wh.gov\/k6txuv"
      } ]
    },
    "geo" : { },
    "id_str" : "760585964771172352",
    "text" : "Dear Major Haynes: You\u2019re Invited. Read the story of two special guests at tonight\u2019s Singapore State Dinner:  https:\/\/t.co\/LZVu0MOcjq",
    "id" : 760585964771172352,
    "created_at" : "2016-08-02 21:19:59 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 760586471573037056,
  "created_at" : "2016-08-02 21:22:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "Rio2016",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760582877801308160",
  "text" : "RT @JohnKerry: Proud to lead the US delegation &amp; support #TeamUSA at the #Rio2016 Olympic Games. I\u2019ve been practicing just in case\u2026 https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/760522616310554624\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/OgZ3vfzMtb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3rLnQWAAAHzQd.jpg",
        "id_str" : "760522496844103680",
        "id" : 760522496844103680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3rLnQWAAAHzQd.jpg",
        "sizes" : [ {
          "h" : 796,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1358,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1358,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/OgZ3vfzMtb"
      } ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 46, 54 ]
      }, {
        "text" : "Rio2016",
        "indices" : [ 62, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760522616310554624",
    "text" : "Proud to lead the US delegation &amp; support #TeamUSA at the #Rio2016 Olympic Games. I\u2019ve been practicing just in case\u2026 https:\/\/t.co\/OgZ3vfzMtb",
    "id" : 760522616310554624,
    "created_at" : "2016-08-02 17:08:16 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 760582877801308160,
  "created_at" : "2016-08-02 21:07:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Hsien Loong",
      "screen_name" : "leehsienloong",
      "indices" : [ 59, 73 ],
      "id_str" : "34568673",
      "id" : 34568673
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 81, 91 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760549783861886978\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/944RMl1WR4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co4DpyqXYAANPYK.jpg",
      "id_str" : "760549403581177856",
      "id" : 760549403581177856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co4DpyqXYAANPYK.jpg",
      "sizes" : [ {
        "h" : 792,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1426,
        "resize" : "fit",
        "w" : 2160
      }, {
        "h" : 1352,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/944RMl1WR4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/KyRFFZ6lzH",
      "expanded_url" : "http:\/\/go.wh.gov\/PxmxUv",
      "display_url" : "go.wh.gov\/PxmxUv"
    } ]
  },
  "geo" : { },
  "id_str" : "760549783861886978",
  "text" : "Go behind the scenes of Singapore\u2019s official visit with PM @leehsienloong on our @Instagram: https:\/\/t.co\/KyRFFZ6lzH https:\/\/t.co\/944RMl1WR4",
  "id" : 760549783861886978,
  "created_at" : "2016-08-02 18:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760527246335639554",
  "text" : "RT @Denis44: Commercial drones have enormous potential to help address civic problems\u2014from fighting fires to advancing health: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/760491313611452417\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/D4LqslsFom",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3OwIRUMAAHXQd.jpg",
        "id_str" : "760491238344634368",
        "id" : 760491238344634368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3OwIRUMAAHXQd.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/D4LqslsFom"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "760491043473199106",
    "geo" : { },
    "id_str" : "760491313611452417",
    "in_reply_to_user_id" : 3093573484,
    "text" : "Commercial drones have enormous potential to help address civic problems\u2014from fighting fires to advancing health: https:\/\/t.co\/D4LqslsFom",
    "id" : 760491313611452417,
    "in_reply_to_status_id" : 760491043473199106,
    "created_at" : "2016-08-02 15:03:53 +0000",
    "in_reply_to_screen_name" : "Denis44",
    "in_reply_to_user_id_str" : "3093573484",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 760527246335639554,
  "created_at" : "2016-08-02 17:26:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760526258870456320",
  "text" : "RT @rhodes44: As Singapore visit demonstrates @POTUS commitment to Asia, so will upcoming engagements with Laos and Burma. https:\/\/t.co\/NJZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 32, 38 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/NJZ8rMMah7",
        "expanded_url" : "https:\/\/medium.com\/@rhodes44\/what-the-presidents-visits-to-laos-and-burma-reveal-about-his-foreign-policy-3de1bf24e8cc#.raitqpj9s",
        "display_url" : "medium.com\/@rhodes44\/what\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760496288739700740",
    "text" : "As Singapore visit demonstrates @POTUS commitment to Asia, so will upcoming engagements with Laos and Burma. https:\/\/t.co\/NJZ8rMMah7",
    "id" : 760496288739700740,
    "created_at" : "2016-08-02 15:23:39 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 760526258870456320,
  "created_at" : "2016-08-02 17:22:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 20, 29 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760516465439236097\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/HnucVK3Fyz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3kNEuVUAA3EoL.jpg",
      "id_str" : "760514825352990720",
      "id" : 760514825352990720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3kNEuVUAA3EoL.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/HnucVK3Fyz"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760516465439236097\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/HnucVK3Fyz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3kNEvVMAAy_7v.jpg",
      "id_str" : "760514825357176832",
      "id" : 760514825357176832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3kNEvVMAAy_7v.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/HnucVK3Fyz"
    } ],
    "hashtags" : [ {
      "text" : "SingaporeVisit",
      "indices" : [ 70, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760516465439236097",
  "text" : "Add 'WhiteHouse' on @Snapchat to go behind the scenes of the official #SingaporeVisit. https:\/\/t.co\/HnucVK3Fyz",
  "id" : 760516465439236097,
  "created_at" : "2016-08-02 16:43:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "indices" : [ 3, 13 ],
      "id_str" : "1665298740",
      "id" : 1665298740
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760502852976517120",
  "text" : "RT @Hoffine44: .@POTUS: #TPP will \"grow our economies &amp; write the rules for trade in the 21st century in a way that's equitable\" https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 9, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/uMcBOspmMc",
        "expanded_url" : "http:\/\/snpy.tv\/2ax8hpl",
        "display_url" : "snpy.tv\/2ax8hpl"
      } ]
    },
    "geo" : { },
    "id_str" : "760499979395792896",
    "text" : ".@POTUS: #TPP will \"grow our economies &amp; write the rules for trade in the 21st century in a way that's equitable\" https:\/\/t.co\/uMcBOspmMc",
    "id" : 760499979395792896,
    "created_at" : "2016-08-02 15:38:19 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 760502852976517120,
  "created_at" : "2016-08-02 15:49:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760495519193890816",
  "text" : "\"This is an opportunity to grow our economies and write the rules of trade in the 21st century.\" \u2014@POTUS on the Trans-Pacific Partnership",
  "id" : 760495519193890816,
  "created_at" : "2016-08-02 15:20:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Lee Hsien Loong",
      "screen_name" : "leehsienloong",
      "indices" : [ 25, 39 ],
      "id_str" : "34568673",
      "id" : 34568673
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 73, 84 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Singapore",
      "indices" : [ 43, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760495025226674176",
  "text" : "RT @Price44: .@POTUS and @leehsienloong of #Singapore hold a press conf. @WhiteHouse following bilateral meetings this morning. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Lee Hsien Loong",
        "screen_name" : "leehsienloong",
        "indices" : [ 12, 26 ],
        "id_str" : "34568673",
        "id" : 34568673
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 60, 71 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/760494964702846977\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/dBXcKQNDVD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co3SEOAUAAAY50p.jpg",
        "id_str" : "760494882016198656",
        "id" : 760494882016198656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co3SEOAUAAAY50p.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/dBXcKQNDVD"
      } ],
      "hashtags" : [ {
        "text" : "Singapore",
        "indices" : [ 30, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760494964702846977",
    "text" : ".@POTUS and @leehsienloong of #Singapore hold a press conf. @WhiteHouse following bilateral meetings this morning. https:\/\/t.co\/dBXcKQNDVD",
    "id" : 760494964702846977,
    "created_at" : "2016-08-02 15:18:23 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 760495025226674176,
  "created_at" : "2016-08-02 15:18:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760494646724362240",
  "text" : "RT @WHLive: \u201CSingapore is an anchor for the U.S. presence in the region, which is a foundation of stability and peace.\u201D \u2014@POTUS with PM @le\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 109, 115 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Lee Hsien Loong",
        "screen_name" : "leehsienloong",
        "indices" : [ 124, 138 ],
        "id_str" : "34568673",
        "id" : 34568673
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760494525966061568",
    "text" : "\u201CSingapore is an anchor for the U.S. presence in the region, which is a foundation of stability and peace.\u201D \u2014@POTUS with PM @leehsienloong",
    "id" : 760494525966061568,
    "created_at" : "2016-08-02 15:16:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760494646724362240,
  "created_at" : "2016-08-02 15:17:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Lee Hsien Loong",
      "screen_name" : "leehsienloong",
      "indices" : [ 39, 53 ],
      "id_str" : "34568673",
      "id" : 34568673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/JBVNET8GMz",
      "expanded_url" : "http:\/\/go.wh.gov\/zDrrgh",
      "display_url" : "go.wh.gov\/zDrrgh"
    } ]
  },
  "geo" : { },
  "id_str" : "760494227079909376",
  "text" : "Happening now: @POTUS and Singapore PM @leehsienloong hold a joint press conference: https:\/\/t.co\/JBVNET8GMz",
  "id" : 760494227079909376,
  "created_at" : "2016-08-02 15:15:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "indices" : [ 76, 89 ],
      "id_str" : "18023868",
      "id" : 18023868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760485239969853440",
  "text" : "RT @vj44: Thanks Massachusetts legislature for your leadership and congrats @MassGovernor for making equal pay a reality in your state!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie Baker",
        "screen_name" : "MassGovernor",
        "indices" : [ 66, 79 ],
        "id_str" : "18023868",
        "id" : 18023868
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760481135281528832",
    "text" : "Thanks Massachusetts legislature for your leadership and congrats @MassGovernor for making equal pay a reality in your state!",
    "id" : 760481135281528832,
    "created_at" : "2016-08-02 14:23:26 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 760485239969853440,
  "created_at" : "2016-08-02 14:39:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "NASA Aeronautics",
      "screen_name" : "NASAAero",
      "indices" : [ 64, 73 ],
      "id_str" : "2734381938",
      "id" : 2734381938
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 75, 90 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "The FAA",
      "screen_name" : "FAANews",
      "indices" : [ 92, 100 ],
      "id_str" : "160946337",
      "id" : 160946337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Drones",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/mzKW5uV4hS",
      "expanded_url" : "http:\/\/www.nasa.gov\/live",
      "display_url" : "nasa.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "760474506708324352",
  "text" : "RT @NASA: LIVE NOW: Explore #Drones &amp; future of aviation w\/ @NASAAero, @WhiteHouseOSTP, @FAANews: https:\/\/t.co\/mzKW5uV4hS https:\/\/t.co\/YbpU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA Aeronautics",
        "screen_name" : "NASAAero",
        "indices" : [ 54, 63 ],
        "id_str" : "2734381938",
        "id" : 2734381938
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 65, 80 ],
        "id_str" : "33998183",
        "id" : 33998183
      }, {
        "name" : "The FAA",
        "screen_name" : "FAANews",
        "indices" : [ 82, 90 ],
        "id_str" : "160946337",
        "id" : 160946337
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/760461780200067072\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/YbpUmZyuH1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co2z9TgWIAAHnel.jpg",
        "id_str" : "760461777884815360",
        "id" : 760461777884815360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co2z9TgWIAAHnel.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/YbpUmZyuH1"
      } ],
      "hashtags" : [ {
        "text" : "Drones",
        "indices" : [ 18, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/mzKW5uV4hS",
        "expanded_url" : "http:\/\/www.nasa.gov\/live",
        "display_url" : "nasa.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "760461780200067072",
    "text" : "LIVE NOW: Explore #Drones &amp; future of aviation w\/ @NASAAero, @WhiteHouseOSTP, @FAANews: https:\/\/t.co\/mzKW5uV4hS https:\/\/t.co\/YbpUmZyuH1",
    "id" : 760461780200067072,
    "created_at" : "2016-08-02 13:06:31 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 760474506708324352,
  "created_at" : "2016-08-02 13:57:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Lee Hsien Loong",
      "screen_name" : "leehsienloong",
      "indices" : [ 113, 127 ],
      "id_str" : "34568673",
      "id" : 34568673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760468034872086528",
  "text" : "\u201CWe draw strength from our people, two societies built on multiculturalism and merit.\u201D \u2014@POTUS with Singapore PM @leehsienloong",
  "id" : 760468034872086528,
  "created_at" : "2016-08-02 13:31:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SingaporeVisit",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760467342367129600",
  "text" : "RT @WHLive: \u201CThis marks the first official state visit by a Singaporean prime minister in over 30 years.\u201D \u2014@POTUS #SingaporeVisit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 95, 101 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SingaporeVisit",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760467198489964544",
    "text" : "\u201CThis marks the first official state visit by a Singaporean prime minister in over 30 years.\u201D \u2014@POTUS #SingaporeVisit",
    "id" : 760467198489964544,
    "created_at" : "2016-08-02 13:28:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760467342367129600,
  "created_at" : "2016-08-02 13:28:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SingaporeVisit",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/JBVNET8GMz",
      "expanded_url" : "http:\/\/go.wh.gov\/zDrrgh",
      "display_url" : "go.wh.gov\/zDrrgh"
    } ]
  },
  "geo" : { },
  "id_str" : "760467075148034048",
  "text" : "\u201CI am honored to welcome Prime Minister Lee and Mrs. Lee to the United States.\u201D \u2014@POTUS: https:\/\/t.co\/JBVNET8GMz #SingaporeVisit",
  "id" : 760467075148034048,
  "created_at" : "2016-08-02 13:27:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 24, 31 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Lee Hsien Loong",
      "screen_name" : "leehsienloong",
      "indices" : [ 54, 68 ],
      "id_str" : "34568673",
      "id" : 34568673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/7MjisF89w7",
      "expanded_url" : "http:\/\/go.wh.gov\/zDrrgh",
      "display_url" : "go.wh.gov\/zDrrgh"
    } ]
  },
  "geo" : { },
  "id_str" : "760462587611848704",
  "text" : "RT @WHLive: .@POTUS and @FLOTUS  welcome Singapore PM @leehsienloong and\nMrs. Lee to the White House \u2192 https:\/\/t.co\/7MjisF89w7 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 12, 19 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Lee Hsien Loong",
        "screen_name" : "leehsienloong",
        "indices" : [ 42, 56 ],
        "id_str" : "34568673",
        "id" : 34568673
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/760462499812487169\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/WwGUksGReo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Co2zLNAXEAAt3fT.jpg",
        "id_str" : "760460917146587136",
        "id" : 760460917146587136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Co2zLNAXEAAt3fT.jpg",
        "sizes" : [ {
          "h" : 477,
          "resize" : "fit",
          "w" : 845
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 845
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 845
        } ],
        "display_url" : "pic.twitter.com\/WwGUksGReo"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/7MjisF89w7",
        "expanded_url" : "http:\/\/go.wh.gov\/zDrrgh",
        "display_url" : "go.wh.gov\/zDrrgh"
      } ]
    },
    "geo" : { },
    "id_str" : "760462499812487169",
    "text" : ".@POTUS and @FLOTUS  welcome Singapore PM @leehsienloong and\nMrs. Lee to the White House \u2192 https:\/\/t.co\/7MjisF89w7 https:\/\/t.co\/WwGUksGReo",
    "id" : 760462499812487169,
    "created_at" : "2016-08-02 13:09:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760462587611848704,
  "created_at" : "2016-08-02 13:09:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 31, 38 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Lee Hsien Loong",
      "screen_name" : "leehsienloong",
      "indices" : [ 60, 74 ],
      "id_str" : "34568673",
      "id" : 34568673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/JBVNESR5V1",
      "expanded_url" : "http:\/\/go.wh.gov\/zDrrgh",
      "display_url" : "go.wh.gov\/zDrrgh"
    } ]
  },
  "geo" : { },
  "id_str" : "760458574095081473",
  "text" : "At 9:00am ET, watch @POTUS and @FLOTUS welcome Singapore PM @LeeHsienLoong and\nMrs. Lee to the White House \u2192 https:\/\/t.co\/JBVNESR5V1",
  "id" : 760458574095081473,
  "created_at" : "2016-08-02 12:53:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ADA26",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/EMIGZvLlu2",
      "expanded_url" : "http:\/\/snpy.tv\/2aXYvxD",
      "display_url" : "snpy.tv\/2aXYvxD"
    } ]
  },
  "geo" : { },
  "id_str" : "760261350601830402",
  "text" : "\u201CThe ADA to me is so important because it creates a community. It creates a family.\u201D Inside the East Wing on #ADA26: https:\/\/t.co\/EMIGZvLlu2",
  "id" : 760261350601830402,
  "created_at" : "2016-08-01 23:50:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760250957179465728",
  "text" : "RT @VP: Proud to marry Brian and Joe at my house. Couldn't be happier, two longtime White House staffers, two great guys. https:\/\/t.co\/0om1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/760250205191012352\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/0om1PT7bKh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CozzXa9WIAAmlTO.jpg",
        "id_str" : "760250020817936384",
        "id" : 760250020817936384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CozzXa9WIAAmlTO.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/0om1PT7bKh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760250205191012352",
    "text" : "Proud to marry Brian and Joe at my house. Couldn't be happier, two longtime White House staffers, two great guys. https:\/\/t.co\/0om1PT7bKh",
    "id" : 760250205191012352,
    "created_at" : "2016-08-01 23:05:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 760250957179465728,
  "created_at" : "2016-08-01 23:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/8k4avKlocb",
      "expanded_url" : "http:\/\/bit.ly\/2apPX0w",
      "display_url" : "bit.ly\/2apPX0w"
    } ]
  },
  "geo" : { },
  "id_str" : "760249036091686912",
  "text" : "\"It\u2019s through your sacrifices that this country we love remains free and strong.\" \u2014@POTUS to America's veterans: https:\/\/t.co\/8k4avKlocb",
  "id" : 760249036091686912,
  "created_at" : "2016-08-01 23:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/gZga6swBZe",
      "expanded_url" : "http:\/\/vets.gov",
      "display_url" : "vets.gov"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/MQJiRQ5CRQ",
      "expanded_url" : "http:\/\/snpy.tv\/2aXtPwo",
      "display_url" : "snpy.tv\/2aXtPwo"
    } ]
  },
  "geo" : { },
  "id_str" : "760241362541260800",
  "text" : "Here's how we're making it easier for veterans to access the care they need through https:\/\/t.co\/gZga6swBZe: https:\/\/t.co\/MQJiRQ5CRQ",
  "id" : 760241362541260800,
  "created_at" : "2016-08-01 22:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 96, 102 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/MQJiRQ5CRQ",
      "expanded_url" : "http:\/\/snpy.tv\/2aXtPwo",
      "display_url" : "snpy.tv\/2aXtPwo"
    } ]
  },
  "geo" : { },
  "id_str" : "760238442991058944",
  "text" : "\u201CI do have to point out\u2014Republicans in Congress have proposed cutting my VA budget.\u201D \u2014@POTUS at @DAVHQ https:\/\/t.co\/MQJiRQ5CRQ",
  "id" : 760238442991058944,
  "created_at" : "2016-08-01 22:19:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Task & Purpose",
      "screen_name" : "TaskandPurpose",
      "indices" : [ 3, 18 ],
      "id_str" : "2374466929",
      "id" : 2374466929
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TaskandPurpose\/status\/760219310094688256\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/S795ETZaR7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CozXbo6WIAE6f5Z.jpg",
      "id_str" : "760219306957348865",
      "id" : 760219306957348865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CozXbo6WIAE6f5Z.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/S795ETZaR7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/q7LexBuEIy",
      "expanded_url" : "http:\/\/bit.ly\/2apPX0w",
      "display_url" : "bit.ly\/2apPX0w"
    } ]
  },
  "geo" : { },
  "id_str" : "760226603247013888",
  "text" : "RT @TaskandPurpose: An Exclusive From @POTUS: Keeping Our Covenant With America\u2019s Veterans https:\/\/t.co\/q7LexBuEIy https:\/\/t.co\/S795ETZaR7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 18, 24 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TaskandPurpose\/status\/760219310094688256\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/S795ETZaR7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CozXbo6WIAE6f5Z.jpg",
        "id_str" : "760219306957348865",
        "id" : 760219306957348865,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CozXbo6WIAE6f5Z.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/S795ETZaR7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/q7LexBuEIy",
        "expanded_url" : "http:\/\/bit.ly\/2apPX0w",
        "display_url" : "bit.ly\/2apPX0w"
      } ]
    },
    "geo" : { },
    "id_str" : "760219310094688256",
    "text" : "An Exclusive From @POTUS: Keeping Our Covenant With America\u2019s Veterans https:\/\/t.co\/q7LexBuEIy https:\/\/t.co\/S795ETZaR7",
    "id" : 760219310094688256,
    "created_at" : "2016-08-01 21:03:02 +0000",
    "user" : {
      "name" : "Task & Purpose",
      "screen_name" : "TaskandPurpose",
      "protected" : false,
      "id_str" : "2374466929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468484928095535104\/-7y8-9Pu_normal.png",
      "id" : 2374466929,
      "verified" : false
    }
  },
  "id" : 760226603247013888,
  "created_at" : "2016-08-01 21:32:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 87, 93 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DAVets16",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/18Pmqh9HXU",
      "expanded_url" : "http:\/\/snpy.tv\/2acUQi5",
      "display_url" : "snpy.tv\/2acUQi5"
    } ]
  },
  "geo" : { },
  "id_str" : "760220290215452672",
  "text" : "\"No war should ever be forgotten and no veteran should ever be overlooked.\" \u2014@POTUS at @DAVHQ #DAVets16 https:\/\/t.co\/18Pmqh9HXU",
  "id" : 760220290215452672,
  "created_at" : "2016-08-01 21:06:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/t5oElG6szB",
      "expanded_url" : "http:\/\/snpy.tv\/2asAZdK",
      "display_url" : "snpy.tv\/2asAZdK"
    } ]
  },
  "geo" : { },
  "id_str" : "760196156617920512",
  "text" : "\"No one\u2014no one\u2014has given more for our freedom and security than our Gold Star families.\" \u2014@POTUS https:\/\/t.co\/t5oElG6szB",
  "id" : 760196156617920512,
  "created_at" : "2016-08-01 19:31:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/MQJiRQ5CRQ",
      "expanded_url" : "http:\/\/snpy.tv\/2aXtPwo",
      "display_url" : "snpy.tv\/2aXtPwo"
    } ]
  },
  "geo" : { },
  "id_str" : "760192921643515905",
  "text" : "\"Don\u2019t just talk about standing with veterans\u2014don\u2019t just talk about me\u2014do something to support our veterans\" \u2014@POTUS https:\/\/t.co\/MQJiRQ5CRQ",
  "id" : 760192921643515905,
  "created_at" : "2016-08-01 19:18:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DAVets16",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/P0elMg1yW6",
      "expanded_url" : "http:\/\/snpy.tv\/2aHOMgW",
      "display_url" : "snpy.tv\/2aHOMgW"
    } ]
  },
  "geo" : { },
  "id_str" : "760187522664148992",
  "text" : "\u201CWe\u2019ve increased funding for veterans mental health care by more than 75%\u2014billions more dollars\" \u2014@POTUS #DAVets16 https:\/\/t.co\/P0elMg1yW6",
  "id" : 760187522664148992,
  "created_at" : "2016-08-01 18:56:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DAVets16",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/Vbkb1li4kq",
      "expanded_url" : "http:\/\/snpy.tv\/2aHQ1wG",
      "display_url" : "snpy.tv\/2aHQ1wG"
    } ]
  },
  "geo" : { },
  "id_str" : "760185052122771456",
  "text" : "\"If you want dedication, if you want to get the job done, hire a vet! Hire a military spouse!\u201D \u2014@POTUS #DAVets16 https:\/\/t.co\/Vbkb1li4kq",
  "id" : 760185052122771456,
  "created_at" : "2016-08-01 18:46:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 118, 124 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760177728997957637",
  "text" : "\"When we take care of each other, when we uphold that sacred covenant, then there is nothing we can\u2019t do.\" \u2014@POTUS at @DAVHQ.",
  "id" : 760177728997957637,
  "created_at" : "2016-08-01 18:17:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 122, 128 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760177188251508736",
  "text" : "\u201CTo every company in America\u2014if you want talent, if you want dedication...hire a vet! Hire a military spouse!\u201D \u2014@POTUS at @DAVHQ",
  "id" : 760177188251508736,
  "created_at" : "2016-08-01 18:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760177045078802437\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/LKFyeuIIyc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coyw-2HUMAAeszC.jpg",
      "id_str" : "760177030843346944",
      "id" : 760177030843346944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coyw-2HUMAAeszC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/LKFyeuIIyc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760177045078802437",
  "text" : "\u201CWe\u2019ve cut veterans unemployment by more than half\u2014down to 4.2 percent...lower than the national average.\" \u2014@POTUS https:\/\/t.co\/LKFyeuIIyc",
  "id" : 760177045078802437,
  "created_at" : "2016-08-01 18:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 132, 138 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760176711342264320",
  "text" : "\u201CStarting this fall, we\u2019ll close loopholes to protect our troops and military families from predatory pay-day lenders. \u201D \u2014@POTUS at @DAVHQ",
  "id" : 760176711342264320,
  "created_at" : "2016-08-01 18:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/760176432546930688\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/RnznDWwkDy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoywTmAVIAIxH7x.jpg",
      "id_str" : "760176287784706050",
      "id" : 760176287784706050,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoywTmAVIAIxH7x.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/RnznDWwkDy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760176432546930688",
  "text" : "\u201CWe\u2019ve helped more than 1.6 million veterans and their families realize their dream of an education.\" \u2014@POTUS https:\/\/t.co\/RnznDWwkDy",
  "id" : 760176432546930688,
  "created_at" : "2016-08-01 18:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760176201465856000",
  "text" : "\u201CWe will not stop until every veteran who fought for America has a home in America. This is something we've got to get done.\u201D \u2014@POTUS",
  "id" : 760176201465856000,
  "created_at" : "2016-08-01 18:11:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760176034515787777\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/pwh6Q2uE2s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoywCzFUAAArh98.jpg",
      "id_str" : "760175999237488640",
      "id" : 760175999237488640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoywCzFUAAArh98.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/pwh6Q2uE2s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760176034515787777",
  "text" : "\"I can announce that, nationally, we have now reduced the number of homeless veterans by 47%\u2014nearly half.\" \u2014@POTUS https:\/\/t.co\/pwh6Q2uE2s",
  "id" : 760176034515787777,
  "created_at" : "2016-08-01 18:11:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760175811659837440",
  "text" : "\u201CWe\u2019ve got to keep fighting for the dignity of every veteran\u2014and that includes ending the tragedy...of veteran homelessness\" \u2014@POTUS",
  "id" : 760175811659837440,
  "created_at" : "2016-08-01 18:10:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760175250856218624\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/N0lKrnnvOG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoyvQClUEAArrAT.jpg",
      "id_str" : "760175127224913920",
      "id" : 760175127224913920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoyvQClUEAArrAT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/N0lKrnnvOG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760175250856218624",
  "text" : "\u201CFrom it's peak, we\u2019ve now slashed that backlog by nearly 90 percent.\u201D \u2014@POTUS on the disability claims backlog https:\/\/t.co\/N0lKrnnvOG",
  "id" : 760175250856218624,
  "created_at" : "2016-08-01 18:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 115, 121 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760174971964448768",
  "text" : "\u201CHere\u2019s one thing we will not do\u2014we cannot outsource and privatize health care for America\u2019s veterans.\u201D \u2014@POTUS at @DAVHQ",
  "id" : 760174971964448768,
  "created_at" : "2016-08-01 18:06:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Dn6oT6hEpW",
      "expanded_url" : "http:\/\/go.wh.gov\/52EqnR",
      "display_url" : "go.wh.gov\/52EqnR"
    } ]
  },
  "geo" : { },
  "id_str" : "760174716363472896",
  "text" : "\u201CWe\u2019ve hired thousands more doctors, nurses and staff; opened more clinical space\u201D \u2014@POTUS. Watch live: https:\/\/t.co\/Dn6oT6hEpW",
  "id" : 760174716363472896,
  "created_at" : "2016-08-01 18:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760174424712544256",
  "text" : "RT @WHLive: \"When too many veterans still aren\u2019t getting the care they need\u2014we all have to be outraged. We all have to do better.\"  \u2014@POTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 121, 127 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760174331523575808",
    "text" : "\"When too many veterans still aren\u2019t getting the care they need\u2014we all have to be outraged. We all have to do better.\"  \u2014@POTUS",
    "id" : 760174331523575808,
    "created_at" : "2016-08-01 18:04:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760174424712544256,
  "created_at" : "2016-08-01 18:04:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 108, 114 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760174054124900352\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Mf5rmA4c4m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoyuK9tUAAAmyll.jpg",
      "id_str" : "760173940505313280",
      "id" : 760173940505313280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoyuK9tUAAAmyll.jpg",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1201
      } ],
      "display_url" : "pic.twitter.com\/Mf5rmA4c4m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760174054124900352",
  "text" : "\u201CWe\u2019ve increased funding for veterans mental health care by more than 75%\u2014billions more dollars\" \u2014@POTUS at @DAVHQ https:\/\/t.co\/Mf5rmA4c4m",
  "id" : 760174054124900352,
  "created_at" : "2016-08-01 18:03:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 138, 144 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760173843956719616",
  "text" : "\u201C500,000 veterans...have stepped forward &amp; donated your health &amp; genetic data for research, which brings us halfway to our goal\u201D \u2014@POTUS",
  "id" : 760173843956719616,
  "created_at" : "2016-08-01 18:02:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760173744329416705",
  "text" : "RT @WHLive: \u201CWe\u2019re reaching more veterans...with telemedicine\u2014so you can see someone at the VA without ever leaving home.\u201D \u2014@POTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 112, 118 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760173524614983681",
    "text" : "\u201CWe\u2019re reaching more veterans...with telemedicine\u2014so you can see someone at the VA without ever leaving home.\u201D \u2014@POTUS",
    "id" : 760173524614983681,
    "created_at" : "2016-08-01 18:01:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760173744329416705,
  "created_at" : "2016-08-01 18:01:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760173598535393281",
  "text" : "\u201CWe now have a designated women\u2019s health provider at all VA clinics to make sure our women veterans get the tailored care\u201D \u2014@POTUS",
  "id" : 760173598535393281,
  "created_at" : "2016-08-01 18:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/P4kfdfv6ud",
      "expanded_url" : "http:\/\/Vets.gov",
      "display_url" : "Vets.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "760173481044553728",
  "text" : "RT @WHLive: Veterans can now finally apply for VA health care anytime...in as little as 20 minutes. Just go to https:\/\/t.co\/P4kfdfv6ud.\u201D \u2014@\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 126, 132 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/P4kfdfv6ud",
        "expanded_url" : "http:\/\/Vets.gov",
        "display_url" : "Vets.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "760173414866751488",
    "text" : "Veterans can now finally apply for VA health care anytime...in as little as 20 minutes. Just go to https:\/\/t.co\/P4kfdfv6ud.\u201D \u2014@POTUS",
    "id" : 760173414866751488,
    "created_at" : "2016-08-01 18:00:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760173481044553728,
  "created_at" : "2016-08-01 18:00:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760173336240410624",
  "text" : "RT @WHLive: \u201CThanks to the Affordable Care Act\u2014Obamacare\u2014veterans not covered by the VA now have access to quality, affordable health care\u201D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 129, 135 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760173286101688321",
    "text" : "\u201CThanks to the Affordable Care Act\u2014Obamacare\u2014veterans not covered by the VA now have access to quality, affordable health care\u201D \u2014@POTUS",
    "id" : 760173286101688321,
    "created_at" : "2016-08-01 18:00:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760173336240410624,
  "created_at" : "2016-08-01 18:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 96, 102 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Dn6oT6hEpW",
      "expanded_url" : "http:\/\/go.wh.gov\/52EqnR",
      "display_url" : "go.wh.gov\/52EqnR"
    } ]
  },
  "geo" : { },
  "id_str" : "760173191318822918",
  "text" : "\u201CI do have to point out\u2014Republicans in Congress have proposed cutting my VA budget.\u201D \u2014@POTUS at @DAVHQ. Watch live: https:\/\/t.co\/Dn6oT6hEpW",
  "id" : 760173191318822918,
  "created_at" : "2016-08-01 17:59:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 106, 112 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760172932416974848",
  "text" : "RT @WHLive: \u201CAltogether, we will have increased funding for veterans by more than 85 percent.\u201D \u2014@POTUS at @DAVHQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 84, 90 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "DAV National HQ",
        "screen_name" : "DAVHQ",
        "indices" : [ 94, 100 ],
        "id_str" : "22139417",
        "id" : 22139417
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760172868374110208",
    "text" : "\u201CAltogether, we will have increased funding for veterans by more than 85 percent.\u201D \u2014@POTUS at @DAVHQ",
    "id" : 760172868374110208,
    "created_at" : "2016-08-01 17:58:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760172932416974848,
  "created_at" : "2016-08-01 17:58:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760172896106913792",
  "text" : "RT @WHLive: \u201CAbout 200,000 service members are becoming veterans every year. And America\u2019s got to be there for you for a lifetime.\u201D \u2014@POTUS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 121, 127 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "DAV National HQ",
        "screen_name" : "DAVHQ",
        "indices" : [ 131, 137 ],
        "id_str" : "22139417",
        "id" : 22139417
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760172747490111489",
    "text" : "\u201CAbout 200,000 service members are becoming veterans every year. And America\u2019s got to be there for you for a lifetime.\u201D \u2014@POTUS at @DAVHQ",
    "id" : 760172747490111489,
    "created_at" : "2016-08-01 17:58:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760172896106913792,
  "created_at" : "2016-08-01 17:58:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 129, 135 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760172588974747648",
  "text" : "\u201CWorking together over these past eight years, we\u2019ve delivered real progress for our veterans.  And we can\u2019t let up.\" \u2014@POTUS at @DAVHQ",
  "id" : 760172588974747648,
  "created_at" : "2016-08-01 17:57:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 133, 139 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760172246425935876",
  "text" : "\"The citizens you kept safe\u2014we pledge to take care of you and your families when you come home. That's a sacred covenant\" \u2014@POTUS at @DAVHQ",
  "id" : 760172246425935876,
  "created_at" : "2016-08-01 17:56:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760172056696598528",
  "text" : "\u201CAmerica\u2019s commitment to our veterans is not just lines in a budget\u2026Our commitment to our veterans is a sacred covenant.\u201D \u2014@POTUS",
  "id" : 760172056696598528,
  "created_at" : "2016-08-01 17:55:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 111, 117 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760171972680638468",
  "text" : "RT @WHLive: \"We believe in taking care of each other, lifting each other up, leaving no one behind\" \u2014@POTUS at @DAVHQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 89, 95 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "DAV National HQ",
        "screen_name" : "DAVHQ",
        "indices" : [ 99, 105 ],
        "id_str" : "22139417",
        "id" : 22139417
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "760171880414257152",
    "text" : "\"We believe in taking care of each other, lifting each other up, leaving no one behind\" \u2014@POTUS at @DAVHQ",
    "id" : 760171880414257152,
    "created_at" : "2016-08-01 17:54:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760171972680638468,
  "created_at" : "2016-08-01 17:54:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760171760222253056",
  "text" : "\"This country that we love hasn\u2019t just endured. We\u2019ve thrived and overcome challenges that would have broken a lesser nation\" \u2014@POTUS",
  "id" : 760171760222253056,
  "created_at" : "2016-08-01 17:54:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 100, 106 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/4xONzNk04z",
      "expanded_url" : "http:\/\/go.wh.gov\/M6yd9A",
      "display_url" : "go.wh.gov\/M6yd9A"
    } ]
  },
  "geo" : { },
  "id_str" : "760170882144751616",
  "text" : "\"No one\u2014no one\u2014has given more for our freedom and security than our Gold Star families.\" \u2014@POTUS at @DAVHQ https:\/\/t.co\/4xONzNk04z",
  "id" : 760170882144751616,
  "created_at" : "2016-08-01 17:50:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 115, 121 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760170589159952384",
  "geo" : { },
  "id_str" : "760170721314152448",
  "in_reply_to_user_id" : 30313925,
  "text" : "\"America\u2019s military is the most capable fighting force in history\u2014and we\u2019re going to keep it that way.\u201D \u2014@POTUS at @DAVHQ",
  "id" : 760170721314152448,
  "in_reply_to_status_id" : 760170589159952384,
  "created_at" : "2016-08-01 17:49:57 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760170449380659201",
  "geo" : { },
  "id_str" : "760170589159952384",
  "in_reply_to_user_id" : 30313925,
  "text" : "\u201COur Marines are the world\u2019s only truly expeditionary force. We have the finest Coast Guard.\u201D",
  "id" : 760170589159952384,
  "in_reply_to_status_id" : 760170449380659201,
  "created_at" : "2016-08-01 17:49:26 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760170351166824448",
  "geo" : { },
  "id_str" : "760170449380659201",
  "in_reply_to_user_id" : 30313925,
  "text" : "\u201COur Navy is the largest and most lethal in the world. The precision and reach of our Air Force is unmatched.\u201D \u2014@POTUS",
  "id" : 760170449380659201,
  "in_reply_to_status_id" : 760170351166824448,
  "created_at" : "2016-08-01 17:48:53 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760170351166824448",
  "text" : "\u201CLet\u2019s get some facts straight. America\u2019s Army is the best-trained, best-equipped land force on the planet.\u201D \u2014@POTUS",
  "id" : 760170351166824448,
  "created_at" : "2016-08-01 17:48:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 113, 119 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760170231893463041",
  "text" : "\"As Commander-in-Chief, I\u2019m pretty tired of some folks trash talking America\u2019s military and troops.\"  \u2014@POTUS at @DAVHQ",
  "id" : 760170231893463041,
  "created_at" : "2016-08-01 17:48:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760169801465597952",
  "text" : "\"When I came into office, we had nearly 180,000 American troops in Afghanistan and Iraq. Today, that number is less than 15,000.\u201D \u2014@POTUS",
  "id" : 760169801465597952,
  "created_at" : "2016-08-01 17:46:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 99, 105 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760169589107990533",
  "text" : "RT @WHLive: \u201CNo war should ever be forgotten and no veteran should ever be overlooked.\u201D \u2014@POTUS at @DAVHQ. Watch live: https:\/\/t.co\/WkFIANG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 77, 83 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "DAV National HQ",
        "screen_name" : "DAVHQ",
        "indices" : [ 87, 93 ],
        "id_str" : "22139417",
        "id" : 22139417
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/WkFIANGSG4",
        "expanded_url" : "http:\/\/go.wh.gov\/M6yd9A",
        "display_url" : "go.wh.gov\/M6yd9A"
      } ]
    },
    "geo" : { },
    "id_str" : "760169506195005440",
    "text" : "\u201CNo war should ever be forgotten and no veteran should ever be overlooked.\u201D \u2014@POTUS at @DAVHQ. Watch live: https:\/\/t.co\/WkFIANGSG4",
    "id" : 760169506195005440,
    "created_at" : "2016-08-01 17:45:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 760169589107990533,
  "created_at" : "2016-08-01 17:45:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/760169216339238915\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pEd4qLQLaF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coyp1YqVYAAJsS3.jpg",
      "id_str" : "760169171736944640",
      "id" : 760169171736944640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coyp1YqVYAAJsS3.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/pEd4qLQLaF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760169216339238915",
  "text" : "\"We\u2019ve stood together at Normandy to thank a generation\u2014among them, my grandfather...that literally saved the world\" https:\/\/t.co\/pEd4qLQLaF",
  "id" : 760169216339238915,
  "created_at" : "2016-08-01 17:43:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760169015385976833",
  "text" : "\u201CSome of the most unforgettable experiences I\u2019d had have been the moments I\u2019ve spent with you\u2014America\u2019s veterans and your families.\u201D \u2014@POTUS",
  "id" : 760169015385976833,
  "created_at" : "2016-08-01 17:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Dn6oT6hEpW",
      "expanded_url" : "http:\/\/go.wh.gov\/52EqnR",
      "display_url" : "go.wh.gov\/52EqnR"
    } ]
  },
  "geo" : { },
  "id_str" : "760168779443601409",
  "text" : "\"It's good to be back with the Disabled American Veterans. What a journey we've had together\" \u2014@POTUS. Watch live: https:\/\/t.co\/Dn6oT6hEpW",
  "id" : 760168779443601409,
  "created_at" : "2016-08-01 17:42:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Dn6oT6hEpW",
      "expanded_url" : "http:\/\/go.wh.gov\/52EqnR",
      "display_url" : "go.wh.gov\/52EqnR"
    } ]
  },
  "geo" : { },
  "id_str" : "760167965249548289",
  "text" : "Watch live: @POTUS speaks at the 95th National Convention of Disabled American Veterans: https:\/\/t.co\/Dn6oT6hEpW #HonoringVets",
  "id" : 760167965249548289,
  "created_at" : "2016-08-01 17:39:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 37, 43 ],
      "id_str" : "22139417",
      "id" : 22139417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Dn6oT6zfOw",
      "expanded_url" : "http:\/\/go.wh.gov\/52EqnR",
      "display_url" : "go.wh.gov\/52EqnR"
    } ]
  },
  "geo" : { },
  "id_str" : "760160764846043136",
  "text" : "Tune in at 1:35pm ET as @POTUS joins @DAVHQ and announces a milestone in the fight to end veteran homelessness: https:\/\/t.co\/Dn6oT6zfOw",
  "id" : 760160764846043136,
  "created_at" : "2016-08-01 17:10:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "indices" : [ 3, 9 ],
      "id_str" : "22139417",
      "id" : 22139417
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DAVHQ\/status\/760139305851334656\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/76BI7BcnlS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Codw-fzUIAAtJum.jpg",
      "id_str" : "758699281226145792",
      "id" : 758699281226145792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Codw-fzUIAAtJum.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/76BI7BcnlS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/1gzYwjfQ3T",
      "expanded_url" : "http:\/\/dav.la\/1n",
      "display_url" : "dav.la\/1n"
    } ]
  },
  "geo" : { },
  "id_str" : "760158500504870912",
  "text" : "RT @DAVHQ: TODAY! Hear directly from @POTUS at the 95th DAV National Convention. Tune in: https:\/\/t.co\/1gzYwjfQ3T https:\/\/t.co\/76BI7BcnlS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 26, 32 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DAVHQ\/status\/760139305851334656\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/76BI7BcnlS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Codw-fzUIAAtJum.jpg",
        "id_str" : "758699281226145792",
        "id" : 758699281226145792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Codw-fzUIAAtJum.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/76BI7BcnlS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/1gzYwjfQ3T",
        "expanded_url" : "http:\/\/dav.la\/1n",
        "display_url" : "dav.la\/1n"
      } ]
    },
    "geo" : { },
    "id_str" : "760139305851334656",
    "text" : "TODAY! Hear directly from @POTUS at the 95th DAV National Convention. Tune in: https:\/\/t.co\/1gzYwjfQ3T https:\/\/t.co\/76BI7BcnlS",
    "id" : 760139305851334656,
    "created_at" : "2016-08-01 15:45:07 +0000",
    "user" : {
      "name" : "DAV National HQ",
      "screen_name" : "DAVHQ",
      "protected" : false,
      "id_str" : "22139417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2468405773\/wb605f45ik6on1xr2u9b_normal.png",
      "id" : 22139417,
      "verified" : true
    }
  },
  "id" : 760158500504870912,
  "created_at" : "2016-08-01 17:01:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/V89CzmtHku",
      "expanded_url" : "http:\/\/portal.hud.gov\/hudportal\/HUD?src=\/press\/press_releases_media_advisories\/2016\/HUDNo_16-117",
      "display_url" : "portal.hud.gov\/hudportal\/HUD?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760134014359441408",
  "text" : "RT @SecretaryCastro: NEWS: Our nation has cut overall veteran homelessness nearly in half since in 2010. https:\/\/t.co\/V89CzmtHku https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryCastro\/status\/760121389672239104\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/DzDxWe1qC6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cox-UG7XgAAdRbT.jpg",
        "id_str" : "760121321040871424",
        "id" : 760121321040871424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cox-UG7XgAAdRbT.jpg",
        "sizes" : [ {
          "h" : 941,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 941,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 941,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/DzDxWe1qC6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/V89CzmtHku",
        "expanded_url" : "http:\/\/portal.hud.gov\/hudportal\/HUD?src=\/press\/press_releases_media_advisories\/2016\/HUDNo_16-117",
        "display_url" : "portal.hud.gov\/hudportal\/HUD?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760121389672239104",
    "text" : "NEWS: Our nation has cut overall veteran homelessness nearly in half since in 2010. https:\/\/t.co\/V89CzmtHku https:\/\/t.co\/DzDxWe1qC6",
    "id" : 760121389672239104,
    "created_at" : "2016-08-01 14:33:56 +0000",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 760134014359441408,
  "created_at" : "2016-08-01 15:24:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The Straits Times",
      "screen_name" : "STcom",
      "indices" : [ 43, 49 ],
      "id_str" : "37874853",
      "id" : 37874853
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 93, 104 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/Js5kiiyz2D",
      "expanded_url" : "http:\/\/www.straitstimes.com\/world\/united-states\/singapore-an-anchor-for-us-presence-in-region-obama",
      "display_url" : "straitstimes.com\/world\/united-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760125579668688897",
  "text" : "RT @Price44: .@POTUS speaks to Singapore's @STcom ahead of Prime Minister Lee's visit to the @WhiteHouse: https:\/\/t.co\/Js5kiiyz2D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The Straits Times",
        "screen_name" : "STcom",
        "indices" : [ 30, 36 ],
        "id_str" : "37874853",
        "id" : 37874853
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 80, 91 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/Js5kiiyz2D",
        "expanded_url" : "http:\/\/www.straitstimes.com\/world\/united-states\/singapore-an-anchor-for-us-presence-in-region-obama",
        "display_url" : "straitstimes.com\/world\/united-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "760121889025122304",
    "text" : ".@POTUS speaks to Singapore's @STcom ahead of Prime Minister Lee's visit to the @WhiteHouse: https:\/\/t.co\/Js5kiiyz2D",
    "id" : 760121889025122304,
    "created_at" : "2016-08-01 14:35:55 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 760125579668688897,
  "created_at" : "2016-08-01 14:50:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]