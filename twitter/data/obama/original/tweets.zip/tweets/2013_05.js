Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/340580998955794432\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/lLmi0F7CGY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLn8nTRCAAMcmck.jpg",
      "id_str" : "340580998959988739",
      "id" : 340580998959988739,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLn8nTRCAAMcmck.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/lLmi0F7CGY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340580998955794432",
  "text" : "Happy Friday! http:\/\/t.co\/lLmi0F7CGY",
  "id" : 340580998955794432,
  "created_at" : "2013-05-31 21:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AsteroidQE2",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "WeTheGeeks",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/kN4Gzhqu1o",
      "expanded_url" : "http:\/\/at.wh.gov\/lB0bu",
      "display_url" : "at.wh.gov\/lB0bu"
    } ]
  },
  "geo" : { },
  "id_str" : "340570891861770240",
  "text" : "#AsteroidQE2 is harmlessly passing Earth right now. Celebrate by watching today's #WeTheGeeks Hangout on asteroids: http:\/\/t.co\/kN4Gzhqu1o",
  "id" : 340570891861770240,
  "created_at" : "2013-05-31 20:50:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340562635395305474",
  "text" : "RT @WHVideo: New #WestWingWeek: Memorial Day, Naval Academy Commencement &amp; POTUS travels to OK &amp; NJ to highlight recovery efforts. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WestWingWeek",
        "indices" : [ 4, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/8qAhEyXidy",
        "expanded_url" : "http:\/\/wh.gov\/lqntv",
        "display_url" : "wh.gov\/lqntv"
      } ]
    },
    "geo" : { },
    "id_str" : "340554389964070912",
    "text" : "New #WestWingWeek: Memorial Day, Naval Academy Commencement &amp; POTUS travels to OK &amp; NJ to highlight recovery efforts. http:\/\/t.co\/8qAhEyXidy",
    "id" : 340554389964070912,
    "created_at" : "2013-05-31 19:44:28 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 340562635395305474,
  "created_at" : "2013-05-31 20:17:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340553670808702978",
  "text" : "RT @Simas44: Over 90% of the uninsured in Arizona will immediately benefit from Obamacare. Security for nearly a million Americans http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/XXrdabxvnM",
        "expanded_url" : "http:\/\/tucsoncitizen.com\/obamacare-news\/2013\/05\/28\/over-90-of-uninsured-in-arizona-will-get-obamacare-help\/",
        "display_url" : "tucsoncitizen.com\/obamacare-news\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "340462526246563840",
    "text" : "Over 90% of the uninsured in Arizona will immediately benefit from Obamacare. Security for nearly a million Americans http:\/\/t.co\/XXrdabxvnM",
    "id" : 340462526246563840,
    "created_at" : "2013-05-31 13:39:26 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 340553670808702978,
  "created_at" : "2013-05-31 19:41:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "Obamacares",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/2qHVN7tH81",
      "expanded_url" : "http:\/\/wh.gov\/lqpEk",
      "display_url" : "wh.gov\/lqpEk"
    } ]
  },
  "geo" : { },
  "id_str" : "340538424018731008",
  "text" : "RT @pfeiffer44: Good news for seniors: With help from the #ACA, Medicare will be solvent through 2026. http:\/\/t.co\/2qHVN7tH81 #Obamacares",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 42, 46 ]
      }, {
        "text" : "Obamacares",
        "indices" : [ 110, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/2qHVN7tH81",
        "expanded_url" : "http:\/\/wh.gov\/lqpEk",
        "display_url" : "wh.gov\/lqpEk"
      } ]
    },
    "geo" : { },
    "id_str" : "340524600737812481",
    "text" : "Good news for seniors: With help from the #ACA, Medicare will be solvent through 2026. http:\/\/t.co\/2qHVN7tH81 #Obamacares",
    "id" : 340524600737812481,
    "created_at" : "2013-05-31 17:46:06 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 340538424018731008,
  "created_at" : "2013-05-31 18:41:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 30, 45 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Lori Garver",
      "screen_name" : "Lori_Garver",
      "indices" : [ 57, 69 ],
      "id_str" : "119897041",
      "id" : 119897041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Asteroid",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "WeTheGeeks",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340530914322944000",
  "text" : "RT @NASA: Watch now #Asteroid @WhiteHouseOSTP Hangout w\/ @Lori_Garver &amp; others. Use #WeTheGeeks for questions. Live at: http:\/\/t.co\/QIQiZQI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 20, 35 ],
        "id_str" : "33998183",
        "id" : 33998183
      }, {
        "name" : "Lori Garver",
        "screen_name" : "Lori_Garver",
        "indices" : [ 47, 59 ],
        "id_str" : "119897041",
        "id" : 119897041
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Asteroid",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "WeTheGeeks",
        "indices" : [ 78, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/QIQiZQIAVL",
        "expanded_url" : "http:\/\/youtu.be\/yJq91w3sqvk",
        "display_url" : "youtu.be\/yJq91w3sqvk"
      } ]
    },
    "geo" : { },
    "id_str" : "340528274042150912",
    "text" : "Watch now #Asteroid @WhiteHouseOSTP Hangout w\/ @Lori_Garver &amp; others. Use #WeTheGeeks for questions. Live at: http:\/\/t.co\/QIQiZQIAVL",
    "id" : 340528274042150912,
    "created_at" : "2013-05-31 18:00:41 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 340530914322944000,
  "created_at" : "2013-05-31 18:11:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 20, 25 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 32, 46 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/qWjcwkjJEW",
      "expanded_url" : "http:\/\/wh.gov\/we-the-geeks",
      "display_url" : "wh.gov\/we-the-geeks"
    } ]
  },
  "geo" : { },
  "id_str" : "340528499175591936",
  "text" : "Happening now: Join @NASA &amp; @TheScienceGuy for a WH Google+ Hangout on asteroids: http:\/\/t.co\/qWjcwkjJEW #WeTheGeeks",
  "id" : 340528499175591936,
  "created_at" : "2013-05-31 18:01:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 38, 43 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 50, 64 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/qWjcwkjJEW",
      "expanded_url" : "http:\/\/wh.gov\/we-the-geeks",
      "display_url" : "wh.gov\/we-the-geeks"
    } ]
  },
  "geo" : { },
  "id_str" : "340518143443234817",
  "text" : "Have a question about asteroids? Join @NASA &amp; @TheScienceGuy for a WH Google+ Hangout at 2pm ET: http:\/\/t.co\/qWjcwkjJEW. Ask w\/ #WeTheGeeks.",
  "id" : 340518143443234817,
  "created_at" : "2013-05-31 17:20:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patti Paige",
      "screen_name" : "PattiPaige",
      "indices" : [ 3, 14 ],
      "id_str" : "89243478",
      "id" : 89243478
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 16, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340498456781131780",
  "text" : "RT @PattiPaige: #DontDoubleMyRate Our economy will not be able to grow if young adults cannot afford to buy a home or car because they are \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340496808738430976",
    "text" : "#DontDoubleMyRate Our economy will not be able to grow if young adults cannot afford to buy a home or car because they are paying off debt.",
    "id" : 340496808738430976,
    "created_at" : "2013-05-31 15:55:39 +0000",
    "user" : {
      "name" : "Patti Paige",
      "screen_name" : "PattiPaige",
      "protected" : false,
      "id_str" : "89243478",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521678635\/case_car_normal.jpg",
      "id" : 89243478,
      "verified" : false
    }
  },
  "id" : 340498456781131780,
  "created_at" : "2013-05-31 16:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 21, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340494223671439361",
  "text" : "Spread the word: Use #DontDoubleMyRate to share why students can't afford to pay more for college loans.",
  "id" : 340494223671439361,
  "created_at" : "2013-05-31 15:45:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/340487994819616771\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Xy8w64ODVT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLmoBv3CIAIMdEa.jpg",
      "id_str" : "340487994823811074",
      "id" : 340487994823811074,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLmoBv3CIAIMdEa.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Xy8w64ODVT"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 97, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340487994819616771",
  "text" : "If Congress lets student loan rates double on July 1st, millions of students will pay the price. #DontDoubleMyRate, http:\/\/t.co\/Xy8w64ODVT",
  "id" : 340487994819616771,
  "created_at" : "2013-05-31 15:20:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/340478105690963969\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/QixlTVYM05",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLmfCH_CAAAhrqs.jpg",
      "id_str" : "340478105695158272",
      "id" : 340478105695158272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLmfCH_CAAAhrqs.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/QixlTVYM05"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 90, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340478105690963969",
  "text" : "Obama: \"In America, a higher education cannot be a luxury reserved for a privileged few.\" #DontDoubleMyRate, http:\/\/t.co\/QixlTVYM05",
  "id" : 340478105690963969,
  "created_at" : "2013-05-31 14:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340477376989364227",
  "text" : "Obama on convincing Congress to keep rates low: \"I need you to call them up, or email them, or find them on Twitter.\" #DontDoubleMyRate",
  "id" : 340477376989364227,
  "created_at" : "2013-05-31 14:38:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340476673763995648",
  "text" : "President Obama: \"Last year, you convinced 186 Republicans in the House and 24 Republicans in the Senate...to keep student loan rates low.\"",
  "id" : 340476673763995648,
  "created_at" : "2013-05-31 14:35:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 102, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340475964108701696",
  "text" : "President Obama: \"If Congress doesn\u2019t act by July 1st, federal student loan rates are set to double.\" #DontDoubleMyRate",
  "id" : 340475964108701696,
  "created_at" : "2013-05-31 14:32:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340475617696940032",
  "text" : "President Obama: \"We cannot price the middle class...out of a college education.\" #DontDoubleMyRate",
  "id" : 340475617696940032,
  "created_at" : "2013-05-31 14:31:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 89, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340474987091734529",
  "text" : "President Obama: \u201CThe surest path to the middle class is some form of higher education.\u201D #DontDoubleMyRate",
  "id" : 340474987091734529,
  "created_at" : "2013-05-31 14:28:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340474650133938176",
  "text" : "President Obama on keeping student loan rates low: \u201CThis isn\u2019t just critical for their futures, but for America\u2019s future.\u201D #DontDoubleMyRate",
  "id" : 340474650133938176,
  "created_at" : "2013-05-31 14:27:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 112, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "340474040751882241",
  "text" : "Happening now: President Obama speaks about preventing student loan rates from doubling. http:\/\/t.co\/KvadYk9atb #DontDoubleMyRate",
  "id" : 340474040751882241,
  "created_at" : "2013-05-31 14:25:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "340460073820254209",
  "text" : "At 10:20am ET: President Obama speaks on why we need to prevent student loan rates from doubling. http:\/\/t.co\/KvadYk9atb #DontDoubleMyRate",
  "id" : 340460073820254209,
  "created_at" : "2013-05-31 13:29:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "Sr. Simone Campbell",
      "screen_name" : "sr_simone",
      "indices" : [ 66, 76 ],
      "id_str" : "318518392",
      "id" : 318518392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 108, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340287200639987712",
  "text" : "RT @lacasablanca: Oval Office meeting: Today, President Obama and @sr_simone of \"Nuns on the Bus\" discussed #ImmigrationReform. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sr. Simone Campbell",
        "screen_name" : "sr_simone",
        "indices" : [ 48, 58 ],
        "id_str" : "318518392",
        "id" : 318518392
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/340249417745580034\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/9Ke8n4sYe1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BLjPCvACQAEn4nd.jpg",
        "id_str" : "340249417749774337",
        "id" : 340249417749774337,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLjPCvACQAEn4nd.jpg",
        "sizes" : [ {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9Ke8n4sYe1"
      } ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 90, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "340249417745580034",
    "text" : "Oval Office meeting: Today, President Obama and @sr_simone of \"Nuns on the Bus\" discussed #ImmigrationReform. http:\/\/t.co\/9Ke8n4sYe1",
    "id" : 340249417745580034,
    "created_at" : "2013-05-30 23:32:37 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 340287200639987712,
  "created_at" : "2013-05-31 02:02:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/340249413102493696\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/ONyjCSFUBm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLjPCdtCYAAmYL2.jpg",
      "id_str" : "340249413106688000",
      "id" : 340249413106688000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLjPCdtCYAAmYL2.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ONyjCSFUBm"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 75, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340249413102493696",
  "text" : "RT if you agree: Every American should be able to afford higher education. #DontDoubleMyRate, http:\/\/t.co\/ONyjCSFUBm",
  "id" : 340249413102493696,
  "created_at" : "2013-05-30 23:32:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/rMvMZ0WzXI",
      "expanded_url" : "http:\/\/at.wh.gov\/lyTds",
      "display_url" : "at.wh.gov\/lyTds"
    } ]
  },
  "geo" : { },
  "id_str" : "340240757577371650",
  "text" : "Asteroids! http:\/\/t.co\/rMvMZ0WzXI #WeTheGeeks",
  "id" : 340240757577371650,
  "created_at" : "2013-05-30 22:58:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/BKP6VeEaQl",
      "expanded_url" : "http:\/\/go.usa.gov\/bbYx",
      "display_url" : "go.usa.gov\/bbYx"
    } ]
  },
  "geo" : { },
  "id_str" : "340224650707599360",
  "text" : "RT @whitehouseostp: New Task Force Report (http:\/\/t.co\/BKP6VeEaQl) on Empowering Consumers through the Smart Disclosure of Data http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/BKP6VeEaQl",
        "expanded_url" : "http:\/\/go.usa.gov\/bbYx",
        "display_url" : "go.usa.gov\/bbYx"
      }, {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/eh2cU0Pqpe",
        "expanded_url" : "http:\/\/go.usa.gov\/bbYj",
        "display_url" : "go.usa.gov\/bbYj"
      } ]
    },
    "geo" : { },
    "id_str" : "340174425305530369",
    "text" : "New Task Force Report (http:\/\/t.co\/BKP6VeEaQl) on Empowering Consumers through the Smart Disclosure of Data http:\/\/t.co\/eh2cU0Pqpe",
    "id" : 340174425305530369,
    "created_at" : "2013-05-30 18:34:37 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 340224650707599360,
  "created_at" : "2013-05-30 21:54:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 114, 125 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340214432275775489",
  "text" : "RT @Sebelius: The #ACA is leading to more choices for individuals buying health coverage. Read the new study from @whitehouse http:\/\/t.co\/u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 100, 111 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 4, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/uZ5NkoW2XG",
        "expanded_url" : "http:\/\/1.usa.gov\/15fwdp6",
        "display_url" : "1.usa.gov\/15fwdp6"
      } ]
    },
    "geo" : { },
    "id_str" : "340190783758020609",
    "text" : "The #ACA is leading to more choices for individuals buying health coverage. Read the new study from @whitehouse http:\/\/t.co\/uZ5NkoW2XG",
    "id" : 340190783758020609,
    "created_at" : "2013-05-30 19:39:37 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 340214432275775489,
  "created_at" : "2013-05-30 21:13:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340188671384903680",
  "text" : "RT if you agree: We should keep working to make college more affordable\u2014not force students to pay more for college loans. #DontDoubleMyRate",
  "id" : 340188671384903680,
  "created_at" : "2013-05-30 19:31:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340181785545695232",
  "text" : "FACT: Last year, President Obama helped students save an average of $1,000 on their college loans by extending low interest rates.",
  "id" : 340181785545695232,
  "created_at" : "2013-05-30 19:03:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340175940711772162",
  "text" : "FACT: President Obama doubled investments in Pell Grants\u2014helping millions of additional low-income and middle-class students afford college.",
  "id" : 340175940711772162,
  "created_at" : "2013-05-30 18:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340170867558453252",
  "text" : "FACT: Obama created and extended a tax credit worth $10,000 over 4 years that helps more than 9 million families cover college costs.",
  "id" : 340170867558453252,
  "created_at" : "2013-05-30 18:20:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340166078829322242",
  "text" : "FACT: President Obama's plan would keep interest rates low on student loans for more than 7 million borrowers. #DontDoubleMyRate",
  "id" : 340166078829322242,
  "created_at" : "2013-05-30 18:01:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340160707326799873",
  "text" : "FACT: If Congress doesn't act, more than 7 million students will pay about $1,000 more in interest on next year's loans. #DontDoubleMyRate",
  "id" : 340160707326799873,
  "created_at" : "2013-05-30 17:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/aUOtDDCLTh",
      "expanded_url" : "http:\/\/at.wh.gov\/lyaqS",
      "display_url" : "at.wh.gov\/lyaqS"
    } ]
  },
  "geo" : { },
  "id_str" : "340155682894528513",
  "text" : "President Obama: \"Now is not the time to make school more expensive for our young people.\" http:\/\/t.co\/aUOtDDCLTh #DontDoubleMyRate",
  "id" : 340155682894528513,
  "created_at" : "2013-05-30 17:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/O0rfc66hD7",
      "expanded_url" : "http:\/\/at.wh.gov\/ly7Af",
      "display_url" : "at.wh.gov\/ly7Af"
    } ]
  },
  "geo" : { },
  "id_str" : "340151062558277633",
  "text" : "Why Congress needs to act to keep student loan rates from doubling\u2014slooow jam style: http:\/\/t.co\/O0rfc66hD7 #TBT",
  "id" : 340151062558277633,
  "created_at" : "2013-05-30 17:01:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Bz4rSOf1Tc",
      "expanded_url" : "http:\/\/at.wh.gov\/ly6Pp",
      "display_url" : "at.wh.gov\/ly6Pp"
    } ]
  },
  "geo" : { },
  "id_str" : "340142415199494145",
  "text" : "2012: Congress almost let student loan rates double. 2013: Congress is set to let student loan rates double: http:\/\/t.co\/Bz4rSOf1Tc #TBT",
  "id" : 340142415199494145,
  "created_at" : "2013-05-30 16:27:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/GLuttWhtrj",
      "expanded_url" : "http:\/\/at.wh.gov\/lxXIs",
      "display_url" : "at.wh.gov\/lxXIs"
    } ]
  },
  "geo" : { },
  "id_str" : "340129160146059265",
  "text" : "Tomorrow at 2pm ET, learn about how experts are working to find asteroids before they find us: http:\/\/t.co\/GLuttWhtrj #WeTheGeeks",
  "id" : 340129160146059265,
  "created_at" : "2013-05-30 15:34:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/339886432049065985\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/zXUPQoLIGM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLeE6L7CcAA98fO.jpg",
      "id_str" : "339886432057454592",
      "id" : 339886432057454592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLeE6L7CcAA98fO.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/zXUPQoLIGM"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339886432049065985",
  "text" : "Let's live up to our heritage as a nation of immigrants by fixing our broken immigration system. #ImmigrationNation, http:\/\/t.co\/zXUPQoLIGM",
  "id" : 339886432049065985,
  "created_at" : "2013-05-29 23:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 5, 10 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 21, 35 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Ed Lu",
      "screen_name" : "astroEdLu",
      "indices" : [ 42, 52 ],
      "id_str" : "470939544",
      "id" : 470939544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/fa8PGQ2iLR",
      "expanded_url" : "http:\/\/at.wh.gov\/lwxnC",
      "display_url" : "at.wh.gov\/lwxnC"
    } ]
  },
  "geo" : { },
  "id_str" : "339877448344821760",
  "text" : "Join @NASA, Bill Nye @TheScienceGuy &amp; @AstroEdLu Friday for a #WeTheGeeks White House Google+ Hangout on asteroids: http:\/\/t.co\/fa8PGQ2iLR",
  "id" : 339877448344821760,
  "created_at" : "2013-05-29 22:54:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/339826019756302337\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/nbBAO23hkd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLdN9umCYAAiOrF.jpg",
      "id_str" : "339826019764690944",
      "id" : 339826019764690944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLdN9umCYAAiOrF.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/nbBAO23hkd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339826019756302337",
  "text" : "RT if you agree: Immigration makes us stronger, and there's no reason we can't pass immigration reform this year. http:\/\/t.co\/nbBAO23hkd",
  "id" : 339826019756302337,
  "created_at" : "2013-05-29 19:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339817264217980928",
  "text" : "FACT: U.S. immigrants represent 50% of PhDs working in math and computer science and 57% of PhDs working in engineering. #ImmigrationNation",
  "id" : 339817264217980928,
  "created_at" : "2013-05-29 18:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339811424400457729",
  "text" : "FACT: More than 40% of Fortune 500 companies were founded by immigrants or children of immigrants. #ImmigrationNation",
  "id" : 339811424400457729,
  "created_at" : "2013-05-29 18:32:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 95, 102 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "eBay",
      "screen_name" : "eBay",
      "indices" : [ 104, 109 ],
      "id_str" : "19709040",
      "id" : 19709040
    }, {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 111, 117 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 123, 129 ],
      "id_str" : "2803191",
      "id" : 2803191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339805929631543296",
  "text" : "FACT: Immigrants have started 25% of public U.S. companies backed by venture capital\u2014including @Google, @eBay, @Yahoo, and @Intel.",
  "id" : 339805929631543296,
  "created_at" : "2013-05-29 18:10:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339800918151266304",
  "text" : "FACT: Immigrants represent 33% of engineers and 27% of mathematicians, statisticians, and computer scientists in the U.S. #ImmigrationNation",
  "id" : 339800918151266304,
  "created_at" : "2013-05-29 17:50:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 72, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339795955836661760",
  "text" : "FACT: In 2011, immigrants started 28% of all new businesses in the U.S. #ImmigrationNation",
  "id" : 339795955836661760,
  "created_at" : "2013-05-29 17:30:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/339790698477940736\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/3a9zvlhTm6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLct1wlCcAEIkje.jpg",
      "id_str" : "339790698486329345",
      "id" : 339790698486329345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLct1wlCcAEIkje.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/3a9zvlhTm6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/GJlQMNfXy9",
      "expanded_url" : "http:\/\/at.wh.gov\/lvOOf",
      "display_url" : "at.wh.gov\/lvOOf"
    } ]
  },
  "geo" : { },
  "id_str" : "339790698477940736",
  "text" : "Fixing our broken immigration system would strengthen our economy &amp; make us more prosperous: http:\/\/t.co\/GJlQMNfXy9, http:\/\/t.co\/3a9zvlhTm6",
  "id" : 339790698477940736,
  "created_at" : "2013-05-29 17:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/339771897296338946\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/mbgUwG5MtU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLccvYtCQAAQxoa.jpg",
      "id_str" : "339771897300533248",
      "id" : 339771897300533248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLccvYtCQAAQxoa.jpg",
      "sizes" : [ {
        "h" : 734,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mbgUwG5MtU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339771897296338946",
  "text" : "High five. http:\/\/t.co\/mbgUwG5MtU",
  "id" : 339771897296338946,
  "created_at" : "2013-05-29 15:55:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "339758622772969472",
  "text" : "Watch live: Immigrant entrepreneurs discuss how immigration reform would strengthen our economy and the middle class. http:\/\/t.co\/KvadYk9atb",
  "id" : 339758622772969472,
  "created_at" : "2013-05-29 15:02:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/339544716691525632\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/FpngyYd4zI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLZOHvBCUAAG9gD.jpg",
      "id_str" : "339544716699914240",
      "id" : 339544716699914240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLZOHvBCUAAG9gD.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FpngyYd4zI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/rhlrgOOhun",
      "expanded_url" : "http:\/\/at.wh.gov\/lu9gF",
      "display_url" : "at.wh.gov\/lu9gF"
    } ]
  },
  "geo" : { },
  "id_str" : "339544716691525632",
  "text" : "Harvest time in the White House Kitchen Garden: http:\/\/t.co\/rhlrgOOhun, http:\/\/t.co\/FpngyYd4zI",
  "id" : 339544716691525632,
  "created_at" : "2013-05-29 00:52:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 60, 67 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339494674333040640",
  "text" : "RT @whitehouseostp: Join us Friday for the next #WeTheGeeks @Google+ Hangout! Topic: Asteroids ... let's find them before they find us: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google",
        "screen_name" : "google",
        "indices" : [ 40, 47 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 28, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/cihUYDPqf2",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/05\/28\/we-geeks-asteroids",
        "display_url" : "whitehouse.gov\/blog\/2013\/05\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "339490601991012354",
    "text" : "Join us Friday for the next #WeTheGeeks @Google+ Hangout! Topic: Asteroids ... let's find them before they find us: http:\/\/t.co\/cihUYDPqf2",
    "id" : 339490601991012354,
    "created_at" : "2013-05-28 21:17:21 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 339494674333040640,
  "created_at" : "2013-05-28 21:33:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/rOXCMnDWoc",
      "expanded_url" : "http:\/\/at.wh.gov\/ltJW0",
      "display_url" : "at.wh.gov\/ltJW0"
    } ]
  },
  "geo" : { },
  "id_str" : "339476319677067266",
  "text" : "\"Fellow Americans are praying with you, they're thinking about you, and they want to help.\" \u2014Obama in Oklahoma: http:\/\/t.co\/rOXCMnDWoc",
  "id" : 339476319677067266,
  "created_at" : "2013-05-28 20:20:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Christie",
      "screen_name" : "GovChristie",
      "indices" : [ 3, 15 ],
      "id_str" : "90484508",
      "id" : 90484508
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GovChristie\/status\/339449321890136064\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Vf2ho2bABf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLX3XBsCQAANNAR.jpg",
      "id_str" : "339449321898524672",
      "id" : 339449321898524672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLX3XBsCQAANNAR.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Vf2ho2bABf"
    } ],
    "hashtags" : [ {
      "text" : "AsburyPark",
      "indices" : [ 89, 100 ]
    }, {
      "text" : "STTS",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339464830912180224",
  "text" : "RT @GovChristie: President Obama told this Jersey crowd we are \u201Cstronger than the storm\u201D #AsburyPark #STTS http:\/\/t.co\/Vf2ho2bABf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GovChristie\/status\/339449321890136064\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Vf2ho2bABf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BLX3XBsCQAANNAR.jpg",
        "id_str" : "339449321898524672",
        "id" : 339449321898524672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLX3XBsCQAANNAR.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Vf2ho2bABf"
      } ],
      "hashtags" : [ {
        "text" : "AsburyPark",
        "indices" : [ 72, 83 ]
      }, {
        "text" : "STTS",
        "indices" : [ 84, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339449321890136064",
    "text" : "President Obama told this Jersey crowd we are \u201Cstronger than the storm\u201D #AsburyPark #STTS http:\/\/t.co\/Vf2ho2bABf",
    "id" : 339449321890136064,
    "created_at" : "2013-05-28 18:33:19 +0000",
    "user" : {
      "name" : "Governor Christie",
      "screen_name" : "GovChristie",
      "protected" : false,
      "id_str" : "90484508",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646777986528645120\/TRMcntto_normal.jpg",
      "id" : 90484508,
      "verified" : true
    }
  },
  "id" : 339464830912180224,
  "created_at" : "2013-05-28 19:34:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 102, 113 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339455042950135808",
  "text" : "RT @FLOTUS: The First Lady &amp; kids from across the country just harvested the summer crop from the @WhiteHouse Kitchen Garden. http:\/\/t.co\/I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 90, 101 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/339443529870880769\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/IlJfJ15hPT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BLXyF4vCMAA_vD6.jpg",
        "id_str" : "339443529879269376",
        "id" : 339443529879269376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLXyF4vCMAA_vD6.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/IlJfJ15hPT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339443529870880769",
    "text" : "The First Lady &amp; kids from across the country just harvested the summer crop from the @WhiteHouse Kitchen Garden. http:\/\/t.co\/IlJfJ15hPT",
    "id" : 339443529870880769,
    "created_at" : "2013-05-28 18:10:19 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 339455042950135808,
  "created_at" : "2013-05-28 18:56:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STTS",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339438493027688448",
  "text" : "President Obama: \"That\u2019s who we are. We help each other through the bad times, and we sure make the most of the good times.\" #STTS",
  "id" : 339438493027688448,
  "created_at" : "2013-05-28 17:50:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/339437282606055428\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/YZ7k6qXvfm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLXsaP3CAAIsscq.jpg",
      "id_str" : "339437282614444034",
      "id" : 339437282614444034,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLXsaP3CAAIsscq.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/YZ7k6qXvfm"
    } ],
    "hashtags" : [ {
      "text" : "STTS",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339437282606055428",
  "text" : "President Obama: \"After all you\u2019ve been through, the Jersey Shore is back and open for business.\" #STTS, http:\/\/t.co\/YZ7k6qXvfm",
  "id" : 339437282606055428,
  "created_at" : "2013-05-28 17:45:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STTS",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339435156291063808",
  "text" : "President Obama on the New Jersey Shore: \u201CWe\u2019re going to keep doing what it takes to help you rebuild.\u201D #STTS",
  "id" : 339435156291063808,
  "created_at" : "2013-05-28 17:37:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STTS",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Q7B4sGeOZl",
      "expanded_url" : "http:\/\/Ready.gov",
      "display_url" : "Ready.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "339434902296616960",
  "text" : "Obama: \"Anyone who wants to make sure they\u2019re ready\u2014for a hurricane or any other disaster\u2014I want them to visit http:\/\/t.co\/Q7B4sGeOZl\" #STTS",
  "id" : 339434902296616960,
  "created_at" : "2013-05-28 17:36:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STTS",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xLsbnLQlt5",
      "expanded_url" : "http:\/\/at.wh.gov\/ltkET",
      "display_url" : "at.wh.gov\/ltkET"
    } ]
  },
  "geo" : { },
  "id_str" : "339432349982941184",
  "text" : "Happening now: President Obama speaks in New Jersey about the rebuilding efforts after Hurricane Sandy. Watch: http:\/\/t.co\/xLsbnLQlt5 #STTS",
  "id" : 339432349982941184,
  "created_at" : "2013-05-28 17:25:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STTS",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "339409611109052416",
  "text" : "At 1:30pm ET, President Obama speaks in New Jersey about rebuilding and recovery efforts after Hurricane Sandy: http:\/\/t.co\/KvadYk9atb #STTS",
  "id" : 339409611109052416,
  "created_at" : "2013-05-28 15:55:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/rbnggNk3kF",
      "expanded_url" : "http:\/\/at.wh.gov\/lrDUc",
      "display_url" : "at.wh.gov\/lrDUc"
    } ]
  },
  "geo" : { },
  "id_str" : "339201956021153792",
  "text" : "Obama on Memorial Day: \"We remember our sacred obligation to those who laid down their lives so we could live ours.\" http:\/\/t.co\/rbnggNk3kF",
  "id" : 339201956021153792,
  "created_at" : "2013-05-28 02:10:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 62, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/42HqUlykP3",
      "expanded_url" : "http:\/\/at.wh.gov\/lrDRV",
      "display_url" : "at.wh.gov\/lrDRV"
    } ]
  },
  "geo" : { },
  "id_str" : "339178928189095939",
  "text" : "President Obama: \"This time next year, we will mark the final #MemorialDay of our war in Afghanistan.\" http:\/\/t.co\/42HqUlykP3",
  "id" : 339178928189095939,
  "created_at" : "2013-05-28 00:38:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/c6mPkRHF9U",
      "expanded_url" : "http:\/\/at.wh.gov\/lrhUf",
      "display_url" : "at.wh.gov\/lrhUf"
    } ]
  },
  "geo" : { },
  "id_str" : "339104941689946114",
  "text" : "Full video: President Obama commemorates #MemorialDay at Arlington National Cemetery: http:\/\/t.co\/c6mPkRHF9U",
  "id" : 339104941689946114,
  "created_at" : "2013-05-27 19:44:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 62, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rUrVu4W9wu",
      "expanded_url" : "http:\/\/at.wh.gov\/lqE4c",
      "display_url" : "at.wh.gov\/lqE4c"
    } ]
  },
  "geo" : { },
  "id_str" : "339037476821803009",
  "text" : "Happening now: President Obama delivers remarks commemorating #MemorialDay from Arlington National Cemetery. Watch: http:\/\/t.co\/rUrVu4W9wu",
  "id" : 339037476821803009,
  "created_at" : "2013-05-27 15:16:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339032499260895232",
  "text" : "RT @FLOTUS: This Memorial Day, let's take time to honor and remember the men and women who have given their lives in service to our great c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339028946689613825",
    "text" : "This Memorial Day, let's take time to honor and remember the men and women who have given their lives in service to our great country. -mo",
    "id" : 339028946689613825,
    "created_at" : "2013-05-27 14:42:54 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 339032499260895232,
  "created_at" : "2013-05-27 14:57:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339028874966999040",
  "text" : "RT @DrBiden: This Memorial Day, we express our gratitude to our military families.  You are in our hearts and prayers today and every day. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "339024600233025536",
    "text" : "This Memorial Day, we express our gratitude to our military families.  You are in our hearts and prayers today and every day. - Jill",
    "id" : 339024600233025536,
    "created_at" : "2013-05-27 14:25:38 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 339028874966999040,
  "created_at" : "2013-05-27 14:42:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/rUrVu4W9wu",
      "expanded_url" : "http:\/\/at.wh.gov\/lqE4c",
      "display_url" : "at.wh.gov\/lqE4c"
    } ]
  },
  "geo" : { },
  "id_str" : "339018218012307456",
  "text" : "At 11:20ET, President Obama delivers remarks commemorating #MemorialDay from Arlington National Cemetery. Watch live: http:\/\/t.co\/rUrVu4W9wu",
  "id" : 339018218012307456,
  "created_at" : "2013-05-27 14:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 9, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339005067703234562",
  "text" : "To honor #MemorialDay, the President will deliver remarks at Arlington National Cemetery &amp; lay a wreath at the Tomb of the Unknown Soldier.",
  "id" : 339005067703234562,
  "created_at" : "2013-05-27 13:08:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338832868941905921",
  "text" : "RT @petesouza: Photo of POTUS hugging principal Amy Simpson outside Plaza Towers Elementary School in Moore, Oklahoma today http:\/\/t.co\/bFX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/338813519740948480\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/bFXSRj0Fbm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BLO1GeHCUAA8V6b.jpg",
        "id_str" : "338813519749337088",
        "id" : 338813519749337088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLO1GeHCUAA8V6b.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/bFXSRj0Fbm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "338813519740948480",
    "text" : "Photo of POTUS hugging principal Amy Simpson outside Plaza Towers Elementary School in Moore, Oklahoma today http:\/\/t.co\/bFXSRj0Fbm",
    "id" : 338813519740948480,
    "created_at" : "2013-05-27 00:26:52 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 338832868941905921,
  "created_at" : "2013-05-27 01:43:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/a9KiQlFcwq",
      "expanded_url" : "http:\/\/at.wh.gov\/lpMQt",
      "display_url" : "at.wh.gov\/lpMQt"
    } ]
  },
  "geo" : { },
  "id_str" : "338824377913184256",
  "text" : "\"When we say that we\u2019ve got your back, I promise you, we keep our word.\" \u2014President Obama today in Oklahoma: http:\/\/t.co\/a9KiQlFcwq",
  "id" : 338824377913184256,
  "created_at" : "2013-05-27 01:10:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/fkSNqHMSeL",
      "expanded_url" : "http:\/\/at.wh.gov\/lpEVK",
      "display_url" : "at.wh.gov\/lpEVK"
    } ]
  },
  "geo" : { },
  "id_str" : "338776681047261185",
  "text" : "Today, President Obama visited Oklahoma to tour storm damage, meet with families impacted &amp; thank first responders: http:\/\/t.co\/fkSNqHMSeL",
  "id" : 338776681047261185,
  "created_at" : "2013-05-26 22:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338717412650278914",
  "text" : "President Obama: \"I want folks affected throughout Oklahoma to know that we are going to be with you every step of the way.\"",
  "id" : 338717412650278914,
  "created_at" : "2013-05-26 18:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338717133036998656",
  "text" : "President Obama in Oklahoma: \"This is a strong community, with strong character. There's no doubt that they are going to bounce back\"",
  "id" : 338717133036998656,
  "created_at" : "2013-05-26 18:03:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338715938092359681",
  "text" : "President Obama to the people of Oklahoma: \"You are not alone.\"",
  "id" : 338715938092359681,
  "created_at" : "2013-05-26 17:59:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/o9cJkssOJ1",
      "expanded_url" : "http:\/\/at.wh.gov\/lpmnX",
      "display_url" : "at.wh.gov\/lpmnX"
    } ]
  },
  "geo" : { },
  "id_str" : "338715779270852608",
  "text" : "Happening now: President Obama speaks from Oklahoma after meeting with families impacted by the severe weather: http:\/\/t.co\/o9cJkssOJ1",
  "id" : 338715779270852608,
  "created_at" : "2013-05-26 17:58:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/o9cJkssOJ1",
      "expanded_url" : "http:\/\/at.wh.gov\/lpmnX",
      "display_url" : "at.wh.gov\/lpmnX"
    } ]
  },
  "geo" : { },
  "id_str" : "338697301902118913",
  "text" : "Starting at 1:45ET: President Obama speaks from Oklahoma after meeting with families impacted by the severe weather: http:\/\/t.co\/o9cJkssOJ1",
  "id" : 338697301902118913,
  "created_at" : "2013-05-26 16:45:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338686940016672768",
  "text" : "Today, President Obama travels to Oklahoma to meet with families impacted by the devastating tornadoes and to thank first responders.",
  "id" : 338686940016672768,
  "created_at" : "2013-05-26 16:03:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/338402607523569664\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/KMLrU4YJ05",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLI_YO0CIAAvdec.jpg",
      "id_str" : "338402607531958272",
      "id" : 338402607531958272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLI_YO0CIAAvdec.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/KMLrU4YJ05"
    } ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/mRPqwYhxOe",
      "expanded_url" : "http:\/\/on.wh.gov\/vUK956D",
      "display_url" : "on.wh.gov\/vUK956D"
    } ]
  },
  "geo" : { },
  "id_str" : "338402607523569664",
  "text" : "This #MemorialDay weekend, let's all hold our fallen heroes in our hearts: http:\/\/t.co\/mRPqwYhxOe http:\/\/t.co\/KMLrU4YJ05",
  "id" : 338402607523569664,
  "created_at" : "2013-05-25 21:14:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/62dBen9Vxl",
      "expanded_url" : "http:\/\/at.wh.gov\/loiy2",
      "display_url" : "at.wh.gov\/loiy2"
    } ]
  },
  "geo" : { },
  "id_str" : "338346308442148864",
  "text" : "President Obama: \"As we commemorate Memorial Day, I ask you to hold all our fallen heroes in your hearts.\" http:\/\/t.co\/62dBen9Vxl",
  "id" : 338346308442148864,
  "created_at" : "2013-05-25 17:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/sJ2NRQoeAi",
      "expanded_url" : "http:\/\/at.wh.gov\/loioG",
      "display_url" : "at.wh.gov\/loioG"
    } ]
  },
  "geo" : { },
  "id_str" : "338285766352465921",
  "text" : "President Obama in his Weekly Address: \"We must make sure all veterans have the care and benefits they\u2019ve earned.\" http:\/\/t.co\/sJ2NRQoeAi",
  "id" : 338285766352465921,
  "created_at" : "2013-05-25 13:29:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/338027372152487937\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/Rv6QfF3z4K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BLDqGqHCAAAB-TZ.jpg",
      "id_str" : "338027372156682240",
      "id" : 338027372156682240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BLDqGqHCAAAB-TZ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Rv6QfF3z4K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338027372152487937",
  "text" : "New receptionist in the West Wing: http:\/\/t.co\/Rv6QfF3z4K",
  "id" : 338027372152487937,
  "created_at" : "2013-05-24 20:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338019213799206912",
  "text" : "RT @Simas44: Great news from CA on Obamacare. Affordable premiums in America's biggest market. Lots of competition &amp; choice. http:\/\/t.co\/gj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/gjO6pTyZID",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/wonkblog\/wp\/2013\/05\/24\/wonkbook-some-very-good-news-for-obamacare\/",
        "display_url" : "washingtonpost.com\/blogs\/wonkblog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "337983059615956992",
    "text" : "Great news from CA on Obamacare. Affordable premiums in America's biggest market. Lots of competition &amp; choice. http:\/\/t.co\/gjO6pTyZID",
    "id" : 337983059615956992,
    "created_at" : "2013-05-24 17:26:55 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 338019213799206912,
  "created_at" : "2013-05-24 19:50:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337993704772091904",
  "text" : "RT @arneduncan: Great discussion in CT today &amp; glad to announce $1.3M grant to help Newtown's teachers, students &amp; families. http:\/\/t.co\/1a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/1ahP1s5kpE",
        "expanded_url" : "http:\/\/go.usa.gov\/br8e",
        "display_url" : "go.usa.gov\/br8e"
      } ]
    },
    "geo" : { },
    "id_str" : "337992389752926208",
    "text" : "Great discussion in CT today &amp; glad to announce $1.3M grant to help Newtown's teachers, students &amp; families. http:\/\/t.co\/1ahP1s5kpE",
    "id" : 337992389752926208,
    "created_at" : "2013-05-24 18:03:59 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 337993704772091904,
  "created_at" : "2013-05-24 18:09:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/1MKwFHO8o4",
      "expanded_url" : "http:\/\/at.wh.gov\/ln4aU",
      "display_url" : "at.wh.gov\/ln4aU"
    } ]
  },
  "geo" : { },
  "id_str" : "337983447278690304",
  "text" : "Obamacare in action: California's rates \"appear to be significantly less expensive than what forecasters expected.\" http:\/\/t.co\/1MKwFHO8o4",
  "id" : 337983447278690304,
  "created_at" : "2013-05-24 17:28:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337944716882628608",
  "text" : "\"I am absolutely confident that you will uphold the highest of standards.\" \u2014President Obama to this year's Naval Academy graduates",
  "id" : 337944716882628608,
  "created_at" : "2013-05-24 14:54:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337944038802067456",
  "text" : "President Obama to the Class of 2013: \u201CWe need your resolve\u2014the same spirit reflected in your class motto: \u2018Surrender to Nothing.\u2019\u201D",
  "id" : 337944038802067456,
  "created_at" : "2013-05-24 14:51:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337943403650228224",
  "text" : "\"We need your moral courage\u2014the strength to do what\u2019s right, especially when it\u2019s unpopular.\" \u2014President Obama to Naval Academy graduates",
  "id" : 337943403650228224,
  "created_at" : "2013-05-24 14:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337942867219726337",
  "text" : "Obama: \"We need your courage\u2014yes, the daring that tells you to move toward danger when every fiber of your being says to run the other way.\"",
  "id" : 337942867219726337,
  "created_at" : "2013-05-24 14:47:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337942070545223680",
  "text" : "Obama to the Class of 2013: \"I\u2019m going to keep fighting to give you the equipment and support required to meet the missions we ask of you.\"",
  "id" : 337942070545223680,
  "created_at" : "2013-05-24 14:44:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337941793385611266",
  "text" : "President Obama: \u201CThanks to our brave personnel\u2014including our incredible Navy SEALs\u2014we delivered justice to Osama bin Laden.\u201D",
  "id" : 337941793385611266,
  "created_at" : "2013-05-24 14:42:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337941168602116096",
  "text" : "President Obama: \u201COver the past four years, we\u2019ve strengthened our alliances and restored America\u2019s image in the world.\u201D",
  "id" : 337941168602116096,
  "created_at" : "2013-05-24 14:40:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337940310015492096",
  "text" : "President Obama: \"You\u2019re the most diverse class to graduate in Naval Academy history.\"",
  "id" : 337940310015492096,
  "created_at" : "2013-05-24 14:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337940019027267584",
  "text" : "Obama: \"You've proven yourselves morally\u2014living a concept of honor and integrity. This includes treating one another with respect.\"",
  "id" : 337940019027267584,
  "created_at" : "2013-05-24 14:35:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337939660913381376",
  "text" : "Obama to the Naval Academy's Class of 2013: \"Today, each of you can take enormous pride, for you have met the mission of this Academy.\"",
  "id" : 337939660913381376,
  "created_at" : "2013-05-24 14:34:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "337938598567497731",
  "text" : "Happening now: President Obama gives the commencement address at the United States Naval Academy. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 337938598567497731,
  "created_at" : "2013-05-24 14:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/337709517053779968\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/vtWE9f3sT8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BK_JBDmCYAAXvp7.jpg",
      "id_str" : "337709517057974272",
      "id" : 337709517057974272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BK_JBDmCYAAXvp7.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/vtWE9f3sT8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/FfrZdLsMIu",
      "expanded_url" : "http:\/\/at.wh.gov\/lliHa",
      "display_url" : "at.wh.gov\/lliHa"
    } ]
  },
  "geo" : { },
  "id_str" : "337709517053779968",
  "text" : "Worth a read and a RT: President Obama on the future of our fight against terrorism --&gt; http:\/\/t.co\/FfrZdLsMIu, http:\/\/t.co\/vtWE9f3sT8",
  "id" : 337709517053779968,
  "created_at" : "2013-05-23 23:19:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8M4T96pyGK",
      "expanded_url" : "http:\/\/at.wh.gov\/llaWv",
      "display_url" : "at.wh.gov\/llaWv"
    } ]
  },
  "geo" : { },
  "id_str" : "337688656267579394",
  "text" : "President Obama on today's Senate confirmation of Sri Srinivasan to the U.S. Court of Appeals for the D.C. Circuit: http:\/\/t.co\/8M4T96pyGK",
  "id" : 337688656267579394,
  "created_at" : "2013-05-23 21:57:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Doodle4Google",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337661406767878144",
  "text" : "RT @FLOTUS: Congrats to #Doodle4Google winner Sabrina Brady\u2014whose work was inspired by her father's return from serving in Iraq: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Doodle4Google",
        "indices" : [ 12, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/5uiAR1i7b6",
        "expanded_url" : "http:\/\/at.wh.gov\/lkQTV",
        "display_url" : "at.wh.gov\/lkQTV"
      } ]
    },
    "geo" : { },
    "id_str" : "337646780953014273",
    "text" : "Congrats to #Doodle4Google winner Sabrina Brady\u2014whose work was inspired by her father's return from serving in Iraq: http:\/\/t.co\/5uiAR1i7b6",
    "id" : 337646780953014273,
    "created_at" : "2013-05-23 19:10:40 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 337661406767878144,
  "created_at" : "2013-05-23 20:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337645037435375617",
  "text" : "President Obama: \"That strength of character and bond of fellowship, that refutation of fear\u2014that is both our sword and our shield.\"",
  "id" : 337645037435375617,
  "created_at" : "2013-05-23 19:03:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337644550560563200",
  "text" : "Obama: \"Victory will be measured in parents taking their kids to school; immigrants coming to our shores; fans taking in a ballgame.\"",
  "id" : 337644550560563200,
  "created_at" : "2013-05-23 19:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337644250290352129",
  "text" : "Obama: \"Our victory against terrorism won\u2019t be measured in a surrender ceremony on a battleship, or a statue being pulled to the ground.\"",
  "id" : 337644250290352129,
  "created_at" : "2013-05-23 19:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337643995519938560",
  "text" : "President Obama: \"America, we have faced down dangers far greater than al Qaeda by staying true to the values of our founding.\"",
  "id" : 337643995519938560,
  "created_at" : "2013-05-23 18:59:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337642294268264449",
  "text" : "Obama: \"There is no justification beyond politics for Congress to prevent us from closing a facility that should never have been opened.\"",
  "id" : 337642294268264449,
  "created_at" : "2013-05-23 18:52:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337640774277664768",
  "text" : "President Obama: \"Our systematic effort to dismantle terrorist organizations must continue. But this war, like all wars, must end.\"",
  "id" : 337640774277664768,
  "created_at" : "2013-05-23 18:46:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337639176814067712",
  "text" : "President Obama: \"American leadership has always been elevated by our ability to connect with peoples\u2019 hopes, and not simply their fears.\"",
  "id" : 337639176814067712,
  "created_at" : "2013-05-23 18:40:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337638884752101377",
  "text" : "President Obama: \"Foreign assistance cannot be viewed as charity. It is fundamental to our national security.\"",
  "id" : 337638884752101377,
  "created_at" : "2013-05-23 18:39:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337638661959086080",
  "text" : "\"The peaceful realization of individual aspirations will serve as a rebuke to violent extremists.\" \u2014Obama on transitions to democracy",
  "id" : 337638661959086080,
  "created_at" : "2013-05-23 18:38:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337637888319705088",
  "text" : "Obama: \"The use of force must be seen as part of a larger discussion we need to have about a comprehensive counter-terrorism strategy.\"",
  "id" : 337637888319705088,
  "created_at" : "2013-05-23 18:35:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337634943645663232",
  "text" : "Obama: \u201CAmerica does not take strikes to punish individuals\u2014we act against terrorists who pose a continuing and imminent threat.\u201D",
  "id" : 337634943645663232,
  "created_at" : "2013-05-23 18:23:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337634469336973312",
  "text" : "President Obama: \"My Administration has worked vigorously to establish a framework that governs our use of force against terrorists.\"",
  "id" : 337634469336973312,
  "created_at" : "2013-05-23 18:21:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337633016052584448",
  "text" : "Obama: \"We must define our effort not as a boundless \u2018global war on terror\u2019\u2014but rather as a series of persistent, targeted efforts.\"",
  "id" : 337633016052584448,
  "created_at" : "2013-05-23 18:15:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337632662690869248",
  "text" : "President Obama: \u201CFirst, we must finish the work of defeating al Qaeda and its associated forces.\u201D",
  "id" : 337632662690869248,
  "created_at" : "2013-05-23 18:14:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337632481211736065",
  "text" : "President Obama: \u201CWe need all elements of national power to win a battle of wills and a battle of ideas.\u201D",
  "id" : 337632481211736065,
  "created_at" : "2013-05-23 18:13:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337632147072507906",
  "text" : "\u201CWe must make decisions based not on fear, but hard-earned wisdom.\u201D \u2014President Obama on our approach to fighting terrorism",
  "id" : 337632147072507906,
  "created_at" : "2013-05-23 18:12:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337631589859217408",
  "text" : "\"Now is the time to ask ourselves hard questions\u2014about the nature of today\u2019s threats, and how we should confront them.\" \u2014President Obama",
  "id" : 337631589859217408,
  "created_at" : "2013-05-23 18:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337631177810792448",
  "text" : "President Obama: \u201CToday, Osama bin Laden is dead, and so are most of his top lieutenants.\u201D",
  "id" : 337631177810792448,
  "created_at" : "2013-05-23 18:08:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337630972193427457",
  "text" : "Obama: \"We unequivocally banned torture, affirmed our commitment to civilian courts, worked to align our policies with the rule of law.\"",
  "id" : 337630972193427457,
  "created_at" : "2013-05-23 18:07:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337630711085424640",
  "text" : "President Obama: \"We relentlessly targeted al Qaeda\u2019s leadership. We ended the war in Iraq, and brought nearly 150,000 troops home.\"",
  "id" : 337630711085424640,
  "created_at" : "2013-05-23 18:06:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337630587110162432",
  "text" : "President Obama: \"After I took office, we stepped up the war against al Qaeda, but also sought to change its course.\"",
  "id" : 337630587110162432,
  "created_at" : "2013-05-23 18:06:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337630335326109696",
  "text" : "Obama: \u201CFor over two centuries, the United States has been bound together by founding documents that defined who we are as Americans.\u201D",
  "id" : 337630335326109696,
  "created_at" : "2013-05-23 18:05:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "337630195139870721",
  "text" : "Happening now: President Obama speaks on the future of our fight against terrorism. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 337630195139870721,
  "created_at" : "2013-05-23 18:04:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "337616239125991424",
  "text" : "Tune in at 2pm ET for President Obama's speech on the future of our fight against terrorism: http:\/\/t.co\/KvadYk9atb",
  "id" : 337616239125991424,
  "created_at" : "2013-05-23 17:09:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/337599190685343744\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/oXJljvzon3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BK9krN3CYAAoK2m.jpg",
      "id_str" : "337599190693732352",
      "id" : 337599190693732352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BK9krN3CYAAoK2m.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/oXJljvzon3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337599190685343744",
  "text" : "RT if you agree: Every child should have access to a high-quality early education. http:\/\/t.co\/oXJljvzon3",
  "id" : 337599190685343744,
  "created_at" : "2013-05-23 16:01:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven VanRoekel",
      "screen_name" : "stevenvDC",
      "indices" : [ 3, 13 ],
      "id_str" : "26390322",
      "id" : 26390322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DigitalGov",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337590552885342209",
  "text" : "RT @stevenvDC: Today is the 1 Yr Anniversary of #DigitalGov Strategy \u2013 check out the ways we are innovating for the American people: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DigitalGov",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xACDD49gAm",
        "expanded_url" : "http:\/\/wh.gov\/hOOJ",
        "display_url" : "wh.gov\/hOOJ"
      } ]
    },
    "geo" : { },
    "id_str" : "337564036638060545",
    "text" : "Today is the 1 Yr Anniversary of #DigitalGov Strategy \u2013 check out the ways we are innovating for the American people: http:\/\/t.co\/xACDD49gAm",
    "id" : 337564036638060545,
    "created_at" : "2013-05-23 13:41:52 +0000",
    "user" : {
      "name" : "Steven VanRoekel",
      "screen_name" : "stevenvDC",
      "protected" : false,
      "id_str" : "26390322",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2637435481\/8b47f7521e20a93de456cb4b945e05ed_normal.png",
      "id" : 26390322,
      "verified" : true
    }
  },
  "id" : 337590552885342209,
  "created_at" : "2013-05-23 15:27:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole King",
      "screen_name" : "Carole_King",
      "indices" : [ 56, 68 ],
      "id_str" : "34774807",
      "id" : 34774807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/337582783289503744\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/EmusE4c6gI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BK9VwLjCMAAFQXM.jpg",
      "id_str" : "337582783297892352",
      "id" : 337582783297892352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BK9VwLjCMAAFQXM.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EmusE4c6gI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337582783289503744",
  "text" : "Last night, President Obama presented singer-songwriter @Carole_King with the 2013 Gershwin Prize for Popular Song: http:\/\/t.co\/EmusE4c6gI",
  "id" : 337582783289503744,
  "created_at" : "2013-05-23 14:56:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337337759834443776",
  "text" : "RT @FLOTUS: Tonight, the President and First Lady will host a concert honoring Carole King\u2014a 2013 Library of Congress Gershwin Prize winner.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "337307834226196481",
    "text" : "Tonight, the President and First Lady will host a concert honoring Carole King\u2014a 2013 Library of Congress Gershwin Prize winner.",
    "id" : 337307834226196481,
    "created_at" : "2013-05-22 20:43:49 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 337337759834443776,
  "created_at" : "2013-05-22 22:42:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMarch",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337313888301350912",
  "text" : "FACT: Immigrants represent 33% of engineers and 27% of mathematicians, statisticians, and computer scientists in the U.S. #iMarch",
  "id" : 337313888301350912,
  "created_at" : "2013-05-22 21:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oklahoma",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337283334994546688",
  "text" : "President Obama will visit #Oklahoma on Sunday to see firsthand the response to the tornadoes, meet with families &amp; thank first responders.",
  "id" : 337283334994546688,
  "created_at" : "2013-05-22 19:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/337273843590766592\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/lyTIJ2eodV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BK48xheCIAASmKv.jpg",
      "id_str" : "337273843594960896",
      "id" : 337273843594960896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BK48xheCIAASmKv.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/lyTIJ2eodV"
    } ],
    "hashtags" : [ {
      "text" : "iMarch",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "ImmigrationNation",
      "indices" : [ 83, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337273843590766592",
  "text" : "RT if you agree: This is not just a debate about policy\u2014it's about people. #iMarch #ImmigrationNation, http:\/\/t.co\/lyTIJ2eodV",
  "id" : 337273843590766592,
  "created_at" : "2013-05-22 18:28:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMarch",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Sy6RcVblSe",
      "expanded_url" : "http:\/\/at.wh.gov\/lhzq3",
      "display_url" : "at.wh.gov\/lhzq3"
    } ]
  },
  "geo" : { },
  "id_str" : "337259557145432065",
  "text" : "Fixing our broken immigration system will strengthen our economy\u2014and it's time to make it happen: http:\/\/t.co\/Sy6RcVblSe #iMarch",
  "id" : 337259557145432065,
  "created_at" : "2013-05-22 17:31:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 95, 102 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "eBay",
      "screen_name" : "eBay",
      "indices" : [ 104, 109 ],
      "id_str" : "19709040",
      "id" : 19709040
    }, {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 111, 117 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 123, 129 ],
      "id_str" : "2803191",
      "id" : 2803191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMarch",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337252434877489152",
  "text" : "FACT: Immigrants have started 25% of public U.S. companies backed by venture capital\u2014including @Google, @eBay, @Yahoo, and @Intel. #iMarch",
  "id" : 337252434877489152,
  "created_at" : "2013-05-22 17:03:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMarch",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337248113322491905",
  "text" : "FACT: U.S. immigrants represent 50% of PhDs working in math and computer science and 57% of PhDs working in engineering. #iMarch",
  "id" : 337248113322491905,
  "created_at" : "2013-05-22 16:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMarch",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337244000710967296",
  "text" : "FACT: More than 40% of Fortune 500 companies were founded by immigrants or a child of immigrants. #iMarch",
  "id" : 337244000710967296,
  "created_at" : "2013-05-22 16:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMarch",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337240207248203777",
  "text" : "FACT: In 2011, immigrants started 28% of all new businesses in the U.S. #iMarch",
  "id" : 337240207248203777,
  "created_at" : "2013-05-22 16:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iMarch",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337237328617672704",
  "text" : "RT if you agree: It's time for smart immigration reform that strengths our economy by attracting and keeping talent in the U.S. #iMarch",
  "id" : 337237328617672704,
  "created_at" : "2013-05-22 16:03:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 61, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/SQXhL41odk",
      "expanded_url" : "http:\/\/at.wh.gov\/lhMdE",
      "display_url" : "at.wh.gov\/lhMdE"
    } ]
  },
  "geo" : { },
  "id_str" : "337224256222031872",
  "text" : "Competition. Choice. Security. --&gt; http:\/\/t.co\/SQXhL41odk #ObamaCareInThreeWords",
  "id" : 337224256222031872,
  "created_at" : "2013-05-22 15:11:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    }, {
      "name" : "Mayor Tom Menino",
      "screen_name" : "mayortommenino",
      "indices" : [ 77, 92 ],
      "id_str" : "33719856",
      "id" : 33719856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337215474414796800",
  "text" : "RT @DavidAgnew44: \"Our current system is unacceptable and so is inaction.\" \u2014 @MayorTomMenino on why we need immigration reform: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mayor Tom Menino",
        "screen_name" : "mayortommenino",
        "indices" : [ 59, 74 ],
        "id_str" : "33719856",
        "id" : 33719856
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iMarch",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/3CD5zvKzXR",
        "expanded_url" : "http:\/\/at.wh.gov\/lhCdh",
        "display_url" : "at.wh.gov\/lhCdh"
      } ]
    },
    "geo" : { },
    "id_str" : "337210050865135616",
    "text" : "\"Our current system is unacceptable and so is inaction.\" \u2014 @MayorTomMenino on why we need immigration reform: http:\/\/t.co\/3CD5zvKzXR #iMarch",
    "id" : 337210050865135616,
    "created_at" : "2013-05-22 14:15:15 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 337215474414796800,
  "created_at" : "2013-05-22 14:36:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/sk71IYxHRb",
      "expanded_url" : "http:\/\/at.wh.gov\/lht3Z",
      "display_url" : "at.wh.gov\/lht3Z"
    } ]
  },
  "geo" : { },
  "id_str" : "337204893351809027",
  "text" : "\"I encourage the full Senate to bring this bipartisan bill to the floor.\" \u2014President Obama on #ImmigrationReform: http:\/\/t.co\/sk71IYxHRb",
  "id" : 337204893351809027,
  "created_at" : "2013-05-22 13:54:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DREAMers",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336978117530886145",
  "text" : "RT @Simas44: #DREAMers \"They...need a permanent solution that will allow them to fully contribute to the country they call home.\" http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DREAMers",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/kX3BlSqbAB",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/05\/21\/aspiring-americans-share-their-stories-senate-debates-immigration-reform",
        "display_url" : "whitehouse.gov\/blog\/2013\/05\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "336977605855150080",
    "text" : "#DREAMers \"They...need a permanent solution that will allow them to fully contribute to the country they call home.\" http:\/\/t.co\/kX3BlSqbAB",
    "id" : 336977605855150080,
    "created_at" : "2013-05-21 22:51:36 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 336978117530886145,
  "created_at" : "2013-05-21 22:53:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "American Red Cross",
      "screen_name" : "RedCross",
      "indices" : [ 75, 84 ],
      "id_str" : "6519522",
      "id" : 6519522
    }, {
      "name" : "Kevin Durant",
      "screen_name" : "KDTrey5",
      "indices" : [ 133, 141 ],
      "id_str" : "35936474",
      "id" : 35936474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oklahoma",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336968535236558849",
  "text" : "RT @VP: VP called Kevin Durant to thank him for his $1 million donation to @RedCross &amp; for providing moral support to #Oklahoma. @KDTrey5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "American Red Cross",
        "screen_name" : "RedCross",
        "indices" : [ 67, 76 ],
        "id_str" : "6519522",
        "id" : 6519522
      }, {
        "name" : "Kevin Durant",
        "screen_name" : "KDTrey5",
        "indices" : [ 125, 133 ],
        "id_str" : "35936474",
        "id" : 35936474
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oklahoma",
        "indices" : [ 114, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336966635699200000",
    "text" : "VP called Kevin Durant to thank him for his $1 million donation to @RedCross &amp; for providing moral support to #Oklahoma. @KDTrey5",
    "id" : 336966635699200000,
    "created_at" : "2013-05-21 22:08:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 336968535236558849,
  "created_at" : "2013-05-21 22:15:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 11, 23 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 61, 68 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/bQKxynvStG",
      "expanded_url" : "http:\/\/at.wh.gov\/lgjjg",
      "display_url" : "at.wh.gov\/lgjjg"
    } ]
  },
  "geo" : { },
  "id_str" : "336965884335767552",
  "text" : "Today, Dr. @ErnestMoniz was sworn in as our new Secretary of @Energy. Welcome him to Twitter with a follow. http:\/\/t.co\/bQKxynvStG",
  "id" : 336965884335767552,
  "created_at" : "2013-05-21 22:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/336918821443096576\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/mC6mGH7Onb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKz54g7CUAAKBMI.jpg",
      "id_str" : "336918821451485184",
      "id" : 336918821451485184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKz54g7CUAAKBMI.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mC6mGH7Onb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336925435118092289",
  "text" : "RT @petesouza: POTUS receives update this am on Oklahoma tornado aftermath from Sec Napolitano et al http:\/\/t.co\/mC6mGH7Onb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/336918821443096576\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/mC6mGH7Onb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKz54g7CUAAKBMI.jpg",
        "id_str" : "336918821451485184",
        "id" : 336918821451485184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKz54g7CUAAKBMI.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mC6mGH7Onb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336918821443096576",
    "text" : "POTUS receives update this am on Oklahoma tornado aftermath from Sec Napolitano et al http:\/\/t.co\/mC6mGH7Onb",
    "id" : 336918821443096576,
    "created_at" : "2013-05-21 18:58:01 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 336925435118092289,
  "created_at" : "2013-05-21 19:24:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/0onuEtWQ7u",
      "expanded_url" : "http:\/\/at.wh.gov\/lfTwA",
      "display_url" : "at.wh.gov\/lfTwA"
    } ]
  },
  "geo" : { },
  "id_str" : "336913542001332226",
  "text" : "\"Our prayers are with the people of Oklahoma today.\" \u2014President Obama: http:\/\/t.co\/0onuEtWQ7u",
  "id" : 336913542001332226,
  "created_at" : "2013-05-21 18:37:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/336898265939312640\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/E0hxqoVu72",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKznMBuCAAAe82X.jpg",
      "id_str" : "336898265951895552",
      "id" : 336898265951895552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKznMBuCAAAe82X.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/E0hxqoVu72"
    } ],
    "hashtags" : [ {
      "text" : "Oklahoma",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/pIlq2ap74B",
      "expanded_url" : "http:\/\/at.wh.gov\/lfKa8",
      "display_url" : "at.wh.gov\/lfKa8"
    } ]
  },
  "geo" : { },
  "id_str" : "336898265939312640",
  "text" : "RT this to show your support for the people of #Oklahoma\u2014then find out how you can help: http:\/\/t.co\/pIlq2ap74B, http:\/\/t.co\/E0hxqoVu72",
  "id" : 336898265939312640,
  "created_at" : "2013-05-21 17:36:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oklahoma",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/9UOKs09Apt",
      "expanded_url" : "http:\/\/wh.gov\/oklahoma",
      "display_url" : "wh.gov\/oklahoma"
    } ]
  },
  "geo" : { },
  "id_str" : "336861439128109056",
  "text" : "RT @FLOTUS: Our thoughts and prayers are with the people of #Oklahoma. Here's how you can help: http:\/\/t.co\/9UOKs09Apt -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oklahoma",
        "indices" : [ 48, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/9UOKs09Apt",
        "expanded_url" : "http:\/\/wh.gov\/oklahoma",
        "display_url" : "wh.gov\/oklahoma"
      } ]
    },
    "geo" : { },
    "id_str" : "336861160743788544",
    "text" : "Our thoughts and prayers are with the people of #Oklahoma. Here's how you can help: http:\/\/t.co\/9UOKs09Apt -mo",
    "id" : 336861160743788544,
    "created_at" : "2013-05-21 15:08:53 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 336861439128109056,
  "created_at" : "2013-05-21 15:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oklahoma",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/0VF7LQw0QP",
      "expanded_url" : "http:\/\/wh.gov\/oklahoma",
      "display_url" : "wh.gov\/oklahoma"
    } ]
  },
  "geo" : { },
  "id_str" : "336855718453985281",
  "text" : "RT @DrBiden: Our gratitude is with the teachers and first responders helping the people of #Oklahoma. http:\/\/t.co\/0VF7LQw0QP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oklahoma",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/0VF7LQw0QP",
        "expanded_url" : "http:\/\/wh.gov\/oklahoma",
        "display_url" : "wh.gov\/oklahoma"
      } ]
    },
    "geo" : { },
    "id_str" : "336853710472876032",
    "text" : "Our gratitude is with the teachers and first responders helping the people of #Oklahoma. http:\/\/t.co\/0VF7LQw0QP",
    "id" : 336853710472876032,
    "created_at" : "2013-05-21 14:39:17 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 336855718453985281,
  "created_at" : "2013-05-21 14:47:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336846981144133632",
  "text" : "Obama to the people of Moore: \"You face a long road ahead, but you will not travel it alone. Your country will travel it with you.\"",
  "id" : 336846981144133632,
  "created_at" : "2013-05-21 14:12:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336846465420890114",
  "text" : "President Obama: \"I spoke with Governor Fallin to make it clear that Oklahomans would have all the resources they need at their disposal.\"",
  "id" : 336846465420890114,
  "created_at" : "2013-05-21 14:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336846293974540288",
  "text" : "\u201CAs a nation, our full focus is on the urgent work of rescue and the hard work of recovery and rebuilding that lies ahead.\u201D \u2014President Obama",
  "id" : 336846293974540288,
  "created_at" : "2013-05-21 14:09:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrayForOklahoma",
      "indices" : [ 99, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336846127011885058",
  "text" : "President Obama: \"Our gratitude is with the teachers who gave their all to shield their children.\" #PrayForOklahoma",
  "id" : 336846127011885058,
  "created_at" : "2013-05-21 14:09:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrayForOklahoma",
      "indices" : [ 70, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336845991233871872",
  "text" : "President Obama: \u201COur prayers are with the people of Oklahoma today.\u201D #PrayForOklahoma",
  "id" : 336845991233871872,
  "created_at" : "2013-05-21 14:08:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrayForOklahoma",
      "indices" : [ 127, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336845901702242306",
  "text" : "President Obama: \"Yesterday...one of the most destructive tornadoes in memory sliced through Newcastle &amp; Moore, Oklahoma.\" #PrayForOklahoma",
  "id" : 336845901702242306,
  "created_at" : "2013-05-21 14:08:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oklahoma",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/FIUXeDklYW",
      "expanded_url" : "http:\/\/wh.gov\/oklahoma",
      "display_url" : "wh.gov\/oklahoma"
    } ]
  },
  "geo" : { },
  "id_str" : "336845573795762177",
  "text" : "Happening now: President Obama delivers a statement on the devastating tornadoes that impacted #Oklahoma. Watch: http:\/\/t.co\/FIUXeDklYW",
  "id" : 336845573795762177,
  "created_at" : "2013-05-21 14:06:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oklahoma",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/FIUXeDklYW",
      "expanded_url" : "http:\/\/wh.gov\/oklahoma",
      "display_url" : "wh.gov\/oklahoma"
    } ]
  },
  "geo" : { },
  "id_str" : "336833441872097281",
  "text" : "At 10am ET, President Obama delivers a statement on the devastating tornadoes that impacted #Oklahoma: http:\/\/t.co\/FIUXeDklYW",
  "id" : 336833441872097281,
  "created_at" : "2013-05-21 13:18:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oklahoma",
      "indices" : [ 72, 81 ]
    }, {
      "text" : "PrayForOklahoma",
      "indices" : [ 112, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/FIUXeDklYW",
      "expanded_url" : "http:\/\/wh.gov\/oklahoma",
      "display_url" : "wh.gov\/oklahoma"
    } ]
  },
  "geo" : { },
  "id_str" : "336674077941059584",
  "text" : "For information on ways to help those affected by the severe weather in #Oklahoma visit: http:\/\/t.co\/FIUXeDklYW #PrayForOklahoma",
  "id" : 336674077941059584,
  "created_at" : "2013-05-21 02:45:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "American Red Cross",
      "screen_name" : "RedCross",
      "indices" : [ 21, 30 ],
      "id_str" : "6519522",
      "id" : 6519522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "okwx",
      "indices" : [ 10, 15 ]
    }, {
      "text" : "tornado",
      "indices" : [ 137, 145 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/elKagl3JcC",
      "expanded_url" : "https:\/\/safeandwell-mobile.communityos.org",
      "display_url" : "safeandwell-mobile.communityos.org"
    } ]
  },
  "geo" : { },
  "id_str" : "336660637411315715",
  "text" : "RT @fema: #okwx: Use @redcross Safe &amp; Well mobile https:\/\/t.co\/elKagl3JcC &amp; text messaging to check-in with friends &amp; family #tornado",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "American Red Cross",
        "screen_name" : "RedCross",
        "indices" : [ 11, 20 ],
        "id_str" : "6519522",
        "id" : 6519522
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "okwx",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "tornado",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/elKagl3JcC",
        "expanded_url" : "https:\/\/safeandwell-mobile.communityos.org",
        "display_url" : "safeandwell-mobile.communityos.org"
      } ]
    },
    "geo" : { },
    "id_str" : "336655461048807424",
    "text" : "#okwx: Use @redcross Safe &amp; Well mobile https:\/\/t.co\/elKagl3JcC &amp; text messaging to check-in with friends &amp; family #tornado",
    "id" : 336655461048807424,
    "created_at" : "2013-05-21 01:31:31 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 336660637411315715,
  "created_at" : "2013-05-21 01:52:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "City of OKC",
      "screen_name" : "cityofokc",
      "indices" : [ 36, 46 ],
      "id_str" : "14947962",
      "id" : 14947962
    }, {
      "name" : "\u0422\u0438\u043C\u043E\u0444\u0435\u0439",
      "screen_name" : "redcrossokc",
      "indices" : [ 47, 59 ],
      "id_str" : "2982188615",
      "id" : 2982188615
    }, {
      "name" : "NWS Norman",
      "screen_name" : "NWSNorman",
      "indices" : [ 60, 70 ],
      "id_str" : "303994581",
      "id" : 303994581
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "okwx",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "tornado",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "moore",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336660576585519106",
  "text" : "RT @fema: For #okwx updates, follow @cityofokc @RedCrossOKC @NWSNorman #tornado #moore",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "City of OKC",
        "screen_name" : "cityofokc",
        "indices" : [ 26, 36 ],
        "id_str" : "14947962",
        "id" : 14947962
      }, {
        "name" : "\u0422\u0438\u043C\u043E\u0444\u0435\u0439",
        "screen_name" : "redcrossokc",
        "indices" : [ 37, 49 ],
        "id_str" : "2982188615",
        "id" : 2982188615
      }, {
        "name" : "NWS Norman",
        "screen_name" : "NWSNorman",
        "indices" : [ 50, 60 ],
        "id_str" : "303994581",
        "id" : 303994581
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "okwx",
        "indices" : [ 4, 9 ]
      }, {
        "text" : "tornado",
        "indices" : [ 61, 69 ]
      }, {
        "text" : "moore",
        "indices" : [ 70, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336655906861375490",
    "text" : "For #okwx updates, follow @cityofokc @RedCrossOKC @NWSNorman #tornado #moore",
    "id" : 336655906861375490,
    "created_at" : "2013-05-21 01:33:17 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 336660576585519106,
  "created_at" : "2013-05-21 01:51:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/336644849715539969\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/zd3lVPAPZJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKwAtQsCcAE1vQW.jpg",
      "id_str" : "336644849719734273",
      "id" : 336644849719734273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKwAtQsCcAE1vQW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 701,
        "resize" : "fit",
        "w" : 1051
      } ],
      "display_url" : "pic.twitter.com\/zd3lVPAPZJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JlJp7m8lB4",
      "expanded_url" : "http:\/\/wh.gov\/SELr",
      "display_url" : "wh.gov\/SELr"
    } ]
  },
  "geo" : { },
  "id_str" : "336644849715539969",
  "text" : "This evening President Obama spoke with \nOklahoma Governor Mary Fallin. Readout: http:\/\/t.co\/JlJp7m8lB4, http:\/\/t.co\/zd3lVPAPZJ",
  "id" : 336644849715539969,
  "created_at" : "2013-05-21 00:49:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Mary Fallin",
      "screen_name" : "GovMaryFallin",
      "indices" : [ 36, 50 ],
      "id_str" : "194233791",
      "id" : 194233791
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/336636295608664064\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/XLPnF7Z3dJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKv47WLCAAEk9tv.png",
      "id_str" : "336636295617052673",
      "id" : 336636295617052673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKv47WLCAAEk9tv.png",
      "sizes" : [ {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 638
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 638
      } ],
      "display_url" : "pic.twitter.com\/XLPnF7Z3dJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336636295608664064",
  "text" : "President Obama spoke with Oklahoma @GovMaryFallin to express his concern for those affected by the severe weather: http:\/\/t.co\/XLPnF7Z3dJ",
  "id" : 336636295608664064,
  "created_at" : "2013-05-21 00:15:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336583696104689664",
  "text" : "RT @rhodes44: Just announced: This June, the President and the First Lady will travel to Senegal, South Africa, and Tanzania.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "336575210662813696",
    "text" : "Just announced: This June, the President and the First Lady will travel to Senegal, South Africa, and Tanzania.",
    "id" : 336575210662813696,
    "created_at" : "2013-05-20 20:12:38 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 336583696104689664,
  "created_at" : "2013-05-20 20:46:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 45, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/b0pq6PTaJR",
      "expanded_url" : "http:\/\/at.wh.gov\/ldBVl",
      "display_url" : "at.wh.gov\/ldBVl"
    } ]
  },
  "geo" : { },
  "id_str" : "336575448467251200",
  "text" : "Premiums are falling: http:\/\/t.co\/b0pq6PTaJR #ObamaCareInThreeWords",
  "id" : 336575448467251200,
  "created_at" : "2013-05-20 20:13:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336565237060866048",
  "text" : "RT @Simas44: More Obamacare good news. Some Oregon premiums drop by 11%. In Washington, drop 21%. Greater competition and choice. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/6W1bqHvXDN",
        "expanded_url" : "http:\/\/thehill.com\/blogs\/healthwatch\/health-insurance\/300765-dems-early-data-show-premiums-falling-under-obama-health-law",
        "display_url" : "thehill.com\/blogs\/healthwa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "336564627724988416",
    "text" : "More Obamacare good news. Some Oregon premiums drop by 11%. In Washington, drop 21%. Greater competition and choice. http:\/\/t.co\/6W1bqHvXDN",
    "id" : 336564627724988416,
    "created_at" : "2013-05-20 19:30:34 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 336565237060866048,
  "created_at" : "2013-05-20 19:33:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/336550349869559809\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/9ApRB0bbfp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKuqwpVCMAIJt9I.jpg",
      "id_str" : "336550349873754114",
      "id" : 336550349873754114,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKuqwpVCMAIJt9I.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9ApRB0bbfp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336550349869559809",
  "text" : "All smiles in the Oval Office. http:\/\/t.co\/9ApRB0bbfp",
  "id" : 336550349869559809,
  "created_at" : "2013-05-20 18:33:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    }, {
      "name" : "Carole King",
      "screen_name" : "Carole_King",
      "indices" : [ 14, 26 ],
      "id_str" : "34774807",
      "id" : 34774807
    }, {
      "name" : "Paul McCartney",
      "screen_name" : "PaulMcCartney",
      "indices" : [ 82, 96 ],
      "id_str" : "74712538",
      "id" : 74712538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/W1X1KIFpSr",
      "expanded_url" : "http:\/\/at.wh.gov\/ld6sL",
      "display_url" : "at.wh.gov\/ld6sL"
    } ]
  },
  "geo" : { },
  "id_str" : "336531321654493184",
  "text" : "RT @WHVideo: .@Carole_King receives a Gershwin Award at the WH on Wed. Watch when @PaulMcCartney got one in 2011: http:\/\/t.co\/W1X1KIFpSr #M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carole King",
        "screen_name" : "Carole_King",
        "indices" : [ 1, 13 ],
        "id_str" : "34774807",
        "id" : 34774807
      }, {
        "name" : "Paul McCartney",
        "screen_name" : "PaulMcCartney",
        "indices" : [ 69, 83 ],
        "id_str" : "74712538",
        "id" : 74712538
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MusicMonday",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/W1X1KIFpSr",
        "expanded_url" : "http:\/\/at.wh.gov\/ld6sL",
        "display_url" : "at.wh.gov\/ld6sL"
      } ]
    },
    "geo" : { },
    "id_str" : "336529558905958401",
    "text" : ".@Carole_King receives a Gershwin Award at the WH on Wed. Watch when @PaulMcCartney got one in 2011: http:\/\/t.co\/W1X1KIFpSr #MusicMonday",
    "id" : 336529558905958401,
    "created_at" : "2013-05-20 17:11:13 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 336531321654493184,
  "created_at" : "2013-05-20 17:18:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/336509165969211394\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/0nFL71KbQ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKuFTbXCAAEXaKc.jpg",
      "id_str" : "336509165977600001",
      "id" : 336509165977600001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKuFTbXCAAEXaKc.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/0nFL71KbQ3"
    } ],
    "hashtags" : [ {
      "text" : "CIRMarkup",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336509165969211394",
  "text" : "RT so your friends know President Obama's plan to fix our broken immigration system. #CIRMarkup, http:\/\/t.co\/0nFL71KbQ3",
  "id" : 336509165969211394,
  "created_at" : "2013-05-20 15:50:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/336501582818578433\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/pdqEa0NdYe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKt-aB7CEAIn_N7.jpg",
      "id_str" : "336501582826967042",
      "id" : 336501582826967042,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKt-aB7CEAIn_N7.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/pdqEa0NdYe"
    } ],
    "hashtags" : [ {
      "text" : "CIRMarkup",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "336501582818578433",
  "text" : "We're a nation of immigrants-and it's one of our greatest strengths. #CIRMarkup, http:\/\/t.co\/pdqEa0NdYe",
  "id" : 336501582818578433,
  "created_at" : "2013-05-20 15:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZkSjLuALci",
      "expanded_url" : "http:\/\/at.wh.gov\/lcMEo",
      "display_url" : "at.wh.gov\/lcMEo"
    } ]
  },
  "geo" : { },
  "id_str" : "336493692720402433",
  "text" : "President Obama: \"It is important for all of us ... to advocate for an America where everybody has got a fair shot.\" http:\/\/t.co\/ZkSjLuALci",
  "id" : 336493692720402433,
  "created_at" : "2013-05-20 14:48:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/WlK4tE26j2",
      "expanded_url" : "http:\/\/bit.ly\/14J06gs",
      "display_url" : "bit.ly\/14J06gs"
    } ]
  },
  "geo" : { },
  "id_str" : "336488560305766400",
  "text" : "RT @petesouza: NEW behind-the-scenes photos of POTUS and FLOTUS from April: http:\/\/t.co\/WlK4tE26j2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/WlK4tE26j2",
        "expanded_url" : "http:\/\/bit.ly\/14J06gs",
        "display_url" : "bit.ly\/14J06gs"
      } ]
    },
    "geo" : { },
    "id_str" : "336479828511424512",
    "text" : "NEW behind-the-scenes photos of POTUS and FLOTUS from April: http:\/\/t.co\/WlK4tE26j2",
    "id" : 336479828511424512,
    "created_at" : "2013-05-20 13:53:37 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 336488560305766400,
  "created_at" : "2013-05-20 14:28:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morehouse College",
      "screen_name" : "Morehouse",
      "indices" : [ 68, 78 ],
      "id_str" : "111074974",
      "id" : 111074974
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/336272257942974464\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/S71IzDM5IN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKqt1kLCcAEy6Wo.jpg",
      "id_str" : "336272257947168769",
      "id" : 336272257947168769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKqt1kLCcAEy6Wo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/S71IzDM5IN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/PvfcY14DBt",
      "expanded_url" : "http:\/\/wh.gov\/S5s7",
      "display_url" : "wh.gov\/S5s7"
    } ]
  },
  "geo" : { },
  "id_str" : "336272257942974464",
  "text" : "\u201CKeep setting an example\u201D \u2014President Obama to the 2013 graduates of @Morehouse College today: http:\/\/t.co\/PvfcY14DBt, http:\/\/t.co\/S71IzDM5IN",
  "id" : 336272257942974464,
  "created_at" : "2013-05-20 00:08:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morehouse College",
      "screen_name" : "Morehouse",
      "indices" : [ 64, 74 ],
      "id_str" : "111074974",
      "id" : 111074974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/fXsPNgGL6H",
      "expanded_url" : "http:\/\/at.wh.gov\/lb7sM",
      "display_url" : "at.wh.gov\/lb7sM"
    } ]
  },
  "geo" : { },
  "id_str" : "336136507993763842",
  "text" : "Today, President Obama will deliver the commencement address at @Morehouse College. Watch live: http:\/\/t.co\/fXsPNgGL6H",
  "id" : 336136507993763842,
  "created_at" : "2013-05-19 15:09:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335907757855211520",
  "text" : "RT @FLOTUS: Today the First Lady delivered the commencement address at Martin Luther King Jr. Academic Magnet High School. Watch: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/NrHlSKSTi7",
        "expanded_url" : "http:\/\/at.wh.gov\/laxDM",
        "display_url" : "at.wh.gov\/laxDM"
      } ]
    },
    "geo" : { },
    "id_str" : "335907348231118848",
    "text" : "Today the First Lady delivered the commencement address at Martin Luther King Jr. Academic Magnet High School. Watch: http:\/\/t.co\/NrHlSKSTi7",
    "id" : 335907348231118848,
    "created_at" : "2013-05-18 23:58:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 335907757855211520,
  "created_at" : "2013-05-19 00:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/tWJN5B6wWC",
      "expanded_url" : "http:\/\/at.wh.gov\/l9VZW",
      "display_url" : "at.wh.gov\/l9VZW"
    } ]
  },
  "geo" : { },
  "id_str" : "335762655904161792",
  "text" : "\"The American people make me optimistic about where we\u2019re headed as a nation\" \u2014President Obama in his Weekly Address: http:\/\/t.co\/tWJN5B6wWC",
  "id" : 335762655904161792,
  "created_at" : "2013-05-18 14:23:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/335532071021838336\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/3rrOoDhszk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKgMpBBCAAAgQWk.jpg",
      "id_str" : "335532071026032640",
      "id" : 335532071026032640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKgMpBBCAAAgQWk.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/3rrOoDhszk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335532571054186496",
  "text" : "RT @FLOTUS: RT if you believe in the power of a good education. http:\/\/t.co\/3rrOoDhszk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/335532071021838336\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/3rrOoDhszk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKgMpBBCAAAgQWk.jpg",
        "id_str" : "335532071026032640",
        "id" : 335532071026032640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKgMpBBCAAAgQWk.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/3rrOoDhszk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335532071021838336",
    "text" : "RT if you believe in the power of a good education. http:\/\/t.co\/3rrOoDhszk",
    "id" : 335532071021838336,
    "created_at" : "2013-05-17 23:07:34 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 335532571054186496,
  "created_at" : "2013-05-17 23:09:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/xtsZzZkr92",
      "expanded_url" : "http:\/\/at.wh.gov\/l9kVk",
      "display_url" : "at.wh.gov\/l9kVk"
    } ]
  },
  "geo" : { },
  "id_str" : "335505533861781504",
  "text" : "Today, the President signed a memorandum designed to cut red tape, jump start infrastructure projects &amp; create jobs: http:\/\/t.co\/xtsZzZkr92",
  "id" : 335505533861781504,
  "created_at" : "2013-05-17 21:22:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "indices" : [ 3, 13 ],
      "id_str" : "22012091",
      "id" : 22012091
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 105, 116 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhipHoyer\/status\/335462088669544448\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/lEnE4KBvfP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKfM_gcCQAAOwTq.jpg",
      "id_str" : "335462088673738752",
      "id" : 335462088673738752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKfM_gcCQAAOwTq.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/lEnE4KBvfP"
    } ],
    "hashtags" : [ {
      "text" : "POTUS",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "MakeItInAmerica",
      "indices" : [ 88, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335492908021055489",
  "text" : "RT @WhipHoyer: Listening to #POTUS talk about investing in manufacturing to create jobs #MakeItInAmerica @whitehouse http:\/\/t.co\/lEnE4KBvfP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 90, 101 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhipHoyer\/status\/335462088669544448\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/lEnE4KBvfP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKfM_gcCQAAOwTq.jpg",
        "id_str" : "335462088673738752",
        "id" : 335462088673738752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKfM_gcCQAAOwTq.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/lEnE4KBvfP"
      } ],
      "hashtags" : [ {
        "text" : "POTUS",
        "indices" : [ 13, 19 ]
      }, {
        "text" : "MakeItInAmerica",
        "indices" : [ 73, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335462088669544448",
    "text" : "Listening to #POTUS talk about investing in manufacturing to create jobs #MakeItInAmerica @whitehouse http:\/\/t.co\/lEnE4KBvfP",
    "id" : 335462088669544448,
    "created_at" : "2013-05-17 18:29:29 +0000",
    "user" : {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "protected" : false,
      "id_str" : "22012091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742490369347203072\/WLvGn-ia_normal.jpg",
      "id" : 22012091,
      "verified" : true
    }
  },
  "id" : 335492908021055489,
  "created_at" : "2013-05-17 20:31:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Navajo Tech",
      "screen_name" : "NavajoTech",
      "indices" : [ 22, 33 ],
      "id_str" : "290164555",
      "id" : 290164555
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/335462054137823233\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/avYz8EmiQm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKfM9f0CAAEUuoh.jpg",
      "id_str" : "335462054146211841",
      "id" : 335462054146211841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKfM9f0CAAEUuoh.jpg",
      "sizes" : [ {
        "h" : 980,
        "resize" : "fit",
        "w" : 1470
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/avYz8EmiQm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335473539178176512",
  "text" : "RT @DrBiden: Congrats @NavajoTech graduates. We are excited to see what you'll do next! -Jill http:\/\/t.co\/avYz8EmiQm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Navajo Tech",
        "screen_name" : "NavajoTech",
        "indices" : [ 9, 20 ],
        "id_str" : "290164555",
        "id" : 290164555
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/335462054137823233\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/avYz8EmiQm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKfM9f0CAAEUuoh.jpg",
        "id_str" : "335462054146211841",
        "id" : 335462054146211841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKfM9f0CAAEUuoh.jpg",
        "sizes" : [ {
          "h" : 980,
          "resize" : "fit",
          "w" : 1470
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/avYz8EmiQm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335462054137823233",
    "text" : "Congrats @NavajoTech graduates. We are excited to see what you'll do next! -Jill http:\/\/t.co\/avYz8EmiQm",
    "id" : 335462054137823233,
    "created_at" : "2013-05-17 18:29:21 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 335473539178176512,
  "created_at" : "2013-05-17 19:14:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335451132572889088",
  "text" : "President Obama: \"America remains a place where you can make it if you try \u2013 and we will all prosper, together.\"",
  "id" : 335451132572889088,
  "created_at" : "2013-05-17 17:45:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335449679707910144",
  "text" : "President Obama: \"I\u2019m going to keep trying to work with both parties in Washington to make progress. Because our challenges are solvable.\"",
  "id" : 335449679707910144,
  "created_at" : "2013-05-17 17:40:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335448693790617600",
  "text" : "Obama: \"We need to invest in high-tech manufacturing centers, because I want the next revolution in manufacturing to be made in America.\"",
  "id" : 335448693790617600,
  "created_at" : "2013-05-17 17:36:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335446631963049987",
  "text" : "Obama: Thanks to the grit &amp; determination of the American people, we have cleared away the rubble of crisis...but our work is not done.\"",
  "id" : 335446631963049987,
  "created_at" : "2013-05-17 17:28:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335445515816812544",
  "text" : "President Obama: \"The middle class will always be my number one focus. Period. Your jobs. Your families. Your communities.\"",
  "id" : 335445515816812544,
  "created_at" : "2013-05-17 17:23:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "335444326446411776",
  "text" : "Happening now: President Obama speaks on ways we can make America a magnet for good middle class jobs in Baltimore: http:\/\/t.co\/KvadYk9atb",
  "id" : 335444326446411776,
  "created_at" : "2013-05-17 17:18:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/HyY2cTl0jh",
      "expanded_url" : "http:\/\/at.wh.gov\/l8DEe",
      "display_url" : "at.wh.gov\/l8DEe"
    } ]
  },
  "geo" : { },
  "id_str" : "335426377048264704",
  "text" : "At 1:20ET: President Obama speaks on early childhood education, infrastructure &amp; middle class jobs from Baltimore: http:\/\/t.co\/HyY2cTl0jh",
  "id" : 335426377048264704,
  "created_at" : "2013-05-17 16:07:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335420765568647170",
  "text" : "RT @VP: In Vol. 7 of #BeingBiden, the VP reads letters about reducing gun violence from 3rd graders in Philadelphia. Listen: https:\/\/t.co\/d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeingBiden",
        "indices" : [ 13, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/dV9I2teDBv",
        "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/vol-7-gems-of-wisdom",
        "display_url" : "soundcloud.com\/whitehouse\/vol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "335414392697012224",
    "text" : "In Vol. 7 of #BeingBiden, the VP reads letters about reducing gun violence from 3rd graders in Philadelphia. Listen: https:\/\/t.co\/dV9I2teDBv",
    "id" : 335414392697012224,
    "created_at" : "2013-05-17 15:19:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 335420765568647170,
  "created_at" : "2013-05-17 15:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/jWxYrlosLD",
      "expanded_url" : "http:\/\/at.wh.gov\/l8l33",
      "display_url" : "at.wh.gov\/l8l33"
    } ]
  },
  "geo" : { },
  "id_str" : "335401543719333890",
  "text" : "President Obama is on his way to Baltimore, the 2nd stop on his Middle Class Jobs &amp; Opportunity Tour. Trip preview: http:\/\/t.co\/jWxYrlosLD",
  "id" : 335401543719333890,
  "created_at" : "2013-05-17 14:28:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/1HoNMIEKO7",
      "expanded_url" : "http:\/\/at.wh.gov\/l71d9",
      "display_url" : "at.wh.gov\/l71d9"
    } ]
  },
  "geo" : { },
  "id_str" : "335205691352559616",
  "text" : "Preview President Obama's trip to Baltimore where he'll discuss the importance of manufacturing and early education. http:\/\/t.co\/1HoNMIEKO7",
  "id" : 335205691352559616,
  "created_at" : "2013-05-17 01:30:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 28, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/dZMGxUctGR",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/sec-kathleen-sebelius\/secretary-sebelius-whats_b_3288382.html",
      "display_url" : "huffingtonpost.com\/sec-kathleen-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335168236658229248",
  "text" : "RT @Sebelius: Peace of mind #ObamaCareInThreeWords http:\/\/t.co\/dZMGxUctGR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCareInThreeWords",
        "indices" : [ 14, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/dZMGxUctGR",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/sec-kathleen-sebelius\/secretary-sebelius-whats_b_3288382.html",
        "display_url" : "huffingtonpost.com\/sec-kathleen-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "335166483128807424",
    "text" : "Peace of mind #ObamaCareInThreeWords http:\/\/t.co\/dZMGxUctGR",
    "id" : 335166483128807424,
    "created_at" : "2013-05-16 22:54:51 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 335168236658229248,
  "created_at" : "2013-05-16 23:01:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/335156247147991040\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/RemLWRvd8T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKa21L_CUAEBbnC.jpg",
      "id_str" : "335156247152185345",
      "id" : 335156247152185345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKa21L_CUAEBbnC.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/RemLWRvd8T"
    } ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 21, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335156247147991040",
  "text" : "Affordable Care Act. #ObamaCareInThreeWords, http:\/\/t.co\/RemLWRvd8T",
  "id" : 335156247147991040,
  "created_at" : "2013-05-16 22:14:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 47, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/qlWn22ycrO",
      "expanded_url" : "http:\/\/at.wh.gov\/l6Xn0",
      "display_url" : "at.wh.gov\/l6Xn0"
    } ]
  },
  "geo" : { },
  "id_str" : "335150697655984129",
  "text" : "Mammograms are covered. http:\/\/t.co\/qlWn22ycrO #ObamaCareInThreeWords",
  "id" : 335150697655984129,
  "created_at" : "2013-05-16 21:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/macon44\/status\/335117327777538048\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/4LYBI274Qr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKaTbyCCIAAF4tT.png",
      "id_str" : "335117327781732352",
      "id" : 335117327781732352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKaTbyCCIAAF4tT.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 393
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 393
      } ],
      "display_url" : "pic.twitter.com\/4LYBI274Qr"
    } ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 39, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335133295283142656",
  "text" : "RT @macon44: Parents covering children #ObamaCareInThreeWords http:\/\/t.co\/4LYBI274Qr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/macon44\/status\/335117327777538048\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/4LYBI274Qr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKaTbyCCIAAF4tT.png",
        "id_str" : "335117327781732352",
        "id" : 335117327781732352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKaTbyCCIAAF4tT.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 393
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 393
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 393
        } ],
        "display_url" : "pic.twitter.com\/4LYBI274Qr"
      } ],
      "hashtags" : [ {
        "text" : "ObamaCareInThreeWords",
        "indices" : [ 26, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335117327777538048",
    "text" : "Parents covering children #ObamaCareInThreeWords http:\/\/t.co\/4LYBI274Qr",
    "id" : 335117327777538048,
    "created_at" : "2013-05-16 19:39:31 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 335133295283142656,
  "created_at" : "2013-05-16 20:42:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 48, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/LqWmY37RQf",
      "expanded_url" : "http:\/\/at.wh.gov\/l6MQy",
      "display_url" : "at.wh.gov\/l6MQy"
    } ]
  },
  "geo" : { },
  "id_str" : "335128106610348032",
  "text" : "Share your story ---&gt; http:\/\/t.co\/LqWmY37RQf #ObamaCareInThreeWords",
  "id" : 335128106610348032,
  "created_at" : "2013-05-16 20:22:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 57, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335123050276200448",
  "text" : "RT @NancyPelosi: Affordable. Accessible. Constitutional. #ObamaCareInThreeWords",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCareInThreeWords",
        "indices" : [ 40, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335119839876231168",
    "text" : "Affordable. Accessible. Constitutional. #ObamaCareInThreeWords",
    "id" : 335119839876231168,
    "created_at" : "2013-05-16 19:49:30 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 335123050276200448,
  "created_at" : "2013-05-16 20:02:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alissa",
      "screen_name" : "_al_man",
      "indices" : [ 3, 11 ],
      "id_str" : "224716965",
      "id" : 224716965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 13, 35 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 58, 68 ]
    }, {
      "text" : "ACA",
      "indices" : [ 69, 73 ]
    }, {
      "text" : "PatientsOverPolitics",
      "indices" : [ 74, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335121451399131136",
  "text" : "RT @_al_man: #ObamaCareInThreeWords: Already Saving Lives #Obamacare #ACA #PatientsOverPolitics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCareInThreeWords",
        "indices" : [ 0, 22 ]
      }, {
        "text" : "Obamacare",
        "indices" : [ 45, 55 ]
      }, {
        "text" : "ACA",
        "indices" : [ 56, 60 ]
      }, {
        "text" : "PatientsOverPolitics",
        "indices" : [ 61, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335118276130664449",
    "text" : "#ObamaCareInThreeWords: Already Saving Lives #Obamacare #ACA #PatientsOverPolitics",
    "id" : 335118276130664449,
    "created_at" : "2013-05-16 19:43:17 +0000",
    "user" : {
      "name" : "Alissa",
      "screen_name" : "_al_man",
      "protected" : false,
      "id_str" : "224716965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545793604837707776\/9b-Sjrt3_normal.jpeg",
      "id" : 224716965,
      "verified" : false
    }
  },
  "id" : 335121451399131136,
  "created_at" : "2013-05-16 19:55:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DdoubleP",
      "screen_name" : "ddoublep",
      "indices" : [ 3, 12 ],
      "id_str" : "16195937",
      "id" : 16195937
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInThreeWords",
      "indices" : [ 35, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335119601992073216",
  "text" : "RT @ddoublep: Reduces the deficit. #ObamacareInThreeWords",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamacareInThreeWords",
        "indices" : [ 21, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335108729777315840",
    "text" : "Reduces the deficit. #ObamacareInThreeWords",
    "id" : 335108729777315840,
    "created_at" : "2013-05-16 19:05:21 +0000",
    "user" : {
      "name" : "DdoubleP",
      "screen_name" : "ddoublep",
      "protected" : false,
      "id_str" : "16195937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436269456197554176\/ntPwFDy2_normal.jpeg",
      "id" : 16195937,
      "verified" : false
    }
  },
  "id" : 335119601992073216,
  "created_at" : "2013-05-16 19:48:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 52, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/ouPLaoGeBF",
      "expanded_url" : "http:\/\/at.wh.gov\/l6H7I",
      "display_url" : "at.wh.gov\/l6H7I"
    } ]
  },
  "geo" : { },
  "id_str" : "335117613896200192",
  "text" : "Young adults covered ---&gt; http:\/\/t.co\/ouPLaoGeBF #ObamaCareInThreeWords",
  "id" : 335117613896200192,
  "created_at" : "2013-05-16 19:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 46, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/P7hDVj0QNv",
      "expanded_url" : "http:\/\/wh.gov\/healthreform",
      "display_url" : "wh.gov\/healthreform"
    } ]
  },
  "geo" : { },
  "id_str" : "335114747626287104",
  "text" : "Get the facts ---&gt; http:\/\/t.co\/P7hDVj0QNv, #ObamaCareInThreeWords",
  "id" : 335114747626287104,
  "created_at" : "2013-05-16 19:29:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 20, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335113296388698112",
  "text" : "No lifetime limits. #ObamaCareInThreeWords",
  "id" : 335113296388698112,
  "created_at" : "2013-05-16 19:23:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Osborne",
      "screen_name" : "OsborneInk",
      "indices" : [ 3, 14 ],
      "id_str" : "63065243",
      "id" : 63065243
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 38, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335112731332067328",
  "text" : "RT @OsborneInk: Birth control covered #ObamaCareInThreeWords",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCareInThreeWords",
        "indices" : [ 22, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335111857415282688",
    "text" : "Birth control covered #ObamaCareInThreeWords",
    "id" : 335111857415282688,
    "created_at" : "2013-05-16 19:17:47 +0000",
    "user" : {
      "name" : "Matt Osborne",
      "screen_name" : "OsborneInk",
      "protected" : false,
      "id_str" : "63065243",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784981272816787456\/gOaloGuq_normal.jpg",
      "id" : 63065243,
      "verified" : false
    }
  },
  "id" : 335112731332067328,
  "created_at" : "2013-05-16 19:21:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nerdy Wonka",
      "screen_name" : "NerdyWonka",
      "indices" : [ 3, 14 ],
      "id_str" : "325265073",
      "id" : 325265073
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 16, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335112012378030083",
  "text" : "RT @NerdyWonka: #ObamaCareInThreeWords Preexisting Conditions Covered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCareInThreeWords",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335109940303781888",
    "text" : "#ObamaCareInThreeWords Preexisting Conditions Covered",
    "id" : 335109940303781888,
    "created_at" : "2013-05-16 19:10:10 +0000",
    "user" : {
      "name" : "Nerdy Wonka",
      "screen_name" : "NerdyWonka",
      "protected" : false,
      "id_str" : "325265073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3321150452\/91262959f936ac25c801242c6304d269_normal.jpeg",
      "id" : 325265073,
      "verified" : false
    }
  },
  "id" : 335112012378030083,
  "created_at" : "2013-05-16 19:18:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Darrell Issa",
      "screen_name" : "DarrellIssa",
      "indices" : [ 61, 73 ],
      "id_str" : "22509548",
      "id" : 22509548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 86, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/WCytnfskG3",
      "expanded_url" : "https:\/\/www.google.com\/#hl=en&sclient=psy-ab&q=Obamacare+saved+my+life",
      "display_url" : "google.com\/#hl=en&sclient\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335110748776828928",
  "text" : "RT @jesseclee44: \"Saved my life\" https:\/\/t.co\/WCytnfskG3  RT @DarrellIssa: Hey folks, #ObamaCareInThreeWords -- go!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Darrell Issa",
        "screen_name" : "DarrellIssa",
        "indices" : [ 44, 56 ],
        "id_str" : "22509548",
        "id" : 22509548
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCareInThreeWords",
        "indices" : [ 69, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/WCytnfskG3",
        "expanded_url" : "https:\/\/www.google.com\/#hl=en&sclient=psy-ab&q=Obamacare+saved+my+life",
        "display_url" : "google.com\/#hl=en&sclient\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "335103758495277056",
    "text" : "\"Saved my life\" https:\/\/t.co\/WCytnfskG3  RT @DarrellIssa: Hey folks, #ObamaCareInThreeWords -- go!",
    "id" : 335103758495277056,
    "created_at" : "2013-05-16 18:45:36 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 335110748776828928,
  "created_at" : "2013-05-16 19:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/335104215863132160\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/yCHSmuxkKj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKaHgkWCAAEZB_U.jpg",
      "id_str" : "335104215867326465",
      "id" : 335104215867326465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKaHgkWCAAEZB_U.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yCHSmuxkKj"
    } ],
    "hashtags" : [ {
      "text" : "ObamaCareInThreeWords",
      "indices" : [ 16, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335104215863132160",
  "text" : "It's. The. Law. #ObamaCareInThreeWords, http:\/\/t.co\/yCHSmuxkKj",
  "id" : 335104215863132160,
  "created_at" : "2013-05-16 18:47:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 54, 61 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/335093522170535936\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/PJX9rgxQoG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKZ9yHQCYAAdd4F.jpg",
      "id_str" : "335093522178924544",
      "id" : 335093522178924544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKZ9yHQCYAAdd4F.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/PJX9rgxQoG"
    } ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/yBbHL80leY",
      "expanded_url" : "http:\/\/wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "335093522170535936",
  "text" : "Happening now: Tune in for the first-ever #WeTheGeeks @Google+ Hangout at the White House --&gt; http:\/\/t.co\/yBbHL80leY http:\/\/t.co\/PJX9rgxQoG",
  "id" : 335093522170535936,
  "created_at" : "2013-05-16 18:04:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "335074151763148800",
  "text" : "Happening now: President Obama holds a joint press conference with Turkish Prime Minister Erdogan. http:\/\/t.co\/JludLrcLOd",
  "id" : 335074151763148800,
  "created_at" : "2013-05-16 16:47:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 86, 93 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 62, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/e1so9Wi6yQ",
      "expanded_url" : "http:\/\/goo.gl\/O22Mb",
      "display_url" : "goo.gl\/O22Mb"
    } ]
  },
  "geo" : { },
  "id_str" : "335055172357210113",
  "text" : "If you're into science and innovation, RSVP for today's first #WeTheGeeks White House @Google+ hangout ---&gt; http:\/\/t.co\/e1so9Wi6yQ",
  "id" : 335055172357210113,
  "created_at" : "2013-05-16 15:32:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "335043042794950656",
  "text" : "Tune in at 12pm ET for President Obama's joint press conference with Turkish Prime Minister Erdogan. http:\/\/t.co\/JludLrcLOd",
  "id" : 335043042794950656,
  "created_at" : "2013-05-16 14:44:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335040480838565888",
  "text" : "RT @jesseclee44: \"most significant advance in information policies by the fed gov since the passage of the Freedom of Information Act\" http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ZS96tgMZga",
        "expanded_url" : "http:\/\/www.slate.com\/articles\/technology\/future_tense\/2013\/05\/open_data_executive_order_is_the_best_thing_obama_s_done_this_month.single.html",
        "display_url" : "slate.com\/articles\/techn\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "335031651556003840",
    "text" : "\"most significant advance in information policies by the fed gov since the passage of the Freedom of Information Act\" http:\/\/t.co\/ZS96tgMZga",
    "id" : 335031651556003840,
    "created_at" : "2013-05-16 13:59:04 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 335040480838565888,
  "created_at" : "2013-05-16 14:34:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335024380302204930",
  "text" : "RT @rhodes44: Today, POTUS will welcome PM Erdogan of Turkey to the White House for a meeting, press conference, and working dinner.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335022772726157314",
    "text" : "Today, POTUS will welcome PM Erdogan of Turkey to the White House for a meeting, press conference, and working dinner.",
    "id" : 335022772726157314,
    "created_at" : "2013-05-16 13:23:48 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 335024380302204930,
  "created_at" : "2013-05-16 13:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/334814733028966400\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/uCJoXsaFKZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKWAOcwCQAA3cAv.jpg",
      "id_str" : "334814733033160704",
      "id" : 334814733033160704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKWAOcwCQAA3cAv.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/uCJoXsaFKZ"
    } ],
    "hashtags" : [ {
      "text" : "ObamaCares",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334814733028966400",
  "text" : "President #ObamaCares\u2014and that's why he's fighting to help millions of Americans afford quality health insurance. http:\/\/t.co\/uCJoXsaFKZ",
  "id" : 334814733028966400,
  "created_at" : "2013-05-15 23:37:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "334795463599472641",
  "text" : "Happening now: President Obama delivers a statement on the situation regarding the Internal Revenue Service. Watch: http:\/\/t.co\/JludLrcLOd",
  "id" : 334795463599472641,
  "created_at" : "2013-05-15 22:20:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "334782952993071104",
  "text" : "At 6pm ET, President Obama will deliver a statement on the situation regarding the Internal Revenue Service. Watch: http:\/\/t.co\/JludLrcLOd",
  "id" : 334782952993071104,
  "created_at" : "2013-05-15 21:30:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334764203854401537",
  "text" : "RT @Simas44: More good news on Obamacare implementation. \"We are pleasantly surprised at what we're seeing in the rates...\" http:\/\/t.co\/1ND\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/1NDlwn3ykj",
        "expanded_url" : "http:\/\/seattletimes.com\/html\/localnews\/2020982752_apwahealthoverhaulwash1stldwritethru.html",
        "display_url" : "seattletimes.com\/html\/localnews\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "334760281400029184",
    "text" : "More good news on Obamacare implementation. \"We are pleasantly surprised at what we're seeing in the rates...\" http:\/\/t.co\/1NDlwn3ykj",
    "id" : 334760281400029184,
    "created_at" : "2013-05-15 20:00:45 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 334764203854401537,
  "created_at" : "2013-05-15 20:16:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacares",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334748909236781056",
  "text" : "Please retweet: Health care reform is helping millions of Americans afford quality health insurance\u2014and it's here to stay. #Obamacares",
  "id" : 334748909236781056,
  "created_at" : "2013-05-15 19:15:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacares",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334743919759867904",
  "text" : "FACT: Thanks to Obamacare, 12.8 million consumers received $1.1 billion in rebates from their insurance companies in 2012. #Obamacares",
  "id" : 334743919759867904,
  "created_at" : "2013-05-15 18:55:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 20, 24 ]
    }, {
      "text" : "Obamacares",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334738911974793216",
  "text" : "FACT: Thanks to the #ACA, more than 3.1 million more young adults under 26 have health insurance through their parents' plans. #Obamacares",
  "id" : 334738911974793216,
  "created_at" : "2013-05-15 18:35:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacares",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334734733697249280",
  "text" : "FACT: Since 2010, health care reform has saved 6.3 million seniors more than $6.1 billion on their prescription drugs. #Obamacares",
  "id" : 334734733697249280,
  "created_at" : "2013-05-15 18:19:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacares",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334727471318589440",
  "text" : "FACT: Thanks to health care reform, 54 million more Americans have access to free preventive services\u2014like cancer screenings. #Obamacares",
  "id" : 334727471318589440,
  "created_at" : "2013-05-15 17:50:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacares",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/TdVAy5mDso",
      "expanded_url" : "http:\/\/at.wh.gov\/l3q68",
      "display_url" : "at.wh.gov\/l3q68"
    } ]
  },
  "geo" : { },
  "id_str" : "334722445661577216",
  "text" : "In case you missed it, health care reform is causing insurers to lower rates through competition: http:\/\/t.co\/TdVAy5mDso #Obamacares",
  "id" : 334722445661577216,
  "created_at" : "2013-05-15 17:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/334714076490002432\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/KeLWFwpvqe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKUkrd8CcAARp6F.jpg",
      "id_str" : "334714076498391040",
      "id" : 334714076498391040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKUkrd8CcAARp6F.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KeLWFwpvqe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/P76VccVbsK",
      "expanded_url" : "http:\/\/at.wh.gov\/l3Q5H",
      "display_url" : "at.wh.gov\/l3Q5H"
    } ]
  },
  "geo" : { },
  "id_str" : "334714076490002432",
  "text" : "Happy National Women's Health Week! http:\/\/t.co\/P76VccVbsK, http:\/\/t.co\/KeLWFwpvqe",
  "id" : 334714076490002432,
  "created_at" : "2013-05-15 16:57:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334691383598256130",
  "text" : "Obama: \"We should not pause &amp; remember to thank first responders &amp; police officers only in the wake of tragedy. We should do it every day.\"",
  "id" : 334691383598256130,
  "created_at" : "2013-05-15 15:26:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334689926312513536",
  "text" : "President Obama: \"The brave officers we gather to remember today devoted themselves so fully to others\u2014to serve and to protect others.\"",
  "id" : 334689926312513536,
  "created_at" : "2013-05-15 15:21:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "334689441815855104",
  "text" : "Happening now: President Obama speaks at the National Peace Officers Memorial Service. http:\/\/t.co\/JludLrcLOd",
  "id" : 334689441815855104,
  "created_at" : "2013-05-15 15:19:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "334669560160604161",
  "text" : "At 11:00am ET: President Obama speaks at the National Peace Officers Memorial Service. Watch: http:\/\/t.co\/JludLrcLOd",
  "id" : 334669560160604161,
  "created_at" : "2013-05-15 14:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Gqjs2uJjEa",
      "expanded_url" : "http:\/\/at.wh.gov\/l2mFc",
      "display_url" : "at.wh.gov\/l2mFc"
    } ]
  },
  "geo" : { },
  "id_str" : "334485291270287361",
  "text" : "President Obama: The IRS report\u2019s findings are \"intolerable and inexcusable.\" http:\/\/t.co\/Gqjs2uJjEa",
  "id" : 334485291270287361,
  "created_at" : "2013-05-15 01:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/uotgUufExu",
      "expanded_url" : "http:\/\/ow.ly\/l28ga",
      "display_url" : "ow.ly\/l28ga"
    } ]
  },
  "geo" : { },
  "id_str" : "334439323317448704",
  "text" : "RT to spread the word: Washington state residents may see lower health care premiums thanks to Obamacare. http:\/\/t.co\/uotgUufExu",
  "id" : 334439323317448704,
  "created_at" : "2013-05-14 22:45:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334430725946351617",
  "text" : "RT @FLOTUS: The First Lady: \"Reach out and get our kids and our communities back on track toward healthier, happier living.\" http:\/\/t.co\/sc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/sc7LoZWE6e",
        "expanded_url" : "http:\/\/ow.ly\/l20YJ",
        "display_url" : "ow.ly\/l20YJ"
      } ]
    },
    "geo" : { },
    "id_str" : "334413193852096512",
    "text" : "The First Lady: \"Reach out and get our kids and our communities back on track toward healthier, happier living.\" http:\/\/t.co\/sc7LoZWE6e",
    "id" : 334413193852096512,
    "created_at" : "2013-05-14 21:01:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 334430725946351617,
  "created_at" : "2013-05-14 22:11:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/334413709596303360\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/DYlPKZskNZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKQTf0DCIAAY9-s.jpg",
      "id_str" : "334413709600497664",
      "id" : 334413709600497664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKQTf0DCIAAY9-s.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/DYlPKZskNZ"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 61, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334413709596303360",
  "text" : "RT if you agree that immigration makes our country stronger. #ImmigrationNation, http:\/\/t.co\/DYlPKZskNZ",
  "id" : 334413709596303360,
  "created_at" : "2013-05-14 21:03:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 93, 104 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 116, 125 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334410206849150976",
  "text" : "RT @VP: VP ceremonially swears in Sylvia Mathews Burwell as director of the OMB today at the @whitehouse. (WHPhoto) @OMBPress http:\/\/t.co\/p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 85, 96 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "OMBPress",
        "screen_name" : "OMBPress",
        "indices" : [ 108, 117 ],
        "id_str" : "337742544",
        "id" : 337742544
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/334408626934525953\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/pW9Sm0xdlb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKQO39rCMAAHrep.jpg",
        "id_str" : "334408626942914560",
        "id" : 334408626942914560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKQO39rCMAAHrep.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pW9Sm0xdlb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "334408626934525953",
    "text" : "VP ceremonially swears in Sylvia Mathews Burwell as director of the OMB today at the @whitehouse. (WHPhoto) @OMBPress http:\/\/t.co\/pW9Sm0xdlb",
    "id" : 334408626934525953,
    "created_at" : "2013-05-14 20:43:24 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 334410206849150976,
  "created_at" : "2013-05-14 20:49:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WetheGeeks",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/e4TueErNii",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/05\/14\/hanging-out-we-geeks",
      "display_url" : "whitehouse.gov\/blog\/2013\/05\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334400315338137600",
  "text" : "RT @whitehouseostp: Introducing #WetheGeeks! http:\/\/t.co\/e4TueErNii",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WetheGeeks",
        "indices" : [ 12, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/e4TueErNii",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/05\/14\/hanging-out-we-geeks",
        "display_url" : "whitehouse.gov\/blog\/2013\/05\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "334393638383652864",
    "text" : "Introducing #WetheGeeks! http:\/\/t.co\/e4TueErNii",
    "id" : 334393638383652864,
    "created_at" : "2013-05-14 19:43:50 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 334400315338137600,
  "created_at" : "2013-05-14 20:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/xRBLo654u6",
      "expanded_url" : "http:\/\/at.wh.gov\/kZvSK",
      "display_url" : "at.wh.gov\/kZvSK"
    } ]
  },
  "geo" : { },
  "id_str" : "334050812001140737",
  "text" : "\"Our two peoples stand as one.\" \u2014President Obama at a joint press conference with UK Prime Minister David Cameron: http:\/\/t.co\/xRBLo654u6",
  "id" : 334050812001140737,
  "created_at" : "2013-05-13 21:01:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/333975889744371712\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/7ztdgdxa8a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKKFTWBCIAATiEL.jpg",
      "id_str" : "333975889752760320",
      "id" : 333975889752760320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKKFTWBCIAATiEL.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 769
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7ztdgdxa8a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333977581177159680",
  "text" : "RT @petesouza: POTUS and PM Cameron in East Room now http:\/\/t.co\/7ztdgdxa8a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/333975889744371712\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/7ztdgdxa8a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BKKFTWBCIAATiEL.jpg",
        "id_str" : "333975889752760320",
        "id" : 333975889752760320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKKFTWBCIAATiEL.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 769
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 769
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7ztdgdxa8a"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "333975889744371712",
    "text" : "POTUS and PM Cameron in East Room now http:\/\/t.co\/7ztdgdxa8a",
    "id" : 333975889744371712,
    "created_at" : "2013-05-13 16:03:51 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 333977581177159680,
  "created_at" : "2013-05-13 16:10:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333971865326465026",
  "text" : "\u201CIf the history of our peoples shows anything, it\u2019s that we persevere.\u201D \u2014President Obama on the U.S. and the U.K.",
  "id" : 333971865326465026,
  "created_at" : "2013-05-13 15:47:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333971023005376513",
  "text" : "\"We've got a real opportunity to cut tariffs, open markets, create jobs and make all our economies even more competitive.\" \u2014Obama on trade",
  "id" : 333971023005376513,
  "created_at" : "2013-05-13 15:44:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333970474268762113",
  "text" : "President Obama: \"The great alliance between the United States and the United Kingdom is rooted in shared interests and shared values.\"",
  "id" : 333970474268762113,
  "created_at" : "2013-05-13 15:42:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/lZhUc8zPoZ",
      "expanded_url" : "http:\/\/at.wh.gov\/kYDUT",
      "display_url" : "at.wh.gov\/kYDUT"
    } ]
  },
  "geo" : { },
  "id_str" : "333970121821405184",
  "text" : "Happening now: President Obama and UK Prime Minister David Cameron hold a joint press conference. http:\/\/t.co\/lZhUc8zPoZ",
  "id" : 333970121821405184,
  "created_at" : "2013-05-13 15:40:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "333945739417894915",
  "text" : "Tune in at 11:15am ET for President Obama's joint press conference with UK Prime Minister David Cameron: http:\/\/t.co\/JludLrcLOd",
  "id" : 333945739417894915,
  "created_at" : "2013-05-13 14:04:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/333589918922207234\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/pJXRUoylPS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKEmQ4pCcAAubAS.png",
      "id_str" : "333589918926401536",
      "id" : 333589918926401536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKEmQ4pCcAAubAS.png",
      "sizes" : [ {
        "h" : 669,
        "resize" : "fit",
        "w" : 843
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 843
      } ],
      "display_url" : "pic.twitter.com\/pJXRUoylPS"
    } ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 6, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333589918922207234",
  "text" : "Happy #MothersDay! http:\/\/t.co\/pJXRUoylPS",
  "id" : 333589918922207234,
  "created_at" : "2013-05-12 14:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333304972827561984",
  "text" : "RT @Simas44: Worth a RT. Obamacare beginning to work the way it was intended. Insurers lowering rates because of competition. http:\/\/t.co\/P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Pofmi5dwp0",
        "expanded_url" : "http:\/\/www.oregonlive.com\/health\/index.ssf\/2013\/05\/two_oregon_insurers_reconsider.html",
        "display_url" : "oregonlive.com\/health\/index.s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "333286272426729472",
    "text" : "Worth a RT. Obamacare beginning to work the way it was intended. Insurers lowering rates because of competition. http:\/\/t.co\/Pofmi5dwp0",
    "id" : 333286272426729472,
    "created_at" : "2013-05-11 18:23:34 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 333304972827561984,
  "created_at" : "2013-05-11 19:37:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/333295474637426688\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/6bHpYgtqVW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKAad-NCUAAylf6.jpg",
      "id_str" : "333295474641620992",
      "id" : 333295474641620992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKAad-NCUAAylf6.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/6bHpYgtqVW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/Kv9i6nZnwz",
      "expanded_url" : "http:\/\/on.wh.gov\/HxI5Xe8",
      "display_url" : "on.wh.gov\/HxI5Xe8"
    } ]
  },
  "geo" : { },
  "id_str" : "333295474637426688",
  "text" : "Our North Star. http:\/\/t.co\/Kv9i6nZnwz, http:\/\/t.co\/6bHpYgtqVW",
  "id" : 333295474637426688,
  "created_at" : "2013-05-11 19:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/333250148912230401\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/pfhG3aU05j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ_xPquCcAEHDUE.png",
      "id_str" : "333250148916424705",
      "id" : 333250148916424705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ_xPquCcAEHDUE.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/pfhG3aU05j"
    } ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 2, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333250148912230401",
  "text" : "A #MothersDay present from health care reform: Being a mom will no longer be a pre-existing condition. http:\/\/t.co\/pfhG3aU05j",
  "id" : 333250148912230401,
  "created_at" : "2013-05-11 16:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/333219977194782720\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xnFdsOKB6p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ_VzcVCQAAFq34.jpg",
      "id_str" : "333219977203171328",
      "id" : 333219977203171328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ_VzcVCQAAFq34.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/xnFdsOKB6p"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/b2AdEsdzkC",
      "expanded_url" : "http:\/\/on.wh.gov\/scGY0CC",
      "display_url" : "on.wh.gov\/scGY0CC"
    } ]
  },
  "geo" : { },
  "id_str" : "333219977194782720",
  "text" : "President Obama on reigniting our engine of economic growth-a rising, thriving middle class: http:\/\/t.co\/b2AdEsdzkC, http:\/\/t.co\/xnFdsOKB6p",
  "id" : 333219977194782720,
  "created_at" : "2013-05-11 14:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/333002123186950144\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/XUpWsqL7Qc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ8Pqq5CUAA-TPy.jpg",
      "id_str" : "333002123191144448",
      "id" : 333002123191144448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ8Pqq5CUAA-TPy.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/XUpWsqL7Qc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333002123186950144",
  "text" : "Thanks Obamacare. http:\/\/t.co\/XUpWsqL7Qc",
  "id" : 333002123186950144,
  "created_at" : "2013-05-10 23:34:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/N32iMQqXMA",
      "expanded_url" : "http:\/\/ow.ly\/kUEF4",
      "display_url" : "ow.ly\/kUEF4"
    } ]
  },
  "geo" : { },
  "id_str" : "332974743911268352",
  "text" : "RT @lacasablanca: First bilingual episode of \u201CWest Wing Week\u201D, watch it here: http:\/\/t.co\/N32iMQqXMA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/N32iMQqXMA",
        "expanded_url" : "http:\/\/ow.ly\/kUEF4",
        "display_url" : "ow.ly\/kUEF4"
      } ]
    },
    "geo" : { },
    "id_str" : "332918327318036480",
    "text" : "First bilingual episode of \u201CWest Wing Week\u201D, watch it here: http:\/\/t.co\/N32iMQqXMA",
    "id" : 332918327318036480,
    "created_at" : "2013-05-10 18:01:29 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 332974743911268352,
  "created_at" : "2013-05-10 21:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 84, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332938291345235968",
  "text" : "RT @Sebelius: President Obama: Being a woman is no longer a pre-existing condition. #ThanksObamacare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThanksObamacare",
        "indices" : [ 70, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332935813069426689",
    "text" : "President Obama: Being a woman is no longer a pre-existing condition. #ThanksObamacare",
    "id" : 332935813069426689,
    "created_at" : "2013-05-10 19:10:58 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 332938291345235968,
  "created_at" : "2013-05-10 19:20:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332935597658353665",
  "text" : "Obama: \"There are millions of other Americans\u2014moms &amp; dads &amp; daughters &amp; sons\u2014who will no longer have to hang their fortunes on chance.\"",
  "id" : 332935597658353665,
  "created_at" : "2013-05-10 19:10:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332934655949017088",
  "text" : "President Obama: \u201CThis is too important for political games. Most moms and dads don\u2019t think about politics when their kid gets sick.\u201D",
  "id" : 332934655949017088,
  "created_at" : "2013-05-10 19:06:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 84, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332933888139730944",
  "text" : "President Obama: \u201CPregnancy will no longer be considered a pre-existing condition.\u201D #ThanksObamacare",
  "id" : 332933888139730944,
  "created_at" : "2013-05-10 19:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 112, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332933404981092354",
  "text" : "President Obama: \u201CSeniors on Medicare receive free checkups and preventive care, with no co-pay or deductible.\u201D #ThanksObamacare",
  "id" : 332933404981092354,
  "created_at" : "2013-05-10 19:01:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 106, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332933055268405248",
  "text" : "President Obama: \u201CYoung adults under the age of 26 are able to stay on their parents\u2019 health care plans.\u201D #ThanksObamacare",
  "id" : 332933055268405248,
  "created_at" : "2013-05-10 19:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 119, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332932712258236416",
  "text" : "President Obama: \"Women now have access to free preventive care like checkups, and mammograms, and cancer screenings.\" #ThanksObamacare",
  "id" : 332932712258236416,
  "created_at" : "2013-05-10 18:58:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 111, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332932533119504384",
  "text" : "President Obama: \"Insurance companies can no longer impose lifetime limits on the amount of care you receive.\" #ThanksObamacare",
  "id" : 332932533119504384,
  "created_at" : "2013-05-10 18:57:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/4BpUGPai7B",
      "expanded_url" : "http:\/\/at.wh.gov\/kUJfE",
      "display_url" : "at.wh.gov\/kUJfE"
    } ]
  },
  "geo" : { },
  "id_str" : "332932331096649728",
  "text" : "President Obama: \u201C\u2018The health care law is about people like me,\u2019\u201D Alycia said. \u2018It\u2019s AlyciaCare.\u2019\u201D http:\/\/t.co\/4BpUGPai7B",
  "id" : 332932331096649728,
  "created_at" : "2013-05-10 18:57:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332931796079616000",
  "text" : "Obama: \"I\u2019m pleased to be joined today by many women who wrote in to tell us what the Affordable Care Act means to them.\" #ThanksObamacare",
  "id" : 332931796079616000,
  "created_at" : "2013-05-10 18:55:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332931182071263234",
  "text" : "\"In a nation as wealthy as this one, there is no reason why a family\u2019s security should be determined by chance of illness.\" \u2014President Obama",
  "id" : 332931182071263234,
  "created_at" : "2013-05-10 18:52:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 131, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332930454296616961",
  "text" : "President Obama: \"Let me just start off with a public service announcement to the dads, partners, &amp; kids of America: Sunday is #MothersDay.\"",
  "id" : 332930454296616961,
  "created_at" : "2013-05-10 18:49:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "332930165166440448",
  "text" : "Happening now: President Obama speaks about how the Affordable Care Act is helping mothers and families. http:\/\/t.co\/JludLrcLOd",
  "id" : 332930165166440448,
  "created_at" : "2013-05-10 18:48:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "HappyMothersDay",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332923172661911552",
  "text" : "Thanks to the #ACA, 1 in 3 women under 65 gained access to preventive care\u2014like birth control\u2014with no out-of-pocket costs. #HappyMothersDay",
  "id" : 332923172661911552,
  "created_at" : "2013-05-10 18:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 19, 23 ]
    }, {
      "text" : "HappyMothersDay",
      "indices" : [ 107, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332918398705094656",
  "text" : "FACT: In 2014, the #ACA will make it illegal to deny women health coverage due to pre-existing conditions. #HappyMothersDay",
  "id" : 332918398705094656,
  "created_at" : "2013-05-10 18:01:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyMothersDay",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332913131959488512",
  "text" : "FACT: Thanks to health care reform, insurance companies won't be able to charge women more than men for the same coverage. #HappyMothersDay",
  "id" : 332913131959488512,
  "created_at" : "2013-05-10 17:40:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/332905628026687489\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9GxCQRdwQj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ6356bCUAAHRG7.png",
      "id_str" : "332905628035076096",
      "id" : 332905628035076096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ6356bCUAAHRG7.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/9GxCQRdwQj"
    } ],
    "hashtags" : [ {
      "text" : "HappyMothersDay",
      "indices" : [ 99, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332905628026687489",
  "text" : "Please retweet: Health care reform is helping millions of mothers afford quality health insurance. #HappyMothersDay, http:\/\/t.co\/9GxCQRdwQj",
  "id" : 332905628026687489,
  "created_at" : "2013-05-10 17:11:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/zbd7LFIgZ1",
      "expanded_url" : "http:\/\/at.wh.gov\/kUthw",
      "display_url" : "at.wh.gov\/kUthw"
    } ]
  },
  "geo" : { },
  "id_str" : "332898569931595776",
  "text" : "Don't miss Secretary of State John Kerry's first-ever Google Hangout. Watch live today at 1:30pm ET: http:\/\/t.co\/zbd7LFIgZ1",
  "id" : 332898569931595776,
  "created_at" : "2013-05-10 16:42:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/IIOyN1EJZt",
      "expanded_url" : "http:\/\/at.wh.gov\/kUnBh",
      "display_url" : "at.wh.gov\/kUnBh"
    } ]
  },
  "geo" : { },
  "id_str" : "332889172610260993",
  "text" : "\"Let us pledge once more to serve them as well as they serve us.\" \u2014the President on Military Spouse Appreciation Day: http:\/\/t.co\/IIOyN1EJZt",
  "id" : 332889172610260993,
  "created_at" : "2013-05-10 16:05:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecKerry",
      "indices" : [ 15, 24 ]
    }, {
      "text" : "GooglePlus",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ssqV34O8lJ",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/statevideo",
      "display_url" : "youtube.com\/user\/statevideo"
    } ]
  },
  "geo" : { },
  "id_str" : "332884220433276930",
  "text" : "RT @StateDept: #SecKerry kicks off \"Hangouts at State\" series on #GooglePlus today at 1:30 PM ET. Watch live on http:\/\/t.co\/ssqV34O8lJ.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecKerry",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "GooglePlus",
        "indices" : [ 50, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/ssqV34O8lJ",
        "expanded_url" : "http:\/\/www.youtube.com\/user\/statevideo",
        "display_url" : "youtube.com\/user\/statevideo"
      } ]
    },
    "geo" : { },
    "id_str" : "332840161866022912",
    "text" : "#SecKerry kicks off \"Hangouts at State\" series on #GooglePlus today at 1:30 PM ET. Watch live on http:\/\/t.co\/ssqV34O8lJ.",
    "id" : 332840161866022912,
    "created_at" : "2013-05-10 12:50:53 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 332884220433276930,
  "created_at" : "2013-05-10 15:45:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenData",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/VYDjdABhjT",
      "expanded_url" : "http:\/\/at.wh.gov\/kU9wK",
      "display_url" : "at.wh.gov\/kU9wK"
    } ]
  },
  "geo" : { },
  "id_str" : "332876777590505476",
  "text" : "Good news: President Obama's #OpenData initiative makes hospital charge data public. More than 100K downloads so far: http:\/\/t.co\/VYDjdABhjT",
  "id" : 332876777590505476,
  "created_at" : "2013-05-10 15:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/332867884588101632\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/VTCaONypMn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ6Vk9KCcAA_9BD.jpg",
      "id_str" : "332867884596490240",
      "id" : 332867884596490240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ6Vk9KCcAA_9BD.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1336,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 1002,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1336,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/VTCaONypMn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332867884588101632",
  "text" : "Future engineers geeking out with President Obama yesterday: http:\/\/t.co\/VTCaONypMn",
  "id" : 332867884588101632,
  "created_at" : "2013-05-10 14:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/332661316655403009\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/MFVY11Ku1N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ3ZtHpCUAEN67D.jpg",
      "id_str" : "332661316663791617",
      "id" : 332661316663791617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ3ZtHpCUAEN67D.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/MFVY11Ku1N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332661316655403009",
  "text" : "ROBOTS! President Obama met with some really talented students in Manor, Texas today: http:\/\/t.co\/MFVY11Ku1N",
  "id" : 332661316655403009,
  "created_at" : "2013-05-10 01:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/332637778464632832\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/r8EPvtOO5N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ3ETBCCcAEAthW.jpg",
      "id_str" : "332637778468827137",
      "id" : 332637778468827137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ3ETBCCcAEAthW.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/r8EPvtOO5N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332637778464632832",
  "text" : "RT if you agree: We need to educate our kids so they have the skills to succeed in the jobs of tomorrow. http:\/\/t.co\/r8EPvtOO5N",
  "id" : 332637778464632832,
  "created_at" : "2013-05-09 23:26:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/JRzf9mYLM2",
      "expanded_url" : "https:\/\/vine.co\/v\/b23riwn59BO",
      "display_url" : "vine.co\/v\/b23riwn59BO"
    } ]
  },
  "geo" : { },
  "id_str" : "332625225768382464",
  "text" : "RT @WHVideo: Six seconds with POTUS, sitting down for savory BBQ at Stubb's in Austin, TX https:\/\/t.co\/JRzf9mYLM2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/JRzf9mYLM2",
        "expanded_url" : "https:\/\/vine.co\/v\/b23riwn59BO",
        "display_url" : "vine.co\/v\/b23riwn59BO"
      } ]
    },
    "geo" : { },
    "id_str" : "332623255435374592",
    "text" : "Six seconds with POTUS, sitting down for savory BBQ at Stubb's in Austin, TX https:\/\/t.co\/JRzf9mYLM2",
    "id" : 332623255435374592,
    "created_at" : "2013-05-09 22:28:58 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 332625225768382464,
  "created_at" : "2013-05-09 22:36:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 7, 15 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332624461113208832",
  "text" : "Follow @WHVideo for the latest videos that take you inside 1600 Pennsylvania Ave. and around the country with President Obama.",
  "id" : 332624461113208832,
  "created_at" : "2013-05-09 22:33:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Capital Factory",
      "screen_name" : "CapitalFactory",
      "indices" : [ 23, 38 ],
      "id_str" : "16887429",
      "id" : 16887429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "entrepreneurship",
      "indices" : [ 61, 78 ]
    }, {
      "text" : "innovation",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "ObamaInAustin",
      "indices" : [ 108, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332602915984404481",
  "text" : "President Obama visits @CapitalFactory today to see American #entrepreneurship &amp; #innovation firsthand. #ObamaInAustin",
  "id" : 332602915984404481,
  "created_at" : "2013-05-09 21:08:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 34, 45 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332597686345801729",
  "text" : "RT @FLOTUS: Surprise guest at the @WhiteHouse today for the Mother's Day Tea event: Watch live to find out who it is ---&gt; http:\/\/t.co\/d1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 22, 33 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/d17tb57X9Y",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "332594787540688896",
    "text" : "Surprise guest at the @WhiteHouse today for the Mother's Day Tea event: Watch live to find out who it is ---&gt; http:\/\/t.co\/d17tb57X9Y",
    "id" : 332594787540688896,
    "created_at" : "2013-05-09 20:35:51 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 332597686345801729,
  "created_at" : "2013-05-09 20:47:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/OkifSyUNVj",
      "expanded_url" : "http:\/\/at.wh.gov\/kSATf",
      "display_url" : "at.wh.gov\/kSATf"
    } ]
  },
  "geo" : { },
  "id_str" : "332593549180813315",
  "text" : "On the clock: Economic advisor Gene Sperling breaks down the President's efforts to create more manufacturing hubs. http:\/\/t.co\/OkifSyUNVj",
  "id" : 332593549180813315,
  "created_at" : "2013-05-09 20:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 97, 108 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/d17tb57X9Y",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "332587157426421760",
  "text" : "RT @FLOTUS: Happening now: First Lady Michelle Obama speaks at the Mother's Day Tea event at the @WhiteHouse. http:\/\/t.co\/d17tb57X9Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 85, 96 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/d17tb57X9Y",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "332587029034577920",
    "text" : "Happening now: First Lady Michelle Obama speaks at the Mother's Day Tea event at the @WhiteHouse. http:\/\/t.co\/d17tb57X9Y",
    "id" : 332587029034577920,
    "created_at" : "2013-05-09 20:05:01 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 332587157426421760,
  "created_at" : "2013-05-09 20:05:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/332568631391182848\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/aNVFuVhIE4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ2FaIICYAAk-ku.jpg",
      "id_str" : "332568631399571456",
      "id" : 332568631399571456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ2FaIICYAAk-ku.jpg",
      "sizes" : [ {
        "h" : 462,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 816,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 753
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 753
      } ],
      "display_url" : "pic.twitter.com\/aNVFuVhIE4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332572328561090560",
  "text" : "RT @petesouza: POTUS speaking now at Manor New Tech HS in Austin, Texas http:\/\/t.co\/aNVFuVhIE4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/332568631391182848\/photo\/1",
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/aNVFuVhIE4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJ2FaIICYAAk-ku.jpg",
        "id_str" : "332568631399571456",
        "id" : 332568631399571456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJ2FaIICYAAk-ku.jpg",
        "sizes" : [ {
          "h" : 462,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 753
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 753
        } ],
        "display_url" : "pic.twitter.com\/aNVFuVhIE4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332568631391182848",
    "text" : "POTUS speaking now at Manor New Tech HS in Austin, Texas http:\/\/t.co\/aNVFuVhIE4",
    "id" : 332568631391182848,
    "created_at" : "2013-05-09 18:51:55 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 332572328561090560,
  "created_at" : "2013-05-09 19:06:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332570656405323776",
  "text" : "\"That's what it's all about\u2014caring for each other, helping each another, being invested in every child\u2019s success.\" \u2014President Obama",
  "id" : 332570656405323776,
  "created_at" : "2013-05-09 18:59:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332569473288654850",
  "text" : "\"Every dollar that we put into early childhood education can save $7 down the road.\" \u2014President Obama on investing in Pre-K",
  "id" : 332569473288654850,
  "created_at" : "2013-05-09 18:55:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332568872517509122",
  "text" : "\"Every young person in America deserves a world-class education. We've got an obligation to give it to them.\" \u2014President Obama",
  "id" : 332568872517509122,
  "created_at" : "2013-05-09 18:52:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332567717859176453",
  "text" : "\"Our economy can\u2019t succeed unless our young people have the skills that they need to succeed.\" \u2014President Obama",
  "id" : 332567717859176453,
  "created_at" : "2013-05-09 18:48:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332566559480487937",
  "text" : "President Obama: \"We've cleared away the rubble of the worst economic crisis of our lifetimes. So we're poised for progress.\"",
  "id" : 332566559480487937,
  "created_at" : "2013-05-09 18:43:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332566088728588288",
  "text" : "President Obama: \"In a little over three years, our businesses have now created more than 6.5 million new jobs.\"",
  "id" : 332566088728588288,
  "created_at" : "2013-05-09 18:41:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "332564815476305920",
  "text" : "Happening now: President Obama speaks in Texas at Manor New Technology High School. http:\/\/t.co\/JludLrcLOd",
  "id" : 332564815476305920,
  "created_at" : "2013-05-09 18:36:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opendata",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/pUn6fO6uiU",
      "expanded_url" : "http:\/\/go.usa.gov\/TAMQ",
      "display_url" : "go.usa.gov\/TAMQ"
    } ]
  },
  "geo" : { },
  "id_str" : "332537481356521472",
  "text" : "RT @whitehouseostp: It\u2019s a big day for #opendata. http:\/\/t.co\/pUn6fO6uiU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opendata",
        "indices" : [ 19, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/pUn6fO6uiU",
        "expanded_url" : "http:\/\/go.usa.gov\/TAMQ",
        "display_url" : "go.usa.gov\/TAMQ"
      } ]
    },
    "geo" : { },
    "id_str" : "332512644902830081",
    "text" : "It\u2019s a big day for #opendata. http:\/\/t.co\/pUn6fO6uiU",
    "id" : 332512644902830081,
    "created_at" : "2013-05-09 15:09:26 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 332537481356521472,
  "created_at" : "2013-05-09 16:48:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenData",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/yGb3bBp04i",
      "expanded_url" : "http:\/\/wh.gov\/J5nS",
      "display_url" : "wh.gov\/J5nS"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/36m24JTHw2",
      "expanded_url" : "http:\/\/wh.gov\/J5UQ",
      "display_url" : "wh.gov\/J5UQ"
    } ]
  },
  "geo" : { },
  "id_str" : "332531855813394432",
  "text" : "Obama announces two new executive actions: #OpenData: http:\/\/t.co\/yGb3bBp04i and Manufacturing Innovation Institutes: http:\/\/t.co\/36m24JTHw2",
  "id" : 332531855813394432,
  "created_at" : "2013-05-09 16:25:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/kYJexrKyGf",
      "expanded_url" : "http:\/\/wh.gov\/J9F2",
      "display_url" : "wh.gov\/J9F2"
    } ]
  },
  "geo" : { },
  "id_str" : "332491677359022080",
  "text" : "President Obama travels to Austin, TX today\u2014the first stop on his Middle Class Jobs and Opportunity Tour: http:\/\/t.co\/kYJexrKyGf",
  "id" : 332491677359022080,
  "created_at" : "2013-05-09 13:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 30, 40 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/FQU4rYmpR1",
      "expanded_url" : "http:\/\/youtu.be\/M_POr-h82eg",
      "display_url" : "youtu.be\/M_POr-h82eg"
    } ]
  },
  "geo" : { },
  "id_str" : "332306485637959680",
  "text" : "U.S. Chief Technology Officer @Todd_Park previews President Obama's trip to Austin, TX: http:\/\/t.co\/FQU4rYmpR1",
  "id" : 332306485637959680,
  "created_at" : "2013-05-09 01:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/332272492079087617\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/p8G9SxeMBp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJx4EjNCAAAEH3Q.jpg",
      "id_str" : "332272492083281920",
      "id" : 332272492083281920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJx4EjNCAAAEH3Q.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/p8G9SxeMBp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332272492079087617",
  "text" : "We are a nation of immigrants. http:\/\/t.co\/p8G9SxeMBp",
  "id" : 332272492079087617,
  "created_at" : "2013-05-08 23:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/332258714864214016\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/L93J9aAejZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJxrinFCYAAckcS.jpg",
      "id_str" : "332258714868408320",
      "id" : 332258714868408320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJxrinFCYAAckcS.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/L93J9aAejZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332258714864214016",
  "text" : "Sebastian Krys was brought here as an undocumented child. Now he's a 13-time Grammy Award-winning producer: http:\/\/t.co\/L93J9aAejZ",
  "id" : 332258714864214016,
  "created_at" : "2013-05-08 22:20:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "Sebastian Pi\u00F1era",
      "screen_name" : "sebastianpinera",
      "indices" : [ 46, 62 ],
      "id_str" : "13623532",
      "id" : 13623532
    }, {
      "name" : "Ollanta Humala Tasso",
      "screen_name" : "Ollanta_HumalaT",
      "indices" : [ 86, 102 ],
      "id_str" : "151190865",
      "id" : 151190865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332247067206492160",
  "text" : "RT @rhodes44: POTUS will be hosting President @SebastianPinera of Chile and President @Ollanta_HumalaT of Peru at the White House this June",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sebastian Pi\u00F1era",
        "screen_name" : "sebastianpinera",
        "indices" : [ 32, 48 ],
        "id_str" : "13623532",
        "id" : 13623532
      }, {
        "name" : "Ollanta Humala Tasso",
        "screen_name" : "Ollanta_HumalaT",
        "indices" : [ 72, 88 ],
        "id_str" : "151190865",
        "id" : 151190865
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "332207656079069185",
    "text" : "POTUS will be hosting President @SebastianPinera of Chile and President @Ollanta_HumalaT of Peru at the White House this June",
    "id" : 332207656079069185,
    "created_at" : "2013-05-08 18:57:31 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 332247067206492160,
  "created_at" : "2013-05-08 21:34:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/MmtVM4Qqbf",
      "expanded_url" : "http:\/\/at.wh.gov\/kQgOt",
      "display_url" : "at.wh.gov\/kQgOt"
    } ]
  },
  "geo" : { },
  "id_str" : "332235084809768962",
  "text" : "Unless you're a Native American, you came from someplace else. Share your family's story: http:\/\/t.co\/MmtVM4Qqbf #ImmigrationNation",
  "id" : 332235084809768962,
  "created_at" : "2013-05-08 20:46:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/332206982184448000\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PXOMs0HiC8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJw8fX1CMAI-_hv.jpg",
      "id_str" : "332206982188642306",
      "id" : 332206982188642306,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJw8fX1CMAI-_hv.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/PXOMs0HiC8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332206982184448000",
  "text" : "RT if you agree: It's time to live up to our heritage as a nation of immigrants by passing immigration reform. http:\/\/t.co\/PXOMs0HiC8",
  "id" : 332206982184448000,
  "created_at" : "2013-05-08 18:54:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332190478890041344",
  "text" : "RT @FLOTUS: Happening now: First Lady Michelle Obama speaks at the National Medal for Museum and Library Service Ceremony. http:\/\/t.co\/Amyt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/AmytdwzHIe",
        "expanded_url" : "http:\/\/at.wh.gov\/kPPKF",
        "display_url" : "at.wh.gov\/kPPKF"
      } ]
    },
    "geo" : { },
    "id_str" : "332190403501633536",
    "text" : "Happening now: First Lady Michelle Obama speaks at the National Medal for Museum and Library Service Ceremony. http:\/\/t.co\/AmytdwzHIe",
    "id" : 332190403501633536,
    "created_at" : "2013-05-08 17:48:58 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 332190478890041344,
  "created_at" : "2013-05-08 17:49:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/332162179342143488\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/phgT6hb9Ub",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJwTvgQCEAANg8_.jpg",
      "id_str" : "332162179350532096",
      "id" : 332162179350532096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJwTvgQCEAANg8_.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/phgT6hb9Ub"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 67, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332162179342143488",
  "text" : "\"I truly believe that I have lived the American Dream.\" \u2014Miguel C. #ImmigrationNation, http:\/\/t.co\/phgT6hb9Ub",
  "id" : 332162179342143488,
  "created_at" : "2013-05-08 15:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 104, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/0S4d5KImAv",
      "expanded_url" : "http:\/\/at.wh.gov\/kPp9q",
      "display_url" : "at.wh.gov\/kPp9q"
    } ]
  },
  "geo" : { },
  "id_str" : "332147726072545283",
  "text" : "Nearly every family in America has an immigration story to share. Tell us yours: http:\/\/t.co\/0S4d5KImAv #ImmigrationNation",
  "id" : 332147726072545283,
  "created_at" : "2013-05-08 14:59:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Design Squad Global",
      "screen_name" : "DesignSquad",
      "indices" : [ 37, 49 ],
      "id_str" : "95510244",
      "id" : 95510244
    }, {
      "name" : "Design Squad Global",
      "screen_name" : "DesignSquad",
      "indices" : [ 89, 101 ],
      "id_str" : "95510244",
      "id" : 95510244
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332143098589220864",
  "text" : "RT @whitehouseostp: Thx 4 coming! RT @DesignSquad: Watch this behind-the-scenes video of @DesignSquad visiting the #WHScienceFair http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Design Squad Global",
        "screen_name" : "DesignSquad",
        "indices" : [ 17, 29 ],
        "id_str" : "95510244",
        "id" : 95510244
      }, {
        "name" : "Design Squad Global",
        "screen_name" : "DesignSquad",
        "indices" : [ 69, 81 ],
        "id_str" : "95510244",
        "id" : 95510244
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 95, 109 ]
      }, {
        "text" : "STEM",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/9E2BJk6rLp",
        "expanded_url" : "http:\/\/ow.ly\/kNxmi",
        "display_url" : "ow.ly\/kNxmi"
      } ]
    },
    "geo" : { },
    "id_str" : "332140539174596608",
    "text" : "Thx 4 coming! RT @DesignSquad: Watch this behind-the-scenes video of @DesignSquad visiting the #WHScienceFair http:\/\/t.co\/9E2BJk6rLp #STEM",
    "id" : 332140539174596608,
    "created_at" : "2013-05-08 14:30:50 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 332143098589220864,
  "created_at" : "2013-05-08 14:41:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331921421863374849\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ZPBNqNvwgv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJs4xkwCUAI2Uxi.jpg",
      "id_str" : "331921421871763458",
      "id" : 331921421871763458,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJs4xkwCUAI2Uxi.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ZPBNqNvwgv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331921421863374849",
  "text" : "It's time to give our country's 11 million undocumented immigrants a pathway to earn their citizenship. http:\/\/t.co\/ZPBNqNvwgv",
  "id" : 331921421863374849,
  "created_at" : "2013-05-08 00:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Colin Kaepernick",
      "screen_name" : "Kaepernick7",
      "indices" : [ 13, 25 ],
      "id_str" : "45055696",
      "id" : 45055696
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/331904750176063489\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/WFKVbAaVkW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJspnJ4CUAIWhEM.jpg",
      "id_str" : "331904750184452098",
      "id" : 331904750184452098,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJspnJ4CUAIWhEM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/WFKVbAaVkW"
    } ],
    "hashtags" : [ {
      "text" : "Kaepernicking",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/6UczmbaEYX",
      "expanded_url" : "http:\/\/letsmoveschools.org",
      "display_url" : "letsmoveschools.org"
    } ]
  },
  "geo" : { },
  "id_str" : "331907936500715521",
  "text" : "RT @FLOTUS: .@Kaepernick7: Had fun #Kaepernicking. Thanks for helping our kids get moving! http:\/\/t.co\/6UczmbaEYX \u2013mo http:\/\/t.co\/WFKVbAaVkW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Colin Kaepernick",
        "screen_name" : "Kaepernick7",
        "indices" : [ 1, 13 ],
        "id_str" : "45055696",
        "id" : 45055696
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/331904750176063489\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/WFKVbAaVkW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJspnJ4CUAIWhEM.jpg",
        "id_str" : "331904750184452098",
        "id" : 331904750184452098,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJspnJ4CUAIWhEM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/WFKVbAaVkW"
      } ],
      "hashtags" : [ {
        "text" : "Kaepernicking",
        "indices" : [ 23, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/6UczmbaEYX",
        "expanded_url" : "http:\/\/letsmoveschools.org",
        "display_url" : "letsmoveschools.org"
      } ]
    },
    "geo" : { },
    "id_str" : "331904750176063489",
    "text" : ".@Kaepernick7: Had fun #Kaepernicking. Thanks for helping our kids get moving! http:\/\/t.co\/6UczmbaEYX \u2013mo http:\/\/t.co\/WFKVbAaVkW",
    "id" : 331904750176063489,
    "created_at" : "2013-05-07 22:53:53 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 331907936500715521,
  "created_at" : "2013-05-07 23:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/331893173804756992\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/I3Z7UK5Bs2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJsfFUhCcAEqyo9.jpg",
      "id_str" : "331893173808951297",
      "id" : 331893173808951297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJsfFUhCcAEqyo9.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      } ],
      "display_url" : "pic.twitter.com\/I3Z7UK5Bs2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331893173804756992",
  "text" : "Inside the Oval Office: Today, President Obama met with President Park Geun-hye of the Republic of Korea. http:\/\/t.co\/I3Z7UK5Bs2",
  "id" : 331893173804756992,
  "created_at" : "2013-05-07 22:07:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 109, 117 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/9qNj72w8ER",
      "expanded_url" : "http:\/\/at.wh.gov\/kN2eq",
      "display_url" : "at.wh.gov\/kN2eq"
    } ]
  },
  "geo" : { },
  "id_str" : "331877291137323010",
  "text" : "\"What they want to do is the same thing my folks wanted to do 43 years ago\u2014which is to build a better life.\"\u2014@Simas44 http:\/\/t.co\/9qNj72w8ER",
  "id" : 331877291137323010,
  "created_at" : "2013-05-07 21:04:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/7kMoI4A9Iw",
      "expanded_url" : "http:\/\/at.wh.gov\/kKBxR",
      "display_url" : "at.wh.gov\/kKBxR"
    } ]
  },
  "geo" : { },
  "id_str" : "331866123656114176",
  "text" : "Submit a recipe for the Healthy Lunchtime Challenge and you could join the Kids' State Dinner at the White House: http:\/\/t.co\/7kMoI4A9Iw",
  "id" : 331866123656114176,
  "created_at" : "2013-05-07 20:20:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331848453967708162\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Z2URqZtjqr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJr2aSKCAAAyu8Z.jpg",
      "id_str" : "331848453976096768",
      "id" : 331848453976096768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJr2aSKCAAAyu8Z.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Z2URqZtjqr"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331848453967708162",
  "text" : "RT if you agree: Our immigration system has been broken for too long, and it's time to fix it. #ImmigrationNation, http:\/\/t.co\/Z2URqZtjqr",
  "id" : 331848453967708162,
  "created_at" : "2013-05-07 19:10:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331840875812515841",
  "text" : "FACT: Under President Obama's plan, kids who were brought here illegally will be able to earn their citizenship. #ImmigrationNation",
  "id" : 331840875812515841,
  "created_at" : "2013-05-07 18:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331835853246713856\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ozboeizFtH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJrq800CUAAAo_-.jpg",
      "id_str" : "331835853255102464",
      "id" : 331835853255102464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJrq800CUAAAo_-.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ozboeizFtH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331835853246713856",
  "text" : "FACT: Obama's plan brings undocumented immigrants out of the shadows so they can contribute fully to our economy. http:\/\/t.co\/ozboeizFtH",
  "id" : 331835853246713856,
  "created_at" : "2013-05-07 18:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331830849593044992\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/2vYBV2UH9l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJrmZkwCcAA7VOS.jpg",
      "id_str" : "331830849601433600",
      "id" : 331830849601433600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJrmZkwCcAA7VOS.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/2vYBV2UH9l"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/RnwW8f2mWJ",
      "expanded_url" : "http:\/\/on.wh.gov\/FwJyVH0",
      "display_url" : "on.wh.gov\/FwJyVH0"
    } ]
  },
  "geo" : { },
  "id_str" : "331830849593044992",
  "text" : "Make sure your friends know President Obama's plan to fix our broken immigration system: http:\/\/t.co\/RnwW8f2mWJ, http:\/\/t.co\/2vYBV2UH9l",
  "id" : 331830849593044992,
  "created_at" : "2013-05-07 18:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "331826826810912769",
  "text" : "Watch live: President Obama and President Park Geun-hye of the Republic of Korea hold a joint press conference. http:\/\/t.co\/JludLrcLOd",
  "id" : 331826826810912769,
  "created_at" : "2013-05-07 17:44:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 55, 63 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/6supjLwVWb",
      "expanded_url" : "http:\/\/at.wh.gov\/kNfHB",
      "display_url" : "at.wh.gov\/kNfHB"
    } ]
  },
  "geo" : { },
  "id_str" : "331813545241092096",
  "text" : "\"Invest in the future. Change someone's life. Teach.\" \u2014@DrBiden: http:\/\/t.co\/6supjLwVWb #ThankATeacher",
  "id" : 331813545241092096,
  "created_at" : "2013-05-07 16:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331804106249367552\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/FTsACyxWGH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJrOE6CCcAAq-Bu.jpg",
      "id_str" : "331804106257756160",
      "id" : 331804106257756160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJrOE6CCcAAq-Bu.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/FTsACyxWGH"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331804106249367552",
  "text" : "RT to say thanks to the teachers that have made a difference in your life. #ThankATeacher, http:\/\/t.co\/FTsACyxWGH",
  "id" : 331804106249367552,
  "created_at" : "2013-05-07 16:13:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 65, 73 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/9qNj72w8ER",
      "expanded_url" : "http:\/\/at.wh.gov\/kN2eq",
      "display_url" : "at.wh.gov\/kN2eq"
    } ]
  },
  "geo" : { },
  "id_str" : "331794556230176768",
  "text" : "\"This is consistent with who we are and who we've always been.\" \u2014@Simas44 on why the U.S. is an #ImmigrationNation: http:\/\/t.co\/9qNj72w8ER",
  "id" : 331794556230176768,
  "created_at" : "2013-05-07 15:36:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miami Herald",
      "screen_name" : "MiamiHerald",
      "indices" : [ 23, 35 ],
      "id_str" : "14085040",
      "id" : 14085040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/wxPX5oyoGN",
      "expanded_url" : "http:\/\/at.wh.gov\/kMXcp",
      "display_url" : "at.wh.gov\/kMXcp"
    } ]
  },
  "geo" : { },
  "id_str" : "331781377697648641",
  "text" : "President Obama in the @MiamiHerald on improving our partnership with Latin America: http:\/\/t.co\/wxPX5oyoGN",
  "id" : 331781377697648641,
  "created_at" : "2013-05-07 14:43:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331540158862209024\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/HCPsJP5MGO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJneBJYCMAAIKbi.jpg",
      "id_str" : "331540158866403328",
      "id" : 331540158866403328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJneBJYCMAAIKbi.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/HCPsJP5MGO"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 91, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331540158862209024",
  "text" : "RT so your friends know about President Obama's plan to fix our broken immigration system. #ImmigrationNation, http:\/\/t.co\/HCPsJP5MGO",
  "id" : 331540158862209024,
  "created_at" : "2013-05-06 22:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Grand Canyon NPS",
      "screen_name" : "GrandCanyonNPS",
      "indices" : [ 99, 114 ],
      "id_str" : "212304085",
      "id" : 212304085
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/331522465220157440\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/QGLIw0l87j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJnN7PcCYAA1k3Z.jpg",
      "id_str" : "331522465228546048",
      "id" : 331522465228546048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJnN7PcCYAA1k3Z.jpg",
      "sizes" : [ {
        "h" : 209,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 629,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QGLIw0l87j"
    } ],
    "hashtags" : [ {
      "text" : "lightning",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331529484157206528",
  "text" : "RT @Interior: One of the most spectacular #lightning strikes we have ever seen. Near the South Rim @GrandCanyonNPS. http:\/\/t.co\/QGLIw0l87j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grand Canyon NPS",
        "screen_name" : "GrandCanyonNPS",
        "indices" : [ 85, 100 ],
        "id_str" : "212304085",
        "id" : 212304085
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/331522465220157440\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/QGLIw0l87j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJnN7PcCYAA1k3Z.jpg",
        "id_str" : "331522465228546048",
        "id" : 331522465228546048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJnN7PcCYAA1k3Z.jpg",
        "sizes" : [ {
          "h" : 209,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QGLIw0l87j"
      } ],
      "hashtags" : [ {
        "text" : "lightning",
        "indices" : [ 28, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "331522465220157440",
    "text" : "One of the most spectacular #lightning strikes we have ever seen. Near the South Rim @GrandCanyonNPS. http:\/\/t.co\/QGLIw0l87j",
    "id" : 331522465220157440,
    "created_at" : "2013-05-06 21:34:49 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 331529484157206528,
  "created_at" : "2013-05-06 22:02:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331522625891340289",
  "text" : "RT @Sebelius: Good analysis on how #ACA is important factor in building a smarter health care system, slowing health care spending http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 21, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/02OO4Cb5Vv",
        "expanded_url" : "http:\/\/nyti.ms\/13Zn5ne",
        "display_url" : "nyti.ms\/13Zn5ne"
      } ]
    },
    "geo" : { },
    "id_str" : "331519940689547265",
    "text" : "Good analysis on how #ACA is important factor in building a smarter health care system, slowing health care spending http:\/\/t.co\/02OO4Cb5Vv",
    "id" : 331519940689547265,
    "created_at" : "2013-05-06 21:24:47 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 331522625891340289,
  "created_at" : "2013-05-06 21:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankateacher",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/gfb96hrrEX",
      "expanded_url" : "http:\/\/wh.gov\/z7yU",
      "display_url" : "wh.gov\/z7yU"
    } ]
  },
  "geo" : { },
  "id_str" : "331498743696326656",
  "text" : "RT @DrBiden: It's Teacher Appreciation Week. How will you celebrate our nation's teachers? http:\/\/t.co\/gfb96hrrEX  #thankateacher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thankateacher",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/gfb96hrrEX",
        "expanded_url" : "http:\/\/wh.gov\/z7yU",
        "display_url" : "wh.gov\/z7yU"
      } ]
    },
    "geo" : { },
    "id_str" : "331479454251622400",
    "text" : "It's Teacher Appreciation Week. How will you celebrate our nation's teachers? http:\/\/t.co\/gfb96hrrEX  #thankateacher",
    "id" : 331479454251622400,
    "created_at" : "2013-05-06 18:43:55 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 331498743696326656,
  "created_at" : "2013-05-06 20:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/IAdD6CrYSc",
      "expanded_url" : "http:\/\/at.wh.gov\/kL9YY",
      "display_url" : "at.wh.gov\/kL9YY"
    } ]
  },
  "geo" : { },
  "id_str" : "331485373811286017",
  "text" : "Share your family's immigration story\u2014and why you think it's time to fix our broken immigration system: http:\/\/t.co\/IAdD6CrYSc",
  "id" : 331485373811286017,
  "created_at" : "2013-05-06 19:07:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331468444845350912\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/rBx40I6JCl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJmcy12CIAEMiKy.jpg",
      "id_str" : "331468444849545217",
      "id" : 331468444849545217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJmcy12CIAEMiKy.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/rBx40I6JCl"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 61, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331468444845350912",
  "text" : "There's no reason immigration reform can't happen this year. #ImmigrationNation, http:\/\/t.co\/rBx40I6JCl",
  "id" : 331468444845350912,
  "created_at" : "2013-05-06 18:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 71, 82 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 47, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/VLyWD6rCte",
      "expanded_url" : "http:\/\/epi.us\/KtEU1w",
      "display_url" : "epi.us\/KtEU1w"
    } ]
  },
  "geo" : { },
  "id_str" : "331457965229998082",
  "text" : "RT @FLOTUS: Don't miss your chance to join our #KidsStateDinner at the @WhiteHouse! Submit a recipe today: http:\/\/t.co\/VLyWD6rCte http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 59, 70 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/331429768983629825\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/CyQQy155d7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJl5nnDCUAIjvMM.jpg",
        "id_str" : "331429768992018434",
        "id" : 331429768992018434,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJl5nnDCUAIjvMM.jpg",
        "sizes" : [ {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CyQQy155d7"
      } ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 35, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/VLyWD6rCte",
        "expanded_url" : "http:\/\/epi.us\/KtEU1w",
        "display_url" : "epi.us\/KtEU1w"
      } ]
    },
    "geo" : { },
    "id_str" : "331429768983629825",
    "text" : "Don't miss your chance to join our #KidsStateDinner at the @WhiteHouse! Submit a recipe today: http:\/\/t.co\/VLyWD6rCte http:\/\/t.co\/CyQQy155d7",
    "id" : 331429768983629825,
    "created_at" : "2013-05-06 15:26:29 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 331457965229998082,
  "created_at" : "2013-05-06 17:18:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/letsmove\/status\/331437161461194755\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/jN1Ll52ijr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJmAV6LCIAATHao.jpg",
      "id_str" : "331437161469583360",
      "id" : 331437161469583360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJmAV6LCIAATHao.jpg",
      "sizes" : [ {
        "h" : 525,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 896,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jN1Ll52ijr"
    } ],
    "hashtags" : [ {
      "text" : "strongtothefinish",
      "indices" : [ 73, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331442803714433024",
  "text" : "RT @letsmove: Popeye would have a field day in the First Lady's garden!! #strongtothefinish\n-Sam http:\/\/t.co\/jN1Ll52ijr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/letsmove\/status\/331437161461194755\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/jN1Ll52ijr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJmAV6LCIAATHao.jpg",
        "id_str" : "331437161469583360",
        "id" : 331437161469583360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJmAV6LCIAATHao.jpg",
        "sizes" : [ {
          "h" : 525,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 896,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 896,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jN1Ll52ijr"
      } ],
      "hashtags" : [ {
        "text" : "strongtothefinish",
        "indices" : [ 59, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "331437161461194755",
    "text" : "Popeye would have a field day in the First Lady's garden!! #strongtothefinish\n-Sam http:\/\/t.co\/jN1Ll52ijr",
    "id" : 331437161461194755,
    "created_at" : "2013-05-06 15:55:51 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 331442803714433024,
  "created_at" : "2013-05-06 16:18:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ohio State",
      "screen_name" : "OhioState",
      "indices" : [ 100, 110 ],
      "id_str" : "18846918",
      "id" : 18846918
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331427071987445760\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/NuDSxDumWs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJl3Kn9CcAAI6xA.jpg",
      "id_str" : "331427071995834368",
      "id" : 331427071995834368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJl3Kn9CcAAI6xA.jpg",
      "sizes" : [ {
        "h" : 486,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NuDSxDumWs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331427071987445760",
  "text" : "\"It\u2019s not about what America can do for us. It\u2019s about what can be done by us, together.\" \u2014Obama at @OhioState. http:\/\/t.co\/NuDSxDumWs",
  "id" : 331427071987445760,
  "created_at" : "2013-05-06 15:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331415817239547905\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/v9LfcRS5kx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJls7gwCUAEXtw8.jpg",
      "id_str" : "331415817247936513",
      "id" : 331415817247936513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJls7gwCUAEXtw8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/v9LfcRS5kx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331415817239547905",
  "text" : "Nice to meet you: President Obama greeted kids on his trip to Costa Rica. http:\/\/t.co\/v9LfcRS5kx",
  "id" : 331415817239547905,
  "created_at" : "2013-05-06 14:31:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/IIUmmX0fg1",
      "expanded_url" : "http:\/\/at.wh.gov\/kIRe0",
      "display_url" : "at.wh.gov\/kIRe0"
    } ]
  },
  "geo" : { },
  "id_str" : "331121623333756928",
  "text" : "\"Cinco de Mayo reminds us that America\u2019s diversity is America\u2019s strength.\" \u2014President Obama, http:\/\/t.co\/IIUmmX0fg1",
  "id" : 331121623333756928,
  "created_at" : "2013-05-05 19:02:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ohio State",
      "screen_name" : "OhioState",
      "indices" : [ 21, 31 ],
      "id_str" : "18846918",
      "id" : 18846918
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331083403388653568\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/gZGOLZXvhD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJg-mepCEAEmjdi.jpg",
      "id_str" : "331083403392847873",
      "id" : 331083403392847873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJg-mepCEAEmjdi.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gZGOLZXvhD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/sxNHFoI69Y",
      "expanded_url" : "http:\/\/on.wh.gov\/ouQ82VS",
      "display_url" : "on.wh.gov\/ouQ82VS"
    } ]
  },
  "geo" : { },
  "id_str" : "331083403388653568",
  "text" : "Congrats to the 2013 @OhioState grads! Watch the President give their commencement address: http:\/\/t.co\/sxNHFoI69Y, http:\/\/t.co\/gZGOLZXvhD",
  "id" : 331083403388653568,
  "created_at" : "2013-05-05 16:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/331060762716016641\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/FYSuhWfcoJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJgqAnkCEAIGZDS.jpg",
      "id_str" : "331060762720210946",
      "id" : 331060762720210946,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJgqAnkCEAIGZDS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/FYSuhWfcoJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331060762716016641",
  "text" : "Happy Cinco de Mayo! http:\/\/t.co\/FYSuhWfcoJ",
  "id" : 331060762716016641,
  "created_at" : "2013-05-05 15:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/330756212515827712\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/i2uEz0BzXX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJcVBdqCcAAAKs1.jpg",
      "id_str" : "330756212520022016",
      "id" : 330756212520022016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJcVBdqCcAAAKs1.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/i2uEz0BzXX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/Jby6HWv9O4",
      "expanded_url" : "http:\/\/wh.gov\/zWn7",
      "display_url" : "wh.gov\/zWn7"
    } ]
  },
  "geo" : { },
  "id_str" : "330756212515827712",
  "text" : "RT if you agree: It's time to fix our broken immigration system. http:\/\/t.co\/Jby6HWv9O4, http:\/\/t.co\/i2uEz0BzXX",
  "id" : 330756212515827712,
  "created_at" : "2013-05-04 18:50:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maythefourthbewithyou",
      "indices" : [ 44, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/bAZ1KDgR4n",
      "expanded_url" : "http:\/\/flic.kr\/p\/75XWNy",
      "display_url" : "flic.kr\/p\/75XWNy"
    }, {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/UrQwhywLTM",
      "expanded_url" : "http:\/\/wh.gov\/Ptti",
      "display_url" : "wh.gov\/Ptti"
    } ]
  },
  "geo" : { },
  "id_str" : "330713686283014144",
  "text" : "Happy Star Wars Day! http:\/\/t.co\/bAZ1KDgR4n #maythefourthbewithyou (We're still not building a Death Star: http:\/\/t.co\/UrQwhywLTM)",
  "id" : 330713686283014144,
  "created_at" : "2013-05-04 16:01:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 24, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/szu4G6Iy95",
      "expanded_url" : "http:\/\/at.wh.gov\/kHlrM",
      "display_url" : "at.wh.gov\/kHlrM"
    } ]
  },
  "geo" : { },
  "id_str" : "330624196365402113",
  "text" : "\"There\u2019s no reason that #ImmigrationReform can\u2019t become a reality this year.\" \u2014President Obama in his Weekly Address: http:\/\/t.co\/szu4G6Iy95",
  "id" : 330624196365402113,
  "created_at" : "2013-05-04 10:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/330501141714591746\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/K4p2lrHHTu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJYtCY5CYAAtdKr.jpg",
      "id_str" : "330501141722980352",
      "id" : 330501141722980352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJYtCY5CYAAtdKr.jpg",
      "sizes" : [ {
        "h" : 558,
        "resize" : "fit",
        "w" : 837
      }, {
        "h" : 558,
        "resize" : "fit",
        "w" : 837
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/K4p2lrHHTu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330511269545250816",
  "text" : "RT @petesouza: Photo from Pres Obama's speech earlier today in Mexico City http:\/\/t.co\/K4p2lrHHTu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/330501141714591746\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/K4p2lrHHTu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJYtCY5CYAAtdKr.jpg",
        "id_str" : "330501141722980352",
        "id" : 330501141722980352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJYtCY5CYAAtdKr.jpg",
        "sizes" : [ {
          "h" : 558,
          "resize" : "fit",
          "w" : 837
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 837
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/K4p2lrHHTu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330501141714591746",
    "text" : "Photo from Pres Obama's speech earlier today in Mexico City http:\/\/t.co\/K4p2lrHHTu",
    "id" : 330501141714591746,
    "created_at" : "2013-05-04 01:56:27 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 330511269545250816,
  "created_at" : "2013-05-04 02:36:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/330425305825157120\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/cMqhdJMugy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJXoEKLCIAAzRxR.jpg",
      "id_str" : "330425305829351424",
      "id" : 330425305829351424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJXoEKLCIAAzRxR.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/cMqhdJMugy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330425305825157120",
  "text" : "RT if you agree: We need to keep expanding the trade &amp; commerce that creates good jobs on both sides of the border. http:\/\/t.co\/cMqhdJMugy",
  "id" : 330425305825157120,
  "created_at" : "2013-05-03 20:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 18, 27 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 32, 45 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 123, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330410563479932929",
  "text" : "Follow @NSCPress, @Rhodes44 and @LaCasablanca for the latest updates from President Obama's trip to Mexico and Costa Rica. #FF",
  "id" : 330410563479932929,
  "created_at" : "2013-05-03 19:56:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/RMpakkLA26",
      "expanded_url" : "http:\/\/at.wh.gov\/kGBgP",
      "display_url" : "at.wh.gov\/kGBgP"
    } ]
  },
  "geo" : { },
  "id_str" : "330391642857156608",
  "text" : "Go backstage at the White House for some Memphis Soul: http:\/\/t.co\/RMpakkLA26",
  "id" : 330391642857156608,
  "created_at" : "2013-05-03 18:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/330380450134630400\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/LTeGD7gcC5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJW_RNuCIAEBzoq.jpg",
      "id_str" : "330380450143019009",
      "id" : 330380450143019009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJW_RNuCIAEBzoq.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/LTeGD7gcC5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330380450134630400",
  "text" : "Our economy has added 6.8 million private-sector jobs over the past 38 months\u2014and there's more work to do: http:\/\/t.co\/LTeGD7gcC5",
  "id" : 330380450134630400,
  "created_at" : "2013-05-03 17:56:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "John McCain",
      "screen_name" : "SenJohnMcCain",
      "indices" : [ 50, 64 ],
      "id_str" : "19394188",
      "id" : 19394188
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/GnTTyWgcyM",
      "expanded_url" : "http:\/\/snd.sc\/15ezBnD",
      "display_url" : "snd.sc\/15ezBnD"
    } ]
  },
  "geo" : { },
  "id_str" : "330373858177716224",
  "text" : "RT @VP: The Vice President talks about his friend @SenJohnMcCain in Volume 6 of #BeingBiden. Listen: http:\/\/t.co\/GnTTyWgcyM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John McCain",
        "screen_name" : "SenJohnMcCain",
        "indices" : [ 42, 56 ],
        "id_str" : "19394188",
        "id" : 19394188
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeingBiden",
        "indices" : [ 72, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/GnTTyWgcyM",
        "expanded_url" : "http:\/\/snd.sc\/15ezBnD",
        "display_url" : "snd.sc\/15ezBnD"
      } ]
    },
    "geo" : { },
    "id_str" : "330365217781456901",
    "text" : "The Vice President talks about his friend @SenJohnMcCain in Volume 6 of #BeingBiden. Listen: http:\/\/t.co\/GnTTyWgcyM",
    "id" : 330365217781456901,
    "created_at" : "2013-05-03 16:56:20 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 330373858177716224,
  "created_at" : "2013-05-03 17:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Presidencia M\u00E9xico",
      "screen_name" : "PresidenciaMX",
      "indices" : [ 24, 38 ],
      "id_str" : "34666670",
      "id" : 34666670
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamainMexico",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330360735685283841",
  "text" : "RT @NSCPress: Thanks to @PresidenciaMX for hosting a fantastic visit for President Obama and our entire delegation! #ObamainMexico",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Presidencia M\u00E9xico",
        "screen_name" : "PresidenciaMX",
        "indices" : [ 10, 24 ],
        "id_str" : "34666670",
        "id" : 34666670
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamainMexico",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "330357096015073280",
    "text" : "Thanks to @PresidenciaMX for hosting a fantastic visit for President Obama and our entire delegation! #ObamainMexico",
    "id" : 330357096015073280,
    "created_at" : "2013-05-03 16:24:04 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 330360735685283841,
  "created_at" : "2013-05-03 16:38:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/330351767181221888\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/L87yhAfArV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJWlLpYCYAAsbQL.jpg",
      "id_str" : "330351767185416192",
      "id" : 330351767185416192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJWlLpYCYAAsbQL.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/L87yhAfArV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330351767181221888",
  "text" : "RT the news: Our economy added 176K private-sector jobs, while unemployment dipped to its lowest rate since Dec '08. http:\/\/t.co\/L87yhAfArV",
  "id" : 330351767181221888,
  "created_at" : "2013-05-03 16:02:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330334660171280386",
  "text" : "\"To help spark prosperity in both of our countries, let\u2019s truly invest in innovation, research and development\u2014together.\" \u2014Obama in Mexico",
  "id" : 330334660171280386,
  "created_at" : "2013-05-03 14:54:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330333558805778432",
  "text" : "\"Let\u2019s do more to expand the trade and commerce that creates good jobs for our people.\" \u2014President Obama on the U.S. and Mexico",
  "id" : 330333558805778432,
  "created_at" : "2013-05-03 14:50:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330333071180197888",
  "text" : "\"I am optimistic that after years of trying, we're finally going to get it done this year.\" \u2014President Obama on passing #ImmigrationReform",
  "id" : 330333071180197888,
  "created_at" : "2013-05-03 14:48:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330331063454937088",
  "text" : "\"Our nations must be defined\u2014not by the threats we face\u2014but by the prosperity and opportunity we can create together.\" \u2014President Obama",
  "id" : 330331063454937088,
  "created_at" : "2013-05-03 14:40:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330330644443979776",
  "text" : "\"We are two equal partners\u2014two sovereign nations. We must work together in mutual interest and mutual respect.\" \u2014Obama on the U.S. &amp; Mexico",
  "id" : 330330644443979776,
  "created_at" : "2013-05-03 14:38:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330329752235814912",
  "text" : "\"It's time to put the old mindsets aside. It\u2019s time to recognize new realities, including the impressive progress in today\u2019s Mexico.\" \u2014Obama",
  "id" : 330329752235814912,
  "created_at" : "2013-05-03 14:35:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaInMexico",
      "indices" : [ 84, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "330328217623875584",
  "text" : "Happening now: President Obama speaks in Mexico City. Watch: http:\/\/t.co\/JludLrcLOd #ObamaInMexico",
  "id" : 330328217623875584,
  "created_at" : "2013-05-03 14:29:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaInMexico",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "330315589472108544",
  "text" : "Starting soon: President Obama speaks in Mexico City at 10:15am ET. Watch here: http:\/\/t.co\/JludLrcLOd #ObamaInMexico",
  "id" : 330315589472108544,
  "created_at" : "2013-05-03 13:39:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/330087313466073090\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/5BmtTHHuCx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJS0qaiCIAAZOx9.jpg",
      "id_str" : "330087313474461696",
      "id" : 330087313474461696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJS0qaiCIAAZOx9.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5BmtTHHuCx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330087313466073090",
  "text" : "Air Force One, ready for take off: http:\/\/t.co\/5BmtTHHuCx",
  "id" : 330087313466073090,
  "created_at" : "2013-05-02 22:32:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330075269849288704",
  "text" : "\"Our success is shared. When one of us prospers, both of us prosper.\" \u2014President Obama on the relationship between the U.S. and Mexico",
  "id" : 330075269849288704,
  "created_at" : "2013-05-02 21:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330074428773904385",
  "text" : "\"Mexico and the U.S. have one of the largest, most dynamic relationships of any two countries on earth.\" \u2014President Obama in Mexico City",
  "id" : 330074428773904385,
  "created_at" : "2013-05-02 21:40:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "330070402497904641",
  "text" : "Happening now: President Obama and President Pe\u00F1a Nieto hold a press conference in Mexico City. Watch: http:\/\/t.co\/JludLrcLOd",
  "id" : 330070402497904641,
  "created_at" : "2013-05-02 21:24:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/imjFHKerlK",
      "expanded_url" : "http:\/\/buswk.co\/ZXj2Yj",
      "display_url" : "buswk.co\/ZXj2Yj"
    } ]
  },
  "geo" : { },
  "id_str" : "330037964698689536",
  "text" : "RT @Simas44: Worth a RT: \"American auto industry has best performance in 20 years.\" http:\/\/t.co\/imjFHKerlK #MadeInAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 94, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/imjFHKerlK",
        "expanded_url" : "http:\/\/buswk.co\/ZXj2Yj",
        "display_url" : "buswk.co\/ZXj2Yj"
      } ]
    },
    "geo" : { },
    "id_str" : "330037083047616513",
    "text" : "Worth a RT: \"American auto industry has best performance in 20 years.\" http:\/\/t.co\/imjFHKerlK #MadeInAmerica",
    "id" : 330037083047616513,
    "created_at" : "2013-05-02 19:12:27 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 330037964698689536,
  "created_at" : "2013-05-02 19:15:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/JDgGIcjQCF",
      "expanded_url" : "http:\/\/at.wh.gov\/kEeuR",
      "display_url" : "at.wh.gov\/kEeuR"
    } ]
  },
  "geo" : { },
  "id_str" : "330024141933641730",
  "text" : "Get the latest updates on President Obama's trip to Mexico and Costa Rica: http:\/\/t.co\/JDgGIcjQCF",
  "id" : 330024141933641730,
  "created_at" : "2013-05-02 18:21:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 0, 9 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330014734776668161",
  "geo" : { },
  "id_str" : "330018605762760704",
  "in_reply_to_user_id" : 5695632,
  "text" : "@buzzfeed Thanks!",
  "id" : 330018605762760704,
  "in_reply_to_status_id" : 330014734776668161,
  "created_at" : "2013-05-02 17:59:01 +0000",
  "in_reply_to_screen_name" : "BuzzFeed",
  "in_reply_to_user_id_str" : "5695632",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 94, 103 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/nC1m65yoDD",
      "expanded_url" : "http:\/\/at.wh.gov\/kEbYZ",
      "display_url" : "at.wh.gov\/kEbYZ"
    } ]
  },
  "geo" : { },
  "id_str" : "330014091336876032",
  "text" : "Preview President Obama's trip to Mexico and Costa Rica with Deputy National Security Advisor @Rhodes44: http:\/\/t.co\/nC1m65yoDD",
  "id" : 330014091336876032,
  "created_at" : "2013-05-02 17:41:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/1BXss1dwzc",
      "expanded_url" : "http:\/\/at.wh.gov\/kEaon",
      "display_url" : "at.wh.gov\/kEaon"
    } ]
  },
  "geo" : { },
  "id_str" : "330003760241860608",
  "text" : "Lift off from the South Lawn of the White House. President Obama's headed to Mexico and Costa Rica ---&gt; http:\/\/t.co\/1BXss1dwzc",
  "id" : 330003760241860608,
  "created_at" : "2013-05-02 17:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/329959157799211009\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/ruw8vD90fy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJRAGxeCUAAdDBm.jpg",
      "id_str" : "329959157807599616",
      "id" : 329959157807599616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJRAGxeCUAAdDBm.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ruw8vD90fy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329994291197911040",
  "text" : "RT @FLOTUS: Bo at his morning post. http:\/\/t.co\/ruw8vD90fy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/329959157799211009\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/ruw8vD90fy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BJRAGxeCUAAdDBm.jpg",
        "id_str" : "329959157807599616",
        "id" : 329959157807599616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJRAGxeCUAAdDBm.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ruw8vD90fy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329982210658664448",
    "text" : "Bo at his morning post. http:\/\/t.co\/ruw8vD90fy",
    "id" : 329982210658664448,
    "created_at" : "2013-05-02 15:34:24 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 329994291197911040,
  "created_at" : "2013-05-02 16:22:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 89, 101 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329983566991749122",
  "text" : "\"Penny is one of our country\u2019s most distinguished business leaders.\" \u2014President Obama on @CommerceGov nominee Penny Pritzker",
  "id" : 329983566991749122,
  "created_at" : "2013-05-02 15:39:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329975477605396480",
  "text" : "\"He does not rest until he\u2019s delivered the best possible deal for American businesses &amp; American workers.\"\u2014Obama on USTR nominee Mike Froman",
  "id" : 329975477605396480,
  "created_at" : "2013-05-02 15:07:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "329961423423819776",
  "text" : "Happening now: President Obama makes a personnel announcement from the White House. http:\/\/t.co\/JludLrcLOd",
  "id" : 329961423423819776,
  "created_at" : "2013-05-02 14:11:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/JludLrcLOd",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "329949724960497664",
  "text" : "Today at 10:15am ET, President Obama will make a personnel announcement from the White House. Watch: http:\/\/t.co\/JludLrcLOd",
  "id" : 329949724960497664,
  "created_at" : "2013-05-02 13:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/329732001924014081\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/6S7IhEgEld",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJNxgj4CYAEQ5p-.jpg",
      "id_str" : "329732001928208385",
      "id" : 329732001928208385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJNxgj4CYAEQ5p-.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6S7IhEgEld"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329732001924014081",
  "text" : "It's May! http:\/\/t.co\/6S7IhEgEld",
  "id" : 329732001924014081,
  "created_at" : "2013-05-01 23:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 116, 128 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329726920386297858",
  "text" : "RT @wethepeople: More than 8 million users, 200,000+ petitions, 13 million+ signatures...and now there's an API for @WeThePeople: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 99, 111 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/mIh99jBzvL",
        "expanded_url" : "http:\/\/at.wh.gov\/kCwX3",
        "display_url" : "at.wh.gov\/kCwX3"
      } ]
    },
    "geo" : { },
    "id_str" : "329726470501048321",
    "text" : "More than 8 million users, 200,000+ petitions, 13 million+ signatures...and now there's an API for @WeThePeople: http:\/\/t.co\/mIh99jBzvL",
    "id" : 329726470501048321,
    "created_at" : "2013-05-01 22:38:11 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 329726920386297858,
  "created_at" : "2013-05-01 22:39:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329713138062733312",
  "text" : "RT @letsmove: \"With simple steps, all of us can make physical activity a way of life.\" -President Obama on National Physical Fitness &amp; \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329684177953882113",
    "text" : "\"With simple steps, all of us can make physical activity a way of life.\" -President Obama on National Physical Fitness &amp; Sports Month",
    "id" : 329684177953882113,
    "created_at" : "2013-05-01 19:50:07 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 329713138062733312,
  "created_at" : "2013-05-01 21:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/XSkucXXOKA",
      "expanded_url" : "http:\/\/JoiningForces.gov",
      "display_url" : "JoiningForces.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "329700091927597057",
  "text" : "RT @FLOTUS: Every single person can do something to support our nation's military families. Join forces with us at http:\/\/t.co\/XSkucXXOKA. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/XSkucXXOKA",
        "expanded_url" : "http:\/\/JoiningForces.gov",
        "display_url" : "JoiningForces.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "329660805714960384",
    "text" : "Every single person can do something to support our nation's military families. Join forces with us at http:\/\/t.co\/XSkucXXOKA. \u2013mo",
    "id" : 329660805714960384,
    "created_at" : "2013-05-01 18:17:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 329700091927597057,
  "created_at" : "2013-05-01 20:53:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 72, 76 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/orM0YyTvXv",
      "expanded_url" : "http:\/\/at.wh.gov\/kChq6",
      "display_url" : "at.wh.gov\/kChq6"
    } ]
  },
  "geo" : { },
  "id_str" : "329688101939195906",
  "text" : "\"He\u2019s like the Jim Brown or Bo Jackson of telecom.\" \u2014President Obama on @FCC nominee Tom Wheeler: http:\/\/t.co\/orM0YyTvXv",
  "id" : 329688101939195906,
  "created_at" : "2013-05-01 20:05:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329677792360931328",
  "text" : "\"He\u2019s fought to give more Americans in low-income communities access to affordable housing.\" \u2014President Obama on FHFA nominee Mel Watt",
  "id" : 329677792360931328,
  "created_at" : "2013-05-01 19:24:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "329663375426605056",
  "text" : "Happening now: President Obama makes a personnel announcement. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 329663375426605056,
  "created_at" : "2013-05-01 18:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "329637847801933824",
  "text" : "Tune in at 2:15pm ET for a personnel announcement from President Obama: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 329637847801933824,
  "created_at" : "2013-05-01 16:46:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "WFP USA",
      "screen_name" : "WFPUSA",
      "indices" : [ 90, 97 ],
      "id_str" : "15079924",
      "id" : 15079924
    }, {
      "name" : "Hunter Biden",
      "screen_name" : "HunterBiden",
      "indices" : [ 104, 116 ],
      "id_str" : "1337029050",
      "id" : 1337029050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BelowtheLine",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329628073987284992",
  "text" : "RT @DrBiden: Looking forward to raising awareness on global hunger for #BelowtheLine with @WFPUSA &amp; @HunterBiden. -Jill",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WFP USA",
        "screen_name" : "WFPUSA",
        "indices" : [ 77, 84 ],
        "id_str" : "15079924",
        "id" : 15079924
      }, {
        "name" : "Hunter Biden",
        "screen_name" : "HunterBiden",
        "indices" : [ 91, 103 ],
        "id_str" : "1337029050",
        "id" : 1337029050
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BelowtheLine",
        "indices" : [ 58, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "329614081667522560",
    "text" : "Looking forward to raising awareness on global hunger for #BelowtheLine with @WFPUSA &amp; @HunterBiden. -Jill",
    "id" : 329614081667522560,
    "created_at" : "2013-05-01 15:11:35 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 329628073987284992,
  "created_at" : "2013-05-01 16:07:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/329603719865978880\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/7OZ7I5J0dH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BJL81j-CUAA5Vkm.jpg",
      "id_str" : "329603719870173184",
      "id" : 329603719870173184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BJL81j-CUAA5Vkm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 527
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 527
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 527
      } ],
      "display_url" : "pic.twitter.com\/7OZ7I5J0dH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329603719865978880",
  "text" : "Sharing a moment in the Green Room. http:\/\/t.co\/7OZ7I5J0dH",
  "id" : 329603719865978880,
  "created_at" : "2013-05-01 14:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]