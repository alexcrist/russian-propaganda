Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 98, 102 ]
    }, {
      "text" : "HCR",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/o6idOcIb",
      "expanded_url" : "http:\/\/on.wh.gov\/R0Dh",
      "display_url" : "on.wh.gov\/R0Dh"
    } ]
  },
  "geo" : { },
  "id_str" : "219160779184803840",
  "text" : "Find out all the ways the Affordable Care Act is a win for small businesses: http:\/\/t.co\/o6idOcIb #ACA #HCR",
  "id" : 219160779184803840,
  "created_at" : "2012-06-30 20:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/Yh3AsHwC",
      "expanded_url" : "http:\/\/ow.ly\/bW0IS",
      "display_url" : "ow.ly\/bW0IS"
    } ]
  },
  "geo" : { },
  "id_str" : "219131614800777217",
  "text" : "\"This is a reminder of what makes us Americans. We don't just look out for ourselves.\" -President Obama Weekly Address: http:\/\/t.co\/Yh3AsHwC",
  "id" : 219131614800777217,
  "created_at" : "2012-06-30 18:13:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/8KTlDnqG",
      "expanded_url" : "http:\/\/youtu.be\/-v8VWWi4gsI",
      "display_url" : "youtu.be\/-v8VWWi4gsI"
    } ]
  },
  "geo" : { },
  "id_str" : "219083008592977923",
  "text" : "Weekly Address: An All-Hands-On-Deck Approach to Fighting the Colorado Wildfires: http:\/\/t.co\/8KTlDnqG",
  "id" : 219083008592977923,
  "created_at" : "2012-06-30 15:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/218844305735954432\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/2AwZUdzq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Awl9vJECMAE7Qvf.jpg",
      "id_str" : "218844305744343041",
      "id" : 218844305744343041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Awl9vJECMAE7Qvf.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2AwZUdzq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218844305735954432",
  "text" : "\"Our thoughts and prayers to go out to the families who have been affected\" -President Obama touring fire damage in CO http:\/\/t.co\/2AwZUdzq",
  "id" : 218844305735954432,
  "created_at" : "2012-06-29 23:12:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 16, 23 ]
    }, {
      "text" : "ACA",
      "indices" : [ 34, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/wl5zg73v",
      "expanded_url" : "http:\/\/on.wh.gov\/AXO2",
      "display_url" : "on.wh.gov\/AXO2"
    } ]
  },
  "geo" : { },
  "id_str" : "218772213875212288",
  "text" : "Watch: From the #SCOTUS ruling on #ACA to the Congressional Picnic, here's your video guide to this week at 1600 Penn: http:\/\/t.co\/wl5zg73v",
  "id" : 218772213875212288,
  "created_at" : "2012-06-29 18:25:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/218753330258788353\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/JLGqCWPV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Awkq_rACQAENQ21.jpg",
      "id_str" : "218753330267176961",
      "id" : 218753330267176961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Awkq_rACQAENQ21.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JLGqCWPV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218753330258788353",
  "text" : "Photo of the Day: President Obama calls Solicitor General Verrilli after the Supreme Court's ruling on health reform http:\/\/t.co\/JLGqCWPV",
  "id" : 218753330258788353,
  "created_at" : "2012-06-29 17:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 103, 107 ]
    }, {
      "text" : "ACA",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/HiQOMkKT",
      "expanded_url" : "http:\/\/on.wh.gov\/mp3O",
      "display_url" : "on.wh.gov\/mp3O"
    } ]
  },
  "geo" : { },
  "id_str" : "218743217854742530",
  "text" : "FACT SHEET: The Affordable Care Act: Secure Health Coverage for the Middle Class: http:\/\/t.co\/HiQOMkKT #hcr #ACA",
  "id" : 218743217854742530,
  "created_at" : "2012-06-29 16:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/PHsKUzSY",
      "expanded_url" : "http:\/\/on.wh.gov\/NvDD",
      "display_url" : "on.wh.gov\/NvDD"
    } ]
  },
  "geo" : { },
  "id_str" : "218703851405062144",
  "text" : "20 yr old Abby has a rare congenital disease. Thanks to health reform, she can stay on her parents plan until age 26: http:\/\/t.co\/PHsKUzSY",
  "id" : 218703851405062144,
  "created_at" : "2012-06-29 13:53:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 95, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/KgTNkZBa",
      "expanded_url" : "http:\/\/on.wh.gov\/POQz",
      "display_url" : "on.wh.gov\/POQz"
    } ]
  },
  "geo" : { },
  "id_str" : "218535341609590786",
  "text" : "\"I carried Natoma's story with me every day of the fight to pass this law\" -President Obama on #ACA. Read the letter: http:\/\/t.co\/KgTNkZBa",
  "id" : 218535341609590786,
  "created_at" : "2012-06-29 02:44:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 32, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/qu6DacBC",
      "expanded_url" : "http:\/\/on.wh.gov\/8V6L",
      "display_url" : "on.wh.gov\/8V6L"
    } ]
  },
  "geo" : { },
  "id_str" : "218493815022026752",
  "text" : "Judy on health reform: \"Without #ACA, I would be so worried about lifetime limits that I wouldn't be able to sleep.\"  http:\/\/t.co\/qu6DacBC",
  "id" : 218493815022026752,
  "created_at" : "2012-06-28 23:59:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 130, 134 ]
    }, {
      "text" : "HCR",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/WweLYibn",
      "expanded_url" : "http:\/\/on.wh.gov\/mVpc",
      "display_url" : "on.wh.gov\/mVpc"
    } ]
  },
  "geo" : { },
  "id_str" : "218477357319729152",
  "text" : "Thanks to health reform, kids like 2-year-old Avey can't be denied coverage due to pre-existing conditions: http:\/\/t.co\/WweLYibn  #ACA #HCR",
  "id" : 218477357319729152,
  "created_at" : "2012-06-28 22:53:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/218452887162994688\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ahqFmyMI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwgZvlRCQAEKMDi.jpg",
      "id_str" : "218452887175577601",
      "id" : 218452887175577601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwgZvlRCQAEKMDi.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ahqFmyMI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218452887162994688",
  "text" : "This letter in my office is a reminder of how health reform benefits Americans. Today's victory is 1 for all of us. -bo http:\/\/t.co\/ahqFmyMI",
  "id" : 218452887162994688,
  "created_at" : "2012-06-28 21:16:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 100, 107 ]
    }, {
      "text" : "ACA",
      "indices" : [ 129, 133 ]
    }, {
      "text" : "HCR",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/xJGbFNjP",
      "expanded_url" : "http:\/\/on.wh.gov\/OEcP",
      "display_url" : "on.wh.gov\/OEcP"
    } ]
  },
  "geo" : { },
  "id_str" : "218433659491991553",
  "text" : "Have Qs on the Affordable Care Act? Get answers during WH Office Hours today at 4:30 ET. Ask now w\/ #WHChat http:\/\/t.co\/xJGbFNjP #ACA #HCR",
  "id" : 218433659491991553,
  "created_at" : "2012-06-28 20:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/218429402453770240\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/pkqJp4Yt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwgEYl5CAAISvmO.jpg",
      "id_str" : "218429402462158850",
      "id" : 218429402462158850,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwgEYl5CAAISvmO.jpg",
      "sizes" : [ {
        "h" : 1162,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 1162,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 304
      }, {
        "h" : 1162,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/pkqJp4Yt"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/XACoaGLm",
      "expanded_url" : "http:\/\/on.wh.gov\/Igi2",
      "display_url" : "on.wh.gov\/Igi2"
    } ]
  },
  "geo" : { },
  "id_str" : "218429402453770240",
  "text" : "How does the Affordable Care Act benefit Americans?  Check out this infographic &amp; find out: #ACA http:\/\/t.co\/XACoaGLm http:\/\/t.co\/pkqJp4Yt",
  "id" : 218429402453770240,
  "created_at" : "2012-06-28 19:43:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/fSApvV13",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/healthreform",
      "display_url" : "whitehouse.gov\/healthreform"
    } ]
  },
  "geo" : { },
  "id_str" : "218424147510960128",
  "text" : "RT @VP: Today\u2019s decision is a really big \u2013 important \u2013 deal. Find out what it means for you: http:\/\/t.co\/fSApvV13  \u2013VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/fSApvV13",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/healthreform",
        "display_url" : "whitehouse.gov\/healthreform"
      } ]
    },
    "geo" : { },
    "id_str" : "218423781063004162",
    "text" : "Today\u2019s decision is a really big \u2013 important \u2013 deal. Find out what it means for you: http:\/\/t.co\/fSApvV13  \u2013VP",
    "id" : 218423781063004162,
    "created_at" : "2012-06-28 19:21:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 218424147510960128,
  "created_at" : "2012-06-28 19:22:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 103, 110 ]
    }, {
      "text" : "ACA",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/mOg6Rpkg",
      "expanded_url" : "http:\/\/on.wh.gov\/9X9z",
      "display_url" : "on.wh.gov\/9X9z"
    } ]
  },
  "geo" : { },
  "id_str" : "218416087212101632",
  "text" : "Today at 4:30ET: Jeanne Lambrew answers your Affordable Care Act questions for WH Office Hours. Ask w\/ #WHChat http:\/\/t.co\/mOg6Rpkg #ACA",
  "id" : 218416087212101632,
  "created_at" : "2012-06-28 18:50:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/ZuDhDELs",
      "expanded_url" : "http:\/\/youtu.be\/b5zU1y_0Geo",
      "display_url" : "youtu.be\/b5zU1y_0Geo"
    } ]
  },
  "geo" : { },
  "id_str" : "218386263311527936",
  "text" : "Watch: President Obama speaks on the Supreme Court's decision to uphold the Affordable Care Act: http:\/\/t.co\/ZuDhDELs",
  "id" : 218386263311527936,
  "created_at" : "2012-06-28 16:51:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218380194011029505",
  "text" : "Pres. Obama: \"It is time for us to move forward...to keep our focus on the most urgent challenge of our time: putting people back to work\"",
  "id" : 218380194011029505,
  "created_at" : "2012-06-28 16:27:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aca",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/dfEWfXpi",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "218377221058990082",
  "text" : "Happening now: President Obama Speaks On the Supreme Court\u2019s Ruling on the Affordable Care Act: http:\/\/t.co\/dfEWfXpi #aca",
  "id" : 218377221058990082,
  "created_at" : "2012-06-28 16:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/vQ5OlRZR",
      "expanded_url" : "http:\/\/on.wh.gov\/R34b",
      "display_url" : "on.wh.gov\/R34b"
    } ]
  },
  "geo" : { },
  "id_str" : "218363103501492224",
  "text" : "At 12:15 p.m. ET President Obama will deliver a statement in the East Room. Watch live: http:\/\/t.co\/vQ5OlRZR",
  "id" : 218363103501492224,
  "created_at" : "2012-06-28 15:19:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 36, 47 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pell",
      "indices" : [ 63, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/qRXslPKS",
      "expanded_url" : "http:\/\/on.wh.gov\/igb6",
      "display_url" : "on.wh.gov\/igb6"
    } ]
  },
  "geo" : { },
  "id_str" : "218319080199954432",
  "text" : "Celebrating Success: Education Sec. @ArneDuncan on 40 Years of #Pell Grants: http:\/\/t.co\/qRXslPKS",
  "id" : 218319080199954432,
  "created_at" : "2012-06-28 12:24:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIV",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/DtOdkbT4",
      "expanded_url" : "http:\/\/on.wh.gov\/bzG3",
      "display_url" : "on.wh.gov\/bzG3"
    } ]
  },
  "geo" : { },
  "id_str" : "218147788221984769",
  "text" : "Today Is National #HIV Testing Day: http:\/\/t.co\/DtOdkbT4",
  "id" : 218147788221984769,
  "created_at" : "2012-06-28 01:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 26, 37 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/4bHmNkSz",
      "expanded_url" : "http:\/\/sfy.co\/j0Su",
      "display_url" : "sfy.co\/j0Su"
    } ]
  },
  "geo" : { },
  "id_str" : "218134020729470978",
  "text" : "RT @usedgov: Did you miss @arneduncan's #WHChat on College Affordability today? Read the whole chat here: http:\/\/t.co\/4bHmNkSz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 13, 24 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 27, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/4bHmNkSz",
        "expanded_url" : "http:\/\/sfy.co\/j0Su",
        "display_url" : "sfy.co\/j0Su"
      } ]
    },
    "geo" : { },
    "id_str" : "218131801619697664",
    "text" : "Did you miss @arneduncan's #WHChat on College Affordability today? Read the whole chat here: http:\/\/t.co\/4bHmNkSz",
    "id" : 218131801619697664,
    "created_at" : "2012-06-28 00:00:48 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 218134020729470978,
  "created_at" : "2012-06-28 00:09:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WaldoCanyonFire",
      "indices" : [ 68, 84 ]
    }, {
      "text" : "FlagstaffFire",
      "indices" : [ 85, 99 ]
    }, {
      "text" : "HighParkFire",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/tmtZDniU",
      "expanded_url" : "http:\/\/helpcoloradonow.org",
      "display_url" : "helpcoloradonow.org"
    } ]
  },
  "geo" : { },
  "id_str" : "218128138176167936",
  "text" : "RT @fema: (June 27) Please share: how to help those affected by the #WaldoCanyonFire #FlagstaffFire #HighParkFire http:\/\/t.co\/tmtZDniU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WaldoCanyonFire",
        "indices" : [ 58, 74 ]
      }, {
        "text" : "FlagstaffFire",
        "indices" : [ 75, 89 ]
      }, {
        "text" : "HighParkFire",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/tmtZDniU",
        "expanded_url" : "http:\/\/helpcoloradonow.org",
        "display_url" : "helpcoloradonow.org"
      } ]
    },
    "geo" : { },
    "id_str" : "218030791236648960",
    "text" : "(June 27) Please share: how to help those affected by the #WaldoCanyonFire #FlagstaffFire #HighParkFire http:\/\/t.co\/tmtZDniU",
    "id" : 218030791236648960,
    "created_at" : "2012-06-27 17:19:26 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 218128138176167936,
  "created_at" : "2012-06-27 23:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ronaldwgumbs",
      "screen_name" : "ronaldwgumbs",
      "indices" : [ 3, 16 ],
      "id_str" : "18334172",
      "id" : 18334172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/BXA1aUT8",
      "expanded_url" : "http:\/\/wh.gov\/lqVs\/\/",
      "display_url" : "wh.gov\/lqVs\/\/"
    } ]
  },
  "geo" : { },
  "id_str" : "218087045548081152",
  "text" : "RT @ronaldwgumbs: #MyRefi http:\/\/t.co\/BXA1aUT8@cspanwj I'll refinance and use the $3,000 to replace the refrigerator and gas range, purc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyRefi",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 8, 28 ],
        "url" : "http:\/\/t.co\/BXA1aUT8",
        "expanded_url" : "http:\/\/wh.gov\/lqVs\/\/",
        "display_url" : "wh.gov\/lqVs\/\/"
      } ]
    },
    "geo" : { },
    "id_str" : "218084482975141888",
    "text" : "#MyRefi http:\/\/t.co\/BXA1aUT8@cspanwj I'll refinance and use the $3,000 to replace the refrigerator and gas range, purchased in 1985.",
    "id" : 218084482975141888,
    "created_at" : "2012-06-27 20:52:47 +0000",
    "user" : {
      "name" : "ronaldwgumbs",
      "screen_name" : "ronaldwgumbs",
      "protected" : false,
      "id_str" : "18334172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1271544421\/DSC_0042_normal.JPG",
      "id" : 18334172,
      "verified" : false
    }
  },
  "id" : 218087045548081152,
  "created_at" : "2012-06-27 21:02:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J. Ian Irby",
      "screen_name" : "jayinatlanta",
      "indices" : [ 3, 16 ],
      "id_str" : "15858853",
      "id" : 15858853
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/26llxT8H",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
      "display_url" : "whitehouse.gov\/infographics\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218081756568489984",
  "text" : "RT @jayinatlanta: .@WhiteHouse plan for homeowner refinancing: good for economy, and I know I would benefit. http:\/\/t.co\/26llxT8H http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/Uh0xClxS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "id_str" : "215551607813836801",
        "id" : 215551607813836801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/Uh0xClxS"
      } ],
      "hashtags" : [ {
        "text" : "MyRefi",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/26llxT8H",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
        "display_url" : "whitehouse.gov\/infographics\/r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "218081051505995776",
    "text" : ".@WhiteHouse plan for homeowner refinancing: good for economy, and I know I would benefit. http:\/\/t.co\/26llxT8H http:\/\/t.co\/Uh0xClxS #MyRefi",
    "id" : 218081051505995776,
    "created_at" : "2012-06-27 20:39:09 +0000",
    "user" : {
      "name" : "J. Ian Irby",
      "screen_name" : "jayinatlanta",
      "protected" : false,
      "id_str" : "15858853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1444644038\/Jay_TopOfATL_Small_normal.jpg",
      "id" : 15858853,
      "verified" : false
    }
  },
  "id" : 218081756568489984,
  "created_at" : "2012-06-27 20:41:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betty Tuininga",
      "screen_name" : "BJTuininga",
      "indices" : [ 3, 14 ],
      "id_str" : "32741773",
      "id" : 32741773
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 72, 83 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/GmFkk4x6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "id_str" : "215551607813836801",
      "id" : 215551607813836801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/GmFkk4x6"
    } ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/PK8QualI",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
      "display_url" : "whitehouse.gov\/infographics\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218071843138052098",
  "text" : "RT @BJTuininga: Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/PK8QualI http:\/\/t.co\/GmFkk4x6 #MyRefi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 56, 67 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/GmFkk4x6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "id_str" : "215551607813836801",
        "id" : 215551607813836801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/GmFkk4x6"
      } ],
      "hashtags" : [ {
        "text" : "MyRefi",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/PK8QualI",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
        "display_url" : "whitehouse.gov\/infographics\/r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "218071179385245696",
    "text" : "Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/PK8QualI http:\/\/t.co\/GmFkk4x6 #MyRefi",
    "id" : 218071179385245696,
    "created_at" : "2012-06-27 19:59:55 +0000",
    "user" : {
      "name" : "Betty Tuininga",
      "screen_name" : "BJTuininga",
      "protected" : false,
      "id_str" : "32741773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751831855960354817\/tN0mLzpe_normal.jpg",
      "id" : 32741773,
      "verified" : false
    }
  },
  "id" : 218071843138052098,
  "created_at" : "2012-06-27 20:02:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sweet Sister",
      "screen_name" : "GlissG",
      "indices" : [ 3, 10 ],
      "id_str" : "21630040",
      "id" : 21630040
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 68, 79 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/D3UOz1Pv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "id_str" : "215551607813836801",
      "id" : 215551607813836801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/D3UOz1Pv"
    } ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/Xh0wWUcg",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
      "display_url" : "whitehouse.gov\/infographics\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "218071760724168705",
  "text" : "RT @GlissG: Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/Xh0wWUcg http:\/\/t.co\/D3UOz1Pv #MyRefi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 56, 67 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/D3UOz1Pv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "id_str" : "215551607813836801",
        "id" : 215551607813836801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/D3UOz1Pv"
      } ],
      "hashtags" : [ {
        "text" : "MyRefi",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/Xh0wWUcg",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
        "display_url" : "whitehouse.gov\/infographics\/r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "218071342518509568",
    "text" : "Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/Xh0wWUcg http:\/\/t.co\/D3UOz1Pv #MyRefi",
    "id" : 218071342518509568,
    "created_at" : "2012-06-27 20:00:34 +0000",
    "user" : {
      "name" : "Sweet Sister",
      "screen_name" : "GlissG",
      "protected" : false,
      "id_str" : "21630040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793962993604325376\/5kMHmNPY_normal.jpg",
      "id" : 21630040,
      "verified" : false
    }
  },
  "id" : 218071760724168705,
  "created_at" : "2012-06-27 20:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/218065195736637442\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/KXIJtUUd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Awa5I-JCIAAhbPk.jpg",
      "id_str" : "218065195745026048",
      "id" : 218065195745026048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Awa5I-JCIAAhbPk.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KXIJtUUd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218065195736637442",
  "text" : "Photo of the Day: President Obama talks to a group of students while visiting the Varsity restaurant in Atlanta, G.A. http:\/\/t.co\/KXIJtUUd",
  "id" : 218065195736637442,
  "created_at" : "2012-06-27 19:36:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 100, 117 ]
    }, {
      "text" : "whchat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218049581143957506",
  "text" : "RT @arneduncan: Thanks everyone for your questions. This week is critical for Congressional action: #DontDoubleMyRate. #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 84, 101 ]
      }, {
        "text" : "whchat",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218049528497061889",
    "text" : "Thanks everyone for your questions. This week is critical for Congressional action: #DontDoubleMyRate. #whchat",
    "id" : 218049528497061889,
    "created_at" : "2012-06-27 18:33:53 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218049581143957506,
  "created_at" : "2012-06-27 18:34:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Chip Williams",
      "screen_name" : "chip122772",
      "indices" : [ 17, 28 ],
      "id_str" : "331583562",
      "id" : 331583562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218049415586385921",
  "text" : "RT @arneduncan: .@chip122772 We all must support great public education, it's the key to sustaining our democracy. #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chip Williams",
        "screen_name" : "chip122772",
        "indices" : [ 1, 12 ],
        "id_str" : "331583562",
        "id" : 331583562
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218049230739214336",
    "text" : ".@chip122772 We all must support great public education, it's the key to sustaining our democracy. #whchat",
    "id" : 218049230739214336,
    "created_at" : "2012-06-27 18:32:42 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218049415586385921,
  "created_at" : "2012-06-27 18:33:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chip Williams",
      "screen_name" : "chip122772",
      "indices" : [ 3, 14 ],
      "id_str" : "331583562",
      "id" : 331583562
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 16, 27 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218049397949349888",
  "text" : "RT @chip122772: @arneduncan #whchat how do we get and keep good educators with so many attacks on public education?  Higher Ed prep star ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 0, 11 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218048586645110784",
    "in_reply_to_user_id" : 44873497,
    "text" : "@arneduncan #whchat how do we get and keep good educators with so many attacks on public education?  Higher Ed prep starts long before univ",
    "id" : 218048586645110784,
    "created_at" : "2012-06-27 18:30:08 +0000",
    "in_reply_to_screen_name" : "JohnKingatED",
    "in_reply_to_user_id_str" : "44873497",
    "user" : {
      "name" : "Chip Williams",
      "screen_name" : "chip122772",
      "protected" : false,
      "id_str" : "331583562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621632675661631488\/X0T9GtU4_normal.jpg",
      "id" : 331583562,
      "verified" : false
    }
  },
  "id" : 218049397949349888,
  "created_at" : "2012-06-27 18:33:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Academies",
      "screen_name" : "MyFutureMyWay",
      "indices" : [ 17, 31 ],
      "id_str" : "418133642",
      "id" : 418133642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218049353179332608",
  "text" : "RT @arneduncan: .@MyFutureMyWay Yes - hugely important. More &amp; more high school students are getting college credit before they grad ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Academies",
        "screen_name" : "MyFutureMyWay",
        "indices" : [ 1, 15 ],
        "id_str" : "418133642",
        "id" : 418133642
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218048795773112320",
    "text" : ".@MyFutureMyWay Yes - hugely important. More &amp; more high school students are getting college credit before they graduate. #whchat",
    "id" : 218048795773112320,
    "created_at" : "2012-06-27 18:30:58 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218049353179332608,
  "created_at" : "2012-06-27 18:33:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Academies",
      "screen_name" : "MyFutureMyWay",
      "indices" : [ 3, 17 ],
      "id_str" : "418133642",
      "id" : 418133642
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 19, 30 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218049331968745472",
  "text" : "RT @MyFutureMyWay: @arneduncan #WHChat Do you think that aligning high schools with postsecondary education is the critical next step in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 0, 11 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218048251629285379",
    "in_reply_to_user_id" : 44873497,
    "text" : "@arneduncan #WHChat Do you think that aligning high schools with postsecondary education is the critical next step in education reform?",
    "id" : 218048251629285379,
    "created_at" : "2012-06-27 18:28:48 +0000",
    "in_reply_to_screen_name" : "JohnKingatED",
    "in_reply_to_user_id_str" : "44873497",
    "user" : {
      "name" : "Academies",
      "screen_name" : "MyFutureMyWay",
      "protected" : false,
      "id_str" : "418133642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1650776660\/Academies_Small_normal.jpg",
      "id" : 418133642,
      "verified" : false
    }
  },
  "id" : 218049331968745472,
  "created_at" : "2012-06-27 18:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Bianca Strzalkowski",
      "screen_name" : "BiancaSki",
      "indices" : [ 17, 27 ],
      "id_str" : "382911784",
      "id" : 382911784
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pell",
      "indices" : [ 68, 73 ]
    }, {
      "text" : "joiningforces",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218049305456549889",
  "text" : "RT @arneduncan: .@BiancaSki Yes, military families are eligible for #Pell grants &amp; other federal grants, like GI Bill #joiningforces ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bianca Strzalkowski",
        "screen_name" : "BiancaSki",
        "indices" : [ 1, 11 ],
        "id_str" : "382911784",
        "id" : 382911784
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Pell",
        "indices" : [ 52, 57 ]
      }, {
        "text" : "joiningforces",
        "indices" : [ 106, 120 ]
      }, {
        "text" : "whchat",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218048506957545472",
    "text" : ".@BiancaSki Yes, military families are eligible for #Pell grants &amp; other federal grants, like GI Bill #joiningforces #whchat",
    "id" : 218048506957545472,
    "created_at" : "2012-06-27 18:29:49 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218049305456549889,
  "created_at" : "2012-06-27 18:33:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bianca Strzalkowski",
      "screen_name" : "BiancaSki",
      "indices" : [ 3, 13 ],
      "id_str" : "382911784",
      "id" : 382911784
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 15, 26 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "milfams",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "JoiningForces",
      "indices" : [ 103, 117 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218049288893247488",
  "text" : "RT @BiancaSki: @arneduncan will discretionary grants be opened to #milfams like was pledged as part of #JoiningForces #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 0, 11 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "milfams",
        "indices" : [ 51, 59 ]
      }, {
        "text" : "JoiningForces",
        "indices" : [ 88, 102 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218047978286481408",
    "in_reply_to_user_id" : 44873497,
    "text" : "@arneduncan will discretionary grants be opened to #milfams like was pledged as part of #JoiningForces #WHChat",
    "id" : 218047978286481408,
    "created_at" : "2012-06-27 18:27:43 +0000",
    "in_reply_to_screen_name" : "JohnKingatED",
    "in_reply_to_user_id_str" : "44873497",
    "user" : {
      "name" : "Bianca Strzalkowski",
      "screen_name" : "BiancaSki",
      "protected" : false,
      "id_str" : "382911784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798276181267279872\/vVso34xA_normal.jpg",
      "id" : 382911784,
      "verified" : false
    }
  },
  "id" : 218049288893247488,
  "created_at" : "2012-06-27 18:32:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Jessica MacCall",
      "screen_name" : "jmaccx",
      "indices" : [ 17, 24 ],
      "id_str" : "292106752",
      "id" : 292106752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218048395984633858",
  "text" : "RT @arneduncan: .@jmaccx No. We want every student to be college &amp; career ready with the skills to pursue their dreams whatever they ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jessica MacCall",
        "screen_name" : "jmaccx",
        "indices" : [ 1, 8 ],
        "id_str" : "292106752",
        "id" : 292106752
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218048023157145600",
    "text" : ".@jmaccx No. We want every student to be college &amp; career ready with the skills to pursue their dreams whatever they are. #whchat",
    "id" : 218048023157145600,
    "created_at" : "2012-06-27 18:27:54 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218048395984633858,
  "created_at" : "2012-06-27 18:29:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica MacCall",
      "screen_name" : "jmaccx",
      "indices" : [ 3, 10 ],
      "id_str" : "292106752",
      "id" : 292106752
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 12, 19 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 20, 31 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218048375893925888",
  "text" : "RT @jmaccx: @WHLive @arneduncan Do u think the push that EVERY child pursue a college degree is having a negative impact on college pric ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 0, 7 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 8, 19 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 128, 135 ]
      }, {
        "text" : "ed",
        "indices" : [ 136, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218047283525189632",
    "in_reply_to_user_id" : 369505837,
    "text" : "@WHLive @arneduncan Do u think the push that EVERY child pursue a college degree is having a negative impact on college prices? #WHChat #ed",
    "id" : 218047283525189632,
    "created_at" : "2012-06-27 18:24:58 +0000",
    "in_reply_to_screen_name" : "WHLive",
    "in_reply_to_user_id_str" : "369505837",
    "user" : {
      "name" : "Jessica MacCall",
      "screen_name" : "jmaccx",
      "protected" : false,
      "id_str" : "292106752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797095488084463616\/dbgDWrxc_normal.jpg",
      "id" : 292106752,
      "verified" : false
    }
  },
  "id" : 218048375893925888,
  "created_at" : "2012-06-27 18:29:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Chris Cerrone",
      "screen_name" : "Stoptesting15",
      "indices" : [ 17, 31 ],
      "id_str" : "384028016",
      "id" : 384028016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCLB",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218046903466733568",
  "text" : "RT @arneduncan: .@Stoptesting15 we are giving states flexibility from #NCLB; many are much more focused on graduation rates &amp; colleg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Cerrone",
        "screen_name" : "Stoptesting15",
        "indices" : [ 1, 15 ],
        "id_str" : "384028016",
        "id" : 384028016
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NCLB",
        "indices" : [ 54, 59 ]
      }, {
        "text" : "whchat",
        "indices" : [ 135, 142 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218046400452235265",
    "text" : ".@Stoptesting15 we are giving states flexibility from #NCLB; many are much more focused on graduation rates &amp; college going rates. #whchat",
    "id" : 218046400452235265,
    "created_at" : "2012-06-27 18:21:27 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218046903466733568,
  "created_at" : "2012-06-27 18:23:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Cerrone",
      "screen_name" : "Stoptesting15",
      "indices" : [ 3, 17 ],
      "id_str" : "384028016",
      "id" : 384028016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218046829378551809",
  "text" : "RT @Stoptesting15: #WHChat How do we prepare students for college or careers when the emphasis in many schools is test scores?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218044554262224896",
    "text" : "#WHChat How do we prepare students for college or careers when the emphasis in many schools is test scores?",
    "id" : 218044554262224896,
    "created_at" : "2012-06-27 18:14:07 +0000",
    "user" : {
      "name" : "Chris Cerrone",
      "screen_name" : "Stoptesting15",
      "protected" : false,
      "id_str" : "384028016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/721505775626149888\/K-X9LvjH_normal.jpg",
      "id" : 384028016,
      "verified" : false
    }
  },
  "id" : 218046829378551809,
  "created_at" : "2012-06-27 18:23:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Peter Slutsky",
      "screen_name" : "pslutsky",
      "indices" : [ 17, 26 ],
      "id_str" : "15740946",
      "id" : 15740946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218046331846004736",
  "text" : "RT @arneduncan: .@pslutsky There are many great choices - public &amp; private - look @ all your options &amp; decide what's best for yo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Slutsky",
        "screen_name" : "pslutsky",
        "indices" : [ 1, 10 ],
        "id_str" : "15740946",
        "id" : 15740946
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 140, 147 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218045613974102016",
    "text" : ".@pslutsky There are many great choices - public &amp; private - look @ all your options &amp; decide what's best for you &amp; your family #whchat",
    "id" : 218045613974102016,
    "created_at" : "2012-06-27 18:18:20 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218046331846004736,
  "created_at" : "2012-06-27 18:21:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Slutsky",
      "screen_name" : "pslutsky",
      "indices" : [ 3, 12 ],
      "id_str" : "15740946",
      "id" : 15740946
    }, {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 14, 22 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 23, 34 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 35, 46 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218046304616579073",
  "text" : "RT @pslutsky: @usedgov @whitehouse @arneduncan Is the cost of a private school college education worth it in 2012 for a middle class fam ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 0, 8 ],
        "id_str" : "20437286",
        "id" : 20437286
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 9, 20 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 21, 32 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218044583051919360",
    "in_reply_to_user_id" : 20437286,
    "text" : "@usedgov @whitehouse @arneduncan Is the cost of a private school college education worth it in 2012 for a middle class family? #WHchat",
    "id" : 218044583051919360,
    "created_at" : "2012-06-27 18:14:14 +0000",
    "in_reply_to_screen_name" : "usedgov",
    "in_reply_to_user_id_str" : "20437286",
    "user" : {
      "name" : "Peter Slutsky",
      "screen_name" : "pslutsky",
      "protected" : false,
      "id_str" : "15740946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695456236993699840\/L6301Iif_normal.jpg",
      "id" : 15740946,
      "verified" : false
    }
  },
  "id" : 218046304616579073,
  "created_at" : "2012-06-27 18:21:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Kiki",
      "screen_name" : "Twittymilk",
      "indices" : [ 17, 28 ],
      "id_str" : "20345144",
      "id" : 20345144
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 29, 34 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/nqLeQVit",
      "expanded_url" : "http:\/\/www.consumerfinance.gov",
      "display_url" : "consumerfinance.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "218045632844271616",
  "text" : "RT @arneduncan: .@Twittymilk @CFPB is on the beat - taking complaints about private student loans: http:\/\/t.co\/nqLeQVit #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kiki",
        "screen_name" : "Twittymilk",
        "indices" : [ 1, 12 ],
        "id_str" : "20345144",
        "id" : 20345144
      }, {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 13, 18 ],
        "id_str" : "234826866",
        "id" : 234826866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/nqLeQVit",
        "expanded_url" : "http:\/\/www.consumerfinance.gov",
        "display_url" : "consumerfinance.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "218045341554057216",
    "text" : ".@Twittymilk @CFPB is on the beat - taking complaints about private student loans: http:\/\/t.co\/nqLeQVit #whchat",
    "id" : 218045341554057216,
    "created_at" : "2012-06-27 18:17:15 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218045632844271616,
  "created_at" : "2012-06-27 18:18:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kiki",
      "screen_name" : "Twittymilk",
      "indices" : [ 3, 14 ],
      "id_str" : "20345144",
      "id" : 20345144
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 28, 39 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218045613709856768",
  "text" : "RT @Twittymilk: @whitehouse @arneduncan what is the plan for helping students deal with private loans? There's no reprieve for those str ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 12, 23 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "218041752286801920",
    "geo" : { },
    "id_str" : "218042920765358080",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @arneduncan what is the plan for helping students deal with private loans? There's no reprieve for those struggling #WHChat",
    "id" : 218042920765358080,
    "in_reply_to_status_id" : 218041752286801920,
    "created_at" : "2012-06-27 18:07:38 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Kiki",
      "screen_name" : "Twittymilk",
      "protected" : false,
      "id_str" : "20345144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776965906375307264\/bJPEubyX_normal.jpg",
      "id" : 20345144,
      "verified" : false
    }
  },
  "id" : 218045613709856768,
  "created_at" : "2012-06-27 18:18:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Keith O'Neal",
      "screen_name" : "kd_oneal",
      "indices" : [ 17, 26 ],
      "id_str" : "57158545",
      "id" : 57158545
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218045566112903172",
  "text" : "RT @arneduncan: .@kd_oneal Pell covers tuition @ most community colleges + tax credit up to $2500\/yr #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith O'Neal",
        "screen_name" : "kd_oneal",
        "indices" : [ 1, 10 ],
        "id_str" : "57158545",
        "id" : 57158545
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 85, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218044921553223680",
    "text" : ".@kd_oneal Pell covers tuition @ most community colleges + tax credit up to $2500\/yr #whchat",
    "id" : 218044921553223680,
    "created_at" : "2012-06-27 18:15:35 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218045566112903172,
  "created_at" : "2012-06-27 18:18:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith O'Neal",
      "screen_name" : "kd_oneal",
      "indices" : [ 3, 12 ],
      "id_str" : "57158545",
      "id" : 57158545
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218045546269638656",
  "text" : "RT @kd_oneal: #WHChat How does Congress expect us to compete for jobs when we can't afford the necessary training. Even community colleg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215830024090165249",
    "text" : "#WHChat How does Congress expect us to compete for jobs when we can't afford the necessary training. Even community college rates are high.",
    "id" : 215830024090165249,
    "created_at" : "2012-06-21 15:34:22 +0000",
    "user" : {
      "name" : "Keith O'Neal",
      "screen_name" : "kd_oneal",
      "protected" : false,
      "id_str" : "57158545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475573745\/1358020351_m_normal.jpg",
      "id" : 57158545,
      "verified" : false
    }
  },
  "id" : 218045546269638656,
  "created_at" : "2012-06-27 18:18:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Jake Smith",
      "screen_name" : "CodeMonkey76",
      "indices" : [ 17, 30 ],
      "id_str" : "14291563",
      "id" : 14291563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218045509988925441",
  "text" : "RT @arneduncan: .@CodeMonkey76 Many universities are -- but not enough. We need consumers to vote with their feet &amp; make smart decis ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jake Smith",
        "screen_name" : "CodeMonkey76",
        "indices" : [ 1, 14 ],
        "id_str" : "14291563",
        "id" : 14291563
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218044532829339648",
    "text" : ".@CodeMonkey76 Many universities are -- but not enough. We need consumers to vote with their feet &amp; make smart decisions #whchat",
    "id" : 218044532829339648,
    "created_at" : "2012-06-27 18:14:02 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218045509988925441,
  "created_at" : "2012-06-27 18:17:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Smith",
      "screen_name" : "CodeMonkey76",
      "indices" : [ 3, 16 ],
      "id_str" : "14291563",
      "id" : 14291563
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 18, 29 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218045487096397824",
  "text" : "RT @CodeMonkey76: @arneduncan How is enabling people to take on more debt 'making college affordable'?  Why not *lower costs*? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 0, 11 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217635975180976128",
    "in_reply_to_user_id" : 44873497,
    "text" : "@arneduncan How is enabling people to take on more debt 'making college affordable'?  Why not *lower costs*? #WHChat",
    "id" : 217635975180976128,
    "created_at" : "2012-06-26 15:10:34 +0000",
    "in_reply_to_screen_name" : "JohnKingatED",
    "in_reply_to_user_id_str" : "44873497",
    "user" : {
      "name" : "Jake Smith",
      "screen_name" : "CodeMonkey76",
      "protected" : false,
      "id_str" : "14291563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746437147813519360\/D0IU3Cce_normal.jpg",
      "id" : 14291563,
      "verified" : false
    }
  },
  "id" : 218045487096397824,
  "created_at" : "2012-06-27 18:17:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Andrew Sider Chen",
      "screen_name" : "_ndrw",
      "indices" : [ 17, 23 ],
      "id_str" : "30166922",
      "id" : 30166922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218044703633977344",
  "text" : "RT @arneduncan: .@_ndrw Everyone needs some form of higher ed. 4 yr university, 2 yr comm college, trade\/ tech\/ voc training. $2B invest ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Sider Chen",
        "screen_name" : "_ndrw",
        "indices" : [ 1, 7 ],
        "id_str" : "30166922",
        "id" : 30166922
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218043548157755393",
    "text" : ".@_ndrw Everyone needs some form of higher ed. 4 yr university, 2 yr comm college, trade\/ tech\/ voc training. $2B invested in CCs #WHChat",
    "id" : 218043548157755393,
    "created_at" : "2012-06-27 18:10:07 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218044703633977344,
  "created_at" : "2012-06-27 18:14:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Sider Chen",
      "screen_name" : "_ndrw",
      "indices" : [ 3, 9 ],
      "id_str" : "30166922",
      "id" : 30166922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218044689704697856",
  "text" : "RT @_ndrw: #WHChat College affordability is good, but how about support for alternatives to the traditional 4-year college?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "217712323446579200",
    "text" : "#WHChat College affordability is good, but how about support for alternatives to the traditional 4-year college?",
    "id" : 217712323446579200,
    "created_at" : "2012-06-26 20:13:57 +0000",
    "user" : {
      "name" : "Andrew Sider Chen",
      "screen_name" : "_ndrw",
      "protected" : false,
      "id_str" : "30166922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692420329214312448\/1xDY9BUe_normal.jpg",
      "id" : 30166922,
      "verified" : false
    }
  },
  "id" : 218044689704697856,
  "created_at" : "2012-06-27 18:14:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Jodi Kimmelman",
      "screen_name" : "jodikimmelman",
      "indices" : [ 17, 31 ],
      "id_str" : "564982001",
      "id" : 564982001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218044626131632130",
  "text" : "RT @arneduncan: .@jodikimmelman For people that are repaying we have Income Based Repayment available to help you manage debt: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jodi Kimmelman",
        "screen_name" : "jodikimmelman",
        "indices" : [ 1, 15 ],
        "id_str" : "564982001",
        "id" : 564982001
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/37dTclGz",
        "expanded_url" : "http:\/\/wh.gov\/uc1",
        "display_url" : "wh.gov\/uc1"
      } ]
    },
    "geo" : { },
    "id_str" : "218043055905841152",
    "text" : ".@jodikimmelman For people that are repaying we have Income Based Repayment available to help you manage debt: http:\/\/t.co\/37dTclGz #WHChat",
    "id" : 218043055905841152,
    "created_at" : "2012-06-27 18:08:10 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218044626131632130,
  "created_at" : "2012-06-27 18:14:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jodi Kimmelman",
      "screen_name" : "jodikimmelman",
      "indices" : [ 3, 17 ],
      "id_str" : "564982001",
      "id" : 564982001
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218044602484142080",
  "text" : "RT @jodikimmelman: #WHChat. What about former students from 2006-2008 who have fixed 6.8% direct loans?  Any way to get those lowered?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218016102486245378",
    "text" : "#WHChat. What about former students from 2006-2008 who have fixed 6.8% direct loans?  Any way to get those lowered?",
    "id" : 218016102486245378,
    "created_at" : "2012-06-27 16:21:04 +0000",
    "user" : {
      "name" : "Jodi Kimmelman",
      "screen_name" : "jodikimmelman",
      "protected" : false,
      "id_str" : "564982001",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2173158769\/image_normal.jpg",
      "id" : 564982001,
      "verified" : false
    }
  },
  "id" : 218044602484142080,
  "created_at" : "2012-06-27 18:14:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 23, 34 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/c3LJjm8V",
      "expanded_url" : "http:\/\/twitpic.com\/a16vzx",
      "display_url" : "twitpic.com\/a16vzx"
    } ]
  },
  "geo" : { },
  "id_str" : "218044045958713344",
  "text" : "RT @usedgov: Secretary @arneduncan answering your college affordability Qs during #WHchat Office Hours  http:\/\/t.co\/c3LJjm8V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 10, 21 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/c3LJjm8V",
        "expanded_url" : "http:\/\/twitpic.com\/a16vzx",
        "display_url" : "twitpic.com\/a16vzx"
      } ]
    },
    "geo" : { },
    "id_str" : "218043323930263552",
    "text" : "Secretary @arneduncan answering your college affordability Qs during #WHchat Office Hours  http:\/\/t.co\/c3LJjm8V",
    "id" : 218043323930263552,
    "created_at" : "2012-06-27 18:09:14 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 218044045958713344,
  "created_at" : "2012-06-27 18:12:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Sharon Reshef",
      "screen_name" : "sresh24",
      "indices" : [ 16, 24 ],
      "id_str" : "296427866",
      "id" : 296427866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218043343735758848",
  "text" : "RT @arneduncan: @sresh24 Congress needs to get the short term fix done this wk, then immediately move toward a long term solution #DontD ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sharon Reshef",
        "screen_name" : "sresh24",
        "indices" : [ 0, 8 ],
        "id_str" : "296427866",
        "id" : 296427866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 114, 131 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "218039124937019392",
    "geo" : { },
    "id_str" : "218042678477201408",
    "in_reply_to_user_id" : 296427866,
    "text" : "@sresh24 Congress needs to get the short term fix done this wk, then immediately move toward a long term solution #DontDoubleMyRate #WHChat",
    "id" : 218042678477201408,
    "in_reply_to_status_id" : 218039124937019392,
    "created_at" : "2012-06-27 18:06:40 +0000",
    "in_reply_to_screen_name" : "sresh24",
    "in_reply_to_user_id_str" : "296427866",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218043343735758848,
  "created_at" : "2012-06-27 18:09:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon Reshef",
      "screen_name" : "sresh24",
      "indices" : [ 3, 11 ],
      "id_str" : "296427866",
      "id" : 296427866
    }, {
      "name" : "Campus Progress?",
      "screen_name" : "CampusProgress",
      "indices" : [ 13, 28 ],
      "id_str" : "1619348222",
      "id" : 1619348222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 115, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218043313352228864",
  "text" : "RT @sresh24: @campusprogress What are the administration's long-term plans for keeping Stafford rates low? #WHchat #DontDoubleMyRate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Campus Progress?",
        "screen_name" : "CampusProgress",
        "indices" : [ 0, 15 ],
        "id_str" : "1619348222",
        "id" : 1619348222
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 94, 101 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 102, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218039124937019392",
    "in_reply_to_user_id" : 20463418,
    "text" : "@campusprogress What are the administration's long-term plans for keeping Stafford rates low? #WHchat #DontDoubleMyRate",
    "id" : 218039124937019392,
    "created_at" : "2012-06-27 17:52:33 +0000",
    "in_reply_to_screen_name" : "genprogress",
    "in_reply_to_user_id_str" : "20463418",
    "user" : {
      "name" : "Sharon Reshef",
      "screen_name" : "sresh24",
      "protected" : false,
      "id_str" : "296427866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462740279980605440\/OcNyNupQ_normal.jpeg",
      "id" : 296427866,
      "verified" : false
    }
  },
  "id" : 218043313352228864,
  "created_at" : "2012-06-27 18:09:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "WTU Local 6",
      "screen_name" : "WTUTeacher",
      "indices" : [ 16, 27 ],
      "id_str" : "335339014",
      "id" : 335339014
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RTT",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218042557635100672",
  "text" : "RT @arneduncan: @WTUTeacher We will put out #RTT district level competition -- Urban, suburban &amp; rural districts encouraged to apply ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WTU Local 6",
        "screen_name" : "WTUTeacher",
        "indices" : [ 0, 11 ],
        "id_str" : "335339014",
        "id" : 335339014
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RTT",
        "indices" : [ 28, 32 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 136, 143 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "218040672865894400",
    "geo" : { },
    "id_str" : "218042352198103041",
    "in_reply_to_user_id" : 335339014,
    "text" : "@WTUTeacher We will put out #RTT district level competition -- Urban, suburban &amp; rural districts encouraged to apply. $390M in July #WHChat",
    "id" : 218042352198103041,
    "in_reply_to_status_id" : 218040672865894400,
    "created_at" : "2012-06-27 18:05:22 +0000",
    "in_reply_to_screen_name" : "WTUTeacher",
    "in_reply_to_user_id_str" : "335339014",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 218042557635100672,
  "created_at" : "2012-06-27 18:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WTU Local 6",
      "screen_name" : "WTUTeacher",
      "indices" : [ 3, 14 ],
      "id_str" : "335339014",
      "id" : 335339014
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 104, 115 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218042357264826368",
  "text" : "RT @WTUTeacher: What is the administration planning to do to support students in urban schools? #whchat @arneduncan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 88, 99 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 80, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "218040672865894400",
    "text" : "What is the administration planning to do to support students in urban schools? #whchat @arneduncan",
    "id" : 218040672865894400,
    "created_at" : "2012-06-27 17:58:42 +0000",
    "user" : {
      "name" : "WTU Local 6",
      "screen_name" : "WTUTeacher",
      "protected" : false,
      "id_str" : "335339014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2599330460\/m5tehszo9jf4dezfcz7r_normal.jpeg",
      "id" : 335339014,
      "verified" : false
    }
  },
  "id" : 218042357264826368,
  "created_at" : "2012-06-27 18:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218041752286801920",
  "text" : "RT @arneduncan: Hey - I'm here everyone, ready to answer your Qs on college affordability. Ask w\/ #WHChat -Arne",
  "id" : 218041752286801920,
  "created_at" : "2012-06-27 18:02:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 22, 33 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 137, 144 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218040145943867392",
  "text" : "Starting soon: Ed Sec @ArneDuncan answers your questions on college affordability &amp; education. Ask now w\/ #WHChat &amp; follow along @WHLive",
  "id" : 218040145943867392,
  "created_at" : "2012-06-27 17:56:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 29, 40 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 111, 118 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/5Bg4vAdR",
      "expanded_url" : "http:\/\/on.wh.gov\/uLah",
      "display_url" : "on.wh.gov\/uLah"
    } ]
  },
  "geo" : { },
  "id_str" : "218002075576041472",
  "text" : "Today at 2 ET: Education Sec @ArneDuncan answers your Qs on college affordability. Ask w\/ #WHChat follow along @WHLive http:\/\/t.co\/5Bg4vAdR",
  "id" : 218002075576041472,
  "created_at" : "2012-06-27 15:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/217994177198297088\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/AaLxZBie",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwZ4jJdCEAETeVr.jpg",
      "id_str" : "217994177202491393",
      "id" : 217994177202491393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwZ4jJdCEAETeVr.jpg",
      "sizes" : [ {
        "h" : 354,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/AaLxZBie"
    } ],
    "hashtags" : [ {
      "text" : "refinance",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/qTwsJlgK",
      "expanded_url" : "http:\/\/on.wh.gov\/ClsY",
      "display_url" : "on.wh.gov\/ClsY"
    } ]
  },
  "geo" : { },
  "id_str" : "217994177198297088",
  "text" : "President Obama has a plan to help responsible homeowners #refinance. Would you qualify? Find out: http:\/\/t.co\/qTwsJlgK http:\/\/t.co\/AaLxZBie",
  "id" : 217994177198297088,
  "created_at" : "2012-06-27 14:53:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/XI0sXTt6",
      "expanded_url" : "http:\/\/on.wh.gov\/6xqk",
      "display_url" : "on.wh.gov\/6xqk"
    } ]
  },
  "geo" : { },
  "id_str" : "217964946019975168",
  "text" : "#1is2 Many Launches Dating Violence Public Service Announcement. Watch: http:\/\/t.co\/XI0sXTt6",
  "id" : 217964946019975168,
  "created_at" : "2012-06-27 12:57:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/I1DOJPzv",
      "expanded_url" : "http:\/\/on.wh.gov\/GtaB",
      "display_url" : "on.wh.gov\/GtaB"
    } ]
  },
  "geo" : { },
  "id_str" : "217813897938345987",
  "text" : "Would You Qualify for Refi? Find Out: http:\/\/t.co\/I1DOJPzv #MyRefi",
  "id" : 217813897938345987,
  "created_at" : "2012-06-27 02:57:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Governor Pat Quinn",
      "screen_name" : "GovernorQuinn",
      "indices" : [ 118, 132 ],
      "id_str" : "243271477",
      "id" : 243271477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "milspouse",
      "indices" : [ 40, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/4Uf55RJF",
      "expanded_url" : "http:\/\/wh.gov\/ifWx",
      "display_url" : "wh.gov\/ifWx"
    } ]
  },
  "geo" : { },
  "id_str" : "217744976480706560",
  "text" : "RT @JoiningForces: 23 states passed pro #milspouse license portability measures http:\/\/t.co\/4Uf55RJF First Lady &amp; @GovernorQuinn @ s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Governor Pat Quinn",
        "screen_name" : "GovernorQuinn",
        "indices" : [ 99, 113 ],
        "id_str" : "243271477",
        "id" : 243271477
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/217744520014606336\/photo\/1",
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/wC0YdIUO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AwWVfL-CMAQfR7j.jpg",
        "id_str" : "217744520018800644",
        "id" : 217744520018800644,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwWVfL-CMAQfR7j.jpg",
        "sizes" : [ {
          "h" : 698,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 409,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1325,
          "resize" : "fit",
          "w" : 1944
        } ],
        "display_url" : "pic.twitter.com\/wC0YdIUO"
      } ],
      "hashtags" : [ {
        "text" : "milspouse",
        "indices" : [ 21, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/4Uf55RJF",
        "expanded_url" : "http:\/\/wh.gov\/ifWx",
        "display_url" : "wh.gov\/ifWx"
      } ]
    },
    "geo" : { },
    "id_str" : "217744520014606336",
    "text" : "23 states passed pro #milspouse license portability measures http:\/\/t.co\/4Uf55RJF First Lady &amp; @GovernorQuinn @ signing http:\/\/t.co\/wC0YdIUO",
    "id" : 217744520014606336,
    "created_at" : "2012-06-26 22:21:54 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 217744976480706560,
  "created_at" : "2012-06-26 22:23:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/LFTVEz4K",
      "expanded_url" : "http:\/\/on.wh.gov\/r3GI",
      "display_url" : "on.wh.gov\/r3GI"
    } ]
  },
  "geo" : { },
  "id_str" : "217730413681053697",
  "text" : "Seeking your input: Help us shape our strategy for intellectual property enforcement. Submit feedback &amp; learn more: http:\/\/t.co\/LFTVEz4K",
  "id" : 217730413681053697,
  "created_at" : "2012-06-26 21:25:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "NHC Atlantic Ops",
      "screen_name" : "NHC_Atlantic",
      "indices" : [ 90, 103 ],
      "id_str" : "299798272",
      "id" : 299798272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Debby",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/QQKE0mEO",
      "expanded_url" : "http:\/\/www.hurricanes.gov",
      "display_url" : "hurricanes.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "217693954035040257",
  "text" : "RT @fema: June 26: get your #Debby updates where we get ours - the Nat'l Hurricane Center @NHC_Atlantic http:\/\/t.co\/QQKE0mEO http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NHC Atlantic Ops",
        "screen_name" : "NHC_Atlantic",
        "indices" : [ 80, 93 ],
        "id_str" : "299798272",
        "id" : 299798272
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Debby",
        "indices" : [ 18, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/QQKE0mEO",
        "expanded_url" : "http:\/\/www.hurricanes.gov",
        "display_url" : "hurricanes.gov"
      }, {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/QINv82tl",
        "expanded_url" : "http:\/\/hurricanes.gov\/mobile",
        "display_url" : "hurricanes.gov\/mobile"
      } ]
    },
    "geo" : { },
    "id_str" : "217624345516851200",
    "text" : "June 26: get your #Debby updates where we get ours - the Nat'l Hurricane Center @NHC_Atlantic http:\/\/t.co\/QQKE0mEO http:\/\/t.co\/QINv82tl",
    "id" : 217624345516851200,
    "created_at" : "2012-06-26 14:24:21 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 217693954035040257,
  "created_at" : "2012-06-26 19:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoD",
      "indices" : [ 29, 33 ]
    }, {
      "text" : "DoD",
      "indices" : [ 82, 86 ]
    }, {
      "text" : "Pride",
      "indices" : [ 95, 101 ]
    }, {
      "text" : "Pentagon",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217668834801352704",
  "text" : "RT @DeptofDefense: LIVE NOW: #DoD General Counsel Jeh Johnson delivers keynote at #DoD's first #Pride Month event at the #Pentagon. http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoD",
        "indices" : [ 10, 14 ]
      }, {
        "text" : "DoD",
        "indices" : [ 63, 67 ]
      }, {
        "text" : "Pride",
        "indices" : [ 76, 82 ]
      }, {
        "text" : "Pentagon",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/VqnQSg2c",
        "expanded_url" : "http:\/\/defense.gov\/live",
        "display_url" : "defense.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "217664199919288320",
    "text" : "LIVE NOW: #DoD General Counsel Jeh Johnson delivers keynote at #DoD's first #Pride Month event at the #Pentagon. http:\/\/t.co\/VqnQSg2c",
    "id" : 217664199919288320,
    "created_at" : "2012-06-26 17:02:43 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 217668834801352704,
  "created_at" : "2012-06-26 17:21:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U. of New Hampshire",
      "screen_name" : "UofNH",
      "indices" : [ 60, 66 ],
      "id_str" : "262319404",
      "id" : 262319404
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/217662019892019200\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/eUN0sFEu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwVKdDFCAAAsqJz.jpg",
      "id_str" : "217662019900407808",
      "id" : 217662019900407808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwVKdDFCAAAsqJz.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eUN0sFEu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217662019892019200",
  "text" : "Photo of the Day: President Obama enjoys a hot fudge sundae @UofNH's Dairy Bar yesterday in Durham, N.H. http:\/\/t.co\/eUN0sFEu",
  "id" : 217662019892019200,
  "created_at" : "2012-06-26 16:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217634952815194112",
  "text" : "RT @arneduncan: Looking fwd to tomorrow's @whitehouse office hours. Send me your Qs on college affordability using #WHChat http:\/\/t.co\/8 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 26, 37 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/8TGusYf4",
        "expanded_url" : "http:\/\/go.usa.gov\/vs6",
        "display_url" : "go.usa.gov\/vs6"
      } ]
    },
    "geo" : { },
    "id_str" : "217634642612846593",
    "text" : "Looking fwd to tomorrow's @whitehouse office hours. Send me your Qs on college affordability using #WHChat http:\/\/t.co\/8TGusYf4",
    "id" : 217634642612846593,
    "created_at" : "2012-06-26 15:05:16 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 217634952815194112,
  "created_at" : "2012-06-26 15:06:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Transportation",
      "indices" : [ 37, 52 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/vqxQAniE",
      "expanded_url" : "http:\/\/on.wh.gov\/eMiq",
      "display_url" : "on.wh.gov\/eMiq"
    } ]
  },
  "geo" : { },
  "id_str" : "217593320984162304",
  "text" : "Weekly Address: Congress Must Act on #Transportation Bill &amp; Student Loans: http:\/\/t.co\/vqxQAniE #DontDoubleMyRate",
  "id" : 217593320984162304,
  "created_at" : "2012-06-26 12:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U. of New Hampshire",
      "screen_name" : "UofNH",
      "indices" : [ 4, 10 ],
      "id_str" : "262319404",
      "id" : 262319404
    }, {
      "name" : "UNH Dining Services",
      "screen_name" : "UNHDining",
      "indices" : [ 43, 53 ],
      "id_str" : "74488217",
      "id" : 74488217
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 95, 105 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/217409658892201986\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/1gzkQPsj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwRk7tFCMAA_cFz.jpg",
      "id_str" : "217409658896396288",
      "id" : 217409658896396288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwRk7tFCMAA_cFz.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1gzkQPsj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217409658892201986",
  "text" : "\u200FRT @UofNH: President Obama stopped by the @UNHDining Dairy Bar a few minutes ago \/\/ Check out @petesouza's photo: http:\/\/t.co\/1gzkQPsj",
  "id" : 217409658892201986,
  "created_at" : "2012-06-26 00:11:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 47, 58 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/xIPMDPf2",
      "expanded_url" : "http:\/\/on.wh.gov\/H76b",
      "display_url" : "on.wh.gov\/H76b"
    } ]
  },
  "geo" : { },
  "id_str" : "217402716492795904",
  "text" : "Got Qs on college affordability? Education Sec @ArneDuncan answers during WH Office Hours on 6\/27. Ask with #WHChat: http:\/\/t.co\/xIPMDPf2",
  "id" : 217402716492795904,
  "created_at" : "2012-06-25 23:43:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivan Rodriguez",
      "screen_name" : "ivanrdgz",
      "indices" : [ 3, 12 ],
      "id_str" : "69277190",
      "id" : 69277190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217393974837653504",
  "text" : "RT @ivanrdgz: I support it! Find out if President Obama's refinancing plan could help you save hundreds of dollars each month http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyRefi",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/OxDHQvLd",
        "expanded_url" : "http:\/\/wh.gov\/refi",
        "display_url" : "wh.gov\/refi"
      } ]
    },
    "geo" : { },
    "id_str" : "217366951557742594",
    "text" : "I support it! Find out if President Obama's refinancing plan could help you save hundreds of dollars each month http:\/\/t.co\/OxDHQvLd #MyRefi",
    "id" : 217366951557742594,
    "created_at" : "2012-06-25 21:21:34 +0000",
    "user" : {
      "name" : "Ivan Rodriguez",
      "screen_name" : "ivanrdgz",
      "protected" : false,
      "id_str" : "69277190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1079991873\/IvanAvatar_normal.jpg",
      "id" : 69277190,
      "verified" : false
    }
  },
  "id" : 217393974837653504,
  "created_at" : "2012-06-25 23:08:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/RX8UmPgI",
      "expanded_url" : "http:\/\/on.wh.gov\/OOSc",
      "display_url" : "on.wh.gov\/OOSc"
    } ]
  },
  "geo" : { },
  "id_str" : "217334641445707776",
  "text" : "Find out if President Obama's refinancing plan could help you save hundreds of dollars each month: http:\/\/t.co\/RX8UmPgI #MyRefi",
  "id" : 217334641445707776,
  "created_at" : "2012-06-25 19:13:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Crouch",
      "screen_name" : "LindsayCrouch12",
      "indices" : [ 3, 19 ],
      "id_str" : "524059917",
      "id" : 524059917
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 77, 88 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/Vs4bVOlP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "id_str" : "215551607813836801",
      "id" : 215551607813836801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/Vs4bVOlP"
    } ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/sOMHpXLb",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
      "display_url" : "whitehouse.gov\/infographics\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "217313787294908416",
  "text" : "RT @LindsayCrouch12: Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/sOMHpXLb http:\/\/t.co\/Vs4bVOlP #MyRefi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 56, 67 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/Vs4bVOlP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "id_str" : "215551607813836801",
        "id" : 215551607813836801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/Vs4bVOlP"
      } ],
      "hashtags" : [ {
        "text" : "MyRefi",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/sOMHpXLb",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
        "display_url" : "whitehouse.gov\/infographics\/r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "216679391210639361",
    "text" : "Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/sOMHpXLb http:\/\/t.co\/Vs4bVOlP #MyRefi",
    "id" : 216679391210639361,
    "created_at" : "2012-06-23 23:49:27 +0000",
    "user" : {
      "name" : "Lindsay Crouch",
      "screen_name" : "LindsayCrouch12",
      "protected" : false,
      "id_str" : "524059917",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1895868772\/profile_normal.jpg",
      "id" : 524059917,
      "verified" : false
    }
  },
  "id" : 217313787294908416,
  "created_at" : "2012-06-25 17:50:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 84, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/jV2UNoxP",
      "expanded_url" : "http:\/\/on.wh.gov\/Q5LT",
      "display_url" : "on.wh.gov\/Q5LT"
    } ]
  },
  "geo" : { },
  "id_str" : "217242390937870336",
  "text" : "President Obama again pushes Congress to act on student loans: http:\/\/t.co\/jV2UNoxP #DontDoubleMyRate",
  "id" : 217242390937870336,
  "created_at" : "2012-06-25 13:06:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Disabilities",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/eABlZCd9",
      "expanded_url" : "http:\/\/on.wh.gov\/YWNp",
      "display_url" : "on.wh.gov\/YWNp"
    } ]
  },
  "geo" : { },
  "id_str" : "217082045292232704",
  "text" : "On Anniversary of Olmstead, Obama Administration Reaffirms Commitment to Assist Americans with #Disabilities: http:\/\/t.co\/eABlZCd9",
  "id" : 217082045292232704,
  "created_at" : "2012-06-25 02:29:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Morsi",
      "indices" : [ 35, 41 ]
    }, {
      "text" : "Egypt",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/qXTf0xKl",
      "expanded_url" : "http:\/\/wh.gov\/i4Ru",
      "display_url" : "wh.gov\/i4Ru"
    } ]
  },
  "geo" : { },
  "id_str" : "217028741619130368",
  "text" : "President Obama called Dr. Mohamed #Morsi today to congratulate him on his victory in #Egypt\u2019s presidential election: http:\/\/t.co\/qXTf0xKl",
  "id" : 217028741619130368,
  "created_at" : "2012-06-24 22:57:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Transportation",
      "indices" : [ 38, 53 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/J4GojZ1I",
      "expanded_url" : "http:\/\/youtu.be\/jV-PL7Wt754",
      "display_url" : "youtu.be\/jV-PL7Wt754"
    } ]
  },
  "geo" : { },
  "id_str" : "217022145535021056",
  "text" : "President Obama: Congress Must Act on #Transportation Bill &amp; Student Loans: http:\/\/t.co\/J4GojZ1I #DontDoubleMyRate",
  "id" : 217022145535021056,
  "created_at" : "2012-06-24 22:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/a2bKWF92",
      "expanded_url" : "http:\/\/on.wh.gov\/lhoB",
      "display_url" : "on.wh.gov\/lhoB"
    } ]
  },
  "geo" : { },
  "id_str" : "216982741252702211",
  "text" : "Community Colleges Are Changing the Way We Think About Workforce Development: http:\/\/t.co\/a2bKWF92",
  "id" : 216982741252702211,
  "created_at" : "2012-06-24 19:54:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 136, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/6GBTtYjl",
      "expanded_url" : "http:\/\/on.wh.gov\/SXcW",
      "display_url" : "on.wh.gov\/SXcW"
    } ]
  },
  "geo" : { },
  "id_str" : "216877815012929536",
  "text" : "Obama Admin Commemorates 40 Years of Increasing Equality &amp; Opportunity for Women in Education &amp; Athletics: http:\/\/t.co\/6GBTtYjl #TitleIX",
  "id" : 216877815012929536,
  "created_at" : "2012-06-24 12:57:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 16, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/I1J5B3IX",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/cUVllJid",
      "expanded_url" : "http:\/\/on.wh.gov\/fe8l",
      "display_url" : "on.wh.gov\/fe8l"
    } ]
  },
  "geo" : { },
  "id_str" : "216714824980242432",
  "text" : "Weekly Wrap Up: #DontDoubleMyRate &amp; a quick glimpse at what happened this week on http:\/\/t.co\/I1J5B3IX: http:\/\/t.co\/cUVllJid",
  "id" : 216714824980242432,
  "created_at" : "2012-06-24 02:10:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/xwRPWKbt",
      "expanded_url" : "http:\/\/ow.ly\/bMu8s",
      "display_url" : "ow.ly\/bMu8s"
    } ]
  },
  "geo" : { },
  "id_str" : "216666969364103168",
  "text" : "Gene Sperling, Director of the Natl Economic Council, on the battle for #TitleIX &amp; the opportunities it created: http:\/\/t.co\/xwRPWKbt",
  "id" : 216666969364103168,
  "created_at" : "2012-06-23 23:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Katz",
      "screen_name" : "ESPNAndyKatz",
      "indices" : [ 32, 45 ],
      "id_str" : "85961526",
      "id" : 85961526
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/6Jv1Rybl",
      "expanded_url" : "http:\/\/ow.ly\/bMu5E",
      "display_url" : "ow.ly\/bMu5E"
    } ]
  },
  "geo" : { },
  "id_str" : "216636778180919297",
  "text" : "Watch: President Obama talks to @ESPNAndyKatz about the importance of #TitleIX: http:\/\/t.co\/6Jv1Rybl",
  "id" : 216636778180919297,
  "created_at" : "2012-06-23 21:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/216613538897215489\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/sjgCp6NO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwGQ3bDCQAAcspe.jpg",
      "id_str" : "216613538918187008",
      "id" : 216613538918187008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwGQ3bDCQAAcspe.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sjgCp6NO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/z7O1uJDe",
      "expanded_url" : "http:\/\/wh.gov\/loRG#.T-YXkzWagug.twitter",
      "display_url" : "wh.gov\/loRG#.T-YXkzWa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216613538897215489",
  "text" : "President Obama reflects on the impact of Title IX: http:\/\/t.co\/z7O1uJDe Coaches his daughter Sasha\u2019s basketball team: http:\/\/t.co\/sjgCp6NO",
  "id" : 216613538897215489,
  "created_at" : "2012-06-23 19:27:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 77, 88 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/fG5I4UqQ",
      "expanded_url" : "http:\/\/on.wh.gov\/ad4J",
      "display_url" : "on.wh.gov\/ad4J"
    } ]
  },
  "geo" : { },
  "id_str" : "216584479303675905",
  "text" : "President Obama Announces Presidential Delegation to the Opening Ceremony of #London2012 Olympic Games: http:\/\/t.co\/fG5I4UqQ #TeamUSA",
  "id" : 216584479303675905,
  "created_at" : "2012-06-23 17:32:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Newsweek",
      "screen_name" : "Newsweek",
      "indices" : [ 76, 85 ],
      "id_str" : "2884771",
      "id" : 2884771
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/a3nas5Ie",
      "expanded_url" : "http:\/\/www.thedailybeast.com\/newsweek\/2012\/06\/24\/president-obama-reflects-on-the-impact-of-title-ix.html",
      "display_url" : "thedailybeast.com\/newsweek\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216562161814749184",
  "text" : "President Obama Reflects on the Impact of #TitleIX http:\/\/t.co\/a3nas5Ie via @newsweek",
  "id" : 216562161814749184,
  "created_at" : "2012-06-23 16:03:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/irxLawyY",
      "expanded_url" : "http:\/\/on.wh.gov\/JFcS",
      "display_url" : "on.wh.gov\/JFcS"
    } ]
  },
  "geo" : { },
  "id_str" : "216514803177500672",
  "text" : "Alycia-Care: Peace of Mind in Knowing Sick Child Won't be Denied Health Coverage: http:\/\/t.co\/irxLawyY #ACA",
  "id" : 216514803177500672,
  "created_at" : "2012-06-23 12:55:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 96, 103 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/216347479636054016\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/KLhdbDCn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwCe4vACEAIEHVI.jpg",
      "id_str" : "216347479640248322",
      "id" : 216347479640248322,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwCe4vACEAIEHVI.jpg",
      "sizes" : [ {
        "h" : 643,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KLhdbDCn"
    } ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/xzqWnKqA",
      "expanded_url" : "http:\/\/on.wh.gov\/eUMR",
      "display_url" : "on.wh.gov\/eUMR"
    } ]
  },
  "geo" : { },
  "id_str" : "216347479636054016",
  "text" : "Photo Gallery: Women of the Obama Administration &amp; #TitleIX: http:\/\/t.co\/xzqWnKqA Including @HHSGov Sec Sebelius: http:\/\/t.co\/KLhdbDCn",
  "id" : 216347479636054016,
  "created_at" : "2012-06-23 01:50:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/216285675157340161\/photo\/1",
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/UDrilalH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AwBmrPZCQAASbzg.jpg",
      "id_str" : "216285675165728768",
      "id" : 216285675165728768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AwBmrPZCQAASbzg.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UDrilalH"
    } ],
    "hashtags" : [ {
      "text" : "MansBestFriend",
      "indices" : [ 72, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216285675157340161",
  "text" : "Photo of the Day: President Obama pets First Dog Bo in the Oval Office: #MansBestFriend http:\/\/t.co\/UDrilalH",
  "id" : 216285675157340161,
  "created_at" : "2012-06-22 21:44:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 52, 59 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "Tamika Catchings",
      "screen_name" : "Catchin24",
      "indices" : [ 110, 120 ],
      "id_str" : "370435297",
      "id" : 370435297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/JUWaD37L",
      "expanded_url" : "http:\/\/youtu.be\/3Jqj40dybSQ",
      "display_url" : "youtu.be\/3Jqj40dybSQ"
    } ]
  },
  "geo" : { },
  "id_str" : "216278567716265985",
  "text" : "40th Anniversary of #TitleIX &amp; what it means to @HHSGov Sec Sebelius, Pat Summit, Sec Madeleine Albright, @catchin24: http:\/\/t.co\/JUWaD37L",
  "id" : 216278567716265985,
  "created_at" : "2012-06-22 21:16:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216236315052740608",
  "text" : "RT @Interior: Watch Obama Admin officials mix it up w\/ WNBA &amp; college players 2 celebrate the 40th anniversary of #TitleIX http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TitleIX",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/rVFBAb35",
        "expanded_url" : "http:\/\/on.doi.gov\/NsjNm6",
        "display_url" : "on.doi.gov\/NsjNm6"
      } ]
    },
    "geo" : { },
    "id_str" : "216234636190298112",
    "text" : "Watch Obama Admin officials mix it up w\/ WNBA &amp; college players 2 celebrate the 40th anniversary of #TitleIX http:\/\/t.co\/rVFBAb35",
    "id" : 216234636190298112,
    "created_at" : "2012-06-22 18:22:09 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 216236315052740608,
  "created_at" : "2012-06-22 18:28:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NALEO",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216230693922013184",
  "text" : "RT @WHLive: President Obama: I\u2019ve said time and again that if you send me the DREAM Act, I\u2019ll sign it right away.  #NALEO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NALEO",
        "indices" : [ 103, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216230123299549184",
    "text" : "President Obama: I\u2019ve said time and again that if you send me the DREAM Act, I\u2019ll sign it right away.  #NALEO",
    "id" : 216230123299549184,
    "created_at" : "2012-06-22 18:04:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 216230693922013184,
  "created_at" : "2012-06-22 18:06:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216229671434592256",
  "text" : "RT @WHLive: Obama: We announced that we\u2019re lifting the shadow of deportation from deserving young people who were brought here as childr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NALEO",
        "indices" : [ 128, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "216229464726708225",
    "text" : "Obama: We announced that we\u2019re lifting the shadow of deportation from deserving young people who were brought here as children. #NALEO",
    "id" : 216229464726708225,
    "created_at" : "2012-06-22 18:01:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 216229671434592256,
  "created_at" : "2012-06-22 18:02:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216225165762232320",
  "text" : "RT @WHLive: Starting soon: President Obama speaks at the National Assoc of Latino Elected &amp; Appointed Officials' Conf. Watch http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NALEO",
        "indices" : [ 138, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "216224072898576384",
    "text" : "Starting soon: President Obama speaks at the National Assoc of Latino Elected &amp; Appointed Officials' Conf. Watch http:\/\/t.co\/g5icuVZL #NALEO",
    "id" : 216224072898576384,
    "created_at" : "2012-06-22 17:40:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 216225165762232320,
  "created_at" : "2012-06-22 17:44:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard L. Robinson",
      "screen_name" : "Rick70363",
      "indices" : [ 3, 13 ],
      "id_str" : "151330094",
      "id" : 151330094
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 71, 82 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/WOpOtOC9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "id_str" : "215551607813836801",
      "id" : 215551607813836801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/WOpOtOC9"
    } ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/Rwh14p6e",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
      "display_url" : "whitehouse.gov\/infographics\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216220434721554433",
  "text" : "RT @Rick70363: Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/Rwh14p6e http:\/\/t.co\/WOpOtOC9 #MyRefi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 56, 67 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/WOpOtOC9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "id_str" : "215551607813836801",
        "id" : 215551607813836801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/WOpOtOC9"
      } ],
      "hashtags" : [ {
        "text" : "MyRefi",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/Rwh14p6e",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
        "display_url" : "whitehouse.gov\/infographics\/r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "215947238541770754",
    "text" : "Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/Rwh14p6e http:\/\/t.co\/WOpOtOC9 #MyRefi",
    "id" : 215947238541770754,
    "created_at" : "2012-06-21 23:20:08 +0000",
    "user" : {
      "name" : "Richard L. Robinson",
      "screen_name" : "Rick70363",
      "protected" : false,
      "id_str" : "151330094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/487661609473433600\/PjQVv5v6_normal.jpeg",
      "id" : 151330094,
      "verified" : false
    }
  },
  "id" : 216220434721554433,
  "created_at" : "2012-06-22 17:25:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/a1VDryni",
      "expanded_url" : "http:\/\/on.wh.gov\/2OoR",
      "display_url" : "on.wh.gov\/2OoR"
    } ]
  },
  "geo" : { },
  "id_str" : "216213339586576384",
  "text" : "Entrepreneurs &amp; Innovators Rock 3rd Annual Health Datapalooza: http:\/\/t.co\/a1VDryni",
  "id" : 216213339586576384,
  "created_at" : "2012-06-22 16:57:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 59, 71 ]
    }, {
      "text" : "G20",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/bHZyMFgl",
      "expanded_url" : "http:\/\/youtu.be\/r30yYA2K6nU",
      "display_url" : "youtu.be\/r30yYA2K6nU"
    } ]
  },
  "geo" : { },
  "id_str" : "216175221068140544",
  "text" : "Weekly Video Recap: The President talks about an important #immigration policy change, travels to the #G20 &amp; more: http:\/\/t.co\/bHZyMFgl",
  "id" : 216175221068140544,
  "created_at" : "2012-06-22 14:26:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 94, 104 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/216139150875828224\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/wsDC6BzU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av_haZ6CIAEk2PD.jpg",
      "id_str" : "216139150884216833",
      "id" : 216139150884216833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av_haZ6CIAEk2PD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wsDC6BzU"
    } ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/s8PxjXs1",
      "expanded_url" : "http:\/\/on.wh.gov\/SrmH",
      "display_url" : "on.wh.gov\/SrmH"
    } ]
  },
  "geo" : { },
  "id_str" : "216139150875828224",
  "text" : "New Photos: President Obama at the #G20 Summit in Mexico: http:\/\/t.co\/s8PxjXs1 Pres. Obama w\/ @StateDept Sec. Clinton: http:\/\/t.co\/wsDC6BzU",
  "id" : 216139150875828224,
  "created_at" : "2012-06-22 12:02:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/7Bh5jbpg",
      "expanded_url" : "http:\/\/on.wh.gov\/MTWP",
      "display_url" : "on.wh.gov\/MTWP"
    } ]
  },
  "geo" : { },
  "id_str" : "215948090702696448",
  "text" : "#1is2Many Campaign Releases New Public Service Announcement on Dating Violence: http:\/\/t.co\/7Bh5jbpg",
  "id" : 215948090702696448,
  "created_at" : "2012-06-21 23:23:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215938061568192512",
  "text" : "RT @AmbassadorRice: This week, we celebrate the 40th anniversary of #TitleIX and honor women and girls who can bring it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TitleIX",
        "indices" : [ 48, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215631477080199169",
    "text" : "This week, we celebrate the 40th anniversary of #TitleIX and honor women and girls who can bring it.",
    "id" : 215631477080199169,
    "created_at" : "2012-06-21 02:25:25 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 215938061568192512,
  "created_at" : "2012-06-21 22:43:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215889256332271616",
  "text" : "RT @PressSec: If POTUS hadn't focused on it, GOP was prepared to let interest rates double on 7.5 million students. #DontDoubleMyRate.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 102, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215884728581107712",
    "text" : "If POTUS hadn't focused on it, GOP was prepared to let interest rates double on 7.5 million students. #DontDoubleMyRate.",
    "id" : 215884728581107712,
    "created_at" : "2012-06-21 19:11:44 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 215889256332271616,
  "created_at" : "2012-06-21 19:29:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 48, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/xbQwyFbA",
      "expanded_url" : "http:\/\/youtu.be\/lg3kqDfsLFs",
      "display_url" : "youtu.be\/lg3kqDfsLFs"
    } ]
  },
  "geo" : { },
  "id_str" : "215883004340482048",
  "text" : "President Obama: \"If you tweet, use the hashtag #DontDoubleMyRate...Keep it up. Let's get this done.\" http:\/\/t.co\/xbQwyFbA",
  "id" : 215883004340482048,
  "created_at" : "2012-06-21 19:04:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215862307559976960",
  "text" : "Obama: \"If Congress fails to act, more than 7M students will suddenly be hit with the equivalent of a $1,000 tax hike\" #DontDoubleMyRate",
  "id" : 215862307559976960,
  "created_at" : "2012-06-21 17:42:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 100, 107 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 108, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/dfEWfXpi",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "215861116973223936",
  "text" : "Happening now: President Obama Speaks on College Affordability. Watch: http:\/\/t.co\/dfEWfXpi Follow: @WHLive #DontDoubleMyRate",
  "id" : 215861116973223936,
  "created_at" : "2012-06-21 17:37:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "215832825545498626",
  "text" : "RT @WHLive: Happening now: @VP Biden launches new White House PSA about Dating Violence: http:\/\/t.co\/g5icuVZL #1is2Many",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 15, 18 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1is2Many",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "215832723963645952",
    "text" : "Happening now: @VP Biden launches new White House PSA about Dating Violence: http:\/\/t.co\/g5icuVZL #1is2Many",
    "id" : 215832723963645952,
    "created_at" : "2012-06-21 15:45:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 215832825545498626,
  "created_at" : "2012-06-21 15:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/215821520461758464\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/1ZEj9Myc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av7Ah4ZCAAISy_K.jpg",
      "id_str" : "215821520465952770",
      "id" : 215821520465952770,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av7Ah4ZCAAISy_K.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/1ZEj9Myc"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 96, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/ENZD3Yln",
      "expanded_url" : "http:\/\/on.wh.gov\/Ii6P",
      "display_url" : "on.wh.gov\/Ii6P"
    } ]
  },
  "geo" : { },
  "id_str" : "215821520461758464",
  "text" : "Tune in to hear the President on student loans @ 1:40ET, then ask your ?s: http:\/\/t.co\/ENZD3Yln #DontDoubleMyRate http:\/\/t.co\/1ZEj9Myc",
  "id" : 215821520461758464,
  "created_at" : "2012-06-21 15:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPAGov",
      "indices" : [ 71, 78 ],
      "id_str" : "1604108887",
      "id" : 1604108887
    }, {
      "name" : "Lisa P. Jackson",
      "screen_name" : "lisapjackson",
      "indices" : [ 81, 94 ],
      "id_str" : "1182675871",
      "id" : 1182675871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/mzdCXv1M",
      "expanded_url" : "http:\/\/bit.ly\/M9drGF",
      "display_url" : "bit.ly\/M9drGF"
    } ]
  },
  "geo" : { },
  "id_str" : "215811048794628096",
  "text" : "RT @WhiteHouseCEQ: Forum on Youth Sustainability with Chair Sutley and @EPAgov's @lisapjackson starting now at http:\/\/t.co\/mzdCXv1M #USR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EPA",
        "screen_name" : "EPAGov",
        "indices" : [ 52, 59 ],
        "id_str" : "1604108887",
        "id" : 1604108887
      }, {
        "name" : "Lisa P. Jackson",
        "screen_name" : "lisapjackson",
        "indices" : [ 62, 75 ],
        "id_str" : "1182675871",
        "id" : 1182675871
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USRio20",
        "indices" : [ 113, 121 ]
      }, {
        "text" : "RioPlus20",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/mzdCXv1M",
        "expanded_url" : "http:\/\/bit.ly\/M9drGF",
        "display_url" : "bit.ly\/M9drGF"
      } ]
    },
    "geo" : { },
    "id_str" : "215806313094070272",
    "text" : "Forum on Youth Sustainability with Chair Sutley and @EPAgov's @lisapjackson starting now at http:\/\/t.co\/mzdCXv1M #USRio20 #RioPlus20",
    "id" : 215806313094070272,
    "created_at" : "2012-06-21 14:00:09 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 215811048794628096,
  "created_at" : "2012-06-21 14:18:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheri",
      "screen_name" : "chericmeyer",
      "indices" : [ 3, 15 ],
      "id_str" : "92020337",
      "id" : 92020337
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 73, 84 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/A3wv2pi7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "id_str" : "215551607813836801",
      "id" : 215551607813836801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/A3wv2pi7"
    } ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/SnubiIHY",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
      "display_url" : "whitehouse.gov\/infographics\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "215795926797787136",
  "text" : "RT @chericmeyer: Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/SnubiIHY http:\/\/t.co\/A3wv2pi7 #MyRefi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 56, 67 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/A3wv2pi7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "id_str" : "215551607813836801",
        "id" : 215551607813836801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 699,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/A3wv2pi7"
      } ],
      "hashtags" : [ {
        "text" : "MyRefi",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/SnubiIHY",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/refi-five-things",
        "display_url" : "whitehouse.gov\/infographics\/r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "215595800879841281",
    "text" : "Here are 5 things you should know about refinancing via @WhiteHouse http:\/\/t.co\/SnubiIHY http:\/\/t.co\/A3wv2pi7 #MyRefi",
    "id" : 215595800879841281,
    "created_at" : "2012-06-21 00:03:39 +0000",
    "user" : {
      "name" : "Cheri",
      "screen_name" : "chericmeyer",
      "protected" : false,
      "id_str" : "92020337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459452836690927616\/7gFEY5He_normal.jpeg",
      "id" : 92020337,
      "verified" : false
    }
  },
  "id" : 215795926797787136,
  "created_at" : "2012-06-21 13:18:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/CgttJQDG",
      "expanded_url" : "http:\/\/on.wh.gov\/e2QF",
      "display_url" : "on.wh.gov\/e2QF"
    } ]
  },
  "geo" : { },
  "id_str" : "215779770292633600",
  "text" : "The Affordable Care Act helps improve access to high quality, coordinated care: http:\/\/t.co\/CgttJQDG #ACA",
  "id" : 215779770292633600,
  "created_at" : "2012-06-21 12:14:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215586680051220480\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/Z4z9tvNK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3q8XsCQAEEHAG.jpg",
      "id_str" : "215586680055414785",
      "id" : 215586680055414785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3q8XsCQAEEHAG.jpg",
      "sizes" : [ {
        "h" : 673,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1343,
        "resize" : "fit",
        "w" : 2043
      } ],
      "display_url" : "pic.twitter.com\/Z4z9tvNK"
    } ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215586680051220480",
  "text" : "Photo of the Day: People listen backstage during President Obama's press conference at the end of the #G20 Summit: http:\/\/t.co\/Z4z9tvNK",
  "id" : 215586680051220480,
  "created_at" : "2012-06-20 23:27:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215551607805448195\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/Lqt4ZxqP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "id_str" : "215551607813836801",
      "id" : 215551607813836801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Av3LC5aCEAE7NJa.jpg",
      "sizes" : [ {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/Lqt4ZxqP"
    } ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "refinancing",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215551607805448195",
  "text" : "#MyRefi: We all stand to benefit by simplifying #refinancing. 5 things you should know about the President's plan: http:\/\/t.co\/Lqt4ZxqP",
  "id" : 215551607805448195,
  "created_at" : "2012-06-20 21:08:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215546947220672513",
  "text" : "RT @arneduncan: #TitleIX is just 36 words long, yet one of the great education &amp; civil rights success stories of the last 40 yrs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TitleIX",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "215533583031468032",
    "text" : "#TitleIX is just 36 words long, yet one of the great education &amp; civil rights success stories of the last 40 yrs.",
    "id" : 215533583031468032,
    "created_at" : "2012-06-20 19:56:25 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 215546947220672513,
  "created_at" : "2012-06-20 20:49:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Count Income",
      "screen_name" : "billiejking",
      "indices" : [ 51, 63 ],
      "id_str" : "2195603383",
      "id" : 2195603383
    }, {
      "name" : "WNBAPrez",
      "screen_name" : "WNBAPrez",
      "indices" : [ 64, 73 ],
      "id_str" : "4924419310",
      "id" : 4924419310
    }, {
      "name" : "Bonnie Bernstein",
      "screen_name" : "BonnieBernstein",
      "indices" : [ 74, 90 ],
      "id_str" : "129276705",
      "id" : 129276705
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 91, 102 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/hU1vwc2g",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "215511223695970304",
  "text" : "RT @vj44: Watch now! Celebrating #TitleIX event w\/ @BillieJKing @WNBAprez @BonnieBernstein @arneduncan &amp; more http:\/\/t.co\/hU1vwc2g # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Count Income",
        "screen_name" : "billiejking",
        "indices" : [ 41, 53 ],
        "id_str" : "2195603383",
        "id" : 2195603383
      }, {
        "name" : "WNBAPrez",
        "screen_name" : "WNBAPrez",
        "indices" : [ 54, 63 ],
        "id_str" : "4924419310",
        "id" : 4924419310
      }, {
        "name" : "Bonnie Bernstein",
        "screen_name" : "BonnieBernstein",
        "indices" : [ 64, 80 ],
        "id_str" : "129276705",
        "id" : 129276705
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 81, 92 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TitleIX",
        "indices" : [ 23, 31 ]
      }, {
        "text" : "WHTitleIX",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/hU1vwc2g",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "215505253427195904",
    "text" : "Watch now! Celebrating #TitleIX event w\/ @BillieJKing @WNBAprez @BonnieBernstein @arneduncan &amp; more http:\/\/t.co\/hU1vwc2g #WHTitleIX",
    "id" : 215505253427195904,
    "created_at" : "2012-06-20 18:03:50 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 215511223695970304,
  "created_at" : "2012-06-20 18:27:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TitleIX",
      "indices" : [ 52, 60 ]
    }, {
      "text" : "WHTitleIX",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/Sx3wEzu8",
      "expanded_url" : "http:\/\/wh.gov\/lqRE",
      "display_url" : "wh.gov\/lqRE"
    } ]
  },
  "geo" : { },
  "id_str" : "215481154646720513",
  "text" : "RT @vj44: Today we're celebrating the 40th Anniv of #TitleIX. Will you join us? Tune in &amp; discuss @ 2ET: http:\/\/t.co\/Sx3wEzu8 #WHTitleIX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TitleIX",
        "indices" : [ 42, 50 ]
      }, {
        "text" : "WHTitleIX",
        "indices" : [ 120, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/Sx3wEzu8",
        "expanded_url" : "http:\/\/wh.gov\/lqRE",
        "display_url" : "wh.gov\/lqRE"
      } ]
    },
    "geo" : { },
    "id_str" : "215470733772595200",
    "text" : "Today we're celebrating the 40th Anniv of #TitleIX. Will you join us? Tune in &amp; discuss @ 2ET: http:\/\/t.co\/Sx3wEzu8 #WHTitleIX",
    "id" : 215470733772595200,
    "created_at" : "2012-06-20 15:46:40 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 215481154646720513,
  "created_at" : "2012-06-20 16:28:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/yF9whCO9",
      "expanded_url" : "http:\/\/on.wh.gov\/PRrd",
      "display_url" : "on.wh.gov\/PRrd"
    } ]
  },
  "geo" : { },
  "id_str" : "215463354033119233",
  "text" : "From the Archives: The First Lady's Trip to Africa: http:\/\/t.co\/yF9whCO9",
  "id" : 215463354033119233,
  "created_at" : "2012-06-20 15:17:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215242969584902144",
  "text" : "RT @vj44: Women in #G20 Declaration for 1st time. Women cont to be integral part of our natl security &amp; econ agenda. See 23 &amp; 53 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "G20",
        "indices" : [ 9, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 128, 148 ],
        "url" : "http:\/\/t.co\/qbSDDUAZ",
        "expanded_url" : "http:\/\/wh.gov\/lqUF",
        "display_url" : "wh.gov\/lqUF"
      } ]
    },
    "geo" : { },
    "id_str" : "215241766587215872",
    "text" : "Women in #G20 Declaration for 1st time. Women cont to be integral part of our natl security &amp; econ agenda. See 23 &amp; 53: http:\/\/t.co\/qbSDDUAZ",
    "id" : 215241766587215872,
    "created_at" : "2012-06-20 00:36:50 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 215242969584902144,
  "created_at" : "2012-06-20 00:41:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 34, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/QDIlfhBu",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "215230286600994816",
  "text" : "Watch live: President Obama holds #G20 press conference in Los Cabos, Mexico: http:\/\/t.co\/QDIlfhBu",
  "id" : 215230286600994816,
  "created_at" : "2012-06-19 23:51:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/215203286150680577\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/n3NcaqAH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AvyOP6HCEAE0qD-.jpg",
      "id_str" : "215203286154874881",
      "id" : 215203286154874881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvyOP6HCEAE0qD-.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n3NcaqAH"
    } ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215203286150680577",
  "text" : "Photo of the Day: President Obama talks with Chief of Staff Jack Lew while in Mexico for the #G20 Summit http:\/\/t.co\/n3NcaqAH",
  "id" : 215203286150680577,
  "created_at" : "2012-06-19 22:03:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 17, 25 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhyRefi",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/DyR1QymI",
      "expanded_url" : "http:\/\/WH.gov\/whyrefi",
      "display_url" : "WH.gov\/whyrefi"
    } ]
  },
  "geo" : { },
  "id_str" : "215189545786937344",
  "text" : "RT @vj44: Talked @HUDNews w\/ Atlanta's Ed Jennings, who asked about highlighting stories. We are! http:\/\/t.co\/DyR1QymI #WhyRefi http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUD News | not",
        "screen_name" : "HUDNews",
        "indices" : [ 7, 15 ],
        "id_str" : "1881201980",
        "id" : 1881201980
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/215183115763724288\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/tHRIoW2k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Avx751kCMAEBXkn.jpg",
        "id_str" : "215183115767918593",
        "id" : 215183115767918593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Avx751kCMAEBXkn.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/tHRIoW2k"
      } ],
      "hashtags" : [ {
        "text" : "WhyRefi",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/DyR1QymI",
        "expanded_url" : "http:\/\/WH.gov\/whyrefi",
        "display_url" : "WH.gov\/whyrefi"
      } ]
    },
    "geo" : { },
    "id_str" : "215183115763724288",
    "text" : "Talked @HUDNews w\/ Atlanta's Ed Jennings, who asked about highlighting stories. We are! http:\/\/t.co\/DyR1QymI #WhyRefi http:\/\/t.co\/tHRIoW2k",
    "id" : 215183115763724288,
    "created_at" : "2012-06-19 20:43:48 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 215189545786937344,
  "created_at" : "2012-06-19 21:09:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhyRefi",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/KycOigvW",
      "expanded_url" : "http:\/\/youtu.be\/u_yYoWyoKRI",
      "display_url" : "youtu.be\/u_yYoWyoKRI"
    } ]
  },
  "geo" : { },
  "id_str" : "215168563907010561",
  "text" : "Is your home underwater? The President has a plan that could help you refinance &amp; save money. #WhyRefi  Learn more: http:\/\/t.co\/KycOigvW",
  "id" : 215168563907010561,
  "created_at" : "2012-06-19 19:45:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 26, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "215144755263311872",
  "text" : "RT @HHSGov: Thanks to the #ACA, \u201CNow I don\u2019t have to worry about lifetime limits or pre-existing conditions,\" says Ashley. http:\/\/t.co\/B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 14, 18 ]
      }, {
        "text" : "MyCare",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/BoGhx4a4",
        "expanded_url" : "http:\/\/go.usa.gov\/vke",
        "display_url" : "go.usa.gov\/vke"
      } ]
    },
    "geo" : { },
    "id_str" : "215135566398894081",
    "text" : "Thanks to the #ACA, \u201CNow I don\u2019t have to worry about lifetime limits or pre-existing conditions,\" says Ashley. http:\/\/t.co\/BoGhx4a4 #MyCare",
    "id" : 215135566398894081,
    "created_at" : "2012-06-19 17:34:50 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 215144755263311872,
  "created_at" : "2012-06-19 18:11:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhyRefi",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/9cJT0Y9w",
      "expanded_url" : "http:\/\/youtu.be\/q_QQWI_BniM",
      "display_url" : "youtu.be\/q_QQWI_BniM"
    } ]
  },
  "geo" : { },
  "id_str" : "215121658405593089",
  "text" : "How much will the President\u2019s refinance plan cost taxpayers? Watch to find out. Have more Q\u2019s? Ask us with #WhyRefi http:\/\/t.co\/9cJT0Y9w",
  "id" : 215121658405593089,
  "created_at" : "2012-06-19 16:39:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/214870169305092096\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/hJnEouap",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AvtfR9LCEAAOqJb.jpg",
      "id_str" : "214870169313480704",
      "id" : 214870169313480704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvtfR9LCEAAOqJb.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/hJnEouap"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/I06TGrjC",
      "expanded_url" : "http:\/\/wh.gov\/performances\/gershwin-prize-paul-mccartney",
      "display_url" : "wh.gov\/performances\/g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214870169305092096",
  "text" : "Happy Birthday, Paul McCartney! Watch him perform \u201CHey Jude\u201D at the WH &amp; receive Gershwin Prize: http:\/\/t.co\/I06TGrjC http:\/\/t.co\/hJnEouap",
  "id" : 214870169305092096,
  "created_at" : "2012-06-19 00:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/6d6CNidI",
      "expanded_url" : "http:\/\/youtu.be\/XR35yRKDxck",
      "display_url" : "youtu.be\/XR35yRKDxck"
    } ]
  },
  "geo" : { },
  "id_str" : "214812818996871168",
  "text" : "\"The Rhodes Ahead\": Ben Rhodes, deputy natl security advisor, previews President Obama's trip to the #G20. Watch: http:\/\/t.co\/6d6CNidI",
  "id" : 214812818996871168,
  "created_at" : "2012-06-18 20:12:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214756741802491904",
  "text" : "RT @pfeiffer44: In Mexico for the G20, Pres Obama just met with Mexican President Calderon, meets with President Putin a little later th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214753060008890368",
    "text" : "In Mexico for the G20, Pres Obama just met with Mexican President Calderon, meets with President Putin a little later this morning",
    "id" : 214753060008890368,
    "created_at" : "2012-06-18 16:14:54 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 214756741802491904,
  "created_at" : "2012-06-18 16:29:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhyRefi",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/ClShuco8",
      "expanded_url" : "http:\/\/ow.ly\/bEs22",
      "display_url" : "ow.ly\/bEs22"
    } ]
  },
  "geo" : { },
  "id_str" : "214741249285033984",
  "text" : "Got a minute? Watch: On the Clock: Explaining Refinance in 60 Seconds (Or Less): http:\/\/t.co\/ClShuco8 #WhyRefi",
  "id" : 214741249285033984,
  "created_at" : "2012-06-18 15:27:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/214529043360522240\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/MDOoPXRD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AvopBz_CIAIydiv.jpg",
      "id_str" : "214529043364716546",
      "id" : 214529043364716546,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvopBz_CIAIydiv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/MDOoPXRD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/CcWAMEnU",
      "expanded_url" : "http:\/\/on.wh.gov\/LeCg",
      "display_url" : "on.wh.gov\/LeCg"
    } ]
  },
  "geo" : { },
  "id_str" : "214529043360522240",
  "text" : "By the Numbers: $3,000 http:\/\/t.co\/CcWAMEnU On average, homeowners who refinance under Obama's plan will save $3k\/year: http:\/\/t.co\/MDOoPXRD",
  "id" : 214529043360522240,
  "created_at" : "2012-06-18 01:24:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US National Archives",
      "screen_name" : "USNatArchives",
      "indices" : [ 54, 68 ],
      "id_str" : "101802390",
      "id" : 101802390
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/214513451270291456\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/SQTIUbcq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Avoa2O8CQAI2XPg.jpg",
      "id_str" : "214513451278680066",
      "id" : 214513451278680066,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Avoa2O8CQAI2XPg.jpg",
      "sizes" : [ {
        "h" : 504,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 325
      } ],
      "display_url" : "pic.twitter.com\/SQTIUbcq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/oHkFV6Uk",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/06\/15\/archives-presidents-fathers",
      "display_url" : "whitehouse.gov\/blog\/2012\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "214513451270291456",
  "text" : "Happy Father's Day! Photos: Presidents as Fathers via @USNatArchives http:\/\/t.co\/oHkFV6Uk President Obama &amp; daughters: http:\/\/t.co\/SQTIUbcq",
  "id" : 214513451270291456,
  "created_at" : "2012-06-18 00:22:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214507660731613187",
  "text" : "RT @arneduncan: Today, and every day, we need a lot more fathers to be actively engaged in their children's lives.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "214447750836793345",
    "text" : "Today, and every day, we need a lot more fathers to be actively engaged in their children's lives.",
    "id" : 214447750836793345,
    "created_at" : "2012-06-17 20:01:42 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 214507660731613187,
  "created_at" : "2012-06-17 23:59:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Immigration",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/iCPko5ct",
      "expanded_url" : "http:\/\/on.wh.gov\/r2h6",
      "display_url" : "on.wh.gov\/r2h6"
    } ]
  },
  "geo" : { },
  "id_str" : "214433497249611776",
  "text" : "Deferred Action Process for Certain Young People: Smart and Sensible #Immigration Policy: http:\/\/t.co\/iCPko5ct",
  "id" : 214433497249611776,
  "created_at" : "2012-06-17 19:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214429497863323648",
  "text" : "RT @vj44: Happy Father's Day to all! Obama Admin is committed to promoting responsible fatherhood &amp; healthy families. New report: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/ka3crNdS",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/06\/15\/promoting-responsible-fatherhood-and-healthy-families",
        "display_url" : "whitehouse.gov\/blog\/2012\/06\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "214427899690889217",
    "text" : "Happy Father's Day to all! Obama Admin is committed to promoting responsible fatherhood &amp; healthy families. New report: http:\/\/t.co\/ka3crNdS",
    "id" : 214427899690889217,
    "created_at" : "2012-06-17 18:42:49 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 214429497863323648,
  "created_at" : "2012-06-17 18:49:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/Y5HML4cr",
      "expanded_url" : "http:\/\/ow.ly\/bDiTg",
      "display_url" : "ow.ly\/bDiTg"
    } ]
  },
  "geo" : { },
  "id_str" : "214420852551323649",
  "text" : "\"On Father's Day, we honor the men whose compassion &amp; commitment have...guided us toward brighter horizons\" -Pres Obama http:\/\/t.co\/Y5HML4cr",
  "id" : 214420852551323649,
  "created_at" : "2012-06-17 18:14:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/5HHyIJk8",
      "expanded_url" : "http:\/\/on.wh.gov\/ZwH0",
      "display_url" : "on.wh.gov\/ZwH0"
    } ]
  },
  "geo" : { },
  "id_str" : "214326628233396224",
  "text" : "New Photo Gallery: Behind the Scenes in May 2012: http:\/\/t.co\/5HHyIJk8",
  "id" : 214326628233396224,
  "created_at" : "2012-06-17 12:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 88, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214139053484949504",
  "text" : "RT @letsmove: Just 1 day left to submit a healthy lunch recipe for a chance to attend a #KidsStateDinner at the WH. Get cooking! http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 74, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/5Mez34jc",
        "expanded_url" : "http:\/\/ow.ly\/bvA4t",
        "display_url" : "ow.ly\/bvA4t"
      } ]
    },
    "geo" : { },
    "id_str" : "214138419482337283",
    "text" : "Just 1 day left to submit a healthy lunch recipe for a chance to attend a #KidsStateDinner at the WH. Get cooking! http:\/\/t.co\/5Mez34jc",
    "id" : 214138419482337283,
    "created_at" : "2012-06-16 23:32:32 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 214139053484949504,
  "created_at" : "2012-06-16 23:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/qthgVaQx",
      "expanded_url" : "http:\/\/on.wh.gov\/8hv6",
      "display_url" : "on.wh.gov\/8hv6"
    } ]
  },
  "geo" : { },
  "id_str" : "214123530953043968",
  "text" : "Photo gallery from the Archives: Presidents as Fathers: http:\/\/t.co\/qthgVaQx",
  "id" : 214123530953043968,
  "created_at" : "2012-06-16 22:33:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/SQ68EKO8",
      "expanded_url" : "http:\/\/ow.ly\/bCFY9",
      "display_url" : "ow.ly\/bCFY9"
    } ]
  },
  "geo" : { },
  "id_str" : "214062318038949888",
  "text" : "\"Every problem we face is within our power to solve. What\u2019s lacking is our politics.\" -President Obama. Weekly Address: http:\/\/t.co\/SQ68EKO8",
  "id" : 214062318038949888,
  "created_at" : "2012-06-16 18:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/1AXMAlGC",
      "expanded_url" : "http:\/\/ow.ly\/bCFD8",
      "display_url" : "ow.ly\/bCFD8"
    } ]
  },
  "geo" : { },
  "id_str" : "214028305597349889",
  "text" : "Weekly Address: President Obama tells the American people that the stalemate in Washington is holding our economy back: http:\/\/t.co\/1AXMAlGC",
  "id" : 214028305597349889,
  "created_at" : "2012-06-16 16:14:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 58, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/uJrpySQJ",
      "expanded_url" : "http:\/\/youtu.be\/6RXSlMu5EDI",
      "display_url" : "youtu.be\/6RXSlMu5EDI"
    } ]
  },
  "geo" : { },
  "id_str" : "213970621535760384",
  "text" : "President Obama: New Admin action will make \"our nation's #immigration policy more fair, more efficient &amp; more just\" http:\/\/t.co\/uJrpySQJ",
  "id" : 213970621535760384,
  "created_at" : "2012-06-16 12:25:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/fWalWDx7",
      "expanded_url" : "http:\/\/on.wh.gov\/yYJ8",
      "display_url" : "on.wh.gov\/yYJ8"
    } ]
  },
  "geo" : { },
  "id_str" : "213827012249403393",
  "text" : "West Wing Week: 6\/15\/2012 or \"The Fatherhood Buzz\" http:\/\/t.co\/fWalWDx7",
  "id" : 213827012249403393,
  "created_at" : "2012-06-16 02:55:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 122, 130 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/gWApyJYC",
      "expanded_url" : "http:\/\/on.wh.gov\/mqFz",
      "display_url" : "on.wh.gov\/mqFz"
    } ]
  },
  "geo" : { },
  "id_str" : "213776289885204481",
  "text" : "Your Response: President Obama speaks on #immigration &amp; people around the country speak out: http:\/\/t.co\/gWApyJYC via @storify",
  "id" : 213776289885204481,
  "created_at" : "2012-06-15 23:33:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "213742187857448961",
  "text" : "Happening now: President Obama hosts a reception to observe #LGBT Pride Month at the White House. Watch: http:\/\/t.co\/u95tzH8r",
  "id" : 213742187857448961,
  "created_at" : "2012-06-15 21:18:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Immigration",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/uJrpySQJ",
      "expanded_url" : "http:\/\/youtu.be\/6RXSlMu5EDI",
      "display_url" : "youtu.be\/6RXSlMu5EDI"
    } ]
  },
  "geo" : { },
  "id_str" : "213707482642661379",
  "text" : "Watch: President Obama speaks on Department of Homeland Security #Immigration Announcement: http:\/\/t.co\/uJrpySQJ",
  "id" : 213707482642661379,
  "created_at" : "2012-06-15 19:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Marianne \u0622\u0631\u0632\u0648",
      "screen_name" : "Mwforhr",
      "indices" : [ 13, 21 ],
      "id_str" : "22819351",
      "id" : 22819351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/c3xfJYRa",
      "expanded_url" : "http:\/\/1.usa.gov\/MbQYp3",
      "display_url" : "1.usa.gov\/MbQYp3"
    } ]
  },
  "geo" : { },
  "id_str" : "213702423527702528",
  "text" : "RT @WHLive: .@Mwforhr check out DHS press release for more info http:\/\/t.co\/c3xfJYRa #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marianne \u0622\u0631\u0632\u0648",
        "screen_name" : "Mwforhr",
        "indices" : [ 1, 9 ],
        "id_str" : "22819351",
        "id" : 22819351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/c3xfJYRa",
        "expanded_url" : "http:\/\/1.usa.gov\/MbQYp3",
        "display_url" : "1.usa.gov\/MbQYp3"
      } ]
    },
    "geo" : { },
    "id_str" : "213699876817600513",
    "text" : ".@Mwforhr check out DHS press release for more info http:\/\/t.co\/c3xfJYRa #whchat",
    "id" : 213699876817600513,
    "created_at" : "2012-06-15 18:29:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 213702423527702528,
  "created_at" : "2012-06-15 18:40:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne \u0622\u0631\u0632\u0648",
      "screen_name" : "Mwforhr",
      "indices" : [ 3, 11 ],
      "id_str" : "22819351",
      "id" : 22819351
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 13, 20 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 21, 28 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213702407266377728",
  "text" : "RT @Mwforhr: @WHLive @DHSgov #WHChat Is there a website to learn more about this policy?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 0, 7 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "Homeland Security",
        "screen_name" : "DHSgov",
        "indices" : [ 8, 15 ],
        "id_str" : "15647676",
        "id" : 15647676
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 16, 23 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "213697976093249536",
    "geo" : { },
    "id_str" : "213698471914504192",
    "in_reply_to_user_id" : 369505837,
    "text" : "@WHLive @DHSgov #WHChat Is there a website to learn more about this policy?",
    "id" : 213698471914504192,
    "in_reply_to_status_id" : 213697976093249536,
    "created_at" : "2012-06-15 18:24:20 +0000",
    "in_reply_to_screen_name" : "WHLive",
    "in_reply_to_user_id_str" : "369505837",
    "user" : {
      "name" : "Marianne \u0622\u0631\u0632\u0648",
      "screen_name" : "Mwforhr",
      "protected" : false,
      "id_str" : "22819351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796452581111431168\/f-N7DwuJ_normal.jpg",
      "id" : 22819351,
      "verified" : false
    }
  },
  "id" : 213702407266377728,
  "created_at" : "2012-06-15 18:39:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213696353891647489",
  "text" : "RT @WHLive: President Obama: \"We still need to pass comprehensive #immigration reform that addresses our 21st century economic and secur ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 54, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213696186899632128",
    "text" : "President Obama: \"We still need to pass comprehensive #immigration reform that addresses our 21st century economic and security needs\"",
    "id" : 213696186899632128,
    "created_at" : "2012-06-15 18:15:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 213696353891647489,
  "created_at" : "2012-06-15 18:15:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213696324300836865",
  "text" : "RT @WHLive: Obama: Effective immediately, the Department of Homeland Security is taking steps to lift the shadow of deportation from the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213695908007780354",
    "text" : "Obama: Effective immediately, the Department of Homeland Security is taking steps to lift the shadow of deportation from these young people",
    "id" : 213695908007780354,
    "created_at" : "2012-06-15 18:14:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 213696324300836865,
  "created_at" : "2012-06-15 18:15:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 41, 48 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 49, 61 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 134, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/9UY1hevc",
      "expanded_url" : "http:\/\/on.wh.gov\/c5hp",
      "display_url" : "on.wh.gov\/c5hp"
    } ]
  },
  "geo" : { },
  "id_str" : "213694795590270978",
  "text" : "Happening now: President Obama speaks on @DHSgov #immigration announcement. Watch live: http:\/\/t.co\/9UY1hevc &amp; ask questions with #WHChat",
  "id" : 213694795590270978,
  "created_at" : "2012-06-15 18:09:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTreasuryDept",
      "screen_name" : "USTreasuryDept",
      "indices" : [ 58, 73 ],
      "id_str" : "2484739350",
      "id" : 2484739350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213663762538967040",
  "text" : "RT @Brundage44: Today @ noon, Ben Rhodes, Mike Froman and @USTreasuryDept Lael Brainard hold briefing on POTUS travel to G20 tune in at  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USTreasuryDept",
        "screen_name" : "USTreasuryDept",
        "indices" : [ 42, 57 ],
        "id_str" : "2484739350",
        "id" : 2484739350
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/wzlIuoJS",
        "expanded_url" : "http:\/\/1.usa.gov\/UT2FE",
        "display_url" : "1.usa.gov\/UT2FE"
      } ]
    },
    "geo" : { },
    "id_str" : "213649195255607296",
    "text" : "Today @ noon, Ben Rhodes, Mike Froman and @USTreasuryDept Lael Brainard hold briefing on POTUS travel to G20 tune in at http:\/\/t.co\/wzlIuoJS",
    "id" : 213649195255607296,
    "created_at" : "2012-06-15 15:08:32 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 213663762538967040,
  "created_at" : "2012-06-15 16:06:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 69, 81 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213660910613565440",
  "text" : "RT @WHLive: Today at 1:15 ET President Obama delivers a statement on #immigration. Have Q\u2019s?  Join the Q&amp;A at 2 ET. Ask w\/ #WHChat h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 57, 69 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/s2f4X6zi",
        "expanded_url" : "http:\/\/wh.gov\/lqaJ",
        "display_url" : "wh.gov\/lqaJ"
      } ]
    },
    "geo" : { },
    "id_str" : "213660837053874177",
    "text" : "Today at 1:15 ET President Obama delivers a statement on #immigration. Have Q\u2019s?  Join the Q&amp;A at 2 ET. Ask w\/ #WHChat http:\/\/t.co\/s2f4X6zi",
    "id" : 213660837053874177,
    "created_at" : "2012-06-15 15:54:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 213660910613565440,
  "created_at" : "2012-06-15 15:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213650881948827649",
  "text" : "RT @OMBPress: Imp. study: 91.6% of stories alleging gov't policy = \u201Cjob killer\u201D failed to cite any evidence for this claim: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "regs",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/6s3HRxSZ",
        "expanded_url" : "http:\/\/ht.ly\/bBvs3",
        "display_url" : "ht.ly\/bBvs3"
      } ]
    },
    "geo" : { },
    "id_str" : "213647864361000960",
    "text" : "Imp. study: 91.6% of stories alleging gov't policy = \u201Cjob killer\u201D failed to cite any evidence for this claim: http:\/\/t.co\/6s3HRxSZ #regs",
    "id" : 213647864361000960,
    "created_at" : "2012-06-15 15:03:14 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 213650881948827649,
  "created_at" : "2012-06-15 15:15:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 39, 46 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 47, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "213637720143179776",
  "text" : "President Obama speaks at 1:15ET about @dhsgov #immigration announcement. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 213637720143179776,
  "created_at" : "2012-06-15 14:22:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 3, 10 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213633777631641601",
  "text" : "RT @DHSgov: Secretary Napolitano Announces Deferred Action Process for Young People Who Are Low Enforcement Priorities #immigration http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 107, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/UDnNkVor",
        "expanded_url" : "http:\/\/www.dhs.gov\/ynews\/releases\/20120612-napolitano-announces-deferred-action-process-for-young-people.shtm",
        "display_url" : "dhs.gov\/ynews\/releases\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "213632390415912962",
    "text" : "Secretary Napolitano Announces Deferred Action Process for Young People Who Are Low Enforcement Priorities #immigration http:\/\/t.co\/UDnNkVor",
    "id" : 213632390415912962,
    "created_at" : "2012-06-15 14:01:45 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 213633777631641601,
  "created_at" : "2012-06-15 14:07:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/nmkJ4CV3",
      "expanded_url" : "http:\/\/on.wh.gov\/H9TB",
      "display_url" : "on.wh.gov\/H9TB"
    } ]
  },
  "geo" : { },
  "id_str" : "213608918507732992",
  "text" : "We Can't Wait: President Obama Signs Executive Order to Make Broadband Construction Faster and Cheaper http:\/\/t.co\/nmkJ4CV3",
  "id" : 213608918507732992,
  "created_at" : "2012-06-15 12:28:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/213412630575071233\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/kRwANeAe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AvYxqCSCQAAok71.jpg",
      "id_str" : "213412630583459840",
      "id" : 213412630583459840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvYxqCSCQAAok71.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kRwANeAe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/hLG10tzT",
      "expanded_url" : "http:\/\/on.wh.gov\/pIwP",
      "display_url" : "on.wh.gov\/pIwP"
    } ]
  },
  "geo" : { },
  "id_str" : "213412630575071233",
  "text" : "Happy Flag Day: 96 years ago, our Nation first came together to celebrate Flag Day: http:\/\/t.co\/hLG10tzT http:\/\/t.co\/kRwANeAe",
  "id" : 213412630575071233,
  "created_at" : "2012-06-14 23:28:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USArmy",
      "indices" : [ 23, 30 ]
    }, {
      "text" : "ArmyBDay",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213412622484250626",
  "text" : "RT @USArmy: Today, the #USArmy celebrates 237 years of service to our great nation. #ArmyBDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USArmy",
        "indices" : [ 11, 18 ]
      }, {
        "text" : "ArmyBDay",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213231718029725696",
    "text" : "Today, the #USArmy celebrates 237 years of service to our great nation. #ArmyBDay",
    "id" : 213231718029725696,
    "created_at" : "2012-06-14 11:29:37 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 213412622484250626,
  "created_at" : "2012-06-14 23:28:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shimon Peres",
      "screen_name" : "PresidentPeres",
      "indices" : [ 54, 69 ],
      "id_str" : "406255275",
      "id" : 406255275
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 27, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/mjkaH8Aj",
      "expanded_url" : "http:\/\/on.wh.gov\/YQKF",
      "display_url" : "on.wh.gov\/YQKF"
    } ]
  },
  "geo" : { },
  "id_str" : "213298227523489792",
  "text" : "President Obama awards the #MedalOfFreedom to Israeli @PresidentPeres. Watch: http:\/\/t.co\/mjkaH8Aj",
  "id" : 213298227523489792,
  "created_at" : "2012-06-14 15:53:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213295713730297856",
  "text" : "RT @WHLive: Today at 1:30 pm EDT: Join our Q&amp;A on the President\u2019s plan to help homeowners refinance.  Ask your Q now w\/ #WHChat: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 141 ],
        "url" : "http:\/\/t.co\/ClaRpfr4",
        "expanded_url" : "http:\/\/wh.gov\/hu6",
        "display_url" : "wh.gov\/hu6"
      } ]
    },
    "geo" : { },
    "id_str" : "213284496055861248",
    "text" : "Today at 1:30 pm EDT: Join our Q&amp;A on the President\u2019s plan to help homeowners refinance.  Ask your Q now w\/ #WHChat: http:\/\/t.co\/ClaRpfr4",
    "id" : 213284496055861248,
    "created_at" : "2012-06-14 14:59:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 213295713730297856,
  "created_at" : "2012-06-14 15:43:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/kZOOBzzl",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "213273801960591361",
  "text" : "RT @HHSGov: Happening now: event on protecting seniors from abuse &amp; financial exploitation watch live http:\/\/t.co\/kZOOBzzl &amp; ask ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ProtectSeniors",
        "indices" : [ 131, 146 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/kZOOBzzl",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "213273505314246656",
    "text" : "Happening now: event on protecting seniors from abuse &amp; financial exploitation watch live http:\/\/t.co\/kZOOBzzl &amp; ask Qs w\/ #ProtectSeniors",
    "id" : 213273505314246656,
    "created_at" : "2012-06-14 14:15:40 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 213273801960591361,
  "created_at" : "2012-06-14 14:16:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobsPlus",
      "indices" : [ 73, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/M37vhHAy",
      "expanded_url" : "http:\/\/on.wh.gov\/wRKn",
      "display_url" : "on.wh.gov\/wRKn"
    } ]
  },
  "geo" : { },
  "id_str" : "213237786449420288",
  "text" : "Watch: Actress Betty White discusses her first job: http:\/\/t.co\/M37vhHAy #SummerJobsPlus",
  "id" : 213237786449420288,
  "created_at" : "2012-06-14 11:53:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shimon Peres",
      "screen_name" : "PresidentPeres",
      "indices" : [ 45, 60 ],
      "id_str" : "406255275",
      "id" : 406255275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/Cz7991fw",
      "expanded_url" : "http:\/\/on.wh.gov\/LKfT",
      "display_url" : "on.wh.gov\/LKfT"
    } ]
  },
  "geo" : { },
  "id_str" : "213045944307027968",
  "text" : "Watch live at 7:10ET: President Obama awards @PresidentPeres the Presidential Medal of Freedom: http:\/\/t.co\/Cz7991fw",
  "id" : 213045944307027968,
  "created_at" : "2012-06-13 23:11:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shimon Peres",
      "screen_name" : "PresidentPeres",
      "indices" : [ 3, 18 ],
      "id_str" : "406255275",
      "id" : 406255275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/RZH17fMX",
      "expanded_url" : "http:\/\/instagr.am\/p\/L1CIW1Rq2s\/",
      "display_url" : "instagr.am\/p\/L1CIW1Rq2s\/"
    }, {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/g9P9szS7",
      "expanded_url" : "http:\/\/fb.me\/1OU4PqRE9",
      "display_url" : "fb.me\/1OU4PqRE9"
    } ]
  },
  "geo" : { },
  "id_str" : "213043240117616640",
  "text" : "RT @PresidentPeres: Getting ready to the Presidential Medal of Freedom ceremony http:\/\/t.co\/RZH17fMX http:\/\/t.co\/g9P9szS7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/RZH17fMX",
        "expanded_url" : "http:\/\/instagr.am\/p\/L1CIW1Rq2s\/",
        "display_url" : "instagr.am\/p\/L1CIW1Rq2s\/"
      }, {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/g9P9szS7",
        "expanded_url" : "http:\/\/fb.me\/1OU4PqRE9",
        "display_url" : "fb.me\/1OU4PqRE9"
      } ]
    },
    "geo" : { },
    "id_str" : "213021125008031744",
    "text" : "Getting ready to the Presidential Medal of Freedom ceremony http:\/\/t.co\/RZH17fMX http:\/\/t.co\/g9P9szS7",
    "id" : 213021125008031744,
    "created_at" : "2012-06-13 21:32:48 +0000",
    "user" : {
      "name" : "Shimon Peres",
      "screen_name" : "PresidentPeres",
      "protected" : false,
      "id_str" : "406255275",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781016662753632257\/JGvySZI2_normal.jpg",
      "id" : 406255275,
      "verified" : true
    }
  },
  "id" : 213043240117616640,
  "created_at" : "2012-06-13 23:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "213041312432263168",
  "text" : "RT @vj44: Today the President honored Father's Day early w\/ other dads @ DC's Kenny's BBQ; talked about importance of fatherhood: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/213036734664015872\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/miYHpkvL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AvTbyA5CAAA3YXn.jpg",
        "id_str" : "213036734672404480",
        "id" : 213036734672404480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvTbyA5CAAA3YXn.jpg",
        "sizes" : [ {
          "h" : 1353,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 396,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 677,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/miYHpkvL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "213036734664015872",
    "text" : "Today the President honored Father's Day early w\/ other dads @ DC's Kenny's BBQ; talked about importance of fatherhood: http:\/\/t.co\/miYHpkvL",
    "id" : 213036734664015872,
    "created_at" : "2012-06-13 22:34:51 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 213041312432263168,
  "created_at" : "2012-06-13 22:53:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/0HsZWHa1",
      "expanded_url" : "http:\/\/on.wh.gov\/FNvy",
      "display_url" : "on.wh.gov\/FNvy"
    }, {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/jWrWDS1r",
      "expanded_url" : "http:\/\/on.wh.gov\/Dz1Y",
      "display_url" : "on.wh.gov\/Dz1Y"
    } ]
  },
  "geo" : { },
  "id_str" : "213023781562748928",
  "text" : "Americans speak out in favor of mortgage relief: http:\/\/t.co\/0HsZWHa1 Will you join them? http:\/\/t.co\/jWrWDS1r",
  "id" : 213023781562748928,
  "created_at" : "2012-06-13 21:43:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/YnzGsfqJ",
      "expanded_url" : "http:\/\/on.wh.gov\/HZ3w",
      "display_url" : "on.wh.gov\/HZ3w"
    } ]
  },
  "geo" : { },
  "id_str" : "213002035086376963",
  "text" : "Have questions on the President's plan to help homeowners refinance? Ask now w\/ #WHChat &amp; join Office Hours on 6\/14: http:\/\/t.co\/YnzGsfqJ",
  "id" : 213002035086376963,
  "created_at" : "2012-06-13 20:16:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212997816308600832",
  "text" : "RT @vj44: Congrats to today's WH Champions of Change! 10 people doing amazing work to promote responsible fatherhood: http:\/\/t.co\/1CVWOE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChamps",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/1CVWOEs2",
        "expanded_url" : "http:\/\/wh.gov\/champions",
        "display_url" : "wh.gov\/champions"
      } ]
    },
    "geo" : { },
    "id_str" : "212997501064712194",
    "text" : "Congrats to today's WH Champions of Change! 10 people doing amazing work to promote responsible fatherhood: http:\/\/t.co\/1CVWOEs2 #WHChamps",
    "id" : 212997501064712194,
    "created_at" : "2012-06-13 19:58:56 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 212997816308600832,
  "created_at" : "2012-06-13 20:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212990890732564481",
  "text" : "RT @whitehouseostp: We Can\u2019t Wait: President Obama Signs Executive Order to Make Broadband Construction Faster and Cheaper http:\/\/t.co\/m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USIgnite",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/mX3mDiLS",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/06\/13\/we-can-t-wait-president-obama-signs-executive-order-make-broadband-const",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "212987058963222531",
    "text" : "We Can\u2019t Wait: President Obama Signs Executive Order to Make Broadband Construction Faster and Cheaper http:\/\/t.co\/mX3mDiLS #USIgnite",
    "id" : 212987058963222531,
    "created_at" : "2012-06-13 19:17:26 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 212990890732564481,
  "created_at" : "2012-06-13 19:32:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 3, 13 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/OanR4ODZ",
      "expanded_url" : "http:\/\/1.usa.gov\/KazDT2",
      "display_url" : "1.usa.gov\/KazDT2"
    } ]
  },
  "geo" : { },
  "id_str" : "212967242474860547",
  "text" : "RT @todd_park: Deadline to apply to be a Presidential Innovation Fellow is this Friday 6\/15. Get your application in at http:\/\/t.co\/OanR4ODZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/OanR4ODZ",
        "expanded_url" : "http:\/\/1.usa.gov\/KazDT2",
        "display_url" : "1.usa.gov\/KazDT2"
      } ]
    },
    "geo" : { },
    "id_str" : "212956778789474304",
    "text" : "Deadline to apply to be a Presidential Innovation Fellow is this Friday 6\/15. Get your application in at http:\/\/t.co\/OanR4ODZ",
    "id" : 212956778789474304,
    "created_at" : "2012-06-13 17:17:07 +0000",
    "user" : {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "protected" : false,
      "id_str" : "200176600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140157375\/toddpark_normal.jpg",
      "id" : 200176600,
      "verified" : false
    }
  },
  "id" : 212967242474860547,
  "created_at" : "2012-06-13 17:58:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/2n0nwcwF",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "212955098798759936",
  "text" : "RT @JonCarson44: Happening now: Champions of Change honoring fatherhood is starting now. Tune-in: http:\/\/t.co\/2n0nwcwF #WHChamps",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChamps",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/2n0nwcwF",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "212954790290927617",
    "text" : "Happening now: Champions of Change honoring fatherhood is starting now. Tune-in: http:\/\/t.co\/2n0nwcwF #WHChamps",
    "id" : 212954790290927617,
    "created_at" : "2012-06-13 17:09:13 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 212955098798759936,
  "created_at" : "2012-06-13 17:10:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212886740803919875",
  "text" : "RT @pfeiffer44: Economic advisers Gene Sperling and Jason Furman respond to the recent Federal Reserve study on consumer finances http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/zYYVtesq",
        "expanded_url" : "http:\/\/1.usa.gov\/KBcepZ",
        "display_url" : "1.usa.gov\/KBcepZ"
      } ]
    },
    "geo" : { },
    "id_str" : "212866424018972672",
    "text" : "Economic advisers Gene Sperling and Jason Furman respond to the recent Federal Reserve study on consumer finances http:\/\/t.co\/zYYVtesq",
    "id" : 212866424018972672,
    "created_at" : "2012-06-13 11:18:05 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 212886740803919875,
  "created_at" : "2012-06-13 12:38:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/3laX2hJn",
      "expanded_url" : "http:\/\/on.wh.gov\/wV6C",
      "display_url" : "on.wh.gov\/wV6C"
    } ]
  },
  "geo" : { },
  "id_str" : "212878187850498048",
  "text" : "White House Rural Council Celebrates Its One Year Anniversary: http:\/\/t.co\/3laX2hJn",
  "id" : 212878187850498048,
  "created_at" : "2012-06-13 12:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhyRefi",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/xQsn4W3l",
      "expanded_url" : "http:\/\/on.wh.gov\/3C7c",
      "display_url" : "on.wh.gov\/3C7c"
    } ]
  },
  "geo" : { },
  "id_str" : "212709625970167808",
  "text" : "We asked #WhyRefi; 20,000 of you responded: \"Being able to refinance while underwater will keep people in their homes\" http:\/\/t.co\/xQsn4W3l",
  "id" : 212709625970167808,
  "created_at" : "2012-06-13 00:55:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/iuBECZAZ",
      "expanded_url" : "http:\/\/bit.ly\/KqXi2f",
      "display_url" : "bit.ly\/KqXi2f"
    } ]
  },
  "geo" : { },
  "id_str" : "212655864266502145",
  "text" : "RT @petesouza: New behind the scenes photos of Pres Obama from May: http:\/\/t.co\/iuBECZAZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/iuBECZAZ",
        "expanded_url" : "http:\/\/bit.ly\/KqXi2f",
        "display_url" : "bit.ly\/KqXi2f"
      } ]
    },
    "geo" : { },
    "id_str" : "212638010020343808",
    "text" : "New behind the scenes photos of Pres Obama from May: http:\/\/t.co\/iuBECZAZ",
    "id" : 212638010020343808,
    "created_at" : "2012-06-12 20:10:26 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 212655864266502145,
  "created_at" : "2012-06-12 21:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/212633290094546944\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/hsB9hsTi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AvNs2cwCEAEJKV2.jpg",
      "id_str" : "212633290102935553",
      "id" : 212633290102935553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvNs2cwCEAEJKV2.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 182
      }, {
        "h" : 3647,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 321
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 548
      } ],
      "display_url" : "pic.twitter.com\/hsB9hsTi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/MtEZTrVW",
      "expanded_url" : "http:\/\/on.wh.gov\/s5oK",
      "display_url" : "on.wh.gov\/s5oK"
    } ]
  },
  "geo" : { },
  "id_str" : "212633290094546944",
  "text" : "Infographic: How Refinancing Can Help Families: See full size: http:\/\/t.co\/MtEZTrVW &amp; twitter size: http:\/\/t.co\/hsB9hsTi",
  "id" : 212633290094546944,
  "created_at" : "2012-06-12 19:51:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betty White",
      "screen_name" : "BettyMWhite",
      "indices" : [ 45, 57 ],
      "id_str" : "544517731",
      "id" : 544517731
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/212560356986458112\/photo\/1",
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/WW90ofFD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AvMqhLvCEAIui_u.jpg",
      "id_str" : "212560356990652418",
      "id" : 212560356990652418,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvMqhLvCEAIui_u.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WW90ofFD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212560356986458112",
  "text" : "Photo of the Day: President Obama talks with @BettyMWhite in the Oval Office: http:\/\/t.co\/WW90ofFD",
  "id" : 212560356986458112,
  "created_at" : "2012-06-12 15:01:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 77, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/Y1UVaSFC",
      "expanded_url" : "http:\/\/on.wh.gov\/9n5Z",
      "display_url" : "on.wh.gov\/9n5Z"
    } ]
  },
  "geo" : { },
  "id_str" : "212541576818339840",
  "text" : "Give responsible homeowners a chance to refinance at a lower rate (2 of 5 on #CongressToDoList): http:\/\/t.co\/Y1UVaSFC",
  "id" : 212541576818339840,
  "created_at" : "2012-06-12 13:47:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IBR",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/LURalviM",
      "expanded_url" : "http:\/\/on.wh.gov\/WQ6I",
      "display_url" : "on.wh.gov\/WQ6I"
    } ]
  },
  "geo" : { },
  "id_str" : "212385111927300096",
  "text" : "Income Based Repayment: Everything You Need to Know: http:\/\/t.co\/LURalviM #IBR",
  "id" : 212385111927300096,
  "created_at" : "2012-06-12 03:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/212346492936142849\/photo\/1",
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/BEKZ2uhm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AvJoAqFCQAAUgm0.jpg",
      "id_str" : "212346492944531456",
      "id" : 212346492944531456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvJoAqFCQAAUgm0.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BEKZ2uhm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "212346492936142849",
  "text" : "Photo of the Day: President Obama is briefed by staff in the Oval Office: http:\/\/t.co\/BEKZ2uhm",
  "id" : 212346492936142849,
  "created_at" : "2012-06-12 00:52:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/KR0elK2u",
      "expanded_url" : "http:\/\/on.wh.gov\/6x1B",
      "display_url" : "on.wh.gov\/6x1B"
    } ]
  },
  "geo" : { },
  "id_str" : "212306283490062336",
  "text" : "Weekly Address: Congress Must Act to Keep Our Teachers on the Job: http:\/\/t.co\/KR0elK2u",
  "id" : 212306283490062336,
  "created_at" : "2012-06-11 22:12:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/Ofpj10LQ",
      "expanded_url" : "http:\/\/on.wh.gov\/OkhL",
      "display_url" : "on.wh.gov\/OkhL"
    } ]
  },
  "geo" : { },
  "id_str" : "212264736857931778",
  "text" : "President Obama: \"In today's economy, the best predictor of success is a good education\" Watch: http:\/\/t.co\/Ofpj10LQ",
  "id" : 212264736857931778,
  "created_at" : "2012-06-11 19:27:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Val Young",
      "screen_name" : "vwyoung",
      "indices" : [ 3, 11 ],
      "id_str" : "29779519",
      "id" : 29779519
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 80, 91 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/nVvRZalB",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/women-entrepreneurs-jobs-timeline?utm_source=061112&utm_medium=topper&utm_campaign=daily",
      "display_url" : "whitehouse.gov\/women-entrepre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "212216561044430850",
  "text" : "RT @vwyoung: Check out this great graphic re women entrepreneurs (thanks to the @whitehouse) http:\/\/t.co\/nVvRZalB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 67, 78 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/nVvRZalB",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/women-entrepreneurs-jobs-timeline?utm_source=061112&utm_medium=topper&utm_campaign=daily",
        "display_url" : "whitehouse.gov\/women-entrepre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "212205683574185984",
    "text" : "Check out this great graphic re women entrepreneurs (thanks to the @whitehouse) http:\/\/t.co\/nVvRZalB",
    "id" : 212205683574185984,
    "created_at" : "2012-06-11 15:32:32 +0000",
    "user" : {
      "name" : "Val Young",
      "screen_name" : "vwyoung",
      "protected" : false,
      "id_str" : "29779519",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759075313565388800\/qGEFV4IH_normal.jpg",
      "id" : 29779519,
      "verified" : false
    }
  },
  "id" : 212216561044430850,
  "created_at" : "2012-06-11 16:15:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New York Giants",
      "screen_name" : "Giants",
      "indices" : [ 28, 35 ],
      "id_str" : "240734425",
      "id" : 240734425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Aq9U8cmz",
      "expanded_url" : "http:\/\/on.wh.gov\/7LG4",
      "display_url" : "on.wh.gov\/7LG4"
    } ]
  },
  "geo" : { },
  "id_str" : "212189088743292930",
  "text" : "President Obama welcomes NY @Giants to the White House: http:\/\/t.co\/Aq9U8cmz",
  "id" : 212189088743292930,
  "created_at" : "2012-06-11 14:26:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SeniorsHealth",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/Yby3Dhn9",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "212185076379811840",
  "text" : "RT @HealthCareGov: Happening NOW: Seniors Health Town Hall streaming live from the White House: http:\/\/t.co\/Yby3Dhn9 #SeniorsHealth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SeniorsHealth",
        "indices" : [ 98, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/Yby3Dhn9",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "212184427122536449",
    "text" : "Happening NOW: Seniors Health Town Hall streaming live from the White House: http:\/\/t.co\/Yby3Dhn9 #SeniorsHealth",
    "id" : 212184427122536449,
    "created_at" : "2012-06-11 14:08:04 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 212185076379811840,
  "created_at" : "2012-06-11 14:10:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 62, 72 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/zNbqRH4v",
      "expanded_url" : "http:\/\/on.wh.gov\/5NG2",
      "display_url" : "on.wh.gov\/5NG2"
    } ]
  },
  "geo" : { },
  "id_str" : "211556934158004224",
  "text" : "Watch: Go behind-the-scenes at Health Datapalooza with US CTO @Todd_Park: http:\/\/t.co\/zNbqRH4v",
  "id" : 211556934158004224,
  "created_at" : "2012-06-09 20:34:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/ZNvNGx4u",
      "expanded_url" : "http:\/\/youtu.be\/gBtM9Rkni2k",
      "display_url" : "youtu.be\/gBtM9Rkni2k"
    } ]
  },
  "geo" : { },
  "id_str" : "211490877741342720",
  "text" : "\"Join me in telling Congress\u2026 to get to work and to help get our teachers back in the classroom.\" - President Obama http:\/\/t.co\/ZNvNGx4u",
  "id" : 211490877741342720,
  "created_at" : "2012-06-09 16:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/uDBHwz19",
      "expanded_url" : "http:\/\/on.wh.gov\/YuAP",
      "display_url" : "on.wh.gov\/YuAP"
    } ]
  },
  "geo" : { },
  "id_str" : "211446074525749248",
  "text" : "Vice President Discusses College Affordability with College &amp; University Officials:  http:\/\/t.co\/uDBHwz19",
  "id" : 211446074525749248,
  "created_at" : "2012-06-09 13:14:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/PiGBNx19",
      "expanded_url" : "http:\/\/on.wh.gov\/3oHK",
      "display_url" : "on.wh.gov\/3oHK"
    } ]
  },
  "geo" : { },
  "id_str" : "211288848897019904",
  "text" : "President Obama discusses the state of the economy in the White House Briefing Room: http:\/\/t.co\/PiGBNx19",
  "id" : 211288848897019904,
  "created_at" : "2012-06-09 02:49:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New York Giants",
      "screen_name" : "Giants",
      "indices" : [ 3, 10 ],
      "id_str" : "240734425",
      "id" : 240734425
    }, {
      "name" : "New York Giants",
      "screen_name" : "Giants",
      "indices" : [ 71, 78 ],
      "id_str" : "240734425",
      "id" : 240734425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/etJLGdCH",
      "expanded_url" : "https:\/\/twitter.com\/Giants\/status\/211172972386463744\/photo\/1",
      "display_url" : "pic.twitter.com\/etJLGdCH"
    } ]
  },
  "geo" : { },
  "id_str" : "211229132523188224",
  "text" : "RT @Giants: President Obama welcomes your Super Bowl Champion New York @giants! http:\/\/t.co\/etJLGdCH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New York Giants",
        "screen_name" : "Giants",
        "indices" : [ 59, 66 ],
        "id_str" : "240734425",
        "id" : 240734425
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/etJLGdCH",
        "expanded_url" : "https:\/\/twitter.com\/Giants\/status\/211172972386463744\/photo\/1",
        "display_url" : "pic.twitter.com\/etJLGdCH"
      } ]
    },
    "geo" : { },
    "id_str" : "211172972386463744",
    "text" : "President Obama welcomes your Super Bowl Champion New York @giants! http:\/\/t.co\/etJLGdCH",
    "id" : 211172972386463744,
    "created_at" : "2012-06-08 19:08:55 +0000",
    "user" : {
      "name" : "New York Giants",
      "screen_name" : "Giants",
      "protected" : false,
      "id_str" : "240734425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793819656553394181\/fCi1l2qD_normal.jpg",
      "id" : 240734425,
      "verified" : true
    }
  },
  "id" : 211229132523188224,
  "created_at" : "2012-06-08 22:52:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/211211135846858752\/photo\/1",
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/9iwfIkkk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Au5faLVCQAAwyOP.jpg",
      "id_str" : "211211135855247360",
      "id" : 211211135855247360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Au5faLVCQAAwyOP.jpg",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 635,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1192,
        "resize" : "fit",
        "w" : 1922
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9iwfIkkk"
    } ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 94, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211211135846858752",
  "text" : "Photo of the Day: Pres Obama waves to the crowd after speaking on college affordability &amp; #DontDoubleMyRate at UNLV: http:\/\/t.co\/9iwfIkkk",
  "id" : 211211135846858752,
  "created_at" : "2012-06-08 21:40:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211203352153948164",
  "text" : "RT @jesseclee44: New study: 6.6 Million young adults have insurance on their parents' plan thanks to health care law #hcr http:\/\/t.co\/GL ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 100, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/GL6TcMQs",
        "expanded_url" : "http:\/\/goo.gl\/c6JXu",
        "display_url" : "goo.gl\/c6JXu"
      } ]
    },
    "geo" : { },
    "id_str" : "211084685609140224",
    "text" : "New study: 6.6 Million young adults have insurance on their parents' plan thanks to health care law #hcr http:\/\/t.co\/GL6TcMQs",
    "id" : 211084685609140224,
    "created_at" : "2012-06-08 13:18:05 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 211203352153948164,
  "created_at" : "2012-06-08 21:09:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Girl Scouts",
      "screen_name" : "girlscouts",
      "indices" : [ 33, 44 ],
      "id_str" : "103018203",
      "id" : 103018203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211182476486393857",
  "text" : "RT @vj44: The President just met @GirlScouts Gold Award winners in the Oval; 8 remarkable young women, more than 59M alums: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Girl Scouts",
        "screen_name" : "girlscouts",
        "indices" : [ 23, 34 ],
        "id_str" : "103018203",
        "id" : 103018203
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/qvcn5IEu",
        "expanded_url" : "http:\/\/flic.kr\/p\/ccEPjQ",
        "display_url" : "flic.kr\/p\/ccEPjQ"
      } ]
    },
    "geo" : { },
    "id_str" : "211179547087998976",
    "text" : "The President just met @GirlScouts Gold Award winners in the Oval; 8 remarkable young women, more than 59M alums: http:\/\/t.co\/qvcn5IEu",
    "id" : 211179547087998976,
    "created_at" : "2012-06-08 19:35:02 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 211182476486393857,
  "created_at" : "2012-06-08 19:46:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/dbisP0PB",
      "expanded_url" : "http:\/\/on.wh.gov\/42Gj",
      "display_url" : "on.wh.gov\/42Gj"
    } ]
  },
  "geo" : { },
  "id_str" : "211172081159774209",
  "text" : "Happening now: President Obama honors the Super Bowl XLVI Champion New York Giants. Watch live: http:\/\/t.co\/dbisP0PB",
  "id" : 211172081159774209,
  "created_at" : "2012-06-08 19:05:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/JpOQfoim",
      "expanded_url" : "http:\/\/on.wh.gov\/U6ZF",
      "display_url" : "on.wh.gov\/U6ZF"
    } ]
  },
  "geo" : { },
  "id_str" : "211159203711156227",
  "text" : "West Wing Week: 06\/08\/2012 or \"Roll Up Our Sleeves and Never Quit\" http:\/\/t.co\/JpOQfoim",
  "id" : 211159203711156227,
  "created_at" : "2012-06-08 18:14:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Girl Scouts",
      "screen_name" : "girlscouts",
      "indices" : [ 47, 58 ],
      "id_str" : "103018203",
      "id" : 103018203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211130367355265024",
  "text" : "RT @vj44: Today the President meets w\/ amazing @GirlScouts to thank them for their service to America &amp; congratulates them on their  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Girl Scouts",
        "screen_name" : "girlscouts",
        "indices" : [ 37, 48 ],
        "id_str" : "103018203",
        "id" : 103018203
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211129146288517120",
    "text" : "Today the President meets w\/ amazing @GirlScouts to thank them for their service to America &amp; congratulates them on their 100th anniversary!",
    "id" : 211129146288517120,
    "created_at" : "2012-06-08 16:14:45 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 211130367355265024,
  "created_at" : "2012-06-08 16:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211106292109021186",
  "text" : "RT @WHLive: Obama: \"given signs of weakness in the world economy, it is critical that we take the actions we can to strengthen the Ameri ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "211106242016444416",
    "text" : "Obama: \"given signs of weakness in the world economy, it is critical that we take the actions we can to strengthen the American economy\"",
    "id" : 211106242016444416,
    "created_at" : "2012-06-08 14:43:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 211106292109021186,
  "created_at" : "2012-06-08 14:43:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/9M73HRKY",
      "expanded_url" : "http:\/\/on.wh.gov\/dPzW",
      "display_url" : "on.wh.gov\/dPzW"
    } ]
  },
  "geo" : { },
  "id_str" : "211105220686655488",
  "text" : "Happening now: President Obama delivers a statement on the economy in the Press Briefing Room. Watch live: http:\/\/t.co\/9M73HRKY",
  "id" : 211105220686655488,
  "created_at" : "2012-06-08 14:39:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/lwvrVUIu",
      "expanded_url" : "http:\/\/on.wh.gov\/94CK",
      "display_url" : "on.wh.gov\/94CK"
    } ]
  },
  "geo" : { },
  "id_str" : "211081762703540224",
  "text" : "Happening at 10:15ET: President Obama delivers a statement on the economy in Press Briefing Room. Watch live: http:\/\/t.co\/lwvrVUIu",
  "id" : 211081762703540224,
  "created_at" : "2012-06-08 13:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DiamondJubilee",
      "indices" : [ 56, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/S2gpCTUG",
      "expanded_url" : "http:\/\/on.wh.gov\/gY9p",
      "display_url" : "on.wh.gov\/gY9p"
    } ]
  },
  "geo" : { },
  "id_str" : "211076586051600385",
  "text" : "Watch: President Obama honors Queen Elizabeth II on her #DiamondJubilee: http:\/\/t.co\/S2gpCTUG",
  "id" : 211076586051600385,
  "created_at" : "2012-06-08 12:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/9VNhTLmr",
      "expanded_url" : "http:\/\/on.wh.gov\/DdN6",
      "display_url" : "on.wh.gov\/DdN6"
    } ]
  },
  "geo" : { },
  "id_str" : "210937969496952832",
  "text" : "Celebrating Jewish History at the White House: http:\/\/t.co\/9VNhTLmr",
  "id" : 210937969496952832,
  "created_at" : "2012-06-08 03:35:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210876773431390208",
  "text" : "RT @macon44: \"... reducing personal debt and spurring consumer spending are both very good for this or any other economy.\" http:\/\/t.co\/P ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whyrefi",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/PrC6UjPk",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/06\/07\/why-refi-you-tell-us",
        "display_url" : "whitehouse.gov\/blog\/2012\/06\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "210846066130698242",
    "text" : "\"... reducing personal debt and spurring consumer spending are both very good for this or any other economy.\" http:\/\/t.co\/PrC6UjPk #whyrefi",
    "id" : 210846066130698242,
    "created_at" : "2012-06-07 21:29:54 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 210876773431390208,
  "created_at" : "2012-06-07 23:31:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhyRefi",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/1Dp0gO1s",
      "expanded_url" : "http:\/\/on.wh.gov\/GDow",
      "display_url" : "on.wh.gov\/GDow"
    } ]
  },
  "geo" : { },
  "id_str" : "210853707171119104",
  "text" : "#WhyRefi: \"If I had an extra few $100\/mo I'd definitely be spending more &amp; putting that $ back into the economy\" http:\/\/t.co\/1Dp0gO1s",
  "id" : 210853707171119104,
  "created_at" : "2012-06-07 22:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/210834306757689344\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/ar8ZMQpS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Au0Ir1lCAAA4XHi.jpg",
      "id_str" : "210834306766077952",
      "id" : 210834306766077952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Au0Ir1lCAAA4XHi.jpg",
      "sizes" : [ {
        "h" : 1456,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 853,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1941,
        "resize" : "fit",
        "w" : 1365
      } ],
      "display_url" : "pic.twitter.com\/ar8ZMQpS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210834306757689344",
  "text" : "Photo of the Day: President Obama talks on the phone with Prime Minister Monti of Italy aboard Air Force One: http:\/\/t.co\/ar8ZMQpS",
  "id" : 210834306757689344,
  "created_at" : "2012-06-07 20:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IBR",
      "indices" : [ 120, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "210826588298805248",
  "text" : "RT @WHLive: Happening now: President Obama speaks on college affordability from UNLV - watch live: http:\/\/t.co\/g5icuVZL #IBR #DontDouble ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IBR",
        "indices" : [ 108, 112 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 113, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "210825987745775616",
    "text" : "Happening now: President Obama speaks on college affordability from UNLV - watch live: http:\/\/t.co\/g5icuVZL #IBR #DontDoubleMyRate",
    "id" : 210825987745775616,
    "created_at" : "2012-06-07 20:10:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 210826588298805248,
  "created_at" : "2012-06-07 20:12:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IBR",
      "indices" : [ 36, 40 ]
    }, {
      "text" : "DontDoubleMyRate",
      "indices" : [ 47, 64 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 145 ],
      "url" : "http:\/\/t.co\/mBJCl60r",
      "expanded_url" : "http:\/\/on.wh.gov\/EzxC",
      "display_url" : "on.wh.gov\/EzxC"
    } ]
  },
  "geo" : { },
  "id_str" : "210788968718016512",
  "text" : "Have ?s about college affordability #IBR &amp; #DontDoubleMyRate? Ask now with #WHChat &amp; join Office Hrs today @ 4:30ET: http:\/\/t.co\/mBJCl60r",
  "id" : 210788968718016512,
  "created_at" : "2012-06-07 17:43:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IBR",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/X4RFBrUk",
      "expanded_url" : "http:\/\/on.wh.gov\/mQsE",
      "display_url" : "on.wh.gov\/mQsE"
    } ]
  },
  "geo" : { },
  "id_str" : "210779243699900417",
  "text" : "Here's everything you need to know about Income Based Repayment (#IBR) &amp; how it could help you: http:\/\/t.co\/X4RFBrUk",
  "id" : 210779243699900417,
  "created_at" : "2012-06-07 17:04:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/KoS6So6A",
      "expanded_url" : "http:\/\/wh.gov\/zuM",
      "display_url" : "wh.gov\/zuM"
    } ]
  },
  "geo" : { },
  "id_str" : "210742891788767233",
  "text" : "Today the President heads to UNLV to speak on the economy &amp; keeping college affordable. In the area? You can still join http:\/\/t.co\/KoS6So6A",
  "id" : 210742891788767233,
  "created_at" : "2012-06-07 14:39:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensHealth",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210726117525565440",
  "text" : "RT @vj44: The health care law is helping women: free checkups, cheaper Rx drugs &amp; more. Watch #WomensHealth town hall live @ 10ET ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensHealth",
        "indices" : [ 88, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/hU1vwc2g",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "210725716633993216",
    "text" : "The health care law is helping women: free checkups, cheaper Rx drugs &amp; more. Watch #WomensHealth town hall live @ 10ET http:\/\/t.co\/hU1vwc2g",
    "id" : 210725716633993216,
    "created_at" : "2012-06-07 13:31:40 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 210726117525565440,
  "created_at" : "2012-06-07 13:33:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/VdZKsDrh",
      "expanded_url" : "http:\/\/on.wh.gov\/Lc2b",
      "display_url" : "on.wh.gov\/Lc2b"
    } ]
  },
  "geo" : { },
  "id_str" : "210707227743494144",
  "text" : "Insurance Rebates on the Way: Consumers are starting to hear the good news about their health insurance costs:  http:\/\/t.co\/VdZKsDrh",
  "id" : 210707227743494144,
  "created_at" : "2012-06-07 12:18:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UNLV",
      "screen_name" : "unlvnews",
      "indices" : [ 3, 12 ],
      "id_str" : "702553614921781248",
      "id" : 702553614921781248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/A99m6pyA",
      "expanded_url" : "http:\/\/on.wh.gov\/14N9",
      "display_url" : "on.wh.gov\/14N9"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/HSMimtFp",
      "expanded_url" : "http:\/\/on.wh.gov\/EFkB",
      "display_url" : "on.wh.gov\/EFkB"
    } ]
  },
  "geo" : { },
  "id_str" : "210542941691850753",
  "text" : "RT @unlvnews: Line is forming for tickets to see President Obama at UNLV  http:\/\/t.co\/A99m6pyA \/\/ Want to join? RSVP: http:\/\/t.co\/HSMimtFp",
  "id" : 210542941691850753,
  "created_at" : "2012-06-07 01:25:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/H5R4maUN",
      "expanded_url" : "http:\/\/1.usa.gov\/KSVQDi",
      "display_url" : "1.usa.gov\/KSVQDi"
    } ]
  },
  "geo" : { },
  "id_str" : "210505849888718848",
  "text" : "RT @Brundage44: Getting at the facts on Republicans\u2019 false claims on tax cuts for the wealthy and small biz http:\/\/t.co\/H5R4maUN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/H5R4maUN",
        "expanded_url" : "http:\/\/1.usa.gov\/KSVQDi",
        "display_url" : "1.usa.gov\/KSVQDi"
      } ]
    },
    "geo" : { },
    "id_str" : "210505767734882304",
    "text" : "Getting at the facts on Republicans\u2019 false claims on tax cuts for the wealthy and small biz http:\/\/t.co\/H5R4maUN",
    "id" : 210505767734882304,
    "created_at" : "2012-06-06 22:57:40 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 210505849888718848,
  "created_at" : "2012-06-06 22:58:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/S9R6tA2n",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/06\/06\/archives-president-obama-commemorates-d-day",
      "display_url" : "whitehouse.gov\/blog\/2012\/06\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "210505667352596482",
  "text" : "From the Archives: President Obama Commemorates D-Day in Normandy: Watch: http:\/\/t.co\/S9R6tA2n",
  "id" : 210505667352596482,
  "created_at" : "2012-06-06 22:57:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhyRefi",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/hYnc3Wfi",
      "expanded_url" : "http:\/\/youtu.be\/BhpUiMp6Nlw",
      "display_url" : "youtu.be\/BhpUiMp6Nlw"
    }, {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/XoHHCT9v",
      "expanded_url" : "http:\/\/wh.gov\/why-refi",
      "display_url" : "wh.gov\/why-refi"
    } ]
  },
  "geo" : { },
  "id_str" : "210478284490801152",
  "text" : "We want your feedback: Watch this video: http:\/\/t.co\/hYnc3Wfi then answer some ?s about #WhyRefi: http:\/\/t.co\/XoHHCT9v",
  "id" : 210478284490801152,
  "created_at" : "2012-06-06 21:08:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 3, 13 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/s4xqJpZl",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "210473726687461376",
  "text" : "RT @todd_park: New API to http:\/\/t.co\/s4xqJpZl's powerful Insurance Finder (products, benefits info, pricing) now live http:\/\/t.co\/MXDsd ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "healthdata",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http:\/\/t.co\/s4xqJpZl",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      }, {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/MXDsdP81",
        "expanded_url" : "http:\/\/finder.healthcare.gov\/services",
        "display_url" : "finder.healthcare.gov\/services"
      } ]
    },
    "geo" : { },
    "id_str" : "210217304624070658",
    "text" : "New API to http:\/\/t.co\/s4xqJpZl's powerful Insurance Finder (products, benefits info, pricing) now live http:\/\/t.co\/MXDsdP81 #healthdata",
    "id" : 210217304624070658,
    "created_at" : "2012-06-06 03:51:25 +0000",
    "user" : {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "protected" : false,
      "id_str" : "200176600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140157375\/toddpark_normal.jpg",
      "id" : 200176600,
      "verified" : false
    }
  },
  "id" : 210473726687461376,
  "created_at" : "2012-06-06 20:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UNLV",
      "screen_name" : "unlvnews",
      "indices" : [ 3, 12 ],
      "id_str" : "702553614921781248",
      "id" : 702553614921781248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/EmpbIyae",
      "expanded_url" : "http:\/\/on.wh.gov\/PoQ6",
      "display_url" : "on.wh.gov\/PoQ6"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/p4bvoStH",
      "expanded_url" : "http:\/\/on.wh.gov\/9Bv8",
      "display_url" : "on.wh.gov\/9Bv8"
    } ]
  },
  "geo" : { },
  "id_str" : "210457561172946944",
  "text" : "RT @UNLVNews: Line is forming for tickets to see President Obama at UNLV http:\/\/t.co\/EmpbIyae \/\/ Want to join tmw? RSVP http:\/\/t.co\/p4bvoStH",
  "id" : 210457561172946944,
  "created_at" : "2012-06-06 19:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teachtalk",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210441953018523648",
  "text" : "RT @arneduncan: Teachers: What is one positive lesson you learned from another teacher this year? #teachtalk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teachtalk",
        "indices" : [ 82, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210440640713072642",
    "text" : "Teachers: What is one positive lesson you learned from another teacher this year? #teachtalk",
    "id" : 210440640713072642,
    "created_at" : "2012-06-06 18:38:53 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 210441953018523648,
  "created_at" : "2012-06-06 18:44:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210409504834207744",
  "text" : "RT @VP: We can\u2019t wait.The president has a plan to move this country forward, but we can\u2019t wait for politics on Capitol Hill -VP on #Cong ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CongressToDoList",
        "indices" : [ 123, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210407808426979329",
    "text" : "We can\u2019t wait.The president has a plan to move this country forward, but we can\u2019t wait for politics on Capitol Hill -VP on #CongressToDoList",
    "id" : 210407808426979329,
    "created_at" : "2012-06-06 16:28:25 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 210409504834207744,
  "created_at" : "2012-06-06 16:35:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "EBONY MAGAZINE",
      "screen_name" : "EBONYMag",
      "indices" : [ 29, 38 ],
      "id_str" : "39008044",
      "id" : 39008044
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 64, 75 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210357870083059712",
  "text" : "RT @vj44: Must read story in @EBONYmag about one of my favorite @whitehouse staffer who is a true public servant.http:\/\/bit.ly\/Lkz20D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EBONY MAGAZINE",
        "screen_name" : "EBONYMag",
        "indices" : [ 19, 28 ],
        "id_str" : "39008044",
        "id" : 39008044
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 54, 65 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210355761535139840",
    "text" : "Must read story in @EBONYmag about one of my favorite @whitehouse staffer who is a true public servant.http:\/\/bit.ly\/Lkz20D",
    "id" : 210355761535139840,
    "created_at" : "2012-06-06 13:01:36 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 210357870083059712,
  "created_at" : "2012-06-06 13:09:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/8SVr53ta",
      "expanded_url" : "http:\/\/on.wh.gov\/nl0Y",
      "display_url" : "on.wh.gov\/nl0Y"
    } ]
  },
  "geo" : { },
  "id_str" : "210333681980682240",
  "text" : "President Obama on #EqualPay vote: \"Senate Republicans put partisan politics ahead of American women &amp; their families\" http:\/\/t.co\/8SVr53ta",
  "id" : 210333681980682240,
  "created_at" : "2012-06-06 11:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/CbwQAPlr",
      "expanded_url" : "http:\/\/on.wh.gov\/QnJp",
      "display_url" : "on.wh.gov\/QnJp"
    } ]
  },
  "geo" : { },
  "id_str" : "210181971148681216",
  "text" : "Watch: President Obama honors Queen Elizabeth II on the historic occasion of her Diamond Jubilee: http:\/\/t.co\/CbwQAPlr",
  "id" : 210181971148681216,
  "created_at" : "2012-06-06 01:31:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/210158436422393858\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/nZfVr6m8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Auqh_AYCIAAGbzZ.jpg",
      "id_str" : "210158436430782464",
      "id" : 210158436430782464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Auqh_AYCIAAGbzZ.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/nZfVr6m8"
    } ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 7, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/4FTPisZs",
      "expanded_url" : "http:\/\/on.wh.gov\/6qMG",
      "display_url" : "on.wh.gov\/6qMG"
    } ]
  },
  "geo" : { },
  "id_str" : "210158436422393858",
  "text" : "By the #s: http:\/\/t.co\/4FTPisZs Today's college students graduate w\/ an average of $26,000 in student loan debt: http:\/\/t.co\/nZfVr6m8",
  "id" : 210158436422393858,
  "created_at" : "2012-06-05 23:57:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/iyjXzMK2",
      "expanded_url" : "http:\/\/on.wh.gov\/WPtF",
      "display_url" : "on.wh.gov\/WPtF"
    } ]
  },
  "geo" : { },
  "id_str" : "210103804404834305",
  "text" : "\"My Administration will continue to fight for a woman's right for #EqualPay for equal work\" -President Obama: http:\/\/t.co\/iyjXzMK2",
  "id" : 210103804404834305,
  "created_at" : "2012-06-05 20:20:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210102305603850240",
  "text" : "RT @vj44: Very disappointed that Rs in Congress let down women &amp; girls today. The Obama Admin will keep fighting for #EqualPay: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 111, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/PSeNjB72",
        "expanded_url" : "http:\/\/wh.gov\/zLR",
        "display_url" : "wh.gov\/zLR"
      } ]
    },
    "geo" : { },
    "id_str" : "210101787347271681",
    "text" : "Very disappointed that Rs in Congress let down women &amp; girls today. The Obama Admin will keep fighting for #EqualPay: http:\/\/t.co\/PSeNjB72",
    "id" : 210101787347271681,
    "created_at" : "2012-06-05 20:12:24 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 210102305603850240,
  "created_at" : "2012-06-05 20:14:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 97, 105 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/AaesXEVi",
      "expanded_url" : "http:\/\/on.wh.gov\/pOlZ",
      "display_url" : "on.wh.gov\/pOlZ"
    } ]
  },
  "geo" : { },
  "id_str" : "210082038974386176",
  "text" : "Here's a look at what people are saying about #EqualPay for equal work: http:\/\/t.co\/AaesXEVi via @storify",
  "id" : 210082038974386176,
  "created_at" : "2012-06-05 18:53:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210078420456062976",
  "text" : "RT @vj44: Great visit at the WH with Lilly Ledbetter.  She's on her way to Congress.  Vote on Paycheck Fairness starting soon! http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/210074476837216257\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/9sqOr2wv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AupVn6jCIAAiNHi.jpg",
        "id_str" : "210074476845604864",
        "id" : 210074476845604864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AupVn6jCIAAiNHi.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1529,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9sqOr2wv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210074476837216257",
    "text" : "Great visit at the WH with Lilly Ledbetter.  She's on her way to Congress.  Vote on Paycheck Fairness starting soon! http:\/\/t.co\/9sqOr2wv",
    "id" : 210074476837216257,
    "created_at" : "2012-06-05 18:23:54 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 210078420456062976,
  "created_at" : "2012-06-05 18:39:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210064010748510210",
  "text" : "RT @AmbassadorRice: Women deserve #EqualPay for equal work. Let's make this basic &amp; unambiguous principle a reality.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 14, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210057793854652417",
    "text" : "Women deserve #EqualPay for equal work. Let's make this basic &amp; unambiguous principle a reality.",
    "id" : 210057793854652417,
    "created_at" : "2012-06-05 17:17:35 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 210064010748510210,
  "created_at" : "2012-06-05 17:42:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 42, 45 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210050662644461569",
  "text" : "RT @arneduncan: At @WhiteHouse to meet w\/ @VP &amp; 10 college prez's who've pledged to give incoming students more info on #costofcolle ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 3, 14 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 26, 29 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "costofcollege",
        "indices" : [ 108, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/CEUl3N8a",
        "expanded_url" : "http:\/\/bloom.bg\/LlndFP",
        "display_url" : "bloom.bg\/LlndFP"
      } ]
    },
    "geo" : { },
    "id_str" : "210048828244623360",
    "text" : "At @WhiteHouse to meet w\/ @VP &amp; 10 college prez's who've pledged to give incoming students more info on #costofcollege http:\/\/t.co\/CEUl3N8a",
    "id" : 210048828244623360,
    "created_at" : "2012-06-05 16:41:57 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 210050662644461569,
  "created_at" : "2012-06-05 16:49:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Google Trends",
      "screen_name" : "GSearchTrends",
      "indices" : [ 30, 44 ],
      "id_str" : "396836528",
      "id" : 396836528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 17, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210048761618116609",
  "text" : "RT @jesseclee44: #EqualPay RT @GSearchTrends: Currently Trending: mlb draft, kurt busch, paycheck fairness act, ... on Google Search.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google Trends",
        "screen_name" : "GSearchTrends",
        "indices" : [ 13, 27 ],
        "id_str" : "396836528",
        "id" : 396836528
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "210043309723353090",
    "text" : "#EqualPay RT @GSearchTrends: Currently Trending: mlb draft, kurt busch, paycheck fairness act, ... on Google Search.",
    "id" : 210043309723353090,
    "created_at" : "2012-06-05 16:20:02 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 210048761618116609,
  "created_at" : "2012-06-05 16:41:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 3, 15 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210047563448066049",
  "text" : "RT @ginatrapani: The Paycheck Fairness Act would give employees better tools to claim equal pay for equal work. To support RT #EqualPay  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/4hD442jK",
        "expanded_url" : "http:\/\/wh.gov\/equalpay",
        "display_url" : "wh.gov\/equalpay"
      } ]
    },
    "geo" : { },
    "id_str" : "209683780435320832",
    "text" : "The Paycheck Fairness Act would give employees better tools to claim equal pay for equal work. To support RT #EqualPay http:\/\/t.co\/4hD442jK",
    "id" : 209683780435320832,
    "created_at" : "2012-06-04 16:31:23 +0000",
    "user" : {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "protected" : false,
      "id_str" : "930061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550825678673682432\/YRqb4FJE_normal.png",
      "id" : 930061,
      "verified" : true
    }
  },
  "id" : 210047563448066049,
  "created_at" : "2012-06-05 16:36:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/210018863713230848\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/9K4tb7jn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuojCzgCIAEwai4.jpg",
      "id_str" : "210018863717425153",
      "id" : 210018863717425153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuojCzgCIAEwai4.jpg",
      "sizes" : [ {
        "h" : 848,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9K4tb7jn"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/NnKCJR4I",
      "expanded_url" : "http:\/\/on.wh.gov\/NPak",
      "display_url" : "on.wh.gov\/NPak"
    } ]
  },
  "geo" : { },
  "id_str" : "210018863713230848",
  "text" : "On average, full-time working women earn just 77\u00A2 for every $1 a man earns. http:\/\/t.co\/NnKCJR4I Support #EqualPay: http:\/\/t.co\/9K4tb7jn",
  "id" : 210018863713230848,
  "created_at" : "2012-06-05 14:42:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 100, 111 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/b6xREtMF",
      "expanded_url" : "http:\/\/on.wh.gov\/Ym1a",
      "display_url" : "on.wh.gov\/Ym1a"
    } ]
  },
  "geo" : { },
  "id_str" : "209984076231352320",
  "text" : "Women entrepreneurs are creating #jobs: Check out an interactive timeline: http:\/\/t.co\/b6xREtMF via @whitehouse",
  "id" : 209984076231352320,
  "created_at" : "2012-06-05 12:24:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/209822111475314689\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/4nVsMG5I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AulwGUTCMAUmqpY.jpg",
      "id_str" : "209822111479508997",
      "id" : 209822111479508997,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AulwGUTCMAUmqpY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1263,
        "resize" : "fit",
        "w" : 1893
      } ],
      "display_url" : "pic.twitter.com\/4nVsMG5I"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 69, 86 ]
    }, {
      "text" : "jobs",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209822111475314689",
  "text" : "Photo of the Day: President Obama greets the crowd after speaking on #CongressToDoList &amp; #jobs at Honeywell in MN: http:\/\/t.co\/4nVsMG5I",
  "id" : 209822111475314689,
  "created_at" : "2012-06-05 01:41:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 48, 56 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209801763350511616",
  "text" : "RT @vj44: Thank you all for the warm welcome to @twitter &amp; for speaking out on #EqualPay for equal work. See new fact sheet: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 38, 46 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 73, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/aIQHorJD",
        "expanded_url" : "http:\/\/wh.gov\/zGY",
        "display_url" : "wh.gov\/zGY"
      } ]
    },
    "geo" : { },
    "id_str" : "209801572950089728",
    "text" : "Thank you all for the warm welcome to @twitter &amp; for speaking out on #EqualPay for equal work. See new fact sheet: http:\/\/t.co\/aIQHorJD",
    "id" : 209801572950089728,
    "created_at" : "2012-06-05 00:19:27 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 209801763350511616,
  "created_at" : "2012-06-05 00:20:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/209768540696363009\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/3GOdRWgx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Auk_YFnCQAAphJ1.jpg",
      "id_str" : "209768540704751616",
      "id" : 209768540704751616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Auk_YFnCQAAphJ1.jpg",
      "sizes" : [ {
        "h" : 271,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/3GOdRWgx"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/PigGq2Ov",
      "expanded_url" : "http:\/\/on.wh.gov\/WRTf",
      "display_url" : "on.wh.gov\/WRTf"
    } ]
  },
  "geo" : { },
  "id_str" : "209768540696363009",
  "text" : "#EqualPay by the Numbers: $431,000: http:\/\/t.co\/PigGq2Ov The gender wage gap puts women at a career-long disadvantage: http:\/\/t.co\/3GOdRWgx",
  "id" : 209768540696363009,
  "created_at" : "2012-06-04 22:08:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAP44",
      "indices" : [ 14, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209760540157935616",
  "text" : "RT @OMBPress: #SAP44: Admin strongly supports the Paycheck Fairness Act; gives women tools they need to fight pay discrim http:\/\/t.co\/7G ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SAP44",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "EqualPay",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/7GmsKVBW",
        "expanded_url" : "http:\/\/1.usa.gov\/L7oDRP",
        "display_url" : "1.usa.gov\/L7oDRP"
      } ]
    },
    "geo" : { },
    "id_str" : "209725836859932672",
    "text" : "#SAP44: Admin strongly supports the Paycheck Fairness Act; gives women tools they need to fight pay discrim http:\/\/t.co\/7GmsKVBW #EqualPay",
    "id" : 209725836859932672,
    "created_at" : "2012-06-04 19:18:30 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 209760540157935616,
  "created_at" : "2012-06-04 21:36:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 11, 19 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 55, 60 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/209756593137520641\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/yKCuBOgF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Auk0gpfCEAEVH7f.jpg",
      "id_str" : "209756593145909249",
      "id" : 209756593145909249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Auk0gpfCEAEVH7f.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yKCuBOgF"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/7REX8OC3",
      "expanded_url" : "http:\/\/on.wh.gov\/KUWj",
      "display_url" : "on.wh.gov\/KUWj"
    } ]
  },
  "geo" : { },
  "id_str" : "209756593137520641",
  "text" : "Welcome to @Twitter Sr Advisor Valerie Jarrett! Follow @vj44. 1st tweet on #EqualPay: http:\/\/t.co\/7REX8OC3 Photo: http:\/\/t.co\/yKCuBOgF",
  "id" : 209756593137520641,
  "created_at" : "2012-06-04 21:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/h9A4lIt4",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "209743461891571712",
  "text" : "RT @VP: Tune in NOW to hear the VP's commencement address to Cypress Bay High School in Miami. Listen here: http:\/\/t.co\/h9A4lIt4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/h9A4lIt4",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "209738884341432322",
    "text" : "Tune in NOW to hear the VP's commencement address to Cypress Bay High School in Miami. Listen here: http:\/\/t.co\/h9A4lIt4",
    "id" : 209738884341432322,
    "created_at" : "2012-06-04 20:10:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 209743461891571712,
  "created_at" : "2012-06-04 20:28:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hurricane",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/M9PHguBU",
      "expanded_url" : "http:\/\/on.wh.gov\/176n",
      "display_url" : "on.wh.gov\/176n"
    } ]
  },
  "geo" : { },
  "id_str" : "209736499237888001",
  "text" : "Here are 3 simple steps you can take to prepare for this year's #hurricane season: http:\/\/t.co\/M9PHguBU",
  "id" : 209736499237888001,
  "created_at" : "2012-06-04 20:00:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 79, 84 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209683253039349761",
  "text" : "RT @DavidAgnew44: President Obama was just on a call supporting #EqualPay with @VJ44: \"Let's make sure hard work pays off, responsibilit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 61, 66 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209682935161421824",
    "text" : "President Obama was just on a call supporting #EqualPay with @VJ44: \"Let's make sure hard work pays off, responsibility is rewarded\"",
    "id" : 209682935161421824,
    "created_at" : "2012-06-04 16:28:02 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 209683253039349761,
  "created_at" : "2012-06-04 16:29:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 71, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209682577781559297",
  "text" : "RT @PressSec: I'm answering your ?'s after today's press briefing. Use #1q to join the conversation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 57, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209655241212301312",
    "text" : "I'm answering your ?'s after today's press briefing. Use #1q to join the conversation.",
    "id" : 209655241212301312,
    "created_at" : "2012-06-04 14:37:59 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 209682577781559297,
  "created_at" : "2012-06-04 16:26:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209680415605264384",
  "text" : "RT @jesseclee44: Obama on call re: #EqualPay: \"We've got to understand this is about more than just fairness... everybody suffers\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 18, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209680180158021632",
    "text" : "Obama on call re: #EqualPay: \"We've got to understand this is about more than just fairness... everybody suffers\"",
    "id" : 209680180158021632,
    "created_at" : "2012-06-04 16:17:05 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 209680415605264384,
  "created_at" : "2012-06-04 16:18:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209680268192268288",
  "text" : "RT @vj44: On a call now with President Obama and folks across the country. He is urging all Americans to make their voices heard on #Equ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 122, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209679763005124608",
    "text" : "On a call now with President Obama and folks across the country. He is urging all Americans to make their voices heard on #EqualPay.",
    "id" : 209679763005124608,
    "created_at" : "2012-06-04 16:15:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 209680268192268288,
  "created_at" : "2012-06-04 16:17:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessica ellen",
      "screen_name" : "jessicaellen11",
      "indices" : [ 3, 18 ],
      "id_str" : "1284080856",
      "id" : 1284080856
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 31, 36 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 43, 51 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "Women2012",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/y0QPdZkI",
      "expanded_url" : "http:\/\/wh.gov\/equalpay",
      "display_url" : "wh.gov\/equalpay"
    } ]
  },
  "geo" : { },
  "id_str" : "209648510679785473",
  "text" : "RT @jessicaellen11: So excited @vj44 is on @Twitter and talking about #EqualPay from her first tweet! http:\/\/t.co\/y0QPdZkI #Women2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 11, 16 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 23, 31 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 50, 59 ]
      }, {
        "text" : "Women2012",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/y0QPdZkI",
        "expanded_url" : "http:\/\/wh.gov\/equalpay",
        "display_url" : "wh.gov\/equalpay"
      } ]
    },
    "geo" : { },
    "id_str" : "209648167183065088",
    "text" : "So excited @vj44 is on @Twitter and talking about #EqualPay from her first tweet! http:\/\/t.co\/y0QPdZkI #Women2012",
    "id" : 209648167183065088,
    "created_at" : "2012-06-04 14:09:52 +0000",
    "user" : {
      "name" : "Jessica Hewkin",
      "screen_name" : "jehewkin",
      "protected" : false,
      "id_str" : "141092727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/488722469507706880\/D8iIkp6L_normal.jpeg",
      "id" : 141092727,
      "verified" : false
    }
  },
  "id" : 209648510679785473,
  "created_at" : "2012-06-04 14:11:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Fitzpatrick",
      "screen_name" : "AlexJamesFitz",
      "indices" : [ 3, 17 ],
      "id_str" : "24622734",
      "id" : 24622734
    }, {
      "name" : "Josh Shpayher",
      "screen_name" : "joshs",
      "indices" : [ 22, 28 ],
      "id_str" : "15505053",
      "id" : 15505053
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 105, 110 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209648356098711553",
  "text" : "RT @AlexJamesFitz: RT @joshs: And... Obama confidante extraordinaire Valerie Jarrett has joined Twitter: @vj44",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Shpayher",
        "screen_name" : "joshs",
        "indices" : [ 3, 9 ],
        "id_str" : "15505053",
        "id" : 15505053
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 86, 91 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "209647221715648512",
    "text" : "RT @joshs: And... Obama confidante extraordinaire Valerie Jarrett has joined Twitter: @vj44",
    "id" : 209647221715648512,
    "created_at" : "2012-06-04 14:06:07 +0000",
    "user" : {
      "name" : "Alex Fitzpatrick",
      "screen_name" : "AlexJamesFitz",
      "protected" : false,
      "id_str" : "24622734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791099866642583553\/bEhZ1_AT_normal.jpg",
      "id" : 24622734,
      "verified" : true
    }
  },
  "id" : 209648356098711553,
  "created_at" : "2012-06-04 14:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geo Harrold",
      "screen_name" : "SistahChef",
      "indices" : [ 3, 14 ],
      "id_str" : "240821172",
      "id" : 240821172
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 24, 29 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209648220576550914",
  "text" : "RT @SistahChef: Welcome @vj44 to Twitter!  The social place where the world is your oyster! #EqualPay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 8, 13 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "209641123780636674",
    "geo" : { },
    "id_str" : "209647938727706625",
    "in_reply_to_user_id" : 595515713,
    "text" : "Welcome @vj44 to Twitter!  The social place where the world is your oyster! #EqualPay",
    "id" : 209647938727706625,
    "in_reply_to_status_id" : 209641123780636674,
    "created_at" : "2012-06-04 14:08:58 +0000",
    "in_reply_to_screen_name" : "vj44",
    "in_reply_to_user_id_str" : "595515713",
    "user" : {
      "name" : "Geo Harrold",
      "screen_name" : "SistahChef",
      "protected" : false,
      "id_str" : "240821172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727652533099880448\/va5wnM4V_normal.jpg",
      "id" : 240821172,
      "verified" : false
    }
  },
  "id" : 209648220576550914,
  "created_at" : "2012-06-04 14:10:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 27, 35 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209643911348617216",
  "text" : "RT @vj44: Excited to be on @twitter &amp; hear from you! A woman earns just 77\u00A2 for every $1 a man does. Join me &amp; support #EqualPay ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 17, 25 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 117, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 128, 148 ],
        "url" : "http:\/\/t.co\/2Jy3y1Xn",
        "expanded_url" : "http:\/\/wh.gov\/equalpay",
        "display_url" : "wh.gov\/equalpay"
      } ]
    },
    "geo" : { },
    "id_str" : "209641123780636674",
    "text" : "Excited to be on @twitter &amp; hear from you! A woman earns just 77\u00A2 for every $1 a man does. Join me &amp; support #EqualPay  http:\/\/t.co\/2Jy3y1Xn",
    "id" : 209641123780636674,
    "created_at" : "2012-06-04 13:41:53 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 209643911348617216,
  "created_at" : "2012-06-04 13:52:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/e8Ccj6QS",
      "expanded_url" : "http:\/\/on.wh.gov\/NhJi",
      "display_url" : "on.wh.gov\/NhJi"
    } ]
  },
  "geo" : { },
  "id_str" : "209620169339830273",
  "text" : "Obama: \"Congress should give small business owners a tax break for hiring more workers &amp; paying them higher wages\" http:\/\/t.co\/e8Ccj6QS",
  "id" : 209620169339830273,
  "created_at" : "2012-06-04 12:18:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/I1J5B3IX",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/A0EfwPlZ",
      "expanded_url" : "http:\/\/on.wh.gov\/h14R",
      "display_url" : "on.wh.gov\/h14R"
    } ]
  },
  "geo" : { },
  "id_str" : "209455555385896962",
  "text" : "Weekly Wrap Up: Sacrifices &amp; Accomplishments: A quick glimpse at this week on http:\/\/t.co\/I1J5B3IX: http:\/\/t.co\/A0EfwPlZ",
  "id" : 209455555385896962,
  "created_at" : "2012-06-04 01:24:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209370380538888192",
  "text" : "Obama: \"Congress should give every responsible homeowner the opportunity to save an average of $3,000 a year by refinancing their mortgage\"",
  "id" : 209370380538888192,
  "created_at" : "2012-06-03 19:46:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/eKNg5Bwt",
      "expanded_url" : "http:\/\/on.wh.gov\/vLK9",
      "display_url" : "on.wh.gov\/vLK9"
    } ]
  },
  "geo" : { },
  "id_str" : "209264656697667584",
  "text" : "West Wing Week: 05\/31\/12 or \"Each of Them Loved This Country...More Than Life Itself.\" Watch: http:\/\/t.co\/eKNg5Bwt",
  "id" : 209264656697667584,
  "created_at" : "2012-06-03 12:45:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/TM6iw9cR",
      "expanded_url" : "http:\/\/on.wh.gov\/8SeB",
      "display_url" : "on.wh.gov\/8SeB"
    } ]
  },
  "geo" : { },
  "id_str" : "209118422125125633",
  "text" : "Local students join a May morning harvest in the White House Kitchen Garden: http:\/\/t.co\/TM6iw9cR",
  "id" : 209118422125125633,
  "created_at" : "2012-06-03 03:04:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/tt6OIL7n",
      "expanded_url" : "http:\/\/on.wh.gov\/2fp2",
      "display_url" : "on.wh.gov\/2fp2"
    } ]
  },
  "geo" : { },
  "id_str" : "209032918910251008",
  "text" : "\"Ensuring paycheck fairness for women should be a no brainer\" -President Obama on Congress vote on 6\/5: http:\/\/t.co\/tt6OIL7n #EqualPay",
  "id" : 209032918910251008,
  "created_at" : "2012-06-02 21:25:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 106, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/Tr44XAzl",
      "expanded_url" : "http:\/\/on.wh.gov\/bXAv",
      "display_url" : "on.wh.gov\/bXAv"
    } ]
  },
  "geo" : { },
  "id_str" : "208994916611784705",
  "text" : "President Obama: \"My message to Congress is, get to work.\" Watch his Weekly Address: http:\/\/t.co\/Tr44XAzl #CongressToDoList",
  "id" : 208994916611784705,
  "created_at" : "2012-06-02 18:54:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/JBkVMN7F",
      "expanded_url" : "http:\/\/on.wh.gov\/0JnP",
      "display_url" : "on.wh.gov\/0JnP"
    } ]
  },
  "geo" : { },
  "id_str" : "208914228051066880",
  "text" : "President Obama welcomes President George W. Bush to the White House for portrait unveiling: http:\/\/t.co\/JBkVMN7F",
  "id" : 208914228051066880,
  "created_at" : "2012-06-02 13:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/208768745294938115\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/K3KaKbcP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuWyEVhCQAAdrTd.jpg",
      "id_str" : "208768745307521024",
      "id" : 208768745307521024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuWyEVhCQAAdrTd.jpg",
      "sizes" : [ {
        "h" : 848,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/K3KaKbcP"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/HAQ0jYMg",
      "expanded_url" : "http:\/\/on.wh.gov\/EJCE",
      "display_url" : "on.wh.gov\/EJCE"
    } ]
  },
  "geo" : { },
  "id_str" : "208768745294938115",
  "text" : "Women earn an average of just 77 cents for every dollar earned by men: http:\/\/t.co\/HAQ0jYMg Support #EqualPay: http:\/\/t.co\/K3KaKbcP",
  "id" : 208768745294938115,
  "created_at" : "2012-06-02 03:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/XMN00K4i",
      "expanded_url" : "http:\/\/on.wh.gov\/DeIf",
      "display_url" : "on.wh.gov\/DeIf"
    } ]
  },
  "geo" : { },
  "id_str" : "208723082754523137",
  "text" : "President Obama: \"#LGBT community has written a proud chapter in this fundamentally American story.\" Proclamation: http:\/\/t.co\/XMN00K4i",
  "id" : 208723082754523137,
  "created_at" : "2012-06-02 00:53:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/kRkpPgx6",
      "expanded_url" : "http:\/\/youtu.be\/HTsfXpnOn2c",
      "display_url" : "youtu.be\/HTsfXpnOn2c"
    }, {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/79Qq3ML0",
      "expanded_url" : "http:\/\/on.wh.gov\/EKVO",
      "display_url" : "on.wh.gov\/EKVO"
    } ]
  },
  "geo" : { },
  "id_str" : "208709258945105920",
  "text" : "Watch the latest \"West Wing Week\": http:\/\/t.co\/kRkpPgx6 &amp; let us know what you think: http:\/\/t.co\/79Qq3ML0",
  "id" : 208709258945105920,
  "created_at" : "2012-06-01 23:58:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miss Representation",
      "screen_name" : "RepresentPledge",
      "indices" : [ 3, 19 ],
      "id_str" : "225634187",
      "id" : 225634187
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/tDB8tHR0",
      "expanded_url" : "http:\/\/1.usa.gov\/L4HkI8",
      "display_url" : "1.usa.gov\/L4HkI8"
    } ]
  },
  "geo" : { },
  "id_str" : "208675600779579392",
  "text" : "RT @RepresentPledge: In more than 50% of American households, women are breadwinners. #EqualPay for equal work: http:\/\/t.co\/tDB8tHR0 via ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 116, 127 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 65, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/tDB8tHR0",
        "expanded_url" : "http:\/\/1.usa.gov\/L4HkI8",
        "display_url" : "1.usa.gov\/L4HkI8"
      } ]
    },
    "geo" : { },
    "id_str" : "208650618372505600",
    "text" : "In more than 50% of American households, women are breadwinners. #EqualPay for equal work: http:\/\/t.co\/tDB8tHR0 via @whitehouse",
    "id" : 208650618372505600,
    "created_at" : "2012-06-01 20:05:58 +0000",
    "user" : {
      "name" : "Miss Representation",
      "screen_name" : "RepresentPledge",
      "protected" : false,
      "id_str" : "225634187",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430496143575773185\/VKilFUkM_normal.jpeg",
      "id" : 225634187,
      "verified" : true
    }
  },
  "id" : 208675600779579392,
  "created_at" : "2012-06-01 21:45:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 75, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/HIFmK31H",
      "expanded_url" : "http:\/\/on.wh.gov\/VcjH",
      "display_url" : "on.wh.gov\/VcjH"
    } ]
  },
  "geo" : { },
  "id_str" : "208673794292854786",
  "text" : "President Obama: We Have to Deliver for Our Veterans: http:\/\/t.co\/HIFmK31H #CongressToDoList",
  "id" : 208673794292854786,
  "created_at" : "2012-06-01 21:38:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MomsRising",
      "screen_name" : "MomsRising",
      "indices" : [ 3, 14 ],
      "id_str" : "15174710",
      "id" : 15174710
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 96, 107 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/r9zDDNeN",
      "expanded_url" : "http:\/\/1.usa.gov\/L4xFS0",
      "display_url" : "1.usa.gov\/L4xFS0"
    } ]
  },
  "geo" : { },
  "id_str" : "208641806114627585",
  "text" : "RT @MomsRising: Great e-cards! RT if you support #EqualPay for equal work: http:\/\/t.co\/r9zDDNeN @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 80, 91 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 33, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/r9zDDNeN",
        "expanded_url" : "http:\/\/1.usa.gov\/L4xFS0",
        "display_url" : "1.usa.gov\/L4xFS0"
      } ]
    },
    "geo" : { },
    "id_str" : "208641139241254913",
    "text" : "Great e-cards! RT if you support #EqualPay for equal work: http:\/\/t.co\/r9zDDNeN @whitehouse",
    "id" : 208641139241254913,
    "created_at" : "2012-06-01 19:28:18 +0000",
    "user" : {
      "name" : "MomsRising",
      "screen_name" : "MomsRising",
      "protected" : false,
      "id_str" : "15174710",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750785578250100736\/FfqBY8G0_normal.jpg",
      "id" : 15174710,
      "verified" : true
    }
  },
  "id" : 208641806114627585,
  "created_at" : "2012-06-01 19:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/208630269626957824\/photo\/1",
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/7PSVLRVT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuU0H_cCQAAJBFe.jpg",
      "id_str" : "208630269635346432",
      "id" : 208630269635346432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuU0H_cCQAAJBFe.jpg",
      "sizes" : [ {
        "h" : 1008,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 988,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1008,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7PSVLRVT"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/mBzH0vYk",
      "expanded_url" : "http:\/\/on.wh.gov\/3ag8",
      "display_url" : "on.wh.gov\/3ag8"
    } ]
  },
  "geo" : { },
  "id_str" : "208630269626957824",
  "text" : "It's 2012, but did you know that women are still paid less than men? http:\/\/t.co\/mBzH0vYk #EqualPay http:\/\/t.co\/7PSVLRVT",
  "id" : 208630269626957824,
  "created_at" : "2012-06-01 18:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208614608192290817",
  "text" : "Obama: As Commander-in-Chief, I want all our service members &amp; veterans to know that we are forever grateful for your service &amp; sacrifice",
  "id" : 208614608192290817,
  "created_at" : "2012-06-01 17:42:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208614561769730049",
  "text" : "Obama: Standing up for our veterans isn\u2019t a Democratic responsibility or a Republican responsibility \u2013 it\u2019s an American responsibility.",
  "id" : 208614561769730049,
  "created_at" : "2012-06-01 17:42:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208613921291112449",
  "text" : "Obama: Our government needs their patriotism &amp; sense of duty. I ordered the hiring of more veterans \u2013 we\u2019ve hired more than 200k so far.",
  "id" : 208613921291112449,
  "created_at" : "2012-06-01 17:40:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208612349274357760",
  "text" : "Obama: At Honeywell, you\u2019ve made it a mission to hire more veterans \u2013 not just because it feels good, but because it's good for business.",
  "id" : 208612349274357760,
  "created_at" : "2012-06-01 17:33:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208611527283060738",
  "text" : "President Obama: We should make sure that no one who fights for this country abroad should ever have to fight for a job when they come home.",
  "id" : 208611527283060738,
  "created_at" : "2012-06-01 17:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/ezqIjxYs",
      "expanded_url" : "http:\/\/on.wh.gov\/EPuE",
      "display_url" : "on.wh.gov\/EPuE"
    } ]
  },
  "geo" : { },
  "id_str" : "208606656584613888",
  "text" : "Watch live: President Obama speaks on Veterans Job Corps @ Honeywell's Golden Valley facility in MN http:\/\/t.co\/ezqIjxYs #CongressToDoList",
  "id" : 208606656584613888,
  "created_at" : "2012-06-01 17:11:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Veterans",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "CongressToDoList",
      "indices" : [ 73, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/hinwoSst",
      "expanded_url" : "http:\/\/on.wh.gov\/5bG8",
      "display_url" : "on.wh.gov\/5bG8"
    } ]
  },
  "geo" : { },
  "id_str" : "208589713500667904",
  "text" : "Today President Obama calls on Congress to act on #Veterans Job Corps on #CongressToDoList: http:\/\/t.co\/hinwoSst",
  "id" : 208589713500667904,
  "created_at" : "2012-06-01 16:03:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 27, 38 ]
    }, {
      "text" : "CongressToDoList",
      "indices" : [ 67, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/L6Rq8OJC",
      "expanded_url" : "http:\/\/on.wh.gov\/vzWj",
      "display_url" : "on.wh.gov\/vzWj"
    } ]
  },
  "geo" : { },
  "id_str" : "208524836639739905",
  "text" : "Reward American jobs &amp; #insourcing, not outsourcing (1 of 5 on #CongressToDoList): http:\/\/t.co\/L6Rq8OJC",
  "id" : 208524836639739905,
  "created_at" : "2012-06-01 11:46:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]