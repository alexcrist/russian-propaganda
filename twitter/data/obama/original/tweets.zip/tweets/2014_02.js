Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/86ynhSZkL9",
      "expanded_url" : "http:\/\/youtu.be\/-BGPzJFd3Ko",
      "display_url" : "youtu.be\/-BGPzJFd3Ko"
    } ]
  },
  "geo" : { },
  "id_str" : "439564099970949120",
  "text" : "In case you missed it, President Obama honored some amazing student filmmakers at the first-ever #WHFilmFest \u2192 http:\/\/t.co\/86ynhSZkL9",
  "id" : 439564099970949120,
  "created_at" : "2014-03-01 00:53:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/6EbkEA8k0W",
      "expanded_url" : "http:\/\/go.wh.gov\/jEuxiY",
      "display_url" : "go.wh.gov\/jEuxiY"
    } ]
  },
  "geo" : { },
  "id_str" : "439550525617750016",
  "text" : "Watch President Obama's statement on the situation in Ukraine \u2192 http:\/\/t.co\/6EbkEA8k0W",
  "id" : 439550525617750016,
  "created_at" : "2014-02-28 23:59:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/JtUpFG4rgO",
      "expanded_url" : "http:\/\/go.wh.gov\/xwcJgJ",
      "display_url" : "go.wh.gov\/xwcJgJ"
    } ]
  },
  "geo" : { },
  "id_str" : "439521808765976578",
  "text" : "Starting now: President Obama delivers a statement on Ukraine. Watch \u2192 http:\/\/t.co\/JtUpFG4rgO",
  "id" : 439521808765976578,
  "created_at" : "2014-02-28 22:05:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/JtUpFG4rgO",
      "expanded_url" : "http:\/\/go.wh.gov\/xwcJgJ",
      "display_url" : "go.wh.gov\/xwcJgJ"
    } ]
  },
  "geo" : { },
  "id_str" : "439516199253471233",
  "text" : "Happening shortly: President Obama delivers a statement on Ukraine from the Briefing Room. Watch here \u2192 http:\/\/t.co\/JtUpFG4rgO",
  "id" : 439516199253471233,
  "created_at" : "2014-02-28 21:43:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439511366836449280",
  "text" : "RT @WHVideo: Obama: \"Your imagination, your creativity, your innovation, your dreams that are going to keep driving us forward.\" #WHFilmFes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 116, 127 ]
      }, {
        "text" : "ConnectED",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439511289556369408",
    "text" : "Obama: \"Your imagination, your creativity, your innovation, your dreams that are going to keep driving us forward.\" #WHFilmFest #ConnectED",
    "id" : 439511289556369408,
    "created_at" : "2014-02-28 21:23:51 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 439511366836449280,
  "created_at" : "2014-02-28 21:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439510129403498496",
  "text" : "President Obama: \"In a country where we expect free Wi-Fi at our coffee shops, we should demand it in our schools and libraries.\" #ConnectED",
  "id" : 439510129403498496,
  "created_at" : "2014-02-28 21:19:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 95, 106 ]
    }, {
      "text" : "ConnectED",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439509968522592256",
  "text" : "President Obama: \"We want to bring this spirit\u2014including more technology\u2014to more classrooms.\"  #WHFilmFest #ConnectED",
  "id" : 439509968522592256,
  "created_at" : "2014-02-28 21:18:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439509379285794816",
  "text" : "RT @WHVideo: President Obama: \"In my official capacity as President, let me just say: these movies are awesome.\" #WHFilmFest",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 100, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439509330128547841",
    "text" : "President Obama: \"In my official capacity as President, let me just say: these movies are awesome.\" #WHFilmFest",
    "id" : 439509330128547841,
    "created_at" : "2014-02-28 21:16:04 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 439509379285794816,
  "created_at" : "2014-02-28 21:16:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439509137052164096",
  "text" : "Obama: \"One of the ways we deliver the best education in the world is by empowering our students with the best technology in the world.\"",
  "id" : 439509137052164096,
  "created_at" : "2014-02-28 21:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439508980554276864",
  "text" : "Obama: \u201CEvery child in America deserves a world-class education\u2014especially in science, technology, engineering &amp; math.\u201D #WHFilmFest",
  "id" : 439508980554276864,
  "created_at" : "2014-02-28 21:14:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439508553737711616",
  "text" : "Obama: \"The Academy Awards aren\u2019t until Sunday. But, as you can see, we\u2019ve brought the Oscars to the White House a little early\" #WHFilmFest",
  "id" : 439508553737711616,
  "created_at" : "2014-02-28 21:12:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/gX27YIDzRF",
      "expanded_url" : "http:\/\/go.wh.gov\/LS1msR",
      "display_url" : "go.wh.gov\/LS1msR"
    } ]
  },
  "geo" : { },
  "id_str" : "439506785620492288",
  "text" : "Grab your popcorn! The first-ever White House Student Film Festival starts now \u2192 http:\/\/t.co\/gX27YIDzRF #WHFilmFest",
  "id" : 439506785620492288,
  "created_at" : "2014-02-28 21:05:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 111, 122 ]
    }, {
      "text" : "ConnectED",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/gX27YIDzRF",
      "expanded_url" : "http:\/\/go.wh.gov\/LS1msR",
      "display_url" : "go.wh.gov\/LS1msR"
    } ]
  },
  "geo" : { },
  "id_str" : "439503271791951873",
  "text" : "Starting soon: President Obama speaks at the White House Student Film Festival. Watch \u2192 http:\/\/t.co\/gX27YIDzRF #WHFilmFest #ConnectED",
  "id" : 439503271791951873,
  "created_at" : "2014-02-28 20:52:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Conan O'Brien",
      "screen_name" : "ConanOBrien",
      "indices" : [ 3, 15 ],
      "id_str" : "115485051",
      "id" : 115485051
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 45, 56 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/pzz6rtlbRW",
      "expanded_url" : "http:\/\/go.wh.gov\/pMWn3s",
      "display_url" : "go.wh.gov\/pMWn3s"
    } ]
  },
  "geo" : { },
  "id_str" : "439497396448665601",
  "text" : "RT @ConanOBrien: Please watch the first-ever @WhiteHouse Student Film Fest @ 3:30 ET: http:\/\/t.co\/pzz6rtlbRW. I don't need another audit. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 28, 39 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 121, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/pzz6rtlbRW",
        "expanded_url" : "http:\/\/go.wh.gov\/pMWn3s",
        "display_url" : "go.wh.gov\/pMWn3s"
      } ]
    },
    "geo" : { },
    "id_str" : "439490305558343681",
    "text" : "Please watch the first-ever @WhiteHouse Student Film Fest @ 3:30 ET: http:\/\/t.co\/pzz6rtlbRW. I don't need another audit. #WHFilmFest",
    "id" : 439490305558343681,
    "created_at" : "2014-02-28 20:00:28 +0000",
    "user" : {
      "name" : "Conan O'Brien",
      "screen_name" : "ConanOBrien",
      "protected" : false,
      "id_str" : "115485051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730612231021322240\/Rl0_QYhL_normal.jpg",
      "id" : 115485051,
      "verified" : true
    }
  },
  "id" : 439497396448665601,
  "created_at" : "2014-02-28 20:28:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/gX27YIDzRF",
      "expanded_url" : "http:\/\/go.wh.gov\/LS1msR",
      "display_url" : "go.wh.gov\/LS1msR"
    } ]
  },
  "geo" : { },
  "id_str" : "439495366371991552",
  "text" : "Grab your popcorn! President Obama speaks at the White House Student Film Festival at 3:35pm ET. Watch \u2192 http:\/\/t.co\/gX27YIDzRF #WHFilmFest",
  "id" : 439495366371991552,
  "created_at" : "2014-02-28 20:20:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/439490970250665986\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ur6mavNT0F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhlitXCIgAAkJ77.jpg",
      "id_str" : "439490970061930496",
      "id" : 439490970061930496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhlitXCIgAAkJ77.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ur6mavNT0F"
    } ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 92, 102 ]
    }, {
      "text" : "WHFilmFest",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439490970250665986",
  "text" : "Let's give more students access to technology in the classroom that will help them succeed. #ConnectED #WHFilmFest http:\/\/t.co\/ur6mavNT0F",
  "id" : 439490970250665986,
  "created_at" : "2014-02-28 20:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    }, {
      "name" : "Ryan Seacrest",
      "screen_name" : "RyanSeacrest",
      "indices" : [ 25, 38 ],
      "id_str" : "16190898",
      "id" : 16190898
    }, {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 40, 54 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 102, 113 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439485332619530240",
  "text" : "RT @Lehrich44: Move over @RyanSeacrest. @TheScienceGuy currently hosting red carpet interviews in the @WhiteHouse. WATCH --&gt; http:\/\/t.co\/Rz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Seacrest",
        "screen_name" : "RyanSeacrest",
        "indices" : [ 10, 23 ],
        "id_str" : "16190898",
        "id" : 16190898
      }, {
        "name" : "Bill Nye",
        "screen_name" : "thescienceguy",
        "indices" : [ 25, 39 ],
        "id_str" : "3028904482",
        "id" : 3028904482
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 87, 98 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/RzLPtpOkiB",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "439483929750683648",
    "text" : "Move over @RyanSeacrest. @TheScienceGuy currently hosting red carpet interviews in the @WhiteHouse. WATCH --&gt; http:\/\/t.co\/RzLPtpOkiB",
    "id" : 439483929750683648,
    "created_at" : "2014-02-28 19:35:08 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 439485332619530240,
  "created_at" : "2014-02-28 19:40:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 28, 42 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 44, 54 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "Kal Penn",
      "screen_name" : "kalpenn",
      "indices" : [ 60, 68 ],
      "id_str" : "24024778",
      "id" : 24024778
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/439480944789958656\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/B8yObdhjrQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhlZlxnCEAARzpG.jpg",
      "id_str" : "439480944152416256",
      "id" : 439480944152416256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhlZlxnCEAARzpG.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2432,
        "resize" : "fit",
        "w" : 4320
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/B8yObdhjrQ"
    } ],
    "hashtags" : [ {
      "text" : "FilmFestSelfie",
      "indices" : [ 0, 15 ]
    }, {
      "text" : "WHFilmFest",
      "indices" : [ 80, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/occ3rkoWdN",
      "expanded_url" : "http:\/\/wh.gov\/filmfestival",
      "display_url" : "wh.gov\/filmfestival"
    } ]
  },
  "geo" : { },
  "id_str" : "439480944789958656",
  "text" : "#FilmFestSelfie: Don't miss @TheScienceGuy, @NeilTyson, and @KalPenn at today's #WHFilmFest: http:\/\/t.co\/occ3rkoWdN, http:\/\/t.co\/B8yObdhjrQ",
  "id" : 439480944789958656,
  "created_at" : "2014-02-28 19:23:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/gJFu9KDuWz",
      "expanded_url" : "http:\/\/youtu.be\/hCkjkm6YMCk",
      "display_url" : "youtu.be\/hCkjkm6YMCk"
    } ]
  },
  "geo" : { },
  "id_str" : "439475752489463808",
  "text" : "RT @WHVideo: Need inspiration? The #WHFilmFest has you covered \u2192 http:\/\/t.co\/gJFu9KDuWz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 22, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/gJFu9KDuWz",
        "expanded_url" : "http:\/\/youtu.be\/hCkjkm6YMCk",
        "display_url" : "youtu.be\/hCkjkm6YMCk"
      } ]
    },
    "geo" : { },
    "id_str" : "439471458410967040",
    "text" : "Need inspiration? The #WHFilmFest has you covered \u2192 http:\/\/t.co\/gJFu9KDuWz",
    "id" : 439471458410967040,
    "created_at" : "2014-02-28 18:45:35 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 439475752489463808,
  "created_at" : "2014-02-28 19:02:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 7, 18 ]
    }, {
      "text" : "ConnectED",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/ygECcfjqaj",
      "expanded_url" : "http:\/\/go.wh.gov\/z4g1yp",
      "display_url" : "go.wh.gov\/z4g1yp"
    } ]
  },
  "geo" : { },
  "id_str" : "439470199595487232",
  "text" : "At the #WHFilmFest, President Obama will announce $400 million in private-sector #ConnectED commitments: http:\/\/t.co\/ygECcfjqaj",
  "id" : 439470199595487232,
  "created_at" : "2014-02-28 18:40:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 31, 45 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Kal Penn",
      "screen_name" : "kalpenn",
      "indices" : [ 47, 55 ],
      "id_str" : "24024778",
      "id" : 24024778
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 63, 73 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/mZM69yxKDJ",
      "expanded_url" : "http:\/\/wh.gov\/filmfestival",
      "display_url" : "wh.gov\/filmfestival"
    } ]
  },
  "geo" : { },
  "id_str" : "439460839675158528",
  "text" : "Wanna watch student films with @TheScienceGuy, @KalPenn, &amp; @NeilTyson? Tune in at 3:30pm ET for the #WHFilmFest: http:\/\/t.co\/mZM69yxKDJ",
  "id" : 439460839675158528,
  "created_at" : "2014-02-28 18:03:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/28eVdfUy7I",
      "expanded_url" : "http:\/\/go.wh.gov\/XcStVf",
      "display_url" : "go.wh.gov\/XcStVf"
    } ]
  },
  "geo" : { },
  "id_str" : "439440816722173952",
  "text" : "Today, as part of President Obama's efforts to connect students to tech, we're launching the 1st-ever #WHFilmFest: http:\/\/t.co\/28eVdfUy7I",
  "id" : 439440816722173952,
  "created_at" : "2014-02-28 16:43:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/439417666974265345\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/v7v5jzm7eq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhkgCilIEAElOFB.jpg",
      "id_str" : "439417666659684353",
      "id" : 439417666659684353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhkgCilIEAElOFB.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/v7v5jzm7eq"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/P3aC9Oiosw",
      "expanded_url" : "http:\/\/go.wh.gov\/pMWn3s",
      "display_url" : "go.wh.gov\/pMWn3s"
    } ]
  },
  "geo" : { },
  "id_str" : "439417666974265345",
  "text" : "These kids know how to make movies! Tune in at 3:30pm ET for the first-ever #WHFilmFest: http:\/\/t.co\/P3aC9Oiosw, http:\/\/t.co\/v7v5jzm7eq",
  "id" : 439417666974265345,
  "created_at" : "2014-02-28 15:11:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/QynQ5x1tqB",
      "expanded_url" : "http:\/\/go.wh.gov\/z8NYdQ",
      "display_url" : "go.wh.gov\/z8NYdQ"
    } ]
  },
  "geo" : { },
  "id_str" : "439260214945398784",
  "text" : ".@VP: \"Mr. President, you ready to move?\"\n\nPOTUS: \"Let's do this thing. #LetsMove.\"\n\nWatch \u2192 http:\/\/t.co\/QynQ5x1tqB",
  "id" : 439260214945398784,
  "created_at" : "2014-02-28 04:46:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/NLMjV66JpR",
      "expanded_url" : "http:\/\/go.wh.gov\/tpFM17",
      "display_url" : "go.wh.gov\/tpFM17"
    } ]
  },
  "geo" : { },
  "id_str" : "439222311678246914",
  "text" : "\"When I was their age, I was a lot like them. I didn\u2019t have a dad in my life.\" \u2014President Obama: http:\/\/t.co\/NLMjV66JpR #MyBrothersKeeper",
  "id" : 439222311678246914,
  "created_at" : "2014-02-28 02:15:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/439211303127629825\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/idvK08TF9s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhhkWl8CEAA_2IY.jpg",
      "id_str" : "439211302972428288",
      "id" : 439211302972428288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhhkWl8CEAA_2IY.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/idvK08TF9s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439211303127629825",
  "text" : "\"We need to give every child, no matter what they look like...the chance to reach their full potential.\" \u2014Obama http:\/\/t.co\/idvK08TF9s",
  "id" : 439211303127629825,
  "created_at" : "2014-02-28 01:31:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/439203602125443072\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/J0qyNVy6z6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhhdWVOCQAAb9Ua.jpg",
      "id_str" : "439203601903140864",
      "id" : 439203601903140864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhhdWVOCQAAb9Ua.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/J0qyNVy6z6"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/9af11sj0dR",
      "expanded_url" : "http:\/\/go.wh.gov\/JrS6Ya",
      "display_url" : "go.wh.gov\/JrS6Ya"
    } ]
  },
  "geo" : { },
  "id_str" : "439203602125443072",
  "text" : "You don't want to miss this: Tune in tomorrow at 3:30pm ET for the first-ever #WHFilmFest: http:\/\/t.co\/9af11sj0dR, http:\/\/t.co\/J0qyNVy6z6",
  "id" : 439203602125443072,
  "created_at" : "2014-02-28 01:01:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/439189938127376384\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/MOpsebIACv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhhQ691CIAA68my.jpg",
      "id_str" : "439189937628258304",
      "id" : 439189937628258304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhhQ691CIAA68my.jpg",
      "sizes" : [ {
        "h" : 846,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1986,
        "resize" : "fit",
        "w" : 1408
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1444,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MOpsebIACv"
    } ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "TBT",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 40, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439194553187590144",
  "text" : "RT @FLOTUS: Let's dance! #LetsMove #TBT #ThrowbackThursday http:\/\/t.co\/MOpsebIACv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/439189938127376384\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/MOpsebIACv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhhQ691CIAA68my.jpg",
        "id_str" : "439189937628258304",
        "id" : 439189937628258304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhhQ691CIAA68my.jpg",
        "sizes" : [ {
          "h" : 846,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1986,
          "resize" : "fit",
          "w" : 1408
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1444,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MOpsebIACv"
      } ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 13, 22 ]
      }, {
        "text" : "TBT",
        "indices" : [ 23, 27 ]
      }, {
        "text" : "ThrowbackThursday",
        "indices" : [ 28, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439189938127376384",
    "text" : "Let's dance! #LetsMove #TBT #ThrowbackThursday http:\/\/t.co\/MOpsebIACv",
    "id" : 439189938127376384,
    "created_at" : "2014-02-28 00:06:55 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 439194553187590144,
  "created_at" : "2014-02-28 00:25:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Fallon Tonight",
      "screen_name" : "FallonTonight",
      "indices" : [ 85, 99 ],
      "id_str" : "19777398",
      "id" : 19777398
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/v1ljJCFpUv",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es18iAXxi",
      "display_url" : "tmblr.co\/ZW21es18iAXxi"
    } ]
  },
  "geo" : { },
  "id_str" : "439180736567201792",
  "text" : "RT @FLOTUS: Who's that running through the White House?\n\nBo and Sunny know...\n\nWatch @FallonTonight to find out \u2192 http:\/\/t.co\/v1ljJCFpUv #G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fallon Tonight",
        "screen_name" : "FallonTonight",
        "indices" : [ 73, 87 ],
        "id_str" : "19777398",
        "id" : 19777398
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GIF",
        "indices" : [ 125, 129 ]
      }, {
        "text" : "LetsMove",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/v1ljJCFpUv",
        "expanded_url" : "http:\/\/tmblr.co\/ZW21es18iAXxi",
        "display_url" : "tmblr.co\/ZW21es18iAXxi"
      } ]
    },
    "geo" : { },
    "id_str" : "439180150060883968",
    "text" : "Who's that running through the White House?\n\nBo and Sunny know...\n\nWatch @FallonTonight to find out \u2192 http:\/\/t.co\/v1ljJCFpUv #GIF #LetsMove",
    "id" : 439180150060883968,
    "created_at" : "2014-02-27 23:28:02 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 439180736567201792,
  "created_at" : "2014-02-27 23:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439169664732889088",
  "text" : "RT @FLOTUS: \"You...should be able to...pick an item off the shelf and tell whether it\u2019s good for your family.\" \u2014FLOTUS #LetsMove http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/439168569339686912\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/2b3sXT6Ef4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhg9fKLCEAANWh9.jpg",
        "id_str" : "439168569184489472",
        "id" : 439168569184489472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhg9fKLCEAANWh9.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/2b3sXT6Ef4"
      } ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439168569339686912",
    "text" : "\"You...should be able to...pick an item off the shelf and tell whether it\u2019s good for your family.\" \u2014FLOTUS #LetsMove http:\/\/t.co\/2b3sXT6Ef4",
    "id" : 439168569339686912,
    "created_at" : "2014-02-27 22:42:00 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 439169664732889088,
  "created_at" : "2014-02-27 22:46:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Coleman",
      "screen_name" : "MichaelBColeman",
      "indices" : [ 3, 19 ],
      "id_str" : "151943134",
      "id" : 151943134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439166291497467904",
  "text" : "RT @MichaelBColeman: I'm happy to support this initiative today to continue advocating for success for young men of color in our community.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 119, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439135917442621440",
    "text" : "I'm happy to support this initiative today to continue advocating for success for young men of color in our community. #MyBrothersKeeper",
    "id" : 439135917442621440,
    "created_at" : "2014-02-27 20:32:16 +0000",
    "user" : {
      "name" : "Mike Coleman",
      "screen_name" : "MichaelBColeman",
      "protected" : false,
      "id_str" : "151943134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618036641702260736\/DkC3Y_n4_normal.jpg",
      "id" : 151943134,
      "verified" : true
    }
  },
  "id" : 439166291497467904,
  "created_at" : "2014-02-27 22:32:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439147592082272258",
  "text" : "President Obama: \"We need to give every child, no matter what they look like...the chance to reach their full potential.\" #MyBrothersKeeper",
  "id" : 439147592082272258,
  "created_at" : "2014-02-27 21:18:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439146582303576064",
  "text" : "\"I know you can meet the challenge if you make the effort.\" \u2014President Obama to young boys of color #MyBrothersKeeper",
  "id" : 439146582303576064,
  "created_at" : "2014-02-27 21:14:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 30, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/QpsTGVRto8",
      "expanded_url" : "http:\/\/go.wh.gov\/yrSQFA",
      "display_url" : "go.wh.gov\/yrSQFA"
    } ]
  },
  "geo" : { },
  "id_str" : "439145984422334464",
  "text" : "President Obama: \"That\u2019s what #MyBrothersKeeper is all about: Helping more of our young people stay on track.\" http:\/\/t.co\/QpsTGVRto8",
  "id" : 439145984422334464,
  "created_at" : "2014-02-27 21:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439145788061786112",
  "text" : "RT @WHLive: President Obama: \"By giving more of our young men access to mentors...we can keep them from falling through the cracks\" #MyBrot\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 120, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439145723641491456",
    "text" : "President Obama: \"By giving more of our young men access to mentors...we can keep them from falling through the cracks\" #MyBrothersKeeper",
    "id" : 439145723641491456,
    "created_at" : "2014-02-27 21:11:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 439145788061786112,
  "created_at" : "2014-02-27 21:11:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439143665278394369",
  "text" : "RT @WHLive: Obama: \"Giving every young person who\u2019s willing to work hard a shot at opportunity should not be a partisan issue.\" #MyBrothers\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 116, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439143635024883712",
    "text" : "Obama: \"Giving every young person who\u2019s willing to work hard a shot at opportunity should not be a partisan issue.\" #MyBrothersKeeper",
    "id" : 439143635024883712,
    "created_at" : "2014-02-27 21:02:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 439143665278394369,
  "created_at" : "2014-02-27 21:03:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439143182082002944",
  "text" : "Obama: \"We all have a job to do and we can do it together\u2014black and white; urban and rural; Democrat and Republican.\" #MyBrothersKeeper",
  "id" : 439143182082002944,
  "created_at" : "2014-02-27 21:01:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439142931828846593",
  "text" : "President Obama: \"Nothing keeps a young man out of trouble like a father who takes an active role in his son\u2019s life.\" #MyBrothersKeeper",
  "id" : 439142931828846593,
  "created_at" : "2014-02-27 21:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439142273574797312",
  "text" : "Obama: \"In the aftermath of the Trayvon Martin verdict, I spoke about the need to bolster and reinforce our young men.\" #MyBrothersKeeper",
  "id" : 439142273574797312,
  "created_at" : "2014-02-27 20:57:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 115, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439141782983823360",
  "text" : "Obama: \"I believe the continuing struggles of so many boys and young men...this is a moral issue for our country.\" #MyBrothersKeeper",
  "id" : 439141782983823360,
  "created_at" : "2014-02-27 20:55:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 126, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439141426149195777",
  "text" : "\"These statistics should break our hearts, &amp; they should compel us to act.\" \u2014Obama on the need to help young men of color #MyBrothersKeeper",
  "id" : 439141426149195777,
  "created_at" : "2014-02-27 20:54:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 127, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439140515041517568",
  "text" : "Obama: \"The group that is facing some of the most severe challenges in 21st century America is boys &amp; young men of color.\" #MyBrothersKeeper",
  "id" : 439140515041517568,
  "created_at" : "2014-02-27 20:50:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 21, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439140327753281537",
  "text" : "RT @WHLive: Obama on #OpportunityForAll: \"That means guaranteeing every child in America access to a world-class education.\" http:\/\/t.co\/vr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/439140174149484545\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/vrgXIx5gr0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhgjqV8IAAAG0jD.jpg",
        "id_str" : "439140174019428352",
        "id" : 439140174019428352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhgjqV8IAAAG0jD.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/vrgXIx5gr0"
      } ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 9, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439140174149484545",
    "text" : "Obama on #OpportunityForAll: \"That means guaranteeing every child in America access to a world-class education.\" http:\/\/t.co\/vrgXIx5gr0",
    "id" : 439140174149484545,
    "created_at" : "2014-02-27 20:49:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 439140327753281537,
  "created_at" : "2014-02-27 20:49:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 106, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439139674473635840",
  "text" : "\"They never gave up on me, and so I didn\u2019t give up on myself.\" \u2014Obama on teachers that helped him succeed #MyBrothersKeeper",
  "id" : 439139674473635840,
  "created_at" : "2014-02-27 20:47:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 94, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439139493430714369",
  "text" : "\"I could see myself in them.\" \u2014Obama on helping young men of color reach their full potential #MyBrothersKeeper",
  "id" : 439139493430714369,
  "created_at" : "2014-02-27 20:46:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439139386094260224",
  "text" : "\"When I was their age, I was a lot like them. I didn\u2019t have a dad in my life. I was angry about it.\" \u2014Obama on the need to help young men",
  "id" : 439139386094260224,
  "created_at" : "2014-02-27 20:46:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 91, 96 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 1, 18 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ORZdLkPGH9",
      "expanded_url" : "http:\/\/huff.to\/1fMvBxF",
      "display_url" : "huff.to\/1fMvBxF"
    } ]
  },
  "geo" : { },
  "id_str" : "439132971862609921",
  "text" : "\"#MyBrothersKeeper: A new White House initiative to empower boys and young men of color.\" \u2014@VJ44: http:\/\/t.co\/ORZdLkPGH9 #OpportunityForAll",
  "id" : 439132971862609921,
  "created_at" : "2014-02-27 20:20:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 42, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/QpsTGVRto8",
      "expanded_url" : "http:\/\/go.wh.gov\/yrSQFA",
      "display_url" : "go.wh.gov\/yrSQFA"
    } ]
  },
  "geo" : { },
  "id_str" : "439127576200896512",
  "text" : "At 3:25pm ET, President Obama will launch #MyBrothersKeeper to create more opportunity for young men of color \u2192 http:\/\/t.co\/QpsTGVRto8",
  "id" : 439127576200896512,
  "created_at" : "2014-02-27 19:59:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/439111059828244480\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/7qErrkjrhG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhgJLqsCcAAoM6l.jpg",
      "id_str" : "439111059710832640",
      "id" : 439111059710832640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhgJLqsCcAAoM6l.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7qErrkjrhG"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 73, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/cUJDdroqli",
      "expanded_url" : "http:\/\/go.wh.gov\/jhnHr8",
      "display_url" : "go.wh.gov\/jhnHr8"
    } ]
  },
  "geo" : { },
  "id_str" : "439111059828244480",
  "text" : "Get your popcorn ready! Tune in tomorrow at 3:30pm ET for the first-ever #WHFilmFest: http:\/\/t.co\/cUJDdroqli, http:\/\/t.co\/7qErrkjrhG",
  "id" : 439111059828244480,
  "created_at" : "2014-02-27 18:53:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Seth Meyers",
      "screen_name" : "sethmeyers",
      "indices" : [ 55, 66 ],
      "id_str" : "44039298",
      "id" : 44039298
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 82, 85 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingPeek",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/mQThrCFQdx",
      "expanded_url" : "http:\/\/go.wh.gov\/7AYfqJ",
      "display_url" : "go.wh.gov\/7AYfqJ"
    } ]
  },
  "geo" : { },
  "id_str" : "439108294654066688",
  "text" : "RT @VP: You really need to watch this: Amy Poehler and @sethmeyers backstage with @VP Biden \u2192 http:\/\/t.co\/mQThrCFQdx #WestWingPeek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Seth Meyers",
        "screen_name" : "sethmeyers",
        "indices" : [ 47, 58 ],
        "id_str" : "44039298",
        "id" : 44039298
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 74, 77 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WestWingPeek",
        "indices" : [ 109, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/mQThrCFQdx",
        "expanded_url" : "http:\/\/go.wh.gov\/7AYfqJ",
        "display_url" : "go.wh.gov\/7AYfqJ"
      } ]
    },
    "geo" : { },
    "id_str" : "439107735813373952",
    "text" : "You really need to watch this: Amy Poehler and @sethmeyers backstage with @VP Biden \u2192 http:\/\/t.co\/mQThrCFQdx #WestWingPeek",
    "id" : 439107735813373952,
    "created_at" : "2014-02-27 18:40:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 439108294654066688,
  "created_at" : "2014-02-27 18:42:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KIPP_DC",
      "screen_name" : "KIPP_DC",
      "indices" : [ 3, 11 ],
      "id_str" : "1359342930",
      "id" : 1359342930
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 77, 88 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 52, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439104208630218752",
  "text" : "RT @KIPP_DC: KIPP DC is proud to join the launch of #MyBrothersKeeper at the @WhiteHouse today. Thank you, Mr. President for expanding #Opp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 64, 75 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 39, 56 ]
      }, {
        "text" : "OpportunityForAll",
        "indices" : [ 122, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439041905155125248",
    "text" : "KIPP DC is proud to join the launch of #MyBrothersKeeper at the @WhiteHouse today. Thank you, Mr. President for expanding #OpportunityForAll",
    "id" : 439041905155125248,
    "created_at" : "2014-02-27 14:18:41 +0000",
    "user" : {
      "name" : "KIPP_DC",
      "screen_name" : "KIPP_DC",
      "protected" : false,
      "id_str" : "1359342930",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762746251653816320\/VjRsHYrC_normal.jpg",
      "id" : 1359342930,
      "verified" : false
    }
  },
  "id" : 439104208630218752,
  "created_at" : "2014-02-27 18:26:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 126, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/bJGWcmaZzT",
      "expanded_url" : "http:\/\/go.wh.gov\/TjXn6o",
      "display_url" : "go.wh.gov\/TjXn6o"
    } ]
  },
  "geo" : { },
  "id_str" : "439093963312480260",
  "text" : "Here's how businesses &amp; foundations are answering the President's call to help young men of color: http:\/\/t.co\/bJGWcmaZzT #MyBrothersKeeper",
  "id" : 439093963312480260,
  "created_at" : "2014-02-27 17:45:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/oDqMXO4XjC",
      "expanded_url" : "http:\/\/go.wh.gov\/FTaEzd",
      "display_url" : "go.wh.gov\/FTaEzd"
    } ]
  },
  "geo" : { },
  "id_str" : "439084020513898496",
  "text" : "RT @Cecilia44: Why we\u2019re acting: By 4th grade, 86% of AfAm &amp; 82% of Hispanic boys read below proficiency levels.  http:\/\/t.co\/oDqMXO4XjC #M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 126, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/oDqMXO4XjC",
        "expanded_url" : "http:\/\/go.wh.gov\/FTaEzd",
        "display_url" : "go.wh.gov\/FTaEzd"
      } ]
    },
    "geo" : { },
    "id_str" : "439083692808753153",
    "text" : "Why we\u2019re acting: By 4th grade, 86% of AfAm &amp; 82% of Hispanic boys read below proficiency levels.  http:\/\/t.co\/oDqMXO4XjC #MyBrothersKeeper",
    "id" : 439083692808753153,
    "created_at" : "2014-02-27 17:04:44 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 439084020513898496,
  "created_at" : "2014-02-27 17:06:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439075629196402688",
  "text" : "RT @FLOTUS: \"You...should be able to walk into a grocery store, pick an item off the shelf &amp; tell whether it\u2019s good for your family.\" \u2014FLOT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 134, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439074742537289728",
    "text" : "\"You...should be able to walk into a grocery store, pick an item off the shelf &amp; tell whether it\u2019s good for your family.\" \u2014FLOTUS #LetsMove",
    "id" : 439074742537289728,
    "created_at" : "2014-02-27 16:29:10 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 439075629196402688,
  "created_at" : "2014-02-27 16:32:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439075418994655233",
  "text" : "RT @FLOTUS: \"For the 1st time since the nutrition label was developed...we\u2019re overhauling these labels to make them easier to read &amp; unders\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439074467332251648",
    "text" : "\"For the 1st time since the nutrition label was developed...we\u2019re overhauling these labels to make them easier to read &amp; understand\" \u2014FLOTUS",
    "id" : 439074467332251648,
    "created_at" : "2014-02-27 16:28:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 439075418994655233,
  "created_at" : "2014-02-27 16:31:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 32, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/tXlL9oOZXq",
      "expanded_url" : "http:\/\/go.wh.gov\/FTaEzd",
      "display_url" : "go.wh.gov\/FTaEzd"
    } ]
  },
  "geo" : { },
  "id_str" : "439072462698209280",
  "text" : "Today, President Obama launches #MyBrothersKeeper to make sure more young men of color have opportunities to succeed: http:\/\/t.co\/tXlL9oOZXq",
  "id" : 439072462698209280,
  "created_at" : "2014-02-27 16:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/w2XKEJTGQH",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "439069292903292928",
  "text" : "RT @FLOTUS: Happening now: The First Lady makes an important announcement on the Nutrition Facts label. Watch \u2192 http:\/\/t.co\/w2XKEJTGQH #Let\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/w2XKEJTGQH",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "439069179321548800",
    "text" : "Happening now: The First Lady makes an important announcement on the Nutrition Facts label. Watch \u2192 http:\/\/t.co\/w2XKEJTGQH #LetsMove",
    "id" : 439069179321548800,
    "created_at" : "2014-02-27 16:07:04 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 439069292903292928,
  "created_at" : "2014-02-27 16:07:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CC Sabathia",
      "screen_name" : "CC_Sabathia",
      "indices" : [ 3, 15 ],
      "id_str" : "19238073",
      "id" : 19238073
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gameplan",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "getcovered",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "GP4Me",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/49TqiDLUmc",
      "expanded_url" : "http:\/\/bit.ly\/LPef8t",
      "display_url" : "bit.ly\/LPef8t"
    } ]
  },
  "geo" : { },
  "id_str" : "439060402484555776",
  "text" : "RT @CC_Sabathia: Success starts with a #gameplan visit http:\/\/t.co\/49TqiDLUmc to learn more! #getcovered  #GP4Me",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gameplan",
        "indices" : [ 22, 31 ]
      }, {
        "text" : "getcovered",
        "indices" : [ 76, 87 ]
      }, {
        "text" : "GP4Me",
        "indices" : [ 89, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/49TqiDLUmc",
        "expanded_url" : "http:\/\/bit.ly\/LPef8t",
        "display_url" : "bit.ly\/LPef8t"
      } ]
    },
    "geo" : { },
    "id_str" : "439051202282926080",
    "text" : "Success starts with a #gameplan visit http:\/\/t.co\/49TqiDLUmc to learn more! #getcovered  #GP4Me",
    "id" : 439051202282926080,
    "created_at" : "2014-02-27 14:55:38 +0000",
    "user" : {
      "name" : "CC Sabathia",
      "screen_name" : "CC_Sabathia",
      "protected" : false,
      "id_str" : "19238073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582899872099090432\/fxhEos-P_normal.png",
      "id" : 19238073,
      "verified" : true
    }
  },
  "id" : 439060402484555776,
  "created_at" : "2014-02-27 15:32:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438844239040884738\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/hRQDoWs5DU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhcWgptCMAEwJka.jpg",
      "id_str" : "438844238898278401",
      "id" : 438844238898278401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhcWgptCMAEwJka.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/hRQDoWs5DU"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438844239040884738",
  "text" : "\"The best airports and the best roads and the best trains should be right here in America.\" \u2014Obama #RebuildAmerica http:\/\/t.co\/hRQDoWs5DU",
  "id" : 438844239040884738,
  "created_at" : "2014-02-27 01:13:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grand Canyon NPS",
      "screen_name" : "GrandCanyonNPS",
      "indices" : [ 21, 36 ],
      "id_str" : "212304085",
      "id" : 212304085
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438821119139651584\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/bmzVrv8aX2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhcBe44CAAAyxyH.jpg",
      "id_str" : "438821118867013632",
      "id" : 438821118867013632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhcBe44CAAAyxyH.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/bmzVrv8aX2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/Rc9ZYU4a2G",
      "expanded_url" : "http:\/\/go.wh.gov\/xXNHYf",
      "display_url" : "go.wh.gov\/xXNHYf"
    } ]
  },
  "geo" : { },
  "id_str" : "438821119139651584",
  "text" : "Happy 95th birthday, @GrandCanyonNPS! http:\/\/t.co\/Rc9ZYU4a2G http:\/\/t.co\/bmzVrv8aX2",
  "id" : 438821119139651584,
  "created_at" : "2014-02-26 23:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xwCIy7JwiC",
      "expanded_url" : "http:\/\/yhoo.it\/1gD23jW",
      "display_url" : "yhoo.it\/1gD23jW"
    } ]
  },
  "geo" : { },
  "id_str" : "438809334370545664",
  "text" : "RT @arneduncan: Really thoughtful piece on President Obama\u2019s commitment to the My Brother\u2019s Keeper Initiative: http:\/\/t.co\/xwCIy7JwiC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/xwCIy7JwiC",
        "expanded_url" : "http:\/\/yhoo.it\/1gD23jW",
        "display_url" : "yhoo.it\/1gD23jW"
      } ]
    },
    "geo" : { },
    "id_str" : "438803798870740992",
    "text" : "Really thoughtful piece on President Obama\u2019s commitment to the My Brother\u2019s Keeper Initiative: http:\/\/t.co\/xwCIy7JwiC",
    "id" : 438803798870740992,
    "created_at" : "2014-02-26 22:32:32 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 438809334370545664,
  "created_at" : "2014-02-26 22:54:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raisethewage",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438800781186457600",
  "text" : "RT @NancyPelosi: 107 House Dems\u2014and counting!\u2014have signed the discharge petition to #raisethewage to $10.10! We will give America a raise! \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rep. Barbara Lee",
        "screen_name" : "RepBarbaraLee",
        "indices" : [ 122, 136 ],
        "id_str" : "248735463",
        "id" : 248735463
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "raisethewage",
        "indices" : [ 67, 80 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "438793682070695936",
    "geo" : { },
    "id_str" : "438794060816719872",
    "in_reply_to_user_id" : 248735463,
    "text" : "107 House Dems\u2014and counting!\u2014have signed the discharge petition to #raisethewage to $10.10! We will give America a raise! @RepBarbaraLee",
    "id" : 438794060816719872,
    "in_reply_to_status_id" : 438793682070695936,
    "created_at" : "2014-02-26 21:53:51 +0000",
    "in_reply_to_screen_name" : "RepBarbaraLee",
    "in_reply_to_user_id_str" : "248735463",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 438800781186457600,
  "created_at" : "2014-02-26 22:20:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 3, 19 ],
      "id_str" : "234141596",
      "id" : 234141596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438797024226738176",
  "text" : "RT @GovMalloyOffice: Excited to welcome President Obama to CT on Wed for a #RaiseTheWage event. RT if you agree America deserves a raise. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GovMalloyOffice\/status\/438795711404994560\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/aGr8uFG8Uh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhbqX-vCcAAjxlm.jpg",
        "id_str" : "438795711413383168",
        "id" : 438795711413383168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhbqX-vCcAAjxlm.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/aGr8uFG8Uh"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 54, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438795711404994560",
    "text" : "Excited to welcome President Obama to CT on Wed for a #RaiseTheWage event. RT if you agree America deserves a raise. http:\/\/t.co\/aGr8uFG8Uh",
    "id" : 438795711404994560,
    "created_at" : "2014-02-26 22:00:24 +0000",
    "user" : {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "protected" : false,
      "id_str" : "234141596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738519424223858688\/_0xQvvKS_normal.jpg",
      "id" : 234141596,
      "verified" : true
    }
  },
  "id" : 438797024226738176,
  "created_at" : "2014-02-26 22:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 16, 27 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Discovery Education",
      "screen_name" : "DiscoveryEd",
      "indices" : [ 34, 46 ],
      "id_str" : "1665531",
      "id" : 1665531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureNow",
      "indices" : [ 116, 126 ]
    }, {
      "text" : "ConnectED",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/YHsnQLfwBC",
      "expanded_url" : "http:\/\/go.wh.gov\/FEytDp",
      "display_url" : "go.wh.gov\/FEytDp"
    } ]
  },
  "geo" : { },
  "id_str" : "438788567255744512",
  "text" : "Right now: Join @ArneDuncan for a @DiscoveryEd chat on the transition to digital classrooms: http:\/\/t.co\/YHsnQLfwBC #FutureNow #ConnectED",
  "id" : 438788567255744512,
  "created_at" : "2014-02-26 21:32:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438784326894108672",
  "text" : "RT @WHLive: Obama: \"Let\u2019s create more good jobs building smarter schools, better airports, faster railways and broadband networks.\" #Rebuil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 120, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438781271041638400",
    "text" : "Obama: \"Let\u2019s create more good jobs building smarter schools, better airports, faster railways and broadband networks.\" #RebuildAmerica",
    "id" : 438781271041638400,
    "created_at" : "2014-02-26 21:03:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 438784326894108672,
  "created_at" : "2014-02-26 21:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 68, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438781030498308098",
  "text" : "\"Roads and bridges shouldn\u2019t be a partisan issue.\" \u2014President Obama #RebuildAmerica",
  "id" : 438781030498308098,
  "created_at" : "2014-02-26 21:02:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438778516050804738",
  "text" : "Obama: \"The best airports and the best trains and the best roads should be right here in America.\" #RebuildAmerica",
  "id" : 438778516050804738,
  "created_at" : "2014-02-26 20:52:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438778366616166400",
  "text" : "RT @WHLive: \"We\u2019ve got more than 100,000 bridges that are old enough to qualify for Medicare.\" \u2014President Obama #RebuildAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438778136378241024",
    "text" : "\"We\u2019ve got more than 100,000 bridges that are old enough to qualify for Medicare.\" \u2014President Obama #RebuildAmerica",
    "id" : 438778136378241024,
    "created_at" : "2014-02-26 20:50:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 438778366616166400,
  "created_at" : "2014-02-26 20:51:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438778021072601088",
  "text" : "RT @WHLive: President Obama: \"One of the fastest and best ways to create good jobs is by rebuilding America\u2019s infrastructure.\" #RebuildAmer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 115, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438777876591435777",
    "text" : "President Obama: \"One of the fastest and best ways to create good jobs is by rebuilding America\u2019s infrastructure.\" #RebuildAmerica",
    "id" : 438777876591435777,
    "created_at" : "2014-02-26 20:49:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 438778021072601088,
  "created_at" : "2014-02-26 20:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438777666464796673\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/VqktRFCawg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhbZ9nXCQAABXwM.jpg",
      "id_str" : "438777666276048896",
      "id" : 438777666276048896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhbZ9nXCQAABXwM.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/VqktRFCawg"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 1, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438777666464796673",
  "text" : "\"#EqualPay for equal work, paid sick leave...when women succeed, America succeeds.\" \u2014Obama http:\/\/t.co\/VqktRFCawg",
  "id" : 438777666464796673,
  "created_at" : "2014-02-26 20:48:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438777451661893632\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/g70j6I3Eda",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhbZxHeCIAAesKS.jpg",
      "id_str" : "438777451557036032",
      "id" : 438777451557036032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhbZxHeCIAAesKS.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g70j6I3Eda"
    } ],
    "hashtags" : [ {
      "text" : "Minnesota",
      "indices" : [ 83, 93 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438777451661893632",
  "text" : "\"Your state legislature is poised to raise your minimum wage this year.\" \u2014Obama in #Minnesota #RaiseTheWage http:\/\/t.co\/g70j6I3Eda",
  "id" : 438777451661893632,
  "created_at" : "2014-02-26 20:47:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/TN2wAqzgp0",
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434725519654133760",
      "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438776980147011584",
  "text" : "\"T.J\u2019s shootout performance against the Russians\u2026I enjoyed a lot. I tweeted at him.\" \u2014Obama on T.J. Oshie: https:\/\/t.co\/TN2wAqzgp0",
  "id" : 438776980147011584,
  "created_at" : "2014-02-26 20:45:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Minnesota",
      "indices" : [ 1, 11 ]
    }, {
      "text" : "GoTeamUSA",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438776815835181057",
  "text" : "\"#Minnesota sent 19 athletes to the games. That's tied for the second most of any state. They did us all proud.\" \u2014President Obama #GoTeamUSA",
  "id" : 438776815835181057,
  "created_at" : "2014-02-26 20:45:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/HTJYMRYanE",
      "expanded_url" : "http:\/\/go.wh.gov\/CwFBge",
      "display_url" : "go.wh.gov\/CwFBge"
    } ]
  },
  "geo" : { },
  "id_str" : "438774501896355840",
  "text" : "Right now: President Obama lays out his plan to put Americans to work rebuilding our infrastructure \u2192 http:\/\/t.co\/HTJYMRYanE #RebuildAmerica",
  "id" : 438774501896355840,
  "created_at" : "2014-02-26 20:36:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/GsId1YF2tN",
      "expanded_url" : "http:\/\/go.wh.gov\/7RSvx2",
      "display_url" : "go.wh.gov\/7RSvx2"
    } ]
  },
  "geo" : { },
  "id_str" : "438760510566051841",
  "text" : "President Obama's launching a new competition to put Americans to work repairing our infrastructure: http:\/\/t.co\/GsId1YF2tN #RebuildAmerica",
  "id" : 438760510566051841,
  "created_at" : "2014-02-26 19:40:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438753463954968576\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/w8akiIVJk8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhbD81iCIAA__bN.jpg",
      "id_str" : "438753463644594176",
      "id" : 438753463644594176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhbD81iCIAA__bN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/w8akiIVJk8"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438753463954968576",
  "text" : "Raising the minimum wage to $10.10\/hr would \u2191 wages for 16.5 million Americans.\n\nLet's make it happen. #RaiseTheWage http:\/\/t.co\/w8akiIVJk8",
  "id" : 438753463954968576,
  "created_at" : "2014-02-26 19:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438739120647450624",
  "text" : "\"It will help me save money to go to the college of my dreams and help me lift the burden off my mother.\" \u2014Shelby S. from CA #RaiseTheWage",
  "id" : 438739120647450624,
  "created_at" : "2014-02-26 18:15:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "indices" : [ 3, 14 ],
      "id_str" : "17494010",
      "id" : 17494010
    }, {
      "name" : "Sam Stein",
      "screen_name" : "samsteinhp",
      "indices" : [ 17, 28 ],
      "id_str" : "15463671",
      "id" : 15463671
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GotCovered",
      "indices" : [ 54, 65 ]
    }, {
      "text" : "ACAworks",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438733939919032320",
  "text" : "RT @SenSchumer: .@SamSteinHP reports 4 Million people #GotCovered so far - that's 4 Million more stories that prove #ACAworks http:\/\/t.co\/j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Stein",
        "screen_name" : "samsteinhp",
        "indices" : [ 1, 12 ],
        "id_str" : "15463671",
        "id" : 15463671
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GotCovered",
        "indices" : [ 38, 49 ]
      }, {
        "text" : "ACAworks",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/jKdQt2HgTK",
        "expanded_url" : "http:\/\/ow.ly\/u1mP1",
        "display_url" : "ow.ly\/u1mP1"
      } ]
    },
    "geo" : { },
    "id_str" : "438704255823007744",
    "text" : ".@SamSteinHP reports 4 Million people #GotCovered so far - that's 4 Million more stories that prove #ACAworks http:\/\/t.co\/jKdQt2HgTK",
    "id" : 438704255823007744,
    "created_at" : "2014-02-26 15:56:59 +0000",
    "user" : {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "protected" : false,
      "id_str" : "17494010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623955176131575808\/zWzgRP4C_normal.jpg",
      "id" : 17494010,
      "verified" : true
    }
  },
  "id" : 438733939919032320,
  "created_at" : "2014-02-26 17:54:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438730310771941376",
  "text" : "\"This would help out single parents like me to...finish raising their kids alone on 1 income.\" \u2014Idrissa S. on why it's time to #RaiseTheWage",
  "id" : 438730310771941376,
  "created_at" : "2014-02-26 17:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphyCT",
      "indices" : [ 3, 17 ],
      "id_str" : "150078976",
      "id" : 150078976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAworks",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438728786193170432",
  "text" : "RT @ChrisMurphyCT: Because of the Affordable Care Act, the cost to seniors for their annual checkup is $0.00. #ACAworks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAworks",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438717136882503680",
    "text" : "Because of the Affordable Care Act, the cost to seniors for their annual checkup is $0.00. #ACAworks",
    "id" : 438717136882503680,
    "created_at" : "2014-02-26 16:48:11 +0000",
    "user" : {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphyCT",
      "protected" : false,
      "id_str" : "150078976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738767780246396928\/YrcsMalf_normal.jpg",
      "id" : 150078976,
      "verified" : true
    }
  },
  "id" : 438728786193170432,
  "created_at" : "2014-02-26 17:34:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 129, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438725277938483204",
  "text" : "Malissa M. on raising the min wage: \"It would give me a chance to save something for the future of my kids &amp; grandchildren.\" #RaiseTheWage",
  "id" : 438725277938483204,
  "created_at" : "2014-02-26 17:20:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438720247705509888",
  "text" : "\"Raising the minimum wage will allow...my family to...not worry about living...paycheck to paycheck.\" \u2014Vennatte E. from TX #RaiseTheWage",
  "id" : 438720247705509888,
  "created_at" : "2014-02-26 17:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438715603453366273\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/kjwE0x2zBo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhahhEuCcAAOHQC.jpg",
      "id_str" : "438715603289796608",
      "id" : 438715603289796608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhahhEuCcAAOHQC.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kjwE0x2zBo"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 56, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/AhqTLtgYTL",
      "expanded_url" : "http:\/\/go.wh.gov\/pohkPx",
      "display_url" : "go.wh.gov\/pohkPx"
    } ]
  },
  "geo" : { },
  "id_str" : "438715603453366273",
  "text" : "Make your voice heard: Share why you agree it's time to #RaiseTheWage \u2192 http:\/\/t.co\/AhqTLtgYTL, http:\/\/t.co\/kjwE0x2zBo",
  "id" : 438715603453366273,
  "created_at" : "2014-02-26 16:42:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438697081243303936\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/r4UhUM9tcy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhaQq8JCEAEpQUM.jpg",
      "id_str" : "438697081088118785",
      "id" : 438697081088118785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhaQq8JCEAEpQUM.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/r4UhUM9tcy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438697081243303936",
  "text" : "Snowy South Lawn. http:\/\/t.co\/r4UhUM9tcy",
  "id" : 438697081243303936,
  "created_at" : "2014-02-26 15:28:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438472040102641664\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KA2l9iMOj6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhXD_x6CYAA1NtJ.jpg",
      "id_str" : "438472039234428928",
      "id" : 438472039234428928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhXD_x6CYAA1NtJ.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KA2l9iMOj6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/s1ZDcInft1",
      "expanded_url" : "http:\/\/go.wh.gov\/m6y3WQ",
      "display_url" : "go.wh.gov\/m6y3WQ"
    } ]
  },
  "geo" : { },
  "id_str" : "438472040102641664",
  "text" : "\"We're building Iron Man\u2026not really\u2014maybe\u2014it's classified.\" \u2014Obama on boosting manufacturing: http:\/\/t.co\/s1ZDcInft1 http:\/\/t.co\/KA2l9iMOj6",
  "id" : 438472040102641664,
  "created_at" : "2014-02-26 00:34:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 39, 50 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 67, 72 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manufacturing",
      "indices" : [ 18, 32 ]
    }, {
      "text" : "MadeInAmerica",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438468606171807744",
  "text" : "RT @NASA: Awesome #manufacturing event @WhiteHouse today! Checkout @NASA 's blog about how NASA helps #MadeInAmerica stay #1: http:\/\/t.co\/O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 29, 40 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 57, 62 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "manufacturing",
        "indices" : [ 8, 22 ]
      }, {
        "text" : "MadeInAmerica",
        "indices" : [ 92, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/OlL485MKui",
        "expanded_url" : "http:\/\/go.usa.gov\/BznC",
        "display_url" : "go.usa.gov\/BznC"
      } ]
    },
    "geo" : { },
    "id_str" : "438466342803369984",
    "text" : "Awesome #manufacturing event @WhiteHouse today! Checkout @NASA 's blog about how NASA helps #MadeInAmerica stay #1: http:\/\/t.co\/OlL485MKui",
    "id" : 438466342803369984,
    "created_at" : "2014-02-26 00:11:37 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 438468606171807744,
  "created_at" : "2014-02-26 00:20:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "438463550944575489",
  "text" : "Thanks to the #ACA, 4 million Americans have signed up for private health plans. Let's help even more #GetCovered \u2192 http:\/\/t.co\/0lwMLeJwkK",
  "id" : 438463550944575489,
  "created_at" : "2014-02-26 00:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/AhgP7kq9Uu",
      "expanded_url" : "http:\/\/go.wh.gov\/VY3cjq",
      "display_url" : "go.wh.gov\/VY3cjq"
    } ]
  },
  "geo" : { },
  "id_str" : "438457092283052032",
  "text" : "Great news: 4 million Americans have signed up for private health plans through the Affordable Care Act. http:\/\/t.co\/AhgP7kq9Uu #GetCovered",
  "id" : 438457092283052032,
  "created_at" : "2014-02-25 23:34:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 102, 116 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 117, 127 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438439226074726400",
  "text" : "RT @whitehouseostp: Get your popcorn ready! It's the first-ever White House Student Film Festival, w\/ @TheScienceGuy @NeilTyson &amp; others ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Nye",
        "screen_name" : "thescienceguy",
        "indices" : [ 82, 96 ],
        "id_str" : "3028904482",
        "id" : 3028904482
      }, {
        "name" : "Neil deGrasse Tyson",
        "screen_name" : "neiltyson",
        "indices" : [ 97, 107 ],
        "id_str" : "19725644",
        "id" : 19725644
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/6g00UHp6DY",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/\/filmfestival",
        "display_url" : "whitehouse.gov\/\/filmfestival"
      } ]
    },
    "geo" : { },
    "id_str" : "438435924054392832",
    "text" : "Get your popcorn ready! It's the first-ever White House Student Film Festival, w\/ @TheScienceGuy @NeilTyson &amp; others http:\/\/t.co\/6g00UHp6DY",
    "id" : 438435924054392832,
    "created_at" : "2014-02-25 22:10:44 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 438439226074726400,
  "created_at" : "2014-02-25 22:23:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/RN7IgwIinY",
      "expanded_url" : "http:\/\/nyti.ms\/1pq55OQ",
      "display_url" : "nyti.ms\/1pq55OQ"
    } ]
  },
  "geo" : { },
  "id_str" : "438437183884898304",
  "text" : "RT @FLOTUS: Great news: The obesity rate for young children plummeted 43% over the last decade \u2192 http:\/\/t.co\/RN7IgwIinY #LetsMove",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/RN7IgwIinY",
        "expanded_url" : "http:\/\/nyti.ms\/1pq55OQ",
        "display_url" : "nyti.ms\/1pq55OQ"
      } ]
    },
    "geo" : { },
    "id_str" : "438436863083577344",
    "text" : "Great news: The obesity rate for young children plummeted 43% over the last decade \u2192 http:\/\/t.co\/RN7IgwIinY #LetsMove",
    "id" : 438436863083577344,
    "created_at" : "2014-02-25 22:14:28 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 438437183884898304,
  "created_at" : "2014-02-25 22:15:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Joe Kennedy III",
      "screen_name" : "RepJoeKennedy",
      "indices" : [ 3, 17 ],
      "id_str" : "1055907624",
      "id" : 1055907624
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Tom Reed",
      "screen_name" : "RepTomReed",
      "indices" : [ 115, 126 ],
      "id_str" : "252819323",
      "id" : 252819323
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manufacturing",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438431299091824640",
  "text" : "RT @RepJoeKennedy: Great #manufacturing event @WhiteHouse today. Appreciated the shout-out to our bipartisan bill  @RepTomReed @SenSherrodB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 27, 38 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Tom Reed",
        "screen_name" : "RepTomReed",
        "indices" : [ 96, 107 ],
        "id_str" : "252819323",
        "id" : 252819323
      }, {
        "name" : "Sherrod Brown",
        "screen_name" : "SenSherrodBrown",
        "indices" : [ 108, 124 ],
        "id_str" : "43910797",
        "id" : 43910797
      }, {
        "name" : "Senator Roy Blunt",
        "screen_name" : "RoyBlunt",
        "indices" : [ 125, 134 ],
        "id_str" : "21269970",
        "id" : 21269970
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "manufacturing",
        "indices" : [ 6, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438419430620819456",
    "text" : "Great #manufacturing event @WhiteHouse today. Appreciated the shout-out to our bipartisan bill  @RepTomReed @SenSherrodBrown @RoyBlunt",
    "id" : 438419430620819456,
    "created_at" : "2014-02-25 21:05:12 +0000",
    "user" : {
      "name" : "Rep. Joe Kennedy III",
      "screen_name" : "RepJoeKennedy",
      "protected" : false,
      "id_str" : "1055907624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775775331605241856\/mWMJIZHq_normal.jpg",
      "id" : 1055907624,
      "verified" : true
    }
  },
  "id" : 438431299091824640,
  "created_at" : "2014-02-25 21:52:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 33, 40 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438421906363256832",
  "text" : "RT @PennyPritzker: Just met with @Google to discuss how business, tech &amp; govt can work together to help unleash America's entrepreneurial e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Google",
        "screen_name" : "google",
        "indices" : [ 14, 21 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438416574559817729",
    "text" : "Just met with @Google to discuss how business, tech &amp; govt can work together to help unleash America's entrepreneurial energy.",
    "id" : 438416574559817729,
    "created_at" : "2014-02-25 20:53:51 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 438421906363256832,
  "created_at" : "2014-02-25 21:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438413666409791488",
  "text" : "Obama: \"If we stay focused on winning this race, we will make sure the next revolution in manufacturing is an American revolution.\"",
  "id" : 438413666409791488,
  "created_at" : "2014-02-25 20:42:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438413486558052352",
  "text" : "RT @WHLive: Obama: \"Thanks in part to our investments...factories that once went dark are turning on the lights again.\" #MadeInAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 108, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438413375434158080",
    "text" : "Obama: \"Thanks in part to our investments...factories that once went dark are turning on the lights again.\" #MadeInAmerica",
    "id" : 438413375434158080,
    "created_at" : "2014-02-25 20:41:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 438413486558052352,
  "created_at" : "2014-02-25 20:41:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438411786451419136",
  "text" : "RT @WHLive: Obama: \"Since we stepped in to help our automakers retool, the American auto industry has created almost 425,000 new jobs.\" #Ac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnJobs",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438411708332507136",
    "text" : "Obama: \"Since we stepped in to help our automakers retool, the American auto industry has created almost 425,000 new jobs.\" #ActOnJobs",
    "id" : 438411708332507136,
    "created_at" : "2014-02-25 20:34:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 438411786451419136,
  "created_at" : "2014-02-25 20:34:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438411447836880899",
  "text" : "Obama: \"I don't want the next big job-creating discovery to come from Germany or China or Japan. I want it to be made here in America.\"",
  "id" : 438411447836880899,
  "created_at" : "2014-02-25 20:33:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438410839021060096",
  "text" : "President Obama: \"Today, our manufacturers have added more than 620,000 new manufacturing jobs over the last 4 years.\" #ActOnJobs",
  "id" : 438410839021060096,
  "created_at" : "2014-02-25 20:31:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438410056007426048",
  "text" : "RT @WHLive: Obama: \"My Administration has launched 2 hubs for high-tech manufacturing...on 3-D printing and...energy-efficient electronics.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnJobs",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438409993327738881",
    "text" : "Obama: \"My Administration has launched 2 hubs for high-tech manufacturing...on 3-D printing and...energy-efficient electronics.\" #ActOnJobs",
    "id" : 438409993327738881,
    "created_at" : "2014-02-25 20:27:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 438410056007426048,
  "created_at" : "2014-02-25 20:27:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/438409896568971265\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/w7TtATr4Rh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhWLel1CYAA7S5v.jpg",
      "id_str" : "438409896405393408",
      "id" : 438409896405393408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhWLel1CYAA7S5v.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/w7TtATr4Rh"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438410015725338624",
  "text" : "RT @WHLive: President Obama: \"Four: Make sure hard work pays off for every American.\" #RaiseTheWage, http:\/\/t.co\/w7TtATr4Rh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/438409896568971265\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/w7TtATr4Rh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhWLel1CYAA7S5v.jpg",
        "id_str" : "438409896405393408",
        "id" : 438409896405393408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhWLel1CYAA7S5v.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/w7TtATr4Rh"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 74, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438409896568971265",
    "text" : "President Obama: \"Four: Make sure hard work pays off for every American.\" #RaiseTheWage, http:\/\/t.co\/w7TtATr4Rh",
    "id" : 438409896568971265,
    "created_at" : "2014-02-25 20:27:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 438410015725338624,
  "created_at" : "2014-02-25 20:27:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438409121285816320",
  "text" : "\"I\u2019m here to announce that we\u2019re building Iron Man\u2026Not really. Maybe. It\u2019s classified.\" \u2014President Obama #ActOnJobs",
  "id" : 438409121285816320,
  "created_at" : "2014-02-25 20:24:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0438\u043D\u043E\u0433\u0440\u0430\u0434\u043E\u0432   \u0421\u043F\u0438\u0440\u0438\u0434\u043E",
      "screen_name" : "john_dingell",
      "indices" : [ 96, 109 ],
      "id_str" : "2982226132",
      "id" : 2982226132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438408950858670080",
  "text" : "\"We are better off because of John's service, and we're going to miss you.\" \u2014President Obama on @John_Dingell at an event on manufacturing",
  "id" : 438408950858670080,
  "created_at" : "2014-02-25 20:23:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/XdSZDX5iGG",
      "expanded_url" : "http:\/\/go.wh.gov\/MV9yg5",
      "display_url" : "go.wh.gov\/MV9yg5"
    } ]
  },
  "geo" : { },
  "id_str" : "438395312290684928",
  "text" : "At 3pm ET, President Obama announces new steps to partner with the private sector to boost manufacturing: http:\/\/t.co\/XdSZDX5iGG #ActOnJobs",
  "id" : 438395312290684928,
  "created_at" : "2014-02-25 19:29:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "indices" : [ 3, 19 ],
      "id_str" : "43910797",
      "id" : 43910797
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438389496426807296",
  "text" : "RT @SenSherrodBrown: Heading to @WhiteHouse for news of 2 new manufacturing hubs, 1 co-led by OH. My bipartisan bill would create more. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 11, 22 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/SoiQaojrwb",
        "expanded_url" : "http:\/\/ow.ly\/tZrOJ",
        "display_url" : "ow.ly\/tZrOJ"
      } ]
    },
    "geo" : { },
    "id_str" : "438384566769057792",
    "text" : "Heading to @WhiteHouse for news of 2 new manufacturing hubs, 1 co-led by OH. My bipartisan bill would create more. http:\/\/t.co\/SoiQaojrwb",
    "id" : 438384566769057792,
    "created_at" : "2014-02-25 18:46:40 +0000",
    "user" : {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "protected" : false,
      "id_str" : "43910797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523158370333638657\/cLmYIfYa_normal.jpeg",
      "id" : 43910797,
      "verified" : true
    }
  },
  "id" : 438389496426807296,
  "created_at" : "2014-02-25 19:06:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438385944979595264",
  "text" : "RT @Cecilia44: FACT: A new Detroit-area manufacturing hub will bring together businesses &amp; colleges to focus on advancing lightweight metal\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438355518005182465",
    "text" : "FACT: A new Detroit-area manufacturing hub will bring together businesses &amp; colleges to focus on advancing lightweight metals manufacturing.",
    "id" : 438355518005182465,
    "created_at" : "2014-02-25 16:51:14 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 438385944979595264,
  "created_at" : "2014-02-25 18:52:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/z1uA16hjFx",
      "expanded_url" : "http:\/\/go.wh.gov\/Bb8qmr",
      "display_url" : "go.wh.gov\/Bb8qmr"
    } ]
  },
  "geo" : { },
  "id_str" : "438375467129647104",
  "text" : "FACT: U.S. manufacturing is growing at its fastest pace in more than a decade\u2014and we're building on that progress: http:\/\/t.co\/z1uA16hjFx",
  "id" : 438375467129647104,
  "created_at" : "2014-02-25 18:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/438365171409358848\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/MaBTgWyrAB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhVizPyCMAAwDAR.jpg",
      "id_str" : "438365171287732224",
      "id" : 438365171287732224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhVizPyCMAAwDAR.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MaBTgWyrAB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438365171409358848",
  "text" : "It's a winter wonderland in the Rose Garden. http:\/\/t.co\/MaBTgWyrAB",
  "id" : 438365171409358848,
  "created_at" : "2014-02-25 17:29:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438361625611878401",
  "text" : "FACT: Our manufacturers have added 622,000 jobs since early 2010\u2014including more than 80,000 over the past 4 months. #ActOnJobs",
  "id" : 438361625611878401,
  "created_at" : "2014-02-25 17:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438355595583057920",
  "text" : "RT @FLOTUS: \"Roll my chicken in a wrap, don\u2019t jam it in a nugget. Get hyped for healthy snacks, fresh food\u2014we love it!\u201D \u2014The First Lady #Le\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsWrap",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438352910863581184",
    "text" : "\"Roll my chicken in a wrap, don\u2019t jam it in a nugget. Get hyped for healthy snacks, fresh food\u2014we love it!\u201D \u2014The First Lady #LetsWrap",
    "id" : 438352910863581184,
    "created_at" : "2014-02-25 16:40:52 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 438355595583057920,
  "created_at" : "2014-02-25 16:51:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/AxAU2yECPb",
      "expanded_url" : "http:\/\/go.wh.gov\/kKwGey",
      "display_url" : "go.wh.gov\/kKwGey"
    } ]
  },
  "geo" : { },
  "id_str" : "438346055374368768",
  "text" : "Today, President Obama will announce new steps to partner with the private sector to boost manufacturing: http:\/\/t.co\/AxAU2yECPb #ActOnJobs",
  "id" : 438346055374368768,
  "created_at" : "2014-02-25 16:13:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/1w7cU9F9lb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "438343449964986368",
  "text" : "RT @FLOTUS: Happening now: The First Lady makes an important announcement on promoting school wellness \u2192 http:\/\/t.co\/1w7cU9F9lb #LetsMove",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 116, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/1w7cU9F9lb",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "438342980253282305",
    "text" : "Happening now: The First Lady makes an important announcement on promoting school wellness \u2192 http:\/\/t.co\/1w7cU9F9lb #LetsMove",
    "id" : 438342980253282305,
    "created_at" : "2014-02-25 16:01:25 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 438343449964986368,
  "created_at" : "2014-02-25 16:03:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438331600615395328\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/mXCYdQFnsh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhVERKrCcAAowy8.png",
      "id_str" : "438331600451825664",
      "id" : 438331600451825664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhVERKrCcAAowy8.png",
      "sizes" : [ {
        "h" : 442,
        "resize" : "fit",
        "w" : 776
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 194,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 776
      }, {
        "h" : 342,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mXCYdQFnsh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438331600615395328",
  "text" : "Obama: \"Michelle and I were saddened to hear of the passing of Harold Ramis, one of America\u2019s greatest satirists.\" http:\/\/t.co\/mXCYdQFnsh",
  "id" : 438331600615395328,
  "created_at" : "2014-02-25 15:16:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Parks and Recreation",
      "screen_name" : "parksandrecnbc",
      "indices" : [ 19, 34 ],
      "id_str" : "20630639",
      "id" : 20630639
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438324118099091456",
  "text" : "RT @FLOTUS: Today, @ParksandRecNBC will come to life when Amy Poehler &amp; the First Lady join kids at a Miami Parks &amp; Rec center to get activ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Parks and Recreation",
        "screen_name" : "parksandrecnbc",
        "indices" : [ 7, 22 ],
        "id_str" : "20630639",
        "id" : 20630639
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 138, 147 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438310071488229376",
    "text" : "Today, @ParksandRecNBC will come to life when Amy Poehler &amp; the First Lady join kids at a Miami Parks &amp; Rec center to get active. #LetsMove",
    "id" : 438310071488229376,
    "created_at" : "2014-02-25 13:50:39 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 438324118099091456,
  "created_at" : "2014-02-25 14:46:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/438092272047890434\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ETsTdzbnkm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhRqmZ8CMAAfpcM.jpg",
      "id_str" : "438092271792041984",
      "id" : 438092271792041984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhRqmZ8CMAAfpcM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ETsTdzbnkm"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 66, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/1e7Z1Dj69f",
      "expanded_url" : "http:\/\/go.wh.gov\/Wwt3pK",
      "display_url" : "go.wh.gov\/Wwt3pK"
    } ]
  },
  "geo" : { },
  "id_str" : "438092272047890434",
  "text" : "RT to share how President Obama's already made progress to expand #OpportunityForAll in 2014: http:\/\/t.co\/1e7Z1Dj69f http:\/\/t.co\/ETsTdzbnkm",
  "id" : 438092272047890434,
  "created_at" : "2014-02-24 23:25:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "indices" : [ 3, 14 ],
      "id_str" : "15693493",
      "id" : 15693493
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/funnyordie\/status\/438061385516212224\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/nE9O7MWnpN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhROgloCYAA0VZ-.png",
      "id_str" : "438061385524600832",
      "id" : 438061385524600832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhROgloCYAA0VZ-.png",
      "sizes" : [ {
        "h" : 786,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nE9O7MWnpN"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 65, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/ptvbuHacgT",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "438077536757886976",
  "text" : "RT @funnyordie: Don't have healthcare? Will Ferrell wants you to #GetCovered! http:\/\/t.co\/ptvbuHacgT http:\/\/t.co\/nE9O7MWnpN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/funnyordie\/status\/438061385516212224\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/nE9O7MWnpN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhROgloCYAA0VZ-.png",
        "id_str" : "438061385524600832",
        "id" : 438061385524600832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhROgloCYAA0VZ-.png",
        "sizes" : [ {
          "h" : 786,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 786,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nE9O7MWnpN"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 49, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/ptvbuHacgT",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "438061385516212224",
    "text" : "Don't have healthcare? Will Ferrell wants you to #GetCovered! http:\/\/t.co\/ptvbuHacgT http:\/\/t.co\/nE9O7MWnpN",
    "id" : 438061385516212224,
    "created_at" : "2014-02-24 21:22:27 +0000",
    "user" : {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "protected" : false,
      "id_str" : "15693493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796062959185182720\/FN6QGp0H_normal.jpg",
      "id" : 15693493,
      "verified" : true
    }
  },
  "id" : 438077536757886976,
  "created_at" : "2014-02-24 22:26:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Rick Mastracchio",
      "screen_name" : "AstroRM",
      "indices" : [ 51, 59 ],
      "id_str" : "541158674",
      "id" : 541158674
    }, {
      "name" : "Mike Hopkins",
      "screen_name" : "AstroIllini",
      "indices" : [ 66, 78 ],
      "id_str" : "543582293",
      "id" : 543582293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "ISS",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/n93koZG6Rf",
      "expanded_url" : "http:\/\/youtu.be\/20Ic-f4ab6k",
      "display_url" : "youtu.be\/20Ic-f4ab6k"
    } ]
  },
  "geo" : { },
  "id_str" : "438064671044960256",
  "text" : "RT @NASA: Marking 4 years of #LetsMove, astronauts @AstroRM &amp; @AstroIllini show us how they move on #ISS: http:\/\/t.co\/n93koZG6Rf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rick Mastracchio",
        "screen_name" : "AstroRM",
        "indices" : [ 41, 49 ],
        "id_str" : "541158674",
        "id" : 541158674
      }, {
        "name" : "Mike Hopkins",
        "screen_name" : "AstroIllini",
        "indices" : [ 56, 68 ],
        "id_str" : "543582293",
        "id" : 543582293
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 19, 28 ]
      }, {
        "text" : "ISS",
        "indices" : [ 94, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/n93koZG6Rf",
        "expanded_url" : "http:\/\/youtu.be\/20Ic-f4ab6k",
        "display_url" : "youtu.be\/20Ic-f4ab6k"
      } ]
    },
    "geo" : { },
    "id_str" : "438055444825636864",
    "text" : "Marking 4 years of #LetsMove, astronauts @AstroRM &amp; @AstroIllini show us how they move on #ISS: http:\/\/t.co\/n93koZG6Rf",
    "id" : 438055444825636864,
    "created_at" : "2014-02-24 20:58:51 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 438064671044960256,
  "created_at" : "2014-02-24 21:35:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "\u0412\u0438\u043D\u043E\u0433\u0440\u0430\u0434\u043E\u0432   \u0421\u043F\u0438\u0440\u0438\u0434\u043E",
      "screen_name" : "john_dingell",
      "indices" : [ 22, 35 ],
      "id_str" : "2982226132",
      "id" : 2982226132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438049683525885954",
  "text" : "RT @Simas44: Obama on @John_Dingell: \"He helped give millions of families the peace of mind of knowing they won\u2019t lose everything if they g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0412\u0438\u043D\u043E\u0433\u0440\u0430\u0434\u043E\u0432   \u0421\u043F\u0438\u0440\u0438\u0434\u043E",
        "screen_name" : "john_dingell",
        "indices" : [ 9, 22 ],
        "id_str" : "2982226132",
        "id" : 2982226132
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438025833593454593",
    "text" : "Obama on @John_Dingell: \"He helped give millions of families the peace of mind of knowing they won\u2019t lose everything if they get sick.\" #ACA",
    "id" : 438025833593454593,
    "created_at" : "2014-02-24 19:01:11 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 438049683525885954,
  "created_at" : "2014-02-24 20:35:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/c5lac56dgf",
      "expanded_url" : "http:\/\/go.wh.gov\/P8ZxP1",
      "display_url" : "go.wh.gov\/P8ZxP1"
    } ]
  },
  "geo" : { },
  "id_str" : "438032998316126208",
  "text" : "RT @FLOTUS: Today's #LetsMove \"focus group\":\n1. The First Lady\n2. Will Ferrell\n3. Adorable kids\nWatch \u2192 http:\/\/t.co\/c5lac56dgf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 8, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/c5lac56dgf",
        "expanded_url" : "http:\/\/go.wh.gov\/P8ZxP1",
        "display_url" : "go.wh.gov\/P8ZxP1"
      } ]
    },
    "geo" : { },
    "id_str" : "438023717919424512",
    "text" : "Today's #LetsMove \"focus group\":\n1. The First Lady\n2. Will Ferrell\n3. Adorable kids\nWatch \u2192 http:\/\/t.co\/c5lac56dgf",
    "id" : 438023717919424512,
    "created_at" : "2014-02-24 18:52:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 438032998316126208,
  "created_at" : "2014-02-24 19:29:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0438\u043D\u043E\u0433\u0440\u0430\u0434\u043E\u0432   \u0421\u043F\u0438\u0440\u0438\u0434\u043E",
      "screen_name" : "john_dingell",
      "indices" : [ 91, 104 ],
      "id_str" : "2982226132",
      "id" : 2982226132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/RCb65oOOmE",
      "expanded_url" : "http:\/\/go.wh.gov\/1DX6Lh",
      "display_url" : "go.wh.gov\/1DX6Lh"
    } ]
  },
  "geo" : { },
  "id_str" : "438024545254252544",
  "text" : "President Obama: \"The people of Michigan\u2014and the American people\u2014are better off because of @John_Dingell\u2019s service.\" http:\/\/t.co\/RCb65oOOmE",
  "id" : 438024545254252544,
  "created_at" : "2014-02-24 18:56:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/LFNfs91OZW",
      "expanded_url" : "http:\/\/go.wh.gov\/oZ7bgn",
      "display_url" : "go.wh.gov\/oZ7bgn"
    } ]
  },
  "geo" : { },
  "id_str" : "437987981849546752",
  "text" : "RT @WHLive: Obama to governors: \u201CWhen you succeed, the people in your states succeed and America succeeds.\u201D http:\/\/t.co\/LFNfs91OZW #Opportu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 119, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/LFNfs91OZW",
        "expanded_url" : "http:\/\/go.wh.gov\/oZ7bgn",
        "display_url" : "go.wh.gov\/oZ7bgn"
      } ]
    },
    "geo" : { },
    "id_str" : "437987847644401664",
    "text" : "Obama to governors: \u201CWhen you succeed, the people in your states succeed and America succeeds.\u201D http:\/\/t.co\/LFNfs91OZW #OpportunityForAll",
    "id" : 437987847644401664,
    "created_at" : "2014-02-24 16:30:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 437987981849546752,
  "created_at" : "2014-02-24 16:30:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gap Inc.",
      "screen_name" : "GapInc",
      "indices" : [ 29, 36 ],
      "id_str" : "207686162",
      "id" : 207686162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437986571087020032",
  "text" : "President Obama: \"Last week, @GapInc said it would lift wages for about 65,000 of its employees.\" #RaiseTheWage",
  "id" : 437986571087020032,
  "created_at" : "2014-02-24 16:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437986430233882624",
  "text" : "RT @WHLive: Obama: \"Since I called on Congress to raise the min wage last year, 6 states have gone ahead &amp; done it on their own.\" http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/437986320036544512\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/sC8AJH9L6F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhQKPMHCIAAZftk.jpg",
        "id_str" : "437986319826821120",
        "id" : 437986319826821120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhQKPMHCIAAZftk.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sC8AJH9L6F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "437986320036544512",
    "text" : "Obama: \"Since I called on Congress to raise the min wage last year, 6 states have gone ahead &amp; done it on their own.\" http:\/\/t.co\/sC8AJH9L6F",
    "id" : 437986320036544512,
    "created_at" : "2014-02-24 16:24:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 437986430233882624,
  "created_at" : "2014-02-24 16:24:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/437985344575660032\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/GBvsTaeYpD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhQJWaVCEAEBiG2.jpg",
      "id_str" : "437985344391090177",
      "id" : 437985344391090177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhQJWaVCEAEBiG2.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/GBvsTaeYpD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437985344575660032",
  "text" : "Obama: \"Our economy is growing. Our businesses have created about 8.5 million new jobs over the past 4 years.\" http:\/\/t.co\/GBvsTaeYpD",
  "id" : 437985344575660032,
  "created_at" : "2014-02-24 16:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Jsi2HxLH3a",
      "expanded_url" : "http:\/\/go.wh.gov\/Av9bWT",
      "display_url" : "go.wh.gov\/Av9bWT"
    } ]
  },
  "geo" : { },
  "id_str" : "437983985965490176",
  "text" : "RT @WHLive: Starting soon: Watch President Obama speak to the National Governors Association \u2192 http:\/\/t.co\/Jsi2HxLH3a #OpportunityForAll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 106, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/Jsi2HxLH3a",
        "expanded_url" : "http:\/\/go.wh.gov\/Av9bWT",
        "display_url" : "go.wh.gov\/Av9bWT"
      } ]
    },
    "geo" : { },
    "id_str" : "437983765542219776",
    "text" : "Starting soon: Watch President Obama speak to the National Governors Association \u2192 http:\/\/t.co\/Jsi2HxLH3a #OpportunityForAll",
    "id" : 437983765542219776,
    "created_at" : "2014-02-24 16:14:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 437983985965490176,
  "created_at" : "2014-02-24 16:14:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 31, 49 ]
    }, {
      "text" : "RebuildAmerica",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437975323703906304",
  "text" : "Obama's week of action:\nExpand #OpportunityForAll w\/ Govs\nNew manufacturing hubs\nSteps to #RebuildAmerica\nInitiative for young men of color",
  "id" : 437975323703906304,
  "created_at" : "2014-02-24 15:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 90, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/16DErYkdtw",
      "expanded_url" : "http:\/\/go.wh.gov\/AU4y6t",
      "display_url" : "go.wh.gov\/AU4y6t"
    } ]
  },
  "geo" : { },
  "id_str" : "437968649589358592",
  "text" : "America doesn't stand still &amp; neither does President Obama. Here's how he's expanding #OpportunityForAll this week \u2192 http:\/\/t.co\/16DErYkdtw",
  "id" : 437968649589358592,
  "created_at" : "2014-02-24 15:13:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9q9o5XlakC",
      "expanded_url" : "http:\/\/go.wh.gov\/27R6Zg",
      "display_url" : "go.wh.gov\/27R6Zg"
    } ]
  },
  "geo" : { },
  "id_str" : "437663262310531072",
  "text" : "\"We want trucks that use less oil, save more money, cut pollution.\" \u2014Obama on efficiency standards for large trucks: http:\/\/t.co\/9q9o5XlakC",
  "id" : 437663262310531072,
  "created_at" : "2014-02-23 19:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/xBbSsxuSl2",
      "expanded_url" : "http:\/\/go.wh.gov\/qiigeU",
      "display_url" : "go.wh.gov\/qiigeU"
    } ]
  },
  "geo" : { },
  "id_str" : "437633064626176003",
  "text" : "Obama: \"Hardworking Americans deserve better than 'no.' Let\u2019s tell Congress to say 'yes'...give America a raise.\" http:\/\/t.co\/xBbSsxuSl2",
  "id" : 437633064626176003,
  "created_at" : "2014-02-23 17:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/eG4V5ErFcm",
      "expanded_url" : "http:\/\/go.wh.gov\/QsApFJ",
      "display_url" : "go.wh.gov\/QsApFJ"
    } ]
  },
  "geo" : { },
  "id_str" : "437610413081886720",
  "text" : "\"Raising Americans\u2019 wages isn\u2019t just a good deed; it\u2019s good business and good for our economy.\" \u2014Obama: http:\/\/t.co\/eG4V5ErFcm #RaiseTheWage",
  "id" : 437610413081886720,
  "created_at" : "2014-02-23 15:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gap Inc.",
      "screen_name" : "GapInc",
      "indices" : [ 37, 44 ],
      "id_str" : "207686162",
      "id" : 207686162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/TEXzjL1mj5",
      "expanded_url" : "http:\/\/go.wh.gov\/PLBcTG",
      "display_url" : "go.wh.gov\/PLBcTG"
    } ]
  },
  "geo" : { },
  "id_str" : "437285769774780419",
  "text" : "\"One of America\u2019s largest retailers, @GapInc, decided to raise wages for its employees.\" \u2014Obama: http:\/\/t.co\/TEXzjL1mj5 #RaiseTheWage",
  "id" : 437285769774780419,
  "created_at" : "2014-02-22 18:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 23, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/W1US1ujhtw",
      "expanded_url" : "http:\/\/go.wh.gov\/D8hVRb",
      "display_url" : "go.wh.gov\/D8hVRb"
    } ]
  },
  "geo" : { },
  "id_str" : "437263117932707840",
  "text" : "\"Restoring the idea of #OpportunityForAll requires a year of action from all of us.\" \u2014Obama in his Weekly Address: http:\/\/t.co\/W1US1ujhtw",
  "id" : 437263117932707840,
  "created_at" : "2014-02-22 16:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/slDzuHU4ZX",
      "expanded_url" : "http:\/\/go.wh.gov\/p3QRbm",
      "display_url" : "go.wh.gov\/p3QRbm"
    } ]
  },
  "geo" : { },
  "id_str" : "437240470490464256",
  "text" : "\"Here in America, no one who works hard should have to live in poverty.\" \u2014President Obama: http:\/\/t.co\/slDzuHU4ZX #RaiseTheWage",
  "id" : 437240470490464256,
  "created_at" : "2014-02-22 15:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/437015391814959104\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/mo6C1F2ebJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhCXLuvCAAAfwk-.jpg",
      "id_str" : "437015391634587648",
      "id" : 437015391634587648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhCXLuvCAAAfwk-.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      } ],
      "display_url" : "pic.twitter.com\/mo6C1F2ebJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437015391814959104",
  "text" : "These two. http:\/\/t.co\/mo6C1F2ebJ",
  "id" : 437015391814959104,
  "created_at" : "2014-02-22 00:06:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Alaska",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "437003768836927488",
  "text" : "RT @Interior: Who is ready for the weekend? We hope you have as much fun as these brown bear cubs in Kodiak NWR! #Alaska http:\/\/t.co\/h7QTuG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/436991769159294977\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/h7QTuGGW1k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhCBsttCQAAalwU.jpg",
        "id_str" : "436991769037651968",
        "id" : 436991769037651968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhCBsttCQAAalwU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/h7QTuGGW1k"
      } ],
      "hashtags" : [ {
        "text" : "Alaska",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436991769159294977",
    "text" : "Who is ready for the weekend? We hope you have as much fun as these brown bear cubs in Kodiak NWR! #Alaska http:\/\/t.co\/h7QTuGGW1k",
    "id" : 436991769159294977,
    "created_at" : "2014-02-21 22:32:11 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 437003768836927488,
  "created_at" : "2014-02-21 23:19:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436998012863520768",
  "text" : "RT @pfeiffer44: Please remember that every GOPer attacking Pres Obama on Medicare Advantage voted for the EXACT same policy which is in the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436996160809865216",
    "text" : "Please remember that every GOPer attacking Pres Obama on Medicare Advantage voted for the EXACT same policy which is in the GOP Budget",
    "id" : 436996160809865216,
    "created_at" : "2014-02-21 22:49:38 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 436998012863520768,
  "created_at" : "2014-02-21 22:56:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/436993975912648704\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/XppXlhccbF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhCDtKdCEAE4MXr.jpg",
      "id_str" : "436993975778414593",
      "id" : 436993975778414593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhCDtKdCEAE4MXr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XppXlhccbF"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/1IdF9fgPSb",
      "expanded_url" : "http:\/\/go.wh.gov\/mih6X6",
      "display_url" : "go.wh.gov\/mih6X6"
    } ]
  },
  "geo" : { },
  "id_str" : "436993975912648704",
  "text" : "Worth sharing: Here's how the Affordable Care Act is strengthening Medicare \u2192 http:\/\/t.co\/1IdF9fgPSb #GetCovered http:\/\/t.co\/XppXlhccbF",
  "id" : 436993975912648704,
  "created_at" : "2014-02-21 22:40:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/XH7tZfWTBc",
      "expanded_url" : "http:\/\/go.wh.gov\/uoA8d4",
      "display_url" : "go.wh.gov\/uoA8d4"
    } ]
  },
  "geo" : { },
  "id_str" : "436979410970103808",
  "text" : "\"You can't bet against American workers or American industry.\" \u2014President Obama: http:\/\/t.co\/XH7tZfWTBc #WestWingWeek",
  "id" : 436979410970103808,
  "created_at" : "2014-02-21 21:43:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Fallon Tonight",
      "screen_name" : "FallonTonight",
      "indices" : [ 55, 69 ],
      "id_str" : "19777398",
      "id" : 19777398
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/6M6vxJwbiZ",
      "expanded_url" : "http:\/\/youtu.be\/HOK4aBYNh3s?t=2m50s",
      "display_url" : "youtu.be\/HOK4aBYNh3s?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436973613733142528",
  "text" : "RT @FLOTUS: \"Exercise is not 'ew!'\" \u2013The First Lady on @FallonTonight. Show us how you move with #LetsMove http:\/\/t.co\/6M6vxJwbiZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fallon Tonight",
        "screen_name" : "FallonTonight",
        "indices" : [ 43, 57 ],
        "id_str" : "19777398",
        "id" : 19777398
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/6M6vxJwbiZ",
        "expanded_url" : "http:\/\/youtu.be\/HOK4aBYNh3s?t=2m50s",
        "display_url" : "youtu.be\/HOK4aBYNh3s?t=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436968129370271744",
    "text" : "\"Exercise is not 'ew!'\" \u2013The First Lady on @FallonTonight. Show us how you move with #LetsMove http:\/\/t.co\/6M6vxJwbiZ",
    "id" : 436968129370271744,
    "created_at" : "2014-02-21 20:58:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 436973613733142528,
  "created_at" : "2014-02-21 21:20:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Valor24",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/UNCvudfqZU",
      "expanded_url" : "http:\/\/www.army.mil\/medalofhonor\/valor24",
      "display_url" : "army.mil\/medalofhonor\/v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436970878921093120",
  "text" : "RT @USArmy: Save the date \u2192 One of the largest Medal of Honor ceremonies in history is happening March 18 http:\/\/t.co\/UNCvudfqZU #Valor24",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Valor24",
        "indices" : [ 117, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/UNCvudfqZU",
        "expanded_url" : "http:\/\/www.army.mil\/medalofhonor\/valor24",
        "display_url" : "army.mil\/medalofhonor\/v\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436960701786370048",
    "text" : "Save the date \u2192 One of the largest Medal of Honor ceremonies in history is happening March 18 http:\/\/t.co\/UNCvudfqZU #Valor24",
    "id" : 436960701786370048,
    "created_at" : "2014-02-21 20:28:44 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 436970878921093120,
  "created_at" : "2014-02-21 21:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 3, 14 ],
      "id_str" : "120176950",
      "id" : 120176950
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 54, 68 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Qtp8lTb0Ls",
      "expanded_url" : "http:\/\/go.usa.gov\/BAFB",
      "display_url" : "go.usa.gov\/BAFB"
    } ]
  },
  "geo" : { },
  "id_str" : "436968173855051776",
  "text" : "RT @USTreasury: If you get your health insurance thru @HealthCareGov you may be eligible for the premium tax credit http:\/\/t.co\/Qtp8lTb0Ls \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 38, 52 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 123, 127 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/Qtp8lTb0Ls",
        "expanded_url" : "http:\/\/go.usa.gov\/BAFB",
        "display_url" : "go.usa.gov\/BAFB"
      } ]
    },
    "geo" : { },
    "id_str" : "436905002049605632",
    "text" : "If you get your health insurance thru @HealthCareGov you may be eligible for the premium tax credit http:\/\/t.co\/Qtp8lTb0Ls #ACA #GetCovered",
    "id" : 436905002049605632,
    "created_at" : "2014-02-21 16:47:24 +0000",
    "user" : {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "protected" : false,
      "id_str" : "120176950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461250108441370624\/-9PNMlfp_normal.jpeg",
      "id" : 120176950,
      "verified" : true
    }
  },
  "id" : 436968173855051776,
  "created_at" : "2014-02-21 20:58:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 26, 37 ]
    }, {
      "text" : "BlackHistoryMonth",
      "indices" : [ 51, 69 ]
    }, {
      "text" : "STEM",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "BHM",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/lVbALUvykm",
      "expanded_url" : "http:\/\/wh.gov\/lPbKy",
      "display_url" : "wh.gov\/lPbKy"
    } ]
  },
  "geo" : { },
  "id_str" : "436963807211290625",
  "text" : "RT @whitehouseostp: TUES: #WeTheGeeks \"Celebrating #BlackHistoryMonth\" ft. African American #STEM allstars \u2192 http:\/\/t.co\/lVbALUvykm #BHM ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/436937929781309440\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/1mHQoTmNmX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhBQu23CcAAzgQv.jpg",
        "id_str" : "436937929785503744",
        "id" : 436937929785503744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhBQu23CcAAzgQv.jpg",
        "sizes" : [ {
          "h" : 302,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 430
        } ],
        "display_url" : "pic.twitter.com\/1mHQoTmNmX"
      } ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 6, 17 ]
      }, {
        "text" : "BlackHistoryMonth",
        "indices" : [ 31, 49 ]
      }, {
        "text" : "STEM",
        "indices" : [ 72, 77 ]
      }, {
        "text" : "BHM",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/lVbALUvykm",
        "expanded_url" : "http:\/\/wh.gov\/lPbKy",
        "display_url" : "wh.gov\/lPbKy"
      } ]
    },
    "geo" : { },
    "id_str" : "436937929781309440",
    "text" : "TUES: #WeTheGeeks \"Celebrating #BlackHistoryMonth\" ft. African American #STEM allstars \u2192 http:\/\/t.co\/lVbALUvykm #BHM http:\/\/t.co\/1mHQoTmNmX",
    "id" : 436937929781309440,
    "created_at" : "2014-02-21 18:58:16 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 436963807211290625,
  "created_at" : "2014-02-21 20:41:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/39xGYNdajN",
      "expanded_url" : "http:\/\/go.wh.gov\/hJbtan",
      "display_url" : "go.wh.gov\/hJbtan"
    } ]
  },
  "geo" : { },
  "id_str" : "436949798361382914",
  "text" : "\"Nearly 6 in 10 Americans who are uninsured will be able to #GetCovered for $100\/month or less.\" \u2014President Obama: http:\/\/t.co\/39xGYNdajN",
  "id" : 436949798361382914,
  "created_at" : "2014-02-21 19:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalai Lama",
      "screen_name" : "DalaiLama",
      "indices" : [ 3, 13 ],
      "id_str" : "20609518",
      "id" : 20609518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436943246867300352",
  "text" : "RT @DalaiLama: His Holiness the Dalai Lama with President Barack Obama in the Map Room of the White House on February 21, 2014. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DalaiLama\/status\/436941496437051392\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Rx6zyJS00y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BhBT-dtCEAAgVvJ.jpg",
        "id_str" : "436941496445440000",
        "id" : 436941496445440000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhBT-dtCEAAgVvJ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Rx6zyJS00y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436941496437051392",
    "text" : "His Holiness the Dalai Lama with President Barack Obama in the Map Room of the White House on February 21, 2014. http:\/\/t.co\/Rx6zyJS00y",
    "id" : 436941496437051392,
    "created_at" : "2014-02-21 19:12:25 +0000",
    "user" : {
      "name" : "Dalai Lama",
      "screen_name" : "DalaiLama",
      "protected" : false,
      "id_str" : "20609518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529214699041067008\/fqPBAr5s_normal.jpeg",
      "id" : 20609518,
      "verified" : true
    }
  },
  "id" : 436943246867300352,
  "created_at" : "2014-02-21 19:19:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Johnson",
      "screen_name" : "KJ_MayorJohnson",
      "indices" : [ 40, 56 ],
      "id_str" : "16621525",
      "id" : 16621525
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/vv7Ye2BvwS",
      "expanded_url" : "http:\/\/go.wh.gov\/GoKEiJ",
      "display_url" : "go.wh.gov\/GoKEiJ"
    } ]
  },
  "geo" : { },
  "id_str" : "436938475330211840",
  "text" : "Former NBA point guard &amp; Sacramento @KJ_MayorJohnson wants you to dish out an assist and help a friend #GetCovered: http:\/\/t.co\/vv7Ye2BvwS",
  "id" : 436938475330211840,
  "created_at" : "2014-02-21 19:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalai Lama",
      "screen_name" : "DalaiLama",
      "indices" : [ 34, 44 ],
      "id_str" : "20609518",
      "id" : 20609518
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/436930787833700352\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/uWUmciyz6M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhBKPIUCEAA-yni.jpg",
      "id_str" : "436930787644936192",
      "id" : 436930787644936192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhBKPIUCEAA-yni.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/uWUmciyz6M"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/TNaZ7g7rse",
      "expanded_url" : "http:\/\/go.wh.gov\/hQY3hR",
      "display_url" : "go.wh.gov\/hQY3hR"
    } ]
  },
  "geo" : { },
  "id_str" : "436930787833700352",
  "text" : "President Obama just met with the @DalaiLama at the White House \u2192 http:\/\/t.co\/TNaZ7g7rse, http:\/\/t.co\/uWUmciyz6M",
  "id" : 436930787833700352,
  "created_at" : "2014-02-21 18:29:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/0xWMIuajX8",
      "expanded_url" : "http:\/\/go.wh.gov\/UeSpuh",
      "display_url" : "go.wh.gov\/UeSpuh"
    } ]
  },
  "geo" : { },
  "id_str" : "436921248707530752",
  "text" : "Obama: \"I'm going to continue to press Congress to pass a federal min wage bill that goes up to $10.10\" http:\/\/t.co\/0xWMIuajX8 #RaiseTheWage",
  "id" : 436921248707530752,
  "created_at" : "2014-02-21 17:51:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 106, 115 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ApegiHvcRF",
      "expanded_url" : "http:\/\/go.wh.gov\/24aXG6",
      "display_url" : "go.wh.gov\/24aXG6"
    } ]
  },
  "geo" : { },
  "id_str" : "436913306553430018",
  "text" : "\"The U.S. welcomes the agreement...today between Ukrainian President Yanukovych and Opposition leaders.\" \u2014@PressSec: http:\/\/t.co\/ApegiHvcRF",
  "id" : 436913306553430018,
  "created_at" : "2014-02-21 17:20:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Cosmopolitan",
      "screen_name" : "Cosmopolitan",
      "indices" : [ 20, 33 ],
      "id_str" : "23482952",
      "id" : 23482952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 68, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/CiUsH0pNch",
      "expanded_url" : "http:\/\/goo.gl\/9cT8wd",
      "display_url" : "goo.gl\/9cT8wd"
    } ]
  },
  "geo" : { },
  "id_str" : "436909969246781441",
  "text" : "RT @vj44: Thank you @Cosmopolitan for spreading the word on how the #ACA benefits women! http:\/\/t.co\/CiUsH0pNch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cosmopolitan",
        "screen_name" : "Cosmopolitan",
        "indices" : [ 10, 23 ],
        "id_str" : "23482952",
        "id" : 23482952
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 58, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/CiUsH0pNch",
        "expanded_url" : "http:\/\/goo.gl\/9cT8wd",
        "display_url" : "goo.gl\/9cT8wd"
      } ]
    },
    "geo" : { },
    "id_str" : "436907252684189696",
    "text" : "Thank you @Cosmopolitan for spreading the word on how the #ACA benefits women! http:\/\/t.co\/CiUsH0pNch",
    "id" : 436907252684189696,
    "created_at" : "2014-02-21 16:56:21 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 436909969246781441,
  "created_at" : "2014-02-21 17:07:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xOvDW6ehAP",
      "expanded_url" : "http:\/\/go.wh.gov\/X2S52D",
      "display_url" : "go.wh.gov\/X2S52D"
    } ]
  },
  "geo" : { },
  "id_str" : "436903709680078848",
  "text" : "\"If you already have health insurance, think about someone else you know who needs to hear this news.\" \u2014Obama: http:\/\/t.co\/xOvDW6ehAP",
  "id" : 436903709680078848,
  "created_at" : "2014-02-21 16:42:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Johnson",
      "screen_name" : "KJ_MayorJohnson",
      "indices" : [ 3, 19 ],
      "id_str" : "16621525",
      "id" : 16621525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/csEwN3JJLh",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "436899878858674177",
  "text" : "RT @KJ_MayorJohnson: Just over a month left for open enrollment! Watch my video and visit http:\/\/t.co\/csEwN3JJLh to get signed up! .http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/csEwN3JJLh",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      }, {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/x1GOTcaVzH",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/02\/21\/get-covered-assist-mayor-kevin-johnson",
        "display_url" : "whitehouse.gov\/blog\/2014\/02\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436891106203009024",
    "text" : "Just over a month left for open enrollment! Watch my video and visit http:\/\/t.co\/csEwN3JJLh to get signed up! .http:\/\/t.co\/x1GOTcaVzH",
    "id" : 436891106203009024,
    "created_at" : "2014-02-21 15:52:11 +0000",
    "user" : {
      "name" : "Kevin Johnson",
      "screen_name" : "KJ_MayorJohnson",
      "protected" : false,
      "id_str" : "16621525",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643227428001705984\/3PMJEZ2X_normal.jpg",
      "id" : 16621525,
      "verified" : true
    }
  },
  "id" : 436899878858674177,
  "created_at" : "2014-02-21 16:27:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/BP2KM2Ag6D",
      "expanded_url" : "http:\/\/go.wh.gov\/X2S52D",
      "display_url" : "go.wh.gov\/X2S52D"
    } ]
  },
  "geo" : { },
  "id_str" : "436893177182568448",
  "text" : "\"If you don't have health insurance, head over to http:\/\/t.co\/0lwMLeJwkK.\" \u2014President Obama: http:\/\/t.co\/BP2KM2Ag6D #GetCovered",
  "id" : 436893177182568448,
  "created_at" : "2014-02-21 16:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalai Lama",
      "screen_name" : "DalaiLama",
      "indices" : [ 68, 78 ],
      "id_str" : "20609518",
      "id" : 20609518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436889842405113856",
  "text" : "RT @NSCPress: The President is currently meeting w\/His Holiness the @DalaiLama in his capacity as an internationally respected religious &amp; \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dalai Lama",
        "screen_name" : "DalaiLama",
        "indices" : [ 54, 64 ],
        "id_str" : "20609518",
        "id" : 20609518
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436889620522233856",
    "text" : "The President is currently meeting w\/His Holiness the @DalaiLama in his capacity as an internationally respected religious &amp; cultural leader",
    "id" : 436889620522233856,
    "created_at" : "2014-02-21 15:46:17 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 436889842405113856,
  "created_at" : "2014-02-21 15:47:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/436880744007233536\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/jHCbo2UdtJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BhAcuLyCUAA80pl.jpg",
      "id_str" : "436880743617155072",
      "id" : 436880743617155072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BhAcuLyCUAA80pl.jpg",
      "sizes" : [ {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jHCbo2UdtJ"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/mFUD6eGuAo",
      "expanded_url" : "http:\/\/go.wh.gov\/WRb4tz",
      "display_url" : "go.wh.gov\/WRb4tz"
    } ]
  },
  "geo" : { },
  "id_str" : "436880744007233536",
  "text" : "Watch a special message from President Obama on how you can #GetCovered right now \u2192 http:\/\/t.co\/mFUD6eGuAo, http:\/\/t.co\/jHCbo2UdtJ",
  "id" : 436880744007233536,
  "created_at" : "2014-02-21 15:11:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 3, 13 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USOlympic\/status\/436624173343834113\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ksJdatjQki",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg8zX1ECAAA7khj.jpg",
      "id_str" : "436624173352222720",
      "id" : 436624173352222720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg8zX1ECAAA7khj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ksJdatjQki"
    } ],
    "hashtags" : [ {
      "text" : "USAvsCAN",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "GoTeamUSA",
      "indices" : [ 71, 81 ]
    }, {
      "text" : "Sochi2014",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436662163550531584",
  "text" : "RT @USOlympic: Tomorrow we meet again. #USAvsCAN for men's semifinals. #GoTeamUSA #Sochi2014 http:\/\/t.co\/ksJdatjQki",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USOlympic\/status\/436624173343834113\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/ksJdatjQki",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg8zX1ECAAA7khj.jpg",
        "id_str" : "436624173352222720",
        "id" : 436624173352222720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg8zX1ECAAA7khj.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ksJdatjQki"
      } ],
      "hashtags" : [ {
        "text" : "USAvsCAN",
        "indices" : [ 24, 33 ]
      }, {
        "text" : "GoTeamUSA",
        "indices" : [ 56, 66 ]
      }, {
        "text" : "Sochi2014",
        "indices" : [ 67, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436624173343834113",
    "text" : "Tomorrow we meet again. #USAvsCAN for men's semifinals. #GoTeamUSA #Sochi2014 http:\/\/t.co\/ksJdatjQki",
    "id" : 436624173343834113,
    "created_at" : "2014-02-20 22:11:29 +0000",
    "user" : {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "protected" : false,
      "id_str" : "21870081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781162053104840704\/u4wNd-62_normal.jpg",
      "id" : 21870081,
      "verified" : true
    }
  },
  "id" : 436662163550531584,
  "created_at" : "2014-02-21 00:42:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/436647442130276353\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/qkwUSNO8i5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg9IiPfCUAASyFa.jpg",
      "id_str" : "436647441987686400",
      "id" : 436647441987686400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg9IiPfCUAASyFa.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/qkwUSNO8i5"
    } ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/OdgPNKmf7A",
      "expanded_url" : "http:\/\/go.wh.gov\/zrqVTe",
      "display_url" : "go.wh.gov\/zrqVTe"
    } ]
  },
  "geo" : { },
  "id_str" : "436647442130276353",
  "text" : "President Obama spoke with German Chancellor Merkel today about the situation in #Ukraine \u2192 http:\/\/t.co\/OdgPNKmf7A, http:\/\/t.co\/qkwUSNO8i5",
  "id" : 436647442130276353,
  "created_at" : "2014-02-20 23:43:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/436636806113550337\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/vCP36dKjkv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg8-3JHCQAE5W4a.jpg",
      "id_str" : "436636805937381377",
      "id" : 436636805937381377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg8-3JHCQAE5W4a.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/vCP36dKjkv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/eG1xu4PuZa",
      "expanded_url" : "http:\/\/go.wh.gov\/sRsUcP",
      "display_url" : "go.wh.gov\/sRsUcP"
    } ]
  },
  "geo" : { },
  "id_str" : "436636806113550337",
  "text" : "FACT: Under President Obama, we've reduced the deficit by more than half. http:\/\/t.co\/eG1xu4PuZa, http:\/\/t.co\/vCP36dKjkv",
  "id" : 436636806113550337,
  "created_at" : "2014-02-20 23:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/PQgYmLXM34",
      "expanded_url" : "http:\/\/go.wh.gov\/whJ1pa",
      "display_url" : "go.wh.gov\/whJ1pa"
    } ]
  },
  "geo" : { },
  "id_str" : "436611768941817858",
  "text" : "\"We are all grateful to you for everything that you've done for our country.\" \u2014Obama to Japanese-American WWII vets: http:\/\/t.co\/PQgYmLXM34",
  "id" : 436611768941817858,
  "created_at" : "2014-02-20 21:22:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/IqTO2dgpKV",
      "expanded_url" : "http:\/\/youtu.be\/00Y6EPmeGoM",
      "display_url" : "youtu.be\/00Y6EPmeGoM"
    } ]
  },
  "geo" : { },
  "id_str" : "436605535081992194",
  "text" : "RT @FLOTUS: \"Right now I want you to get up and show me how you move!\" \u2014First Lady Michelle Obama,  http:\/\/t.co\/IqTO2dgpKV  #LetsMove",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/IqTO2dgpKV",
        "expanded_url" : "http:\/\/youtu.be\/00Y6EPmeGoM",
        "display_url" : "youtu.be\/00Y6EPmeGoM"
      } ]
    },
    "geo" : { },
    "id_str" : "436530483544199169",
    "text" : "\"Right now I want you to get up and show me how you move!\" \u2014First Lady Michelle Obama,  http:\/\/t.co\/IqTO2dgpKV  #LetsMove",
    "id" : 436530483544199169,
    "created_at" : "2014-02-20 15:59:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 436605535081992194,
  "created_at" : "2014-02-20 20:57:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PatentAction",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/9gTcnIHdy3",
      "expanded_url" : "http:\/\/go.wh.gov\/YQ383W",
      "display_url" : "go.wh.gov\/YQ383W"
    } ]
  },
  "geo" : { },
  "id_str" : "436594814893948928",
  "text" : "President Obama just took action to encourage American innovation by strengthening our patent system \u2192 http:\/\/t.co\/9gTcnIHdy3 #PatentAction",
  "id" : 436594814893948928,
  "created_at" : "2014-02-20 20:14:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#HockeyFightsCancer",
      "screen_name" : "NHL",
      "indices" : [ 3, 7 ],
      "id_str" : "50004938",
      "id" : 50004938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436583289919647744",
  "text" : "RT @NHL: Nothing like a friendly bet between your countries, right Pres. Obama &amp; @pmharper? http:\/\/t.co\/z2oYK95XtD @Whitehouse #GoCanadaGo \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 110, 121 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoCanadaGo",
        "indices" : [ 122, 133 ]
      }, {
        "text" : "GoTeamUSA",
        "indices" : [ 134, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/z2oYK95XtD",
        "expanded_url" : "http:\/\/s.nhl.com\/tP8mu",
        "display_url" : "s.nhl.com\/tP8mu"
      } ]
    },
    "geo" : { },
    "id_str" : "436561649664028672",
    "text" : "Nothing like a friendly bet between your countries, right Pres. Obama &amp; @pmharper? http:\/\/t.co\/z2oYK95XtD @Whitehouse #GoCanadaGo #GoTeamUSA",
    "id" : 436561649664028672,
    "created_at" : "2014-02-20 18:03:02 +0000",
    "user" : {
      "name" : "#HockeyFightsCancer",
      "screen_name" : "NHL",
      "protected" : false,
      "id_str" : "50004938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790512991192113152\/cPMsM3l0_normal.jpg",
      "id" : 50004938,
      "verified" : true
    }
  },
  "id" : 436583289919647744,
  "created_at" : "2014-02-20 19:29:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "House Democrats",
      "screen_name" : "HouseDemocrats",
      "indices" : [ 3, 18 ],
      "id_str" : "43963249",
      "id" : 43963249
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 94, 107 ]
    }, {
      "text" : "TBT",
      "indices" : [ 109, 113 ]
    }, {
      "text" : "throwbackthursday",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436581810193977344",
  "text" : "RT @HouseDemocrats: Remember when a Democratic Congress worked with a Republican President to #RaiseTheWage? #TBT #throwbackthursday http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HouseDemocrats\/status\/436569042250252288\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Ko9dB9vPUe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg8BOxvCQAE547h.jpg",
        "id_str" : "436569042258640897",
        "id" : 436569042258640897,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg8BOxvCQAE547h.jpg",
        "sizes" : [ {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Ko9dB9vPUe"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 74, 87 ]
      }, {
        "text" : "TBT",
        "indices" : [ 89, 93 ]
      }, {
        "text" : "throwbackthursday",
        "indices" : [ 94, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436569042250252288",
    "text" : "Remember when a Democratic Congress worked with a Republican President to #RaiseTheWage? #TBT #throwbackthursday http:\/\/t.co\/Ko9dB9vPUe",
    "id" : 436569042250252288,
    "created_at" : "2014-02-20 18:32:25 +0000",
    "user" : {
      "name" : "House Democrats",
      "screen_name" : "HouseDemocrats",
      "protected" : false,
      "id_str" : "43963249",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459007737876074496\/0-qC-V2i_normal.png",
      "id" : 43963249,
      "verified" : true
    }
  },
  "id" : 436581810193977344,
  "created_at" : "2014-02-20 19:23:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PatentAction",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/EUV9KHcuQ4",
      "expanded_url" : "http:\/\/go.wh.gov\/Lwafvy",
      "display_url" : "go.wh.gov\/Lwafvy"
    } ]
  },
  "geo" : { },
  "id_str" : "436571395079028736",
  "text" : "Check out how President Obama is helping creators spend more time on innovation, not litigation: http:\/\/t.co\/EUV9KHcuQ4 #PatentAction",
  "id" : 436571395079028736,
  "created_at" : "2014-02-20 18:41:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Univision",
      "screen_name" : "Univision",
      "indices" : [ 94, 104 ],
      "id_str" : "40924038",
      "id" : 40924038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436561973145501696",
  "text" : "RT @FLOTUS: The First Lady discusses why it's important to #GetCovered with Doctora Isabel on @Univision radio. Tune in at 1ET \u2192 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Univision",
        "screen_name" : "Univision",
        "indices" : [ 82, 92 ],
        "id_str" : "40924038",
        "id" : 40924038
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 47, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Jyh2eHpjgv",
        "expanded_url" : "http:\/\/univisionamerica.com",
        "display_url" : "univisionamerica.com"
      } ]
    },
    "geo" : { },
    "id_str" : "436561139707957249",
    "text" : "The First Lady discusses why it's important to #GetCovered with Doctora Isabel on @Univision radio. Tune in at 1ET \u2192 http:\/\/t.co\/Jyh2eHpjgv",
    "id" : 436561139707957249,
    "created_at" : "2014-02-20 18:01:01 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 436561973145501696,
  "created_at" : "2014-02-20 18:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC Nightly News",
      "screen_name" : "NBCNightlyNews",
      "indices" : [ 3, 18 ],
      "id_str" : "8839632",
      "id" : 8839632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/pczLAlQ04m",
      "expanded_url" : "http:\/\/nbcnews.to\/1mev21o",
      "display_url" : "nbcnews.to\/1mev21o"
    } ]
  },
  "geo" : { },
  "id_str" : "436560037134487552",
  "text" : "RT @nbcnightlynews: President Obama, Canadian PM Harper bet cases of beer on US-Canada Olympic hockey games http:\/\/t.co\/pczLAlQ04m @NBCOlym\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NBC Olympics",
        "screen_name" : "NBCOlympics",
        "indices" : [ 111, 123 ],
        "id_str" : "14955353",
        "id" : 14955353
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/pczLAlQ04m",
        "expanded_url" : "http:\/\/nbcnews.to\/1mev21o",
        "display_url" : "nbcnews.to\/1mev21o"
      } ]
    },
    "geo" : { },
    "id_str" : "436557743055732736",
    "text" : "President Obama, Canadian PM Harper bet cases of beer on US-Canada Olympic hockey games http:\/\/t.co\/pczLAlQ04m @NBCOlympics",
    "id" : 436557743055732736,
    "created_at" : "2014-02-20 17:47:31 +0000",
    "user" : {
      "name" : "NBC Nightly News",
      "screen_name" : "NBCNightlyNews",
      "protected" : false,
      "id_str" : "8839632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785592557170548736\/SHaFtQWN_normal.jpg",
      "id" : 8839632,
      "verified" : true
    }
  },
  "id" : 436560037134487552,
  "created_at" : "2014-02-20 17:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/RXnOxU8Q9N",
      "expanded_url" : "http:\/\/go.wh.gov\/YNZz63",
      "display_url" : "go.wh.gov\/YNZz63"
    } ]
  },
  "geo" : { },
  "id_str" : "436540456634421248",
  "text" : "\"We urge the Ukrainian military not to get involved in a conflict that can &amp; should be resolved by political means.\" http:\/\/t.co\/RXnOxU8Q9N",
  "id" : 436540456634421248,
  "created_at" : "2014-02-20 16:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 15, 25 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USOlympic\/status\/436532233927532544\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/nhPkNbikTZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg7fwQECIAAwiXz.png",
      "id_str" : "436532233940115456",
      "id" : 436532233940115456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg7fwQECIAAwiXz.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nhPkNbikTZ"
    } ],
    "hashtags" : [ {
      "text" : "GoTeamUSA",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 41, 49 ]
    }, {
      "text" : "USAvsCAN",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436536056260087808",
  "text" : "#GoTeamUSA! MT @USOlympic: 1 hour to go. #TeamUSA vs. Canada for women's hockey GOLD. Cheer them on. #USAvsCAN http:\/\/t.co\/nhPkNbikTZ",
  "id" : 436536056260087808,
  "created_at" : "2014-02-20 16:21:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436530262886060032",
  "text" : "RT @CEABetsey: Raising the min wage makes good business sense: Gap Inc will raise its min to $10 to \"directly support our business\" http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/FW6MBx7ed7",
        "expanded_url" : "http:\/\/bananarepublic.gap.com\/Asset_Archive\/BRWeb\/content\/0007\/702\/228\/cn7702228.html",
        "display_url" : "bananarepublic.gap.com\/Asset_Archive\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436500703373459456",
    "text" : "Raising the min wage makes good business sense: Gap Inc will raise its min to $10 to \"directly support our business\" http:\/\/t.co\/FW6MBx7ed7",
    "id" : 436500703373459456,
    "created_at" : "2014-02-20 14:00:52 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 436530262886060032,
  "created_at" : "2014-02-20 15:58:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoTeamUSA",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436515835621171200",
  "text" : ".@pmharper and I bet on the women's and men's US-Canada hockey games. Winner gets a case of beer for each game. #GoTeamUSA! -bo",
  "id" : 436515835621171200,
  "created_at" : "2014-02-20 15:00:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/GujW843jY9",
      "expanded_url" : "http:\/\/go.wh.gov\/GZvutp",
      "display_url" : "go.wh.gov\/GZvutp"
    } ]
  },
  "geo" : { },
  "id_str" : "436292958019530754",
  "text" : "\"It\u2019s time to pass that bill and give America a raise.\" \u2014Obama to Congress on raising the minimum wage: http:\/\/t.co\/GujW843jY9 #RaiseTheWage",
  "id" : 436292958019530754,
  "created_at" : "2014-02-20 00:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gap",
      "screen_name" : "Gap",
      "indices" : [ 18, 22 ],
      "id_str" : "18462157",
      "id" : 18462157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/SvcTOibDjO",
      "expanded_url" : "http:\/\/go.wh.gov\/jLPVuc",
      "display_url" : "go.wh.gov\/jLPVuc"
    } ]
  },
  "geo" : { },
  "id_str" : "436284048647135232",
  "text" : "Obama: \"I applaud @Gap, Inc. for announcing that they intend to raise wages for their employees.\" http:\/\/t.co\/SvcTOibDjO #RaiseTheWage",
  "id" : 436284048647135232,
  "created_at" : "2014-02-19 23:39:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enrique Pe\u00F1a Nieto",
      "screen_name" : "EPN",
      "indices" : [ 87, 91 ],
      "id_str" : "2897441",
      "id" : 2897441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/zzApM1j8Dy",
      "expanded_url" : "http:\/\/go.wh.gov\/v9vjgc",
      "display_url" : "go.wh.gov\/v9vjgc"
    } ]
  },
  "geo" : { },
  "id_str" : "436276021298728960",
  "text" : "Watch live: President Obama speaks at the North American Leaders Summit with President @EPN &amp; Prime Minister Harper. http:\/\/t.co\/zzApM1j8Dy",
  "id" : 436276021298728960,
  "created_at" : "2014-02-19 23:08:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/0uJ6lS8RQg",
      "expanded_url" : "http:\/\/go.wh.gov\/Nk5pmo",
      "display_url" : "go.wh.gov\/Nk5pmo"
    } ]
  },
  "geo" : { },
  "id_str" : "436263319859916801",
  "text" : "Good news: President Obama just took action to streamline the export\/import process for America's businesses: http:\/\/t.co\/0uJ6lS8RQg",
  "id" : 436263319859916801,
  "created_at" : "2014-02-19 22:17:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436248917156446208",
  "text" : "\"The United States condemns in strongest terms the violence that's taking place there.\" \u2014President Obama on the situation in Ukraine",
  "id" : 436248917156446208,
  "created_at" : "2014-02-19 21:20:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/IxMhWBS9K4",
      "expanded_url" : "http:\/\/usat.ly\/1eSITDT",
      "display_url" : "usat.ly\/1eSITDT"
    } ]
  },
  "geo" : { },
  "id_str" : "436243887464529922",
  "text" : "FACT: More than 828,000 Californians have signed up for private health plans through the #ACA. http:\/\/t.co\/IxMhWBS9K4 #GetCovered",
  "id" : 436243887464529922,
  "created_at" : "2014-02-19 21:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/lju0O8pJ9C",
      "expanded_url" : "http:\/\/usat.ly\/1eSITDT",
      "display_url" : "usat.ly\/1eSITDT"
    } ]
  },
  "geo" : { },
  "id_str" : "436236977026105345",
  "text" : "Great news: California's Affordable Care Act exchange just exceeded it's 2014 enrollment goal: http:\/\/t.co\/lju0O8pJ9C #GetCovered",
  "id" : 436236977026105345,
  "created_at" : "2014-02-19 20:32:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436232391385153536",
  "text" : "RT @DrBiden: Thank you President &amp; Mrs. Bush for hosting me for today's event on serving our troops as well as they've served us. #KnowOurV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KnowOurVets",
        "indices" : [ 121, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436227584255205376",
    "text" : "Thank you President &amp; Mrs. Bush for hosting me for today's event on serving our troops as well as they've served us. #KnowOurVets \u2013Jill",
    "id" : 436227584255205376,
    "created_at" : "2014-02-19 19:55:35 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 436232391385153536,
  "created_at" : "2014-02-19 20:14:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Crowley",
      "screen_name" : "Stcrow",
      "indices" : [ 3, 10 ],
      "id_str" : "24715018",
      "id" : 24715018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436226933056352257",
  "text" : "RT @Stcrow: 62 SECONDS W THE PRESIDENT ABOARD AF1- signs Executive Order to \"streamline\" export\/import process for US business. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Stcrow\/status\/436221140420132864\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/VxJY7W6CAP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg3E0ObCAAETG8J.jpg",
        "id_str" : "436221140428521473",
        "id" : 436221140428521473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg3E0ObCAAETG8J.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 689,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1010,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VxJY7W6CAP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "436221140420132864",
    "text" : "62 SECONDS W THE PRESIDENT ABOARD AF1- signs Executive Order to \"streamline\" export\/import process for US business. http:\/\/t.co\/VxJY7W6CAP",
    "id" : 436221140420132864,
    "created_at" : "2014-02-19 19:29:59 +0000",
    "user" : {
      "name" : "Stephen Crowley",
      "screen_name" : "Stcrow",
      "protected" : false,
      "id_str" : "24715018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691718175004758020\/jqjxoXpB_normal.jpg",
      "id" : 24715018,
      "verified" : true
    }
  },
  "id" : 436226933056352257,
  "created_at" : "2014-02-19 19:53:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 73, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/twKmzTZKWR",
      "expanded_url" : "http:\/\/go.wh.gov\/s14aWG",
      "display_url" : "go.wh.gov\/s14aWG"
    } ]
  },
  "geo" : { },
  "id_str" : "436223259756220416",
  "text" : "Where Congress won't act, here's what President Obama is doing to expand #OpportunityForAll hardworking Americans \u270D\u260F http:\/\/t.co\/twKmzTZKWR",
  "id" : 436223259756220416,
  "created_at" : "2014-02-19 19:38:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 37, 46 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436213819736866816",
  "text" : "RT @Utech44: 2 new solar plants from @Interior brings the total to 50 approvals of renewables projects on public lands since 2009! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 24, 33 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/TnM4Ejbhr6",
        "expanded_url" : "http:\/\/www.doi.gov\/news\/pressreleases\/secretary-jewell-announces-two-solar-projects-approved-in-california-nevada.cfm",
        "display_url" : "doi.gov\/news\/pressrele\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "436193797329154049",
    "text" : "2 new solar plants from @Interior brings the total to 50 approvals of renewables projects on public lands since 2009! http:\/\/t.co\/TnM4Ejbhr6",
    "id" : 436193797329154049,
    "created_at" : "2014-02-19 17:41:20 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 436213819736866816,
  "created_at" : "2014-02-19 19:00:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/h1fHYFPQ9K",
      "expanded_url" : "http:\/\/go.wh.gov\/HQaKUs",
      "display_url" : "go.wh.gov\/HQaKUs"
    } ]
  },
  "geo" : { },
  "id_str" : "436178452085866496",
  "text" : "FACT: The nonpartisan CBO found that raising the min wage would lift 900,000 Americans out of poverty. http:\/\/t.co\/h1fHYFPQ9K #RaiseTheWage",
  "id" : 436178452085866496,
  "created_at" : "2014-02-19 16:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/8DMo9dWRdm",
      "expanded_url" : "http:\/\/go.wh.gov\/ecyttp",
      "display_url" : "go.wh.gov\/ecyttp"
    } ]
  },
  "geo" : { },
  "id_str" : "436170901432721409",
  "text" : "FACT: Raising the minimum wage would increase incomes for millions of middle-class families. http:\/\/t.co\/8DMo9dWRdm #RaiseTheWage",
  "id" : 436170901432721409,
  "created_at" : "2014-02-19 16:10:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/L9mNqLaXoC",
      "expanded_url" : "http:\/\/go.wh.gov\/viLPun",
      "display_url" : "go.wh.gov\/viLPun"
    } ]
  },
  "geo" : { },
  "id_str" : "436160829495734272",
  "text" : "\"Preserving an open Internet is vital not to just to the free flow of information, but also to promoting innovation.\" http:\/\/t.co\/L9mNqLaXoC",
  "id" : 436160829495734272,
  "created_at" : "2014-02-19 15:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/436149842683756544\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/5HTujgGMqo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bg2D-JFCAAIDh9g.jpg",
      "id_str" : "436149842536955906",
      "id" : 436149842536955906,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bg2D-JFCAAIDh9g.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5HTujgGMqo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436149842683756544",
  "text" : "Wheels up to Mexico for the North American Leaders Summit \u2708 \u2708 \u2708 http:\/\/t.co\/5HTujgGMqo",
  "id" : 436149842683756544,
  "created_at" : "2014-02-19 14:46:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/435925807853096960\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Hh22C1uUI5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bgy4Nm4CUAAzX4V.jpg",
      "id_str" : "435925807861485568",
      "id" : 435925807861485568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bgy4Nm4CUAAzX4V.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Hh22C1uUI5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435927515186855937",
  "text" : "RT @petesouza: A Japanese WWII veteran salutes Pres Obama during their greet in the Oval Office today http:\/\/t.co\/Hh22C1uUI5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/435925807853096960\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/Hh22C1uUI5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bgy4Nm4CUAAzX4V.jpg",
        "id_str" : "435925807861485568",
        "id" : 435925807861485568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bgy4Nm4CUAAzX4V.jpg",
        "sizes" : [ {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Hh22C1uUI5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435925807853096960",
    "text" : "A Japanese WWII veteran salutes Pres Obama during their greet in the Oval Office today http:\/\/t.co\/Hh22C1uUI5",
    "id" : 435925807853096960,
    "created_at" : "2014-02-18 23:56:26 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 435927515186855937,
  "created_at" : "2014-02-19 00:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/CxUTb9ltuE",
      "expanded_url" : "http:\/\/go.wh.gov\/PN3vzF",
      "display_url" : "go.wh.gov\/PN3vzF"
    } ]
  },
  "geo" : { },
  "id_str" : "435915463713767424",
  "text" : "Get the latest on how President Obama is kicking vehicle efficiency into high gear: http:\/\/t.co\/CxUTb9ltuE #ActOnClimate",
  "id" : 435915463713767424,
  "created_at" : "2014-02-18 23:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435907612518133761",
  "text" : "RT @VP: PHOTO: The VP met w\/ student advocates, survivors &amp; educators working to improve sexual assault policies at schools. http:\/\/t.co\/sz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/435906066593742848\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/szznP4xuGG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgymQg8CAAAfGsc.png",
        "id_str" : "435906066597937152",
        "id" : 435906066597937152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgymQg8CAAAfGsc.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/szznP4xuGG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435906066593742848",
    "text" : "PHOTO: The VP met w\/ student advocates, survivors &amp; educators working to improve sexual assault policies at schools. http:\/\/t.co\/szznP4xuGG",
    "id" : 435906066593742848,
    "created_at" : "2014-02-18 22:38:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 435907612518133761,
  "created_at" : "2014-02-18 22:44:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/435902651075534848\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/L4PrxMv0xH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgyjJsvCcAAyxXh.jpg",
      "id_str" : "435902650970697728",
      "id" : 435902650970697728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgyjJsvCcAAyxXh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/L4PrxMv0xH"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435902651075534848",
  "text" : "Raising the minimum wage to $10.10 would boost wages for 16.5 million Americans. Let's make it happen. #RaiseTheWage http:\/\/t.co\/L4PrxMv0xH",
  "id" : 435902651075534848,
  "created_at" : "2014-02-18 22:24:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/b1ooNUoP41",
      "expanded_url" : "http:\/\/go.wh.gov\/4xQnbL",
      "display_url" : "go.wh.gov\/4xQnbL"
    } ]
  },
  "geo" : { },
  "id_str" : "435893866043305984",
  "text" : "Nonpartisan CBO: Raising the minimum wage to $10.10 would increase wages for 16.5 million Americans: http:\/\/t.co\/b1ooNUoP41 #RaiseTheWage",
  "id" : 435893866043305984,
  "created_at" : "2014-02-18 21:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/435877723542523904\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sFjOHn8Lmc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgyMeuECEAAUjuI.jpg",
      "id_str" : "435877723337003008",
      "id" : 435877723337003008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgyMeuECEAAUjuI.jpg",
      "sizes" : [ {
        "h" : 432,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1079,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 737,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sFjOHn8Lmc"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/C8P3bDGIzx",
      "expanded_url" : "http:\/\/go.wh.gov\/scuEZ4",
      "display_url" : "go.wh.gov\/scuEZ4"
    } ]
  },
  "geo" : { },
  "id_str" : "435877723542523904",
  "text" : "Here's how President Obama's helping communities impacted by the drought in CA: http:\/\/t.co\/C8P3bDGIzx #ActOnClimate http:\/\/t.co\/sFjOHn8Lmc",
  "id" : 435877723542523904,
  "created_at" : "2014-02-18 20:45:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435866392567353346",
  "text" : "RT if you agree: It's time to end subsidies for oil and gas companies that have never been more profitable and invest in clean energy.",
  "id" : 435866392567353346,
  "created_at" : "2014-02-18 20:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 75, 87 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/z2JpgZXQJp",
      "expanded_url" : "http:\/\/go.wh.gov\/aMgwyJ",
      "display_url" : "go.wh.gov\/aMgwyJ"
    } ]
  },
  "geo" : { },
  "id_str" : "435861119841087488",
  "text" : "\"An open Internet is an engine for freedom around the world.\" \u2014White House @WeThePeople response on #NetNeutrality: http:\/\/t.co\/z2JpgZXQJp",
  "id" : 435861119841087488,
  "created_at" : "2014-02-18 19:39:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/PYUJJ82fZy",
      "expanded_url" : "http:\/\/go.wh.gov\/GGLVN6",
      "display_url" : "go.wh.gov\/GGLVN6"
    } ]
  },
  "geo" : { },
  "id_str" : "435855064331079680",
  "text" : "President Obama is partnering with business leaders to deploy advanced trucks that use less fuel: http:\/\/t.co\/PYUJJ82fZy #ActOnClimate",
  "id" : 435855064331079680,
  "created_at" : "2014-02-18 19:15:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435843742797287424",
  "text" : "FACT: President Obama's 1st round of fuel efficiency standards for trucks will save $50 billion in fuel costs &amp; 530 million barrels of oil.",
  "id" : 435843742797287424,
  "created_at" : "2014-02-18 18:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 11, 19 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 112, 125 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 136, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435830471977889794",
  "text" : "At 1pm ET, @Utech44 will answer your Qs about President Obama's new fuel efficiency standards &amp; his plan to #ActOnClimate. Ask with #WHChat.",
  "id" : 435830471977889794,
  "created_at" : "2014-02-18 17:37:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435818624813899776",
  "text" : "President Obama: \"If you bet against American workers...if you bet against America\u2014you\u2019re going to lose money every time.\" #ActOnClimate",
  "id" : 435818624813899776,
  "created_at" : "2014-02-18 16:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435818326166892544",
  "text" : "President Obama: \"Anyone who said you can\u2019t grow the economy while reducing carbon pollution has been proven wrong.\" #ActOnClimate",
  "id" : 435818326166892544,
  "created_at" : "2014-02-18 16:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "TransportationGov",
      "screen_name" : "USDOT",
      "indices" : [ 35, 41 ],
      "id_str" : "393562221",
      "id" : 393562221
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 48, 52 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435817689366691840",
  "text" : "RT @WHLive: Obama: \"I\u2019m directing [@USDOT &amp; @EPA] to develop fuel economy standards for heavy-duty trucks that will take us well into the n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TransportationGov",
        "screen_name" : "USDOT",
        "indices" : [ 23, 29 ],
        "id_str" : "393562221",
        "id" : 393562221
      }, {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 36, 40 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435817524819918848",
    "text" : "Obama: \"I\u2019m directing [@USDOT &amp; @EPA] to develop fuel economy standards for heavy-duty trucks that will take us well into the next decade.\"",
    "id" : 435817524819918848,
    "created_at" : "2014-02-18 16:46:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 435817689366691840,
  "created_at" : "2014-02-18 16:46:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/435816990683328514\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/7IMoHSH1mR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgxVPm3CMAAIqIn.jpg",
      "id_str" : "435816990565871616",
      "id" : 435816990565871616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgxVPm3CMAAIqIn.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/7IMoHSH1mR"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435816990683328514",
  "text" : "President Obama's partnering with manufacturers to support innovation for trucks that use less fuel. #ActOnClimate http:\/\/t.co\/7IMoHSH1mR",
  "id" : 435816990683328514,
  "created_at" : "2014-02-18 16:44:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435816261550080000",
  "text" : "Obama: \"Since we stepped in to help our automakers retool, the American auto industry has created almost 425,000 new jobs.\" #MadeInAmerica",
  "id" : 435816261550080000,
  "created_at" : "2014-02-18 16:41:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435815825321492480",
  "text" : "President Obama: \"We're going to double the distance our cars and light trucks can go on a gallon of gas by 2025.\" #ActOnClimate",
  "id" : 435815825321492480,
  "created_at" : "2014-02-18 16:39:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435815628860313601",
  "text" : "RT @WHLive: Obama: \"We set in motion the first-ever national policy aimed at both increasing gas mileage and decreasing carbon pollution.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435815540733788160",
    "text" : "Obama: \"We set in motion the first-ever national policy aimed at both increasing gas mileage and decreasing carbon pollution.\" #ActOnClimate",
    "id" : 435815540733788160,
    "created_at" : "2014-02-18 16:38:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 435815628860313601,
  "created_at" : "2014-02-18 16:38:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435815347875479553",
  "text" : "RT @WHLive: Obama: \"We dedicated ourselves to manufacturing new cars and trucks that go farther on a gallon of gas\u2014saving families money.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435815237175222272",
    "text" : "Obama: \"We dedicated ourselves to manufacturing new cars and trucks that go farther on a gallon of gas\u2014saving families money.\" #ActOnClimate",
    "id" : 435815237175222272,
    "created_at" : "2014-02-18 16:37:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 435815347875479553,
  "created_at" : "2014-02-18 16:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435814650467586048",
  "text" : "Obama: \"I\u2019m eager to work with Congress wherever I can\u2014but whenever I can act on my own to expand opportunity for more Americans\u2014I will.\" \u270D\u260F",
  "id" : 435814650467586048,
  "created_at" : "2014-02-18 16:34:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435814597812314112",
  "text" : "RT @WHLive: Obama: \"I\u2019ve acted to require federal contractors to pay their employees a fair wage of at least $10.10\/hour.\" #RaiseTheWage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 111, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435814245838909440",
    "text" : "Obama: \"I\u2019ve acted to require federal contractors to pay their employees a fair wage of at least $10.10\/hour.\" #RaiseTheWage",
    "id" : 435814245838909440,
    "created_at" : "2014-02-18 16:33:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 435814597812314112,
  "created_at" : "2014-02-18 16:34:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435814180105752576",
  "text" : "President Obama: \"Today...we take another big step to grow our economy and reduce America\u2019s dependence on foreign oil.\" #ActOnClimate",
  "id" : 435814180105752576,
  "created_at" : "2014-02-18 16:32:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/fDZZ0L02bQ",
      "expanded_url" : "http:\/\/go.wh.gov\/MTMxSW",
      "display_url" : "go.wh.gov\/MTMxSW"
    } ]
  },
  "geo" : { },
  "id_str" : "435808092690055170",
  "text" : "Don't miss President Obama speak at 11:20am ET about boosting the fuel efficiency of America's trucks \u2192 http:\/\/t.co\/fDZZ0L02bQ #ActOnClimate",
  "id" : 435808092690055170,
  "created_at" : "2014-02-18 16:08:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 3, 12 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/jSCkd7rH9e",
      "expanded_url" : "http:\/\/usat.ly\/1dHEc4k",
      "display_url" : "usat.ly\/1dHEc4k"
    } ]
  },
  "geo" : { },
  "id_str" : "435804295989297152",
  "text" : "RT @USATODAY: Obama will follow up on his #SOTU pledge to set new fuel standards for trucks today: http:\/\/t.co\/jSCkd7rH9e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 28, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/jSCkd7rH9e",
        "expanded_url" : "http:\/\/usat.ly\/1dHEc4k",
        "display_url" : "usat.ly\/1dHEc4k"
      } ]
    },
    "geo" : { },
    "id_str" : "435790330735366144",
    "text" : "Obama will follow up on his #SOTU pledge to set new fuel standards for trucks today: http:\/\/t.co\/jSCkd7rH9e",
    "id" : 435790330735366144,
    "created_at" : "2014-02-18 14:58:06 +0000",
    "user" : {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "protected" : false,
      "id_str" : "15754281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761954996808286209\/S15RXwx6_normal.jpg",
      "id" : 15754281,
      "verified" : true
    }
  },
  "id" : 435804295989297152,
  "created_at" : "2014-02-18 15:53:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435802216046157825",
  "text" : "President Obama's efficiency standards for trucks will:\n\u2022 \u2191 energy security\n\u2022 \u2704 carbon pollution\n\u2022 Save $\n\u2022 \u2191 manufacturing\n#ActOnClimate",
  "id" : 435802216046157825,
  "created_at" : "2014-02-18 15:45:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/A5bMeOOd5E",
      "expanded_url" : "http:\/\/go.wh.gov\/CqFMJU",
      "display_url" : "go.wh.gov\/CqFMJU"
    } ]
  },
  "geo" : { },
  "id_str" : "435799006120529920",
  "text" : "Today, President Obama will lay out his plan to keep improving the fuel efficiency of America's trucks: http:\/\/t.co\/A5bMeOOd5E #ActOnClimate",
  "id" : 435799006120529920,
  "created_at" : "2014-02-18 15:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 115, 123 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435794994478456832",
  "text" : "RT @pfeiffer44: Latest move in Obama's year of action: Obama to Request New Rules for Cutting Truck Pollution, via @nytimes http:\/\/t.co\/2Ch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 99, 107 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/2ChRjQbeoD",
        "expanded_url" : "http:\/\/nyti.ms\/1dFXdnD",
        "display_url" : "nyti.ms\/1dFXdnD"
      } ]
    },
    "geo" : { },
    "id_str" : "435736299769982976",
    "text" : "Latest move in Obama's year of action: Obama to Request New Rules for Cutting Truck Pollution, via @nytimes http:\/\/t.co\/2ChRjQbeoD",
    "id" : 435736299769982976,
    "created_at" : "2014-02-18 11:23:24 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 435794994478456832,
  "created_at" : "2014-02-18 15:16:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435519098030546945",
  "text" : "FACT: The Recovery Act will improve nearly 42,000 miles of road and mend or replace more than 2,700 bridges. #RebuildAmerica",
  "id" : 435519098030546945,
  "created_at" : "2014-02-17 21:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/0qxENkUriO",
      "expanded_url" : "http:\/\/go.wh.gov\/HE6Vvy",
      "display_url" : "go.wh.gov\/HE6Vvy"
    } ]
  },
  "geo" : { },
  "id_str" : "435507770511470592",
  "text" : "FACT: More than 160 million American workers received tax cuts thanks to the Recovery Act &amp; subsequent jobs measures. http:\/\/t.co\/0qxENkUriO",
  "id" : 435507770511470592,
  "created_at" : "2014-02-17 20:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/El5Evtl3yR",
      "expanded_url" : "http:\/\/go.wh.gov\/LW3rsJ",
      "display_url" : "go.wh.gov\/LW3rsJ"
    } ]
  },
  "geo" : { },
  "id_str" : "435498961713901575",
  "text" : "Want to see George Washington in HD? You're in luck \u2192 http:\/\/t.co\/El5Evtl3yR #PresidentsDay",
  "id" : 435498961713901575,
  "created_at" : "2014-02-17 19:40:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/wSbOQUqvds",
      "expanded_url" : "http:\/\/go.wh.gov\/tNYAjN",
      "display_url" : "go.wh.gov\/tNYAjN"
    } ]
  },
  "geo" : { },
  "id_str" : "435491412612616196",
  "text" : "FACT: The Recovery Act saved or created an average of 1.6 million jobs a year for 4 years through 2012. http:\/\/t.co\/wSbOQUqvds #ActOnJobs",
  "id" : 435491412612616196,
  "created_at" : "2014-02-17 19:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/fqWn8ArSb7",
      "expanded_url" : "http:\/\/go.wh.gov\/5YcNK4",
      "display_url" : "go.wh.gov\/5YcNK4"
    } ]
  },
  "geo" : { },
  "id_str" : "435481345863581697",
  "text" : "From George Washington to Barack Obama, here's where you can learn about all 44 Presidents \u2192 http:\/\/t.co\/fqWn8ArSb7 #PresidentsDay",
  "id" : 435481345863581697,
  "created_at" : "2014-02-17 18:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/435466627908255744\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/RFFSQi4pla",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgsWlzkCcAAd5AL.jpg",
      "id_str" : "435466627723718656",
      "id" : 435466627723718656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgsWlzkCcAAd5AL.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/RFFSQi4pla"
    } ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 6, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/wByVUg1Wme",
      "expanded_url" : "http:\/\/go.wh.gov\/ynA7AU",
      "display_url" : "go.wh.gov\/ynA7AU"
    } ]
  },
  "geo" : { },
  "id_str" : "435466627908255744",
  "text" : "Happy #PresidentsDay! http:\/\/t.co\/wByVUg1Wme, http:\/\/t.co\/RFFSQi4pla",
  "id" : 435466627908255744,
  "created_at" : "2014-02-17 17:31:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dc",
      "indices" : [ 117, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435460020478562304",
  "text" : "RT @Interior: Happy Presidents Day! Here's a photo of the Washington Monument from an angle you don't see every day. #dc http:\/\/t.co\/wAMwYx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/435446077668741120\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/wAMwYxJcSE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgsD5noIEAAWFvt.jpg",
        "id_str" : "435446077396094976",
        "id" : 435446077396094976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgsD5noIEAAWFvt.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wAMwYxJcSE"
      } ],
      "hashtags" : [ {
        "text" : "dc",
        "indices" : [ 103, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "435446077668741120",
    "text" : "Happy Presidents Day! Here's a photo of the Washington Monument from an angle you don't see every day. #dc http:\/\/t.co\/wAMwYxJcSE",
    "id" : 435446077668741120,
    "created_at" : "2014-02-17 16:10:09 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 435460020478562304,
  "created_at" : "2014-02-17 17:05:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435447073203183616",
  "text" : "5 years ago today, President Obama took action to bring our economy back from the brink by signing the Recovery Act into law. #ActOnJobs",
  "id" : 435447073203183616,
  "created_at" : "2014-02-17 16:14:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/zptwRoCxxI",
      "expanded_url" : "http:\/\/go.wh.gov\/AVVyRp",
      "display_url" : "go.wh.gov\/AVVyRp"
    } ]
  },
  "geo" : { },
  "id_str" : "435122726991192065",
  "text" : "Obama: \"Since I 1st asked Congress to raise the min wage, 6 states have passed laws to raise theirs.\" http:\/\/t.co\/zptwRoCxxI #RaiseTheWage",
  "id" : 435122726991192065,
  "created_at" : "2014-02-16 18:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/3V0biChA3a",
      "expanded_url" : "http:\/\/go.wh.gov\/NB5Gyf",
      "display_url" : "go.wh.gov\/NB5Gyf"
    } ]
  },
  "geo" : { },
  "id_str" : "435087509660631041",
  "text" : "Here's a behind-the-scenes peek at the President's week, including the France State Dinner &amp; a view from Marine One \u2192 http:\/\/t.co\/3V0biChA3a",
  "id" : 435087509660631041,
  "created_at" : "2014-02-16 16:25:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/I0sCDvYMiH",
      "expanded_url" : "http:\/\/go.wh.gov\/zzwZLd",
      "display_url" : "go.wh.gov\/zzwZLd"
    } ]
  },
  "geo" : { },
  "id_str" : "435069625701658624",
  "text" : "Obama: \"Raising the min wage wouldn\u2019t just raise their wages\u2014its effect would lift wages for...28 million Americans\" http:\/\/t.co\/I0sCDvYMiH",
  "id" : 435069625701658624,
  "created_at" : "2014-02-16 15:14:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/J7OtMBkCom",
      "expanded_url" : "http:\/\/go.wh.gov\/qMW8RM",
      "display_url" : "go.wh.gov\/qMW8RM"
    } ]
  },
  "geo" : { },
  "id_str" : "434833818881495040",
  "text" : "Obama: \"Let\u2019s make opportunity easier to come by for every American who\u2019s willing to work for it.\" http:\/\/t.co\/J7OtMBkCom #RaiseTheWage",
  "id" : 434833818881495040,
  "created_at" : "2014-02-15 23:37:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SprintCeleb",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434800195499745281",
  "text" : "RT @arneduncan: I had a great time--and a great team--at #SprintCeleb game. Thx for all the support. Keep cheering for education! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/arneduncan\/status\/434511328653221889\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/ky1qpxGXUk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgexwFPCIAARlrl.jpg",
        "id_str" : "434511328661610496",
        "id" : 434511328661610496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgexwFPCIAARlrl.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 200,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ky1qpxGXUk"
      } ],
      "hashtags" : [ {
        "text" : "SprintCeleb",
        "indices" : [ 41, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434511328653221889",
    "text" : "I had a great time--and a great team--at #SprintCeleb game. Thx for all the support. Keep cheering for education! http:\/\/t.co\/ky1qpxGXUk",
    "id" : 434511328653221889,
    "created_at" : "2014-02-15 02:15:48 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 434800195499745281,
  "created_at" : "2014-02-15 21:23:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/R3oVZ3zEdJ",
      "expanded_url" : "http:\/\/go.wh.gov\/qxdunh",
      "display_url" : "go.wh.gov\/qxdunh"
    } ]
  },
  "geo" : { },
  "id_str" : "434790532183629825",
  "text" : "Obama: \"The average worker who would get a raise if Congress acts is about 35 years old.\" http:\/\/t.co\/R3oVZ3zEdJ #RaiseTheWage",
  "id" : 434790532183629825,
  "created_at" : "2014-02-15 20:45:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Z2ShzTyvyZ",
      "expanded_url" : "http:\/\/go.wh.gov\/aeReLi",
      "display_url" : "go.wh.gov\/aeReLi"
    } ]
  },
  "geo" : { },
  "id_str" : "434733153211531265",
  "text" : "Obama: \"I took action...by requiring federal contractors to pay their employees a fair wage of at least $10.10\/hour.\" http:\/\/t.co\/Z2ShzTyvyZ",
  "id" : 434733153211531265,
  "created_at" : "2014-02-15 16:57:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoTeamUSA",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434725519654133760",
  "text" : "Congrats to T.J. Oshie and the U.S. men's hockey team on a huge win! Never stop believing in miracles. #GoTeamUSA -bo",
  "id" : 434725519654133760,
  "created_at" : "2014-02-15 16:26:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/wLghYQz2qY",
      "expanded_url" : "http:\/\/go.wh.gov\/HijjcB",
      "display_url" : "go.wh.gov\/HijjcB"
    } ]
  },
  "geo" : { },
  "id_str" : "434694900454391808",
  "text" : "President Obama's Weekly Address: Calling on Congress to Raise the Minimum Wage \u2192 http:\/\/t.co\/wLghYQz2qY #RaiseTheWage",
  "id" : 434694900454391808,
  "created_at" : "2014-02-15 14:25:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434481498490548224\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/MPwlieSEfK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgeWnudCUAAj6yc.jpg",
      "id_str" : "434481498293424128",
      "id" : 434481498293424128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgeWnudCUAAj6yc.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MPwlieSEfK"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "434481498490548224",
  "text" : "Happy Valentine's Day! Make sure your loved ones #GetCovered: http:\/\/t.co\/uvXCniOFSK, http:\/\/t.co\/MPwlieSEfK",
  "id" : 434481498490548224,
  "created_at" : "2014-02-15 00:17:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434472395513298946",
  "text" : "RT @Interior: In honor of Presidents Day, all national parks will be free this weekend. RT to spread the word!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434448664602636288",
    "text" : "In honor of Presidents Day, all national parks will be free this weekend. RT to spread the word!",
    "id" : 434448664602636288,
    "created_at" : "2014-02-14 22:06:47 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 434472395513298946,
  "created_at" : "2014-02-14 23:41:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434468169214746624\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/dHA6bEYU8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgeKf3OCcAEkKCI.jpg",
      "id_str" : "434468169067950081",
      "id" : 434468169067950081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgeKf3OCcAEkKCI.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/dHA6bEYU8g"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 22, 33 ]
    }, {
      "text" : "HappyValentinesDay",
      "indices" : [ 68, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "434468169214746624",
  "text" : "Single and looking to #GetCovered? Check out http:\/\/t.co\/uvXCniOFSK #HappyValentinesDay, http:\/\/t.co\/dHA6bEYU8g",
  "id" : 434468169214746624,
  "created_at" : "2014-02-14 23:24:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434446543261671424\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/Zso2W4nQFl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bgd21ECCMAAXZHp.jpg",
      "id_str" : "434446543051960320",
      "id" : 434446543051960320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bgd21ECCMAAXZHp.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Zso2W4nQFl"
    } ],
    "hashtags" : [ {
      "text" : "HappyValentinesDay",
      "indices" : [ 7, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434446543261671424",
  "text" : "May I? #HappyValentinesDay http:\/\/t.co\/Zso2W4nQFl",
  "id" : 434446543261671424,
  "created_at" : "2014-02-14 21:58:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/oZVRaXr6bQ",
      "expanded_url" : "http:\/\/go.wh.gov\/Qz7NwL",
      "display_url" : "go.wh.gov\/Qz7NwL"
    } ]
  },
  "geo" : { },
  "id_str" : "434439002687807488",
  "text" : "RT @FLOTUS: \"That's what getting covered is all about: being ready for whatever comes your way.\" \u2014The First Lady: http:\/\/t.co\/oZVRaXr6bQ #G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/oZVRaXr6bQ",
        "expanded_url" : "http:\/\/go.wh.gov\/Qz7NwL",
        "display_url" : "go.wh.gov\/Qz7NwL"
      } ]
    },
    "geo" : { },
    "id_str" : "434438043907657728",
    "text" : "\"That's what getting covered is all about: being ready for whatever comes your way.\" \u2014The First Lady: http:\/\/t.co\/oZVRaXr6bQ #GetCovered",
    "id" : 434438043907657728,
    "created_at" : "2014-02-14 21:24:35 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 434439002687807488,
  "created_at" : "2014-02-14 21:28:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ValentinesDay",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/5zeR2S7xZe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "434433656078491648",
  "text" : "Got a pre-existing condition? Thanks to the Affordable Care Act, your coverage will still love you: http:\/\/t.co\/5zeR2S7xZe #ValentinesDay",
  "id" : 434433656078491648,
  "created_at" : "2014-02-14 21:07:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ValentinesDay",
      "indices" : [ 58, 72 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 133, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/0gdakq6No1",
      "expanded_url" : "http:\/\/link.fox4kc.com\/1gAEQza",
      "display_url" : "link.fox4kc.com\/1gAEQza"
    } ]
  },
  "geo" : { },
  "id_str" : "434424303333830656",
  "text" : "Mike O'Dell received a new healthy heart just in time for #ValentinesDay &amp; says Obamacare saved his life: http:\/\/t.co\/0gdakq6No1 #GetCovered",
  "id" : 434424303333830656,
  "created_at" : "2014-02-14 20:29:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mindy Kaling",
      "screen_name" : "mindykaling",
      "indices" : [ 3, 15 ],
      "id_str" : "23544596",
      "id" : 23544596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/6RrkgblZJF",
      "expanded_url" : "http:\/\/instagram.com\/p\/kaCy2bJQ4M\/",
      "display_url" : "instagram.com\/p\/kaCy2bJQ4M\/"
    } ]
  },
  "geo" : { },
  "id_str" : "434421033958117376",
  "text" : "RT @mindykaling: Happy Valentines Day!#getcovered http:\/\/t.co\/6RrkgblZJF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 21, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/6RrkgblZJF",
        "expanded_url" : "http:\/\/instagram.com\/p\/kaCy2bJQ4M\/",
        "display_url" : "instagram.com\/p\/kaCy2bJQ4M\/"
      } ]
    },
    "geo" : { },
    "id_str" : "434397099183341570",
    "text" : "Happy Valentines Day!#getcovered http:\/\/t.co\/6RrkgblZJF",
    "id" : 434397099183341570,
    "created_at" : "2014-02-14 18:41:53 +0000",
    "user" : {
      "name" : "Mindy Kaling",
      "screen_name" : "mindykaling",
      "protected" : false,
      "id_str" : "23544596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790530450892529666\/P51bmCHe_normal.jpg",
      "id" : 23544596,
      "verified" : true
    }
  },
  "id" : 434421033958117376,
  "created_at" : "2014-02-14 20:17:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatWomenNeed",
      "indices" : [ 91, 105 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434417591495708672",
  "text" : "RT @CEABetsey: Roses are red, violets are blue, I think women need a raise, how about you? #WhatWomenNeed #RaiseTheWage http:\/\/t.co\/kzFcHxh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/434416647776923648\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/kzFcHxhFYW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bgdbo7eCcAAAnor.jpg",
        "id_str" : "434416647781117952",
        "id" : 434416647781117952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bgdbo7eCcAAAnor.jpg",
        "sizes" : [ {
          "h" : 742,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1266,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1657
        } ],
        "display_url" : "pic.twitter.com\/kzFcHxhFYW"
      } ],
      "hashtags" : [ {
        "text" : "WhatWomenNeed",
        "indices" : [ 76, 90 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 91, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434416647776923648",
    "text" : "Roses are red, violets are blue, I think women need a raise, how about you? #WhatWomenNeed #RaiseTheWage http:\/\/t.co\/kzFcHxhFYW",
    "id" : 434416647776923648,
    "created_at" : "2014-02-14 19:59:34 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 434417591495708672,
  "created_at" : "2014-02-14 20:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/eTfU7hSMWR",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "434416027288354816",
  "text" : "RT @HealthCareGov: Happy Valentine\u2019s Day! Don\u2019t forget to tell your loved ones to #GetCovered - enroll now at http:\/\/t.co\/eTfU7hSMWR! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.wildfireapp.com\/?utm_source=Twitter&utm_medium=Tweet&utm_campaign=via%2BWildfire%2BSuite\" rel=\"nofollow\"\u003EWildfire Suite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HealthCareGov\/status\/434405087122051072\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/G04xHZD1Wt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgdRH_OIAAEvR0q.png",
        "id_str" : "434405086736154625",
        "id" : 434405086736154625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgdRH_OIAAEvR0q.png",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/G04xHZD1Wt"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 63, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/eTfU7hSMWR",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "434405087122051072",
    "text" : "Happy Valentine\u2019s Day! Don\u2019t forget to tell your loved ones to #GetCovered - enroll now at http:\/\/t.co\/eTfU7hSMWR! http:\/\/t.co\/G04xHZD1Wt",
    "id" : 434405087122051072,
    "created_at" : "2014-02-14 19:13:38 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 434416027288354816,
  "created_at" : "2014-02-14 19:57:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lance Bass",
      "screen_name" : "LanceBass",
      "indices" : [ 3, 13 ],
      "id_str" : "78693749",
      "id" : 78693749
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/hY4UVh42Pi",
      "expanded_url" : "http:\/\/tellafriendgetcovered.com",
      "display_url" : "tellafriendgetcovered.com"
    } ]
  },
  "geo" : { },
  "id_str" : "434409140505804800",
  "text" : "RT @LanceBass: Thanks to the ACA, my fianc\u00E9 was able to get insurance. Make sure your LOVED ones #GetCovered http:\/\/t.co\/hY4UVh42Pi http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList Pro\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LanceBass\/status\/434401881108914176\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/RdfHswOvC6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgdONYwCUAAarCn.jpg",
        "id_str" : "434401880953737216",
        "id" : 434401880953737216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgdONYwCUAAarCn.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RdfHswOvC6"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 82, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/hY4UVh42Pi",
        "expanded_url" : "http:\/\/tellafriendgetcovered.com",
        "display_url" : "tellafriendgetcovered.com"
      } ]
    },
    "geo" : { },
    "id_str" : "434401881108914176",
    "text" : "Thanks to the ACA, my fianc\u00E9 was able to get insurance. Make sure your LOVED ones #GetCovered http:\/\/t.co\/hY4UVh42Pi http:\/\/t.co\/RdfHswOvC6",
    "id" : 434401881108914176,
    "created_at" : "2014-02-14 19:00:53 +0000",
    "user" : {
      "name" : "Lance Bass",
      "screen_name" : "LanceBass",
      "protected" : false,
      "id_str" : "78693749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796450038679412736\/U_oDvNzD_normal.jpg",
      "id" : 78693749,
      "verified" : true
    }
  },
  "id" : 434409140505804800,
  "created_at" : "2014-02-14 19:29:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Longoria Baston",
      "screen_name" : "EvaLongoria",
      "indices" : [ 3, 15 ],
      "id_str" : "110827653",
      "id" : 110827653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 47, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "434405489426718720",
  "text" : "MT @EvaLongoria: Make sure you and your family #GetCovered! Sign up for affordable health care here: http:\/\/t.co\/uvXCniOFSK",
  "id" : 434405489426718720,
  "created_at" : "2014-02-14 19:15:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "indices" : [ 3, 12 ],
      "id_str" : "338084918",
      "id" : 338084918
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GETCOVERED",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/7t6a4DCKZn",
      "expanded_url" : "http:\/\/tellafriendgetcovered.com",
      "display_url" : "tellafriendgetcovered.com"
    } ]
  },
  "geo" : { },
  "id_str" : "434401601814798337",
  "text" : "RT @Pharrell: Tell your friends, family, cousins, cousin's friends, cousin's friends' family to #GETCOVERED http:\/\/t.co\/7t6a4DCKZn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GETCOVERED",
        "indices" : [ 82, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/7t6a4DCKZn",
        "expanded_url" : "http:\/\/tellafriendgetcovered.com",
        "display_url" : "tellafriendgetcovered.com"
      } ]
    },
    "geo" : { },
    "id_str" : "434383661408870400",
    "text" : "Tell your friends, family, cousins, cousin's friends, cousin's friends' family to #GETCOVERED http:\/\/t.co\/7t6a4DCKZn",
    "id" : 434383661408870400,
    "created_at" : "2014-02-14 17:48:30 +0000",
    "user" : {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "protected" : false,
      "id_str" : "338084918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777892792328531968\/aRbbZcMo_normal.jpg",
      "id" : 338084918,
      "verified" : true
    }
  },
  "id" : 434401601814798337,
  "created_at" : "2014-02-14 18:59:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 96, 107 ]
    }, {
      "text" : "healthpolicyvalentines",
      "indices" : [ 108, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434397333347135488",
  "text" : "RT @Cecilia44: Life without you is like life without getting covered, potentially catastrophic. #getcovered #healthpolicyvalentines",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 81, 92 ]
      }, {
        "text" : "healthpolicyvalentines",
        "indices" : [ 93, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434392400421601281",
    "text" : "Life without you is like life without getting covered, potentially catastrophic. #getcovered #healthpolicyvalentines",
    "id" : 434392400421601281,
    "created_at" : "2014-02-14 18:23:13 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 434397333347135488,
  "created_at" : "2014-02-14 18:42:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434394074619973632\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/dYNuAVrFfl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgdHG_UCcAAc2Yd.jpg",
      "id_str" : "434394074464808960",
      "id" : 434394074464808960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgdHG_UCcAAc2Yd.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/dYNuAVrFfl"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "ValentinesDay",
      "indices" : [ 57, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "434394074619973632",
  "text" : "Help a loved one or that special someone #GetCovered for #ValentinesDay \u2192 http:\/\/t.co\/uvXCniOFSK, http:\/\/t.co\/dYNuAVrFfl",
  "id" : 434394074619973632,
  "created_at" : "2014-02-14 18:29:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 3, 13 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/IYg5hurqib",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "434378758787956736",
  "text" : "RT @UncleRUSH: Encourage your special someone to #GetCovered today! http:\/\/t.co\/IYg5hurqib RT!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 34, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/IYg5hurqib",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "434371142145421312",
    "text" : "Encourage your special someone to #GetCovered today! http:\/\/t.co\/IYg5hurqib RT!",
    "id" : 434371142145421312,
    "created_at" : "2014-02-14 16:58:45 +0000",
    "user" : {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "protected" : false,
      "id_str" : "25110374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748232081008959488\/0fWqh6-F_normal.jpg",
      "id" : 25110374,
      "verified" : true
    }
  },
  "id" : 434378758787956736,
  "created_at" : "2014-02-14 17:29:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/434371077184032768\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/lEZdizGhSj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgcyMWqCIAA27XX.jpg",
      "id_str" : "434371076886241280",
      "id" : 434371076886241280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgcyMWqCIAA27XX.jpg",
      "sizes" : [ {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1004,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/lEZdizGhSj"
    } ],
    "hashtags" : [ {
      "text" : "HappyValentinesDay",
      "indices" : [ 55, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434374724144353280",
  "text" : "RT @FLOTUS: Hey Barack, I'll always be your valentine! #HappyValentinesDay -mo http:\/\/t.co\/lEZdizGhSj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/434371077184032768\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/lEZdizGhSj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgcyMWqCIAA27XX.jpg",
        "id_str" : "434371076886241280",
        "id" : 434371076886241280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgcyMWqCIAA27XX.jpg",
        "sizes" : [ {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1004,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/lEZdizGhSj"
      } ],
      "hashtags" : [ {
        "text" : "HappyValentinesDay",
        "indices" : [ 43, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434371077184032768",
    "text" : "Hey Barack, I'll always be your valentine! #HappyValentinesDay -mo http:\/\/t.co\/lEZdizGhSj",
    "id" : 434371077184032768,
    "created_at" : "2014-02-14 16:58:29 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 434374724144353280,
  "created_at" : "2014-02-14 17:12:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhatWomenWant",
      "indices" : [ 43, 57 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434367650463248384",
  "text" : "RT @VP: Happy Valentine's Day from the VP. #WhatWomenWant is access to quality health care -- it's important to #GetCovered http:\/\/t.co\/Mw6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/434366427298938880\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Mw6juQZu9i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bgct9tnCQAI9JXi.png",
        "id_str" : "434366427303133186",
        "id" : 434366427303133186,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bgct9tnCQAI9JXi.png",
        "sizes" : [ {
          "h" : 873,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1596,
          "resize" : "fit",
          "w" : 1097
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1490,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Mw6juQZu9i"
      } ],
      "hashtags" : [ {
        "text" : "WhatWomenWant",
        "indices" : [ 35, 49 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434366427298938880",
    "text" : "Happy Valentine's Day from the VP. #WhatWomenWant is access to quality health care -- it's important to #GetCovered http:\/\/t.co\/Mw6juQZu9i",
    "id" : 434366427298938880,
    "created_at" : "2014-02-14 16:40:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 434367650463248384,
  "created_at" : "2014-02-14 16:44:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Louis-Dreyfus",
      "screen_name" : "OfficialJLD",
      "indices" : [ 15, 27 ],
      "id_str" : "502281810",
      "id" : 502281810
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434359066941349889\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/8MOYUD0zhw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgcnRRWCIAAXJj-.jpg",
      "id_str" : "434359066731618304",
      "id" : 434359066731618304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgcnRRWCIAAXJj-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/8MOYUD0zhw"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/RoTlhEvkts",
      "expanded_url" : "http:\/\/instagram.com\/p\/kZoWy-uxjZ\/",
      "display_url" : "instagram.com\/p\/kZoWy-uxjZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "434359066941349889",
  "text" : "#GetCovered RT @OfficialJLD Happy Valentine's Day http:\/\/t.co\/RoTlhEvkts, http:\/\/t.co\/8MOYUD0zhw",
  "id" : 434359066941349889,
  "created_at" : "2014-02-14 16:10:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/b9Z1F0f6Gi",
      "expanded_url" : "http:\/\/on.doi.gov\/1b2p3uP",
      "display_url" : "on.doi.gov\/1b2p3uP"
    } ]
  },
  "geo" : { },
  "id_str" : "434355856277504000",
  "text" : "RT @Interior: The cutest Valentine's Day video you'll watch today. Be sure to stick around until the end! http:\/\/t.co\/b9Z1F0f6Gi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/b9Z1F0f6Gi",
        "expanded_url" : "http:\/\/on.doi.gov\/1b2p3uP",
        "display_url" : "on.doi.gov\/1b2p3uP"
      } ]
    },
    "geo" : { },
    "id_str" : "434352519868071936",
    "text" : "The cutest Valentine's Day video you'll watch today. Be sure to stick around until the end! http:\/\/t.co\/b9Z1F0f6Gi",
    "id" : 434352519868071936,
    "created_at" : "2014-02-14 15:44:45 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 434355856277504000,
  "created_at" : "2014-02-14 15:58:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434106383873478656\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/yLI6CoL0PO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgZBdLuCYAAakm6.jpg",
      "id_str" : "434106383705726976",
      "id" : 434106383705726976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgZBdLuCYAAakm6.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/yLI6CoL0PO"
    } ],
    "hashtags" : [ {
      "text" : "SnowDay",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434106383873478656",
  "text" : "Dusk from the White House colonnade. #SnowDay http:\/\/t.co\/yLI6CoL0PO",
  "id" : 434106383873478656,
  "created_at" : "2014-02-13 23:26:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingPeek",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/NliVs9Ov2F",
      "expanded_url" : "http:\/\/go.wh.gov\/uVnWw3",
      "display_url" : "go.wh.gov\/uVnWw3"
    } ]
  },
  "geo" : { },
  "id_str" : "434092170027356165",
  "text" : "\"This guy, he is the king of chips.\" \u2014President Obama while sharing some snacks with his staff: http:\/\/t.co\/NliVs9Ov2F #WestWingPeek",
  "id" : 434092170027356165,
  "created_at" : "2014-02-13 22:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ivanpah",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/qtXx2wpCCh",
      "expanded_url" : "http:\/\/go.wh.gov\/69hAh2",
      "display_url" : "go.wh.gov\/69hAh2"
    } ]
  },
  "geo" : { },
  "id_str" : "434082101801914368",
  "text" : "Just completed in California: #Ivanpah\u2014the world's largest concentrated solar power plant: http:\/\/t.co\/qtXx2wpCCh #ActOnClimate",
  "id" : 434082101801914368,
  "created_at" : "2014-02-13 21:50:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/nrgenergy\/status\/434027709572730880\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/WTgdb8YExb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgX55vLCMAAQd8Z.jpg",
      "id_str" : "434027709421727744",
      "id" : 434027709421727744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgX55vLCMAAQd8Z.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/WTgdb8YExb"
    } ],
    "hashtags" : [ {
      "text" : "Ivanpah",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434078084397293568",
  "text" : "RT @ErnestMoniz: I am honored today to help dedicate #Ivanpah, the world's largest solar thermal energy facility. http:\/\/t.co\/WTgdb8YExb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/nrgenergy\/status\/434027709572730880\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/WTgdb8YExb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgX55vLCMAAQd8Z.jpg",
        "id_str" : "434027709421727744",
        "id" : 434027709421727744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgX55vLCMAAQd8Z.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/WTgdb8YExb"
      } ],
      "hashtags" : [ {
        "text" : "Ivanpah",
        "indices" : [ 36, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434038994062827520",
    "text" : "I am honored today to help dedicate #Ivanpah, the world's largest solar thermal energy facility. http:\/\/t.co\/WTgdb8YExb",
    "id" : 434038994062827520,
    "created_at" : "2014-02-13 18:58:54 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 434078084397293568,
  "created_at" : "2014-02-13 21:34:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Tyler Ennis",
      "screen_name" : "tdot_ennis",
      "indices" : [ 22, 33 ],
      "id_str" : "77115378",
      "id" : 77115378
    }, {
      "name" : "Syracuse Basketball",
      "screen_name" : "syrbasketball",
      "indices" : [ 102, 116 ],
      "id_str" : "14778548",
      "id" : 14778548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434073842558857216",
  "text" : "RT @VP: The VP called @tdot_ennis today to congratulate him on his amazing 35ft buzzer beater to keep @syrbasketball unbeaten http:\/\/t.co\/7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tyler Ennis",
        "screen_name" : "tdot_ennis",
        "indices" : [ 14, 25 ],
        "id_str" : "77115378",
        "id" : 77115378
      }, {
        "name" : "Syracuse Basketball",
        "screen_name" : "syrbasketball",
        "indices" : [ 94, 108 ],
        "id_str" : "14778548",
        "id" : 14778548
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/434047786300874752\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/7XVzYXjDMi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgYMKXbCIAAGIV8.jpg",
        "id_str" : "434047786313457664",
        "id" : 434047786313457664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgYMKXbCIAAGIV8.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/7XVzYXjDMi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434047786300874752",
    "text" : "The VP called @tdot_ennis today to congratulate him on his amazing 35ft buzzer beater to keep @syrbasketball unbeaten http:\/\/t.co\/7XVzYXjDMi",
    "id" : 434047786300874752,
    "created_at" : "2014-02-13 19:33:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 434073842558857216,
  "created_at" : "2014-02-13 21:17:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434066126616539136\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/PEedH81U74",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgYc153CAAA4Y3G.jpg",
      "id_str" : "434066126478114816",
      "id" : 434066126478114816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgYc153CAAA4Y3G.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/PEedH81U74"
    } ],
    "hashtags" : [ {
      "text" : "ValentinesDay",
      "indices" : [ 85, 99 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "434066126616539136",
  "text" : "True love has no lifetime limits\u2026just like health coverage at http:\/\/t.co\/uvXCniOFSK #ValentinesDay #GetCovered http:\/\/t.co\/PEedH81U74",
  "id" : 434066126616539136,
  "created_at" : "2014-02-13 20:46:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Barbara Lee",
      "screen_name" : "RepBarbaraLee",
      "indices" : [ 3, 17 ],
      "id_str" : "248735463",
      "id" : 248735463
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raisethewage",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434053623015038977",
  "text" : "RT @RepBarbaraLee: Tipped workers deserve better than $2.13\/hour. Let's do the right thing and #raisethewage. RT if you agree it's #Timefor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "raisethewage",
        "indices" : [ 76, 89 ]
      }, {
        "text" : "Timefor1010",
        "indices" : [ 112, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434042931222437888",
    "text" : "Tipped workers deserve better than $2.13\/hour. Let's do the right thing and #raisethewage. RT if you agree it's #Timefor1010.",
    "id" : 434042931222437888,
    "created_at" : "2014-02-13 19:14:33 +0000",
    "user" : {
      "name" : "Rep. Barbara Lee",
      "screen_name" : "RepBarbaraLee",
      "protected" : false,
      "id_str" : "248735463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430378206353317888\/3QKYak-Z_normal.jpeg",
      "id" : 248735463,
      "verified" : true
    }
  },
  "id" : 434053623015038977,
  "created_at" : "2014-02-13 19:57:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nita Lowey",
      "screen_name" : "NitaLowey",
      "indices" : [ 3, 13 ],
      "id_str" : "221792092",
      "id" : 221792092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434050387814133760",
  "text" : "RT @NitaLowey: Tomorrow is Valentine\u2019s Day: candy hearts may be sweet, but fair wages are sweeter. Let\u2019s #RaiseTheWage for tipped workers. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 90, 103 ]
      }, {
        "text" : "WhatWomenNeed",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434047737353760768",
    "text" : "Tomorrow is Valentine\u2019s Day: candy hearts may be sweet, but fair wages are sweeter. Let\u2019s #RaiseTheWage for tipped workers. #WhatWomenNeed",
    "id" : 434047737353760768,
    "created_at" : "2014-02-13 19:33:39 +0000",
    "user" : {
      "name" : "Nita Lowey",
      "screen_name" : "NitaLowey",
      "protected" : false,
      "id_str" : "221792092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418870171315339265\/l2YZIdOP_normal.jpeg",
      "id" : 221792092,
      "verified" : true
    }
  },
  "id" : 434050387814133760,
  "created_at" : "2014-02-13 19:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Keith Ellison",
      "screen_name" : "keithellison",
      "indices" : [ 3, 16 ],
      "id_str" : "14135426",
      "id" : 14135426
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raisethewage",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434048809660735490",
  "text" : "RT @keithellison: Nobody should work full time and live in poverty. It's time to #raisethewage for all working Americans",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "raisethewage",
        "indices" : [ 63, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434042842265055232",
    "text" : "Nobody should work full time and live in poverty. It's time to #raisethewage for all working Americans",
    "id" : 434042842265055232,
    "created_at" : "2014-02-13 19:14:12 +0000",
    "user" : {
      "name" : "Rep. Keith Ellison",
      "screen_name" : "keithellison",
      "protected" : false,
      "id_str" : "14135426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794278327070687234\/RRPkSnJI_normal.jpg",
      "id" : 14135426,
      "verified" : true
    }
  },
  "id" : 434048809660735490,
  "created_at" : "2014-02-13 19:37:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D Wasserman Schultz",
      "screen_name" : "DWStweets",
      "indices" : [ 3, 13 ],
      "id_str" : "115979444",
      "id" : 115979444
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whatwomenneed",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434047088452993024",
  "text" : "RT @DWStweets: Flowers &amp; candy are nice but #whatwomenneed is not having to choose between their job and their family! http:\/\/t.co\/sJtPnc5x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whatwomenneed",
        "indices" : [ 33, 47 ]
      }, {
        "text" : "RaisetheWage",
        "indices" : [ 131, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/sJtPnc5xAo",
        "expanded_url" : "http:\/\/ow.ly\/i\/4AEoo",
        "display_url" : "ow.ly\/i\/4AEoo"
      } ]
    },
    "geo" : { },
    "id_str" : "434042654377410561",
    "text" : "Flowers &amp; candy are nice but #whatwomenneed is not having to choose between their job and their family! http:\/\/t.co\/sJtPnc5xAo #RaisetheWage",
    "id" : 434042654377410561,
    "created_at" : "2014-02-13 19:13:27 +0000",
    "user" : {
      "name" : "D Wasserman Schultz",
      "screen_name" : "DWStweets",
      "protected" : false,
      "id_str" : "115979444",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798138866951684096\/D89mZrBJ_normal.jpg",
      "id" : 115979444,
      "verified" : true
    }
  },
  "id" : 434047088452993024,
  "created_at" : "2014-02-13 19:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434042147331792896\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dIgPcNjL5O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgYHCIICUAAtFXw.jpg",
      "id_str" : "434042147210153984",
      "id" : 434042147210153984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgYHCIICUAAtFXw.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/dIgPcNjL5O"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 35, 46 ]
    }, {
      "text" : "ACAValentines",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/ib0CShzyFj",
      "expanded_url" : "http:\/\/wh.gov\/ACAValentines",
      "display_url" : "wh.gov\/ACAValentines"
    } ]
  },
  "geo" : { },
  "id_str" : "434042147331792896",
  "text" : "Want to help a friend or loved one #GetCovered by Valentine's Day? Send them #ACAValentines \u2192 http:\/\/t.co\/ib0CShzyFj http:\/\/t.co\/dIgPcNjL5O",
  "id" : 434042147331792896,
  "created_at" : "2014-02-13 19:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/8DPXinubD3",
      "expanded_url" : "http:\/\/go.usa.gov\/BPWk",
      "display_url" : "go.usa.gov\/BPWk"
    } ]
  },
  "geo" : { },
  "id_str" : "434035430645047296",
  "text" : "RT @arneduncan: RT if you agree: Every student in America deserves access to high-speed internet http:\/\/t.co\/8DPXinubD3 http:\/\/t.co\/INOIfh1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/arneduncan\/status\/434020287684702208\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/INOIfh1CuS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgXzJvECcAE2HWH.jpg",
        "id_str" : "434020287688896513",
        "id" : 434020287688896513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgXzJvECcAE2HWH.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 562
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 562
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 562
        } ],
        "display_url" : "pic.twitter.com\/INOIfh1CuS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/8DPXinubD3",
        "expanded_url" : "http:\/\/go.usa.gov\/BPWk",
        "display_url" : "go.usa.gov\/BPWk"
      } ]
    },
    "geo" : { },
    "id_str" : "434020287684702208",
    "text" : "RT if you agree: Every student in America deserves access to high-speed internet http:\/\/t.co\/8DPXinubD3 http:\/\/t.co\/INOIfh1CuS",
    "id" : 434020287684702208,
    "created_at" : "2014-02-13 17:44:35 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 434035430645047296,
  "created_at" : "2014-02-13 18:44:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ccgeYlodyu",
      "expanded_url" : "http:\/\/wh.gov\/year-of-action",
      "display_url" : "wh.gov\/year-of-action"
    } ]
  },
  "geo" : { },
  "id_str" : "434022114874888192",
  "text" : "President Obama's not waiting for Congress to expand opportunity for more Americans. Here's how he's taking action \u2192 http:\/\/t.co\/ccgeYlodyu",
  "id" : 434022114874888192,
  "created_at" : "2014-02-13 17:51:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/434001674319847424\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/cxkktwIduf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgXiOSOCUAIOlC9.jpg",
      "id_str" : "434001674147876866",
      "id" : 434001674147876866,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgXiOSOCUAIOlC9.jpg",
      "sizes" : [ {
        "h" : 381,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cxkktwIduf"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "SnowDay",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "434001674319847424",
  "text" : "Snowed in? It's a great day to #GetCovered \u2192 http:\/\/t.co\/uvXCniOFSK #SnowDay http:\/\/t.co\/cxkktwIduf",
  "id" : 434001674319847424,
  "created_at" : "2014-02-13 16:30:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433990744156561408\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/RG2tvRGaVf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgXYSD5CMAI3ouP.jpg",
      "id_str" : "433990743904890882",
      "id" : 433990743904890882,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgXYSD5CMAI3ouP.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/RG2tvRGaVf"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433990744156561408",
  "text" : "Thumbs up: Yesterday, President Obama raised the minimum wage for federal contract workers to $10.10. #RaiseTheWage, http:\/\/t.co\/RG2tvRGaVf",
  "id" : 433990744156561408,
  "created_at" : "2014-02-13 15:47:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433777567259459584\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/0u9oolxc6Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgUWZiSIIAADcgm.jpg",
      "id_str" : "433777567066497024",
      "id" : 433777567066497024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgUWZiSIIAADcgm.jpg",
      "sizes" : [ {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0u9oolxc6Z"
    } ],
    "hashtags" : [ {
      "text" : "HappyBirthday",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433777567259459584",
  "text" : "205 years ago today, President Lincoln was born. #HappyBirthday http:\/\/t.co\/0u9oolxc6Z",
  "id" : 433777567259459584,
  "created_at" : "2014-02-13 01:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433767793176367104\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/teramoAv21",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgUNgm-IgAAXXP8.jpg",
      "id_str" : "433767792979247104",
      "id" : 433767792979247104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgUNgm-IgAAXXP8.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/teramoAv21"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433767793176367104",
  "text" : "\"It\u2019s a simple moral principle\u2014if you work full time, you shouldn\u2019t live in poverty.\" \u2014President Obama #RaiseTheWage http:\/\/t.co\/teramoAv21",
  "id" : 433767793176367104,
  "created_at" : "2014-02-13 01:01:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/CK0spjcugX",
      "expanded_url" : "http:\/\/go.wh.gov\/TSzvum",
      "display_url" : "go.wh.gov\/TSzvum"
    } ]
  },
  "geo" : { },
  "id_str" : "433761613062340608",
  "text" : "Obama: \"I\u2019m pleased that Republicans and Democrats...have come together to pay for what they\u2019ve already spent.\" http:\/\/t.co\/CK0spjcugX",
  "id" : 433761613062340608,
  "created_at" : "2014-02-13 00:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/da6Ta80vym",
      "expanded_url" : "http:\/\/go.wh.gov\/vxEgmf",
      "display_url" : "go.wh.gov\/vxEgmf"
    } ]
  },
  "geo" : { },
  "id_str" : "433752425803956225",
  "text" : "\"America deserves a raise.\" \u2014Obama in an email after raising the minimum wage for federal contractors: http:\/\/t.co\/da6Ta80vym #RaiseTheWage",
  "id" : 433752425803956225,
  "created_at" : "2014-02-13 00:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Export-Import Bank",
      "screen_name" : "EximBankUS",
      "indices" : [ 22, 33 ],
      "id_str" : "222666657",
      "id" : 222666657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433743615962001408",
  "text" : "Happy birthday to the @ExImBankUS! Thanks for 80 years of supporting American jobs and exports. #MadeInAmerica",
  "id" : 433743615962001408,
  "created_at" : "2014-02-12 23:25:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 7, 16 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JugglingWithJason",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/DfaifpjaHO",
      "expanded_url" : "http:\/\/wapo.st\/NDujuZ",
      "display_url" : "wapo.st\/NDujuZ"
    } ]
  },
  "geo" : { },
  "id_str" : "433737894701047808",
  "text" : "Follow @CEAChair for the latest on President Obama's economic policies.\n\nAnd juggling tips... http:\/\/t.co\/DfaifpjaHO #JugglingWithJason",
  "id" : 433737894701047808,
  "created_at" : "2014-02-12 23:02:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433725341681459200\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/FtZqcgMgGI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTm5m2CMAAcfeS.jpg",
      "id_str" : "433725341488525312",
      "id" : 433725341488525312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTm5m2CMAAcfeS.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FtZqcgMgGI"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433725341681459200",
  "text" : "Today, President Obama raised the minimum wage to $10.10\/hour for federal contract workers. #RaiseTheWage, http:\/\/t.co\/FtZqcgMgGI",
  "id" : 433725341681459200,
  "created_at" : "2014-02-12 22:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Levitt",
      "screen_name" : "larry_levitt",
      "indices" : [ 3, 16 ],
      "id_str" : "52379394",
      "id" : 52379394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433722803486224384",
  "text" : "RT @larry_levitt: States with big increases in ACA enrollment since December:\nMississippi \u2191116%\nFlorida \u219188%\nLouisiana \u219187%\nTexas \u219175%\nGeor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433718393946923008",
    "text" : "States with big increases in ACA enrollment since December:\nMississippi \u2191116%\nFlorida \u219188%\nLouisiana \u219187%\nTexas \u219175%\nGeorgia \u219173%",
    "id" : 433718393946923008,
    "created_at" : "2014-02-12 21:44:57 +0000",
    "user" : {
      "name" : "Larry Levitt",
      "screen_name" : "larry_levitt",
      "protected" : false,
      "id_str" : "52379394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731522918795083776\/V4EULJz3_normal.jpg",
      "id" : 52379394,
      "verified" : false
    }
  },
  "id" : 433722803486224384,
  "created_at" : "2014-02-12 22:02:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/fVe8hO4SJC",
      "expanded_url" : "http:\/\/StudentAid.gov",
      "display_url" : "StudentAid.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "433717644366479360",
  "text" : "RT @FLOTUS: \"Get the word out: send everybody you know to http:\/\/t.co\/fVe8hO4SJC. Text it, tweet it, take a selfie &amp; Instagram it!\" \u2014The Fi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/fVe8hO4SJC",
        "expanded_url" : "http:\/\/StudentAid.gov",
        "display_url" : "StudentAid.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "433707126029291520",
    "text" : "\"Get the word out: send everybody you know to http:\/\/t.co\/fVe8hO4SJC. Text it, tweet it, take a selfie &amp; Instagram it!\" \u2014The First Lady",
    "id" : 433707126029291520,
    "created_at" : "2014-02-12 21:00:11 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 433717644366479360,
  "created_at" : "2014-02-12 21:41:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YI",
      "screen_name" : "YI_Care",
      "indices" : [ 3, 11 ],
      "id_str" : "2510807636",
      "id" : 2510807636
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/YI_Care\/status\/433707393872957441\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/nGeyD9Xr3E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTWk60CEAAn4jO.png",
      "id_str" : "433707393885540352",
      "id" : 433707393885540352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTWk60CEAAn4jO.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1550,
        "resize" : "fit",
        "w" : 1550
      } ],
      "display_url" : "pic.twitter.com\/nGeyD9Xr3E"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 59, 69 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433715082447831040",
  "text" : "RT @YI_Care: We believe in a healthy young America. 1 in 3 #Obamacare enrollees are under age 35! #GetCovered http:\/\/t.co\/nGeyD9Xr3E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YI_Care\/status\/433707393872957441\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/nGeyD9Xr3E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTWk60CEAAn4jO.png",
        "id_str" : "433707393885540352",
        "id" : 433707393885540352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTWk60CEAAn4jO.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1550,
          "resize" : "fit",
          "w" : 1550
        } ],
        "display_url" : "pic.twitter.com\/nGeyD9Xr3E"
      } ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 46, 56 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 85, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433707393872957441",
    "text" : "We believe in a healthy young America. 1 in 3 #Obamacare enrollees are under age 35! #GetCovered http:\/\/t.co\/nGeyD9Xr3E",
    "id" : 433707393872957441,
    "created_at" : "2014-02-12 21:01:15 +0000",
    "user" : {
      "name" : "Young Invincibles",
      "screen_name" : "YoungInvincible",
      "protected" : false,
      "id_str" : "67215899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691632503577161728\/Zj3TLgji_normal.png",
      "id" : 67215899,
      "verified" : false
    }
  },
  "id" : 433715082447831040,
  "created_at" : "2014-02-12 21:31:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/433701176450633729\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/mbRotVVlAk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTQ7BFCUAEP-pl.jpg",
      "id_str" : "433701176454828033",
      "id" : 433701176454828033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTQ7BFCUAEP-pl.jpg",
      "sizes" : [ {
        "h" : 743,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 743,
        "resize" : "fit",
        "w" : 950
      } ],
      "display_url" : "pic.twitter.com\/mbRotVVlAk"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433709418065428480",
  "text" : "RT @CEABetsey: Let's raise the minimum wage so more people can work their way out of poverty #RaiseTheWage http:\/\/t.co\/mbRotVVlAk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/433701176450633729\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/mbRotVVlAk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTQ7BFCUAEP-pl.jpg",
        "id_str" : "433701176454828033",
        "id" : 433701176454828033,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTQ7BFCUAEP-pl.jpg",
        "sizes" : [ {
          "h" : 743,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 469,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 743,
          "resize" : "fit",
          "w" : 950
        } ],
        "display_url" : "pic.twitter.com\/mbRotVVlAk"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 78, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433701176450633729",
    "text" : "Let's raise the minimum wage so more people can work their way out of poverty #RaiseTheWage http:\/\/t.co\/mbRotVVlAk",
    "id" : 433701176450633729,
    "created_at" : "2014-02-12 20:36:33 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 433709418065428480,
  "created_at" : "2014-02-12 21:09:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433705952152657920",
  "text" : "RT @Cecilia44: 47 days left to sign up for 2014 coverage. Let's help every American who needs affordable insurance #GetCovered \u2192 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 100, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/lgz3bj0AlR",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "433702848967094272",
    "text" : "47 days left to sign up for 2014 coverage. Let's help every American who needs affordable insurance #GetCovered \u2192 http:\/\/t.co\/lgz3bj0AlR",
    "id" : 433702848967094272,
    "created_at" : "2014-02-12 20:43:11 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 433705952152657920,
  "created_at" : "2014-02-12 20:55:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433700085323796480",
  "text" : "Good news: Enrollment in private health plans through the ACA increased 53% in Jan compared to the previous 3 months combined. #GetCovered",
  "id" : 433700085323796480,
  "created_at" : "2014-02-12 20:32:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC Nightly News",
      "screen_name" : "NBCNightlyNews",
      "indices" : [ 3, 18 ],
      "id_str" : "8839632",
      "id" : 8839632
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nbcnightlynews\/status\/433686536521916416\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/I4z4UwyALA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTDm2JCEAAEg1K.png",
      "id_str" : "433686536270254080",
      "id" : 433686536270254080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTDm2JCEAAEg1K.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/I4z4UwyALA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433688137626578945",
  "text" : "RT @nbcnightlynews: PHOTO: President Obama signs executive order raising minimum wage for federal contract workers http:\/\/t.co\/I4z4UwyALA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nbcnightlynews\/status\/433686536521916416\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/I4z4UwyALA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTDm2JCEAAEg1K.png",
        "id_str" : "433686536270254080",
        "id" : 433686536270254080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTDm2JCEAAEg1K.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/I4z4UwyALA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433686536521916416",
    "text" : "PHOTO: President Obama signs executive order raising minimum wage for federal contract workers http:\/\/t.co\/I4z4UwyALA",
    "id" : 433686536521916416,
    "created_at" : "2014-02-12 19:38:22 +0000",
    "user" : {
      "name" : "NBC Nightly News",
      "screen_name" : "NBCNightlyNews",
      "protected" : false,
      "id_str" : "8839632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785592557170548736\/SHaFtQWN_normal.jpg",
      "id" : 8839632,
      "verified" : true
    }
  },
  "id" : 433688137626578945,
  "created_at" : "2014-02-12 19:44:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433686657079185408",
  "text" : "\"Let's give Americans a raise right now.\" \u2014President Obama before raising the minimum wage for federal contract workers #RaiseTheWage",
  "id" : 433686657079185408,
  "created_at" : "2014-02-12 19:38:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433686007683096576\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/QYkaOlbHkH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTDIA9CMAAL-v0.jpg",
      "id_str" : "433686006596775936",
      "id" : 433686006596775936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTDIA9CMAAL-v0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QYkaOlbHkH"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433686007683096576",
  "text" : "President Obama: \"Every American deserves to know where your elected representatives stand on this.\" #RaiseTheWage, http:\/\/t.co\/QYkaOlbHkH",
  "id" : 433686007683096576,
  "created_at" : "2014-02-12 19:36:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433685783267266561",
  "text" : "Obama: \"Members of Congress have a pretty clear choice to make: Raise our workers\u2019 wages &amp; grow our economy, or let wages stagnate further.\"",
  "id" : 433685783267266561,
  "created_at" : "2014-02-12 19:35:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433685343658065920",
  "text" : "RT @WHLive: Obama: \"It\u2019s a simple moral principle\u2014if you work full time, you shouldn\u2019t live in poverty.\" #RaiseTheWage, http:\/\/t.co\/VZxZOgE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/433685284618661888\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/VZxZOgEEWC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTCd-tCEAALzrX.jpg",
        "id_str" : "433685284438282240",
        "id" : 433685284438282240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTCd-tCEAALzrX.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/VZxZOgEEWC"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 93, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433685284618661888",
    "text" : "Obama: \"It\u2019s a simple moral principle\u2014if you work full time, you shouldn\u2019t live in poverty.\" #RaiseTheWage, http:\/\/t.co\/VZxZOgEEWC",
    "id" : 433685284618661888,
    "created_at" : "2014-02-12 19:33:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 433685343658065920,
  "created_at" : "2014-02-12 19:33:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433684918863159296",
  "text" : "RT @WHLive: Obama: \"Today, I\u2019m issuing an Executive Order requiring federal contractors to pay their employees a fair wage of at least $10.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433684843755741184",
    "text" : "Obama: \"Today, I\u2019m issuing an Executive Order requiring federal contractors to pay their employees a fair wage of at least $10.10\/hour.\"",
    "id" : 433684843755741184,
    "created_at" : "2014-02-12 19:31:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 433684918863159296,
  "created_at" : "2014-02-12 19:31:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433684686934917120",
  "text" : "Obama: \"While Congress decides what it\u2019s going to do, I\u2019m going to do what I can to help raise working Americans\u2019 wages.\" #RaiseTheWage",
  "id" : 433684686934917120,
  "created_at" : "2014-02-12 19:31:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433684444311207936",
  "text" : "Obama: \"Owners of small and large businesses are recognizing that fair wages and higher profits go hand in hand.\" #RaiseTheWage",
  "id" : 433684444311207936,
  "created_at" : "2014-02-12 19:30:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433683876892774400\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ezcqZKyHEf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTBMCjCYAAfLSg.png",
      "id_str" : "433683876720828416",
      "id" : 433683876720828416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTBMCjCYAAfLSg.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ezcqZKyHEf"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433683876892774400",
  "text" : "President Obama: \"A majority of lower-wage jobs are held by women. These Americans work full-time.\" #RaiseTheWage, http:\/\/t.co\/ezcqZKyHEf",
  "id" : 433683876892774400,
  "created_at" : "2014-02-12 19:27:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433683318086041600",
  "text" : "President Obama: \"In the wealthiest nation on Earth, no one who works full-time should have to live in poverty.\" #RaiseTheWage",
  "id" : 433683318086041600,
  "created_at" : "2014-02-12 19:25:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433683139093749760\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/E60ZcZoUaN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgTAhGFCAAAXDej.jpg",
      "id_str" : "433683138934341632",
      "id" : 433683138934341632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgTAhGFCAAAXDej.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/E60ZcZoUaN"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 33, 42 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 80, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433683139093749760",
  "text" : "\"It means making sure women earn #EqualPay for equal work.\" \u2014Obama on expanding #OpportunityForAll, http:\/\/t.co\/E60ZcZoUaN",
  "id" : 433683139093749760,
  "created_at" : "2014-02-12 19:24:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 38, 49 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRA",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433682323041947648",
  "text" : "RT @WHLive: Obama: \"I\u2019ve directed the @USTreasury to create #MyRA...a new way for Americans to start saving for retirement.\" http:\/\/t.co\/u0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Treasury Department",
        "screen_name" : "USTreasury",
        "indices" : [ 26, 37 ],
        "id_str" : "120176950",
        "id" : 120176950
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyRA",
        "indices" : [ 48, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/u0XJoofN2y",
        "expanded_url" : "http:\/\/go.wh.gov\/4rcArj",
        "display_url" : "go.wh.gov\/4rcArj"
      } ]
    },
    "geo" : { },
    "id_str" : "433682234680573952",
    "text" : "Obama: \"I\u2019ve directed the @USTreasury to create #MyRA...a new way for Americans to start saving for retirement.\" http:\/\/t.co\/u0XJoofN2y",
    "id" : 433682234680573952,
    "created_at" : "2014-02-12 19:21:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 433682323041947648,
  "created_at" : "2014-02-12 19:21:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Uv7DJXoBHw",
      "expanded_url" : "http:\/\/go.wh.gov\/bcMmWY",
      "display_url" : "go.wh.gov\/bcMmWY"
    } ]
  },
  "geo" : { },
  "id_str" : "433678526223757312",
  "text" : "Starting soon: President Obama speaks and signs an Executive Order to #RaiseTheWage for federal contractors. Watch \u2192 http:\/\/t.co\/Uv7DJXoBHw",
  "id" : 433678526223757312,
  "created_at" : "2014-02-12 19:06:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Curiosity5K",
      "indices" : [ 107, 119 ]
    }, {
      "text" : "LetsMove",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433674078265044992",
  "text" : "RT @MarsCuriosity: Cue \"Chariots of Fire\"! (No slo-mo required.) I just rolled over the 5 km mark on Mars. #Curiosity5K #LetsMove",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Curiosity5K",
        "indices" : [ 88, 100 ]
      }, {
        "text" : "LetsMove",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433660544029958144",
    "text" : "Cue \"Chariots of Fire\"! (No slo-mo required.) I just rolled over the 5 km mark on Mars. #Curiosity5K #LetsMove",
    "id" : 433660544029958144,
    "created_at" : "2014-02-12 17:55:05 +0000",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2793288186\/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 433674078265044992,
  "created_at" : "2014-02-12 18:48:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433664435241365504\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Ho4Myad8ns",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgSvgY6IcAAjGDZ.jpg",
      "id_str" : "433664435111358464",
      "id" : 433664435111358464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgSvgY6IcAAjGDZ.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Ho4Myad8ns"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/Uv7DJXoBHw",
      "expanded_url" : "http:\/\/go.wh.gov\/bcMmWY",
      "display_url" : "go.wh.gov\/bcMmWY"
    } ]
  },
  "geo" : { },
  "id_str" : "433664435241365504",
  "text" : "It's time to give America a raise: http:\/\/t.co\/Uv7DJXoBHw #RaiseTheWage, http:\/\/t.co\/Ho4Myad8ns",
  "id" : 433664435241365504,
  "created_at" : "2014-02-12 18:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 19, 28 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 33, 42 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/MAwJotuKNW",
      "expanded_url" : "http:\/\/go.wh.gov\/sTjZ37",
      "display_url" : "go.wh.gov\/sTjZ37"
    } ]
  },
  "geo" : { },
  "id_str" : "433661118901665793",
  "text" : "Tune in now: Watch @PressSec and @LaborSec speak on why it's time to #RaiseTheWage \u2192 http:\/\/t.co\/MAwJotuKNW",
  "id" : 433661118901665793,
  "created_at" : "2014-02-12 17:57:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/433658045248602112\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/dMdhAmORkt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgSpscLIIAAMnBV.jpg",
      "id_str" : "433658045076611072",
      "id" : 433658045076611072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgSpscLIIAAMnBV.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/dMdhAmORkt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433658045248602112",
  "text" : "Happy 80th birthday to one of the greatest basketball players of all-time, Bill Russell. http:\/\/t.co\/dMdhAmORkt",
  "id" : 433658045248602112,
  "created_at" : "2014-02-12 17:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433653091976880128\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ijnMRu3Cde",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgSlMHhIYAA07C3.png",
      "id_str" : "433653091729432576",
      "id" : 433653091729432576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgSlMHhIYAA07C3.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ijnMRu3Cde"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433653091976880128",
  "text" : "Here's a look at the hardworking Americans that would be helped by raising the minimum wage. #RaiseTheWage, http:\/\/t.co\/ijnMRu3Cde",
  "id" : 433653091976880128,
  "created_at" : "2014-02-12 17:25:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433646141427564544\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/1rZZKKfsb3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgSe3jHCIAAZfzx.jpg",
      "id_str" : "433646141289144320",
      "id" : 433646141289144320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgSe3jHCIAAZfzx.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1rZZKKfsb3"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433646141427564544",
  "text" : "While Congress has delayed action, here's what states around the country are doing to #RaiseTheWage: http:\/\/t.co\/1rZZKKfsb3",
  "id" : 433646141427564544,
  "created_at" : "2014-02-12 16:57:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/qhFjMELejK",
      "expanded_url" : "http:\/\/go.wh.gov\/8YqN7T",
      "display_url" : "go.wh.gov\/8YqN7T"
    } ]
  },
  "geo" : { },
  "id_str" : "433639911267532800",
  "text" : "\"It made a lot of sense for us.\" \u2014Punch Pizza CEO John Sorrano on raising his employees' wages: http:\/\/t.co\/qhFjMELejK #RaiseTheWage",
  "id" : 433639911267532800,
  "created_at" : "2014-02-12 16:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433632140686024705\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/hkYhQrKgzZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgSSImWIAAAke-m.png",
      "id_str" : "433632140564365312",
      "id" : 433632140564365312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgSSImWIAAAke-m.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hkYhQrKgzZ"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433632140686024705",
  "text" : "At today's minimum wage, many full-time workers and their families still live below the poverty line. #RaiseTheWage, http:\/\/t.co\/hkYhQrKgzZ",
  "id" : 433632140686024705,
  "created_at" : "2014-02-12 16:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/CMYFxuAk57",
      "expanded_url" : "http:\/\/go.wh.gov\/Xnd9Ct",
      "display_url" : "go.wh.gov\/Xnd9Ct"
    } ]
  },
  "geo" : { },
  "id_str" : "433626592133120000",
  "text" : "FACT: Raising the federal minimum wage to $10.10\/hour would lift wages for 28 million Americans. http:\/\/t.co\/CMYFxuAk57 #RaiseTheWage",
  "id" : 433626592133120000,
  "created_at" : "2014-02-12 15:40:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/vD9ibtl4i2",
      "expanded_url" : "http:\/\/go.wh.gov\/7QWAJp",
      "display_url" : "go.wh.gov\/7QWAJp"
    } ]
  },
  "geo" : { },
  "id_str" : "433622011945168896",
  "text" : "Share the news: Today, President Obama will raise the minimum wage for federal contractors to $10.10 \u2192 http:\/\/t.co\/vD9ibtl4i2 #RaiseTheWage",
  "id" : 433622011945168896,
  "created_at" : "2014-02-12 15:21:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "5K",
      "indices" : [ 95, 98 ]
    }, {
      "text" : "Curiosity5K",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433408458680193024",
  "text" : "RT @MarsCuriosity: My total driving distance on Mars is 4.97 km. Anyone on Earth want to run a #5K when I reach that mark? #Curiosity5K #Le\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "5K",
        "indices" : [ 76, 79 ]
      }, {
        "text" : "Curiosity5K",
        "indices" : [ 104, 116 ]
      }, {
        "text" : "LetsMove",
        "indices" : [ 117, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433403098820665345",
    "text" : "My total driving distance on Mars is 4.97 km. Anyone on Earth want to run a #5K when I reach that mark? #Curiosity5K #LetsMove",
    "id" : 433403098820665345,
    "created_at" : "2014-02-12 00:52:05 +0000",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2793288186\/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 433408458680193024,
  "created_at" : "2014-02-12 01:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 107, 116 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/y43S9i69KH",
      "expanded_url" : "http:\/\/go.wh.gov\/SHXqm8",
      "display_url" : "go.wh.gov\/SHXqm8"
    } ]
  },
  "geo" : { },
  "id_str" : "433405932039860224",
  "text" : "\"Tonight\u2019s vote is a positive step...away from the...brinkmanship that\u2019s a needless drag on our economy.\" \u2014@PressSec: http:\/\/t.co\/y43S9i69KH",
  "id" : 433405932039860224,
  "created_at" : "2014-02-12 01:03:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 35, 42 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 61, 71 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FranceStateDinner",
      "indices" : [ 85, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/q8pQtWiWvX",
      "expanded_url" : "http:\/\/go.wh.gov\/oahXbz",
      "display_url" : "go.wh.gov\/oahXbz"
    } ]
  },
  "geo" : { },
  "id_str" : "433391533698867200",
  "text" : "Happening now: President Obama and @FLOTUS welcome President @FHollande to tonight's #FranceStateDinner. Watch: http:\/\/t.co\/q8pQtWiWvX",
  "id" : 433391533698867200,
  "created_at" : "2014-02-12 00:06:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FranceStateDinner",
      "indices" : [ 39, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/8Gj6paMJZQ",
      "expanded_url" : "http:\/\/go.wh.gov\/zHqMGR",
      "display_url" : "go.wh.gov\/zHqMGR"
    } ]
  },
  "geo" : { },
  "id_str" : "433380433154555905",
  "text" : "Here's what's on the menu at tonight's #FranceStateDinner from the White House Kitchen Garden \u2192 http:\/\/t.co\/8Gj6paMJZQ",
  "id" : 433380433154555905,
  "created_at" : "2014-02-11 23:22:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/433360039361789952\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/uGNdYTStLk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgOaqNSCcAE10DA.jpg",
      "id_str" : "433360039068200961",
      "id" : 433360039068200961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgOaqNSCcAE10DA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uGNdYTStLk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433360039361789952",
  "text" : "RT if you agree: Nobody who works full-time should live in poverty. It's time to raise the federal minimum wage. http:\/\/t.co\/uGNdYTStLk",
  "id" : 433360039361789952,
  "created_at" : "2014-02-11 22:00:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433356684400918528",
  "text" : "Share the good news: Tomorrow, President Obama will raise the minimum wage for federal contract workers. #RaiseTheWage",
  "id" : 433356684400918528,
  "created_at" : "2014-02-11 21:47:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 32, 41 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "USGS",
      "screen_name" : "USGS",
      "indices" : [ 46, 51 ],
      "id_str" : "14505838",
      "id" : 14505838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433329491071340545",
  "text" : "RT @Utech44: Cool new tool from @Interior and @USGS: data &amp; interactive map for more than 47,000 wind turbines in the US\u2192 http:\/\/t.co\/tZKGR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 19, 28 ],
        "id_str" : "76348185",
        "id" : 76348185
      }, {
        "name" : "USGS",
        "screen_name" : "USGS",
        "indices" : [ 33, 38 ],
        "id_str" : "14505838",
        "id" : 14505838
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/tZKGRGpHQk",
        "expanded_url" : "http:\/\/eerscmap.usgs.gov\/windfarm\/",
        "display_url" : "eerscmap.usgs.gov\/windfarm\/"
      } ]
    },
    "geo" : { },
    "id_str" : "433322192697176065",
    "text" : "Cool new tool from @Interior and @USGS: data &amp; interactive map for more than 47,000 wind turbines in the US\u2192 http:\/\/t.co\/tZKGRGpHQk",
    "id" : 433322192697176065,
    "created_at" : "2014-02-11 19:30:36 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 433329491071340545,
  "created_at" : "2014-02-11 19:59:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433321019776847872\/photo\/1",
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/BdXZz9ePsZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgN3K-wCYAAkB2Z.jpg",
      "id_str" : "433321019684577280",
      "id" : 433321019684577280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgN3K-wCYAAkB2Z.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BdXZz9ePsZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433321019776847872",
  "text" : "Obama: \"We declare our devotion once more to life, liberty &amp;...pursuit of happiness\u2014to libert\u00E9, egalit\u00E9 &amp; fraternit\u00E9\" http:\/\/t.co\/BdXZz9ePsZ",
  "id" : 433321019776847872,
  "created_at" : "2014-02-11 19:25:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/4KGFCoV2gr",
      "expanded_url" : "http:\/\/go.usa.gov\/BRPQ",
      "display_url" : "go.usa.gov\/BRPQ"
    } ]
  },
  "geo" : { },
  "id_str" : "433313682534445057",
  "text" : "RT @arneduncan: A student\u2019s health is strongly linked with his or her academic performance. #GetCovered http:\/\/t.co\/4KGFCoV2gr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 76, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/4KGFCoV2gr",
        "expanded_url" : "http:\/\/go.usa.gov\/BRPQ",
        "display_url" : "go.usa.gov\/BRPQ"
      } ]
    },
    "geo" : { },
    "id_str" : "433311113006964737",
    "text" : "A student\u2019s health is strongly linked with his or her academic performance. #GetCovered http:\/\/t.co\/4KGFCoV2gr",
    "id" : 433311113006964737,
    "created_at" : "2014-02-11 18:46:34 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 433313682534445057,
  "created_at" : "2014-02-11 18:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/BI7CMZpdHb",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "433301439549829120",
  "text" : "President Obama: \u201CThe goal is to make sure that folks are healthy and have decent health care.\u201D http:\/\/t.co\/BI7CMZpdHb #GetCovered",
  "id" : 433301439549829120,
  "created_at" : "2014-02-11 18:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433298672613605376",
  "text" : "\u201CI have two daughters. They are both gorgeous &amp; I would never choose between them.\" \u2014Obama comparing our partnerships with France and the UK",
  "id" : 433298672613605376,
  "created_at" : "2014-02-11 17:57:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433289896233811969",
  "text" : "RT @WHLive: Obama: \"We\u2019ve agreed to keep expanding...clean energy partnerships that make our countries leaders in the fight against climate\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433289785495810051",
    "text" : "Obama: \"We\u2019ve agreed to keep expanding...clean energy partnerships that make our countries leaders in the fight against climate change.\"",
    "id" : 433289785495810051,
    "created_at" : "2014-02-11 17:21:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 433289896233811969,
  "created_at" : "2014-02-11 17:22:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433289562845347840",
  "text" : "RT @WHLive: Obama on the U.S. &amp; France: \"We\u2019ve agreed to continue pursuing an ambitious &amp; comprehensive trans-Atlantic trade &amp; investment p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433289403671535616",
    "text" : "Obama on the U.S. &amp; France: \"We\u2019ve agreed to continue pursuing an ambitious &amp; comprehensive trans-Atlantic trade &amp; investment partnership.\"",
    "id" : 433289403671535616,
    "created_at" : "2014-02-11 17:20:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 433289562845347840,
  "created_at" : "2014-02-11 17:20:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433288880650207232",
  "text" : "Obama: \"Our unity...backed by strong sanctions, has succeeded in halting and rolling back key parts of the Iranian nuclear program.\"",
  "id" : 433288880650207232,
  "created_at" : "2014-02-11 17:18:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433288060118507521",
  "text" : "RT @WHLive: \"It\u2019s a great honor to welcome my friend and partner President Hollande back to the White House.\" \u2014President Obama #FranceState\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FranceStateVisit",
        "indices" : [ 115, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433287955764248577",
    "text" : "\"It\u2019s a great honor to welcome my friend and partner President Hollande back to the White House.\" \u2014President Obama #FranceStateVisit",
    "id" : 433287955764248577,
    "created_at" : "2014-02-11 17:14:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 433288060118507521,
  "created_at" : "2014-02-11 17:14:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 50, 60 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FranceStateVisit",
      "indices" : [ 127, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/o4alSzms0D",
      "expanded_url" : "http:\/\/go.wh.gov\/o9sZkH",
      "display_url" : "go.wh.gov\/o9sZkH"
    } ]
  },
  "geo" : { },
  "id_str" : "433282721071505408",
  "text" : "Don't miss President Obama &amp; French President @FHollande hold a joint press conference at 12pm ET \u2192 http:\/\/t.co\/o4alSzms0D #FranceStateVisit",
  "id" : 433282721071505408,
  "created_at" : "2014-02-11 16:53:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 89, 99 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433279357373923328\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KttTFQZ0QR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgNRR6BIAAAdnsp.jpg",
      "id_str" : "433279357231300608",
      "id" : 433279357231300608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgNRR6BIAAAdnsp.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/KttTFQZ0QR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433279357373923328",
  "text" : "\"Welcome to the United States. Bienvenue mes amis!\" \u2014President Obama to French President @FHollande. http:\/\/t.co\/KttTFQZ0QR",
  "id" : 433279357373923328,
  "created_at" : "2014-02-11 16:40:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/433273092417531905\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/bntDxEukC1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgNLlMOIEAAv91i.jpg",
      "id_str" : "433273091465416704",
      "id" : 433273091465416704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgNLlMOIEAAv91i.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bntDxEukC1"
    } ],
    "hashtags" : [ {
      "text" : "FrenchArrivalCeremony",
      "indices" : [ 26, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433273092417531905",
  "text" : "The President's toe mark. #FrenchArrivalCeremony, http:\/\/t.co\/bntDxEukC1",
  "id" : 433273092417531905,
  "created_at" : "2014-02-11 16:15:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/433266963171639296\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/JqVQ9Oju97",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgNGAeQCYAAokFJ.jpg",
      "id_str" : "433266963091972096",
      "id" : 433266963091972096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgNGAeQCYAAokFJ.jpg",
      "sizes" : [ {
        "h" : 495,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JqVQ9Oju97"
    } ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 91, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433266963171639296",
  "text" : "FACT: 95% of Latinos would be eligible for tax credits, CHIP or Medicaid if all states put #PeopleOverPolitics. http:\/\/t.co\/JqVQ9Oju97",
  "id" : 433266963171639296,
  "created_at" : "2014-02-11 15:51:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Asegurate",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433262385928101888",
  "text" : "RT @lacasablanca: Worth sharing: Here's how the Affordable Care Act is helping millions of Latino Americans #Asegurate http:\/\/t.co\/YwcCX5T8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/433260110152880130\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/YwcCX5T8XD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgM_xlGCUAAL0NN.jpg",
        "id_str" : "433260110161268736",
        "id" : 433260110161268736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgM_xlGCUAAL0NN.jpg",
        "sizes" : [ {
          "h" : 495,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 495,
          "resize" : "fit",
          "w" : 816
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/YwcCX5T8XD"
      } ],
      "hashtags" : [ {
        "text" : "Asegurate",
        "indices" : [ 90, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433260110152880130",
    "text" : "Worth sharing: Here's how the Affordable Care Act is helping millions of Latino Americans #Asegurate http:\/\/t.co\/YwcCX5T8XD",
    "id" : 433260110152880130,
    "created_at" : "2014-02-11 15:23:54 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 433262385928101888,
  "created_at" : "2014-02-11 15:32:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433247510485020672",
  "text" : "RT @WHLive: \"To our French friends, I say let\u2019s do even more together\u2014for the security our citizens deserve, for the prosperity they seek.\"\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433247224924209152",
    "text" : "\"To our French friends, I say let\u2019s do even more together\u2014for the security our citizens deserve, for the prosperity they seek.\" \u2014Obama",
    "id" : 433247224924209152,
    "created_at" : "2014-02-11 14:32:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 433247510485020672,
  "created_at" : "2014-02-11 14:33:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433247286106550273",
  "text" : "RT @WHLive: \"We stand here because of each other. We owe our freedom to each other.\" \u2014President Obama on the United States and France",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433246479583813632",
    "text" : "\"We stand here because of each other. We owe our freedom to each other.\" \u2014President Obama on the United States and France",
    "id" : 433246479583813632,
    "created_at" : "2014-02-11 14:29:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 433247286106550273,
  "created_at" : "2014-02-11 14:32:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 17, 20 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 32, 39 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 58, 68 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/idy3RHirA6",
      "expanded_url" : "http:\/\/go.wh.gov\/DAmamn",
      "display_url" : "go.wh.gov\/DAmamn"
    } ]
  },
  "geo" : { },
  "id_str" : "433244780358021120",
  "text" : "President Obama, @VP Biden, and @FLOTUS welcome President @FHollande to the White House for a State Visit. Watch \u2192 http:\/\/t.co\/idy3RHirA6",
  "id" : 433244780358021120,
  "created_at" : "2014-02-11 14:22:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/4Ip2l9hnp3",
      "expanded_url" : "http:\/\/1.usa.gov\/Nw2HrF",
      "display_url" : "1.usa.gov\/Nw2HrF"
    } ]
  },
  "geo" : { },
  "id_str" : "433035649013547008",
  "text" : "RT @Bobby44: Two paintings by Edward Hopper now in Oval Office. Curator Bill Allman provides the details: http:\/\/t.co\/4Ip2l9hnp3 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Bobby44\/status\/433034180813783040\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/7G3qHXsqoO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgJySwuCAAATiTn.jpg",
        "id_str" : "433034180822171648",
        "id" : 433034180822171648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgJySwuCAAATiTn.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 733
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1100,
          "resize" : "fit",
          "w" : 733
        } ],
        "display_url" : "pic.twitter.com\/7G3qHXsqoO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/4Ip2l9hnp3",
        "expanded_url" : "http:\/\/1.usa.gov\/Nw2HrF",
        "display_url" : "1.usa.gov\/Nw2HrF"
      } ]
    },
    "geo" : { },
    "id_str" : "433034180813783040",
    "text" : "Two paintings by Edward Hopper now in Oval Office. Curator Bill Allman provides the details: http:\/\/t.co\/4Ip2l9hnp3 http:\/\/t.co\/7G3qHXsqoO",
    "id" : 433034180813783040,
    "created_at" : "2014-02-11 00:26:08 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 433035649013547008,
  "created_at" : "2014-02-11 00:31:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/433028472689012736\/photo\/1",
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/vuXRoKEnGY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgJtGfnCQAA_Ilj.jpg",
      "id_str" : "433028472512856064",
      "id" : 433028472512856064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgJtGfnCQAA_Ilj.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/vuXRoKEnGY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433029992608694272",
  "text" : "RT @FLOTUS: Bone app\u00E9tit! http:\/\/t.co\/vuXRoKEnGY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/433028472689012736\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/vuXRoKEnGY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BgJtGfnCQAA_Ilj.jpg",
        "id_str" : "433028472512856064",
        "id" : 433028472512856064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgJtGfnCQAA_Ilj.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/vuXRoKEnGY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433028472689012736",
    "text" : "Bone app\u00E9tit! http:\/\/t.co\/vuXRoKEnGY",
    "id" : 433028472689012736,
    "created_at" : "2014-02-11 00:03:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 433029992608694272,
  "created_at" : "2014-02-11 00:09:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 69, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/sNSugQ3s67",
      "expanded_url" : "http:\/\/go.wh.gov\/QyAW2p",
      "display_url" : "go.wh.gov\/QyAW2p"
    } ]
  },
  "geo" : { },
  "id_str" : "433024011585736704",
  "text" : "President Obama's not waiting for Congress to take steps that expand #OpportunityForAll hardworking Americans \u2192 http:\/\/t.co\/sNSugQ3s67",
  "id" : 433024011585736704,
  "created_at" : "2014-02-10 23:45:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/432987187349434368\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/G3Tu7rzKBg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgJHjX3CAAAzUq0.jpg",
      "id_str" : "432987187206815744",
      "id" : 432987187206815744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgJHjX3CAAAzUq0.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/G3Tu7rzKBg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/faHL4hC4IO",
      "expanded_url" : "http:\/\/instagram.com\/p\/kPv3VHQiuH\/",
      "display_url" : "instagram.com\/p\/kPv3VHQiuH\/"
    } ]
  },
  "geo" : { },
  "id_str" : "432987187349434368",
  "text" : "Bees? Here's how our chefs are using honey from the WH beehive for tomorrow's State Dinner \u2192 http:\/\/t.co\/faHL4hC4IO, http:\/\/t.co\/G3Tu7rzKBg",
  "id" : 432987187349434368,
  "created_at" : "2014-02-10 21:19:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432975312226635776",
  "text" : "RT @SenatorReid: I hope my colleagues across the aisle will think long and hard  about their unsustainable position on UI. We will vote on \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "432953658968670208",
    "text" : "I hope my colleagues across the aisle will think long and hard  about their unsustainable position on UI. We will vote on this issue again.",
    "id" : 432953658968670208,
    "created_at" : "2014-02-10 19:06:10 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 432975312226635776,
  "created_at" : "2014-02-10 20:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 123, 130 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432967688412200960",
  "text" : "RT @USDOL: \"Vets can find jobs &amp; companies can find qualified employees\" at 2600 American Job Centers across the U.S. -@FLOTUS  http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 112, 119 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/jMLTTAf2JP",
        "expanded_url" : "http:\/\/jobcenter.usa.gov",
        "display_url" : "jobcenter.usa.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "432918556934963200",
    "text" : "\"Vets can find jobs &amp; companies can find qualified employees\" at 2600 American Job Centers across the U.S. -@FLOTUS  http:\/\/t.co\/jMLTTAf2JP",
    "id" : 432918556934963200,
    "created_at" : "2014-02-10 16:46:41 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 432967688412200960,
  "created_at" : "2014-02-10 20:01:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill de Blasio",
      "screen_name" : "BilldeBlasio",
      "indices" : [ 17, 30 ],
      "id_str" : "476193064",
      "id" : 476193064
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "SOTC",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432962204644544516",
  "text" : "#RaiseTheWage RT @BillDeBlasio: Next week, we will ask Albany to give NYC the power to raise the minimum wage in all five boroughs. #SOTC",
  "id" : 432962204644544516,
  "created_at" : "2014-02-10 19:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 30, 36 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/FpFGw2AP30",
      "expanded_url" : "http:\/\/go.usa.gov\/B5WF",
      "display_url" : "go.usa.gov\/B5WF"
    } ]
  },
  "geo" : { },
  "id_str" : "432955394563260417",
  "text" : "RT @arneduncan: Fill Out Your @FAFSA, Get Help Paying for College http:\/\/t.co\/FpFGw2AP30",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Federal Student Aid",
        "screen_name" : "FAFSA",
        "indices" : [ 14, 20 ],
        "id_str" : "188001904",
        "id" : 188001904
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/FpFGw2AP30",
        "expanded_url" : "http:\/\/go.usa.gov\/B5WF",
        "display_url" : "go.usa.gov\/B5WF"
      } ]
    },
    "geo" : { },
    "id_str" : "432934276619718656",
    "text" : "Fill Out Your @FAFSA, Get Help Paying for College http:\/\/t.co\/FpFGw2AP30",
    "id" : 432934276619718656,
    "created_at" : "2014-02-10 17:49:09 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 432955394563260417,
  "created_at" : "2014-02-10 19:13:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/432945955504410625\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/XlpyAJL6q2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BgIiDXSIQAAGr1v.jpg",
      "id_str" : "432945955365994496",
      "id" : 432945955365994496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BgIiDXSIQAAGr1v.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XlpyAJL6q2"
    } ],
    "hashtags" : [ {
      "text" : "InsideTheWH",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/pkT6EQGhfw",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "432945955504410625",
  "text" : "Bon app\u00E9tit! Go #InsideTheWH State Dinner for France with WH Chefs Comerford &amp;Yosses: http:\/\/t.co\/pkT6EQGhfw, http:\/\/t.co\/XlpyAJL6q2",
  "id" : 432945955504410625,
  "created_at" : "2014-02-10 18:35:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Michael Sam",
      "screen_name" : "MikeSamFootball",
      "indices" : [ 21, 37 ],
      "id_str" : "2491816728",
      "id" : 2491816728
    }, {
      "name" : "Mizzou Football",
      "screen_name" : "MizzouFootball",
      "indices" : [ 64, 79 ],
      "id_str" : "185802351",
      "id" : 185802351
    }, {
      "name" : "Mizzou",
      "screen_name" : "Mizzou",
      "indices" : [ 97, 104 ],
      "id_str" : "23620660",
      "id" : 23620660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432939979598462976",
  "text" : "RT @VP: Thank you to @MikeSamFootball &amp; all of the players, @mizzoufootball &amp; coaches at @mizzou \u2013 your courage is an inspiration to all of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Sam",
        "screen_name" : "MikeSamFootball",
        "indices" : [ 13, 29 ],
        "id_str" : "2491816728",
        "id" : 2491816728
      }, {
        "name" : "Mizzou Football",
        "screen_name" : "MizzouFootball",
        "indices" : [ 56, 71 ],
        "id_str" : "185802351",
        "id" : 185802351
      }, {
        "name" : "Mizzou",
        "screen_name" : "Mizzou",
        "indices" : [ 89, 96 ],
        "id_str" : "23620660",
        "id" : 23620660
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "432929854216876032",
    "text" : "Thank you to @MikeSamFootball &amp; all of the players, @mizzoufootball &amp; coaches at @mizzou \u2013 your courage is an inspiration to all of us.\u2013VP",
    "id" : 432929854216876032,
    "created_at" : "2014-02-10 17:31:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 432939979598462976,
  "created_at" : "2014-02-10 18:11:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 114, 124 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/tcrypD258p",
      "expanded_url" : "http:\/\/wapo.st\/1lTd2g6",
      "display_url" : "wapo.st\/1lTd2g6"
    } ]
  },
  "geo" : { },
  "id_str" : "432933262457982977",
  "text" : "\"We can expand...clean energy partnerships that create jobs &amp; move us toward low-carbon growth.\" \u2014Obama &amp; @FHollande: http:\/\/t.co\/tcrypD258p",
  "id" : 432933262457982977,
  "created_at" : "2014-02-10 17:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sam",
      "screen_name" : "MikeSamFootball",
      "indices" : [ 3, 19 ],
      "id_str" : "2491816728",
      "id" : 2491816728
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 21, 28 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432928832325431296",
  "text" : "RT @MikeSamFootball: @FLOTUS Thank you for your kind words, humbled by your support.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 0, 7 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "432922036042604544",
    "in_reply_to_user_id" : 1093090866,
    "text" : "@FLOTUS Thank you for your kind words, humbled by your support.",
    "id" : 432922036042604544,
    "created_at" : "2014-02-10 17:00:31 +0000",
    "in_reply_to_screen_name" : "FLOTUS",
    "in_reply_to_user_id_str" : "1093090866",
    "user" : {
      "name" : "Michael Sam",
      "screen_name" : "MichaelSam52",
      "protected" : false,
      "id_str" : "2327860633",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655094548432068608\/H25CybKx_normal.jpg",
      "id" : 2327860633,
      "verified" : true
    }
  },
  "id" : 432928832325431296,
  "created_at" : "2014-02-10 17:27:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gjgj2014",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432927509609725952",
  "text" : "RT @GinaEPA: It\u2019s never been about choosing the between the economy and the environment - we can have both #gjgj2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gjgj2014",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "432924672498225152",
    "text" : "It\u2019s never been about choosing the between the economy and the environment - we can have both #gjgj2014",
    "id" : 432924672498225152,
    "created_at" : "2014-02-10 17:10:59 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 432927509609725952,
  "created_at" : "2014-02-10 17:22:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 102, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/6TLjCs6B13",
      "expanded_url" : "http:\/\/go.wh.gov\/fNG59R",
      "display_url" : "go.wh.gov\/fNG59R"
    } ]
  },
  "geo" : { },
  "id_str" : "432911872090599424",
  "text" : "\"America does not stand still &amp; neither will I.\" \u2014Obama on making 2014 a year of action to expand #OpportunityForAll: http:\/\/t.co\/6TLjCs6B13",
  "id" : 432911872090599424,
  "created_at" : "2014-02-10 16:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 102, 112 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Myw8w5YvCU",
      "expanded_url" : "http:\/\/wapo.st\/1lTd2g6",
      "display_url" : "wapo.st\/1lTd2g6"
    } ]
  },
  "geo" : { },
  "id_str" : "432904322343763969",
  "text" : "\"For more than two centuries, our two peoples have stood together for our mutual freedom.\" \u2014Obama and @FHollande: http:\/\/t.co\/Myw8w5YvCU",
  "id" : 432904322343763969,
  "created_at" : "2014-02-10 15:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Michael Sam",
      "screen_name" : "MikeSamFootball",
      "indices" : [ 48, 64 ],
      "id_str" : "2491816728",
      "id" : 2491816728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432898569901969409",
  "text" : "RT @FLOTUS: You're an inspiration to all of us, @MikeSamFootball. We couldn't be prouder of your courage both on and off the field. -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Sam",
        "screen_name" : "MikeSamFootball",
        "indices" : [ 36, 52 ],
        "id_str" : "2491816728",
        "id" : 2491816728
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "432896998279495680",
    "text" : "You're an inspiration to all of us, @MikeSamFootball. We couldn't be prouder of your courage both on and off the field. -mo",
    "id" : 432896998279495680,
    "created_at" : "2014-02-10 15:21:01 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 432898569901969409,
  "created_at" : "2014-02-10 15:27:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 89, 99 ],
      "id_str" : "18814998",
      "id" : 18814998
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 118, 133 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432884932508397568",
  "text" : "RT @NSCPress: Read an op-ed on the US-France Alliance by President Obama &amp; President @fhollande in this morning's @washingtonpost: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fran\u00E7ois Hollande",
        "screen_name" : "fhollande",
        "indices" : [ 75, 85 ],
        "id_str" : "18814998",
        "id" : 18814998
      }, {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 104, 119 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/qWR9Jk5Tn7",
        "expanded_url" : "http:\/\/wapo.st\/Nrw9Pg",
        "display_url" : "wapo.st\/Nrw9Pg"
      } ]
    },
    "geo" : { },
    "id_str" : "432836215482507264",
    "text" : "Read an op-ed on the US-France Alliance by President Obama &amp; President @fhollande in this morning's @washingtonpost: http:\/\/t.co\/qWR9Jk5Tn7",
    "id" : 432836215482507264,
    "created_at" : "2014-02-10 11:19:30 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 432884932508397568,
  "created_at" : "2014-02-10 14:33:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/SJfOPhhPoE",
      "expanded_url" : "http:\/\/go.wh.gov\/NRMzXP",
      "display_url" : "go.wh.gov\/NRMzXP"
    } ]
  },
  "geo" : { },
  "id_str" : "432650897881980928",
  "text" : "Go behind the scenes with President Obama &amp; watch what happened this week at the White House \u2192 http:\/\/t.co\/SJfOPhhPoE #POTUSRoadTrip",
  "id" : 432650897881980928,
  "created_at" : "2014-02-09 23:03:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 103, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/U3ucg8GjN3",
      "expanded_url" : "http:\/\/go.wh.gov\/kD7CX1",
      "display_url" : "go.wh.gov\/kD7CX1"
    } ]
  },
  "geo" : { },
  "id_str" : "432636301599182848",
  "text" : "President Obama said 2014 will be a year of action. Here's what happened next: http:\/\/t.co\/U3ucg8GjN3  #OpportunityForAll",
  "id" : 432636301599182848,
  "created_at" : "2014-02-09 22:05:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRA",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/H2xI8UaIrP",
      "expanded_url" : "http:\/\/go.wh.gov\/LZaLVk",
      "display_url" : "go.wh.gov\/LZaLVk"
    } ]
  },
  "geo" : { },
  "id_str" : "432604844398886912",
  "text" : "Obama: \"I directed the Treasury to create #MyRA\u2014a...way for working Americans...to start your own retirement savings\" http:\/\/t.co\/H2xI8UaIrP",
  "id" : 432604844398886912,
  "created_at" : "2014-02-09 20:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/H2xI8UaIrP",
      "expanded_url" : "http:\/\/go.wh.gov\/LZaLVk",
      "display_url" : "go.wh.gov\/LZaLVk"
    } ]
  },
  "geo" : { },
  "id_str" : "432589746292809728",
  "text" : "Obama: \"I ordered an across-the-board reform of our training programs to train folks with the skills employers need.\" http:\/\/t.co\/H2xI8UaIrP",
  "id" : 432589746292809728,
  "created_at" : "2014-02-09 19:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/H2xI8UaIrP",
      "expanded_url" : "http:\/\/go.wh.gov\/LZaLVk",
      "display_url" : "go.wh.gov\/LZaLVk"
    } ]
  },
  "geo" : { },
  "id_str" : "432559544367992832",
  "text" : "Obama: \"Whenever I can take steps without legislation to expand opportunity for more American families, I will.\" http:\/\/t.co\/H2xI8UaIrP",
  "id" : 432559544367992832,
  "created_at" : "2014-02-09 17:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/qPa4q8vhyb",
      "expanded_url" : "http:\/\/go.wh.gov\/2Qvd1X",
      "display_url" : "go.wh.gov\/2Qvd1X"
    } ]
  },
  "geo" : { },
  "id_str" : "432514248535588864",
  "text" : "\"Whenever I can take steps...to expand opportunity for more American families, that's what I'm going to do.\" \u2014Obama: http:\/\/t.co\/qPa4q8vhyb",
  "id" : 432514248535588864,
  "created_at" : "2014-02-09 14:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoTeamUSA",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/H2xI8UaIrP",
      "expanded_url" : "http:\/\/go.wh.gov\/LZaLVk",
      "display_url" : "go.wh.gov\/LZaLVk"
    } ]
  },
  "geo" : { },
  "id_str" : "432287750146883584",
  "text" : "\"Have a great weekend, and to our Olympians in Sochi, #GoTeamUSA!\" \u2014President Obama in his Weekly Address: http:\/\/t.co\/H2xI8UaIrP",
  "id" : 432287750146883584,
  "created_at" : "2014-02-08 23:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/H2xI8UaIrP",
      "expanded_url" : "http:\/\/go.wh.gov\/LZaLVk",
      "display_url" : "go.wh.gov\/LZaLVk"
    } ]
  },
  "geo" : { },
  "id_str" : "432227349199728641",
  "text" : "Obama: \"I brought together business leaders who\u2019ve committed to helping more unemployed Americans find work.\" http:\/\/t.co\/H2xI8UaIrP",
  "id" : 432227349199728641,
  "created_at" : "2014-02-08 19:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/4CwzWH7r2Y",
      "expanded_url" : "http:\/\/go.wh.gov\/kD7CX1",
      "display_url" : "go.wh.gov\/kD7CX1"
    } ]
  },
  "geo" : { },
  "id_str" : "432199325851320321",
  "text" : "President Obama said 2014 will be a year of action. Watch how he got started: http:\/\/t.co\/4CwzWH7r2Y #OpportunityForAll",
  "id" : 432199325851320321,
  "created_at" : "2014-02-08 17:08:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/H2xI8UaIrP",
      "expanded_url" : "http:\/\/go.wh.gov\/LZaLVk",
      "display_url" : "go.wh.gov\/LZaLVk"
    } ]
  },
  "geo" : { },
  "id_str" : "432179795263111171",
  "text" : "President Obama: \"We\u2019ve got to build an economy that works for everyone\u2014not just a fortunate few.\" http:\/\/t.co\/H2xI8UaIrP #OpportunityForAll",
  "id" : 432179795263111171,
  "created_at" : "2014-02-08 15:51:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpeningCeremony",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431977155376201728",
  "text" : "RT @FLOTUS: To our troops &amp; their family members competing in Sochi: Thank you for your service. We're proud of you! #OpeningCeremony #Join\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpeningCeremony",
        "indices" : [ 109, 125 ]
      }, {
        "text" : "JoiningForces",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431976529502142464",
    "text" : "To our troops &amp; their family members competing in Sochi: Thank you for your service. We're proud of you! #OpeningCeremony #JoiningForces \u2013mo",
    "id" : 431976529502142464,
    "created_at" : "2014-02-08 02:23:25 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 431977155376201728,
  "created_at" : "2014-02-08 02:25:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 19, 29 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpeningCeremony",
      "indices" : [ 75, 91 ]
    }, {
      "text" : "LetsMove",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431970038137253888",
  "text" : "RT @FLOTUS: Thanks @USOlympic team for inspiring me and our nation's kids. #OpeningCeremony #LetsMove -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Team USA ",
        "screen_name" : "USOlympic",
        "indices" : [ 7, 17 ],
        "id_str" : "3061782654",
        "id" : 3061782654
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpeningCeremony",
        "indices" : [ 63, 79 ]
      }, {
        "text" : "LetsMove",
        "indices" : [ 80, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431964549424906240",
    "text" : "Thanks @USOlympic team for inspiring me and our nation's kids. #OpeningCeremony #LetsMove -mo",
    "id" : 431964549424906240,
    "created_at" : "2014-02-08 01:35:48 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 431970038137253888,
  "created_at" : "2014-02-08 01:57:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "USA",
      "indices" : [ 49, 53 ]
    }, {
      "text" : "USA",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "USA",
      "indices" : [ 59, 63 ]
    }, {
      "text" : "OpeningCeremony",
      "indices" : [ 64, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431955214430896128",
  "text" : "RT @FLOTUS: Who's cheering for #TeamUSA with me? #USA #USA #USA #OpeningCeremony \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 19, 27 ]
      }, {
        "text" : "USA",
        "indices" : [ 37, 41 ]
      }, {
        "text" : "USA",
        "indices" : [ 42, 46 ]
      }, {
        "text" : "USA",
        "indices" : [ 47, 51 ]
      }, {
        "text" : "OpeningCeremony",
        "indices" : [ 52, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431954401885192192",
    "text" : "Who's cheering for #TeamUSA with me? #USA #USA #USA #OpeningCeremony \u2013mo",
    "id" : 431954401885192192,
    "created_at" : "2014-02-08 00:55:29 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 431955214430896128,
  "created_at" : "2014-02-08 00:58:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 42, 52 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpeningCeremony",
      "indices" : [ 84, 100 ]
    }, {
      "text" : "GoTeamUSA",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/HwXRPtwR4h",
      "expanded_url" : "https:\/\/vine.co\/v\/Ma3g2HEwz9x",
      "display_url" : "vine.co\/v\/Ma3g2HEwz9x"
    } ]
  },
  "geo" : { },
  "id_str" : "431946088392982528",
  "text" : "President Obama's excited to cheer on the @USOlympic Team \u2192 https:\/\/t.co\/HwXRPtwR4h #OpeningCeremony #GoTeamUSA",
  "id" : 431946088392982528,
  "created_at" : "2014-02-08 00:22:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sochi2014",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "OpeningCeremonies",
      "indices" : [ 46, 64 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431937095117328385",
  "text" : "RT @JohnKerry: Can\u2019t wait to catch #Sochi2014 #OpeningCeremonies tonight back in Boston. #TeamUSA, we\u2019re all rooting for you here at home!\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sochi2014",
        "indices" : [ 20, 30 ]
      }, {
        "text" : "OpeningCeremonies",
        "indices" : [ 31, 49 ]
      }, {
        "text" : "TeamUSA",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431931975146827777",
    "text" : "Can\u2019t wait to catch #Sochi2014 #OpeningCeremonies tonight back in Boston. #TeamUSA, we\u2019re all rooting for you here at home!\u201D",
    "id" : 431931975146827777,
    "created_at" : "2014-02-07 23:26:22 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 431937095117328385,
  "created_at" : "2014-02-07 23:46:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/431898680895877120\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/02eTkpp4Nv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf5pj95CMAAp0iz.jpg",
      "id_str" : "431898680904265728",
      "id" : 431898680904265728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf5pj95CMAAp0iz.jpg",
      "sizes" : [ {
        "h" : 287,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 981,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/02eTkpp4Nv"
    } ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 15, 23 ]
    }, {
      "text" : "OpeningCeremony",
      "indices" : [ 39, 55 ]
    }, {
      "text" : "GoTeamUSA",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431910423223226368",
  "text" : "RT @StateDept: #TeamUSA arrives at the #OpeningCeremony of the 2014 Winter Olympics in Sochi. #GoTeamUSA http:\/\/t.co\/02eTkpp4Nv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/431898680895877120\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/02eTkpp4Nv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf5pj95CMAAp0iz.jpg",
        "id_str" : "431898680904265728",
        "id" : 431898680904265728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf5pj95CMAAp0iz.jpg",
        "sizes" : [ {
          "h" : 287,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 981,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/02eTkpp4Nv"
      } ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "OpeningCeremony",
        "indices" : [ 24, 40 ]
      }, {
        "text" : "GoTeamUSA",
        "indices" : [ 79, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431898680895877120",
    "text" : "#TeamUSA arrives at the #OpeningCeremony of the 2014 Winter Olympics in Sochi. #GoTeamUSA http:\/\/t.co\/02eTkpp4Nv",
    "id" : 431898680895877120,
    "created_at" : "2014-02-07 21:14:04 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 431910423223226368,
  "created_at" : "2014-02-07 22:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/zgyxmotxV7",
      "expanded_url" : "http:\/\/bit.ly\/1f2kL2r",
      "display_url" : "bit.ly\/1f2kL2r"
    } ]
  },
  "geo" : { },
  "id_str" : "431905220591775744",
  "text" : "Here's how cities like Tampa &amp; Houston are building stronger communities through better health coverage: http:\/\/t.co\/zgyxmotxV7 #GetCovered",
  "id" : 431905220591775744,
  "created_at" : "2014-02-07 21:40:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/431895909618573313\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/4becMDQgjV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf5nCphCAAEtaWH.jpg",
      "id_str" : "431895909475942401",
      "id" : 431895909475942401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf5nCphCAAEtaWH.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4becMDQgjV"
    } ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/J7RoOOAVaT",
      "expanded_url" : "http:\/\/instagram.com\/p\/kH3p0MtNK2\/",
      "display_url" : "instagram.com\/p\/kH3p0MtNK2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "431895909618573313",
  "text" : "POTUS boards Air Force One on his way to sign the #FarmBill in Michigan \u2708 \u2708 \u2708 http:\/\/t.co\/J7RoOOAVaT, http:\/\/t.co\/4becMDQgjV",
  "id" : 431895909618573313,
  "created_at" : "2014-02-07 21:03:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    }, {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 81, 91 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WearRedDay",
      "indices" : [ 47, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431893689099911168",
  "text" : "RT @PAniskoff44: Women of the WH ready for Ntl #WearRedDay to end heart disease! @Cecilia44 @CEABetsey http:\/\/t.co\/WT6Uj2kW1l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cecilia Mu\u00F1oz",
        "screen_name" : "Cecilia44",
        "indices" : [ 64, 74 ],
        "id_str" : "1613223313",
        "id" : 1613223313
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PAniskoff44\/status\/431887588295602176\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/WT6Uj2kW1l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf5feSwCcAEUbd_.jpg",
        "id_str" : "431887588308185089",
        "id" : 431887588308185089,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf5feSwCcAEUbd_.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1632,
          "resize" : "fit",
          "w" : 1224
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/WT6Uj2kW1l"
      } ],
      "hashtags" : [ {
        "text" : "WearRedDay",
        "indices" : [ 30, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431887588295602176",
    "text" : "Women of the WH ready for Ntl #WearRedDay to end heart disease! @Cecilia44 @CEABetsey http:\/\/t.co\/WT6Uj2kW1l",
    "id" : 431887588295602176,
    "created_at" : "2014-02-07 20:30:00 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 431893689099911168,
  "created_at" : "2014-02-07 20:54:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 50, 61 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WearRedDay",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431891620133617664",
  "text" : "RT @vj44: Celebrating national #WearRedDay at the @WhiteHouse. Today we unite to end heart disease\u2014RT if you're wearing red! http:\/\/t.co\/az\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 40, 51 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/431829103004483584\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/azxIsbFutK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf4qSADCAAA_lgR.jpg",
        "id_str" : "431829103012872192",
        "id" : 431829103012872192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf4qSADCAAA_lgR.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/azxIsbFutK"
      } ],
      "hashtags" : [ {
        "text" : "WearRedDay",
        "indices" : [ 21, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431829103004483584",
    "text" : "Celebrating national #WearRedDay at the @WhiteHouse. Today we unite to end heart disease\u2014RT if you're wearing red! http:\/\/t.co\/azxIsbFutK",
    "id" : 431829103004483584,
    "created_at" : "2014-02-07 16:37:36 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 431891620133617664,
  "created_at" : "2014-02-07 20:46:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431874922152230912",
  "text" : "Obama: \"In the weeks ahead, I\u2019ll keep doing everything I can to strengthen the middle class, and build more ladders of opportunity.\"",
  "id" : 431874922152230912,
  "created_at" : "2014-02-07 19:39:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431874817110061056",
  "text" : "RT @WHLive: Obama on the #FarmBill: \"It doesn\u2019t include everything I\u2019d like...but it\u2019s a good sign that Dems &amp; Republicans...were able to c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FarmBill",
        "indices" : [ 13, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431874729604300800",
    "text" : "Obama on the #FarmBill: \"It doesn\u2019t include everything I\u2019d like...but it\u2019s a good sign that Dems &amp; Republicans...were able to come together\"",
    "id" : 431874729604300800,
    "created_at" : "2014-02-07 19:38:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 431874817110061056,
  "created_at" : "2014-02-07 19:39:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/4h0iH81A5t",
      "expanded_url" : "http:\/\/go.wh.gov\/kDxvMx",
      "display_url" : "go.wh.gov\/kDxvMx"
    } ]
  },
  "geo" : { },
  "id_str" : "431873945093283841",
  "text" : "Obama: The #FarmBill \"helps rural communities grow, gives farmers some certainty &amp; puts in place important reforms.\" http:\/\/t.co\/4h0iH81A5t",
  "id" : 431873945093283841,
  "created_at" : "2014-02-07 19:35:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431873553504686080",
  "text" : "RT @WHLive: Obama on the #FarmBill: \"It supports local food by investing in things like farmers markets and organic agriculture.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FarmBill",
        "indices" : [ 13, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431873298402918400",
    "text" : "Obama on the #FarmBill: \"It supports local food by investing in things like farmers markets and organic agriculture.\"",
    "id" : 431873298402918400,
    "created_at" : "2014-02-07 19:33:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 431873553504686080,
  "created_at" : "2014-02-07 19:34:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431873322381758464",
  "text" : "RT @WHLive: Obama: \"This #FarmBill includes things like crop insurance, so...when a disaster...hits our farmers, they don\u2019t lose everything\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FarmBill",
        "indices" : [ 13, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431873094576508928",
    "text" : "Obama: \"This #FarmBill includes things like crop insurance, so...when a disaster...hits our farmers, they don\u2019t lose everything.\"",
    "id" : 431873094576508928,
    "created_at" : "2014-02-07 19:32:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 431873322381758464,
  "created_at" : "2014-02-07 19:33:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 110, 124 ]
    }, {
      "text" : "FarmBill",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431872396912783360",
  "text" : "Obama: \"The products we grow here and sell to the rest of the world support about one million American jobs.\" #MadeInAmerica #FarmBill",
  "id" : 431872396912783360,
  "created_at" : "2014-02-07 19:29:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431872131929231360",
  "text" : "Obama on the #FarmBill: \"It\u2019s like a Swiss Army Knife\u2014it multitasks. It creates more good jobs &amp; gives more Americans a shot at opportunity\"",
  "id" : 431872131929231360,
  "created_at" : "2014-02-07 19:28:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431872098626437120",
  "text" : "RT @WHLive: Obama: \"The #FarmBill is not just about helping farmers. Sec. Vilsack calls it a jobs...innovation...infrastructure...&amp; conserv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FarmBill",
        "indices" : [ 12, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431871925565288448",
    "text" : "Obama: \"The #FarmBill is not just about helping farmers. Sec. Vilsack calls it a jobs...innovation...infrastructure...&amp; conservation bill.\"",
    "id" : 431871925565288448,
    "created_at" : "2014-02-07 19:27:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 431872098626437120,
  "created_at" : "2014-02-07 19:28:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431870551611936768",
  "text" : "President Obama: \"We\u2019ve got to build an economy that works for everyone, not just a fortunate few.\" #OpportunityForAll",
  "id" : 431870551611936768,
  "created_at" : "2014-02-07 19:22:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/431870239802806272\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/A9PgmPk0hS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf5PseGCMAA2AEU.jpg",
      "id_str" : "431870239685357568",
      "id" : 431870239685357568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf5PseGCMAA2AEU.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/A9PgmPk0hS"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431870239802806272",
  "text" : "Obama: \"This morning, we learned that our businesses...created more than 140,000 jobs last month.\" #ActOnJobs http:\/\/t.co\/A9PgmPk0hS",
  "id" : 431870239802806272,
  "created_at" : "2014-02-07 19:21:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSU",
      "screen_name" : "michiganstateu",
      "indices" : [ 38, 53 ],
      "id_str" : "41346792",
      "id" : 41346792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "SpartyOn",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431869889683656704",
  "text" : "Obama before signing the #FarmBill at @MichiganStateU: \u201CCoach Izzo, he always paces so that you peak right at the tournament.\u201D #SpartyOn",
  "id" : 431869889683656704,
  "created_at" : "2014-02-07 19:19:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSU",
      "screen_name" : "michiganstateu",
      "indices" : [ 37, 52 ],
      "id_str" : "41346792",
      "id" : 41346792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/449T8rmCdn",
      "expanded_url" : "http:\/\/go.wh.gov\/5aG8E3",
      "display_url" : "go.wh.gov\/5aG8E3"
    } ]
  },
  "geo" : { },
  "id_str" : "431869074218708992",
  "text" : "Right now: President Obama speaks at @MichiganStateU before signing the #FarmBill. Watch \u2192 http:\/\/t.co\/449T8rmCdn",
  "id" : 431869074218708992,
  "created_at" : "2014-02-07 19:16:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/wcwm8tzE1e",
      "expanded_url" : "http:\/\/go.wh.gov\/kDxvMx",
      "display_url" : "go.wh.gov\/kDxvMx"
    } ]
  },
  "geo" : { },
  "id_str" : "431854025344950272",
  "text" : "Before President Obama signs the #FarmBill, check out how it strengthens our economy &amp; helps businesses and families: http:\/\/t.co\/wcwm8tzE1e",
  "id" : 431854025344950272,
  "created_at" : "2014-02-07 18:16:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoTeamUSA",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/e9hoVrcEs0",
      "expanded_url" : "http:\/\/go.wh.gov\/A6Fjrb",
      "display_url" : "go.wh.gov\/A6Fjrb"
    } ]
  },
  "geo" : { },
  "id_str" : "431841140875485186",
  "text" : "Obama: \"On behalf of all your fans around the country\u2014including everybody in the Obama family\u2014good luck &amp; #GoTeamUSA\" http:\/\/t.co\/e9hoVrcEs0",
  "id" : 431841140875485186,
  "created_at" : "2014-02-07 17:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CEAChair\/status\/431812857865306112\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/YTAdAFczPy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf4bgaMCAAA3L-o.jpg",
      "id_str" : "431812857873694720",
      "id" : 431812857873694720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf4bgaMCAAA3L-o.jpg",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 910
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 910
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YTAdAFczPy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/49U2a41xhZ",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/02\/07\/employment-situation-january",
      "display_url" : "whitehouse.gov\/blog\/2014\/02\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431834620414685184",
  "text" : "RT @CEAChair: Unemployment rates continue to vary widely by educational attainment http:\/\/t.co\/49U2a41xhZ http:\/\/t.co\/YTAdAFczPy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CEAChair\/status\/431812857865306112\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/YTAdAFczPy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf4bgaMCAAA3L-o.jpg",
        "id_str" : "431812857873694720",
        "id" : 431812857873694720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf4bgaMCAAA3L-o.jpg",
        "sizes" : [ {
          "h" : 660,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/YTAdAFczPy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/49U2a41xhZ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/02\/07\/employment-situation-january",
        "display_url" : "whitehouse.gov\/blog\/2014\/02\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431812857865306112",
    "text" : "Unemployment rates continue to vary widely by educational attainment http:\/\/t.co\/49U2a41xhZ http:\/\/t.co\/YTAdAFczPy",
    "id" : 431812857865306112,
    "created_at" : "2014-02-07 15:33:02 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 431834620414685184,
  "created_at" : "2014-02-07 16:59:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431827484183920640",
  "text" : "RT @CEAChair: While still too high the unemployment rate has fallen 1.3% in the last year; fell 0.1% in jan, even as LFPR rose 0.2% http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/431812667846557696\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/G9upfpDXFT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf4bVWTCAAAPFN8.jpg",
        "id_str" : "431812667850752000",
        "id" : 431812667850752000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf4bVWTCAAAPFN8.jpg",
        "sizes" : [ {
          "h" : 660,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/G9upfpDXFT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431812667846557696",
    "text" : "While still too high the unemployment rate has fallen 1.3% in the last year; fell 0.1% in jan, even as LFPR rose 0.2% http:\/\/t.co\/G9upfpDXFT",
    "id" : 431812667846557696,
    "created_at" : "2014-02-07 15:32:17 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 431827484183920640,
  "created_at" : "2014-02-07 16:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpeningCeremony",
      "indices" : [ 66, 82 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431822916507156480",
  "text" : "RT @FLOTUS: Let the games begin! So proud of all of our athletes. #OpeningCeremony #TeamUSA \n\u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpeningCeremony",
        "indices" : [ 54, 70 ]
      }, {
        "text" : "TeamUSA",
        "indices" : [ 71, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431817665129091072",
    "text" : "Let the games begin! So proud of all of our athletes. #OpeningCeremony #TeamUSA \n\u2013mo",
    "id" : 431817665129091072,
    "created_at" : "2014-02-07 15:52:08 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 431822916507156480,
  "created_at" : "2014-02-07 16:13:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/5scqgxj5h5",
      "expanded_url" : "http:\/\/go.wh.gov\/vMCuHh",
      "display_url" : "go.wh.gov\/vMCuHh"
    } ]
  },
  "geo" : { },
  "id_str" : "431817138026721280",
  "text" : "Good news: Our construction sector added 48,000 jobs last month\u2014it's strongest month of job growth since 2007. http:\/\/t.co\/5scqgxj5h5",
  "id" : 431817138026721280,
  "created_at" : "2014-02-07 15:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/431812411624919040\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/wMynIxrHiu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf4bGbICYAAk5Xc.jpg",
      "id_str" : "431812411448778752",
      "id" : 431812411448778752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf4bGbICYAAk5Xc.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/wMynIxrHiu"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/E6pIYSb04i",
      "expanded_url" : "http:\/\/go.wh.gov\/EdA7Zp",
      "display_url" : "go.wh.gov\/EdA7Zp"
    } ]
  },
  "geo" : { },
  "id_str" : "431812411624919040",
  "text" : "RT the news: Our businesses have added 8.5 million jobs over 47 straight months. http:\/\/t.co\/E6pIYSb04i #ActOnJobs http:\/\/t.co\/wMynIxrHiu",
  "id" : 431812411624919040,
  "created_at" : "2014-02-07 15:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Leno",
      "screen_name" : "jayleno",
      "indices" : [ 29, 37 ],
      "id_str" : "35859588",
      "id" : 35859588
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/431623440236568576\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/afOD9T4H91",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf1vO2AIQAAQd7P.jpg",
      "id_str" : "431623440102342656",
      "id" : 431623440102342656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf1vO2AIQAAQd7P.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/afOD9T4H91"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431623440236568576",
  "text" : "Thanks for all the memories, @JayLeno! http:\/\/t.co\/afOD9T4H91",
  "id" : 431623440236568576,
  "created_at" : "2014-02-07 03:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/431583966823325696\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/v4bmr7UgSs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf1LVMICIAApDWu.jpg",
      "id_str" : "431583966701690880",
      "id" : 431583966701690880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf1LVMICIAApDWu.jpg",
      "sizes" : [ {
        "h" : 694,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/v4bmr7UgSs"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 32, 36 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 37, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431587534305787904",
  "text" : "RT @FLOTUS: Brother and sister. #TBT #ThrowbackThursday http:\/\/t.co\/v4bmr7UgSs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/431583966823325696\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/v4bmr7UgSs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf1LVMICIAApDWu.jpg",
        "id_str" : "431583966701690880",
        "id" : 431583966701690880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf1LVMICIAApDWu.jpg",
        "sizes" : [ {
          "h" : 694,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 694,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/v4bmr7UgSs"
      } ],
      "hashtags" : [ {
        "text" : "TBT",
        "indices" : [ 20, 24 ]
      }, {
        "text" : "ThrowbackThursday",
        "indices" : [ 25, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431583966823325696",
    "text" : "Brother and sister. #TBT #ThrowbackThursday http:\/\/t.co\/v4bmr7UgSs",
    "id" : 431583966823325696,
    "created_at" : "2014-02-07 00:23:30 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 431587534305787904,
  "created_at" : "2014-02-07 00:37:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "\u042F\u043A\u043E\u0432\u0446\u0435\u0432a \u042E\u043B\u0438\u044F",
      "screen_name" : "RMNPOfficial",
      "indices" : [ 100, 113 ],
      "id_str" : "2814678878",
      "id" : 2814678878
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/431579388388593664\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/3Q3Szg58Kl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf1HKsFIEAAi3bQ.jpg",
      "id_str" : "431579388254359552",
      "id" : 431579388254359552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf1HKsFIEAAi3bQ.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3Q3Szg58Kl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431582264397668352",
  "text" : "RT @Interior: The car wash is a little different this time of year in Rocky Mountain National Park. @RMNPOfficial http:\/\/t.co\/3Q3Szg58Kl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u042F\u043A\u043E\u0432\u0446\u0435\u0432a \u042E\u043B\u0438\u044F",
        "screen_name" : "RMNPOfficial",
        "indices" : [ 86, 99 ],
        "id_str" : "2814678878",
        "id" : 2814678878
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/431579388388593664\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/3Q3Szg58Kl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf1HKsFIEAAi3bQ.jpg",
        "id_str" : "431579388254359552",
        "id" : 431579388254359552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf1HKsFIEAAi3bQ.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3Q3Szg58Kl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431579388388593664",
    "text" : "The car wash is a little different this time of year in Rocky Mountain National Park. @RMNPOfficial http:\/\/t.co\/3Q3Szg58Kl",
    "id" : 431579388388593664,
    "created_at" : "2014-02-07 00:05:19 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 431582264397668352,
  "created_at" : "2014-02-07 00:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CC Sabathia",
      "screen_name" : "CC_Sabathia",
      "indices" : [ 3, 15 ],
      "id_str" : "19238073",
      "id" : 19238073
    }, {
      "name" : "GamePlan4Me",
      "screen_name" : "gameplan_4me",
      "indices" : [ 80, 93 ],
      "id_str" : "2238143720",
      "id" : 2238143720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GP4Me",
      "indices" : [ 117, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/aJVyCrNvAU",
      "expanded_url" : "http:\/\/gameplan4me.com",
      "display_url" : "gameplan4me.com"
    } ]
  },
  "geo" : { },
  "id_str" : "431569079045214208",
  "text" : "RT @CC_Sabathia: No matter where you are in life, you need to have a game plan. @gameplan_4me http:\/\/t.co\/aJVyCrNvAU #GP4Me",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GamePlan4Me",
        "screen_name" : "gameplan_4me",
        "indices" : [ 63, 76 ],
        "id_str" : "2238143720",
        "id" : 2238143720
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GP4Me",
        "indices" : [ 100, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/aJVyCrNvAU",
        "expanded_url" : "http:\/\/gameplan4me.com",
        "display_url" : "gameplan4me.com"
      } ]
    },
    "geo" : { },
    "id_str" : "431561282328993792",
    "text" : "No matter where you are in life, you need to have a game plan. @gameplan_4me http:\/\/t.co\/aJVyCrNvAU #GP4Me",
    "id" : 431561282328993792,
    "created_at" : "2014-02-06 22:53:22 +0000",
    "user" : {
      "name" : "CC Sabathia",
      "screen_name" : "CC_Sabathia",
      "protected" : false,
      "id_str" : "19238073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582899872099090432\/fxhEos-P_normal.png",
      "id" : 19238073,
      "verified" : true
    }
  },
  "id" : 431569079045214208,
  "created_at" : "2014-02-06 23:24:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 77, 86 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnUI",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/A3qj3elVXb",
      "expanded_url" : "http:\/\/go.wh.gov\/gtNVLE",
      "display_url" : "go.wh.gov\/gtNVLE"
    } ]
  },
  "geo" : { },
  "id_str" : "431551634083037187",
  "text" : "\"We cannot allow 1 vote to stand in the way of supporting these Americans.\" \u2014@PressSec on why it's time to #ActOnUI: http:\/\/t.co\/A3qj3elVXb",
  "id" : 431551634083037187,
  "created_at" : "2014-02-06 22:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Victor Cruz",
      "screen_name" : "TeamVic",
      "indices" : [ 37, 45 ],
      "id_str" : "19548850",
      "id" : 19548850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431542685103837184",
  "text" : "RT @vj44: Great to see athletes like @TeamVic @Thromedamnball &amp; @SanyaRichiRoss spreading the word on health care! http:\/\/t.co\/id30c9I091 #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Victor Cruz",
        "screen_name" : "TeamVic",
        "indices" : [ 27, 35 ],
        "id_str" : "19548850",
        "id" : 19548850
      }, {
        "name" : "Sanya Richards-Ross",
        "screen_name" : "SanyaRichiRoss",
        "indices" : [ 58, 73 ],
        "id_str" : "40781725",
        "id" : 40781725
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 132, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/id30c9I091",
        "expanded_url" : "http:\/\/gameplan4me.com",
        "display_url" : "gameplan4me.com"
      } ]
    },
    "geo" : { },
    "id_str" : "431521602660864001",
    "text" : "Great to see athletes like @TeamVic @Thromedamnball &amp; @SanyaRichiRoss spreading the word on health care! http:\/\/t.co\/id30c9I091 #GetCovered",
    "id" : 431521602660864001,
    "created_at" : "2014-02-06 20:15:42 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 431542685103837184,
  "created_at" : "2014-02-06 21:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431537673149620224",
  "text" : "RT @FLOTUS: \"No matter where you come from or how much money your family has...you can succeed in college.\" \u2014The First Lady: http:\/\/t.co\/Y7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/431527479669321728\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Y7SSHQlbfD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bf0X9MrCYAAph3L.jpg",
        "id_str" : "431527479438630912",
        "id" : 431527479438630912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bf0X9MrCYAAph3L.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/Y7SSHQlbfD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431527479669321728",
    "text" : "\"No matter where you come from or how much money your family has...you can succeed in college.\" \u2014The First Lady: http:\/\/t.co\/Y7SSHQlbfD",
    "id" : 431527479669321728,
    "created_at" : "2014-02-06 20:39:03 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 431537673149620224,
  "created_at" : "2014-02-06 21:19:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnUI",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431525211804942337",
  "text" : "FACT: If Congress fails to #ActOnUI this year, 3.2 million more Americans looking for work will lose unemployment benefits.",
  "id" : 431525211804942337,
  "created_at" : "2014-02-06 20:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnUI",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431517998999150592",
  "text" : "39 GOP senators just voted to block extending a lifeline to 1.7 million Americans looking for a job.\n\nRT if you agree that's wrong. #ActOnUI",
  "id" : 431517998999150592,
  "created_at" : "2014-02-06 20:01:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/PsQZ910IAr",
      "expanded_url" : "http:\/\/go.wh.gov\/yCyctK",
      "display_url" : "go.wh.gov\/yCyctK"
    } ]
  },
  "geo" : { },
  "id_str" : "431510109177389057",
  "text" : "Worth sharing: Here are 6 ways the Affordable Care Act benefits our economy \u2192 http:\/\/t.co\/PsQZ910IAr #GetCovered",
  "id" : 431510109177389057,
  "created_at" : "2014-02-06 19:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/GCdt1SCJlw",
      "expanded_url" : "http:\/\/go.wh.gov\/TfbqxP",
      "display_url" : "go.wh.gov\/TfbqxP"
    } ]
  },
  "geo" : { },
  "id_str" : "431500042533208064",
  "text" : "Thanks to the Affordable Care Act, it's easier to:\n1. Start a business\n2. Raise a family\n3. Switch jobs\nhttp:\/\/t.co\/GCdt1SCJlw #GetCovered",
  "id" : 431500042533208064,
  "created_at" : "2014-02-06 18:50:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Lsp2Zlnvq1",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/02\/06\/six-economic-benefits-affordable-care-act",
      "display_url" : "whitehouse.gov\/blog\/2014\/02\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "431498053389131776",
  "text" : "RT @CEAChair: Today ACA is putting more $ in families\u2019 pockets, boosting demand &amp; bringing down unemployment http:\/\/t.co\/Lsp2Zlnvq1 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/431490289069346816\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/GAchGxhlDQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfz2IbzCUAAJmQ6.jpg",
        "id_str" : "431490289081929728",
        "id" : 431490289081929728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfz2IbzCUAAJmQ6.jpg",
        "sizes" : [ {
          "h" : 182,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/GAchGxhlDQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/Lsp2Zlnvq1",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/02\/06\/six-economic-benefits-affordable-care-act",
        "display_url" : "whitehouse.gov\/blog\/2014\/02\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431490289069346816",
    "text" : "Today ACA is putting more $ in families\u2019 pockets, boosting demand &amp; bringing down unemployment http:\/\/t.co\/Lsp2Zlnvq1 http:\/\/t.co\/GAchGxhlDQ",
    "id" : 431490289069346816,
    "created_at" : "2014-02-06 18:11:16 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 431498053389131776,
  "created_at" : "2014-02-06 18:42:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPrayerBreakfast",
      "indices" : [ 116, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431477392943509505",
  "text" : "Obama: \"Let\u2019s do more to nurture the dialogue between faiths that breaks cycles of conflict and builds true peace.\" #NationalPrayerBreakfast",
  "id" : 431477392943509505,
  "created_at" : "2014-02-06 17:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431472907026722816",
  "text" : "\"No society can truly succeed unless it guarantees the rights of all its peoples, including religious minorities.\" \u2014President Obama",
  "id" : 431472907026722816,
  "created_at" : "2014-02-06 17:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431468089281351680",
  "text" : "\"No nation on Earth does more to stand up for the freedom of religion around the world than the United States of America.\" \u2014President Obama",
  "id" : 431468089281351680,
  "created_at" : "2014-02-06 16:43:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431465034938871809",
  "text" : "\"Nations that uphold the rights of their people\u2014including the freedom of religion\u2014are ultimately more just &amp; more peaceful\" \u2014President Obama",
  "id" : 431465034938871809,
  "created_at" : "2014-02-06 16:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPrayerBreakfast",
      "indices" : [ 116, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431461574659026944",
  "text" : "\"Our faith teaches us that in the face of suffering\u2014we can\u2019t stand idly by...we must be that Good Samaritan\" \u2014Obama #NationalPrayerBreakfast",
  "id" : 431461574659026944,
  "created_at" : "2014-02-06 16:17:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Washington Capitals",
      "screen_name" : "washcaps",
      "indices" : [ 90, 99 ],
      "id_str" : "733381856607883264",
      "id" : 733381856607883264
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "BringHomeTheGold",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431456458442833920",
  "text" : "RT @JohnKerry: Today's power suit. Look forward to meeting #TeamUSA hockey players at the @WashCaps game tonight. #BringHomeTheGold http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Capitals",
        "screen_name" : "washcaps",
        "indices" : [ 75, 84 ],
        "id_str" : "733381856607883264",
        "id" : 733381856607883264
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/431452632415076352\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/XtwEhpklxR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfzT4hzCAAA0VKL.jpg",
        "id_str" : "431452632419270656",
        "id" : 431452632419270656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfzT4hzCAAA0VKL.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 902,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XtwEhpklxR"
      } ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 44, 52 ]
      }, {
        "text" : "BringHomeTheGold",
        "indices" : [ 99, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431452632415076352",
    "text" : "Today's power suit. Look forward to meeting #TeamUSA hockey players at the @WashCaps game tonight. #BringHomeTheGold http:\/\/t.co\/XtwEhpklxR",
    "id" : 431452632415076352,
    "created_at" : "2014-02-06 15:41:38 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 431456458442833920,
  "created_at" : "2014-02-06 15:56:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431451939092828160",
  "text" : "RT @Cecilia44: READ: \u201CSometimes, when you're young, you don\u2019t think about the importance of having [insurance] until it\u2019s too late.\u201D http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/j8IgprgVEn",
        "expanded_url" : "http:\/\/www.usatoday.com\/story\/news\/nation\/2014\/02\/05\/athletes-highlight-health-insurance-as-part-of-life-game-plan\/5233259\/",
        "display_url" : "usatoday.com\/story\/news\/nat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431448402027491328",
    "text" : "READ: \u201CSometimes, when you're young, you don\u2019t think about the importance of having [insurance] until it\u2019s too late.\u201D http:\/\/t.co\/j8IgprgVEn",
    "id" : 431448402027491328,
    "created_at" : "2014-02-06 15:24:49 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 431451939092828160,
  "created_at" : "2014-02-06 15:38:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/431223773124382720\/photo\/1",
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/2qfeezsy7D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfwDvJ1IAAALop_.jpg",
      "id_str" : "431223772948201472",
      "id" : 431223772948201472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfwDvJ1IAAALop_.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2qfeezsy7D"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431223773124382720",
  "text" : "Soon. http:\/\/t.co\/2qfeezsy7D",
  "id" : 431223773124382720,
  "created_at" : "2014-02-06 00:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 88, 94 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431220441391595520",
  "text" : "RT @FLOTUS: \"Fill out those forms...don\u2019t leave money on the table.\" \u2014FLOTUS on how the @FAFSA helps millions afford college http:\/\/t.co\/lo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Federal Student Aid",
        "screen_name" : "FAFSA",
        "indices" : [ 76, 82 ],
        "id_str" : "188001904",
        "id" : 188001904
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/431218278241820672\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/losmtreRpJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfv-vTXCMAAr4cx.jpg",
        "id_str" : "431218277948207104",
        "id" : 431218277948207104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfv-vTXCMAAr4cx.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/losmtreRpJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431218278241820672",
    "text" : "\"Fill out those forms...don\u2019t leave money on the table.\" \u2014FLOTUS on how the @FAFSA helps millions afford college http:\/\/t.co\/losmtreRpJ",
    "id" : 431218278241820672,
    "created_at" : "2014-02-06 00:10:23 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 431220441391595520,
  "created_at" : "2014-02-06 00:18:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NGWSD",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/kXYVoU9VmH",
      "expanded_url" : "http:\/\/go.wh.gov\/jmBAkt",
      "display_url" : "go.wh.gov\/jmBAkt"
    } ]
  },
  "geo" : { },
  "id_str" : "431214228356464640",
  "text" : "RT @letsmove: Passing the torch, blazing the trail: Celebrate National Girls &amp; Women in Sports Day \u2192 http:\/\/t.co\/kXYVoU9VmH #NGWSD, http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/letsmove\/status\/431119291279101952\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/9ybCIzcwpA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfukthTCUAAzZeY.jpg",
        "id_str" : "431119291283296256",
        "id" : 431119291283296256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfukthTCUAAzZeY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/9ybCIzcwpA"
      } ],
      "hashtags" : [ {
        "text" : "NGWSD",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/kXYVoU9VmH",
        "expanded_url" : "http:\/\/go.wh.gov\/jmBAkt",
        "display_url" : "go.wh.gov\/jmBAkt"
      } ]
    },
    "geo" : { },
    "id_str" : "431119291279101952",
    "text" : "Passing the torch, blazing the trail: Celebrate National Girls &amp; Women in Sports Day \u2192 http:\/\/t.co\/kXYVoU9VmH #NGWSD, http:\/\/t.co\/9ybCIzcwpA",
    "id" : 431119291279101952,
    "created_at" : "2014-02-05 17:37:03 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 431214228356464640,
  "created_at" : "2014-02-05 23:54:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "renewUI",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431201715401293826",
  "text" : "RT @SenatorReid: We'll vote to #renewUI tomorrow at 11 am. Please make sure your voices are heard!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "renewUI",
        "indices" : [ 14, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431191652397744128",
    "text" : "We'll vote to #renewUI tomorrow at 11 am. Please make sure your voices are heard!",
    "id" : 431191652397744128,
    "created_at" : "2014-02-05 22:24:35 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 431201715401293826,
  "created_at" : "2014-02-05 23:04:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 17, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/Oj8QDACM3f",
      "expanded_url" : "http:\/\/youtu.be\/CyLIQvbz1Z0",
      "display_url" : "youtu.be\/CyLIQvbz1Z0"
    } ]
  },
  "geo" : { },
  "id_str" : "431185467376013312",
  "text" : "Overheard on the #POTUSRoadTrip: \"I've got this amazing wife &amp; two unbelievably terrific daughters\" \u2014President Obama: http:\/\/t.co\/Oj8QDACM3f",
  "id" : 431185467376013312,
  "created_at" : "2014-02-05 22:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/RzXxUHuOmn",
      "expanded_url" : "http:\/\/go.wh.gov\/5n1FnB",
      "display_url" : "go.wh.gov\/5n1FnB"
    } ]
  },
  "geo" : { },
  "id_str" : "431175866052542464",
  "text" : "New climate hubs to help farmers respond to climate change are just 1 piece of President Obama's #ActOnClimate plan: http:\/\/t.co\/RzXxUHuOmn",
  "id" : 431175866052542464,
  "created_at" : "2014-02-05 21:21:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ZI6xdBR9a9",
      "expanded_url" : "http:\/\/goo.gl\/ZDncgf",
      "display_url" : "goo.gl\/ZDncgf"
    } ]
  },
  "geo" : { },
  "id_str" : "431171511823904768",
  "text" : "RT @NancyPelosi: Mom jeans, pant suits, whatever your mom prefers, rest assured she\u2019ll love to see you #getcovered: http:\/\/t.co\/ZI6xdBR9a9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/ZI6xdBR9a9",
        "expanded_url" : "http:\/\/goo.gl\/ZDncgf",
        "display_url" : "goo.gl\/ZDncgf"
      } ]
    },
    "geo" : { },
    "id_str" : "431123219534204928",
    "text" : "Mom jeans, pant suits, whatever your mom prefers, rest assured she\u2019ll love to see you #getcovered: http:\/\/t.co\/ZI6xdBR9a9",
    "id" : 431123219534204928,
    "created_at" : "2014-02-05 17:52:40 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 431171511823904768,
  "created_at" : "2014-02-05 21:04:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431164909242843136",
  "text" : "RT @Schultz44: This President has done staggeringly more than any other to make the 3rd branch of govt look like America. See data: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/0Gt2cXFqQt",
        "expanded_url" : "http:\/\/1.usa.gov\/1kTsVz6",
        "display_url" : "1.usa.gov\/1kTsVz6"
      } ]
    },
    "geo" : { },
    "id_str" : "431102880389419009",
    "text" : "This President has done staggeringly more than any other to make the 3rd branch of govt look like America. See data: http:\/\/t.co\/0Gt2cXFqQt",
    "id" : 431102880389419009,
    "created_at" : "2014-02-05 16:31:50 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 431164909242843136,
  "created_at" : "2014-02-05 20:38:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    }, {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 13, 29 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 34, 43 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431158509049479168",
  "text" : "RT @Utech44: @SecretaryJewell and @Interior just announced key steps towards offshore wind in Oregon. Let's #ActOnClimate\u2192 http:\/\/t.co\/92P5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sally Jewell",
        "screen_name" : "SecretaryJewell",
        "indices" : [ 0, 16 ],
        "id_str" : "1342861723",
        "id" : 1342861723
      }, {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 21, 30 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 95, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/92P5mRUEgX",
        "expanded_url" : "http:\/\/www.doi.gov\/news\/pressreleases\/secretary-jewell-announces-key-step-forward-for-offshore-wind-project-in-oregon.cfm",
        "display_url" : "doi.gov\/news\/pressrele\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "431156137296031745",
    "in_reply_to_user_id" : 1342861723,
    "text" : "@SecretaryJewell and @Interior just announced key steps towards offshore wind in Oregon. Let's #ActOnClimate\u2192 http:\/\/t.co\/92P5mRUEgX",
    "id" : 431156137296031745,
    "created_at" : "2014-02-05 20:03:28 +0000",
    "in_reply_to_screen_name" : "SecretaryJewell",
    "in_reply_to_user_id_str" : "1342861723",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 431158509049479168,
  "created_at" : "2014-02-05 20:12:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 112, 131 ]
    }, {
      "text" : "FAFSA",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/E54WTAZMRH",
      "expanded_url" : "http:\/\/go.wh.gov\/SyLHDk",
      "display_url" : "go.wh.gov\/SyLHDk"
    } ]
  },
  "geo" : { },
  "id_str" : "431148092297986049",
  "text" : "Here are 5 reasons why you should complete the Free Application for Federal Student Aid: http:\/\/t.co\/E54WTAZMRH #CollegeOpportunity #FAFSA",
  "id" : 431148092297986049,
  "created_at" : "2014-02-05 19:31:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/J2g34i11FH",
      "expanded_url" : "http:\/\/go.wh.gov\/eghCzr",
      "display_url" : "go.wh.gov\/eghCzr"
    } ]
  },
  "geo" : { },
  "id_str" : "431138627012530176",
  "text" : "RT @FLOTUS: Spread the word!\nFilling out the FAFSA:\n1. Helps you pay for college\n2. Takes less than 30 mins\nhttp:\/\/t.co\/J2g34i11FH #College\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 119, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/J2g34i11FH",
        "expanded_url" : "http:\/\/go.wh.gov\/eghCzr",
        "display_url" : "go.wh.gov\/eghCzr"
      } ]
    },
    "geo" : { },
    "id_str" : "431137761941528576",
    "text" : "Spread the word!\nFilling out the FAFSA:\n1. Helps you pay for college\n2. Takes less than 30 mins\nhttp:\/\/t.co\/J2g34i11FH #CollegeOpportunity",
    "id" : 431137761941528576,
    "created_at" : "2014-02-05 18:50:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 431138627012530176,
  "created_at" : "2014-02-05 18:53:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSCam",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "ConnectED",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/yXYVtb4aFu",
      "expanded_url" : "http:\/\/go.wh.gov\/eBEqEF",
      "display_url" : "go.wh.gov\/eBEqEF"
    } ]
  },
  "geo" : { },
  "id_str" : "431122330145017856",
  "text" : "#POTUSCam: Watch President Obama record a video on an iPad before speaking on #ConnectED at a MD middle school: http:\/\/t.co\/yXYVtb4aFu",
  "id" : 431122330145017856,
  "created_at" : "2014-02-05 17:49:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fran\u00E7ois Hollande",
      "screen_name" : "fhollande",
      "indices" : [ 17, 27 ],
      "id_str" : "18814998",
      "id" : 18814998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHSocial",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/3XfK1mlG5M",
      "expanded_url" : "http:\/\/wh.gov\/social",
      "display_url" : "wh.gov\/social"
    } ]
  },
  "geo" : { },
  "id_str" : "431101664582705152",
  "text" : "French President @FHollande is coming to the White House for a State Visit and you're invited. Apply here \u2192 http:\/\/t.co\/3XfK1mlG5M #WHSocial",
  "id" : 431101664582705152,
  "created_at" : "2014-02-05 16:27:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/ZgMQ3RVE47",
      "expanded_url" : "http:\/\/nyti.ms\/1lzKkk9",
      "display_url" : "nyti.ms\/1lzKkk9"
    } ]
  },
  "geo" : { },
  "id_str" : "431093484087685120",
  "text" : "Worth a read: 7 new climate hubs will help farmers respond to increased droughts, fires, and floods \u2192 http:\/\/t.co\/ZgMQ3RVE47 #ActOnClimate",
  "id" : 431093484087685120,
  "created_at" : "2014-02-05 15:54:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVS",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431077500475539457",
  "text" : "Obama: \"Today\u2019s decision will help advance my Administration\u2019s efforts to reduce tobacco-related deaths, cancer, and heart disease.\" #CVS",
  "id" : 431077500475539457,
  "created_at" : "2014-02-05 14:50:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CVS Pharmacy",
      "screen_name" : "CVS_Extra",
      "indices" : [ 43, 53 ],
      "id_str" : "110775353",
      "id" : 110775353
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/431071542382833664\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PAbM3AHkmv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bft5SKTCIAAMstI.png",
      "id_str" : "431071542252806144",
      "id" : 431071542252806144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bft5SKTCIAAMstI.png",
      "sizes" : [ {
        "h" : 281,
        "resize" : "fit",
        "w" : 906
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 906
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PAbM3AHkmv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431071542382833664",
  "text" : "Obama: \"I applaud this morning\u2019s news that @CVS_Extra has decided to stop selling cigarettes...in its stores.\" http:\/\/t.co\/PAbM3AHkmv",
  "id" : 431071542382833664,
  "created_at" : "2014-02-05 14:27:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "CVS Pharmacy",
      "screen_name" : "CVS_Extra",
      "indices" : [ 19, 29 ],
      "id_str" : "110775353",
      "id" : 110775353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431067653797842944",
  "text" : "RT @FLOTUS: Thanks @CVS_Extra, now we can all breathe a little easier, and our families can live healthier. \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CVS Pharmacy",
        "screen_name" : "CVS_Extra",
        "indices" : [ 7, 17 ],
        "id_str" : "110775353",
        "id" : 110775353
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "431067334779080704",
    "text" : "Thanks @CVS_Extra, now we can all breathe a little easier, and our families can live healthier. \u2013mo",
    "id" : 431067334779080704,
    "created_at" : "2014-02-05 14:10:36 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 431067653797842944,
  "created_at" : "2014-02-05 14:11:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seattle Seahawks",
      "screen_name" : "Seahawks",
      "indices" : [ 72, 81 ],
      "id_str" : "23642374",
      "id" : 23642374
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/430856875765006336\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/7sC8zZogHF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfq2C6sCMAAH3Ry.jpg",
      "id_str" : "430856875597246464",
      "id" : 430856875597246464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfq2C6sCMAAH3Ry.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7sC8zZogHF"
    } ],
    "hashtags" : [ {
      "text" : "12thMan",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430856875765006336",
  "text" : "President Obama calls to congratulate coach Pete Carroll on the Seattle @Seahawks' Super Bowl victory. #12thMan, http:\/\/t.co\/7sC8zZogHF",
  "id" : 430856875765006336,
  "created_at" : "2014-02-05 00:14:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/430845214480007169\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/vHhYmcY0Z6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfqrcJMCUAAFZaC.jpg",
      "id_str" : "430845214358392832",
      "id" : 430845214358392832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfqrcJMCUAAFZaC.jpg",
      "sizes" : [ {
        "h" : 725,
        "resize" : "fit",
        "w" : 1005
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1005
      } ],
      "display_url" : "pic.twitter.com\/vHhYmcY0Z6"
    } ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430845214480007169",
  "text" : "POTUS records a video at a MD middle school before speaking on expanding high-speed internet access. #ConnectED, http:\/\/t.co\/vHhYmcY0Z6",
  "id" : 430845214480007169,
  "created_at" : "2014-02-04 23:27:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/NCPec2XIhA",
      "expanded_url" : "http:\/\/go.wh.gov\/3UuiFZ",
      "display_url" : "go.wh.gov\/3UuiFZ"
    } ]
  },
  "geo" : { },
  "id_str" : "430841709967454208",
  "text" : "President Obama: \"Today\u2014in a strong bipartisan vote\u2014the U.S. Senate came together to pass a comprehensive Farm Bill.\" http:\/\/t.co\/NCPec2XIhA",
  "id" : 430841709967454208,
  "created_at" : "2014-02-04 23:14:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uF8FF James T Richardson",
      "screen_name" : "PrincipalJRich",
      "indices" : [ 3, 18 ],
      "id_str" : "478321969",
      "id" : 478321969
    }, {
      "name" : "BuckLodgeMS",
      "screen_name" : "BuckLodgeMS",
      "indices" : [ 63, 75 ],
      "id_str" : "2327577991",
      "id" : 2327577991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/VATTvlRaPM",
      "expanded_url" : "http:\/\/youtu.be\/kHWcl12eQrs",
      "display_url" : "youtu.be\/kHWcl12eQrs"
    } ]
  },
  "geo" : { },
  "id_str" : "430822890268033024",
  "text" : "MT @PrincipalJRich: World, check out President Obama recording @BuckLodgeMS students with an iPad http:\/\/t.co\/VATTvlRaPM #ConnectED",
  "id" : 430822890268033024,
  "created_at" : "2014-02-04 21:59:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/wiOiEWEaee",
      "expanded_url" : "http:\/\/go.wh.gov\/kkUXvE",
      "display_url" : "go.wh.gov\/kkUXvE"
    } ]
  },
  "geo" : { },
  "id_str" : "430797656617943041",
  "text" : "President Obama on new steps to accelerate the development of life-saving drugs and identify new treatments &amp; cures: http:\/\/t.co\/wiOiEWEaee",
  "id" : 430797656617943041,
  "created_at" : "2014-02-04 20:18:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/430778588921884672\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/M1GIaCP340",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfpu2BeIYAAv4ag.jpg",
      "id_str" : "430778588754108416",
      "id" : 430778588754108416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfpu2BeIYAAv4ag.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/M1GIaCP340"
    } ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/0HstOGvh6z",
      "expanded_url" : "http:\/\/go.wh.gov\/T8TYAB",
      "display_url" : "go.wh.gov\/T8TYAB"
    } ]
  },
  "geo" : { },
  "id_str" : "430778588921884672",
  "text" : "RT if you agree: Every student in America deserves access to high-speed internet: http:\/\/t.co\/0HstOGvh6z #ConnectED, http:\/\/t.co\/M1GIaCP340",
  "id" : 430778588921884672,
  "created_at" : "2014-02-04 19:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/dw1WotZYmF",
      "expanded_url" : "http:\/\/go.wh.gov\/Ua3m6n",
      "display_url" : "go.wh.gov\/Ua3m6n"
    } ]
  },
  "geo" : { },
  "id_str" : "430770475690504192",
  "text" : "FACT: Less than 30% of schools in America have the broadband they need to teach using today's technology \u2192 http:\/\/t.co\/dw1WotZYmF #ConnectED",
  "id" : 430770475690504192,
  "created_at" : "2014-02-04 18:30:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 11, 27 ],
      "id_str" : "234141596",
      "id" : 234141596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/G4VecB830F",
      "expanded_url" : "http:\/\/1.usa.gov\/1cRfxtB",
      "display_url" : "1.usa.gov\/1cRfxtB"
    } ]
  },
  "geo" : { },
  "id_str" : "430765330966011904",
  "text" : "Good news: @GovMalloyOffice just proposed raising Connecticut's minimum wage to $10.10\/hour \u2192 http:\/\/t.co\/G4VecB830F #RaiseTheWage",
  "id" : 430765330966011904,
  "created_at" : "2014-02-04 18:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Z3XEPeEQaE",
      "expanded_url" : "http:\/\/go.wh.gov\/Rcitvb",
      "display_url" : "go.wh.gov\/Rcitvb"
    } ]
  },
  "geo" : { },
  "id_str" : "430757889666330625",
  "text" : "Here's how President Obama's #ConnectED initiative will help 99% of America's students access high-speed internet \u2192 http:\/\/t.co\/Z3XEPeEQaE",
  "id" : 430757889666330625,
  "created_at" : "2014-02-04 17:40:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430747945190055936",
  "text" : "Obama: \"If we...make sure every young person can go as far as their...hard work will take them...we can keep the American Dream alive.\"",
  "id" : 430747945190055936,
  "created_at" : "2014-02-04 17:01:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430747252655919105",
  "text" : "Obama: \"Imagine what it could mean for a girl growing up on a farm to take AP biology...even if her school\u2019s too small to offer it.\"",
  "id" : 430747252655919105,
  "created_at" : "2014-02-04 16:58:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430747107121958912",
  "text" : "Obama: \"I'll ask every business leader...to join...ask yourself what you can do to help us connect our students to the 21st century.\"",
  "id" : 430747107121958912,
  "created_at" : "2014-02-04 16:58:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Apple",
      "screen_name" : "Apple",
      "indices" : [ 20, 26 ],
      "id_str" : "380749300",
      "id" : 380749300
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430746100258312192",
  "text" : "RT @WHLive: Obama: \"@Apple will donate $100 million worth of iPads, MacBooks, and other products to schools across the country.\" #ConnectED",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Apple",
        "screen_name" : "Apple",
        "indices" : [ 8, 14 ],
        "id_str" : "380749300",
        "id" : 380749300
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ConnectED",
        "indices" : [ 117, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430746045988216832",
    "text" : "Obama: \"@Apple will donate $100 million worth of iPads, MacBooks, and other products to schools across the country.\" #ConnectED",
    "id" : 430746045988216832,
    "created_at" : "2014-02-04 16:53:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 430746100258312192,
  "created_at" : "2014-02-04 16:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430745941394853888",
  "text" : "Obama: \"Some of America\u2019s biggest tech companies are joining this effort, with commitments worth more than $750 million.\" #ConnectED",
  "id" : 430745941394853888,
  "created_at" : "2014-02-04 16:53:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430745245861814272",
  "text" : "President Obama: \"Technology allows teachers here to spend more time being creative and less time teaching to the test.\" #ConnectED",
  "id" : 430745245861814272,
  "created_at" : "2014-02-04 16:50:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430744999010267136",
  "text" : "President Obama: \"In a country where we expect free Wi-Fi with our coffee, we should demand it in our schools.\" #ConnectED",
  "id" : 430744999010267136,
  "created_at" : "2014-02-04 16:49:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430744190184853504",
  "text" : "RT @WHLive: Obama: \"We\u2019ll work with states and communities to help them make high-quality pre-K available to more young children.\" #ActOnPr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnPreK",
        "indices" : [ 119, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430744151463059458",
    "text" : "Obama: \"We\u2019ll work with states and communities to help them make high-quality pre-K available to more young children.\" #ActOnPreK",
    "id" : 430744151463059458,
    "created_at" : "2014-02-04 16:46:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 430744190184853504,
  "created_at" : "2014-02-04 16:46:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 108, 127 ]
    }, {
      "text" : "ConnectED",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430743930817495040",
  "text" : "\u201CMy country invested in me\u2026and now I want America to invest in you.\u201D \u2014Obama to middle school students in MD #CollegeOpportunity #ConnectED",
  "id" : 430743930817495040,
  "created_at" : "2014-02-04 16:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430743461391007744",
  "text" : "Obama: \"I\u2019m not so different from many of you. I was raised by a single mom, with the help of my grandma and grandpa.\" #OpportunityForAll",
  "id" : 430743461391007744,
  "created_at" : "2014-02-04 16:43:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 92, 111 ]
    }, {
      "text" : "ConnectED",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430743295690817536",
  "text" : "\"I\u2019m only standing here today because of the chance my education gave me.\" \u2014President Obama #CollegeOpportunity #ConnectED",
  "id" : 430743295690817536,
  "created_at" : "2014-02-04 16:42:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 41, 51 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 74, 87 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430743063141822464",
  "text" : "President Obama's opportunity agenda:\n1. #ActOnJobs\n2. Skills training\n3. #RaiseTheWage\n4. Access to a quality education\n#OpportunityForAll",
  "id" : 430743063141822464,
  "created_at" : "2014-02-04 16:42:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430742904509042688",
  "text" : "\"Each generation has to work hard to make sure the dream of opportunity stays alive for the next generation.\" \u2014President Obama #ConnectED",
  "id" : 430742904509042688,
  "created_at" : "2014-02-04 16:41:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430742748510294016",
  "text" : "\"Your education is the very best investment that all of us can make in America.\" \u2014President Obama at a middle school in Maryland #ConnectED",
  "id" : 430742748510294016,
  "created_at" : "2014-02-04 16:40:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/o76oBsfr0M",
      "expanded_url" : "http:\/\/go.wh.gov\/UUb84S",
      "display_url" : "go.wh.gov\/UUb84S"
    } ]
  },
  "geo" : { },
  "id_str" : "430738175733268480",
  "text" : "At 11:30am ET, President Obama announces progress on connecting 99% of students to high-speed Internet: http:\/\/t.co\/o76oBsfr0M #ConnectED",
  "id" : 430738175733268480,
  "created_at" : "2014-02-04 16:22:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/430729227256598528\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/1J8PdLupEF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfpB8y9CEAEaR6q.jpg",
      "id_str" : "430729227093020673",
      "id" : 430729227093020673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfpB8y9CEAEaR6q.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/1J8PdLupEF"
    } ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430729227256598528",
  "text" : "In a country where we expect free WI-FI with our coffee, we should have it in our schools. #ConnectED, http:\/\/t.co\/1J8PdLupEF",
  "id" : 430729227256598528,
  "created_at" : "2014-02-04 15:47:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 16, 24 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 35, 45 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JKTweetsAgain",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430723178462470144",
  "text" : "Welcome back to @Twitter Secretary @JohnKerry! #JKTweetsAgain",
  "id" : 430723178462470144,
  "created_at" : "2014-02-04 15:23:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 39, 49 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 77, 85 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JKTweetsAgain",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430711519417225217",
  "text" : "RT @JohnKerry: It only took a year but @StateDept finally let me have my own @Twitter account. #JKTweetsAgain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 24, 34 ],
        "id_str" : "9624742",
        "id" : 9624742
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 62, 70 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JKTweetsAgain",
        "indices" : [ 80, 94 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "430693713673596928",
    "geo" : { },
    "id_str" : "430693971510059008",
    "in_reply_to_user_id" : 9624742,
    "text" : "It only took a year but @StateDept finally let me have my own @Twitter account. #JKTweetsAgain",
    "id" : 430693971510059008,
    "in_reply_to_status_id" : 430693713673596928,
    "created_at" : "2014-02-04 13:26:59 +0000",
    "in_reply_to_screen_name" : "StateDept",
    "in_reply_to_user_id_str" : "9624742",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 430711519417225217,
  "created_at" : "2014-02-04 14:36:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/430496030824857600\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/T9lYLmeDen",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bflt2-cIAAAA8pl.jpg",
      "id_str" : "430496030631919616",
      "id" : 430496030631919616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bflt2-cIAAAA8pl.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/T9lYLmeDen"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430496030824857600",
  "text" : "Blue Room belly rub. http:\/\/t.co\/T9lYLmeDen",
  "id" : 430496030824857600,
  "created_at" : "2014-02-04 00:20:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/430481714591178752\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/XEklYLIAFO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bflg1qOCQAACEjX.jpg",
      "id_str" : "430481714373083136",
      "id" : 430481714373083136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bflg1qOCQAACEjX.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XEklYLIAFO"
    } ],
    "hashtags" : [ {
      "text" : "Fermi",
      "indices" : [ 8, 14 ]
    }, {
      "text" : "EnergyEfficiency",
      "indices" : [ 53, 70 ]
    }, {
      "text" : "Solar",
      "indices" : [ 71, 77 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 78, 91 ]
    }, {
      "text" : "ScienceRules",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/6VUAzluBIx",
      "expanded_url" : "http:\/\/go.wh.gov\/VitN4V",
      "display_url" : "go.wh.gov\/VitN4V"
    } ]
  },
  "geo" : { },
  "id_str" : "430481714591178752",
  "text" : "And the #Fermi Award goes to\u2026 http:\/\/t.co\/6VUAzluBIx #EnergyEfficiency #Solar #ActOnClimate #ScienceRules, http:\/\/t.co\/XEklYLIAFO",
  "id" : 430481714591178752,
  "created_at" : "2014-02-03 23:23:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wisconsin",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430475220156436481",
  "text" : "RT @Interior: For the 1st time in 5 years, Lake Superior is frozen enough 2 visit the amazing ice caves @ Apostle Is. #Wisconsin http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/430470682099855360\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/q9RgQHQlkE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BflWzfUIAAAW2Wv.jpg",
        "id_str" : "430470681969819648",
        "id" : 430470681969819648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BflWzfUIAAAW2Wv.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/q9RgQHQlkE"
      } ],
      "hashtags" : [ {
        "text" : "Wisconsin",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430470682099855360",
    "text" : "For the 1st time in 5 years, Lake Superior is frozen enough 2 visit the amazing ice caves @ Apostle Is. #Wisconsin http:\/\/t.co\/q9RgQHQlkE",
    "id" : 430470682099855360,
    "created_at" : "2014-02-03 22:39:43 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 430475220156436481,
  "created_at" : "2014-02-03 22:57:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430459330174148608",
  "text" : "RT @VP: You\u2019re a lucky man when you can look at your child &amp; realize he\u2019s turned out better than you. Happy Birthday to my son Beau @AG_Bid\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "430395631878672384",
    "text" : "You\u2019re a lucky man when you can look at your child &amp; realize he\u2019s turned out better than you. Happy Birthday to my son Beau @AG_Biden!  \u2013VP",
    "id" : 430395631878672384,
    "created_at" : "2014-02-03 17:41:29 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 430459330174148608,
  "created_at" : "2014-02-03 21:54:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "indices" : [ 68, 78 ],
      "id_str" : "321466257",
      "id" : 321466257
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IMadeThis",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/iMKBRjWt2V",
      "expanded_url" : "http:\/\/go.wh.gov\/yLt1zr",
      "display_url" : "go.wh.gov\/yLt1zr"
    } ]
  },
  "geo" : { },
  "id_str" : "430449078405955586",
  "text" : "Introducing the 1st-ever White House Maker Faire, brought to you by @Joey_Hudy and his marshmallow cannon: http:\/\/t.co\/iMKBRjWt2V #IMadeThis",
  "id" : 430449078405955586,
  "created_at" : "2014-02-03 21:13:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcia Snyder",
      "screen_name" : "GovSteveBeshear",
      "indices" : [ 3, 19 ],
      "id_str" : "4549215252",
      "id" : 4549215252
    }, {
      "name" : "kynectky",
      "screen_name" : "kynectky",
      "indices" : [ 88, 97 ],
      "id_str" : "1336773938",
      "id" : 1336773938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kynect",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "ACA",
      "indices" : [ 107, 111 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430428430476529664",
  "text" : "RT @GovSteveBeshear: 200,477 Kentuckians have signed up for affordable healthcare using @kynectky! #kynect #ACA #GetCovered http:\/\/t.co\/6B8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kynectky",
        "screen_name" : "kynectky",
        "indices" : [ 67, 76 ],
        "id_str" : "1336773938",
        "id" : 1336773938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kynect",
        "indices" : [ 78, 85 ]
      }, {
        "text" : "ACA",
        "indices" : [ 86, 90 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 91, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/6B8TGA8NMH",
        "expanded_url" : "http:\/\/www.kynect.ky.gov",
        "display_url" : "kynect.ky.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "430395688363372545",
    "text" : "200,477 Kentuckians have signed up for affordable healthcare using @kynectky! #kynect #ACA #GetCovered http:\/\/t.co\/6B8TGA8NMH",
    "id" : 430395688363372545,
    "created_at" : "2014-02-03 17:41:43 +0000",
    "user" : {
      "name" : "Steve Beshear",
      "screen_name" : "Steve__Beshear",
      "protected" : false,
      "id_str" : "37656339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674302651681648640\/9IZtv6cB_normal.jpg",
      "id" : 37656339,
      "verified" : false
    }
  },
  "id" : 430428430476529664,
  "created_at" : "2014-02-03 19:51:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    }, {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 76, 83 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430425107291729920",
  "text" : "RT @Utech44: More efficiency news! External power supply standards from the @ENERGY Dept will save $4 billion and #ActOnClimate\u2192 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Energy Department",
        "screen_name" : "ENERGY",
        "indices" : [ 63, 70 ],
        "id_str" : "166252256",
        "id" : 166252256
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/XOa6y8Dzke",
        "expanded_url" : "http:\/\/energy.gov\/articles\/new-energy-efficiency-standards-external-power-supplies-cut-consumers-utility-bills",
        "display_url" : "energy.gov\/articles\/new-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430404935243403264",
    "text" : "More efficiency news! External power supply standards from the @ENERGY Dept will save $4 billion and #ActOnClimate\u2192 http:\/\/t.co\/XOa6y8Dzke",
    "id" : 430404935243403264,
    "created_at" : "2014-02-03 18:18:27 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 430425107291729920,
  "created_at" : "2014-02-03 19:38:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/430387866510688256\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/hzwGGqt9r8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfkLe_QCQAAkCc6.jpg",
      "id_str" : "430387866393264128",
      "id" : 430387866393264128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfkLe_QCQAAkCc6.jpg",
      "sizes" : [ {
        "h" : 770,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 790,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/hzwGGqt9r8"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/n1ULY7KTUG",
      "expanded_url" : "http:\/\/go.wh.gov\/NMkjKC",
      "display_url" : "go.wh.gov\/NMkjKC"
    } ]
  },
  "geo" : { },
  "id_str" : "430387866510688256",
  "text" : "\"We can\u2019t afford to let such incredible talent be wasting away.\" \u2014Obama: http:\/\/t.co\/n1ULY7KTUG #OpportunityForAll, http:\/\/t.co\/hzwGGqt9r8",
  "id" : 430387866510688256,
  "created_at" : "2014-02-03 17:10:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteOurTroops",
      "indices" : [ 109, 125 ]
    }, {
      "text" : "JoiningForces",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/CU5NDzyxAD",
      "expanded_url" : "http:\/\/go.wh.gov\/fbnq5E",
      "display_url" : "go.wh.gov\/fbnq5E"
    } ]
  },
  "geo" : { },
  "id_str" : "430377369875275777",
  "text" : "\"We honor their sacrifice to protect those ideals upon which this nation was founded\" http:\/\/t.co\/CU5NDzyxAD #SaluteOurTroops #JoiningForces",
  "id" : 430377369875275777,
  "created_at" : "2014-02-03 16:28:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/qXu9I67kvm",
      "expanded_url" : "http:\/\/go.wh.gov\/crH6g8",
      "display_url" : "go.wh.gov\/crH6g8"
    } ]
  },
  "geo" : { },
  "id_str" : "430362705481170945",
  "text" : "\"When we come together in common purpose, we can right the wrongs of history and make our world anew.\" \u2014Obama: http:\/\/t.co\/qXu9I67kvm",
  "id" : 430362705481170945,
  "created_at" : "2014-02-03 15:30:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/430109743773126656\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/DvkM6G8QKN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfgOiHCIAAAFm4U.jpg",
      "id_str" : "430109743580184576",
      "id" : 430109743580184576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfgOiHCIAAAFm4U.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/DvkM6G8QKN"
    } ],
    "hashtags" : [ {
      "text" : "SuperBowlSunday",
      "indices" : [ 12, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430109743773126656",
  "text" : "Beast mode. #SuperBowlSunday, http:\/\/t.co\/DvkM6G8QKN",
  "id" : 430109743773126656,
  "created_at" : "2014-02-02 22:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/430091068655558656\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/i0nbrcKiFc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bff9jE7IgAAMGRu.jpg",
      "id_str" : "430091068496183296",
      "id" : 430091068496183296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bff9jE7IgAAMGRu.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/i0nbrcKiFc"
    } ],
    "hashtags" : [ {
      "text" : "SuperBowlSunday",
      "indices" : [ 9, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430091068655558656",
  "text" : "\"Omaha!\" #SuperBowlSunday, http:\/\/t.co\/i0nbrcKiFc",
  "id" : 430091068655558656,
  "created_at" : "2014-02-02 21:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendon Ayanbadejo",
      "screen_name" : "brendon310",
      "indices" : [ 3, 14 ],
      "id_str" : "297098066",
      "id" : 297098066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/nS6HeQL927",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "430075888215285760",
  "text" : "RT @brendon310: Getting ready for Super Bowl XLVIII\u2026 Football fans don\u2019t forget you can affordable healthcare at http:\/\/t.co\/nS6HeQL927 #ge\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 120, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/nS6HeQL927",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "430038866289229824",
    "text" : "Getting ready for Super Bowl XLVIII\u2026 Football fans don\u2019t forget you can affordable healthcare at http:\/\/t.co\/nS6HeQL927 #getcovered.",
    "id" : 430038866289229824,
    "created_at" : "2014-02-02 18:03:50 +0000",
    "user" : {
      "name" : "Brendon Ayanbadejo",
      "screen_name" : "brendon310",
      "protected" : false,
      "id_str" : "297098066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775218198664720385\/eOqsCOGG_normal.jpg",
      "id" : 297098066,
      "verified" : true
    }
  },
  "id" : 430075888215285760,
  "created_at" : "2014-02-02 20:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Victor Cruz",
      "screen_name" : "TeamVic",
      "indices" : [ 50, 58 ],
      "id_str" : "19548850",
      "id" : 19548850
    }, {
      "name" : "Connect Minds",
      "screen_name" : "ConnectMinds",
      "indices" : [ 116, 129 ],
      "id_str" : "97002407",
      "id" : 97002407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 67, 72 ]
    }, {
      "text" : "CAMMDay",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/fD6BAjv0gg",
      "expanded_url" : "http:\/\/wh.gov\/lRPo3",
      "display_url" : "wh.gov\/lRPo3"
    } ]
  },
  "geo" : { },
  "id_str" : "430065113668661250",
  "text" : "RT @whitehouseostp: It's game day. We caught up w @TeamVic to talk #STEM &amp; Super Bowl! \u2192 http:\/\/t.co\/fD6BAjv0gg @ConnectMinds #CAMMDay http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Victor Cruz",
        "screen_name" : "TeamVic",
        "indices" : [ 30, 38 ],
        "id_str" : "19548850",
        "id" : 19548850
      }, {
        "name" : "Connect Minds",
        "screen_name" : "ConnectMinds",
        "indices" : [ 96, 109 ],
        "id_str" : "97002407",
        "id" : 97002407
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 47, 52 ]
      }, {
        "text" : "CAMMDay",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/fD6BAjv0gg",
        "expanded_url" : "http:\/\/wh.gov\/lRPo3",
        "display_url" : "wh.gov\/lRPo3"
      }, {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/vxenqclJ5J",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=cgCKDCVC2vM",
        "display_url" : "youtube.com\/watch?v=cgCKDC\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "430054275893325824",
    "text" : "It's game day. We caught up w @TeamVic to talk #STEM &amp; Super Bowl! \u2192 http:\/\/t.co\/fD6BAjv0gg @ConnectMinds #CAMMDay http:\/\/t.co\/vxenqclJ5J",
    "id" : 430054275893325824,
    "created_at" : "2014-02-02 19:05:04 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 430065113668661250,
  "created_at" : "2014-02-02 19:48:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/430022727030689792\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/95RA9iH8rc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bfe_ZEbCAAA6yhS.jpg",
      "id_str" : "430022726841925632",
      "id" : 430022726841925632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bfe_ZEbCAAA6yhS.jpg",
      "sizes" : [ {
        "h" : 707,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 707,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/95RA9iH8rc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430022727030689792",
  "text" : "Game day. http:\/\/t.co\/95RA9iH8rc",
  "id" : 430022727030689792,
  "created_at" : "2014-02-02 16:59:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/KH8qY74FOu",
      "expanded_url" : "http:\/\/go.wh.gov\/ze4BKe",
      "display_url" : "go.wh.gov\/ze4BKe"
    } ]
  },
  "geo" : { },
  "id_str" : "429996610328604675",
  "text" : "Obama: \"Wherever I can take steps to expand opportunity for more families on my own, I will.\" http:\/\/t.co\/KH8qY74FOu #OpportunityForAll",
  "id" : 429996610328604675,
  "created_at" : "2014-02-02 15:15:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/429781636029632512\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/5FEIP3Fz3V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfbkHupIAAA-Fl1.jpg",
      "id_str" : "429781635891200000",
      "id" : 429781635891200000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfbkHupIAAA-Fl1.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/5FEIP3Fz3V"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429781636029632512",
  "text" : "Face mask. http:\/\/t.co\/5FEIP3Fz3V",
  "id" : 429781636029632512,
  "created_at" : "2014-02-02 01:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 44, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/6nbp5Fcxp2",
      "expanded_url" : "http:\/\/go.wh.gov\/8PJeCW",
      "display_url" : "go.wh.gov\/8PJeCW"
    } ]
  },
  "geo" : { },
  "id_str" : "429755015054364672",
  "text" : "President Obama's Weekly Address: Restoring #OpportunityForAll \u2192 http:\/\/t.co\/6nbp5Fcxp2",
  "id" : 429755015054364672,
  "created_at" : "2014-02-01 23:15:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 39, 52 ]
    }, {
      "text" : "space",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/yxk1WK0S3q",
      "expanded_url" : "http:\/\/go.wh.gov\/SU4cmn",
      "display_url" : "go.wh.gov\/SU4cmn"
    } ]
  },
  "geo" : { },
  "id_str" : "429743689355653120",
  "text" : "Don't miss out on the 200th edition of #WestWingWeek, with narration from President Obama\u2026and from outer #space \u2192 http:\/\/t.co\/yxk1WK0S3q",
  "id" : 429743689355653120,
  "created_at" : "2014-02-01 22:30:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/YqRGQAgk7U",
      "expanded_url" : "http:\/\/go.wh.gov\/PFBK2y",
      "display_url" : "go.wh.gov\/PFBK2y"
    } ]
  },
  "geo" : { },
  "id_str" : "429731609521053696",
  "text" : "President Obama: \"I\u2019m going to fight\u2026to shift the odds back in favor of more working and middle-class Americans.\" http:\/\/t.co\/YqRGQAgk7U",
  "id" : 429731609521053696,
  "created_at" : "2014-02-01 21:42:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 19, 28 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/BxoPac4lk4",
      "expanded_url" : "http:\/\/usat.ly\/LkMAeg",
      "display_url" : "usat.ly\/LkMAeg"
    } ]
  },
  "geo" : { },
  "id_str" : "429713491578982405",
  "text" : "Worth reading from @USAToday: Repealing the Affordable Care Act would mean higher costs \u2192 http:\/\/t.co\/BxoPac4lk4 #GetCovered",
  "id" : 429713491578982405,
  "created_at" : "2014-02-01 20:30:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/fCcxx7Y7Vc",
      "expanded_url" : "http:\/\/go.wh.gov\/xr9kYd",
      "display_url" : "go.wh.gov\/xr9kYd"
    } ]
  },
  "geo" : { },
  "id_str" : "429697131813679104",
  "text" : "President Obama: \"Job one is more new jobs: Jobs in construction and manufacturing, jobs in innovation and energy.\" http:\/\/t.co\/fCcxx7Y7Vc",
  "id" : 429697131813679104,
  "created_at" : "2014-02-01 19:25:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/bOB4anIZ9W",
      "expanded_url" : "http:\/\/go.wh.gov\/QmqdvV",
      "display_url" : "go.wh.gov\/QmqdvV"
    } ]
  },
  "geo" : { },
  "id_str" : "429634216557432832",
  "text" : "Obama: \"This week, I delivered my State of the Union Address\u2026here\u2019s the three-minute version.\" http:\/\/t.co\/bOB4anIZ9W #OpportunityForAll",
  "id" : 429634216557432832,
  "created_at" : "2014-02-01 15:15:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]