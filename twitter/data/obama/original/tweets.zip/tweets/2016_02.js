Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 6, 13 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/MX2bgbM1we",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/93e0173b-ed9d-486c-991d-c834aa7a2ec0",
      "display_url" : "amp.twimg.com\/v\/93e0173b-ed9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704472986598768640",
  "text" : "Watch @USNavy SEAL Ed Byers share his reactions after receiving the #MedalOfHonor.\nhttps:\/\/t.co\/MX2bgbM1we",
  "id" : 704472986598768640,
  "created_at" : "2016-03-01 01:07:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/3AEGsy5ZTY",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/asked-and-answered-president-obama-commemorates-black-history-month-458819f4dc88#.wo2tyuqox",
      "display_url" : "medium.com\/@WhiteHouse\/as\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704470787269464064",
  "text" : "RT @vj44: \"Change takes time. But change is possible\" - Read @POTUS response to Gretchen Stewart's poignant letter https:\/\/t.co\/3AEGsy5ZTY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 51, 57 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/3AEGsy5ZTY",
        "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/asked-and-answered-president-obama-commemorates-black-history-month-458819f4dc88#.wo2tyuqox",
        "display_url" : "medium.com\/@WhiteHouse\/as\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704467941983522816",
    "text" : "\"Change takes time. But change is possible\" - Read @POTUS response to Gretchen Stewart's poignant letter https:\/\/t.co\/3AEGsy5ZTY",
    "id" : 704467941983522816,
    "created_at" : "2016-03-01 00:47:00 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 704470787269464064,
  "created_at" : "2016-03-01 00:58:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 28, 39 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeekAtTheLabs",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/G2IoAhmtxT",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/02\/27\/engaging-americas-youth-stem-through-hands-experiences-labs-and-communities-across",
      "display_url" : "whitehouse.gov\/blog\/2016\/02\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704448520363835392",
  "text" : "RT @NASA: Watch live as the @WhiteHouse hosts #WeekAtTheLabs kickoff, featuring NASA + other fed labs: https:\/\/t.co\/G2IoAhmtxT https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 18, 29 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/704333179562401792\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/gltQs8aLPV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZLS3pW4AAG9CF.jpg",
        "id_str" : "704333179277205504",
        "id" : 704333179277205504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZLS3pW4AAG9CF.jpg",
        "sizes" : [ {
          "h" : 516,
          "resize" : "fit",
          "w" : 936
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 936
        } ],
        "display_url" : "pic.twitter.com\/gltQs8aLPV"
      } ],
      "hashtags" : [ {
        "text" : "WeekAtTheLabs",
        "indices" : [ 36, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/G2IoAhmtxT",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/02\/27\/engaging-americas-youth-stem-through-hands-experiences-labs-and-communities-across",
        "display_url" : "whitehouse.gov\/blog\/2016\/02\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704333179562401792",
    "text" : "Watch live as the @WhiteHouse hosts #WeekAtTheLabs kickoff, featuring NASA + other fed labs: https:\/\/t.co\/G2IoAhmtxT https:\/\/t.co\/gltQs8aLPV",
    "id" : 704333179562401792,
    "created_at" : "2016-02-29 15:51:30 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 704448520363835392,
  "created_at" : "2016-02-29 23:29:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalLabs",
      "indices" : [ 61, 74 ]
    }, {
      "text" : "MBKLabWeek",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/u8FIWFjzdA",
      "expanded_url" : "http:\/\/1.usa.gov\/1LPIR1G",
      "display_url" : "1.usa.gov\/1LPIR1G"
    } ]
  },
  "geo" : { },
  "id_str" : "704446260846190596",
  "text" : "RT @ENERGY: America's next great scientists are visiting the #NationalLabs this week! &gt;&gt;&gt; https:\/\/t.co\/u8FIWFjzdA #MBKLabWeek https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/704374608317784066\/photo\/1",
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/FjoS6uM7Kp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcZw-VCXIAAMg_b.jpg",
        "id_str" : "704374607831310336",
        "id" : 704374607831310336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcZw-VCXIAAMg_b.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/FjoS6uM7Kp"
      } ],
      "hashtags" : [ {
        "text" : "NationalLabs",
        "indices" : [ 49, 62 ]
      }, {
        "text" : "MBKLabWeek",
        "indices" : [ 111, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/u8FIWFjzdA",
        "expanded_url" : "http:\/\/1.usa.gov\/1LPIR1G",
        "display_url" : "1.usa.gov\/1LPIR1G"
      } ]
    },
    "geo" : { },
    "id_str" : "704374608317784066",
    "text" : "America's next great scientists are visiting the #NationalLabs this week! &gt;&gt;&gt; https:\/\/t.co\/u8FIWFjzdA #MBKLabWeek https:\/\/t.co\/FjoS6uM7Kp",
    "id" : 704374608317784066,
    "created_at" : "2016-02-29 18:36:07 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 704446260846190596,
  "created_at" : "2016-02-29 23:20:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/704435652880961536\/photo\/1",
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/VAVAr3Mx7P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcaodfLW8AE6yrj.jpg",
      "id_str" : "704435616268873729",
      "id" : 704435616268873729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcaodfLW8AE6yrj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VAVAr3Mx7P"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/O5iYU1cW6b",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "704435652880961536",
  "text" : "Some wise words from President Reagan. https:\/\/t.co\/O5iYU1cW6b #SCOTUS https:\/\/t.co\/VAVAr3Mx7P",
  "id" : 704435652880961536,
  "created_at" : "2016-02-29 22:38:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/704422548226875392\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/ZHCQoZaXiU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ccacf-xWAAEHoZu.jpg",
      "id_str" : "704422464969900033",
      "id" : 704422464969900033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ccacf-xWAAEHoZu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZHCQoZaXiU"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/O5iYU1cW6b",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "704422548226875392",
  "text" : "The last time a president's Supreme Court nominee was denied a hearing?\n \n1875.\n\nhttps:\/\/t.co\/O5iYU1cW6b #SCOTUS https:\/\/t.co\/ZHCQoZaXiU",
  "id" : 704422548226875392,
  "created_at" : "2016-02-29 21:46:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704416665157500928",
  "text" : "RT @PressSec: What will @POTUS talk abt in his meeting tomorrow with Sen McConnell &amp; Sen Grassley? Let's start w\/ 1988. #SCOTUS  https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/K2EZyJbXPs",
        "expanded_url" : "http:\/\/www.snappytv.com\/tc\/1466580",
        "display_url" : "snappytv.com\/tc\/1466580"
      } ]
    },
    "geo" : { },
    "id_str" : "704399317990150144",
    "text" : "What will @POTUS talk abt in his meeting tomorrow with Sen McConnell &amp; Sen Grassley? Let's start w\/ 1988. #SCOTUS  https:\/\/t.co\/K2EZyJbXPs",
    "id" : 704399317990150144,
    "created_at" : "2016-02-29 20:14:19 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 704416665157500928,
  "created_at" : "2016-02-29 21:23:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 116, 127 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 56, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704408861260845057",
  "text" : "RT @FLOTUS: From tribal rhythms to freedom songs \u2013 this #BlackHistoryMonth we celebrated these young dancers at the @WhiteHouse.\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 104, 115 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackHistoryMonth",
        "indices" : [ 44, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/weOVSRbadu",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/046668e5-dcc9-4282-b7d5-113cf522fd59",
        "display_url" : "amp.twimg.com\/v\/046668e5-dcc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704408348221788160",
    "text" : "From tribal rhythms to freedom songs \u2013 this #BlackHistoryMonth we celebrated these young dancers at the @WhiteHouse.\nhttps:\/\/t.co\/weOVSRbadu",
    "id" : 704408348221788160,
    "created_at" : "2016-02-29 20:50:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 704408861260845057,
  "created_at" : "2016-02-29 20:52:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "indices" : [ 3, 15 ],
      "id_str" : "3246838764",
      "id" : 3246838764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 37, 54 ]
    }, {
      "text" : "MBK",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704403987882233856",
  "text" : "RT @Broderick44: Happy 2nd Birthday, #MyBrothersKeeper! Read my new post on how #MBK is igniting opportunity nationwide: https:\/\/t.co\/9LW5Z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 20, 37 ]
      }, {
        "text" : "MBK",
        "indices" : [ 63, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/9LW5ZHbdOZ",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/broderick-johnson\/highlighting-2-years-of-s_b_9349538.html",
        "display_url" : "huffingtonpost.com\/broderick-john\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704399818332856321",
    "text" : "Happy 2nd Birthday, #MyBrothersKeeper! Read my new post on how #MBK is igniting opportunity nationwide: https:\/\/t.co\/9LW5ZHbdOZ",
    "id" : 704399818332856321,
    "created_at" : "2016-02-29 20:16:18 +0000",
    "user" : {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "protected" : false,
      "id_str" : "3246838764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610850749086433280\/Y1iGefZo_normal.jpg",
      "id" : 3246838764,
      "verified" : true
    }
  },
  "id" : 704403987882233856,
  "created_at" : "2016-02-29 20:32:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/tVK90PQIcH",
      "expanded_url" : "http:\/\/snpy.tv\/1T4bhfY",
      "display_url" : "snpy.tv\/1T4bhfY"
    } ]
  },
  "geo" : { },
  "id_str" : "704399072946462720",
  "text" : "\u201CEd saved the lives of several teammates\u2014and that hostage.\u201D \u2014@POTUS on #MedalOfHonor recipient Ed Byers https:\/\/t.co\/tVK90PQIcH",
  "id" : 704399072946462720,
  "created_at" : "2016-02-29 20:13:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704392556524675072",
  "text" : "RT @Deese44: .@POTUS will do his constitutional duty &amp; nominate a SCOTUS justice. Senators must do theirs &amp; consider his nominee. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 125, 148 ],
        "url" : "https:\/\/t.co\/uBKqX4WKOs",
        "expanded_url" : "http:\/\/wh.gov\/scotus",
        "display_url" : "wh.gov\/scotus"
      } ]
    },
    "geo" : { },
    "id_str" : "704358060995665920",
    "text" : ".@POTUS will do his constitutional duty &amp; nominate a SCOTUS justice. Senators must do theirs &amp; consider his nominee. https:\/\/t.co\/uBKqX4WKOs",
    "id" : 704358060995665920,
    "created_at" : "2016-02-29 17:30:22 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 704392556524675072,
  "created_at" : "2016-02-29 19:47:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 26, 33 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/yCBd6n21gA",
      "expanded_url" : "http:\/\/snpy.tv\/1T4bb8n",
      "display_url" : "snpy.tv\/1T4bb8n"
    } ]
  },
  "geo" : { },
  "id_str" : "704388684657913856",
  "text" : "Watch as @POTUS describes @USNavy SEAL Ed Byers' harrowing mission that earned him the #MedalOfHonor. https:\/\/t.co\/yCBd6n21gA",
  "id" : 704388684657913856,
  "created_at" : "2016-02-29 19:32:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 1, 17 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInSpace",
      "indices" : [ 20, 32 ]
    }, {
      "text" : "LeapDay",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/P2FA7nOBDk",
      "expanded_url" : "http:\/\/go.nasa.gov\/1oJLgFQ",
      "display_url" : "go.nasa.gov\/1oJLgFQ"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/3YGVbNpBRN",
      "expanded_url" : "https:\/\/twitter.com\/StationCDRKelly\/status\/704331894637199360",
      "display_url" : "twitter.com\/StationCDRKell\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704377607199055873",
  "text" : ".@StationCDRKelly's #YearInSpace = One giant #LeapDay for mankind \u2192 https:\/\/t.co\/P2FA7nOBDk https:\/\/t.co\/3YGVbNpBRN",
  "id" : 704377607199055873,
  "created_at" : "2016-02-29 18:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 55, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/4iPhoFQzDE",
      "expanded_url" : "http:\/\/snpy.tv\/1RAkNnQ",
      "display_url" : "snpy.tv\/1RAkNnQ"
    } ]
  },
  "geo" : { },
  "id_str" : "704352417266139136",
  "text" : "Until today, just five Navy SEALs had been awarded the #MedalOfHonor.\nEd Byers just became the sixth. https:\/\/t.co\/4iPhoFQzDE",
  "id" : 704352417266139136,
  "created_at" : "2016-02-29 17:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/yCBd6n21gA",
      "expanded_url" : "http:\/\/snpy.tv\/1T4bb8n",
      "display_url" : "snpy.tv\/1T4bb8n"
    } ]
  },
  "geo" : { },
  "id_str" : "704348614382977025",
  "text" : "Thank you, Ed Byers.\n\n11 deployments.\n9 combat tours.\n5 Bronze Stars with valor.\n2 Purple Hearts.\n#MedalOfHonor\nhttps:\/\/t.co\/yCBd6n21gA",
  "id" : 704348614382977025,
  "created_at" : "2016-02-29 16:52:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 36, 43 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "US Navy SEALs",
      "screen_name" : "us_navyseals",
      "indices" : [ 111, 124 ],
      "id_str" : "106597684",
      "id" : 106597684
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalofHonor",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704345746758176769",
  "text" : "RT @DeptofDefense: .@POTUS presents @USNavy Senior Chief Petty Officer Edward Byers Jr with the #MedalofHonor. @us_navyseals https:\/\/t.co\/E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 17, 24 ],
        "id_str" : "54885400",
        "id" : 54885400
      }, {
        "name" : "US Navy SEALs",
        "screen_name" : "us_navyseals",
        "indices" : [ 92, 105 ],
        "id_str" : "106597684",
        "id" : 106597684
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalofHonor",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/EitA1qFMfi",
        "expanded_url" : "http:\/\/snpy.tv\/1QGJfAL",
        "display_url" : "snpy.tv\/1QGJfAL"
      } ]
    },
    "geo" : { },
    "id_str" : "704345527643541504",
    "text" : ".@POTUS presents @USNavy Senior Chief Petty Officer Edward Byers Jr with the #MedalofHonor. @us_navyseals https:\/\/t.co\/EitA1qFMfi",
    "id" : 704345527643541504,
    "created_at" : "2016-02-29 16:40:34 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 704345746758176769,
  "created_at" : "2016-02-29 16:41:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 95, 102 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704342569526755328",
  "text" : "\u201CEd saved the lives of several teammates\u2014and that hostage.\u201D \u2014@POTUS on #MedalOfHonor recipient @USNavy Senior Chief Ed Byers",
  "id" : 704342569526755328,
  "created_at" : "2016-02-29 16:28:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 30, 37 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704341151235469312",
  "text" : "\"In the entire history of the @USNavy SEALs, just five have been awarded the #MedalOfHonor...And now, a sixth. Byers.\" \u2014@POTUS",
  "id" : 704341151235469312,
  "created_at" : "2016-02-29 16:23:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 44, 51 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/K57x5Qfsmk",
      "expanded_url" : "http:\/\/go.wh.gov\/ejy9un",
      "display_url" : "go.wh.gov\/ejy9un"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ec6zSJnYnp",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/6feb8f22-fef3-4783-a35f-01f53158770f",
      "display_url" : "amp.twimg.com\/v\/6feb8f22-fef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "704339394111516672",
  "text" : "Tune in: @POTUS awards the #MedalOfHonor to @USNavy SEAL Senior Chief Edward Byers \u2192 https:\/\/t.co\/K57x5Qfsmk https:\/\/t.co\/ec6zSJnYnp",
  "id" : 704339394111516672,
  "created_at" : "2016-02-29 16:16:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 3, 10 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 100, 111 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USNavy",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "MedalOfHonor",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704327418849464324",
  "text" : "RT @USNavy: Watch as this #USNavy SEAL describes the mission he'll receive the #MedalOfHonor for at @WhiteHouse today\nhttps:\/\/t.co\/CceaANzP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 88, 99 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USNavy",
        "indices" : [ 14, 21 ]
      }, {
        "text" : "MedalOfHonor",
        "indices" : [ 67, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/CceaANzPHr",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/6feb8f22-fef3-4783-a35f-01f53158770f",
        "display_url" : "amp.twimg.com\/v\/6feb8f22-fef\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704290903913926656",
    "text" : "Watch as this #USNavy SEAL describes the mission he'll receive the #MedalOfHonor for at @WhiteHouse today\nhttps:\/\/t.co\/CceaANzPHr",
    "id" : 704290903913926656,
    "created_at" : "2016-02-29 13:03:31 +0000",
    "user" : {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "protected" : false,
      "id_str" : "54885400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785776641066708992\/nEqdAKde_normal.jpg",
      "id" : 54885400,
      "verified" : true
    }
  },
  "id" : 704327418849464324,
  "created_at" : "2016-02-29 15:28:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 92, 104 ],
      "id_str" : "133880286",
      "id" : 133880286
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/704178816042848256\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/dIp3G8KyZZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcW-IbkWEAA-59V.jpg",
      "id_str" : "704177968801779712",
      "id" : 704177968801779712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcW-IbkWEAA-59V.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dIp3G8KyZZ"
    } ],
    "hashtags" : [ {
      "text" : "Oscars",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704178816042848256",
  "text" : "Climate change \"is the most urgent threat facing our entire species.\"\n\nRT if you agree with @LeoDiCaprio. #Oscars https:\/\/t.co\/dIp3G8KyZZ",
  "id" : 704178816042848256,
  "created_at" : "2016-02-29 05:38:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 85, 97 ],
      "id_str" : "133880286",
      "id" : 133880286
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/704175770453860352\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/lWdAWmlR3m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcW8Cm3WEAAbZIf.jpg",
      "id_str" : "704175669731790848",
      "id" : 704175669731790848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcW8Cm3WEAAbZIf.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/lWdAWmlR3m"
    } ],
    "hashtags" : [ {
      "text" : "Oscars",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704175770453860352",
  "text" : "\"A world that we collectively felt in 2015 as the hottest year in recorded history\" \u2014@LeoDiCaprio #Oscars https:\/\/t.co\/lWdAWmlR3m",
  "id" : 704175770453860352,
  "created_at" : "2016-02-29 05:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonardo DiCaprio",
      "screen_name" : "LeoDiCaprio",
      "indices" : [ 79, 91 ],
      "id_str" : "133880286",
      "id" : 133880286
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/704171403201765376\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/AHfflR6VkN",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcW3plYWwAIj1qm.jpg",
      "id_str" : "704170841790136322",
      "id" : 704170841790136322,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcW3plYWwAIj1qm.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AHfflR6VkN"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "Oscars",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704171403201765376",
  "text" : "\u201CClimate change is real...let's not take this planet for granted.\"\n\nThank you, @LeoDiCaprio. #ActOnClimate #Oscars https:\/\/t.co\/AHfflR6VkN",
  "id" : 704171403201765376,
  "created_at" : "2016-02-29 05:08:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 16, 19 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "#CountryOfKindness",
      "screen_name" : "ladygaga",
      "indices" : [ 42, 51 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/704162155982151680\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/4XP8O4XjM1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcWvp-pXIAIgWpa.jpg",
      "id_str" : "704162052479328258",
      "id" : 704162052479328258,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcWvp-pXIAIgWpa.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 3840
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/4XP8O4XjM1"
    } ],
    "hashtags" : [ {
      "text" : "Oscars",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "ItsOnUs",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704164588476956672",
  "text" : "RT @VPLive: The @VP applauds backstage as @LadyGaga performs at tonight's #Oscars. #ItsOnUs https:\/\/t.co\/4XP8O4XjM1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 4, 7 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "#CountryOfKindness",
        "screen_name" : "ladygaga",
        "indices" : [ 30, 39 ],
        "id_str" : "14230524",
        "id" : 14230524
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/704162155982151680\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/4XP8O4XjM1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcWvp-pXIAIgWpa.jpg",
        "id_str" : "704162052479328258",
        "id" : 704162052479328258,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcWvp-pXIAIgWpa.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2560,
          "resize" : "fit",
          "w" : 3840
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/4XP8O4XjM1"
      } ],
      "hashtags" : [ {
        "text" : "Oscars",
        "indices" : [ 62, 69 ]
      }, {
        "text" : "ItsOnUs",
        "indices" : [ 71, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704162155982151680",
    "text" : "The @VP applauds backstage as @LadyGaga performs at tonight's #Oscars. #ItsOnUs https:\/\/t.co\/4XP8O4XjM1",
    "id" : 704162155982151680,
    "created_at" : "2016-02-29 04:31:55 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 704164588476956672,
  "created_at" : "2016-02-29 04:41:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "#CountryOfKindness",
      "screen_name" : "ladygaga",
      "indices" : [ 36, 45 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704158630602481664",
  "text" : "RT @VP: Proud to stand by my friend @LadyGaga tonight. Pure courage that inspires, challenges us all. #ItsOnUs. All of us. https:\/\/t.co\/1ee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#CountryOfKindness",
        "screen_name" : "ladygaga",
        "indices" : [ 28, 37 ],
        "id_str" : "14230524",
        "id" : 14230524
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/704158331032707072\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/1eee3v0Xd2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcWsRUHWwAIUX0-.jpg",
        "id_str" : "704158330210664450",
        "id" : 704158330210664450,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcWsRUHWwAIUX0-.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2560,
          "resize" : "fit",
          "w" : 3840
        } ],
        "display_url" : "pic.twitter.com\/1eee3v0Xd2"
      } ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704158331032707072",
    "text" : "Proud to stand by my friend @LadyGaga tonight. Pure courage that inspires, challenges us all. #ItsOnUs. All of us. https:\/\/t.co\/1eee3v0Xd2",
    "id" : 704158331032707072,
    "created_at" : "2016-02-29 04:16:43 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 704158630602481664,
  "created_at" : "2016-02-29 04:17:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 129, 132 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704158346404892672",
  "text" : "RT @VPLive: \"Change the culture so that no abused woman or man...ever feels like they have to ask themselves, 'What did I do?'\" -@VP at #Os\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 117, 120 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oscars",
        "indices" : [ 124, 131 ]
      }, {
        "text" : "ItsOnUs",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704157236487176192",
    "text" : "\"Change the culture so that no abused woman or man...ever feels like they have to ask themselves, 'What did I do?'\" -@VP at #Oscars #ItsOnUs",
    "id" : 704157236487176192,
    "created_at" : "2016-02-29 04:12:22 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 704158346404892672,
  "created_at" : "2016-02-29 04:16:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 19, 22 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "xoxo, Joanne",
      "screen_name" : "ladygaga",
      "indices" : [ 29, 38 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 40, 48 ]
    }, {
      "text" : "Oscars",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/C1uQt5vVu3",
      "expanded_url" : "http:\/\/itsonus.org",
      "display_url" : "itsonus.org"
    } ]
  },
  "geo" : { },
  "id_str" : "704157311162576898",
  "text" : "RT @vj44: Proud of @VP &amp; @ladygaga: #ItsOnUs to stand with survivors of sexual assault  https:\/\/t.co\/C1uQt5vVu3 #Oscars",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 9, 12 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "xoxo, Joanne",
        "screen_name" : "ladygaga",
        "indices" : [ 19, 28 ],
        "id_str" : "14230524",
        "id" : 14230524
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 30, 38 ]
      }, {
        "text" : "Oscars",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/C1uQt5vVu3",
        "expanded_url" : "http:\/\/itsonus.org",
        "display_url" : "itsonus.org"
      } ]
    },
    "geo" : { },
    "id_str" : "704157164160557058",
    "text" : "Proud of @VP &amp; @ladygaga: #ItsOnUs to stand with survivors of sexual assault  https:\/\/t.co\/C1uQt5vVu3 #Oscars",
    "id" : 704157164160557058,
    "created_at" : "2016-02-29 04:12:05 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 704157311162576898,
  "created_at" : "2016-02-29 04:12:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oscars",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Di7cjD4xbh",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "704124681331335173",
  "text" : "RT @VP: Honored to introduce someone special at tonight's #Oscars. Powerful message. Join us: https:\/\/t.co\/Di7cjD4xbh https:\/\/t.co\/LsDPSmi8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/704124065515233280\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/LsDPSmi8n7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcWNGztW4AAUjlk.jpg",
        "id_str" : "704124064852533248",
        "id" : 704124064852533248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcWNGztW4AAUjlk.jpg",
        "sizes" : [ {
          "h" : 1043,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 611,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1484,
          "resize" : "fit",
          "w" : 1457
        } ],
        "display_url" : "pic.twitter.com\/LsDPSmi8n7"
      } ],
      "hashtags" : [ {
        "text" : "Oscars",
        "indices" : [ 50, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/Di7cjD4xbh",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      } ]
    },
    "geo" : { },
    "id_str" : "704124065515233280",
    "text" : "Honored to introduce someone special at tonight's #Oscars. Powerful message. Join us: https:\/\/t.co\/Di7cjD4xbh https:\/\/t.co\/LsDPSmi8n7",
    "id" : 704124065515233280,
    "created_at" : "2016-02-29 02:00:33 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 704124681331335173,
  "created_at" : "2016-02-29 02:03:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 16, 19 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "xoxo, Joanne",
      "screen_name" : "ladygaga",
      "indices" : [ 35, 44 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oscars",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/SRPnGzC9dM",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "704099266323677184",
  "text" : "RT @VPLive: The @VP will introduce @LadyGaga at tonight's #Oscars. Stand with them and take the pledge: https:\/\/t.co\/SRPnGzC9dM https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 4, 7 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "xoxo, Joanne",
        "screen_name" : "ladygaga",
        "indices" : [ 23, 32 ],
        "id_str" : "14230524",
        "id" : 14230524
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/704097208778489856\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/hRnIEeWhik",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcV0aFBWwAE3_xz.jpg",
        "id_str" : "704096908126633985",
        "id" : 704096908126633985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcV0aFBWwAE3_xz.jpg",
        "sizes" : [ {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 686,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1028,
          "resize" : "fit",
          "w" : 1534
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hRnIEeWhik"
      } ],
      "hashtags" : [ {
        "text" : "Oscars",
        "indices" : [ 46, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/SRPnGzC9dM",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      } ]
    },
    "geo" : { },
    "id_str" : "704097208778489856",
    "text" : "The @VP will introduce @LadyGaga at tonight's #Oscars. Stand with them and take the pledge: https:\/\/t.co\/SRPnGzC9dM https:\/\/t.co\/hRnIEeWhik",
    "id" : 704097208778489856,
    "created_at" : "2016-02-29 00:13:50 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 704099266323677184,
  "created_at" : "2016-02-29 00:22:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 43, 46 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oscars",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704086827683201025",
  "text" : "RT @VPLive: A one-stop shop for all things @VP. Follow for ongoing behind-the-scenes coverage -- including of tonight's #Oscars! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 31, 34 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/704086155105423360\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/5YImeHjbI4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcVqoFdW4AAukAP.jpg",
        "id_str" : "704086153645973504",
        "id" : 704086153645973504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcVqoFdW4AAukAP.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1511,
          "resize" : "fit",
          "w" : 2015
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5YImeHjbI4"
      } ],
      "hashtags" : [ {
        "text" : "Oscars",
        "indices" : [ 108, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704086155105423360",
    "text" : "A one-stop shop for all things @VP. Follow for ongoing behind-the-scenes coverage -- including of tonight's #Oscars! https:\/\/t.co\/5YImeHjbI4",
    "id" : 704086155105423360,
    "created_at" : "2016-02-28 23:29:55 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 704086827683201025,
  "created_at" : "2016-02-28 23:32:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/RnXlQ7rsWf",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "704029573386645504",
  "text" : "\"We\u2019ll continue to stay vigilant here at home, including for lone actors or small groups of terrorists\" \u2014@POTUS: https:\/\/t.co\/RnXlQ7rsWf",
  "id" : 704029573386645504,
  "created_at" : "2016-02-28 19:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/RnXlQ7rsWf",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "704014556960411648",
  "text" : "\"We\u2019ll continue discrediting the ideology that ISIL uses to radicalize...especially online\" \u2014@POTUS: https:\/\/t.co\/RnXlQ7rsWf",
  "id" : 704014556960411648,
  "created_at" : "2016-02-28 18:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/RnXlQ7rsWf",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "703999387416940545",
  "text" : "\"Beyond Syria and Iraq, we continue to use the full range of our tools to go after ISIL\" \u2014@POTUS: https:\/\/t.co\/RnXlQ7rsWf",
  "id" : 703999387416940545,
  "created_at" : "2016-02-28 17:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "It's On Us",
      "screen_name" : "ItsOnUs",
      "indices" : [ 3, 11 ],
      "id_str" : "2840712124",
      "id" : 2840712124
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 14, 17 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "#CountryOfKindness",
      "screen_name" : "ladygaga",
      "indices" : [ 24, 33 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oscars",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "ItsOnUs",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/n18cRwN3k3",
      "expanded_url" : "http:\/\/itsonus.org\/#pledge",
      "display_url" : "itsonus.org\/#pledge"
    } ]
  },
  "geo" : { },
  "id_str" : "703997027299016704",
  "text" : "RT @ItsOnUs: .@VP &amp; @ladygaga are standing with survivors at the #Oscars. Join the #ItsOnUs movement: https:\/\/t.co\/n18cRwN3k3 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 1, 4 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "#CountryOfKindness",
        "screen_name" : "ladygaga",
        "indices" : [ 11, 20 ],
        "id_str" : "14230524",
        "id" : 14230524
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ItsOnUs\/status\/703635013422731264\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/HxN3OJmqqW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcPQUQSWIAA786N.jpg",
        "id_str" : "703635013187805184",
        "id" : 703635013187805184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcPQUQSWIAA786N.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HxN3OJmqqW"
      } ],
      "hashtags" : [ {
        "text" : "Oscars",
        "indices" : [ 56, 63 ]
      }, {
        "text" : "ItsOnUs",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/n18cRwN3k3",
        "expanded_url" : "http:\/\/itsonus.org\/#pledge",
        "display_url" : "itsonus.org\/#pledge"
      } ]
    },
    "geo" : { },
    "id_str" : "703635013422731264",
    "text" : ".@VP &amp; @ladygaga are standing with survivors at the #Oscars. Join the #ItsOnUs movement: https:\/\/t.co\/n18cRwN3k3 https:\/\/t.co\/HxN3OJmqqW",
    "id" : 703635013422731264,
    "created_at" : "2016-02-27 17:37:14 +0000",
    "user" : {
      "name" : "It's On Us",
      "screen_name" : "ItsOnUs",
      "protected" : false,
      "id_str" : "2840712124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666281106770173952\/tPVjIzos_normal.png",
      "id" : 2840712124,
      "verified" : false
    }
  },
  "id" : 703997027299016704,
  "created_at" : "2016-02-28 17:35:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/RnXlQ7rsWf",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "703984276304326656",
  "text" : "\"There will be absolutely no cease-fire in our fight against ISIL. We\u2019ll remain relentless.\" \u2014@POTUS: https:\/\/t.co\/RnXlQ7rsWf",
  "id" : 703984276304326656,
  "created_at" : "2016-02-28 16:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/RnXlQ79S4H",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "703969114386276353",
  "text" : "\"A cessation of hostilities in the civil war is scheduled to take effect this weekend.\" \u2014@POTUS on Syria: https:\/\/t.co\/RnXlQ79S4H",
  "id" : 703969114386276353,
  "created_at" : "2016-02-28 15:44:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 88, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/1aORexoL6Z",
      "expanded_url" : "http:\/\/snpy.tv\/212KDn8",
      "display_url" : "snpy.tv\/212KDn8"
    } ]
  },
  "geo" : { },
  "id_str" : "703756980805095424",
  "text" : "Watch 106-year-old Virginia McLaurin share her story before meeting @POTUS to celebrate #BlackHistoryMonth: https:\/\/t.co\/1aORexoL6Z",
  "id" : 703756980805095424,
  "created_at" : "2016-02-28 01:41:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/RnXlQ7rsWf",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "703686165279281152",
  "text" : "\"The only way to deal ISIL a lasting defeat is to end the civil war and chaos in Syria.\" \u2014@POTUS: https:\/\/t.co\/RnXlQ7rsWf",
  "id" : 703686165279281152,
  "created_at" : "2016-02-27 21:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/RnXlQ7rsWf",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "703671085879787520",
  "text" : "\"ISIL\u2019s territory is shrinking, there are fewer ISIL fighters on the battlefield, &amp; it\u2019s harder for them to recruit\" https:\/\/t.co\/RnXlQ7rsWf",
  "id" : 703671085879787520,
  "created_at" : "2016-02-27 20:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/RnXlQ7rsWf",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "703655986167328769",
  "text" : "\"As we bomb its oil infrastructure, ISIL\u2019s been forced to slash the salaries of its fighters.\" \u2014@POTUS: https:\/\/t.co\/RnXlQ7rsWf",
  "id" : 703655986167328769,
  "created_at" : "2016-02-27 19:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/RnXlQ7rsWf",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "703640937109417984",
  "text" : "\"We continue to go after ISIL leaders and commanders\u2014taking them out, day in, day out\" \u2014@POTUS: https:\/\/t.co\/RnXlQ7rsWf",
  "id" : 703640937109417984,
  "created_at" : "2016-02-27 18:00:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/RnXlQ79S4H",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "703630717130051586",
  "text" : "\"Every day, our air campaign\u2014more than 10,000 strikes so far\u2014continues to destroy ISIL forces.\" \u2014@POTUS: https:\/\/t.co\/RnXlQ79S4H",
  "id" : 703630717130051586,
  "created_at" : "2016-02-27 17:20:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/RnXlQ79S4H",
      "expanded_url" : "http:\/\/go.wh.gov\/EffhjC",
      "display_url" : "go.wh.gov\/EffhjC"
    } ]
  },
  "geo" : { },
  "id_str" : "703618715892506624",
  "text" : "\"This week, I directed my team to continue accelerating our campaign on all fronts.\" \u2014@POTUS on fighting ISIL: https:\/\/t.co\/RnXlQ79S4H",
  "id" : 703618715892506624,
  "created_at" : "2016-02-27 16:32:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703613420638216192",
  "text" : "RT @Deese44: Warren Buffett: supporting Paris \"will make great sense, both for the environment and for Berkshire's economics.\" https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/VS5BrWFaT3",
        "expanded_url" : "http:\/\/bit.ly\/1XR8KFp",
        "display_url" : "bit.ly\/1XR8KFp"
      } ]
    },
    "geo" : { },
    "id_str" : "703606952392302592",
    "text" : "Warren Buffett: supporting Paris \"will make great sense, both for the environment and for Berkshire's economics.\" https:\/\/t.co\/VS5BrWFaT3",
    "id" : 703606952392302592,
    "created_at" : "2016-02-27 15:45:44 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 703613420638216192,
  "created_at" : "2016-02-27 16:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RayCharlesTribute",
      "indices" : [ 15, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/XhphyLrcRI",
      "expanded_url" : "http:\/\/snpy.tv\/1KMfcLX",
      "display_url" : "snpy.tv\/1KMfcLX"
    } ]
  },
  "geo" : { },
  "id_str" : "703395409733943296",
  "text" : "What'd he say? #RayCharlesTribute https:\/\/t.co\/XhphyLrcRI",
  "id" : 703395409733943296,
  "created_at" : "2016-02-27 01:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Demi Lovato",
      "screen_name" : "ddlovato",
      "indices" : [ 38, 47 ],
      "id_str" : "21111883",
      "id" : 21111883
    }, {
      "name" : "Usher Raymond IV",
      "screen_name" : "Usher",
      "indices" : [ 49, 55 ],
      "id_str" : "40908929",
      "id" : 40908929
    }, {
      "name" : "Yolanda Adams",
      "screen_name" : "YolandaAdams",
      "indices" : [ 57, 70 ],
      "id_str" : "56869426",
      "id" : 56869426
    }, {
      "name" : "Leon Bridges",
      "screen_name" : "leonbridges",
      "indices" : [ 72, 84 ],
      "id_str" : "46597488",
      "id" : 46597488
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/703379854021025792\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/pndk28jdvF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcLoEiZWwAAsO9g.jpg",
      "id_str" : "703379656473493504",
      "id" : 703379656473493504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcLoEiZWwAAsO9g.jpg",
      "sizes" : [ {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/pndk28jdvF"
    } ],
    "hashtags" : [ {
      "text" : "RayCharlesTribute",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703379854021025792",
  "text" : ".@POTUS on track featuring Sam Moore, @ddlovato, @Usher, @YolandaAdams, @LeonBridges and more. #RayCharlesTribute https:\/\/t.co\/pndk28jdvF",
  "id" : 703379854021025792,
  "created_at" : "2016-02-27 00:43:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 81, 85 ],
      "id_str" : "12133382",
      "id" : 12133382
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/703375544843239424\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/xcwq6oVvZI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcLkNUDW8AA7vZa.jpg",
      "id_str" : "703375409195446272",
      "id" : 703375409195446272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcLkNUDW8AA7vZa.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xcwq6oVvZI"
    } ],
    "hashtags" : [ {
      "text" : "RayCharlesTribute",
      "indices" : [ 87, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703375544843239424",
  "text" : ".@POTUS is back for his encore. Don't miss him take the mic tonight at 9pm ET on @PBS. #RayCharlesTribute https:\/\/t.co\/xcwq6oVvZI",
  "id" : 703375544843239424,
  "created_at" : "2016-02-27 00:26:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kim Kardashian West",
      "screen_name" : "KimKardashian",
      "indices" : [ 3, 17 ],
      "id_str" : "25365536",
      "id" : 25365536
    }, {
      "name" : "Michelle Obama",
      "screen_name" : "MichelleObama",
      "indices" : [ 29, 43 ],
      "id_str" : "409486555",
      "id" : 409486555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpeneBooks",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703372633396490240",
  "text" : "RT @KimKardashian: Thank you @MichelleObama and #OpeneBooks for giving children access to books they need to learn and dream! https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michelle Obama",
        "screen_name" : "MichelleObama",
        "indices" : [ 10, 24 ],
        "id_str" : "409486555",
        "id" : 409486555
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpeneBooks",
        "indices" : [ 29, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/bTNATKbo2Y",
        "expanded_url" : "http:\/\/bit.ly\/1p5CIcT",
        "display_url" : "bit.ly\/1p5CIcT"
      } ]
    },
    "geo" : { },
    "id_str" : "702659101650587648",
    "text" : "Thank you @MichelleObama and #OpeneBooks for giving children access to books they need to learn and dream! https:\/\/t.co\/bTNATKbo2Y",
    "id" : 702659101650587648,
    "created_at" : "2016-02-25 00:59:19 +0000",
    "user" : {
      "name" : "Kim Kardashian West",
      "screen_name" : "KimKardashian",
      "protected" : false,
      "id_str" : "25365536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767526519098843136\/ck3mOeCw_normal.jpg",
      "id" : 25365536,
      "verified" : true
    }
  },
  "id" : 703372633396490240,
  "created_at" : "2016-02-27 00:14:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703361373275865088",
  "text" : "RT @POTUS: Isiah, I'm so proud of you. Your kindness and willingness to help others is why I'm so hopeful for our future. https:\/\/t.co\/RakS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/RakSNxe7rk",
        "expanded_url" : "http:\/\/huff.to\/21u24PG",
        "display_url" : "huff.to\/21u24PG"
      } ]
    },
    "geo" : { },
    "id_str" : "703359876483977217",
    "text" : "Isiah, I'm so proud of you. Your kindness and willingness to help others is why I'm so hopeful for our future. https:\/\/t.co\/RakSNxe7rk",
    "id" : 703359876483977217,
    "created_at" : "2016-02-26 23:23:57 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 703361373275865088,
  "created_at" : "2016-02-26 23:29:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leon Bridges",
      "screen_name" : "leonbridges",
      "indices" : [ 1, 13 ],
      "id_str" : "46597488",
      "id" : 46597488
    }, {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 54, 58 ],
      "id_str" : "12133382",
      "id" : 12133382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RayCharlesTribute",
      "indices" : [ 66, 84 ]
    }, {
      "text" : "BlackHistoryMonth",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/MJTHeqE0pK",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/95590123-3e79-4e21-b011-bb541abce488",
      "display_url" : "amp.twimg.com\/v\/95590123-3e7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703336910903574529",
  "text" : ".@LeonBridges: That's soul, man. Tune in at 9pm ET on @PBS to the #RayCharlesTribute for #BlackHistoryMonth.\nhttps:\/\/t.co\/MJTHeqE0pK",
  "id" : 703336910903574529,
  "created_at" : "2016-02-26 21:52:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/p0WfxMDMEB",
      "expanded_url" : "http:\/\/snpy.tv\/1WOyd0Y",
      "display_url" : "snpy.tv\/1WOyd0Y"
    } ]
  },
  "geo" : { },
  "id_str" : "703316146624307200",
  "text" : "FACT: Clean energy is providing thousands of jobs for veterans, including those who served in Iraq and Afghanistan. https:\/\/t.co\/p0WfxMDMEB",
  "id" : 703316146624307200,
  "created_at" : "2016-02-26 20:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ESpewxu09F",
      "expanded_url" : "http:\/\/snpy.tv\/1KQK1iI",
      "display_url" : "snpy.tv\/1KQK1iI"
    } ]
  },
  "geo" : { },
  "id_str" : "703305319229857792",
  "text" : "Our progress on clean energy:\n\nSolar power: \u2191 more than 30x\nWind power: \u2191 threefold\nOil imports: \u2193 nearly 60%\nhttps:\/\/t.co\/ESpewxu09F",
  "id" : 703305319229857792,
  "created_at" : "2016-02-26 19:47:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/703296536998969344\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/9wDiwoQWBU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcKcYp_WIAAvxzQ.jpg",
      "id_str" : "703296439225556992",
      "id" : 703296439225556992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcKcYp_WIAAvxzQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9wDiwoQWBU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Lz5tnqoYPh",
      "expanded_url" : "http:\/\/go.wh.gov\/ARRA",
      "display_url" : "go.wh.gov\/ARRA"
    } ]
  },
  "geo" : { },
  "id_str" : "703296536998969344",
  "text" : "\"I\u2019ve never been more optimistic that we\u2019ll get where we need to go.\" \u2014@POTUS: https:\/\/t.co\/Lz5tnqoYPh https:\/\/t.co\/9wDiwoQWBU",
  "id" : 703296536998969344,
  "created_at" : "2016-02-26 19:12:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/703294880592830464\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/dUXZLJZOHz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKa6f1WAAAGWNb.jpg",
      "id_str" : "703294821591547904",
      "id" : 703294821591547904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKa6f1WAAAGWNb.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dUXZLJZOHz"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703294880592830464",
  "text" : "\"We\u2019ve cut our net imports of foreign oil by nearly 60% percent.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/dUXZLJZOHz",
  "id" : 703294880592830464,
  "created_at" : "2016-02-26 19:05:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703294571636252672",
  "text" : "RT @FactsOnClimate: \"Solar jobs are growing 12 times faster than other jobs and they pay better than average.\" \u2014@POTUS #ActOnClimate https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 92, 98 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/703294538295746560\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/T91aLjhjJz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcKao4mWIAEpF7D.jpg",
        "id_str" : "703294519001882625",
        "id" : 703294519001882625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcKao4mWIAEpF7D.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/T91aLjhjJz"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703294538295746560",
    "text" : "\"Solar jobs are growing 12 times faster than other jobs and they pay better than average.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/T91aLjhjJz",
    "id" : 703294538295746560,
    "created_at" : "2016-02-26 19:04:19 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 703294571636252672,
  "created_at" : "2016-02-26 19:04:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/703294221390848000\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/9D6ctizWYE",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKaTGMW8AAIhnB.jpg",
      "id_str" : "703294144693858304",
      "id" : 703294144693858304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKaTGMW8AAIhnB.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9D6ctizWYE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703294221390848000",
  "text" : "\"We made the largest single investment in clean energy in our history.\" \u2014@POTUS\n\nHere's how it paid off. https:\/\/t.co\/9D6ctizWYE",
  "id" : 703294221390848000,
  "created_at" : "2016-02-26 19:03:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/703293590399803393\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/oreZo1ymsF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcKZwWDWoAA3c-i.jpg",
      "id_str" : "703293547655634944",
      "id" : 703293547655634944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcKZwWDWoAA3c-i.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/oreZo1ymsF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Lz5tnqoYPh",
      "expanded_url" : "http:\/\/go.wh.gov\/ARRA",
      "display_url" : "go.wh.gov\/ARRA"
    } ]
  },
  "geo" : { },
  "id_str" : "703293590399803393",
  "text" : "\"We wanted to build a new foundation for a stronger, smarter economy.\" \u2014@POTUS: https:\/\/t.co\/Lz5tnqoYPh https:\/\/t.co\/oreZo1ymsF",
  "id" : 703293590399803393,
  "created_at" : "2016-02-26 19:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/703292227943010304\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/yZodI2QOKD",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKYi6RW4AAYFtb.jpg",
      "id_str" : "703292217348251648",
      "id" : 703292217348251648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKYi6RW4AAYFtb.jpg",
      "sizes" : [ {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yZodI2QOKD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703292227943010304",
  "text" : "\u201CAnyone who says we\u2019re not better off today than we were seven years ago, they\u2019re not leveling with you.\u201D \u2014@POTUS https:\/\/t.co\/yZodI2QOKD",
  "id" : 703292227943010304,
  "created_at" : "2016-02-26 18:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/703291950515032065\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/Y1U4wqqZES",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKYQLbW4AAVWRk.jpg",
      "id_str" : "703291895536082944",
      "id" : 703291895536082944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKYQLbW4AAVWRk.jpg",
      "sizes" : [ {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Y1U4wqqZES"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Lz5tnqoYPh",
      "expanded_url" : "http:\/\/go.wh.gov\/ARRA",
      "display_url" : "go.wh.gov\/ARRA"
    } ]
  },
  "geo" : { },
  "id_str" : "703291950515032065",
  "text" : "\u201CWe\u2019ve cut the unemployment rate by more than half\" \u2014@POTUS: https:\/\/t.co\/Lz5tnqoYPh https:\/\/t.co\/Y1U4wqqZES",
  "id" : 703291950515032065,
  "created_at" : "2016-02-26 18:54:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/703291699913687040\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/45eRYwbulc",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKX-jDWoAAsetZ.jpg",
      "id_str" : "703291592640208896",
      "id" : 703291592640208896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKX-jDWoAAsetZ.jpg",
      "sizes" : [ {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/45eRYwbulc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703291699913687040",
  "text" : "\"Businesses like yours have created jobs 71 straight months\u201414 million in all\" \u2014@POTUS in Jacksonville https:\/\/t.co\/45eRYwbulc",
  "id" : 703291699913687040,
  "created_at" : "2016-02-26 18:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 92, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703291085049700353",
  "text" : "\"Anyone who says they want to keep the American people safe has to care about this\" \u2014@POTUS #StopGunViolence",
  "id" : 703291085049700353,
  "created_at" : "2016-02-26 18:50:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 114, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703290988853338112",
  "text" : "\"There are two more communities in America that are torn apart by grief...we cannot become numb to this.\" \u2014@POTUS #StopGunViolence",
  "id" : 703290988853338112,
  "created_at" : "2016-02-26 18:50:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703290657281085441",
  "text" : "\"Yesterday, a gunman murdered three people and injured 14 others in Hesston, Kansas.\" \u2014@POTUS #StopGunViolence",
  "id" : 703290657281085441,
  "created_at" : "2016-02-26 18:48:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/703290111652401152\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/sMYbmevTqL",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKWm4nWwAA_jTO.jpg",
      "id_str" : "703290086599868416",
      "id" : 703290086599868416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKWm4nWwAA_jTO.jpg",
      "sizes" : [ {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sMYbmevTqL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/Lz5tnqoYPh",
      "expanded_url" : "http:\/\/go.wh.gov\/ARRA",
      "display_url" : "go.wh.gov\/ARRA"
    } ]
  },
  "geo" : { },
  "id_str" : "703290111652401152",
  "text" : "Happening now: Watch @POTUS speak about the Recovery Act &amp; how far we've come since 2009 \u2192 https:\/\/t.co\/Lz5tnqoYPh https:\/\/t.co\/sMYbmevTqL",
  "id" : 703290111652401152,
  "created_at" : "2016-02-26 18:46:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Periscope",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "FirstJob",
      "indices" : [ 72, 81 ]
    }, {
      "text" : "InvestInSummer",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/3OySALpEVE",
      "expanded_url" : "https:\/\/www.periscope.tv\/w\/aaCN0TFKUkVta2d5eFJLUHl8MXZBR1Jqd1JqUlJHbCkqh5BKLG5linjd_JSLuXLrUrZcQkGcbIzR3KG2Gr9u",
      "display_url" : "periscope.tv\/w\/aaCN0TFKUkVt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "703283148566573056",
  "text" : "RT @vj44: LIVE on #Periscope: Hi everyone! I'm ready to chat about your #FirstJob. Tune in. #InvestInSummer  https:\/\/t.co\/3OySALpEVE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/periscope.tv\" rel=\"nofollow\"\u003EPeriscope\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Periscope",
        "indices" : [ 8, 18 ]
      }, {
        "text" : "FirstJob",
        "indices" : [ 62, 71 ]
      }, {
        "text" : "InvestInSummer",
        "indices" : [ 82, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/3OySALpEVE",
        "expanded_url" : "https:\/\/www.periscope.tv\/w\/aaCN0TFKUkVta2d5eFJLUHl8MXZBR1Jqd1JqUlJHbCkqh5BKLG5linjd_JSLuXLrUrZcQkGcbIzR3KG2Gr9u",
        "display_url" : "periscope.tv\/w\/aaCN0TFKUkVt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703282322301460480",
    "text" : "LIVE on #Periscope: Hi everyone! I'm ready to chat about your #FirstJob. Tune in. #InvestInSummer  https:\/\/t.co\/3OySALpEVE",
    "id" : 703282322301460480,
    "created_at" : "2016-02-26 18:15:46 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 703283148566573056,
  "created_at" : "2016-02-26 18:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/703277892990431232\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/wAhVsl9hAf",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKLaYdW4AEU2x5.jpg",
      "id_str" : "703277777181663233",
      "id" : 703277777181663233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcKLaYdW4AEU2x5.jpg",
      "sizes" : [ {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wAhVsl9hAf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/Lz5tnqGzGP",
      "expanded_url" : "http:\/\/go.wh.gov\/ARRA",
      "display_url" : "go.wh.gov\/ARRA"
    } ]
  },
  "geo" : { },
  "id_str" : "703277892990431232",
  "text" : "We've come a long way since the financial crisis.\n\nHere's a look \u2192 https:\/\/t.co\/Lz5tnqGzGP https:\/\/t.co\/wAhVsl9hAf",
  "id" : 703277892990431232,
  "created_at" : "2016-02-26 17:58:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703275231725617152",
  "text" : "RT @PressSec: Just arrived in Florida w\/ @POTUS, where he'll talk about our economic progress thanks in part to the Recovery Act. There's a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 27, 33 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703274117961678848",
    "text" : "Just arrived in Florida w\/ @POTUS, where he'll talk about our economic progress thanks in part to the Recovery Act. There's a lot to say.",
    "id" : 703274117961678848,
    "created_at" : "2016-02-26 17:43:10 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 703275231725617152,
  "created_at" : "2016-02-26 17:47:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RecoveryAct",
      "indices" : [ 54, 66 ]
    }, {
      "text" : "CleanEnergy",
      "indices" : [ 90, 102 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703267095786692608",
  "text" : "RT @ENERGY: It's been 7 years since @POTUS signed the #RecoveryAct. See how it shaped our #CleanEnergy future. #ActOnClimate\nhttps:\/\/t.co\/R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 24, 30 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RecoveryAct",
        "indices" : [ 42, 54 ]
      }, {
        "text" : "CleanEnergy",
        "indices" : [ 78, 90 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/RN2HmxuXdm",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/c4b243c9-def3-40ef-b129-102fde468199",
        "display_url" : "amp.twimg.com\/v\/c4b243c9-def\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "703265079370723329",
    "text" : "It's been 7 years since @POTUS signed the #RecoveryAct. See how it shaped our #CleanEnergy future. #ActOnClimate\nhttps:\/\/t.co\/RN2HmxuXdm",
    "id" : 703265079370723329,
    "created_at" : "2016-02-26 17:07:15 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 703267095786692608,
  "created_at" : "2016-02-26 17:15:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirstJob",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/oIsh4JSXr1",
      "expanded_url" : "http:\/\/go.wh.gov\/4w8AfJ",
      "display_url" : "go.wh.gov\/4w8AfJ"
    } ]
  },
  "geo" : { },
  "id_str" : "703257405950275584",
  "text" : "\"My first summer job wasn\u2019t exactly glamorous, but it taught me some valuable lessons\" \u2014@POTUS on his #FirstJob: https:\/\/t.co\/oIsh4JSXr1",
  "id" : 703257405950275584,
  "created_at" : "2016-02-26 16:36:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Periscope",
      "screen_name" : "periscopeco",
      "indices" : [ 103, 115 ],
      "id_str" : "2445809510",
      "id" : 2445809510
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 121, 126 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirstJob",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703213723830378497",
  "text" : "RT @vj44: Have stories on how important your #FirstJob was to you?\nTell us by 1:15pm ET\nI'll answer w\/ @PeriscopeCo from @VJ44\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Periscope",
        "screen_name" : "periscopeco",
        "indices" : [ 93, 105 ],
        "id_str" : "2445809510",
        "id" : 2445809510
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 111, 116 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FirstJob",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/5q3OhwDCkF",
        "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/everyone-should-have-access-first-job-valerie-jarrett",
        "display_url" : "linkedin.com\/pulse\/everyone\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702998243005706241",
    "text" : "Have stories on how important your #FirstJob was to you?\nTell us by 1:15pm ET\nI'll answer w\/ @PeriscopeCo from @VJ44\nhttps:\/\/t.co\/5q3OhwDCkF",
    "id" : 702998243005706241,
    "created_at" : "2016-02-25 23:26:56 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 703213723830378497,
  "created_at" : "2016-02-26 13:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703010502033670144",
  "text" : "RT @PressSec: In fact, the last time there was a confirmation vote in a presidential election year (1988), both Senators McConnell and Gras\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "702996304922701825",
    "geo" : { },
    "id_str" : "702997033313939456",
    "in_reply_to_user_id" : 113420831,
    "text" : "In fact, the last time there was a confirmation vote in a presidential election year (1988), both Senators McConnell and Grassley voted yes.",
    "id" : 702997033313939456,
    "in_reply_to_status_id" : 702996304922701825,
    "created_at" : "2016-02-25 23:22:08 +0000",
    "in_reply_to_screen_name" : "PressSec",
    "in_reply_to_user_id_str" : "113420831",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 703010502033670144,
  "created_at" : "2016-02-26 00:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703009977909288960",
  "text" : "RT @PressSec: On Tuesday, @POTUS will meet with Senators McConnell, Reid, Grassley, and Leahy on the need to fill the #SCOTUS vacancy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 12, 18 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702995584316084224",
    "text" : "On Tuesday, @POTUS will meet with Senators McConnell, Reid, Grassley, and Leahy on the need to fill the #SCOTUS vacancy.",
    "id" : 702995584316084224,
    "created_at" : "2016-02-25 23:16:22 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 703009977909288960,
  "created_at" : "2016-02-26 00:13:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "703002726603595778",
  "text" : "RT @Denis44: Congrats Milwaukee, on winning the Healthy Communities Challenge! @POTUS is headed your way on March 3, so get ready to #getco\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 66, 72 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcoveredMKE",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702991802442260481",
    "text" : "Congrats Milwaukee, on winning the Healthy Communities Challenge! @POTUS is headed your way on March 3, so get ready to #getcoveredMKE.",
    "id" : 702991802442260481,
    "created_at" : "2016-02-25 23:01:21 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 703002726603595778,
  "created_at" : "2016-02-25 23:44:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/5aGVHnOfMk",
      "expanded_url" : "http:\/\/snpy.tv\/1QIP07j",
      "display_url" : "snpy.tv\/1QIP07j"
    } ]
  },
  "geo" : { },
  "id_str" : "702997338818674688",
  "text" : "Here's how @POTUS is working with high-tech leaders in Silicon Valley to help counter ISIL online. https:\/\/t.co\/5aGVHnOfMk",
  "id" : 702997338818674688,
  "created_at" : "2016-02-25 23:23:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/iTwC35xiBU",
      "expanded_url" : "http:\/\/snpy.tv\/1WMnOms",
      "display_url" : "snpy.tv\/1WMnOms"
    } ]
  },
  "geo" : { },
  "id_str" : "702996682250715136",
  "text" : "\u201CWe\u2019ve continued to intensify our efforts. We\u2019re seeing results.\" \u2014@POTUS on the fight against ISIL https:\/\/t.co\/iTwC35xiBU",
  "id" : 702996682250715136,
  "created_at" : "2016-02-25 23:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702994025649999872",
  "text" : "\"My administration is working with high-tech leaders in Silicon Valley...to help counter ISIL online\" \u2014@POTUS on countering ISIL",
  "id" : 702994025649999872,
  "created_at" : "2016-02-25 23:10:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702992694486941697",
  "text" : "\u201CIn fact, ISIL has still not had a single successful major offensive operation in Syria or Iraq since last summer.\u201D \u2014@POTUS on ISIL",
  "id" : 702992694486941697,
  "created_at" : "2016-02-25 23:04:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702992481055600640",
  "text" : "\"ISIL fighters are learning that they have no safe haven. We can hit them anywhere, anytime\u2014and we do.\" \u2014@POTUS on the fight against ISIL",
  "id" : 702992481055600640,
  "created_at" : "2016-02-25 23:04:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/702992347991318528\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/DYIp9EckbQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcGHsetW4AEPjYi.jpg",
      "id_str" : "702992215073808385",
      "id" : 702992215073808385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcGHsetW4AEPjYi.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/DYIp9EckbQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702992347991318528",
  "text" : "\"Every day, our air campaign\u2014more than 10,000 strikes so far\u2014continues to destroy ISIL forces\" \u2014@POTUS https:\/\/t.co\/DYIp9EckbQ",
  "id" : 702992347991318528,
  "created_at" : "2016-02-25 23:03:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702992082487648256",
  "text" : "We\u2019ve continued to intensify our efforts. We\u2019re seeing results...I directed my team to continue accelerating this campaign\" \u2014@POTUS on ISIL",
  "id" : 702992082487648256,
  "created_at" : "2016-02-25 23:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702992001080410113",
  "text" : "RT @WHLive: \"I want to make it totally clear that there will be absolutely no cease-fire in our fight against ISIL. We will remain relentle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 132, 138 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702991933094936576",
    "text" : "\"I want to make it totally clear that there will be absolutely no cease-fire in our fight against ISIL. We will remain relentless\" \u2014@POTUS",
    "id" : 702991933094936576,
    "created_at" : "2016-02-25 23:01:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 702992001080410113,
  "created_at" : "2016-02-25 23:02:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/CAV1yf5g84",
      "expanded_url" : "http:\/\/go.wh.gov\/isil",
      "display_url" : "go.wh.gov\/isil"
    } ]
  },
  "geo" : { },
  "id_str" : "702991432446033922",
  "text" : "RT @NSC44: \u201CThis remains a difficult fight\u201D-@POTUS. Learn more about what we\u2019re doing to defeat ISIL\u2192 https:\/\/t.co\/CAV1yf5g84 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 33, 39 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NSC44\/status\/702991308344832000\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/OxtDs81NJo",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcGGziwVIAAQhNs.jpg",
        "id_str" : "702991236907474944",
        "id" : 702991236907474944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcGGziwVIAAQhNs.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OxtDs81NJo"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/CAV1yf5g84",
        "expanded_url" : "http:\/\/go.wh.gov\/isil",
        "display_url" : "go.wh.gov\/isil"
      } ]
    },
    "in_reply_to_status_id_str" : "702991157664419840",
    "geo" : { },
    "id_str" : "702991308344832000",
    "in_reply_to_user_id" : 369245377,
    "text" : "\u201CThis remains a difficult fight\u201D-@POTUS. Learn more about what we\u2019re doing to defeat ISIL\u2192 https:\/\/t.co\/CAV1yf5g84 https:\/\/t.co\/OxtDs81NJo",
    "id" : 702991308344832000,
    "in_reply_to_status_id" : 702991157664419840,
    "created_at" : "2016-02-25 22:59:23 +0000",
    "in_reply_to_screen_name" : "NSC44",
    "in_reply_to_user_id_str" : "369245377",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 702991432446033922,
  "created_at" : "2016-02-25 22:59:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/t8MxRXyctj",
      "expanded_url" : "http:\/\/go.wh.gov\/tMJFse",
      "display_url" : "go.wh.gov\/tMJFse"
    } ]
  },
  "geo" : { },
  "id_str" : "702991031160217600",
  "text" : "Tune in as @POTUS delivers remarks on the progress in the fight against ISIL \u2192 https:\/\/t.co\/t8MxRXyctj",
  "id" : 702991031160217600,
  "created_at" : "2016-02-25 22:58:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 42, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/02ULgpz8SN",
      "expanded_url" : "http:\/\/go.wh.gov\/PMI-Letter",
      "display_url" : "go.wh.gov\/PMI-Letter"
    } ]
  },
  "geo" : { },
  "id_str" : "702971726116872192",
  "text" : "RT @VP: Read the letter VP Biden wrote to #PrecisionMedicine experts visiting the White House today: https:\/\/t.co\/02ULgpz8SN https:\/\/t.co\/n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/702962318167162880\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/nScI3RulYb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcFsgNrWIAAuam4.jpg",
        "id_str" : "702962317529587712",
        "id" : 702962317529587712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcFsgNrWIAAuam4.jpg",
        "sizes" : [ {
          "h" : 301,
          "resize" : "fit",
          "w" : 779
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 779
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 779
        } ],
        "display_url" : "pic.twitter.com\/nScI3RulYb"
      } ],
      "hashtags" : [ {
        "text" : "PrecisionMedicine",
        "indices" : [ 34, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/02ULgpz8SN",
        "expanded_url" : "http:\/\/go.wh.gov\/PMI-Letter",
        "display_url" : "go.wh.gov\/PMI-Letter"
      } ]
    },
    "geo" : { },
    "id_str" : "702962318167162880",
    "text" : "Read the letter VP Biden wrote to #PrecisionMedicine experts visiting the White House today: https:\/\/t.co\/02ULgpz8SN https:\/\/t.co\/nScI3RulYb",
    "id" : 702962318167162880,
    "created_at" : "2016-02-25 21:04:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 702971726116872192,
  "created_at" : "2016-02-25 21:41:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/702954800846135296\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/84HVEXd4xZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcFlpkEW0AA20Yc.jpg",
      "id_str" : "702954781577498624",
      "id" : 702954781577498624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcFlpkEW0AA20Yc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/84HVEXd4xZ"
    } ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 64, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/dMtOFXgfYk",
      "expanded_url" : "http:\/\/go.wh.gov\/PMI",
      "display_url" : "go.wh.gov\/PMI"
    } ]
  },
  "geo" : { },
  "id_str" : "702954800846135296",
  "text" : ".@POTUS on the progress we've made one year after the launch of #PrecisionMedicine: https:\/\/t.co\/dMtOFXgfYk https:\/\/t.co\/84HVEXd4xZ",
  "id" : 702954800846135296,
  "created_at" : "2016-02-25 20:34:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702946424846196736",
  "text" : "RT @CEAChair: 2008 crisis erased $13 trillion in US wealth, 5x the amount lost in Great Depression, but recovery has been strong https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/702944368945016832\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/slt1MiHGbv",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CcFafKgW4AA4HZF.jpg",
        "id_str" : "702942508289024000",
        "id" : 702942508289024000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CcFafKgW4AA4HZF.jpg",
        "sizes" : [ {
          "h" : 352,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/slt1MiHGbv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702944368945016832",
    "text" : "2008 crisis erased $13 trillion in US wealth, 5x the amount lost in Great Depression, but recovery has been strong https:\/\/t.co\/slt1MiHGbv",
    "id" : 702944368945016832,
    "created_at" : "2016-02-25 19:52:52 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 702946424846196736,
  "created_at" : "2016-02-25 20:01:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 68, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/HlYoAbS1VD",
      "expanded_url" : "http:\/\/1.usa.gov\/21u7jPo",
      "display_url" : "1.usa.gov\/21u7jPo"
    } ]
  },
  "geo" : { },
  "id_str" : "702931894476906496",
  "text" : "RT @HHSGov: The @WhiteHouse announces key actions to accelerate the #PrecisionMedicine Initiative \u2192 https:\/\/t.co\/HlYoAbS1VD https:\/\/t.co\/mA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/702906658725343232\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/mAJgu25P8v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcE54cLUsAAUPE5.jpg",
        "id_str" : "702906658645651456",
        "id" : 702906658645651456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcE54cLUsAAUPE5.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/mAJgu25P8v"
      } ],
      "hashtags" : [ {
        "text" : "PrecisionMedicine",
        "indices" : [ 56, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/HlYoAbS1VD",
        "expanded_url" : "http:\/\/1.usa.gov\/21u7jPo",
        "display_url" : "1.usa.gov\/21u7jPo"
      } ]
    },
    "geo" : { },
    "id_str" : "702906658725343232",
    "text" : "The @WhiteHouse announces key actions to accelerate the #PrecisionMedicine Initiative \u2192 https:\/\/t.co\/HlYoAbS1VD https:\/\/t.co\/mAJgu25P8v",
    "id" : 702906658725343232,
    "created_at" : "2016-02-25 17:23:01 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 702931894476906496,
  "created_at" : "2016-02-25 19:03:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/orm4s7YAWA",
      "expanded_url" : "http:\/\/snpy.tv\/1XOZUrH",
      "display_url" : "snpy.tv\/1XOZUrH"
    } ]
  },
  "geo" : { },
  "id_str" : "702927690320338945",
  "text" : ".@POTUS on how encouraging stronger collaboration is key to the future of #PrecisionMedicine. https:\/\/t.co\/orm4s7YAWA",
  "id" : 702927690320338945,
  "created_at" : "2016-02-25 18:46:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 3, 12 ],
      "id_str" : "13058772",
      "id" : 13058772
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/uENTn71z9w",
      "expanded_url" : "http:\/\/bit.ly\/1Qgip6S",
      "display_url" : "bit.ly\/1Qgip6S"
    } ]
  },
  "geo" : { },
  "id_str" : "702918622109310976",
  "text" : "RT @LinkedIn: Finding a first job with limited education can be daunting. @POTUS announces plans to help: https:\/\/t.co\/uENTn71z9w https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 60, 66 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LinkedIn\/status\/702895859726471168\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/dzeDcg0FFN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcEwD0fW4AAIY3p.jpg",
        "id_str" : "702895859034415104",
        "id" : 702895859034415104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcEwD0fW4AAIY3p.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/dzeDcg0FFN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/uENTn71z9w",
        "expanded_url" : "http:\/\/bit.ly\/1Qgip6S",
        "display_url" : "bit.ly\/1Qgip6S"
      } ]
    },
    "geo" : { },
    "id_str" : "702895859726471168",
    "text" : "Finding a first job with limited education can be daunting. @POTUS announces plans to help: https:\/\/t.co\/uENTn71z9w https:\/\/t.co\/dzeDcg0FFN",
    "id" : 702895859726471168,
    "created_at" : "2016-02-25 16:40:06 +0000",
    "user" : {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "protected" : false,
      "id_str" : "13058772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614583061448036352\/CBpFkPaz_normal.png",
      "id" : 13058772,
      "verified" : true
    }
  },
  "id" : 702918622109310976,
  "created_at" : "2016-02-25 18:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    }, {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "indices" : [ 31, 43 ],
      "id_str" : "116498184",
      "id" : 116498184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/x1VembAzx4",
      "expanded_url" : "http:\/\/ilovecharts.tumblr.com\/",
      "display_url" : "ilovecharts.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "702909057665880064",
  "text" : "RT @CEAChair: Guest posting on @ilovecharts today - a whirlwind tour of our economy seven years after the crisis - https:\/\/t.co\/x1VembAzx4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Oberholtzer",
        "screen_name" : "ilovecharts",
        "indices" : [ 17, 29 ],
        "id_str" : "116498184",
        "id" : 116498184
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/x1VembAzx4",
        "expanded_url" : "http:\/\/ilovecharts.tumblr.com\/",
        "display_url" : "ilovecharts.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "702903625299988480",
    "text" : "Guest posting on @ilovecharts today - a whirlwind tour of our economy seven years after the crisis - https:\/\/t.co\/x1VembAzx4",
    "id" : 702903625299988480,
    "created_at" : "2016-02-25 17:10:58 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 702909057665880064,
  "created_at" : "2016-02-25 17:32:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSbudget",
      "indices" : [ 14, 26 ]
    }, {
      "text" : "PrecisionMedicine",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/NxSATBTWZd",
      "expanded_url" : "http:\/\/1.usa.gov\/1QVgkvG",
      "display_url" : "1.usa.gov\/1QVgkvG"
    } ]
  },
  "geo" : { },
  "id_str" : "702907326433341440",
  "text" : "RT @OMBPress: #POTUSbudget includes $300m for NIH to continue progress of #PrecisionMedicine Initiative. https:\/\/t.co\/NxSATBTWZd https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OMBPress\/status\/702898427189981184\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/zmRhqSKaiT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcEyYO-UkAA5sb1.jpg",
        "id_str" : "702898408764248064",
        "id" : 702898408764248064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcEyYO-UkAA5sb1.jpg",
        "sizes" : [ {
          "h" : 391,
          "resize" : "fit",
          "w" : 462
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 462
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 462
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 462
        } ],
        "display_url" : "pic.twitter.com\/zmRhqSKaiT"
      } ],
      "hashtags" : [ {
        "text" : "POTUSbudget",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "PrecisionMedicine",
        "indices" : [ 60, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/NxSATBTWZd",
        "expanded_url" : "http:\/\/1.usa.gov\/1QVgkvG",
        "display_url" : "1.usa.gov\/1QVgkvG"
      } ]
    },
    "geo" : { },
    "id_str" : "702898427189981184",
    "text" : "#POTUSbudget includes $300m for NIH to continue progress of #PrecisionMedicine Initiative. https:\/\/t.co\/NxSATBTWZd https:\/\/t.co\/zmRhqSKaiT",
    "id" : 702898427189981184,
    "created_at" : "2016-02-25 16:50:18 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 702907326433341440,
  "created_at" : "2016-02-25 17:25:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/vMlnAdUg7k",
      "expanded_url" : "http:\/\/snpy.tv\/1WLxI7T",
      "display_url" : "snpy.tv\/1WLxI7T"
    } ]
  },
  "geo" : { },
  "id_str" : "702898550326177792",
  "text" : "#PrecisionMedicine is giving us the possibility of curing diseases that up until now we couldn\u2019t figure out. https:\/\/t.co\/vMlnAdUg7k",
  "id" : 702898550326177792,
  "created_at" : "2016-02-25 16:50:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702894481826156544",
  "text" : "RT @WHLive: Today, more than 40 private-sector organizations are making new commitments to advance #PrecisionMedicine \u2192 https:\/\/t.co\/SQ7usi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PrecisionMedicine",
        "indices" : [ 87, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/SQ7usiajgP",
        "expanded_url" : "http:\/\/go.wh.gov\/YhLpSv",
        "display_url" : "go.wh.gov\/YhLpSv"
      } ]
    },
    "geo" : { },
    "id_str" : "702894447277682688",
    "text" : "Today, more than 40 private-sector organizations are making new commitments to advance #PrecisionMedicine \u2192 https:\/\/t.co\/SQ7usiajgP",
    "id" : 702894447277682688,
    "created_at" : "2016-02-25 16:34:30 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 702894481826156544,
  "created_at" : "2016-02-25 16:34:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/702892201408266240\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/oH3sMRvcJa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcEsPb6UEAE8wCd.jpg",
      "id_str" : "702891660548509697",
      "id" : 702891660548509697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcEsPb6UEAE8wCd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/oH3sMRvcJa"
    } ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 63, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/IYDBJ7zyK9",
      "expanded_url" : "http:\/\/go.wh.gov\/YhLpSv",
      "display_url" : "go.wh.gov\/YhLpSv"
    } ]
  },
  "geo" : { },
  "id_str" : "702892201408266240",
  "text" : "Happening now: Watch @POTUS take part in a panel discussion on #PrecisionMedicine \u2192 https:\/\/t.co\/IYDBJ7zyK9 https:\/\/t.co\/oH3sMRvcJa",
  "id" : 702892201408266240,
  "created_at" : "2016-02-25 16:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 57, 66 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirstJob",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/oIsh4KayPB",
      "expanded_url" : "http:\/\/go.wh.gov\/4w8AfJ",
      "display_url" : "go.wh.gov\/4w8AfJ"
    } ]
  },
  "geo" : { },
  "id_str" : "702885850712039424",
  "text" : "\"Here\u2019s the Scoop: Why My #FirstJob Mattered\" \u2014@POTUS on @LinkedIn about creating opportunity for young Americans: https:\/\/t.co\/oIsh4KayPB",
  "id" : 702885850712039424,
  "created_at" : "2016-02-25 16:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/702881123999813632\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/DoxDY4hJFp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcEimaVXEAQkSjo.jpg",
      "id_str" : "702881060145795076",
      "id" : 702881060145795076,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcEimaVXEAQkSjo.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/DoxDY4hJFp"
    } ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 30, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/IYDBJ7hXSB",
      "expanded_url" : "http:\/\/go.wh.gov\/YhLpSv",
      "display_url" : "go.wh.gov\/YhLpSv"
    } ]
  },
  "geo" : { },
  "id_str" : "702881123999813632",
  "text" : "Watch @POTUS take part in the #PrecisionMedicine Initiative Summit at 11:10am ET \u2192 https:\/\/t.co\/IYDBJ7hXSB https:\/\/t.co\/DoxDY4hJFp",
  "id" : 702881123999813632,
  "created_at" : "2016-02-25 15:41:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 69, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/kGR8MnCJbj",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "702878579261108225",
  "text" : "RT @whitehouseostp: At 11:10: @POTUS participates in the White House #PrecisionMedicine Initiative Summit. https:\/\/t.co\/kGR8MnCJbj https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/702877116061392896\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/5Lx0b3SmKX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcEfAx6UUAQKkx0.jpg",
        "id_str" : "702877115104907268",
        "id" : 702877115104907268,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcEfAx6UUAQKkx0.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/5Lx0b3SmKX"
      } ],
      "hashtags" : [ {
        "text" : "PrecisionMedicine",
        "indices" : [ 49, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/kGR8MnCJbj",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "702877116061392896",
    "text" : "At 11:10: @POTUS participates in the White House #PrecisionMedicine Initiative Summit. https:\/\/t.co\/kGR8MnCJbj https:\/\/t.co\/5Lx0b3SmKX",
    "id" : 702877116061392896,
    "created_at" : "2016-02-25 15:25:37 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 702878579261108225,
  "created_at" : "2016-02-25 15:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 3, 8 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 50, 61 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DJ44\/status\/702842565465411584\/video\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/jX8OwJ5rtR",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702842217207992320\/pu\/img\/M07d-Rmr4nf-a50D.jpg",
      "id_str" : "702842217207992320",
      "id" : 702842217207992320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702842217207992320\/pu\/img\/M07d-Rmr4nf-a50D.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/jX8OwJ5rtR"
    } ],
    "hashtags" : [ {
      "text" : "PrecisionMedicine",
      "indices" : [ 15, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702873327929577472",
  "text" : "RT @DJ44: It's #PrecisionMedicine day here at the @WhiteHouse \n\nLet's get this summit started! https:\/\/t.co\/jX8OwJ5rtR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 40, 51 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DJ44\/status\/702842565465411584\/video\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/jX8OwJ5rtR",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702842217207992320\/pu\/img\/M07d-Rmr4nf-a50D.jpg",
        "id_str" : "702842217207992320",
        "id" : 702842217207992320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/702842217207992320\/pu\/img\/M07d-Rmr4nf-a50D.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/jX8OwJ5rtR"
      } ],
      "hashtags" : [ {
        "text" : "PrecisionMedicine",
        "indices" : [ 5, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702842565465411584",
    "text" : "It's #PrecisionMedicine day here at the @WhiteHouse \n\nLet's get this summit started! https:\/\/t.co\/jX8OwJ5rtR",
    "id" : 702842565465411584,
    "created_at" : "2016-02-25 13:08:20 +0000",
    "user" : {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "protected" : false,
      "id_str" : "3030922321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570697565977313280\/aoCw1bC5_normal.jpeg",
      "id" : 3030922321,
      "verified" : true
    }
  },
  "id" : 702873327929577472,
  "created_at" : "2016-02-25 15:10:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702686072535252994",
  "text" : "RT @PressSec: See what this constitutional law professor has to say on #SCOTUS process &amp; the Senate's constitutional duty to act. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 57, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/UkXLJLGKf7",
        "expanded_url" : "http:\/\/snpy.tv\/1RosNZc",
        "display_url" : "snpy.tv\/1RosNZc"
      } ]
    },
    "geo" : { },
    "id_str" : "702639469137108992",
    "text" : "See what this constitutional law professor has to say on #SCOTUS process &amp; the Senate's constitutional duty to act. https:\/\/t.co\/UkXLJLGKf7",
    "id" : 702639469137108992,
    "created_at" : "2016-02-24 23:41:18 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 702686072535252994,
  "created_at" : "2016-02-25 02:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 85, 96 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RayCharlesTribute",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/8jfclEHV1U",
      "expanded_url" : "http:\/\/go.wh.gov\/3zWtJY",
      "display_url" : "go.wh.gov\/3zWtJY"
    } ]
  },
  "geo" : { },
  "id_str" : "702662485971640320",
  "text" : "\"Are you ready? Me too. Hold onto your seats. And enjoy the show.\" \u2014@POTUS\nWatch the @WhiteHouse #RayCharlesTribute: https:\/\/t.co\/8jfclEHV1U",
  "id" : 702662485971640320,
  "created_at" : "2016-02-25 01:12:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RayCharlesTribute",
      "indices" : [ 106, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702662112598892544",
  "text" : "\"Ray was an electrifying performer. He couldn\u2019t see us\u2014but we couldn\u2019t take our eyes off of him.\" \u2014@POTUS #RayCharlesTribute",
  "id" : 702662112598892544,
  "created_at" : "2016-02-25 01:11:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702661832981348352",
  "text" : "\"Black musicians were expected to play in the Jim Crow South.  But in 1961 Ray refused to play for a segregated audience in Augusta\" \u2014@POTUS",
  "id" : 702661832981348352,
  "created_at" : "2016-02-25 01:10:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 30, 37 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 100, 111 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 48, 66 ]
    }, {
      "text" : "RayCharlesTribute",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/8jfclEHV1U",
      "expanded_url" : "http:\/\/go.wh.gov\/3zWtJY",
      "display_url" : "go.wh.gov\/3zWtJY"
    } ]
  },
  "geo" : { },
  "id_str" : "702642842426978304",
  "text" : "Watch at 7pm ET as @POTUS and @FLOTUS celebrate #BlackHistoryMonth with a #RayCharlesTribute at the @WhiteHouse: https:\/\/t.co\/8jfclEHV1U",
  "id" : 702642842426978304,
  "created_at" : "2016-02-24 23:54:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/702640189827629056\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/oakLyKDk9B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcBA9N7WIAQ4p6x.jpg",
      "id_str" : "702632962324570116",
      "id" : 702632962324570116,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcBA9N7WIAQ4p6x.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/oakLyKDk9B"
    } ],
    "hashtags" : [ {
      "text" : "OpenEBooks",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/3ySm58OoT2",
      "expanded_url" : "http:\/\/go.wh.gov\/Ft5mZu",
      "display_url" : "go.wh.gov\/Ft5mZu"
    } ]
  },
  "geo" : { },
  "id_str" : "702640189827629056",
  "text" : "Here's how we're bringing access to free books to millions of students: https:\/\/t.co\/3ySm58OoT2 #OpenEBooks https:\/\/t.co\/oakLyKDk9B",
  "id" : 702640189827629056,
  "created_at" : "2016-02-24 23:44:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702625929214885888",
  "text" : "RT @Cecilia44: As a Michigan native, it's been devastating to watch what's been happening in Flint. Here's what we're doing to help https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/gMn3DbGPWT",
        "expanded_url" : "https:\/\/medium.com\/@Cecilia44\/how-we-re-responding-to-the-public-health-crisis-in-flint-856998aa92e4",
        "display_url" : "medium.com\/@Cecilia44\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702616476897972225",
    "text" : "As a Michigan native, it's been devastating to watch what's been happening in Flint. Here's what we're doing to help https:\/\/t.co\/gMn3DbGPWT",
    "id" : 702616476897972225,
    "created_at" : "2016-02-24 22:09:56 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 702625929214885888,
  "created_at" : "2016-02-24 22:47:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 20, 23 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702621589469327365",
  "text" : "RT @PressSec: FACT: @VP was Chair of the Judiciary Comm in 1988. So, he helped Reagan's nominee get thru in an elex year. Biden did his job\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 6, 9 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askpresssec",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "702619737289674752",
    "geo" : { },
    "id_str" : "702620313616457728",
    "in_reply_to_user_id" : 113420831,
    "text" : "FACT: @VP was Chair of the Judiciary Comm in 1988. So, he helped Reagan's nominee get thru in an elex year. Biden did his job. #askpresssec",
    "id" : 702620313616457728,
    "in_reply_to_status_id" : 702619737289674752,
    "created_at" : "2016-02-24 22:25:11 +0000",
    "in_reply_to_screen_name" : "PressSec",
    "in_reply_to_user_id_str" : "113420831",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 702621589469327365,
  "created_at" : "2016-02-24 22:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702619974448197634",
  "text" : "RT @PressSec: Sen Hatch voted for him too. So it's either their rule or we could just call it the \"Constitution rule\" #AskPressSec https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/T3XlAIfQPR",
        "expanded_url" : "https:\/\/twitter.com\/Brian8473\/status\/702617171159965696",
        "display_url" : "twitter.com\/Brian8473\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702619737289674752",
    "text" : "Sen Hatch voted for him too. So it's either their rule or we could just call it the \"Constitution rule\" #AskPressSec https:\/\/t.co\/T3XlAIfQPR",
    "id" : 702619737289674752,
    "created_at" : "2016-02-24 22:22:54 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 702619974448197634,
  "created_at" : "2016-02-24 22:23:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702619910845833216",
  "text" : "RT @PressSec: Also, per custom, @POTUS has invited Judiciary Comm chair &amp; ranking members to meet at WH. POTUS looks fwd to getting the mtg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 18, 24 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "702617858442813441",
    "geo" : { },
    "id_str" : "702618816279289856",
    "in_reply_to_user_id" : 113420831,
    "text" : "Also, per custom, @POTUS has invited Judiciary Comm chair &amp; ranking members to meet at WH. POTUS looks fwd to getting the mtg on the books.",
    "id" : 702618816279289856,
    "in_reply_to_status_id" : 702617858442813441,
    "created_at" : "2016-02-24 22:19:14 +0000",
    "in_reply_to_screen_name" : "PressSec",
    "in_reply_to_user_id_str" : "113420831",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 702619910845833216,
  "created_at" : "2016-02-24 22:23:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askpresssec",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702619882215469056",
  "text" : "RT @PressSec: .@POTUS has called party leaders &amp; Judiciary Comm members in both parties. More calls to come. #askpresssec  https:\/\/t.co\/Zft\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askpresssec",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ZftiCmCsQK",
        "expanded_url" : "https:\/\/twitter.com\/stay_frank_2\/status\/702603423896748033",
        "display_url" : "twitter.com\/stay_frank_2\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702617858442813441",
    "text" : ".@POTUS has called party leaders &amp; Judiciary Comm members in both parties. More calls to come. #askpresssec  https:\/\/t.co\/ZftiCmCsQK",
    "id" : 702617858442813441,
    "created_at" : "2016-02-24 22:15:26 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 702619882215469056,
  "created_at" : "2016-02-24 22:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/702615201267519489\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/4yuCNPp6Kl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcAwzBLWAAA5Utv.jpg",
      "id_str" : "702615194917273600",
      "id" : 702615194917273600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcAwzBLWAAA5Utv.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/4yuCNPp6Kl"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 42, 49 ]
    }, {
      "text" : "AskPressSec",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702616492173463552",
  "text" : "RT @PressSec: Ready for your questions on #SCOTUS nominations, fire away using #AskPressSec! https:\/\/t.co\/4yuCNPp6Kl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/702615201267519489\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/4yuCNPp6Kl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcAwzBLWAAA5Utv.jpg",
        "id_str" : "702615194917273600",
        "id" : 702615194917273600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcAwzBLWAAA5Utv.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/4yuCNPp6Kl"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 28, 35 ]
      }, {
        "text" : "AskPressSec",
        "indices" : [ 65, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702615201267519489",
    "text" : "Ready for your questions on #SCOTUS nominations, fire away using #AskPressSec! https:\/\/t.co\/4yuCNPp6Kl",
    "id" : 702615201267519489,
    "created_at" : "2016-02-24 22:04:52 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 702616492173463552,
  "created_at" : "2016-02-24 22:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 31, 38 ]
    }, {
      "text" : "AskPressSec",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702591805372669953",
  "text" : "RT @PressSec: Got questions on #SCOTUS nominations? Send 'em my way using #AskPressSec, I'll be here with answers at 5:00pm ET. Looking for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 17, 24 ]
      }, {
        "text" : "AskPressSec",
        "indices" : [ 60, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702581165669031936",
    "text" : "Got questions on #SCOTUS nominations? Send 'em my way using #AskPressSec, I'll be here with answers at 5:00pm ET. Looking forward to it.",
    "id" : 702581165669031936,
    "created_at" : "2016-02-24 19:49:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 702591805372669953,
  "created_at" : "2016-02-24 20:31:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NGA",
      "screen_name" : "NatlGovsAssoc",
      "indices" : [ 55, 69 ],
      "id_str" : "393615360",
      "id" : 393615360
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/JEHZ96lITd",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/01\/27\/zika-virus-what-you-need-know",
      "display_url" : "whitehouse.gov\/blog\/2016\/01\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702580906914021376",
  "text" : "RT @NSC44: How is @POTUS working w\/ local leaders like @NatlGovsAssoc to combat #Zika? Find out here: https:\/\/t.co\/JEHZ96lITd https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "NGA",
        "screen_name" : "NatlGovsAssoc",
        "indices" : [ 44, 58 ],
        "id_str" : "393615360",
        "id" : 393615360
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/702554937956302848\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/NxOSdsFVaD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_5_jXUAAAud6_.jpg",
        "id_str" : "702554937113182208",
        "id" : 702554937113182208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_5_jXUAAAud6_.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/NxOSdsFVaD"
      } ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 69, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/JEHZ96lITd",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/01\/27\/zika-virus-what-you-need-know",
        "display_url" : "whitehouse.gov\/blog\/2016\/01\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702554937956302848",
    "text" : "How is @POTUS working w\/ local leaders like @NatlGovsAssoc to combat #Zika? Find out here: https:\/\/t.co\/JEHZ96lITd https:\/\/t.co\/NxOSdsFVaD",
    "id" : 702554937956302848,
    "created_at" : "2016-02-24 18:05:24 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 702580906914021376,
  "created_at" : "2016-02-24 19:48:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. David Edelman",
      "screen_name" : "rD44",
      "indices" : [ 3, 8 ],
      "id_str" : "4073671214",
      "id" : 4073671214
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "DC Public Library",
      "screen_name" : "dcpl",
      "indices" : [ 39, 44 ],
      "id_str" : "17879538",
      "id" : 17879538
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenEBooks",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/1mxPRvJ5ZI",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/02\/23\/now-available-library-opportunity",
      "display_url" : "whitehouse.gov\/blog\/2016\/02\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702565120723922944",
  "text" : "RT @rD44: 241 days ago, @POTUS visited @DCPL to unveil #OpenEBooks. Today, it's live. Check it out: https:\/\/t.co\/1mxPRvJ5ZI https:\/\/t.co\/eJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 14, 20 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "DC Public Library",
        "screen_name" : "dcpl",
        "indices" : [ 29, 34 ],
        "id_str" : "17879538",
        "id" : 17879538
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rD44\/status\/702559781152759809\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/eJCbYhOVtx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_4Xi8UsAA5Af0.jpg",
        "id_str" : "702553150293585920",
        "id" : 702553150293585920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_4Xi8UsAA5Af0.jpg",
        "sizes" : [ {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/eJCbYhOVtx"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/rD44\/status\/702559781152759809\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/eJCbYhOVtx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_4YQUUMAAX3L-.png",
        "id_str" : "702553162473811968",
        "id" : 702553162473811968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_4YQUUMAAX3L-.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 220
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 220
        } ],
        "display_url" : "pic.twitter.com\/eJCbYhOVtx"
      } ],
      "hashtags" : [ {
        "text" : "OpenEBooks",
        "indices" : [ 45, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/1mxPRvJ5ZI",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/02\/23\/now-available-library-opportunity",
        "display_url" : "whitehouse.gov\/blog\/2016\/02\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702559781152759809",
    "text" : "241 days ago, @POTUS visited @DCPL to unveil #OpenEBooks. Today, it's live. Check it out: https:\/\/t.co\/1mxPRvJ5ZI https:\/\/t.co\/eJCbYhOVtx",
    "id" : 702559781152759809,
    "created_at" : "2016-02-24 18:24:39 +0000",
    "user" : {
      "name" : "R. David Edelman",
      "screen_name" : "rD44",
      "protected" : false,
      "id_str" : "4073671214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664566060801216513\/-QEofkKM_normal.jpg",
      "id" : 4073671214,
      "verified" : true
    }
  },
  "id" : 702565120723922944,
  "created_at" : "2016-02-24 18:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/5zQhYVj74j",
      "expanded_url" : "http:\/\/go.wh.gov\/ofovbh",
      "display_url" : "go.wh.gov\/ofovbh"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/vkWq9IfqcU",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/5879cca2-5f10-4588-b83d-f6149d4bfd3a",
      "display_url" : "amp.twimg.com\/v\/5879cca2-5f1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702560297974788096",
  "text" : ".@POTUS nominates the first woman and first African-American to be Librarian of Congress: https:\/\/t.co\/5zQhYVj74j\nhttps:\/\/t.co\/vkWq9IfqcU",
  "id" : 702560297974788096,
  "created_at" : "2016-02-24 18:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/JRgZMAbgKg",
      "expanded_url" : "http:\/\/on.fb.me\/1oHmh6M",
      "display_url" : "on.fb.me\/1oHmh6M"
    } ]
  },
  "geo" : { },
  "id_str" : "702544969920356352",
  "text" : "RT @vj44: Today @POTUS nominated superstar from our hometown Dr. Carla Hayden to be our 14th Librarian of Congress https:\/\/t.co\/JRgZMAbgKg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/JRgZMAbgKg",
        "expanded_url" : "http:\/\/on.fb.me\/1oHmh6M",
        "display_url" : "on.fb.me\/1oHmh6M"
      } ]
    },
    "geo" : { },
    "id_str" : "702535664609337344",
    "text" : "Today @POTUS nominated superstar from our hometown Dr. Carla Hayden to be our 14th Librarian of Congress https:\/\/t.co\/JRgZMAbgKg",
    "id" : 702535664609337344,
    "created_at" : "2016-02-24 16:48:49 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 702544969920356352,
  "created_at" : "2016-02-24 17:25:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/702538842671177728\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ogzYZ4SBVC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb_rPHGXEAAsZ74.jpg",
      "id_str" : "702538711729377280",
      "id" : 702538711729377280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb_rPHGXEAAsZ74.jpg",
      "sizes" : [ {
        "h" : 613,
        "resize" : "fit",
        "w" : 482
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 482
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 482
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 482
      } ],
      "display_url" : "pic.twitter.com\/ogzYZ4SBVC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/C3NZXB6qjg",
      "expanded_url" : "http:\/\/on.fb.me\/1oHneMc",
      "display_url" : "on.fb.me\/1oHneMc"
    } ]
  },
  "geo" : { },
  "id_str" : "702538842671177728",
  "text" : "Big news: @POTUS announced he's nominating Carla Hayden as our 14th Librarian of Congress: https:\/\/t.co\/C3NZXB6qjg https:\/\/t.co\/ogzYZ4SBVC",
  "id" : 702538842671177728,
  "created_at" : "2016-02-24 17:01:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Open eBooks",
      "screen_name" : "OpenEbks",
      "indices" : [ 38, 47 ],
      "id_str" : "3422699535",
      "id" : 3422699535
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702517581425598464",
  "text" : "RT @FLOTUS: Today marks the launch of @OpenEBks, bringing access to free books for students across the country. #ReachHigher\nhttps:\/\/t.co\/1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Open eBooks",
        "screen_name" : "OpenEbks",
        "indices" : [ 26, 35 ],
        "id_str" : "3422699535",
        "id" : 3422699535
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/1fRsZ9tFXv",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/43af80da-5a55-4a04-963c-1b393fb0c4e8",
        "display_url" : "amp.twimg.com\/v\/43af80da-5a5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702514803571429376",
    "text" : "Today marks the launch of @OpenEBks, bringing access to free books for students across the country. #ReachHigher\nhttps:\/\/t.co\/1fRsZ9tFXv",
    "id" : 702514803571429376,
    "created_at" : "2016-02-24 15:25:55 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 702517581425598464,
  "created_at" : "2016-02-24 15:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/S4jyLmEV6B",
      "expanded_url" : "http:\/\/www.scotusblog.com\/2016\/02\/a-responsibility-i-take-seriously\/",
      "display_url" : "scotusblog.com\/2016\/02\/a-resp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702506303277563904",
  "text" : "RT @Denis44: POTUS takes Art. II, Sec. 2 as serious business. Does the Senate? https:\/\/t.co\/S4jyLmEV6B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/S4jyLmEV6B",
        "expanded_url" : "http:\/\/www.scotusblog.com\/2016\/02\/a-responsibility-i-take-seriously\/",
        "display_url" : "scotusblog.com\/2016\/02\/a-resp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702501975410221056",
    "text" : "POTUS takes Art. II, Sec. 2 as serious business. Does the Senate? https:\/\/t.co\/S4jyLmEV6B",
    "id" : 702501975410221056,
    "created_at" : "2016-02-24 14:34:57 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 702506303277563904,
  "created_at" : "2016-02-24 14:52:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUSblog",
      "screen_name" : "SCOTUSblog",
      "indices" : [ 3, 14 ],
      "id_str" : "16228479",
      "id" : 16228479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702501331265822720",
  "text" : "RT @SCOTUSblog: President Obama on his duties in the appointment process &amp; the qualities he seeks in a nominee, for SCOTUSblog: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/Mi3nKExzlk",
        "expanded_url" : "http:\/\/goo.gl\/uqvAjP",
        "display_url" : "goo.gl\/uqvAjP"
      } ]
    },
    "geo" : { },
    "id_str" : "702478747895775238",
    "text" : "President Obama on his duties in the appointment process &amp; the qualities he seeks in a nominee, for SCOTUSblog: https:\/\/t.co\/Mi3nKExzlk",
    "id" : 702478747895775238,
    "created_at" : "2016-02-24 13:02:39 +0000",
    "user" : {
      "name" : "SCOTUSblog",
      "screen_name" : "SCOTUSblog",
      "protected" : false,
      "id_str" : "16228479",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476743057325322240\/vU0ZvBDn_normal.jpeg",
      "id" : 16228479,
      "verified" : true
    }
  },
  "id" : 702501331265822720,
  "created_at" : "2016-02-24 14:32:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "SCOTUSblog",
      "screen_name" : "SCOTUSblog",
      "indices" : [ 17, 28 ],
      "id_str" : "16228479",
      "id" : 16228479
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/fOBAdTm8kn",
      "expanded_url" : "http:\/\/go.wh.gov\/pmg6LF",
      "display_url" : "go.wh.gov\/pmg6LF"
    } ]
  },
  "geo" : { },
  "id_str" : "702499239906115584",
  "text" : ".@POTUS takes to @SCOTUSBlog to lay out what he's looking for in a Supreme Court nominee \u2192 https:\/\/t.co\/fOBAdTm8kn",
  "id" : 702499239906115584,
  "created_at" : "2016-02-24 14:24:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/702316811577073664\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/h7JIbD0dQH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb8hKU8W0AEAWKh.jpg",
      "id_str" : "702316528197357569",
      "id" : 702316528197357569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb8hKU8W0AEAWKh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/h7JIbD0dQH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/R5okJhIdLP",
      "expanded_url" : "http:\/\/go.wh.gov\/usDQaP",
      "display_url" : "go.wh.gov\/usDQaP"
    } ]
  },
  "geo" : { },
  "id_str" : "702316811577073664",
  "text" : "It's time to close the prison at Guantanamo Bay.\n\nHere's @POTUS's plan to do it \u2192 https:\/\/t.co\/R5okJhIdLP https:\/\/t.co\/h7JIbD0dQH",
  "id" : 702316811577073664,
  "created_at" : "2016-02-24 02:19:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/lUQxXRePVd",
      "expanded_url" : "https:\/\/twitter.com\/chrislhayes\/status\/702241048332935168",
      "display_url" : "twitter.com\/chrislhayes\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "702268300416446465",
  "text" : "RT @PressSec: Almost certainly not, considering every #SCOTUS nominee since 1875 has gotten a hearing and\/or a vote. https:\/\/t.co\/lUQxXRePVd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/lUQxXRePVd",
        "expanded_url" : "https:\/\/twitter.com\/chrislhayes\/status\/702241048332935168",
        "display_url" : "twitter.com\/chrislhayes\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702264712570863616",
    "text" : "Almost certainly not, considering every #SCOTUS nominee since 1875 has gotten a hearing and\/or a vote. https:\/\/t.co\/lUQxXRePVd",
    "id" : 702264712570863616,
    "created_at" : "2016-02-23 22:52:09 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 702268300416446465,
  "created_at" : "2016-02-23 23:06:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 4, 18 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/R5okJhZODn",
      "expanded_url" : "http:\/\/go.wh.gov\/usDQaP",
      "display_url" : "go.wh.gov\/usDQaP"
    } ]
  },
  "geo" : { },
  "id_str" : "702261837929144320",
  "text" : "The @DeptOfDefense just submitted a plan to Congress to close the prison at Guantanamo Bay.\n\nRead it here: https:\/\/t.co\/R5okJhZODn",
  "id" : 702261837929144320,
  "created_at" : "2016-02-23 22:40:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 3, 16 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    }, {
      "name" : "Demi Lovato",
      "screen_name" : "ddlovato",
      "indices" : [ 28, 37 ],
      "id_str" : "21111883",
      "id" : 21111883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702246256467451905",
  "text" : "RT @Botticelli44: Thank you @ddlovato for being so open about your recovery. Stories like yours give hope that recovery is possible! https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Demi Lovato",
        "screen_name" : "ddlovato",
        "indices" : [ 10, 19 ],
        "id_str" : "21111883",
        "id" : 21111883
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/1re0zX6JGc",
        "expanded_url" : "https:\/\/twitter.com\/ddlovato\/status\/702225008504889344",
        "display_url" : "twitter.com\/ddlovato\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702240765519519747",
    "text" : "Thank you @ddlovato for being so open about your recovery. Stories like yours give hope that recovery is possible! https:\/\/t.co\/1re0zX6JGc",
    "id" : 702240765519519747,
    "created_at" : "2016-02-23 21:17:00 +0000",
    "user" : {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "protected" : false,
      "id_str" : "2382297056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789238935159312385\/z7RppzRN_normal.jpg",
      "id" : 2382297056,
      "verified" : true
    }
  },
  "id" : 702246256467451905,
  "created_at" : "2016-02-23 21:38:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/R5okJhZODn",
      "expanded_url" : "http:\/\/go.wh.gov\/usDQaP",
      "display_url" : "go.wh.gov\/usDQaP"
    }, {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/vlKgRiNK7y",
      "expanded_url" : "http:\/\/snpy.tv\/1oF4Mnz",
      "display_url" : "snpy.tv\/1oF4Mnz"
    } ]
  },
  "geo" : { },
  "id_str" : "702195384194453504",
  "text" : "Here's the plan @POTUS just laid out to close the prison at Guantanamo Bay: https:\/\/t.co\/R5okJhZODn https:\/\/t.co\/vlKgRiNK7y",
  "id" : 702195384194453504,
  "created_at" : "2016-02-23 18:16:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702163388550479872",
  "text" : "RT @PressSec: When @POTUS took office, he took action to begin closing Gitmo. Today, he's announcing a plan to close it for good: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 5, 11 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/13Skb7xe1V",
        "expanded_url" : "http:\/\/go.wh.gov\/8sxXiM",
        "display_url" : "go.wh.gov\/8sxXiM"
      } ]
    },
    "geo" : { },
    "id_str" : "702162564373835776",
    "text" : "When @POTUS took office, he took action to begin closing Gitmo. Today, he's announcing a plan to close it for good: https:\/\/t.co\/13Skb7xe1V",
    "id" : 702162564373835776,
    "created_at" : "2016-02-23 16:06:15 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 702163388550479872,
  "created_at" : "2016-02-23 16:09:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702160093903605760",
  "text" : "RT @Price44: For years, the prison at Guantanamo Bay has undermined our national security. Here's the plan to close it \u2192 https:\/\/t.co\/2ZkYK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GTMO",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/2ZkYKPTFbz",
        "expanded_url" : "http:\/\/www.defense.gov\/Portals\/1\/Documents\/pubs\/GTMO_Closure_Plan_0216.pdf",
        "display_url" : "defense.gov\/Portals\/1\/Docu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "702148954310340608",
    "text" : "For years, the prison at Guantanamo Bay has undermined our national security. Here's the plan to close it \u2192 https:\/\/t.co\/2ZkYKPTFbz. #GTMO",
    "id" : 702148954310340608,
    "created_at" : "2016-02-23 15:12:10 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 702160093903605760,
  "created_at" : "2016-02-23 15:56:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/86p9S60WJm",
      "expanded_url" : "http:\/\/go.wh.gov\/8sxXiM",
      "display_url" : "go.wh.gov\/8sxXiM"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/vlKgRj5lw8",
      "expanded_url" : "http:\/\/snpy.tv\/1oF4Mnz",
      "display_url" : "snpy.tv\/1oF4Mnz"
    } ]
  },
  "geo" : { },
  "id_str" : "702158870383296513",
  "text" : "BREAKING: Watch @POTUS announce his plan to close the prison at Guantanamo Bay \u2192 https:\/\/t.co\/86p9S60WJm https:\/\/t.co\/vlKgRj5lw8",
  "id" : 702158870383296513,
  "created_at" : "2016-02-23 15:51:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702157041473888256",
  "text" : "RT @WHLive: \"The plan we\u2019re submitting today is not only the right thing to do for our security, it will save money\" \u2014@POTUS on closing Gua\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 106, 112 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "702156938306527233",
    "text" : "\"The plan we\u2019re submitting today is not only the right thing to do for our security, it will save money\" \u2014@POTUS on closing Guantanamo",
    "id" : 702156938306527233,
    "created_at" : "2016-02-23 15:43:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 702157041473888256,
  "created_at" : "2016-02-23 15:44:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702156715266023424",
  "text" : "RT @NSC44: \u201CFourth, &amp; finally, we\u2019re going to work w\/ Congress to find a secure location in the U.S. to hold remaining detainees\u201D-@POTUS on\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 123, 129 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "702155690765189120",
    "geo" : { },
    "id_str" : "702156423979933696",
    "in_reply_to_user_id" : 369245377,
    "text" : "\u201CFourth, &amp; finally, we\u2019re going to work w\/ Congress to find a secure location in the U.S. to hold remaining detainees\u201D-@POTUS on Guantanamo",
    "id" : 702156423979933696,
    "in_reply_to_status_id" : 702155690765189120,
    "created_at" : "2016-02-23 15:41:51 +0000",
    "in_reply_to_screen_name" : "NSC44",
    "in_reply_to_user_id_str" : "369245377",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 702156715266023424,
  "created_at" : "2016-02-23 15:43:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702156232317128704",
  "text" : "\"It reflects the lessons we\u2019ve learned since 9\/11\u2014lessons that must guide our nation going forward.\" \u2014@POTUS on his plan to close Guantanamo",
  "id" : 702156232317128704,
  "created_at" : "2016-02-23 15:41:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702155935851134976",
  "text" : "RT @NSC44: \u201CThird, we\u2019ll continue to use all legal tools to deal w\/ the remaining detainees still held under law of war detention\u201D-@POTUS o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 120, 126 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "702155614416338944",
    "geo" : { },
    "id_str" : "702155690765189120",
    "in_reply_to_user_id" : 369245377,
    "text" : "\u201CThird, we\u2019ll continue to use all legal tools to deal w\/ the remaining detainees still held under law of war detention\u201D-@POTUS on Guantanamo",
    "id" : 702155690765189120,
    "in_reply_to_status_id" : 702155614416338944,
    "created_at" : "2016-02-23 15:38:56 +0000",
    "in_reply_to_screen_name" : "NSC44",
    "in_reply_to_user_id_str" : "369245377",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 702155935851134976,
  "created_at" : "2016-02-23 15:39:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702155814086307845",
  "text" : "RT @NSC44: \u201CSecond, we\u2019ll accelerate the periodic reviews of remaining detainees to determine whether their continued detention is necessar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 131, 137 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "702155517448183808",
    "geo" : { },
    "id_str" : "702155614416338944",
    "in_reply_to_user_id" : 369245377,
    "text" : "\u201CSecond, we\u2019ll accelerate the periodic reviews of remaining detainees to determine whether their continued detention is necessary\u201D-@POTUS",
    "id" : 702155614416338944,
    "in_reply_to_status_id" : 702155517448183808,
    "created_at" : "2016-02-23 15:38:38 +0000",
    "in_reply_to_screen_name" : "NSC44",
    "in_reply_to_user_id_str" : "369245377",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 702155814086307845,
  "created_at" : "2016-02-23 15:39:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702155608284336129",
  "text" : "RT @NSC44: \u201CFirst, we\u2019ll continue to securely &amp; responsibly transfer to other countries the 35 of 91 detainees already approved for transfe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 135, 141 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "702155208952930305",
    "geo" : { },
    "id_str" : "702155517448183808",
    "in_reply_to_user_id" : 369245377,
    "text" : "\u201CFirst, we\u2019ll continue to securely &amp; responsibly transfer to other countries the 35 of 91 detainees already approved for transfer\u201D-@POTUS",
    "id" : 702155517448183808,
    "in_reply_to_status_id" : 702155208952930305,
    "created_at" : "2016-02-23 15:38:15 +0000",
    "in_reply_to_screen_name" : "NSC44",
    "in_reply_to_user_id_str" : "369245377",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 702155608284336129,
  "created_at" : "2016-02-23 15:38:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702155157111500802",
  "text" : "\"Today, the Defense Department\u2026is submitting to Congress our plan for closing the facility at Guantanamo once and for all.\" \u2014@POTUS",
  "id" : 702155157111500802,
  "created_at" : "2016-02-23 15:36:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702154358264352774",
  "text" : "\"Keeping this facility open is contrary to our values, it undermines our standing in the world.\" \u2014@POTUS on Guantanamo",
  "id" : 702154358264352774,
  "created_at" : "2016-02-23 15:33:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "702154065892012032",
  "text" : "\"It has been clear that the detention facility at Guantanamo Bay does not advance our national security\u2014it undermines it\" \u2014@POTUS",
  "id" : 702154065892012032,
  "created_at" : "2016-02-23 15:32:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/LBxEaUPfCv",
      "expanded_url" : "http:\/\/go.wh.gov\/Wj5EnF",
      "display_url" : "go.wh.gov\/Wj5EnF"
    } ]
  },
  "geo" : { },
  "id_str" : "702153796768636928",
  "text" : "Happening now: @POTUS delivers a statement on Guantanamo \u2192 https:\/\/t.co\/LBxEaUPfCv",
  "id" : 702153796768636928,
  "created_at" : "2016-02-23 15:31:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/LBxEaUPfCv",
      "expanded_url" : "http:\/\/go.wh.gov\/Wj5EnF",
      "display_url" : "go.wh.gov\/Wj5EnF"
    } ]
  },
  "geo" : { },
  "id_str" : "702142581963149313",
  "text" : "At 10:30am ET, watch @POTUS deliver a statement on Guantanamo \u2192 https:\/\/t.co\/LBxEaUPfCv",
  "id" : 702142581963149313,
  "created_at" : "2016-02-23 14:46:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701933720513679360",
  "text" : "RT @VP: As my record shows, I presided over the consideration of Justice Kennedy,\nReagan nominee, who was confirmed in a presidential elect\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701927523022667776",
    "text" : "As my record shows, I presided over the consideration of Justice Kennedy,\nReagan nominee, who was confirmed in a presidential election year.",
    "id" : 701927523022667776,
    "created_at" : "2016-02-23 00:32:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 701933720513679360,
  "created_at" : "2016-02-23 00:56:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701922601405431810",
  "text" : "RT @VP: In 1992, I urged the Senate and White House to work together to ensure the Court functioned as our founders intended. Remains my po\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701922165424316416",
    "text" : "In 1992, I urged the Senate and White House to work together to ensure the Court functioned as our founders intended. Remains my position.",
    "id" : 701922165424316416,
    "created_at" : "2016-02-23 00:10:59 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 701922601405431810,
  "created_at" : "2016-02-23 00:12:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KalamazooShooting",
      "indices" : [ 82, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/kwtfK65AFQ",
      "expanded_url" : "http:\/\/snpy.tv\/1UicU9f",
      "display_url" : "snpy.tv\/1UicU9f"
    } ]
  },
  "geo" : { },
  "id_str" : "701901871846465541",
  "text" : "\"They'll have whatever support they need for their investigation.\" \u2014@POTUS on the #KalamazooShooting https:\/\/t.co\/kwtfK65AFQ",
  "id" : 701901871846465541,
  "created_at" : "2016-02-22 22:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701872314137313283",
  "text" : "RT @POTUS: We've made big strides in the fight against Malaria - saving millions of lives. That's American leadership at work. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/701871557002407936\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/jVdeE4Qktw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb2MdLUUUAA3FcI.jpg",
        "id_str" : "701871549821767680",
        "id" : 701871549821767680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb2MdLUUUAA3FcI.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/jVdeE4Qktw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701871557002407936",
    "text" : "We've made big strides in the fight against Malaria - saving millions of lives. That's American leadership at work. https:\/\/t.co\/jVdeE4Qktw",
    "id" : 701871557002407936,
    "created_at" : "2016-02-22 20:49:53 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 701872314137313283,
  "created_at" : "2016-02-22 20:52:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/bnP2BDBRgP",
      "expanded_url" : "http:\/\/1.usa.gov\/24mszJc",
      "display_url" : "1.usa.gov\/24mszJc"
    } ]
  },
  "geo" : { },
  "id_str" : "701859616913756160",
  "text" : "RT @FactsOnClimate: JUST IN: Solar and wind tax credits extended by @POTUS will \u2191 capacity by nearly 60% \u2192 https:\/\/t.co\/bnP2BDBRgP https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 48, 54 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/701859300097052676\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/Juuv0MoYB6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb2BLUwUYAAMTtk.jpg",
        "id_str" : "701859148489580544",
        "id" : 701859148489580544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb2BLUwUYAAMTtk.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/Juuv0MoYB6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/bnP2BDBRgP",
        "expanded_url" : "http:\/\/1.usa.gov\/24mszJc",
        "display_url" : "1.usa.gov\/24mszJc"
      } ]
    },
    "geo" : { },
    "id_str" : "701859300097052676",
    "text" : "JUST IN: Solar and wind tax credits extended by @POTUS will \u2191 capacity by nearly 60% \u2192 https:\/\/t.co\/bnP2BDBRgP https:\/\/t.co\/Juuv0MoYB6",
    "id" : 701859300097052676,
    "created_at" : "2016-02-22 20:01:11 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 701859616913756160,
  "created_at" : "2016-02-22 20:02:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 101, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701855167617089537",
  "text" : "RT @JohnKerry: Gratified to see final arrangements concluded today for a cessation of hostilities in #Syria. \nMy full statement: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 86, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/76DSDBbwHN",
        "expanded_url" : "http:\/\/go.usa.gov\/cpysV",
        "display_url" : "go.usa.gov\/cpysV"
      } ]
    },
    "geo" : { },
    "id_str" : "701848101892575232",
    "text" : "Gratified to see final arrangements concluded today for a cessation of hostilities in #Syria. \nMy full statement: https:\/\/t.co\/76DSDBbwHN",
    "id" : 701848101892575232,
    "created_at" : "2016-02-22 19:16:41 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 701855167617089537,
  "created_at" : "2016-02-22 19:44:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701848255886446592",
  "text" : "RT @Denis44: Politics isn\u2019t always about posturing, as today\u2019s Q&amp;A showed, Dems &amp; GOP can still work together to get things done https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/yJkqybg01B",
        "expanded_url" : "http:\/\/snpy.tv\/21lsAe2",
        "display_url" : "snpy.tv\/21lsAe2"
      } ]
    },
    "geo" : { },
    "id_str" : "701848132707971072",
    "text" : "Politics isn\u2019t always about posturing, as today\u2019s Q&amp;A showed, Dems &amp; GOP can still work together to get things done https:\/\/t.co\/yJkqybg01B",
    "id" : 701848132707971072,
    "created_at" : "2016-02-22 19:16:49 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 701848255886446592,
  "created_at" : "2016-02-22 19:17:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Trudeau",
      "screen_name" : "JustinTrudeau",
      "indices" : [ 22, 36 ],
      "id_str" : "14260960",
      "id" : 14260960
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 44, 55 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHSocial",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/GUK11JXUzm",
      "expanded_url" : "http:\/\/go.wh.gov\/CanadaSocial",
      "display_url" : "go.wh.gov\/CanadaSocial"
    } ]
  },
  "geo" : { },
  "id_str" : "701840291096043520",
  "text" : "Ready to help welcome @JustinTrudeau to the @WhiteHouse? Apply to join the #WHSocial: https:\/\/t.co\/GUK11JXUzm",
  "id" : 701840291096043520,
  "created_at" : "2016-02-22 18:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/XmIMHktjMq",
      "expanded_url" : "http:\/\/snpy.tv\/1UidrYV",
      "display_url" : "snpy.tv\/1UidrYV"
    } ]
  },
  "geo" : { },
  "id_str" : "701825883083042817",
  "text" : "\"We're launching an aggressive coordinated campaign...to stop #Zika at the source &amp; keep Americans healthy.\" \u2014@POTUS https:\/\/t.co\/XmIMHktjMq",
  "id" : 701825883083042817,
  "created_at" : "2016-02-22 17:48:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NGA",
      "screen_name" : "NatlGovsAssoc",
      "indices" : [ 66, 80 ],
      "id_str" : "393615360",
      "id" : 393615360
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 54, 58 ]
    }, {
      "text" : "NGA2016",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/xb8Gza4T6e",
      "expanded_url" : "http:\/\/snpy.tv\/1oxGJq4",
      "display_url" : "snpy.tv\/1oxGJq4"
    } ]
  },
  "geo" : { },
  "id_str" : "701824607943319552",
  "text" : "RT @USTradeRep: WATCH: @POTUS makes a strong case for #TPP to the @NatlGovsAssoc \u2192 https:\/\/t.co\/xb8Gza4T6e #NGA2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "NGA",
        "screen_name" : "NatlGovsAssoc",
        "indices" : [ 50, 64 ],
        "id_str" : "393615360",
        "id" : 393615360
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 38, 42 ]
      }, {
        "text" : "NGA2016",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/xb8Gza4T6e",
        "expanded_url" : "http:\/\/snpy.tv\/1oxGJq4",
        "display_url" : "snpy.tv\/1oxGJq4"
      } ]
    },
    "geo" : { },
    "id_str" : "701823176356065280",
    "text" : "WATCH: @POTUS makes a strong case for #TPP to the @NatlGovsAssoc \u2192 https:\/\/t.co\/xb8Gza4T6e #NGA2016",
    "id" : 701823176356065280,
    "created_at" : "2016-02-22 17:37:39 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 701824607943319552,
  "created_at" : "2016-02-22 17:43:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KalamazooShooting",
      "indices" : [ 26, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/kwtfK65AFQ",
      "expanded_url" : "http:\/\/snpy.tv\/1UicU9f",
      "display_url" : "snpy.tv\/1UicU9f"
    } ]
  },
  "geo" : { },
  "id_str" : "701810557817585664",
  "text" : "Watch @POTUS speak on the #KalamazooShooting and keeping the American people safe. https:\/\/t.co\/kwtfK65AFQ",
  "id" : 701810557817585664,
  "created_at" : "2016-02-22 16:47:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/701808190070136832\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/n9I6aDcIZN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cb1S0liUEAAhoPg.jpg",
      "id_str" : "701808180322373632",
      "id" : 701808180322373632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cb1S0liUEAAhoPg.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/n9I6aDcIZN"
    } ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701808190070136832",
  "text" : "\"I want us fighting this disease at every level, with every tool at our disposal.\" \u2014@POTUS on #ZikaVirus https:\/\/t.co\/n9I6aDcIZN",
  "id" : 701808190070136832,
  "created_at" : "2016-02-22 16:38:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KalamazooShooting",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701807070077657089",
  "text" : "\"I called the mayor, sheriff and police chief there, and told them they\u2019ll have whatever support they need\" \u2014@POTUS on #KalamazooShooting",
  "id" : 701807070077657089,
  "created_at" : "2016-02-22 16:33:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NGA",
      "screen_name" : "NatlGovsAssoc",
      "indices" : [ 125, 139 ],
      "id_str" : "393615360",
      "id" : 393615360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701806790695112706",
  "text" : "\"We have to stay united as one American family...rejecting any politics that tries to divide Americans by faith.\" \u2014@POTUS to @NatlGovsAssoc",
  "id" : 701806790695112706,
  "created_at" : "2016-02-22 16:32:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701806615423541252",
  "text" : "RT @vj44: \"Whatever our party, we all raise our hand, take an oath, and assume the solemn responsibility to protect our citizens.\" - @POTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 123, 129 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701806486981373954",
    "text" : "\"Whatever our party, we all raise our hand, take an oath, and assume the solemn responsibility to protect our citizens.\" - @POTUS",
    "id" : 701806486981373954,
    "created_at" : "2016-02-22 16:31:20 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 701806615423541252,
  "created_at" : "2016-02-22 16:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NGA",
      "screen_name" : "NatlGovsAssoc",
      "indices" : [ 36, 50 ],
      "id_str" : "393615360",
      "id" : 393615360
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NGA2016",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/madMsiuk3H",
      "expanded_url" : "http:\/\/go.wh.gov\/LadV2X",
      "display_url" : "go.wh.gov\/LadV2X"
    } ]
  },
  "geo" : { },
  "id_str" : "701805826726559744",
  "text" : "Tune in now as @POTUS speaks to the @NatlGovsAssoc: https:\/\/t.co\/madMsiuk3H #NGA2016",
  "id" : 701805826726559744,
  "created_at" : "2016-02-22 16:28:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/CAPi3heOMT",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/549ad94b-1661-425e-97d8-1bd8f5a6b9af",
      "display_url" : "amp.twimg.com\/v\/549ad94b-166\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701589800193650688",
  "text" : "This is one dance party 106-year-old Virginia McLaurin will never forget. #BlackHistoryMonth\nhttps:\/\/t.co\/CAPi3heOMT",
  "id" : 701589800193650688,
  "created_at" : "2016-02-22 02:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701563367358603265",
  "text" : "\"I believe that a politics that better reflects our people is not only possible \u2013 it couldn\u2019t be more important.\" \u2014@POTUS to U.S. governors",
  "id" : 701563367358603265,
  "created_at" : "2016-02-22 00:25:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NGA",
      "screen_name" : "NatlGovsAssoc",
      "indices" : [ 126, 140 ],
      "id_str" : "393615360",
      "id" : 393615360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701562752607903744",
  "text" : "\"People we serve don\u2019t typcially think in terms of red or blue, left or right. They just want a shot to get ahead\" \u2014@POTUS to @NatlGovsAssoc",
  "id" : 701562752607903744,
  "created_at" : "2016-02-22 00:22:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NGA2016",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/MLYxYw5Fo7",
      "expanded_url" : "http:\/\/go.wh.gov\/hY7XRA",
      "display_url" : "go.wh.gov\/hY7XRA"
    } ]
  },
  "geo" : { },
  "id_str" : "701561729931542528",
  "text" : "Happening now: @POTUS speaks to the National Governors Association \u2192 https:\/\/t.co\/MLYxYw5Fo7 #NGA2016",
  "id" : 701561729931542528,
  "created_at" : "2016-02-22 00:18:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/cM2PFjBcNP",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/555c6fa3-2330-4231-9fd8-4e0c2eee1020",
      "display_url" : "amp.twimg.com\/v\/555c6fa3-233\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701553871173193728",
  "text" : "Go behind the scenes with @POTUS and see who stopped by the White House last week. #WestWingWeek\nhttps:\/\/t.co\/cM2PFjBcNP",
  "id" : 701553871173193728,
  "created_at" : "2016-02-21 23:47:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 34, 50 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 57, 73 ],
      "id_str" : "65707359",
      "id" : 65707359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/9VRLY1VMFb",
      "expanded_url" : "http:\/\/nasa.tumblr.com\/post\/129151446854\/the-one-year-mission",
      "display_url" : "nasa.tumblr.com\/post\/129151446\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "701550654314127360",
  "text" : "RT @NASA: Happy Birthday to twins @StationCDRKelly &amp; @ShuttleCDRKelly, one on Earth and one in space: https:\/\/t.co\/9VRLY1VMFb https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Kelly",
        "screen_name" : "StationCDRKelly",
        "indices" : [ 24, 40 ],
        "id_str" : "65647594",
        "id" : 65647594
      }, {
        "name" : "Mark Kelly",
        "screen_name" : "ShuttleCDRKelly",
        "indices" : [ 47, 63 ],
        "id_str" : "65707359",
        "id" : 65707359
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/701482269618401280\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/DBqAScbp1T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbwqaE6WEAEPE_q.jpg",
        "id_str" : "701482269446377473",
        "id" : 701482269446377473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbwqaE6WEAEPE_q.jpg",
        "sizes" : [ {
          "h" : 656,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 656,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 656,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/DBqAScbp1T"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/9VRLY1VMFb",
        "expanded_url" : "http:\/\/nasa.tumblr.com\/post\/129151446854\/the-one-year-mission",
        "display_url" : "nasa.tumblr.com\/post\/129151446\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "701482269618401280",
    "text" : "Happy Birthday to twins @StationCDRKelly &amp; @ShuttleCDRKelly, one on Earth and one in space: https:\/\/t.co\/9VRLY1VMFb https:\/\/t.co\/DBqAScbp1T",
    "id" : 701482269618401280,
    "created_at" : "2016-02-21 19:03:00 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 701550654314127360,
  "created_at" : "2016-02-21 23:34:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaVisit",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/aXJhut5C1F",
      "expanded_url" : "http:\/\/go.wh.gov\/3ESSLY",
      "display_url" : "go.wh.gov\/3ESSLY"
    } ]
  },
  "geo" : { },
  "id_str" : "701536219314913281",
  "text" : "\"More Americans are visiting Cuba than at any time in the last 50 years\" \u2014@POTUS #CubaVisit https:\/\/t.co\/aXJhut5C1F",
  "id" : 701536219314913281,
  "created_at" : "2016-02-21 22:37:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaVisit",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/aXJhutncTd",
      "expanded_url" : "http:\/\/go.wh.gov\/3ESSLY",
      "display_url" : "go.wh.gov\/3ESSLY"
    } ]
  },
  "geo" : { },
  "id_str" : "701530675510272000",
  "text" : "\"It will be the first visit of a U.S. president to Cuba in nearly 90 years.\" \u2014@POTUS #CubaVisit https:\/\/t.co\/aXJhutncTd",
  "id" : 701530675510272000,
  "created_at" : "2016-02-21 22:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/701192243793645568\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/MjJfhRLKnw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbsinCVWEAAqdk3.jpg",
      "id_str" : "701192221022883840",
      "id" : 701192221022883840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbsinCVWEAAqdk3.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/MjJfhRLKnw"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 11, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701192243793645568",
  "text" : "Nose goes. #ObamaAndKids https:\/\/t.co\/MjJfhRLKnw",
  "id" : 701192243793645568,
  "created_at" : "2016-02-20 23:50:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/701183013917487105\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/NR1wFpCyEE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbsaHIdW4AEakeA.jpg",
      "id_str" : "701182876818268161",
      "id" : 701182876818268161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbsaHIdW4AEakeA.jpg",
      "sizes" : [ {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 509,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/NR1wFpCyEE"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 11, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701183013917487105",
  "text" : "Stiff arm! #ObamaAndKids https:\/\/t.co\/NR1wFpCyEE",
  "id" : 701183013917487105,
  "created_at" : "2016-02-20 23:13:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/701175151069507584\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/51NWvm7IAW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbsS0_PVIAAePeL.jpg",
      "id_str" : "701174868524474368",
      "id" : 701174868524474368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbsS0_PVIAAePeL.jpg",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1025,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1025,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 820,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/51NWvm7IAW"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701175151069507584",
  "text" : "\"I want to know if my hair is just like yours\"\n\u201CTouch it, dude!\u201D\n#ObamaAndKids https:\/\/t.co\/51NWvm7IAW",
  "id" : 701175151069507584,
  "created_at" : "2016-02-20 22:42:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/701148044788682752\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/0UaQ7fWRfa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbr6bj-UAAAwhlp.jpg",
      "id_str" : "701148043429543936",
      "id" : 701148043429543936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbr6bj-UAAAwhlp.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/0UaQ7fWRfa"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701149944841793536",
  "text" : "RT @vj44: One of my favorites - @POTUS in Treme #ObamaAndKids https:\/\/t.co\/0UaQ7fWRfa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 22, 28 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/701148044788682752\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/0UaQ7fWRfa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbr6bj-UAAAwhlp.jpg",
        "id_str" : "701148043429543936",
        "id" : 701148043429543936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbr6bj-UAAAwhlp.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/0UaQ7fWRfa"
      } ],
      "hashtags" : [ {
        "text" : "ObamaAndKids",
        "indices" : [ 38, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701148044788682752",
    "text" : "One of my favorites - @POTUS in Treme #ObamaAndKids https:\/\/t.co\/0UaQ7fWRfa",
    "id" : 701148044788682752,
    "created_at" : "2016-02-20 20:54:55 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 701149944841793536,
  "created_at" : "2016-02-20 21:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sinorice Moss",
      "screen_name" : "sinoricemoss",
      "indices" : [ 3, 16 ],
      "id_str" : "27503901",
      "id" : 27503901
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sinoricemoss\/status\/701066105620566016\/photo\/1",
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/PyvQVC2Vif",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbqv555VAAE7fcl.jpg",
      "id_str" : "701066101338210305",
      "id" : 701066101338210305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbqv555VAAE7fcl.jpg",
      "sizes" : [ {
        "h" : 845,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 845,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 845,
        "resize" : "fit",
        "w" : 564
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 454
      } ],
      "display_url" : "pic.twitter.com\/PyvQVC2Vif"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701144598022897664",
  "text" : "RT @sinoricemoss: My Favorite #ObamaAndKids @POTUS https:\/\/t.co\/PyvQVC2Vif",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 26, 32 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sinoricemoss\/status\/701066105620566016\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/PyvQVC2Vif",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbqv555VAAE7fcl.jpg",
        "id_str" : "701066101338210305",
        "id" : 701066101338210305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbqv555VAAE7fcl.jpg",
        "sizes" : [ {
          "h" : 845,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 845,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 845,
          "resize" : "fit",
          "w" : 564
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 454
        } ],
        "display_url" : "pic.twitter.com\/PyvQVC2Vif"
      } ],
      "hashtags" : [ {
        "text" : "ObamaAndKids",
        "indices" : [ 12, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701066105620566016",
    "text" : "My Favorite #ObamaAndKids @POTUS https:\/\/t.co\/PyvQVC2Vif",
    "id" : 701066105620566016,
    "created_at" : "2016-02-20 15:29:19 +0000",
    "user" : {
      "name" : "Sinorice Moss",
      "screen_name" : "sinoricemoss",
      "protected" : false,
      "id_str" : "27503901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723666962203566080\/tH-C0VZw_normal.jpg",
      "id" : 27503901,
      "verified" : true
    }
  },
  "id" : 701144598022897664,
  "created_at" : "2016-02-20 20:41:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/701142804999766016\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/uJlOxLDCXj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbr1nRiUkAAIDI4.jpg",
      "id_str" : "701142747080593408",
      "id" : 701142747080593408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbr1nRiUkAAIDI4.jpg",
      "sizes" : [ {
        "h" : 504,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 325
      } ],
      "display_url" : "pic.twitter.com\/uJlOxLDCXj"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 34, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701143401526333444",
  "text" : "RT @FLOTUS: Can't help but smile. #ObamaAndKids https:\/\/t.co\/uJlOxLDCXj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/701142804999766016\/photo\/1",
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/uJlOxLDCXj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbr1nRiUkAAIDI4.jpg",
        "id_str" : "701142747080593408",
        "id" : 701142747080593408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbr1nRiUkAAIDI4.jpg",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 325
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 325
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 325
        }, {
          "h" : 504,
          "resize" : "fit",
          "w" : 325
        } ],
        "display_url" : "pic.twitter.com\/uJlOxLDCXj"
      } ],
      "hashtags" : [ {
        "text" : "ObamaAndKids",
        "indices" : [ 22, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701142804999766016",
    "text" : "Can't help but smile. #ObamaAndKids https:\/\/t.co\/uJlOxLDCXj",
    "id" : 701142804999766016,
    "created_at" : "2016-02-20 20:34:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 701143401526333444,
  "created_at" : "2016-02-20 20:36:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701137925623431171",
  "text" : "RT @petesouza: This photo I made on Thursday has caused people to start tweeting photos of the President w kids #ObamaAndKids https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/701122681496690688\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/WSmAA3Z0It",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbrjW4RUcAAYMEi.jpg",
        "id_str" : "701122674211188736",
        "id" : 701122674211188736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbrjW4RUcAAYMEi.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 454
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 667
        } ],
        "display_url" : "pic.twitter.com\/WSmAA3Z0It"
      } ],
      "hashtags" : [ {
        "text" : "ObamaAndKids",
        "indices" : [ 97, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701122681496690688",
    "text" : "This photo I made on Thursday has caused people to start tweeting photos of the President w kids #ObamaAndKids https:\/\/t.co\/WSmAA3Z0It",
    "id" : 701122681496690688,
    "created_at" : "2016-02-20 19:14:08 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 701137925623431171,
  "created_at" : "2016-02-20 20:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/701133748717289472\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/An5ikZWC3V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbrtUzkWEAEwaNb.jpg",
      "id_str" : "701133633705349121",
      "id" : 701133633705349121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbrtUzkWEAEwaNb.jpg",
      "sizes" : [ {
        "h" : 677,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 677,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 677,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 677,
        "resize" : "fit",
        "w" : 467
      } ],
      "display_url" : "pic.twitter.com\/An5ikZWC3V"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/7R3TB081B6",
      "expanded_url" : "http:\/\/on.fb.me\/1oBeIhO",
      "display_url" : "on.fb.me\/1oBeIhO"
    } ]
  },
  "geo" : { },
  "id_str" : "701133748717289472",
  "text" : "\"Caprina, tell her to dry her tears\" \u2014@POTUS: https:\/\/t.co\/7R3TB081B6 #ObamaAndKids https:\/\/t.co\/An5ikZWC3V",
  "id" : 701133748717289472,
  "created_at" : "2016-02-20 19:58:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ayan C.",
      "screen_name" : "Ayan_SB",
      "indices" : [ 3, 11 ],
      "id_str" : "20902140",
      "id" : 20902140
    }, {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "indices" : [ 13, 28 ],
      "id_str" : "24165761",
      "id" : 24165761
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701118784661274630",
  "text" : "RT @Ayan_SB: @MichaelSkolnik Vidal, who's story was featured on Humans of New York, meeting President Obama. #ObamaAndKids https:\/\/t.co\/d6z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Skolnik",
        "screen_name" : "MichaelSkolnik",
        "indices" : [ 0, 15 ],
        "id_str" : "24165761",
        "id" : 24165761
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Ayan_SB\/status\/701089441344049152\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/d6zQIBod1Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbrFIa9UEAAXFph.jpg",
        "id_str" : "701089440475648000",
        "id" : 701089440475648000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbrFIa9UEAAXFph.jpg",
        "sizes" : [ {
          "h" : 553,
          "resize" : "fit",
          "w" : 830
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 553,
          "resize" : "fit",
          "w" : 830
        }, {
          "h" : 553,
          "resize" : "fit",
          "w" : 830
        } ],
        "display_url" : "pic.twitter.com\/d6zQIBod1Z"
      } ],
      "hashtags" : [ {
        "text" : "ObamaAndKids",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701089441344049152",
    "in_reply_to_user_id" : 24165761,
    "text" : "@MichaelSkolnik Vidal, who's story was featured on Humans of New York, meeting President Obama. #ObamaAndKids https:\/\/t.co\/d6zQIBod1Z",
    "id" : 701089441344049152,
    "created_at" : "2016-02-20 17:02:03 +0000",
    "in_reply_to_screen_name" : "MichaelSkolnik",
    "in_reply_to_user_id_str" : "24165761",
    "user" : {
      "name" : "Ayan C.",
      "screen_name" : "Ayan_SB",
      "protected" : false,
      "id_str" : "20902140",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755292339535507456\/8n-C86f4_normal.jpg",
      "id" : 20902140,
      "verified" : false
    }
  },
  "id" : 701118784661274630,
  "created_at" : "2016-02-20 18:58:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "indices" : [ 3, 9 ],
      "id_str" : "2800630026",
      "id" : 2800630026
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScienceFair",
      "indices" : [ 81, 93 ]
    }, {
      "text" : "ObamaAndKids",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701117525740937217",
  "text" : "RT @Lee44: .@POTUS listens to six-year-old Girl Scouts from Tulsa describe their #ScienceFair projects last year. #ObamaAndKids https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lee44\/status\/701115279208636417\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/IuGWmBBkBC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbrcoXmWIAACDZP.jpg",
        "id_str" : "701115278097260544",
        "id" : 701115278097260544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbrcoXmWIAACDZP.jpg",
        "sizes" : [ {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        } ],
        "display_url" : "pic.twitter.com\/IuGWmBBkBC"
      } ],
      "hashtags" : [ {
        "text" : "ScienceFair",
        "indices" : [ 70, 82 ]
      }, {
        "text" : "ObamaAndKids",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701115279208636417",
    "text" : ".@POTUS listens to six-year-old Girl Scouts from Tulsa describe their #ScienceFair projects last year. #ObamaAndKids https:\/\/t.co\/IuGWmBBkBC",
    "id" : 701115279208636417,
    "created_at" : "2016-02-20 18:44:43 +0000",
    "user" : {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "protected" : false,
      "id_str" : "2800630026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626378024359870464\/dc8kq4yl_normal.png",
      "id" : 2800630026,
      "verified" : true
    }
  },
  "id" : 701117525740937217,
  "created_at" : "2016-02-20 18:53:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "I'm just sayin'",
      "screen_name" : "benzita04",
      "indices" : [ 3, 13 ],
      "id_str" : "547863663",
      "id" : 547863663
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/benzita04\/status\/701074019903209472\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/IpegFOEHar",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbq3GvDW4AAQh9V.jpg",
      "id_str" : "701074018347180032",
      "id" : 701074018347180032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbq3GvDW4AAQh9V.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IpegFOEHar"
    } ],
    "hashtags" : [ {
      "text" : "ObamaAndKids",
      "indices" : [ 55, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701116143256338432",
  "text" : "RT @benzita04: This will forever be my favorite pic of #ObamaAndKids. Powerful message behind it. https:\/\/t.co\/IpegFOEHar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/benzita04\/status\/701074019903209472\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/IpegFOEHar",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbq3GvDW4AAQh9V.jpg",
        "id_str" : "701074018347180032",
        "id" : 701074018347180032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbq3GvDW4AAQh9V.jpg",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IpegFOEHar"
      } ],
      "hashtags" : [ {
        "text" : "ObamaAndKids",
        "indices" : [ 40, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701074019903209472",
    "text" : "This will forever be my favorite pic of #ObamaAndKids. Powerful message behind it. https:\/\/t.co\/IpegFOEHar",
    "id" : 701074019903209472,
    "created_at" : "2016-02-20 16:00:46 +0000",
    "user" : {
      "name" : "I'm just sayin'",
      "screen_name" : "benzita04",
      "protected" : false,
      "id_str" : "547863663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662365602280030208\/avn-LMJP_normal.jpg",
      "id" : 547863663,
      "verified" : false
    }
  },
  "id" : 701116143256338432,
  "created_at" : "2016-02-20 18:48:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "indices" : [ 3, 18 ],
      "id_str" : "24165761",
      "id" : 24165761
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 83, 95 ],
      "id_str" : "813286",
      "id" : 813286
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 124, 134 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701115271285702656",
  "text" : "RT @MichaelSkolnik: We'll never truly be able to measure the impact that President @BarackObama has had on our children.\n\uD83D\uDCF7: @petesouza http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 63, 75 ],
        "id_str" : "813286",
        "id" : 813286
      }, {
        "name" : "petesouza",
        "screen_name" : "petesouza",
        "indices" : [ 104, 114 ],
        "id_str" : "18215973",
        "id" : 18215973
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MichaelSkolnik\/status\/701040383879417856\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/3nvpRJyAiJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbqYgbvW4AE3A-W.jpg",
        "id_str" : "701040374979158017",
        "id" : 701040374979158017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbqYgbvW4AE3A-W.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 462
        }, {
          "h" : 1271,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1271,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 816
        } ],
        "display_url" : "pic.twitter.com\/3nvpRJyAiJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "701040383879417856",
    "text" : "We'll never truly be able to measure the impact that President @BarackObama has had on our children.\n\uD83D\uDCF7: @petesouza https:\/\/t.co\/3nvpRJyAiJ",
    "id" : 701040383879417856,
    "created_at" : "2016-02-20 13:47:06 +0000",
    "user" : {
      "name" : "Michael Skolnik",
      "screen_name" : "MichaelSkolnik",
      "protected" : false,
      "id_str" : "24165761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738364600220045313\/L-103cVr_normal.jpg",
      "id" : 24165761,
      "verified" : true
    }
  },
  "id" : 701115271285702656,
  "created_at" : "2016-02-20 18:44:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaVisit",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/aXJhut5C1F",
      "expanded_url" : "http:\/\/go.wh.gov\/3ESSLY",
      "display_url" : "go.wh.gov\/3ESSLY"
    } ]
  },
  "geo" : { },
  "id_str" : "701109495989198848",
  "text" : "\"This week, we made it official\u2014I\u2019m going to Cuba.\" \u2014@POTUS\nWatch his weekly address. #CubaVisit https:\/\/t.co\/aXJhut5C1F",
  "id" : 701109495989198848,
  "created_at" : "2016-02-20 18:21:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 17, 24 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700885551826628609\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/BLjWzOcGcf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CboLnFnWIAIw5Wf.jpg",
      "id_str" : "700885458159542274",
      "id" : 700885458159542274,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CboLnFnWIAIw5Wf.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/BLjWzOcGcf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700885551826628609",
  "text" : "Today @POTUS and @FLOTUS paid their respects to Justice Antonin Scalia in the Great Hall of the Supreme Court. https:\/\/t.co\/BLjWzOcGcf",
  "id" : 700885551826628609,
  "created_at" : "2016-02-20 03:31:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700813758252326912",
  "text" : "RT @FLOTUS: \u201CShe showed us the beautiful complexity of our common humanity.\u201D \u2014@POTUS and the First Lady on Harper Lee https:\/\/t.co\/BejEvuE1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 66, 72 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/700811165090365440\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/BejEvuE1a2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbnG1pIVIAAVDtc.jpg",
        "id_str" : "700809841908981760",
        "id" : 700809841908981760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbnG1pIVIAAVDtc.jpg",
        "sizes" : [ {
          "h" : 364,
          "resize" : "fit",
          "w" : 487
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 487
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 487
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 487
        } ],
        "display_url" : "pic.twitter.com\/BejEvuE1a2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700811165090365440",
    "text" : "\u201CShe showed us the beautiful complexity of our common humanity.\u201D \u2014@POTUS and the First Lady on Harper Lee https:\/\/t.co\/BejEvuE1a2",
    "id" : 700811165090365440,
    "created_at" : "2016-02-19 22:36:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 700813758252326912,
  "created_at" : "2016-02-19 22:46:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700804522453544960\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/KNXYShtkoy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbnB6IwW4AAfc_r.jpg",
      "id_str" : "700804421559705600",
      "id" : 700804421559705600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbnB6IwW4AAfc_r.jpg",
      "sizes" : [ {
        "h" : 368,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 492
      } ],
      "display_url" : "pic.twitter.com\/KNXYShtkoy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/IXc3MOMZR0",
      "expanded_url" : "http:\/\/on.fb.me\/1Tr2XWd",
      "display_url" : "on.fb.me\/1Tr2XWd"
    } ]
  },
  "geo" : { },
  "id_str" : "700804522453544960",
  "text" : "\"Ms. Lee changed America for the better.\" \u2014@POTUS on Harper Lee: https:\/\/t.co\/IXc3MOMZR0 https:\/\/t.co\/KNXYShtkoy",
  "id" : 700804522453544960,
  "created_at" : "2016-02-19 22:09:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/lh5bkADLw6",
      "expanded_url" : "http:\/\/www.cops.usdoj.gov\/pdf\/taskforce\/taskforce_finalreport.pdf",
      "display_url" : "cops.usdoj.gov\/pdf\/taskforce\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700782333251551232",
  "text" : "RT @vj44: Important recommendation from 21st Century Task Force report was regarding the use of force: https:\/\/t.co\/lh5bkADLw6 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/lh5bkADLw6",
        "expanded_url" : "http:\/\/www.cops.usdoj.gov\/pdf\/taskforce\/taskforce_finalreport.pdf",
        "display_url" : "cops.usdoj.gov\/pdf\/taskforce\/\u2026"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/A4R4Q6tmAF",
        "expanded_url" : "https:\/\/twitter.com\/deray\/status\/700777555930951680",
        "display_url" : "twitter.com\/deray\/status\/7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700779260357844994",
    "text" : "Important recommendation from 21st Century Task Force report was regarding the use of force: https:\/\/t.co\/lh5bkADLw6 https:\/\/t.co\/A4R4Q6tmAF",
    "id" : 700779260357844994,
    "created_at" : "2016-02-19 20:29:30 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 700782333251551232,
  "created_at" : "2016-02-19 20:41:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700781006236700672",
  "text" : "RT @vj44: I agree. Change happens when ordinary citizens fully engage w\/ their elected representatives. That means showing up! https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/oBA1af199h",
        "expanded_url" : "https:\/\/twitter.com\/MsPackyetti\/status\/700779839301804032",
        "display_url" : "twitter.com\/MsPackyetti\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700780488697495552",
    "text" : "I agree. Change happens when ordinary citizens fully engage w\/ their elected representatives. That means showing up! https:\/\/t.co\/oBA1af199h",
    "id" : 700780488697495552,
    "created_at" : "2016-02-19 20:34:23 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 700781006236700672,
  "created_at" : "2016-02-19 20:36:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700775434082910209",
  "text" : "RT @DrBiden: Love teaching To Kill a Mockingbird. As one of America's greatest novelists, Harper Lee will be missed but her work will live \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700775005349515264",
    "text" : "Love teaching To Kill a Mockingbird. As one of America's greatest novelists, Harper Lee will be missed but her work will live on. \u2014Jill",
    "id" : 700775005349515264,
    "created_at" : "2016-02-19 20:12:35 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 700775434082910209,
  "created_at" : "2016-02-19 20:14:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeAnAstronaut",
      "indices" : [ 48, 62 ]
    }, {
      "text" : "JourneyToMars",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/tuCcCftDYy",
      "expanded_url" : "http:\/\/go.nasa.gov\/1TuJkOk",
      "display_url" : "go.nasa.gov\/1TuJkOk"
    } ]
  },
  "geo" : { },
  "id_str" : "700749672550371328",
  "text" : "RT @NASA: Record number of Americans applied to #BeAnAstronaut &amp; contribute to our #JourneyToMars: https:\/\/t.co\/tuCcCftDYy https:\/\/t.co\/Y2a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/700729445850685440\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Y2aFYjwNuR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbl9t9tW8AEdZOj.jpg",
        "id_str" : "700729445645217793",
        "id" : 700729445645217793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbl9t9tW8AEdZOj.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Y2aFYjwNuR"
      } ],
      "hashtags" : [ {
        "text" : "BeAnAstronaut",
        "indices" : [ 38, 52 ]
      }, {
        "text" : "JourneyToMars",
        "indices" : [ 77, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/tuCcCftDYy",
        "expanded_url" : "http:\/\/go.nasa.gov\/1TuJkOk",
        "display_url" : "go.nasa.gov\/1TuJkOk"
      } ]
    },
    "geo" : { },
    "id_str" : "700729445850685440",
    "text" : "Record number of Americans applied to #BeAnAstronaut &amp; contribute to our #JourneyToMars: https:\/\/t.co\/tuCcCftDYy https:\/\/t.co\/Y2aFYjwNuR",
    "id" : 700729445850685440,
    "created_at" : "2016-02-19 17:11:33 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 700749672550371328,
  "created_at" : "2016-02-19 18:31:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "deray mckesson",
      "screen_name" : "deray",
      "indices" : [ 62, 68 ],
      "id_str" : "29417304",
      "id" : 29417304
    }, {
      "name" : "Brittany Packnett",
      "screen_name" : "MsPackyetti",
      "indices" : [ 75, 87 ],
      "id_str" : "239509917",
      "id" : 239509917
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 109, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700746452843294720",
  "text" : "RT @vj44: Recapping WH meeting with Civil Rights activists w\/ @deray\n&amp; @MsPackyetti.\nAsk Qs by 3pm ET w\/ #BlackHistoryMonth https:\/\/t.co\/CZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "deray mckesson",
        "screen_name" : "deray",
        "indices" : [ 52, 58 ],
        "id_str" : "29417304",
        "id" : 29417304
      }, {
        "name" : "Brittany Packnett",
        "screen_name" : "MsPackyetti",
        "indices" : [ 65, 77 ],
        "id_str" : "239509917",
        "id" : 239509917
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/700719294988943360\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/CZZ5ZwB7yJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbl0fC-UcAAxDKF.jpg",
        "id_str" : "700719293755846656",
        "id" : 700719293755846656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbl0fC-UcAAxDKF.jpg",
        "sizes" : [ {
          "h" : 936,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2253,
          "resize" : "fit",
          "w" : 2889
        }, {
          "h" : 1597,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/CZZ5ZwB7yJ"
      } ],
      "hashtags" : [ {
        "text" : "BlackHistoryMonth",
        "indices" : [ 99, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700719294988943360",
    "text" : "Recapping WH meeting with Civil Rights activists w\/ @deray\n&amp; @MsPackyetti.\nAsk Qs by 3pm ET w\/ #BlackHistoryMonth https:\/\/t.co\/CZZ5ZwB7yJ",
    "id" : 700719294988943360,
    "created_at" : "2016-02-19 16:31:13 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 700746452843294720,
  "created_at" : "2016-02-19 18:19:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700741554193965056\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/jdr8y6pCLJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbmIlENVAAAL3pH.jpg",
      "id_str" : "700741387399004160",
      "id" : 700741387399004160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbmIlENVAAAL3pH.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1012
      }, {
        "h" : 1281,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 573
      }, {
        "h" : 1281,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/jdr8y6pCLJ"
    } ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 90, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700741554193965056",
  "text" : "Every child, no matter who they are, should have the opportunity to achieve their dreams. #BlackHistoryMonth https:\/\/t.co\/jdr8y6pCLJ",
  "id" : 700741554193965056,
  "created_at" : "2016-02-19 17:59:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700495399505690624",
  "text" : "RT @vj44: Extraordinary moment to see three generations of Dr. MLK Jr.'s family in the Oval today. #BlackHistoryMonth https:\/\/t.co\/rtJimuJc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/700474121734352897\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/rtJimuJcMN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbiVgFSUEAAeM6s.jpg",
        "id_str" : "700474120463454208",
        "id" : 700474120463454208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbiVgFSUEAAeM6s.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 4032,
          "resize" : "fit",
          "w" : 3024
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rtJimuJcMN"
      } ],
      "hashtags" : [ {
        "text" : "BlackHistoryMonth",
        "indices" : [ 89, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700474121734352897",
    "text" : "Extraordinary moment to see three generations of Dr. MLK Jr.'s family in the Oval today. #BlackHistoryMonth https:\/\/t.co\/rtJimuJcMN",
    "id" : 700474121734352897,
    "created_at" : "2016-02-19 00:16:59 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 700495399505690624,
  "created_at" : "2016-02-19 01:41:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700493565516861444",
  "text" : "RT @Denis44: 28 years ago today, Justice Kennedy was sworn into office. Some wise words from the President who appointed him: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Denis44\/status\/700492971758620672\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/nIWwjAAO66",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbimozUUcAA_pg2.jpg",
        "id_str" : "700492961956524032",
        "id" : 700492961956524032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbimozUUcAA_pg2.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/nIWwjAAO66"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700492971758620672",
    "text" : "28 years ago today, Justice Kennedy was sworn into office. Some wise words from the President who appointed him: https:\/\/t.co\/nIWwjAAO66",
    "id" : 700492971758620672,
    "created_at" : "2016-02-19 01:31:53 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 700493565516861444,
  "created_at" : "2016-02-19 01:34:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700486020714860544\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/VrdmL6hI6m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbif0XhUUAADILo.jpg",
      "id_str" : "700485464071884800",
      "id" : 700485464071884800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbif0XhUUAADILo.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/VrdmL6hI6m"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/wrn87AnPMo",
      "expanded_url" : "http:\/\/go.wh.gov\/gVCMcd",
      "display_url" : "go.wh.gov\/gVCMcd"
    } ]
  },
  "geo" : { },
  "id_str" : "700486020714860544",
  "text" : "\"Give it up for the Stanley Cup champs\u2014my hometown Chicago Blackhawks!\" \u2014@POTUS: https:\/\/t.co\/wrn87AnPMo https:\/\/t.co\/VrdmL6hI6m",
  "id" : 700486020714860544,
  "created_at" : "2016-02-19 01:04:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoani S\u00E1nchez",
      "screen_name" : "yoanisanchez",
      "indices" : [ 3, 16 ],
      "id_str" : "15973392",
      "id" : 15973392
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cubana",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/3wcTTsXkgD",
      "expanded_url" : "http:\/\/www.14ymedio.com\/blogs\/generacion_y\/visita-simbolica-politica_7_1946875295.html",
      "display_url" : "14ymedio.com\/blogs\/generaci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700445517428473856",
  "text" : "RT @yoanisanchez: \u00BFC\u00F3mo reaccionar\u00E1 poblaci\u00F3n #cubana ante visita de Barack Obama @POTUS? Con alegr\u00EDa y alivio https:\/\/t.co\/3wcTTsXkgD http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 64, 70 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/yoanisanchez\/status\/700374103971135488\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/j4qvVogDzA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbg6iTcVIAAXNLl.png",
        "id_str" : "700374103065174016",
        "id" : 700374103065174016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbg6iTcVIAAXNLl.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/j4qvVogDzA"
      } ],
      "hashtags" : [ {
        "text" : "cubana",
        "indices" : [ 28, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/3wcTTsXkgD",
        "expanded_url" : "http:\/\/www.14ymedio.com\/blogs\/generacion_y\/visita-simbolica-politica_7_1946875295.html",
        "display_url" : "14ymedio.com\/blogs\/generaci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700374103971135488",
    "text" : "\u00BFC\u00F3mo reaccionar\u00E1 poblaci\u00F3n #cubana ante visita de Barack Obama @POTUS? Con alegr\u00EDa y alivio https:\/\/t.co\/3wcTTsXkgD https:\/\/t.co\/j4qvVogDzA",
    "id" : 700374103971135488,
    "created_at" : "2016-02-18 17:39:33 +0000",
    "user" : {
      "name" : "Yoani S\u00E1nchez",
      "screen_name" : "yoanisanchez",
      "protected" : false,
      "id_str" : "15973392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664596018797944832\/6ai2mx5M_normal.png",
      "id" : 15973392,
      "verified" : true
    }
  },
  "id" : 700445517428473856,
  "created_at" : "2016-02-18 22:23:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700444155319705600",
  "text" : "RT @rhodes44: Calls for @POTUS to reverse course on Cuba ignore history &amp; Cubans' desire for a new chapter. This is what's right. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/jcvR4qgegQ",
        "expanded_url" : "http:\/\/snpy.tv\/1QMbbUh",
        "display_url" : "snpy.tv\/1QMbbUh"
      } ]
    },
    "geo" : { },
    "id_str" : "700442329396543489",
    "text" : "Calls for @POTUS to reverse course on Cuba ignore history &amp; Cubans' desire for a new chapter. This is what's right. https:\/\/t.co\/jcvR4qgegQ",
    "id" : 700442329396543489,
    "created_at" : "2016-02-18 22:10:39 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 700444155319705600,
  "created_at" : "2016-02-18 22:17:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 85, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700439921711050752",
  "text" : "\"It's that effort to form 'a more perfect union' that marks us as a people.\" \u2014@POTUS #BlackHistoryMonth",
  "id" : 700439921711050752,
  "created_at" : "2016-02-18 22:01:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 68, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700439441383563264",
  "text" : "\"That\u2019s the thing about our democracy. It takes all of us.\" \u2014@POTUS #BlackHistoryMonth",
  "id" : 700439441383563264,
  "created_at" : "2016-02-18 21:59:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700438566837620736\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Dap5tjz1Sd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbh1F16XEAAFdXo.jpg",
      "id_str" : "700438485287768064",
      "id" : 700438485287768064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbh1F16XEAAFdXo.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Dap5tjz1Sd"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700438566837620736\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Dap5tjz1Sd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbh1HP3WAAAhoLT.jpg",
      "id_str" : "700438509434306560",
      "id" : 700438509434306560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbh1HP3WAAAhoLT.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/Dap5tjz1Sd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700438566837620736",
  "text" : "\"African-American culture has profoundly shaped American culture, in music and art, literature and sports.\" \u2014@POTUS https:\/\/t.co\/Dap5tjz1Sd",
  "id" : 700438566837620736,
  "created_at" : "2016-02-18 21:55:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700438332237545472\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Pqfh02Lsn1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbh06gPW4AA0u_Q.jpg",
      "id_str" : "700438290491695104",
      "id" : 700438290491695104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbh06gPW4AA0u_Q.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Pqfh02Lsn1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700438332237545472",
  "text" : "\"We stand on the shoulders of...countless, nameless heroes who marched for equality and justice for all.\" \u2014@POTUS https:\/\/t.co\/Pqfh02Lsn1",
  "id" : 700438332237545472,
  "created_at" : "2016-02-18 21:54:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 38, 45 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 56, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/DuXMyi4KFB",
      "expanded_url" : "http:\/\/go.wh.gov\/FbWa1j",
      "display_url" : "go.wh.gov\/FbWa1j"
    }, {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/j6W9QTWuKX",
      "expanded_url" : "http:\/\/snpy.tv\/1PS8Ryu",
      "display_url" : "snpy.tv\/1PS8Ryu"
    } ]
  },
  "geo" : { },
  "id_str" : "700437699791085568",
  "text" : "RT @WHLive: Happening now: @POTUS and @FLOTUS celebrate #BlackHistoryMonth \u2192 https:\/\/t.co\/DuXMyi4KFB https:\/\/t.co\/j6W9QTWuKX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 26, 33 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackHistoryMonth",
        "indices" : [ 44, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/DuXMyi4KFB",
        "expanded_url" : "http:\/\/go.wh.gov\/FbWa1j",
        "display_url" : "go.wh.gov\/FbWa1j"
      }, {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/j6W9QTWuKX",
        "expanded_url" : "http:\/\/snpy.tv\/1PS8Ryu",
        "display_url" : "snpy.tv\/1PS8Ryu"
      } ]
    },
    "geo" : { },
    "id_str" : "700437539266629636",
    "text" : "Happening now: @POTUS and @FLOTUS celebrate #BlackHistoryMonth \u2192 https:\/\/t.co\/DuXMyi4KFB https:\/\/t.co\/j6W9QTWuKX",
    "id" : 700437539266629636,
    "created_at" : "2016-02-18 21:51:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 700437699791085568,
  "created_at" : "2016-02-18 21:52:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 33, 40 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 51, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/bhu76FJtS9",
      "expanded_url" : "http:\/\/go.wh.gov\/FbWa1j",
      "display_url" : "go.wh.gov\/FbWa1j"
    } ]
  },
  "geo" : { },
  "id_str" : "700433423563943937",
  "text" : "Tune in at 4:40pm ET: @POTUS and @FLOTUS celebrate #BlackHistoryMonth at the White House \u2192 https:\/\/t.co\/bhu76FJtS9",
  "id" : 700433423563943937,
  "created_at" : "2016-02-18 21:35:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700416535685369859\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/DQKdVRVW7C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbhhCLCWEAERg7g.jpg",
      "id_str" : "700416432006369281",
      "id" : 700416432006369281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbhhCLCWEAERg7g.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DQKdVRVW7C"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700416535685369859",
  "text" : "Since 1975, it's only taken an average of 67 days to confirm a president's nominee to the Supreme Court. #SCOTUS https:\/\/t.co\/DQKdVRVW7C",
  "id" : 700416535685369859,
  "created_at" : "2016-02-18 20:28:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 3, 19 ],
      "id_str" : "234141596",
      "id" : 234141596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CT",
      "indices" : [ 24, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/MsW8d9p8ti",
      "expanded_url" : "http:\/\/portal.ct.gov\/Departments_and_Agencies\/Office_of_the_Governor\/Press_Room\/Press_Releases\/2016\/02-2016\/Gov__Malloy_Announces_Connecticut_Receives_Federal_Certification_of_Effectively_Eliminating_Veteran_Homelessness\/",
      "display_url" : "portal.ct.gov\/Departments_an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "700403002348331009",
  "text" : "RT @GovMalloyOffice: In #CT, we're taking major, unprecedented steps to ensure housing for our nation's veterans: https:\/\/t.co\/MsW8d9p8ti h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GovMalloyOffice\/status\/700395825382432768\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/byuqguC4vc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbhOSonUkAA0nKo.jpg",
        "id_str" : "700395824103067648",
        "id" : 700395824103067648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbhOSonUkAA0nKo.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 972,
          "resize" : "fit",
          "w" : 1944
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/byuqguC4vc"
      } ],
      "hashtags" : [ {
        "text" : "CT",
        "indices" : [ 3, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/MsW8d9p8ti",
        "expanded_url" : "http:\/\/portal.ct.gov\/Departments_and_Agencies\/Office_of_the_Governor\/Press_Room\/Press_Releases\/2016\/02-2016\/Gov__Malloy_Announces_Connecticut_Receives_Federal_Certification_of_Effectively_Eliminating_Veteran_Homelessness\/",
        "display_url" : "portal.ct.gov\/Departments_an\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700395825382432768",
    "text" : "In #CT, we're taking major, unprecedented steps to ensure housing for our nation's veterans: https:\/\/t.co\/MsW8d9p8ti https:\/\/t.co\/byuqguC4vc",
    "id" : 700395825382432768,
    "created_at" : "2016-02-18 19:05:52 +0000",
    "user" : {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "protected" : false,
      "id_str" : "234141596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738519424223858688\/_0xQvvKS_normal.jpg",
      "id" : 234141596,
      "verified" : true
    }
  },
  "id" : 700403002348331009,
  "created_at" : "2016-02-18 19:34:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaVisit",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/2c62oMNrmD",
      "expanded_url" : "https:\/\/medium.com\/@rhodes44\/president-obama-is-going-to-cuba-here-s-why-41ecdc0586d8#.tleuhtxhb",
      "display_url" : "medium.com\/@rhodes44\/pres\u2026"
    }, {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/VhAv9WGnw5",
      "expanded_url" : "http:\/\/snpy.tv\/1XA7N3W",
      "display_url" : "snpy.tv\/1XA7N3W"
    } ]
  },
  "geo" : { },
  "id_str" : "700392471960940545",
  "text" : "RT @NSC44: In March, @POTUS will travel to Cuba. Here\u2019s why: https:\/\/t.co\/2c62oMNrmD\n#CubaVisit \nhttps:\/\/t.co\/VhAv9WGnw5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CubaVisit",
        "indices" : [ 74, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/2c62oMNrmD",
        "expanded_url" : "https:\/\/medium.com\/@rhodes44\/president-obama-is-going-to-cuba-here-s-why-41ecdc0586d8#.tleuhtxhb",
        "display_url" : "medium.com\/@rhodes44\/pres\u2026"
      }, {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/VhAv9WGnw5",
        "expanded_url" : "http:\/\/snpy.tv\/1XA7N3W",
        "display_url" : "snpy.tv\/1XA7N3W"
      } ]
    },
    "geo" : { },
    "id_str" : "700384039937507328",
    "text" : "In March, @POTUS will travel to Cuba. Here\u2019s why: https:\/\/t.co\/2c62oMNrmD\n#CubaVisit \nhttps:\/\/t.co\/VhAv9WGnw5",
    "id" : 700384039937507328,
    "created_at" : "2016-02-18 18:19:02 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 700392471960940545,
  "created_at" : "2016-02-18 18:52:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Chicago Blackhawks",
      "screen_name" : "NHLBlackhawks",
      "indices" : [ 57, 71 ],
      "id_str" : "14498484",
      "id" : 14498484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/hHd0vycfV1",
      "expanded_url" : "http:\/\/snpy.tv\/1ou4eRf",
      "display_url" : "snpy.tv\/1ou4eRf"
    } ]
  },
  "geo" : { },
  "id_str" : "700370229172551680",
  "text" : "Watch @POTUS honor the 2015 Stanley Cup champion Chicago @NHLBlackhawks. https:\/\/t.co\/hHd0vycfV1",
  "id" : 700370229172551680,
  "created_at" : "2016-02-18 17:24:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700354462800572417",
  "text" : "\"For the third time as President, I get to say: Give it up for the Stanley Cup champs \u2013 my hometown Chicago Blackhawks!\" \u2014@POTUS",
  "id" : 700354462800572417,
  "created_at" : "2016-02-18 16:21:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Chicago Blackhawks",
      "screen_name" : "NHLBlackhawks",
      "indices" : [ 71, 85 ],
      "id_str" : "14498484",
      "id" : 14498484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/ZNWxJLSOe0",
      "expanded_url" : "http:\/\/go.wh.gov\/gVCMcd",
      "display_url" : "go.wh.gov\/gVCMcd"
    } ]
  },
  "geo" : { },
  "id_str" : "700354252410060800",
  "text" : "RT @WHLive: Watch live: @POTUS honors the Stanley Cup champion Chicago @NHLBlackhawks \u2192 https:\/\/t.co\/ZNWxJLSOe0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 12, 18 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Chicago Blackhawks",
        "screen_name" : "NHLBlackhawks",
        "indices" : [ 59, 73 ],
        "id_str" : "14498484",
        "id" : 14498484
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/ZNWxJLSOe0",
        "expanded_url" : "http:\/\/go.wh.gov\/gVCMcd",
        "display_url" : "go.wh.gov\/gVCMcd"
      } ]
    },
    "geo" : { },
    "id_str" : "700354217366712321",
    "text" : "Watch live: @POTUS honors the Stanley Cup champion Chicago @NHLBlackhawks \u2192 https:\/\/t.co\/ZNWxJLSOe0",
    "id" : 700354217366712321,
    "created_at" : "2016-02-18 16:20:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 700354252410060800,
  "created_at" : "2016-02-18 16:20:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700352245137805312\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/q2Fa0zXzfX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbgmdN2XIAAfxZH.jpg",
      "id_str" : "700352025431842816",
      "id" : 700352025431842816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbgmdN2XIAAfxZH.jpg",
      "sizes" : [ {
        "h" : 251,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 142,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/q2Fa0zXzfX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/5jPvVh2faS",
      "expanded_url" : "http:\/\/go.wh.gov\/4b4M4z",
      "display_url" : "go.wh.gov\/4b4M4z"
    } ]
  },
  "geo" : { },
  "id_str" : "700352245137805312",
  "text" : ".@POTUS will be the first U.S. President to travel to Cuba since Calvin Coolidge in 1928 \u2192 https:\/\/t.co\/5jPvVh2faS https:\/\/t.co\/q2Fa0zXzfX",
  "id" : 700352245137805312,
  "created_at" : "2016-02-18 16:12:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700348547179405313",
  "text" : "RT @Denis44: Un momento importante: El Presidente viajar\u00E1 a Cuba para avanzar nuestro progreso y mejorar las vidas de los Cubanos https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/k28PUiFNWQ",
        "expanded_url" : "http:\/\/go.wh.gov\/7otN9Y",
        "display_url" : "go.wh.gov\/7otN9Y"
      } ]
    },
    "geo" : { },
    "id_str" : "700348394129268736",
    "text" : "Un momento importante: El Presidente viajar\u00E1 a Cuba para avanzar nuestro progreso y mejorar las vidas de los Cubanos https:\/\/t.co\/k28PUiFNWQ",
    "id" : 700348394129268736,
    "created_at" : "2016-02-18 15:57:23 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 700348547179405313,
  "created_at" : "2016-02-18 15:58:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaVisit",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/8YiCH88N1x",
      "expanded_url" : "http:\/\/go.wh.gov\/4b4M4z",
      "display_url" : "go.wh.gov\/4b4M4z"
    } ]
  },
  "geo" : { },
  "id_str" : "700345964020760577",
  "text" : "RT @rhodes44: Why is @POTUS headed to Cuba on March 21? Here's a rundown of how we got here \u2192 https:\/\/t.co\/8YiCH88N1x #CubaVisit https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/700337351973679104\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/XtO0NTbWOF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbgY954UAAAiBeg.jpg",
        "id_str" : "700337193844211712",
        "id" : 700337193844211712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbgY954UAAAiBeg.jpg",
        "sizes" : [ {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XtO0NTbWOF"
      } ],
      "hashtags" : [ {
        "text" : "CubaVisit",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/8YiCH88N1x",
        "expanded_url" : "http:\/\/go.wh.gov\/4b4M4z",
        "display_url" : "go.wh.gov\/4b4M4z"
      } ]
    },
    "in_reply_to_status_id_str" : "700336396964212737",
    "geo" : { },
    "id_str" : "700337351973679104",
    "in_reply_to_user_id" : 249722522,
    "text" : "Why is @POTUS headed to Cuba on March 21? Here's a rundown of how we got here \u2192 https:\/\/t.co\/8YiCH88N1x #CubaVisit https:\/\/t.co\/XtO0NTbWOF",
    "id" : 700337351973679104,
    "in_reply_to_status_id" : 700336396964212737,
    "created_at" : "2016-02-18 15:13:31 +0000",
    "in_reply_to_screen_name" : "rhodes44",
    "in_reply_to_user_id_str" : "249722522",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 700345964020760577,
  "created_at" : "2016-02-18 15:47:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700337404054376449",
  "text" : "RT @AmbassadorRice: #Cuba visit will allow @POTUS to discuss progress over 1+ year and, more importantly, continued disagreements, incl. ov\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 23, 29 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700329741920948224",
    "text" : "#Cuba visit will allow @POTUS to discuss progress over 1+ year and, more importantly, continued disagreements, incl. over human rights",
    "id" : 700329741920948224,
    "created_at" : "2016-02-18 14:43:16 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 700337404054376449,
  "created_at" : "2016-02-18 15:13:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700336868555030530",
  "text" : "RT @AmbassadorRice: .@POTUS travel to #Cuba will be next major step in our commitment to a new approach of engagement rather than a failed \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 18, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700329683330670592",
    "text" : ".@POTUS travel to #Cuba will be next major step in our commitment to a new approach of engagement rather than a failed policy of isolation",
    "id" : 700329683330670592,
    "created_at" : "2016-02-18 14:43:02 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 700336868555030530,
  "created_at" : "2016-02-18 15:11:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/a0KcsmpF39",
      "expanded_url" : "http:\/\/go.wh.gov\/4b4M4z",
      "display_url" : "go.wh.gov\/4b4M4z"
    } ]
  },
  "geo" : { },
  "id_str" : "700322187962642432",
  "text" : "RT @POTUS: Here's how we're looking at the road ahead: https:\/\/t.co\/a0KcsmpF39",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/a0KcsmpF39",
        "expanded_url" : "http:\/\/go.wh.gov\/4b4M4z",
        "display_url" : "go.wh.gov\/4b4M4z"
      } ]
    },
    "in_reply_to_status_id_str" : "700320240022921216",
    "geo" : { },
    "id_str" : "700320856858189824",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Here's how we're looking at the road ahead: https:\/\/t.co\/a0KcsmpF39",
    "id" : 700320856858189824,
    "in_reply_to_status_id" : 700320240022921216,
    "created_at" : "2016-02-18 14:07:58 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 700322187962642432,
  "created_at" : "2016-02-18 14:13:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700320430436052992",
  "text" : "RT @POTUS: Next month, I'll travel to Cuba to advance our progress and efforts that can improve the lives of the Cuban people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "700319754054074368",
    "geo" : { },
    "id_str" : "700320240022921216",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Next month, I'll travel to Cuba to advance our progress and efforts that can improve the lives of the Cuban people.",
    "id" : 700320240022921216,
    "in_reply_to_status_id" : 700319754054074368,
    "created_at" : "2016-02-18 14:05:31 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 700320430436052992,
  "created_at" : "2016-02-18 14:06:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700320047848357888",
  "text" : "RT @POTUS: We still have differences with the Cuban government that I will raise directly. America will always stand for human rights aroun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "700319236451741697",
    "geo" : { },
    "id_str" : "700319754054074368",
    "in_reply_to_user_id" : 1536791610,
    "text" : "We still have differences with the Cuban government that I will raise directly. America will always stand for human rights around the world.",
    "id" : 700319754054074368,
    "in_reply_to_status_id" : 700319236451741697,
    "created_at" : "2016-02-18 14:03:35 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 700320047848357888,
  "created_at" : "2016-02-18 14:04:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700319495131439104",
  "text" : "RT @POTUS: Our flag flies over our Embassy in Havana once again. More Americans are traveling to Cuba than at any time in the last 50 years.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "700318872147066880",
    "geo" : { },
    "id_str" : "700319236451741697",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Our flag flies over our Embassy in Havana once again. More Americans are traveling to Cuba than at any time in the last 50 years.",
    "id" : 700319236451741697,
    "in_reply_to_status_id" : 700318872147066880,
    "created_at" : "2016-02-18 14:01:31 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 700319495131439104,
  "created_at" : "2016-02-18 14:02:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700319173038227456",
  "text" : "RT @POTUS: 14 months ago, I announced that we would begin normalizing relations with Cuba - and we've already made significant progress.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "700318872147066880",
    "text" : "14 months ago, I announced that we would begin normalizing relations with Cuba - and we've already made significant progress.",
    "id" : 700318872147066880,
    "created_at" : "2016-02-18 14:00:05 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 700319173038227456,
  "created_at" : "2016-02-18 14:01:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700129900812828672\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/EO0HhwAk3n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbdcVf_W4AAl-mN.jpg",
      "id_str" : "700129791513649152",
      "id" : 700129791513649152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbdcVf_W4AAl-mN.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EO0HhwAk3n"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 23, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700129900812828672",
  "text" : "Without a 9th Justice, #SCOTUS's 4-4 decisions can't legally establish uniform, nationwide rules. https:\/\/t.co\/EO0HhwAk3n",
  "id" : 700129900812828672,
  "created_at" : "2016-02-18 01:29:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700114571701415936\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/LRuIiB9dW5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbdOYoUXIAAn8GG.jpg",
      "id_str" : "700114452126048256",
      "id" : 700114452126048256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbdOYoUXIAAn8GG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LRuIiB9dW5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700114571701415936",
  "text" : "\"The Federal judiciary is too important to be made a political football\" \u2014Reagan on Justice Kennedy's confirmation https:\/\/t.co\/LRuIiB9dW5",
  "id" : 700114571701415936,
  "created_at" : "2016-02-18 00:28:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/700095766375731200\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/dgPZ8bum9n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbc9FV1WcAAWObY.jpg",
      "id_str" : "700095429048954880",
      "id" : 700095429048954880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbc9FV1WcAAWObY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dgPZ8bum9n"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/O5iYU0VkHB",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "700095766375731200",
  "text" : "A vacancy on the Supreme Court for the better part of two Terms would be unprecedented \u2192 https:\/\/t.co\/O5iYU0VkHB https:\/\/t.co\/dgPZ8bum9n",
  "id" : 700095766375731200,
  "created_at" : "2016-02-17 23:13:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700082322771570688\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/4LEMV493w4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cbcthh5WIAAJxoJ.jpg",
      "id_str" : "700078321137229824",
      "id" : 700078321137229824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cbcthh5WIAAJxoJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4LEMV493w4"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/O5iYU0VkHB",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "700082322771570688",
  "text" : "FACT: Since 1900, 6 justices have been confirmed in a presidential election year \u2192 https:\/\/t.co\/O5iYU0VkHB #SCOTUS https:\/\/t.co\/4LEMV493w4",
  "id" : 700082322771570688,
  "created_at" : "2016-02-17 22:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/700077426207039489\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/NgA7Rh5iWm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbcslrFWwAIXr6-.jpg",
      "id_str" : "700077292811370498",
      "id" : 700077292811370498,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbcslrFWwAIXr6-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NgA7Rh5iWm"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/O5iYU1cW6b",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "700077426207039489",
  "text" : "The last time a Supreme Court nominee was denied a hearing?\n \n1875.\n\nhttps:\/\/t.co\/O5iYU1cW6b #SCOTUS https:\/\/t.co\/NgA7Rh5iWm",
  "id" : 700077426207039489,
  "created_at" : "2016-02-17 22:00:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/700074521689255936\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/MQp6pz6ekS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbcpkthXEAUGvnj.jpg",
      "id_str" : "700073977750949893",
      "id" : 700073977750949893,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbcpkthXEAUGvnj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MQp6pz6ekS"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/O5iYU1cW6b",
      "expanded_url" : "http:\/\/go.wh.gov\/SCOTUS",
      "display_url" : "go.wh.gov\/SCOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "700074521689255936",
  "text" : "Every U.S. Supreme Court nominee in history has received a vote within 125 days \u2192 https:\/\/t.co\/O5iYU1cW6b #SCOTUS https:\/\/t.co\/MQp6pz6ekS",
  "id" : 700074521689255936,
  "created_at" : "2016-02-17 21:49:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/700049569158205440\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/m4qZopalJb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbcTJHwWIAEPkBE.jpg",
      "id_str" : "700049314500976641",
      "id" : 700049314500976641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbcTJHwWIAEPkBE.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/m4qZopalJb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/pgf8r2X8TS",
      "expanded_url" : "http:\/\/go.wh.gov\/T3W7d1",
      "display_url" : "go.wh.gov\/T3W7d1"
    } ]
  },
  "geo" : { },
  "id_str" : "700049569158205440",
  "text" : ".@VP shares how the Recovery Act has helped rebuild our communities over the past 7 years: https:\/\/t.co\/pgf8r2X8TS https:\/\/t.co\/m4qZopalJb",
  "id" : 700049569158205440,
  "created_at" : "2016-02-17 20:09:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RecoveryAct",
      "indices" : [ 23, 35 ]
    }, {
      "text" : "CleanEnergy",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "700023112436420609",
  "text" : "RT @ENERGY: VIDEO: The #RecoveryAct was passed 7 years ago today. Here's how it helped transform America's #CleanEnergy economy\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RecoveryAct",
        "indices" : [ 11, 23 ]
      }, {
        "text" : "CleanEnergy",
        "indices" : [ 95, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/s6SrEwF9KG",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/c0f18dc7-b5ab-4cd1-b433-b38c752f8c4e",
        "display_url" : "amp.twimg.com\/v\/c0f18dc7-b5a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "700019319531376640",
    "text" : "VIDEO: The #RecoveryAct was passed 7 years ago today. Here's how it helped transform America's #CleanEnergy economy\nhttps:\/\/t.co\/s6SrEwF9KG",
    "id" : 700019319531376640,
    "created_at" : "2016-02-17 18:09:46 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 700023112436420609,
  "created_at" : "2016-02-17 18:24:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/eghMN3UyO5",
      "expanded_url" : "http:\/\/snpy.tv\/1PDJteC",
      "display_url" : "snpy.tv\/1PDJteC"
    } ]
  },
  "geo" : { },
  "id_str" : "699994858866536449",
  "text" : "Watch @POTUS explain why there's more than enough time for the Senate to consider a #SCOTUS nominee he presents. https:\/\/t.co\/eghMN3UyO5",
  "id" : 699994858866536449,
  "created_at" : "2016-02-17 16:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/eghMN3UyO5",
      "expanded_url" : "http:\/\/snpy.tv\/1PDJteC",
      "display_url" : "snpy.tv\/1PDJteC"
    } ]
  },
  "geo" : { },
  "id_str" : "699986269166833664",
  "text" : "\"I expect them to hold hearings.  \nI expect there to be a vote.\nFull stop.\"\n\n\u2014@POTUS to Senate Republicans #SCOTUS https:\/\/t.co\/eghMN3UyO5",
  "id" : 699986269166833664,
  "created_at" : "2016-02-17 15:58:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699977652690669568",
  "text" : "RT @VP: Seven years ago, the President signed the Recovery Act into law. Here's where I'm going today, and why it matters: https:\/\/t.co\/XXZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/XXZc1XHJKY",
        "expanded_url" : "http:\/\/go.wh.gov\/Up-The-Mississippi",
        "display_url" : "go.wh.gov\/Up-The-Mississ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "699977400680128512",
    "text" : "Seven years ago, the President signed the Recovery Act into law. Here's where I'm going today, and why it matters: https:\/\/t.co\/XXZc1XHJKY",
    "id" : 699977400680128512,
    "created_at" : "2016-02-17 15:23:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 699977652690669568,
  "created_at" : "2016-02-17 15:24:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Jeff Merkley",
      "screen_name" : "SenJeffMerkley",
      "indices" : [ 3, 18 ],
      "id_str" : "29201047",
      "id" : 29201047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699744007514103808",
  "text" : "RT @SenJeffMerkley: FACT: More Americans die every day from drug overdoses than from car crashes\u2014We need to act on the opioid crisis now ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenJeffMerkley\/status\/699739621178150914\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/g18T3prLnj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbX5ekbUcAEVeQx.jpg",
        "id_str" : "699739620695633921",
        "id" : 699739620695633921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbX5ekbUcAEVeQx.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/g18T3prLnj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "699738240107089921",
    "geo" : { },
    "id_str" : "699739621178150914",
    "in_reply_to_user_id" : 29201047,
    "text" : "FACT: More Americans die every day from drug overdoses than from car crashes\u2014We need to act on the opioid crisis now https:\/\/t.co\/g18T3prLnj",
    "id" : 699739621178150914,
    "in_reply_to_status_id" : 699738240107089921,
    "created_at" : "2016-02-16 23:38:20 +0000",
    "in_reply_to_screen_name" : "SenJeffMerkley",
    "in_reply_to_user_id_str" : "29201047",
    "user" : {
      "name" : "Senator Jeff Merkley",
      "screen_name" : "SenJeffMerkley",
      "protected" : false,
      "id_str" : "29201047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783767069745635330\/CIQXtwex_normal.jpg",
      "id" : 29201047,
      "verified" : true
    }
  },
  "id" : 699744007514103808,
  "created_at" : "2016-02-16 23:55:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/eghMN4c9FD",
      "expanded_url" : "http:\/\/snpy.tv\/1PDJteC",
      "display_url" : "snpy.tv\/1PDJteC"
    } ]
  },
  "geo" : { },
  "id_str" : "699731547935494144",
  "text" : "\"The Constitution is pretty clear about what is supposed to happen now\" \u2014@POTUS on the Supreme Court vacancy #SCOTUS https:\/\/t.co\/eghMN4c9FD",
  "id" : 699731547935494144,
  "created_at" : "2016-02-16 23:06:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699722042862673920",
  "text" : "\"I intend to do my job between now and January 20th of 2017. I expect them to do their job as well.\" \u2014@POTUS to Senate Republicans #SCOTUS",
  "id" : 699722042862673920,
  "created_at" : "2016-02-16 22:28:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699718868835635201",
  "text" : "\"There's more than enough time for the Senate to consider\u2026the record of a nominee I present\" \u2014@POTUS on the Supreme Court vacancy #SCOTUS",
  "id" : 699718868835635201,
  "created_at" : "2016-02-16 22:15:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ASEAN",
      "screen_name" : "ASEAN",
      "indices" : [ 40, 46 ],
      "id_str" : "111560581",
      "id" : 111560581
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USASEAN2016",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699713554157416448",
  "text" : "\"The commitment of the United States to @ASEAN and its peoples is\u2014and will remain\u2014 strong and enduring.\" \u2014@POTUS at #USASEAN2016",
  "id" : 699713554157416448,
  "created_at" : "2016-02-16 21:54:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/699712904526852096\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/S9RqoxiwLc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbXhKulWEAA3XU8.jpg",
      "id_str" : "699712891545587712",
      "id" : 699712891545587712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbXhKulWEAA3XU8.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/S9RqoxiwLc"
    } ],
    "hashtags" : [ {
      "text" : "USASEAN2016",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/Ql0ZWFZ9Xs",
      "expanded_url" : "http:\/\/go.wh.gov\/SinhYu",
      "display_url" : "go.wh.gov\/SinhYu"
    } ]
  },
  "geo" : { },
  "id_str" : "699712904526852096",
  "text" : "Tune in as @POTUS holds a press conference at the #USASEAN2016 Summit: https:\/\/t.co\/Ql0ZWFZ9Xs https:\/\/t.co\/S9RqoxiwLc",
  "id" : 699712904526852096,
  "created_at" : "2016-02-16 21:52:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USASEAN2016",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699709544427982850",
  "text" : "RT @JohnKerry: Constructive #USASEAN2016 Summit with @POTUS. Continue to work with all member countries on regional &amp; global issues.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 38, 44 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USASEAN2016",
        "indices" : [ 13, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699701464487186432",
    "text" : "Constructive #USASEAN2016 Summit with @POTUS. Continue to work with all member countries on regional &amp; global issues.",
    "id" : 699701464487186432,
    "created_at" : "2016-02-16 21:06:43 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 699709544427982850,
  "created_at" : "2016-02-16 21:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/699677060067799040\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/SERTmKEOsS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbXAk-iUEAAbejK.jpg",
      "id_str" : "699677058620723200",
      "id" : 699677058620723200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbXAk-iUEAAbejK.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 3000
      } ],
      "display_url" : "pic.twitter.com\/SERTmKEOsS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/12bY1MUS4v",
      "expanded_url" : "http:\/\/on.doi.gov\/20Zegrl",
      "display_url" : "on.doi.gov\/20Zegrl"
    } ]
  },
  "geo" : { },
  "id_str" : "699682857896153088",
  "text" : "RT @Interior: The 8 presidents who shaped America\u2019s public lands: https:\/\/t.co\/12bY1MUS4v https:\/\/t.co\/SERTmKEOsS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/699677060067799040\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/SERTmKEOsS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbXAk-iUEAAbejK.jpg",
        "id_str" : "699677058620723200",
        "id" : 699677058620723200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbXAk-iUEAAbejK.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 3000
        } ],
        "display_url" : "pic.twitter.com\/SERTmKEOsS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/12bY1MUS4v",
        "expanded_url" : "http:\/\/on.doi.gov\/20Zegrl",
        "display_url" : "on.doi.gov\/20Zegrl"
      } ]
    },
    "geo" : { },
    "id_str" : "699677060067799040",
    "text" : "The 8 presidents who shaped America\u2019s public lands: https:\/\/t.co\/12bY1MUS4v https:\/\/t.co\/SERTmKEOsS",
    "id" : 699677060067799040,
    "created_at" : "2016-02-16 19:29:45 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 699682857896153088,
  "created_at" : "2016-02-16 19:52:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/699651359566667776\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/nz9D3xIzge",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbWpKgSW4AEOc-1.jpg",
      "id_str" : "699651315056697345",
      "id" : 699651315056697345,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbWpKgSW4AEOc-1.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nz9D3xIzge"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/t0I6FpS4t4",
      "expanded_url" : "http:\/\/go.wh.gov\/wupunS",
      "display_url" : "go.wh.gov\/wupunS"
    } ]
  },
  "geo" : { },
  "id_str" : "699651359566667776",
  "text" : "We're restoring flights with Cuba for the first time in 50 years \u2192 https:\/\/t.co\/t0I6FpS4t4 #CubaPolicy https:\/\/t.co\/nz9D3xIzge",
  "id" : 699651359566667776,
  "created_at" : "2016-02-16 17:47:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/G55x0ottwR",
      "expanded_url" : "http:\/\/go.wh.gov\/wupunS",
      "display_url" : "go.wh.gov\/wupunS"
    } ]
  },
  "geo" : { },
  "id_str" : "699645849022763008",
  "text" : "RT @rhodes44: Our #CubaPolicy: \nNew embassy \u2713\nNew flights \u2713\nNew commerce \u2713\nNew opportunity for Cubans \u2713\nhttps:\/\/t.co\/G55x0ottwR https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/699645766562770944\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/SsRobUVPcp",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CbWjSD4UcAECbH9.jpg",
        "id_str" : "699644847800479745",
        "id" : 699644847800479745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CbWjSD4UcAECbH9.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SsRobUVPcp"
      } ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/G55x0ottwR",
        "expanded_url" : "http:\/\/go.wh.gov\/wupunS",
        "display_url" : "go.wh.gov\/wupunS"
      } ]
    },
    "geo" : { },
    "id_str" : "699645766562770944",
    "text" : "Our #CubaPolicy: \nNew embassy \u2713\nNew flights \u2713\nNew commerce \u2713\nNew opportunity for Cubans \u2713\nhttps:\/\/t.co\/G55x0ottwR https:\/\/t.co\/SsRobUVPcp",
    "id" : 699645766562770944,
    "created_at" : "2016-02-16 17:25:24 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 699645849022763008,
  "created_at" : "2016-02-16 17:25:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GRAMMYs",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699429205638057984",
  "text" : "RT @vj44: \"We need to make every single thing accessible to every single person with a disability\" - Stevie Wonder #GRAMMYs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GRAMMYs",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699422198012977152",
    "text" : "\"We need to make every single thing accessible to every single person with a disability\" - Stevie Wonder #GRAMMYs",
    "id" : 699422198012977152,
    "created_at" : "2016-02-16 02:37:01 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 699429205638057984,
  "created_at" : "2016-02-16 03:04:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kendrick Lamar",
      "screen_name" : "kendricklamar",
      "indices" : [ 12, 26 ],
      "id_str" : "23561980",
      "id" : 23561980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Grammys",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "MyBrothersKeeper",
      "indices" : [ 99, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/XM0KwV3jNB",
      "expanded_url" : "https:\/\/twitter.com\/kendricklamar\/status\/686712188816375809",
      "display_url" : "twitter.com\/kendricklamar\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "699405986885410817",
  "text" : "Shoutout to @KendrickLamar and all the artists at the #Grammys working to build a brighter future. #MyBrothersKeeper https:\/\/t.co\/XM0KwV3jNB",
  "id" : 699405986885410817,
  "created_at" : "2016-02-16 01:32:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DC",
      "indices" : [ 91, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/vomhoFslqm",
      "expanded_url" : "http:\/\/on.doi.gov\/1Lq2xc9",
      "display_url" : "on.doi.gov\/1Lq2xc9"
    } ]
  },
  "geo" : { },
  "id_str" : "699361649145311232",
  "text" : "RT @Interior: TODAY: $18.5M donation will help revitalize nation's iconic Lincoln Memorial #DC https:\/\/t.co\/vomhoFslqm https:\/\/t.co\/U065Wbz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/699310758736371712\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/U065Wbz1W0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbRzbfOWEAA-vQN.jpg",
        "id_str" : "699310758224596992",
        "id" : 699310758224596992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbRzbfOWEAA-vQN.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 984,
          "resize" : "fit",
          "w" : 1484
        } ],
        "display_url" : "pic.twitter.com\/U065Wbz1W0"
      } ],
      "hashtags" : [ {
        "text" : "DC",
        "indices" : [ 77, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/vomhoFslqm",
        "expanded_url" : "http:\/\/on.doi.gov\/1Lq2xc9",
        "display_url" : "on.doi.gov\/1Lq2xc9"
      } ]
    },
    "geo" : { },
    "id_str" : "699310758736371712",
    "text" : "TODAY: $18.5M donation will help revitalize nation's iconic Lincoln Memorial #DC https:\/\/t.co\/vomhoFslqm https:\/\/t.co\/U065Wbz1W0",
    "id" : 699310758736371712,
    "created_at" : "2016-02-15 19:14:12 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 699361649145311232,
  "created_at" : "2016-02-15 22:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/699299709593133057\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/a22MGrutxY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbRf9LqW0AA7hO-.jpg",
      "id_str" : "699289346856374272",
      "id" : 699289346856374272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbRf9LqW0AA7hO-.jpg",
      "sizes" : [ {
        "h" : 697,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1165,
        "resize" : "fit",
        "w" : 1712
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/a22MGrutxY"
    } ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 6, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/BCuwU0uHVG",
      "expanded_url" : "http:\/\/go.wh.gov\/Presidents",
      "display_url" : "go.wh.gov\/Presidents"
    } ]
  },
  "geo" : { },
  "id_str" : "699299709593133057",
  "text" : "Happy #PresidentsDay!\n\nLearn more about all 44 of them \u2192 https:\/\/t.co\/BCuwU0uHVG https:\/\/t.co\/a22MGrutxY",
  "id" : 699299709593133057,
  "created_at" : "2016-02-15 18:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/699253227095719936\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/klxoFzTJJE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbQ_Gh2WIAQ71D7.jpg",
      "id_str" : "699253223547346948",
      "id" : 699253223547346948,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbQ_Gh2WIAQ71D7.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/klxoFzTJJE"
    } ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 20, 34 ]
    }, {
      "text" : "sunrise",
      "indices" : [ 88, 96 ]
    }, {
      "text" : "DC",
      "indices" : [ 112, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699279500056649729",
  "text" : "RT @Interior: Happy #PresidentsDay! Here\u2019s a gorgeous pic of the Washington Monument at #sunrise by Jeff Norman #DC https:\/\/t.co\/klxoFzTJJE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/699253227095719936\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/klxoFzTJJE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbQ_Gh2WIAQ71D7.jpg",
        "id_str" : "699253223547346948",
        "id" : 699253223547346948,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbQ_Gh2WIAQ71D7.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/klxoFzTJJE"
      } ],
      "hashtags" : [ {
        "text" : "PresidentsDay",
        "indices" : [ 6, 20 ]
      }, {
        "text" : "sunrise",
        "indices" : [ 74, 82 ]
      }, {
        "text" : "DC",
        "indices" : [ 98, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "699253227095719936",
    "text" : "Happy #PresidentsDay! Here\u2019s a gorgeous pic of the Washington Monument at #sunrise by Jeff Norman #DC https:\/\/t.co\/klxoFzTJJE",
    "id" : 699253227095719936,
    "created_at" : "2016-02-15 15:25:35 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 699279500056649729,
  "created_at" : "2016-02-15 17:09:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/699266618749231104\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/61rXgo7Ata",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbRLEyRUsAA_VUl.jpg",
      "id_str" : "699266387735261184",
      "id" : 699266387735261184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbRLEyRUsAA_VUl.jpg",
      "sizes" : [ {
        "h" : 536,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 493
      } ],
      "display_url" : "pic.twitter.com\/61rXgo7Ata"
    } ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/bYWyXAes5a",
      "expanded_url" : "http:\/\/on.fb.me\/1Kl2HGU",
      "display_url" : "on.fb.me\/1Kl2HGU"
    } ]
  },
  "geo" : { },
  "id_str" : "699266618749231104",
  "text" : "\"He held a nation together and helped free a people.\"\n\n\u2014@POTUS on Lincoln: https:\/\/t.co\/bYWyXAes5a #PresidentsDay https:\/\/t.co\/61rXgo7Ata",
  "id" : 699266618749231104,
  "created_at" : "2016-02-15 16:18:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/699250641856806912\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/DoX2gnJiRd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbQ8k8QW0AAFEjx.jpg",
      "id_str" : "699250447496957952",
      "id" : 699250447496957952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbQ8k8QW0AAFEjx.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/DoX2gnJiRd"
    } ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/jeqH3zhlix",
      "expanded_url" : "http:\/\/wh.gov\/EasterEggRoll",
      "display_url" : "wh.gov\/EasterEggRoll"
    } ]
  },
  "geo" : { },
  "id_str" : "699250641856806912",
  "text" : "Sign up for a chance to come to the 2016 White House #EasterEggRoll \u2192 https:\/\/t.co\/jeqH3zhlix https:\/\/t.co\/DoX2gnJiRd",
  "id" : 699250641856806912,
  "created_at" : "2016-02-15 15:15:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/699032896300933123\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/DebPQbCGtO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbNFp7aWcAA8UjE.jpg",
      "id_str" : "698978953797726208",
      "id" : 698978953797726208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbNFp7aWcAA8UjE.jpg",
      "sizes" : [ {
        "h" : 493,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 690
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 690
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DebPQbCGtO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "699032896300933123",
  "text" : "Happy Valentine's Day! https:\/\/t.co\/DebPQbCGtO",
  "id" : 699032896300933123,
  "created_at" : "2016-02-15 00:50:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/iIJsoGLfjL",
      "expanded_url" : "http:\/\/go.wh.gov\/DXPZap",
      "display_url" : "go.wh.gov\/DXPZap"
    } ]
  },
  "geo" : { },
  "id_str" : "698982580956233728",
  "text" : "\"Choosing a politics of hope is something that\u2019s entirely up to each of us.\" \u2014@POTUS https:\/\/t.co\/iIJsoGLfjL",
  "id" : 698982580956233728,
  "created_at" : "2016-02-14 21:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/iIJsoGtEsd",
      "expanded_url" : "http:\/\/go.wh.gov\/DXPZap",
      "display_url" : "go.wh.gov\/DXPZap"
    } ]
  },
  "geo" : { },
  "id_str" : "698968830505304064",
  "text" : "\"Nine years after I first announced for this office, I still believe in a politics of hope.\" \u2014@POTUS https:\/\/t.co\/iIJsoGtEsd",
  "id" : 698968830505304064,
  "created_at" : "2016-02-14 20:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698699791128096768",
  "text" : "RT @VP: Jill and I send deepest condolences to Maureen and the entire Scalia family on the loss of their beloved husband, father, and grand\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698699187572105216",
    "text" : "Jill and I send deepest condolences to Maureen and the entire Scalia family on the loss of their beloved husband, father, and grandfather.",
    "id" : 698699187572105216,
    "created_at" : "2016-02-14 02:44:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 698699791128096768,
  "created_at" : "2016-02-14 02:46:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/MgqEeftDp3",
      "expanded_url" : "http:\/\/snpy.tv\/1SoVSGP",
      "display_url" : "snpy.tv\/1SoVSGP"
    } ]
  },
  "geo" : { },
  "id_str" : "698686453132308480",
  "text" : "FULL VIDEO: @POTUS on the passing of Supreme Court Justice Antonin Scalia. https:\/\/t.co\/MgqEeftDp3",
  "id" : 698686453132308480,
  "created_at" : "2016-02-14 01:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698685443970244609",
  "text" : "\"Michelle and I join the nation in sending our deepest sympathy to Justice Scalia\u2019s wife Maureen and their loving family\" \u2014@POTUS",
  "id" : 698685443970244609,
  "created_at" : "2016-02-14 01:49:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698685324688379904",
  "text" : "\"These are responsibilities I take seriously, as should everyone. They\u2019re bigger than any one party. They\u2019re about our democracy.\" \u2014@POTUS",
  "id" : 698685324688379904,
  "created_at" : "2016-02-14 01:48:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698685266496659456",
  "text" : "\"There\u2019s plenty of time...for the Senate to fulfill its responsibility to give that person a fair hearing and a timely vote\" \u2014@POTUS",
  "id" : 698685266496659456,
  "created_at" : "2016-02-14 01:48:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698685235181932544",
  "text" : "\"I plan to fulfill my Constitutional responsibility to nominate a successor in due time.\" \u2014@POTUS",
  "id" : 698685235181932544,
  "created_at" : "2016-02-14 01:48:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 137, 143 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698685105192054784",
  "text" : "\"Scalia was both an avid hunter &amp; opera lover\u2014a passion for music he shared with his dear colleague and friend, Justice...Ginsberg\" \u2014@POTUS",
  "id" : 698685105192054784,
  "created_at" : "2016-02-14 01:48:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698684991371251712",
  "text" : "\"Tonight, we honor his extraordinary service to our nation and remember one of the towering legal figures of our time.\" \u2014@POTUS on Scalia",
  "id" : 698684991371251712,
  "created_at" : "2016-02-14 01:47:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698684933460533248",
  "text" : "\"Justice Scalia dedicated his life to the cornerstone of our democracy\u2014the rule of law.\" \u2014@POTUS",
  "id" : 698684933460533248,
  "created_at" : "2016-02-14 01:47:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698684852166533120",
  "text" : "\"He will no doubt be remembered as one of the most consequential judges and thinkers to serve on the Supreme Court.\" \u2014@POTUS on Scalia",
  "id" : 698684852166533120,
  "created_at" : "2016-02-14 01:47:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698684794440257536",
  "text" : "\"He influenced a generation of judges, lawyers, and students, and profoundly shaped the legal landscape.\" \u2014@POTUS",
  "id" : 698684794440257536,
  "created_at" : "2016-02-14 01:46:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698684747594137600",
  "text" : "\"A brilliant legal mind with a pugnacious style, incisive wit, and colorful opinions.\" \u2014@POTUS on Justice Scalia",
  "id" : 698684747594137600,
  "created_at" : "2016-02-14 01:46:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698684683349929985",
  "text" : "\"For almost 30 years, Justice Antonin \u201CNino\u201D Scalia was a larger-than-life presence on the bench\" \u2014@POTUS",
  "id" : 698684683349929985,
  "created_at" : "2016-02-14 01:46:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/D2jyhFm7wU",
      "expanded_url" : "http:\/\/go.wh.gov\/FidW2p",
      "display_url" : "go.wh.gov\/FidW2p"
    } ]
  },
  "geo" : { },
  "id_str" : "698684628433969152",
  "text" : "Watch live: @POTUS delivers remarks on the passing of Antonin Scalia \u2192 https:\/\/t.co\/D2jyhFm7wU",
  "id" : 698684628433969152,
  "created_at" : "2016-02-14 01:46:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/D2jyhFDIVu",
      "expanded_url" : "http:\/\/go.wh.gov\/FidW2p",
      "display_url" : "go.wh.gov\/FidW2p"
    } ]
  },
  "geo" : { },
  "id_str" : "698675851504840704",
  "text" : "At 8:30pm ET, @POTUS will deliver a statement on the passing of Supreme Court Justice Antonin Scalia \u2192 https:\/\/t.co\/D2jyhFDIVu",
  "id" : 698675851504840704,
  "created_at" : "2016-02-14 01:11:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698576066739179522",
  "text" : "RT @POTUS: Got a view yesterday of the lands we protected in CA. We owe it to our kids to preserve America's natural beauty. https:\/\/t.co\/8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/698574908247425024\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/8OR9MrupyG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbHWKkdXIAIfmgu.jpg",
        "id_str" : "698574894293000194",
        "id" : 698574894293000194,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbHWKkdXIAIfmgu.jpg",
        "sizes" : [ {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 702,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 702,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/8OR9MrupyG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698574908247425024",
    "text" : "Got a view yesterday of the lands we protected in CA. We owe it to our kids to preserve America's natural beauty. https:\/\/t.co\/8OR9MrupyG",
    "id" : 698574908247425024,
    "created_at" : "2016-02-13 18:30:11 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 698576066739179522,
  "created_at" : "2016-02-13 18:34:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/iIJsoGLfjL",
      "expanded_url" : "http:\/\/go.wh.gov\/DXPZap",
      "display_url" : "go.wh.gov\/DXPZap"
    } ]
  },
  "geo" : { },
  "id_str" : "698567426720419841",
  "text" : "\"When more of us vote, the less captive our politics will be to narrow interests\" \u2014@POTUS https:\/\/t.co\/iIJsoGLfjL",
  "id" : 698567426720419841,
  "created_at" : "2016-02-13 18:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/iIJsoGLfjL",
      "expanded_url" : "http:\/\/go.wh.gov\/DXPZap",
      "display_url" : "go.wh.gov\/DXPZap"
    } ]
  },
  "geo" : { },
  "id_str" : "698548478880800769",
  "text" : "\"We can make voting easier, not harder, and modernize it for the way we live now.\" \u2014@POTUS https:\/\/t.co\/iIJsoGLfjL",
  "id" : 698548478880800769,
  "created_at" : "2016-02-13 16:45:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/iIJsoGtEsd",
      "expanded_url" : "http:\/\/go.wh.gov\/DXPZap",
      "display_url" : "go.wh.gov\/DXPZap"
    } ]
  },
  "geo" : { },
  "id_str" : "698528872204279808",
  "text" : "Watch @POTUS's message on the state of American politics. https:\/\/t.co\/iIJsoGtEsd",
  "id" : 698528872204279808,
  "created_at" : "2016-02-13 15:27:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Axelrod",
      "screen_name" : "davidaxelrod",
      "indices" : [ 3, 16 ],
      "id_str" : "244655353",
      "id" : 244655353
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698275427559669760",
  "text" : "RT @davidaxelrod: My reflections on returning to Springfield with @POTUS nine years after he launched his candidacy there. https:\/\/t.co\/IB8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 48, 54 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/IB8RuIj0Gj",
        "expanded_url" : "https:\/\/goo.gl\/IYu5A0",
        "display_url" : "goo.gl\/IYu5A0"
      } ]
    },
    "geo" : { },
    "id_str" : "698253446022037504",
    "text" : "My reflections on returning to Springfield with @POTUS nine years after he launched his candidacy there. https:\/\/t.co\/IB8RuIj0Gj",
    "id" : 698253446022037504,
    "created_at" : "2016-02-12 21:12:49 +0000",
    "user" : {
      "name" : "David Axelrod",
      "screen_name" : "davidaxelrod",
      "protected" : false,
      "id_str" : "244655353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2948601880\/c6d7f729324c1e592ea9b0879e4abca5_normal.jpeg",
      "id" : 244655353,
      "verified" : true
    }
  },
  "id" : 698275427559669760,
  "created_at" : "2016-02-12 22:40:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/JCDd5Shfwo",
      "expanded_url" : "http:\/\/go.wh.gov\/s6Mjq8",
      "display_url" : "go.wh.gov\/s6Mjq8"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/q4CSuPcSp9",
      "expanded_url" : "http:\/\/go.wh.gov\/WiT1ox",
      "display_url" : "go.wh.gov\/WiT1ox"
    } ]
  },
  "geo" : { },
  "id_str" : "698272411259686912",
  "text" : "Watch @POTUS's trip back to Springfield nine years after he announced his campaign: https:\/\/t.co\/JCDd5Shfwo https:\/\/t.co\/q4CSuPcSp9",
  "id" : 698272411259686912,
  "created_at" : "2016-02-12 22:28:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "indices" : [ 28, 41 ],
      "id_str" : "15846407",
      "id" : 15846407
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 81, 88 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/698229432184664064\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ZFfDO5v0oL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbCbdOlW0AAahyr.jpg",
      "id_str" : "698228868675719168",
      "id" : 698228868675719168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbCbdOlW0AAahyr.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZFfDO5v0oL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/6py4WOP9wp",
      "expanded_url" : "http:\/\/ellentube.com\/videos\/0-wh2ip495\/",
      "display_url" : "ellentube.com\/videos\/0-wh2ip\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "698229432184664064",
  "text" : "A boombox\u2713 \nRoses\u2713 \n@POTUS\u2713\n@TheEllenShow\u2713\n\nWatch his Valentine's Day message to @FLOTUS: https:\/\/t.co\/6py4WOP9wp https:\/\/t.co\/ZFfDO5v0oL",
  "id" : 698229432184664064,
  "created_at" : "2016-02-12 19:37:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patagonia",
      "screen_name" : "patagonia",
      "indices" : [ 3, 13 ],
      "id_str" : "16191793",
      "id" : 16191793
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698225329383542784",
  "text" : "RT @patagonia: .@POTUS has protected more acres of land and water than any Administration in history. A win for conservation. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/patagonia\/status\/698212522629926912\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/x6FYfLiXla",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbCMlsuUEAA-JAK.jpg",
        "id_str" : "698212521530888192",
        "id" : 698212521530888192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbCMlsuUEAA-JAK.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/x6FYfLiXla"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698212522629926912",
    "text" : ".@POTUS has protected more acres of land and water than any Administration in history. A win for conservation. https:\/\/t.co\/x6FYfLiXla",
    "id" : 698212522629926912,
    "created_at" : "2016-02-12 18:30:12 +0000",
    "user" : {
      "name" : "Patagonia",
      "screen_name" : "patagonia",
      "protected" : false,
      "id_str" : "16191793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725446734726336513\/AwZNaoVG_normal.jpg",
      "id" : 16191793,
      "verified" : true
    }
  },
  "id" : 698225329383542784,
  "created_at" : "2016-02-12 19:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/698192604756885504\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/PnZHqmuGPI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbB6boJWEAIG50E.jpg",
      "id_str" : "698192557294096386",
      "id" : 698192557294096386,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbB6boJWEAIG50E.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1066,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PnZHqmuGPI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/jnLF7pHein",
      "expanded_url" : "http:\/\/go.wh.gov\/FindYourPark",
      "display_url" : "go.wh.gov\/FindYourPark"
    } ]
  },
  "geo" : { },
  "id_str" : "698192604756885504",
  "text" : "Check out the big steps @POTUS just took to protect our \uD83C\uDF0E for future generations \u2192 https:\/\/t.co\/jnLF7pHein https:\/\/t.co\/PnZHqmuGPI",
  "id" : 698192604756885504,
  "created_at" : "2016-02-12 17:11:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698180592081342464",
  "text" : "RT @Denis44: Just got off the blower w\/Mayor 2 tell him POTUS is coming 2 MKE \u2013 congrats 4 winning Healthy Communities Challenge! https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/698179885089468417\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/v09iFsX48Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbBu59MUMAAmtfq.jpg",
        "id_str" : "698179884200243200",
        "id" : 698179884200243200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbBu59MUMAAmtfq.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/v09iFsX48Y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698179885089468417",
    "text" : "Just got off the blower w\/Mayor 2 tell him POTUS is coming 2 MKE \u2013 congrats 4 winning Healthy Communities Challenge! https:\/\/t.co\/v09iFsX48Y",
    "id" : 698179885089468417,
    "created_at" : "2016-02-12 16:20:30 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 698180592081342464,
  "created_at" : "2016-02-12 16:23:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "California",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "698179015245303808",
  "text" : "RT @Interior: .@POTUS protects #California desert w\/ 3 new national monuments including the stunning Mojave Trails #FindYourPark https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/698178234823811072\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/94qVga94bh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CbBtZ5LXEAAXFnh.jpg",
        "id_str" : "698178233855053824",
        "id" : 698178233855053824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbBtZ5LXEAAXFnh.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/94qVga94bh"
      } ],
      "hashtags" : [ {
        "text" : "California",
        "indices" : [ 17, 28 ]
      }, {
        "text" : "FindYourPark",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "698178234823811072",
    "text" : ".@POTUS protects #California desert w\/ 3 new national monuments including the stunning Mojave Trails #FindYourPark https:\/\/t.co\/94qVga94bh",
    "id" : 698178234823811072,
    "created_at" : "2016-02-12 16:13:57 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 698179015245303808,
  "created_at" : "2016-02-12 16:17:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/698174275426107392\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/sSaG32k6va",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbBptIBXEAE6Gbf.jpg",
      "id_str" : "698174166210646017",
      "id" : 698174166210646017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbBptIBXEAE6Gbf.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/sSaG32k6va"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/jnLF7pHein",
      "expanded_url" : "http:\/\/go.wh.gov\/FindYourPark",
      "display_url" : "go.wh.gov\/FindYourPark"
    } ]
  },
  "geo" : { },
  "id_str" : "698174275426107392",
  "text" : ".@POTUS has protected more public lands and waters than any other President \u2192 https:\/\/t.co\/jnLF7pHein #FindYourPark https:\/\/t.co\/sSaG32k6va",
  "id" : 698174275426107392,
  "created_at" : "2016-02-12 15:58:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/698163064902914051\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/IMhsjHlPSE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CbBfWurWIAAx2E_.jpg",
      "id_str" : "698162786334023680",
      "id" : 698162786334023680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CbBfWurWIAAx2E_.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/IMhsjHlPSE"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/jnLF7pHein",
      "expanded_url" : "http:\/\/go.wh.gov\/FindYourPark",
      "display_url" : "go.wh.gov\/FindYourPark"
    } ]
  },
  "geo" : { },
  "id_str" : "698163064902914051",
  "text" : "Big news: @POTUS just protected 1.8 million acres of public lands in CA \u2192 https:\/\/t.co\/jnLF7pHein #FindYourPark https:\/\/t.co\/IMhsjHlPSE",
  "id" : 698163064902914051,
  "created_at" : "2016-02-12 15:13:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "indices" : [ 3, 14 ],
      "id_str" : "562385224",
      "id" : 562385224
    }, {
      "name" : "Governor Jay Inslee",
      "screen_name" : "GovInslee",
      "indices" : [ 43, 53 ],
      "id_str" : "1077214808",
      "id" : 1077214808
    }, {
      "name" : "Gov. Asa Hutchinson",
      "screen_name" : "AsaHutchinson",
      "indices" : [ 54, 68 ],
      "id_str" : "269992801",
      "id" : 269992801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSforAll",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697942311682969601",
  "text" : "RT @Abramson44: Another great read! Thanks @GovInslee @AsaHutchinson for showing that Rs + Ds can agree our kids need #CSforAll: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Governor Jay Inslee",
        "screen_name" : "GovInslee",
        "indices" : [ 27, 37 ],
        "id_str" : "1077214808",
        "id" : 1077214808
      }, {
        "name" : "Gov. Asa Hutchinson",
        "screen_name" : "AsaHutchinson",
        "indices" : [ 38, 52 ],
        "id_str" : "269992801",
        "id" : 269992801
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CSforAll",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/GMZ0CFfxvC",
        "expanded_url" : "http:\/\/bit.ly\/1LjF9Nr",
        "display_url" : "bit.ly\/1LjF9Nr"
      } ]
    },
    "geo" : { },
    "id_str" : "697892996004585472",
    "text" : "Another great read! Thanks @GovInslee @AsaHutchinson for showing that Rs + Ds can agree our kids need #CSforAll: https:\/\/t.co\/GMZ0CFfxvC",
    "id" : 697892996004585472,
    "created_at" : "2016-02-11 21:20:31 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 697942311682969601,
  "created_at" : "2016-02-12 00:36:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 45, 51 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697936718003982336\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/t1t49Vjzcn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca-Ri6pWIAE9UeZ.jpg",
      "id_str" : "697936496309968897",
      "id" : 697936496309968897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca-Ri6pWIAE9UeZ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/t1t49Vjzcn"
    } ],
    "hashtags" : [ {
      "text" : "WhereWereYou",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/XNn0nWxdxD",
      "expanded_url" : "http:\/\/go.wh.gov\/2GG3AM",
      "display_url" : "go.wh.gov\/2GG3AM"
    } ]
  },
  "geo" : { },
  "id_str" : "697936718003982336",
  "text" : "Meet 2008 campaign veterans who've been with @POTUS since the very beginning: https:\/\/t.co\/XNn0nWxdxD #WhereWereYou https:\/\/t.co\/t1t49Vjzcn",
  "id" : 697936718003982336,
  "created_at" : "2016-02-12 00:14:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "National Science Fdn",
      "screen_name" : "NSF",
      "indices" : [ 43, 47 ],
      "id_str" : "16245822",
      "id" : 16245822
    }, {
      "name" : "LIGO",
      "screen_name" : "LIGO",
      "indices" : [ 52, 57 ],
      "id_str" : "15000857",
      "id" : 15000857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697930107504218113",
  "text" : "RT @POTUS: Einstein was right! Congrats to @NSF and @LIGO on detecting gravitational waves - a huge breakthrough in how we understand the u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Science Fdn",
        "screen_name" : "NSF",
        "indices" : [ 32, 36 ],
        "id_str" : "16245822",
        "id" : 16245822
      }, {
        "name" : "LIGO",
        "screen_name" : "LIGO",
        "indices" : [ 41, 46 ],
        "id_str" : "15000857",
        "id" : 15000857
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697928913457188864",
    "text" : "Einstein was right! Congrats to @NSF and @LIGO on detecting gravitational waves - a huge breakthrough in how we understand the universe.",
    "id" : 697928913457188864,
    "created_at" : "2016-02-11 23:43:14 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 697930107504218113,
  "created_at" : "2016-02-11 23:47:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "indices" : [ 3, 16 ],
      "id_str" : "15846407",
      "id" : 15846407
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 19, 31 ],
      "id_str" : "813286",
      "id" : 813286
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 89, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/LKU0eS0GXF",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/11cd4fa2-733a-44c4-b126-432a10dcdc8a",
      "display_url" : "amp.twimg.com\/v\/11cd4fa2-733\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697922213249286144",
  "text" : "RT @TheEllenShow: .@BarackObama was here in 2007, and tomorrow he\u2019s barack. I mean back. #TBT @POTUS\nhttps:\/\/t.co\/LKU0eS0GXF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 1, 13 ],
        "id_str" : "813286",
        "id" : 813286
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 76, 82 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TBT",
        "indices" : [ 71, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/LKU0eS0GXF",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/11cd4fa2-733a-44c4-b126-432a10dcdc8a",
        "display_url" : "amp.twimg.com\/v\/11cd4fa2-733\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697910692775497728",
    "text" : ".@BarackObama was here in 2007, and tomorrow he\u2019s barack. I mean back. #TBT @POTUS\nhttps:\/\/t.co\/LKU0eS0GXF",
    "id" : 697910692775497728,
    "created_at" : "2016-02-11 22:30:50 +0000",
    "user" : {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "protected" : false,
      "id_str" : "15846407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789558314191425539\/X_imv1vL_normal.jpg",
      "id" : 15846407,
      "verified" : true
    }
  },
  "id" : 697922213249286144,
  "created_at" : "2016-02-11 23:16:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/697832884934021120\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/Ynp9pMd6Ai",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca8zT4mUEAAsxAM.jpg",
      "id_str" : "697832883969331200",
      "id" : 697832883969331200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca8zT4mUEAAsxAM.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Ynp9pMd6Ai"
    } ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ofLRV6BW9g",
      "expanded_url" : "http:\/\/go.wh.gov\/STEMforAll",
      "display_url" : "go.wh.gov\/STEMforAll"
    } ]
  },
  "geo" : { },
  "id_str" : "697917943087149057",
  "text" : "Here's how we're helping create more opportunities for girls and #WomenInSTEM: https:\/\/t.co\/ofLRV6BW9g https:\/\/t.co\/Ynp9pMd6Ai",
  "id" : 697917943087149057,
  "created_at" : "2016-02-11 22:59:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "National Science Fdn",
      "screen_name" : "NSF",
      "indices" : [ 45, 49 ],
      "id_str" : "16245822",
      "id" : 16245822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LIGO",
      "indices" : [ 65, 70 ]
    }, {
      "text" : "gravitationalwaves",
      "indices" : [ 86, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697872772270133248",
  "text" : "RT @whitehouseostp: I'd like to congratulate @NSF researchers at #LIGO for confirming #gravitationalwaves 100 years after Einstein predicte\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Science Fdn",
        "screen_name" : "NSF",
        "indices" : [ 25, 29 ],
        "id_str" : "16245822",
        "id" : 16245822
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LIGO",
        "indices" : [ 45, 50 ]
      }, {
        "text" : "gravitationalwaves",
        "indices" : [ 66, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697842277952061440",
    "text" : "I'd like to congratulate @NSF researchers at #LIGO for confirming #gravitationalwaves 100 years after Einstein predicted it - John Holdren",
    "id" : 697842277952061440,
    "created_at" : "2016-02-11 17:58:59 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 697872772270133248,
  "created_at" : "2016-02-11 20:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/s8E4xheTaM",
      "expanded_url" : "http:\/\/go.wh.gov\/Million-Miles-AF2",
      "display_url" : "go.wh.gov\/Million-Miles-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697868590414827521",
  "text" : "RT @VP: I've been around the world a few times as Vice President. See some shots from the road: https:\/\/t.co\/s8E4xheTaM https:\/\/t.co\/VMOaeY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/697830138898022400\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/VMOaeYL0Ph",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca8w0CZWAAQa8Hl.jpg",
        "id_str" : "697830137820217348",
        "id" : 697830137820217348,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca8w0CZWAAQa8Hl.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/VMOaeYL0Ph"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/s8E4xheTaM",
        "expanded_url" : "http:\/\/go.wh.gov\/Million-Miles-AF2",
        "display_url" : "go.wh.gov\/Million-Miles-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697830138898022400",
    "text" : "I've been around the world a few times as Vice President. See some shots from the road: https:\/\/t.co\/s8E4xheTaM https:\/\/t.co\/VMOaeYL0Ph",
    "id" : 697830138898022400,
    "created_at" : "2016-02-11 17:10:44 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 697868590414827521,
  "created_at" : "2016-02-11 19:43:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697863998012698624\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5m8Z89KHVe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca9PcIQW0AAtPOM.jpg",
      "id_str" : "697863811936735232",
      "id" : 697863811936735232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca9PcIQW0AAtPOM.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2500,
        "resize" : "fit",
        "w" : 5000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5m8Z89KHVe"
    } ],
    "hashtags" : [ {
      "text" : "WomenInScience",
      "indices" : [ 24, 39 ]
    }, {
      "text" : "WomenInSTEM",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/6viKUcTLud",
      "expanded_url" : "http:\/\/go.wh.gov\/WomenInSTEM",
      "display_url" : "go.wh.gov\/WomenInSTEM"
    } ]
  },
  "geo" : { },
  "id_str" : "697863998012698624",
  "text" : "On International Day of #WomenInScience, we're honoring the untold history of #WomenInSTEM: https:\/\/t.co\/6viKUcTLud https:\/\/t.co\/5m8Z89KHVe",
  "id" : 697863998012698624,
  "created_at" : "2016-02-11 19:25:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA Goddard",
      "screen_name" : "NASAGoddard",
      "indices" : [ 3, 15 ],
      "id_str" : "20060293",
      "id" : 20060293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LIGO",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/fvVDpLOtvE",
      "expanded_url" : "http:\/\/go.nasa.gov\/23ZbqoE",
      "display_url" : "go.nasa.gov\/23ZbqoE"
    } ]
  },
  "geo" : { },
  "id_str" : "697861991818510336",
  "text" : "RT @NASAGoddard: #LIGO heard chip of 2 black holes collide, fulfilling Einstein General Theory of Relativity https:\/\/t.co\/fvVDpLOtvE\nhttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LIGO",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/fvVDpLOtvE",
        "expanded_url" : "http:\/\/go.nasa.gov\/23ZbqoE",
        "display_url" : "go.nasa.gov\/23ZbqoE"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/Uo4wWSovlh",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/e56f498d-eea8-4dd9-b9d3-0b17fe327982",
        "display_url" : "amp.twimg.com\/v\/e56f498d-eea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697842753762242560",
    "text" : "#LIGO heard chip of 2 black holes collide, fulfilling Einstein General Theory of Relativity https:\/\/t.co\/fvVDpLOtvE\nhttps:\/\/t.co\/Uo4wWSovlh",
    "id" : 697842753762242560,
    "created_at" : "2016-02-11 18:00:52 +0000",
    "user" : {
      "name" : "NASA Goddard",
      "screen_name" : "NASAGoddard",
      "protected" : false,
      "id_str" : "20060293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793800527767371777\/LGB7B5PM_normal.jpg",
      "id" : 20060293,
      "verified" : true
    }
  },
  "id" : 697861991818510336,
  "created_at" : "2016-02-11 19:17:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/oi6LG6K3L4",
      "expanded_url" : "http:\/\/trib.in\/1TeOSMM",
      "display_url" : "trib.in\/1TeOSMM"
    } ]
  },
  "geo" : { },
  "id_str" : "697856129242689538",
  "text" : "Watch @POTUS sit down with his friends on both sides of the aisle from when he was an Illinois State Senator: https:\/\/t.co\/oi6LG6K3L4",
  "id" : 697856129242689538,
  "created_at" : "2016-02-11 18:54:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Axelrod",
      "screen_name" : "davidaxelrod",
      "indices" : [ 3, 16 ],
      "id_str" : "244655353",
      "id" : 244655353
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 67, 79 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697852267416911872",
  "text" : "RT @davidaxelrod: Really terrific speech in Springfield today from @Barackobama on fixing our ailing  politics. Worth reading. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 49, 61 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/ueL3B5Qr7b",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/02\/10\/remarks-president-address-illinois-general-assembly",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697590377478549504",
    "text" : "Really terrific speech in Springfield today from @Barackobama on fixing our ailing  politics. Worth reading. https:\/\/t.co\/ueL3B5Qr7b",
    "id" : 697590377478549504,
    "created_at" : "2016-02-11 01:18:01 +0000",
    "user" : {
      "name" : "David Axelrod",
      "screen_name" : "davidaxelrod",
      "protected" : false,
      "id_str" : "244655353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2948601880\/c6d7f729324c1e592ea9b0879e4abca5_normal.jpeg",
      "id" : 244655353,
      "verified" : true
    }
  },
  "id" : 697852267416911872,
  "created_at" : "2016-02-11 18:38:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben LaBolt",
      "screen_name" : "BenLaBolt",
      "indices" : [ 3, 13 ],
      "id_str" : "114497182",
      "id" : 114497182
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 113, 125 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697851014515462144",
  "text" : "RT @BenLaBolt: 9 yrs ago today I was getting set up on the Hill to tend to the Capitol &amp; IL press corps from @BarackObama's Senate office #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 98, 110 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wherewereyou",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697479287524478976",
    "text" : "9 yrs ago today I was getting set up on the Hill to tend to the Capitol &amp; IL press corps from @BarackObama's Senate office #wherewereyou",
    "id" : 697479287524478976,
    "created_at" : "2016-02-10 17:56:35 +0000",
    "user" : {
      "name" : "Ben LaBolt",
      "screen_name" : "BenLaBolt",
      "protected" : false,
      "id_str" : "114497182",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798634266779389952\/TFMsvBSm_normal.jpg",
      "id" : 114497182,
      "verified" : true
    }
  },
  "id" : 697851014515462144,
  "created_at" : "2016-02-11 18:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 36, 48 ]
    }, {
      "text" : "STEMforAll",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/jLDgjI8gQe",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/02\/11\/stem-all",
      "display_url" : "whitehouse.gov\/blog\/2016\/02\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697842771848073216",
  "text" : "RT @whitehouseostp: As we celebrate #WomenInSTEM, we're thinking about other ways to help expand #STEMforAll \u2192 https:\/\/t.co\/jLDgjI8gQe http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/697832884934021120\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/AWmdGDwfEs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca8zT4mUEAAsxAM.jpg",
        "id_str" : "697832883969331200",
        "id" : 697832883969331200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca8zT4mUEAAsxAM.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/AWmdGDwfEs"
      } ],
      "hashtags" : [ {
        "text" : "WomenInSTEM",
        "indices" : [ 16, 28 ]
      }, {
        "text" : "STEMforAll",
        "indices" : [ 77, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/jLDgjI8gQe",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/02\/11\/stem-all",
        "display_url" : "whitehouse.gov\/blog\/2016\/02\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697832884934021120",
    "text" : "As we celebrate #WomenInSTEM, we're thinking about other ways to help expand #STEMforAll \u2192 https:\/\/t.co\/jLDgjI8gQe https:\/\/t.co\/AWmdGDwfEs",
    "id" : 697832884934021120,
    "created_at" : "2016-02-11 17:21:39 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 697842771848073216,
  "created_at" : "2016-02-11 18:00:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/697835620631076865\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/njL5vT47LY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca81zGvUcAQ8mU3.jpg",
      "id_str" : "697835619364401156",
      "id" : 697835619364401156,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca81zGvUcAQ8mU3.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2500,
        "resize" : "fit",
        "w" : 5000
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/njL5vT47LY"
    } ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 11, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/6viKUcTLud",
      "expanded_url" : "http:\/\/go.wh.gov\/WomenInSTEM",
      "display_url" : "go.wh.gov\/WomenInSTEM"
    } ]
  },
  "geo" : { },
  "id_str" : "697835620631076865",
  "text" : "Who's your #WomenInSTEM hero? Women from across the Administration tell their stories: https:\/\/t.co\/6viKUcTLud https:\/\/t.co\/njL5vT47LY",
  "id" : 697835620631076865,
  "created_at" : "2016-02-11 17:32:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697829642074505217",
  "text" : "RT @Denis44: Being pro-science is only way 2 make sure US continues 2 lead \uD83C\uDF0E. That's why POTUS has made science \uD83D\uDD11 part of Admin. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/bB4J2fU9Uh",
        "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/697767099498782724",
        "display_url" : "twitter.com\/PopSci\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697827549703856129",
    "text" : "Being pro-science is only way 2 make sure US continues 2 lead \uD83C\uDF0E. That's why POTUS has made science \uD83D\uDD11 part of Admin. https:\/\/t.co\/bB4J2fU9Uh",
    "id" : 697827549703856129,
    "created_at" : "2016-02-11 17:00:27 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 697829642074505217,
  "created_at" : "2016-02-11 17:08:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697826606027575296",
  "text" : "RT @POTUS: Way to ace your AP Calc test, Landon! You should come drop some knowledge at the White House Science Fair: https:\/\/t.co\/hFaAgxVd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/hFaAgxVdEE",
        "expanded_url" : "http:\/\/wapo.st\/1RpdCk9",
        "display_url" : "wapo.st\/1RpdCk9"
      } ]
    },
    "geo" : { },
    "id_str" : "697824490344968192",
    "text" : "Way to ace your AP Calc test, Landon! You should come drop some knowledge at the White House Science Fair: https:\/\/t.co\/hFaAgxVdEE",
    "id" : 697824490344968192,
    "created_at" : "2016-02-11 16:48:18 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 697826606027575296,
  "created_at" : "2016-02-11 16:56:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697824422003150848\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/YNx8lhHulQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca8rVOlW8AAGEkv.jpg",
      "id_str" : "697824110957752320",
      "id" : 697824110957752320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca8rVOlW8AAGEkv.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1350,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1575,
        "resize" : "fit",
        "w" : 1195
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YNx8lhHulQ"
    } ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 58, 70 ]
    }, {
      "text" : "CSforAll",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/3i3KY6QcGS",
      "expanded_url" : "http:\/\/pops.ci\/obama",
      "display_url" : "pops.ci\/obama"
    } ]
  },
  "geo" : { },
  "id_str" : "697824422003150848",
  "text" : "Read how @POTUS is helping inspire the next generation of #WomenInSTEM: https:\/\/t.co\/3i3KY6QcGS #CSforAll https:\/\/t.co\/YNx8lhHulQ",
  "id" : 697824422003150848,
  "created_at" : "2016-02-11 16:48:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "indices" : [ 3, 9 ],
      "id_str" : "2800630026",
      "id" : 2800630026
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomeninSTEM",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/F7gM4FrMAV",
      "expanded_url" : "http:\/\/wh.gov\/csforall",
      "display_url" : "wh.gov\/csforall"
    } ]
  },
  "geo" : { },
  "id_str" : "697814969577050112",
  "text" : "RT @Lee44: A year ago, Adrianna Mitchell helped @POTUS write his first line of code. https:\/\/t.co\/F7gM4FrMAV #WomeninSTEM https:\/\/t.co\/PbUz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 37, 43 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lee44\/status\/697813989946978304\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/PbUzRJ7Tji",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca8iH-OWIAEJrzk.jpg",
        "id_str" : "697813987623313409",
        "id" : 697813987623313409,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca8iH-OWIAEJrzk.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/PbUzRJ7Tji"
      } ],
      "hashtags" : [ {
        "text" : "WomeninSTEM",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/F7gM4FrMAV",
        "expanded_url" : "http:\/\/wh.gov\/csforall",
        "display_url" : "wh.gov\/csforall"
      } ]
    },
    "geo" : { },
    "id_str" : "697813989946978304",
    "text" : "A year ago, Adrianna Mitchell helped @POTUS write his first line of code. https:\/\/t.co\/F7gM4FrMAV #WomeninSTEM https:\/\/t.co\/PbUzRJ7Tji",
    "id" : 697813989946978304,
    "created_at" : "2016-02-11 16:06:34 +0000",
    "user" : {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "protected" : false,
      "id_str" : "2800630026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626378024359870464\/dc8kq4yl_normal.png",
      "id" : 2800630026,
      "verified" : true
    }
  },
  "id" : 697814969577050112,
  "created_at" : "2016-02-11 16:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Glamour",
      "screen_name" : "glamourmag",
      "indices" : [ 101, 112 ],
      "id_str" : "19247844",
      "id" : 19247844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/NvlyzmyUfr",
      "expanded_url" : "http:\/\/bit.ly\/1n4TuI5",
      "display_url" : "bit.ly\/1n4TuI5"
    } ]
  },
  "geo" : { },
  "id_str" : "697808322125283329",
  "text" : "RT @NASA: Meet the four women astronauts who can't wait to go to Mars: https:\/\/t.co\/NvlyzmyUfr   Via @glamourmag #WomenInSTEM https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glamour",
        "screen_name" : "glamourmag",
        "indices" : [ 91, 102 ],
        "id_str" : "19247844",
        "id" : 19247844
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/697805795430428672\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/mWFkEv00GZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca8arHXWEAAvHkU.jpg",
        "id_str" : "697805795279376384",
        "id" : 697805795279376384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca8arHXWEAAvHkU.jpg",
        "sizes" : [ {
          "h" : 548,
          "resize" : "fit",
          "w" : 724
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 724
        } ],
        "display_url" : "pic.twitter.com\/mWFkEv00GZ"
      } ],
      "hashtags" : [ {
        "text" : "WomenInSTEM",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/NvlyzmyUfr",
        "expanded_url" : "http:\/\/bit.ly\/1n4TuI5",
        "display_url" : "bit.ly\/1n4TuI5"
      } ]
    },
    "geo" : { },
    "id_str" : "697805795430428672",
    "text" : "Meet the four women astronauts who can't wait to go to Mars: https:\/\/t.co\/NvlyzmyUfr   Via @glamourmag #WomenInSTEM https:\/\/t.co\/mWFkEv00GZ",
    "id" : 697805795430428672,
    "created_at" : "2016-02-11 15:34:00 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 697808322125283329,
  "created_at" : "2016-02-11 15:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 3, 10 ],
      "id_str" : "19722699",
      "id" : 19722699
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/697767099498782724\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/4gtR71YCgV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca439QKUkAAcNLm.jpg",
      "id_str" : "697556517738811392",
      "id" : 697556517738811392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca439QKUkAAcNLm.jpg",
      "sizes" : [ {
        "h" : 1268,
        "resize" : "fit",
        "w" : 1797
      }, {
        "h" : 723,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4gtR71YCgV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/o1oG1OcG9J",
      "expanded_url" : "http:\/\/pops.ci\/obama",
      "display_url" : "pops.ci\/obama"
    } ]
  },
  "geo" : { },
  "id_str" : "697798952373133312",
  "text" : "RT @PopSci: EXCLUSIVE: Our interview with @POTUS on science, tech, and how to win the future https:\/\/t.co\/o1oG1OcG9J https:\/\/t.co\/4gtR71YCgV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 30, 36 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PopSci\/status\/697767099498782724\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/4gtR71YCgV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca439QKUkAAcNLm.jpg",
        "id_str" : "697556517738811392",
        "id" : 697556517738811392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca439QKUkAAcNLm.jpg",
        "sizes" : [ {
          "h" : 1268,
          "resize" : "fit",
          "w" : 1797
        }, {
          "h" : 723,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4gtR71YCgV"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/o1oG1OcG9J",
        "expanded_url" : "http:\/\/pops.ci\/obama",
        "display_url" : "pops.ci\/obama"
      } ]
    },
    "geo" : { },
    "id_str" : "697767099498782724",
    "text" : "EXCLUSIVE: Our interview with @POTUS on science, tech, and how to win the future https:\/\/t.co\/o1oG1OcG9J https:\/\/t.co\/4gtR71YCgV",
    "id" : 697767099498782724,
    "created_at" : "2016-02-11 13:00:15 +0000",
    "user" : {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "protected" : false,
      "id_str" : "19722699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793561660833267712\/Y5RPH9Te_normal.jpg",
      "id" : 19722699,
      "verified" : true
    }
  },
  "id" : 697798952373133312,
  "created_at" : "2016-02-11 15:06:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697583512455544832\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/gq1Vtb1LTA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca5QgMyXEAEGx9C.jpg",
      "id_str" : "697583506407493633",
      "id" : 697583506407493633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca5QgMyXEAEGx9C.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gq1Vtb1LTA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Toz670bmz4",
      "expanded_url" : "http:\/\/go.wh.gov\/tF97PZ",
      "display_url" : "go.wh.gov\/tF97PZ"
    } ]
  },
  "geo" : { },
  "id_str" : "697583512455544832",
  "text" : ".@POTUS checks out his old digs from back when he was a State Senator in Illinois: https:\/\/t.co\/Toz670bmz4 https:\/\/t.co\/gq1Vtb1LTA",
  "id" : 697583512455544832,
  "created_at" : "2016-02-11 00:50:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 36, 45 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/fdSmWlBMVd",
      "expanded_url" : "http:\/\/snapchat.com\/add\/whitehouse",
      "display_url" : "snapchat.com\/add\/whitehouse"
    }, {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/pmvd6SWv5A",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/80c18284-a845-46f1-bf2f-c14fc9bcfcef",
      "display_url" : "amp.twimg.com\/v\/80c18284-a84\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697573705518452736",
  "text" : "Go behind the scenes with @POTUS on @Snapchat during his trip to Springfield: https:\/\/t.co\/fdSmWlBMVd\nhttps:\/\/t.co\/pmvd6SWv5A",
  "id" : 697573705518452736,
  "created_at" : "2016-02-11 00:11:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhereWereYou",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697555777796644864",
  "text" : "RT @FLOTUS: It was freezing that day in Springfield, but I was filled with hope and ready for this adventure. -mo #WhereWereYou https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/697555146855698432\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/aJTZb6PqNq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca42eNbW0AAxQbu.jpg",
        "id_str" : "697554884917383168",
        "id" : 697554884917383168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca42eNbW0AAxQbu.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/aJTZb6PqNq"
      } ],
      "hashtags" : [ {
        "text" : "WhereWereYou",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697555146855698432",
    "text" : "It was freezing that day in Springfield, but I was filled with hope and ready for this adventure. -mo #WhereWereYou https:\/\/t.co\/aJTZb6PqNq",
    "id" : 697555146855698432,
    "created_at" : "2016-02-10 22:58:01 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 697555777796644864,
  "created_at" : "2016-02-10 23:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/AzqVt37Xq6",
      "expanded_url" : "http:\/\/snpy.tv\/1osCtIA",
      "display_url" : "snpy.tv\/1osCtIA"
    } ]
  },
  "geo" : { },
  "id_str" : "697548621802295296",
  "text" : "\"When I hear voices in either party boast of their refusal to compromise\u2026I'm not impressed.\" \u2014@POTUS https:\/\/t.co\/AzqVt37Xq6",
  "id" : 697548621802295296,
  "created_at" : "2016-02-10 22:32:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/gJhU5xeXSd",
      "expanded_url" : "http:\/\/snpy.tv\/1LhBoIn",
      "display_url" : "snpy.tv\/1LhBoIn"
    } ]
  },
  "geo" : { },
  "id_str" : "697541115990437889",
  "text" : "Nine years after @POTUS first announced his candidacy for President, he still believes in a politics of hope. https:\/\/t.co\/gJhU5xeXSd",
  "id" : 697541115990437889,
  "created_at" : "2016-02-10 22:02:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/B24H4OIUX7",
      "expanded_url" : "http:\/\/snpy.tv\/1LhxYp8",
      "display_url" : "snpy.tv\/1LhxYp8"
    } ]
  },
  "geo" : { },
  "id_str" : "697532233897414659",
  "text" : "\u201CWe\u2019ve gotten a heck of a lot done these past seven years, despite the gridlock.\u201D \u2014@POTUS https:\/\/t.co\/B24H4OIUX7",
  "id" : 697532233897414659,
  "created_at" : "2016-02-10 21:26:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/RAgGhPNUxB",
      "expanded_url" : "http:\/\/snpy.tv\/1Q9jQpo",
      "display_url" : "snpy.tv\/1Q9jQpo"
    } ]
  },
  "geo" : { },
  "id_str" : "697528713869725698",
  "text" : "\"If 99% of us voted, it wouldn\u2019t matter how much the one percent spent on our elections.\" \u2014@POTUS https:\/\/t.co\/RAgGhPNUxB",
  "id" : 697528713869725698,
  "created_at" : "2016-02-10 21:12:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/697517100458385409\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/AzgWmbymFi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4UGuDUEAAv-rM.jpg",
      "id_str" : "697517097962704896",
      "id" : 697517097962704896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4UGuDUEAAv-rM.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      } ],
      "display_url" : "pic.twitter.com\/AzgWmbymFi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697520563368169472",
  "text" : "RT @vj44: .@POTUS in his old Senate office https:\/\/t.co\/AzgWmbymFi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/697517100458385409\/photo\/1",
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/AzgWmbymFi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4UGuDUEAAv-rM.jpg",
        "id_str" : "697517097962704896",
        "id" : 697517097962704896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4UGuDUEAAv-rM.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 4032,
          "resize" : "fit",
          "w" : 3024
        } ],
        "display_url" : "pic.twitter.com\/AzgWmbymFi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697517100458385409",
    "text" : ".@POTUS in his old Senate office https:\/\/t.co\/AzgWmbymFi",
    "id" : 697517100458385409,
    "created_at" : "2016-02-10 20:26:50 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 697520563368169472,
  "created_at" : "2016-02-10 20:40:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/0BRePTUQhz",
      "expanded_url" : "http:\/\/snpy.tv\/1PlUlOc",
      "display_url" : "snpy.tv\/1PlUlOc"
    } ]
  },
  "geo" : { },
  "id_str" : "697518979091447810",
  "text" : "RT if you agree: Politicians shouldn\u2019t pick their voters.\n\nVoters should pick their politicians. https:\/\/t.co\/0BRePTUQhz",
  "id" : 697518979091447810,
  "created_at" : "2016-02-10 20:34:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697511471010488320\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/58AqkT2SAr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4O9W8XEAAFvUI.jpg",
      "id_str" : "697511439582564352",
      "id" : 697511439582564352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4O9W8XEAAFvUI.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2112,
        "resize" : "fit",
        "w" : 3168
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/58AqkT2SAr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697511471010488320",
  "text" : "\"Nine years to the day I first announced for this office, I still believe in a politics of hope.\" \u2014@POTUS https:\/\/t.co\/58AqkT2SAr",
  "id" : 697511471010488320,
  "created_at" : "2016-02-10 20:04:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697511054163779584\/photo\/1",
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/T7IotAkDgR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4Ok-zWcAAsmK-.jpg",
      "id_str" : "697511020785463296",
      "id" : 697511020785463296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4Ok-zWcAAsmK-.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1060,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/T7IotAkDgR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697511054163779584",
  "text" : "\"Through his will &amp; his words &amp; his character, he held a nation together &amp; helped free a people\" \u2014@POTUS on Lincoln https:\/\/t.co\/T7IotAkDgR",
  "id" : 697511054163779584,
  "created_at" : "2016-02-10 20:02:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697509794945626112\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/iBHzFi0jgv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4NWV1W0AAb4RA.jpg",
      "id_str" : "697509669758226432",
      "id" : 697509669758226432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4NWV1W0AAb4RA.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/iBHzFi0jgv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697509794945626112",
  "text" : "\"If 99% of us voted, it wouldn\u2019t matter how much the one percent spent on our elections.\" \u2014@POTUS https:\/\/t.co\/iBHzFi0jgv",
  "id" : 697509794945626112,
  "created_at" : "2016-02-10 19:57:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697509472403591169",
  "text" : "\"We can\u2019t move forward if all we do is tear each other down\" \u2014@POTUS on our need for a better politics",
  "id" : 697509472403591169,
  "created_at" : "2016-02-10 19:56:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697508132562604034",
  "text" : "\"I ask every state in America to join us...make it easier for your constituents to get out and vote.\" \u2014@POTUS to the Illinois legislature",
  "id" : 697508132562604034,
  "created_at" : "2016-02-10 19:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697507777527291904\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/dX5nOLBZaB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4LkfDXIAE2yI1.jpg",
      "id_str" : "697507713727799297",
      "id" : 697507713727799297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4LkfDXIAE2yI1.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/dX5nOLBZaB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697507777527291904",
  "text" : "\"A third step toward a better politics is to make voting easier, not harder.\" \u2014@POTUS https:\/\/t.co\/dX5nOLBZaB",
  "id" : 697507777527291904,
  "created_at" : "2016-02-10 19:49:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697507403357679616\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/jbyAHZ4cse",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4LNBuWIAEG66r.jpg",
      "id_str" : "697507310718033921",
      "id" : 697507310718033921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4LNBuWIAEG66r.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/jbyAHZ4cse"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697507403357679616",
  "text" : "\"Politicians shouldn\u2019t pick their voters; voters should pick their politicians.\" \u2014@POTUS https:\/\/t.co\/jbyAHZ4cse",
  "id" : 697507403357679616,
  "created_at" : "2016-02-10 19:48:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697507040722337792",
  "text" : "\"A handful of families and hidden interests shouldn\u2019t be able to bankroll elections in the greatest democracy on Earth.\" \u2014@POTUS",
  "id" : 697507040722337792,
  "created_at" : "2016-02-10 19:46:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697506819003019265",
  "text" : "\"I still support a Constitutional amendment to set reasonable limits on financial influence in America\u2019s elections.\" \u2014@POTUS",
  "id" : 697506819003019265,
  "created_at" : "2016-02-10 19:45:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697506680754536450",
  "text" : "\"I don\u2019t believe that money is speech, or that political spending should have no limits.\" \u2014@POTUS",
  "id" : 697506680754536450,
  "created_at" : "2016-02-10 19:45:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697506560281616385\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/mW820qMJ0P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4Kev8WAAQtgI2.jpg",
      "id_str" : "697506515670925316",
      "id" : 697506515670925316,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4Kev8WAAQtgI2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mW820qMJ0P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697506560281616385",
  "text" : "\"150 families have spent as much on the presidential race as the rest of America combined.\" \u2014@POTUS https:\/\/t.co\/mW820qMJ0P",
  "id" : 697506560281616385,
  "created_at" : "2016-02-10 19:44:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697504494180036610",
  "text" : "\"When I\u2019ve got an opportunity to find some common ground\u2026that doesn\u2019t make me a sellout to my own party.\" \u2014@POTUS",
  "id" : 697504494180036610,
  "created_at" : "2016-02-10 19:36:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697504044374499329",
  "text" : "\"Unlimited dark money...drowns out ordinary voices, and far too many of us surrender our voices entirely by choosing not to vote.\" \u2014@POTUS",
  "id" : 697504044374499329,
  "created_at" : "2016-02-10 19:34:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeThePeople",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697503114883166210",
  "text" : "\"The success of this American experiment of ours rests on engaging all our citizens in this work.\" \u2014@POTUS #WeThePeople",
  "id" : 697503114883166210,
  "created_at" : "2016-02-10 19:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697501348946956288",
  "text" : "RT @WHLive: \"As an American citizen, I know that our progress is not inevitable.  It must be fought for and won by all of us\" \u2014@POTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 115, 121 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697501302419562497",
    "text" : "\"As an American citizen, I know that our progress is not inevitable.  It must be fought for and won by all of us\" \u2014@POTUS",
    "id" : 697501302419562497,
    "created_at" : "2016-02-10 19:24:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 697501348946956288,
  "created_at" : "2016-02-10 19:24:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697501137629532160\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/dMPyh5z5Ut",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4Fj0ZW4AYscQP.jpg",
      "id_str" : "697501105207566342",
      "id" : 697501105207566342,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4Fj0ZW4AYscQP.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dMPyh5z5Ut"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697501137629532160",
  "text" : "\"Next year, I\u2019ll still hold the most important title of all\u2014that of citizen.\" \u2014@POTUS https:\/\/t.co\/dMPyh5z5Ut",
  "id" : 697501137629532160,
  "created_at" : "2016-02-10 19:23:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697500882309672962\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/iS9voT8aJ6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4FT7cWEAAs8Mh.jpg",
      "id_str" : "697500832221237248",
      "id" : 697500832221237248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4FT7cWEAAs8Mh.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/iS9voT8aJ6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697500882309672962",
  "text" : "\"There is no doubt that America\u2019s better off today than when I took office.\" \u2014@POTUS https:\/\/t.co\/iS9voT8aJ6",
  "id" : 697500882309672962,
  "created_at" : "2016-02-10 19:22:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/697500482261139456\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/SNWaNCBzoV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4E9qPWEAACJGK.jpg",
      "id_str" : "697500449646186496",
      "id" : 697500449646186496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4E9qPWEAACJGK.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/SNWaNCBzoV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697500518747398145",
  "text" : "RT @WHLive: \u201CWe\u2019ve helped our businesses create 14 million new jobs over the past six years\" \u2014@POTUS https:\/\/t.co\/SNWaNCBzoV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 82, 88 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/697500482261139456\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/SNWaNCBzoV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4E9qPWEAACJGK.jpg",
        "id_str" : "697500449646186496",
        "id" : 697500449646186496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4E9qPWEAACJGK.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/SNWaNCBzoV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697500482261139456",
    "text" : "\u201CWe\u2019ve helped our businesses create 14 million new jobs over the past six years\" \u2014@POTUS https:\/\/t.co\/SNWaNCBzoV",
    "id" : 697500482261139456,
    "created_at" : "2016-02-10 19:20:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 697500518747398145,
  "created_at" : "2016-02-10 19:20:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/697500241797509121\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/9naUB17cXc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4EvRoXIAAH0d0.jpg",
      "id_str" : "697500202522058752",
      "id" : 697500202522058752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4EvRoXIAAH0d0.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/9naUB17cXc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697500241797509121",
  "text" : "\u201CWe saved the economy from Depression and brought back an auto industry from the brink of collapse.\u201D \u2014@POTUS https:\/\/t.co\/9naUB17cXc",
  "id" : 697500241797509121,
  "created_at" : "2016-02-10 19:19:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697500086713085952\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/VOd8CSn1YG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4ElhVWAAABr5E.jpg",
      "id_str" : "697500034938568704",
      "id" : 697500034938568704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4ElhVWAAABr5E.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VOd8CSn1YG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697500086713085952",
  "text" : "\u201CWe\u2019ve gotten a heck of a lot done these past seven years, despite the gridlock.\u201D \u2014@POTUS https:\/\/t.co\/VOd8CSn1YG",
  "id" : 697500086713085952,
  "created_at" : "2016-02-10 19:19:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697499578006958082\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/7I1ZHmapMx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4EJ1iW0AMJiTo.jpg",
      "id_str" : "697499559325519875",
      "id" : 697499559325519875,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4EJ1iW0AMJiTo.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7I1ZHmapMx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697499578006958082",
  "text" : "\"9 years ago today, on the steps of the Old State Capitol\u2026I announced my candidacy for President.\" \u2014@POTUS https:\/\/t.co\/7I1ZHmapMx",
  "id" : 697499578006958082,
  "created_at" : "2016-02-10 19:17:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697499030230822915",
  "text" : "\"I\u2019ve always believed so deeply in a better kind of politics because of what I learned here, in this legislature.\" \u2014@POTUS in Illinois",
  "id" : 697499030230822915,
  "created_at" : "2016-02-10 19:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697498292167569409",
  "text" : "RT @WHLive: \"We found that despite all our surface differences\u2014Democrats and Republicans...we actually had a lot in common.\" \u2014@POTUS on the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 114, 120 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697498269153370112",
    "text" : "\"We found that despite all our surface differences\u2014Democrats and Republicans...we actually had a lot in common.\" \u2014@POTUS on the IL Senate",
    "id" : 697498269153370112,
    "created_at" : "2016-02-10 19:12:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 697498292167569409,
  "created_at" : "2016-02-10 19:12:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697497255859875840",
  "text" : "RT @WHLive: \"I was passionate, idealistic, and ready to make a difference.\" \u2014@POTUS reflecting on when he first got to the Illinois State S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 65, 71 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697497229247057922",
    "text" : "\"I was passionate, idealistic, and ready to make a difference.\" \u2014@POTUS reflecting on when he first got to the Illinois State Senate",
    "id" : 697497229247057922,
    "created_at" : "2016-02-10 19:07:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 697497255859875840,
  "created_at" : "2016-02-10 19:07:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697496384640049152\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/9t0ASZ9YLQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca4BMBzWEAAYgOE.jpg",
      "id_str" : "697496298442854400",
      "id" : 697496298442854400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca4BMBzWEAAYgOE.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2112,
        "resize" : "fit",
        "w" : 3168
      } ],
      "display_url" : "pic.twitter.com\/9t0ASZ9YLQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/X64sZjPc26",
      "expanded_url" : "http:\/\/go.wh.gov\/C6N66R",
      "display_url" : "go.wh.gov\/C6N66R"
    } ]
  },
  "geo" : { },
  "id_str" : "697496384640049152",
  "text" : ".@POTUS returns to Springfield, IL, where he launched his campaign 9 years ago.\n\nWatch \u2192 https:\/\/t.co\/X64sZjPc26 https:\/\/t.co\/9t0ASZ9YLQ",
  "id" : 697496384640049152,
  "created_at" : "2016-02-10 19:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/697488977016688640\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/4kO9grp8dU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca36hyvVIAIpM3L.jpg",
      "id_str" : "697488975775211522",
      "id" : 697488975775211522,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca36hyvVIAIpM3L.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4kO9grp8dU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697489776425865216",
  "text" : "RT @vj44: .@POTUS with his former colleagues in the State Senate https:\/\/t.co\/4kO9grp8dU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/697488977016688640\/photo\/1",
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/4kO9grp8dU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca36hyvVIAIpM3L.jpg",
        "id_str" : "697488975775211522",
        "id" : 697488975775211522,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca36hyvVIAIpM3L.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 3024,
          "resize" : "fit",
          "w" : 4032
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4kO9grp8dU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697488977016688640",
    "text" : ".@POTUS with his former colleagues in the State Senate https:\/\/t.co\/4kO9grp8dU",
    "id" : 697488977016688640,
    "created_at" : "2016-02-10 18:35:05 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 697489776425865216,
  "created_at" : "2016-02-10 18:38:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697485531517710337\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/BQBshJwrYk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca33TnwVAAASzgj.jpg",
      "id_str" : "697485433773555712",
      "id" : 697485433773555712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca33TnwVAAASzgj.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BQBshJwrYk"
    } ],
    "hashtags" : [ {
      "text" : "WhereWereYou",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/uBjUxxkSY3",
      "expanded_url" : "http:\/\/go.wh.gov\/Springfield",
      "display_url" : "go.wh.gov\/Springfield"
    } ]
  },
  "geo" : { },
  "id_str" : "697485531517710337",
  "text" : "9 years later, @POTUS returns to the place where it all began: https:\/\/t.co\/uBjUxxkSY3 #WhereWereYou https:\/\/t.co\/BQBshJwrYk",
  "id" : 697485531517710337,
  "created_at" : "2016-02-10 18:21:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/697478635230519296\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/mZ3VWGCzwv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3xHf9WIAEjur7.jpg",
      "id_str" : "697478628452474881",
      "id" : 697478628452474881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3xHf9WIAEjur7.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mZ3VWGCzwv"
    } ],
    "hashtags" : [ {
      "text" : "WhereWereYou",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697479362233282560",
  "text" : "RT @ks44: The Old State Capitol \u2013 where it all began 9 years ago today. #WhereWereYou https:\/\/t.co\/mZ3VWGCzwv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/697478635230519296\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/mZ3VWGCzwv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3xHf9WIAEjur7.jpg",
        "id_str" : "697478628452474881",
        "id" : 697478628452474881,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3xHf9WIAEjur7.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mZ3VWGCzwv"
      } ],
      "hashtags" : [ {
        "text" : "WhereWereYou",
        "indices" : [ 62, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697478635230519296",
    "text" : "The Old State Capitol \u2013 where it all began 9 years ago today. #WhereWereYou https:\/\/t.co\/mZ3VWGCzwv",
    "id" : 697478635230519296,
    "created_at" : "2016-02-10 17:53:59 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 697479362233282560,
  "created_at" : "2016-02-10 17:56:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697474939729813504",
  "text" : "RT @Schultz44: Back to where it all began! @POTUS arrives in Springfield nine years - to the day - after announcing bid for WH. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 28, 34 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/697472359129837571\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/bHA09Xa6gD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3rZ_GW0AEwYbj.jpg",
        "id_str" : "697472348979646465",
        "id" : 697472348979646465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3rZ_GW0AEwYbj.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bHA09Xa6gD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697472359129837571",
    "text" : "Back to where it all began! @POTUS arrives in Springfield nine years - to the day - after announcing bid for WH. https:\/\/t.co\/bHA09Xa6gD",
    "id" : 697472359129837571,
    "created_at" : "2016-02-10 17:29:03 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 697474939729813504,
  "created_at" : "2016-02-10 17:39:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697471767367946241",
  "text" : "RT @vj44: Thank you Suzanne Barakat for sharing your story w\/ @POTUS last week \u2013 your strength is inspiring. We stand with you https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 52, 58 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/AFdeiRJfUK",
        "expanded_url" : "http:\/\/1.usa.gov\/1PzYFHt",
        "display_url" : "1.usa.gov\/1PzYFHt"
      } ]
    },
    "geo" : { },
    "id_str" : "697463713746452481",
    "text" : "Thank you Suzanne Barakat for sharing your story w\/ @POTUS last week \u2013 your strength is inspiring. We stand with you https:\/\/t.co\/AFdeiRJfUK",
    "id" : 697463713746452481,
    "created_at" : "2016-02-10 16:54:42 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 697471767367946241,
  "created_at" : "2016-02-10 17:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Genius",
      "screen_name" : "Genius",
      "indices" : [ 3, 10 ],
      "id_str" : "72073289",
      "id" : 72073289
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Genius\/status\/697452709704822784\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/R70xBffhbz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3ZizlWwAE77vq.jpg",
      "id_str" : "697452709297963009",
      "id" : 697452709297963009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3ZizlWwAE77vq.jpg",
      "sizes" : [ {
        "h" : 603,
        "resize" : "fit",
        "w" : 930
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 930
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R70xBffhbz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/taf6jNt5vU",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/02\/09\/president-obamas-2017-budget-innovating-better-future",
      "display_url" : "whitehouse.gov\/blog\/2016\/02\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697466698610380801",
  "text" : "RT @Genius: Get the real story. @WhiteHouse uses Genius to annotate POTUS' budget message. \uD83D\uDCB8https:\/\/t.co\/taf6jNt5vU. https:\/\/t.co\/R70xBffhbz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 20, 31 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Genius\/status\/697452709704822784\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/R70xBffhbz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3ZizlWwAE77vq.jpg",
        "id_str" : "697452709297963009",
        "id" : 697452709297963009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3ZizlWwAE77vq.jpg",
        "sizes" : [ {
          "h" : 603,
          "resize" : "fit",
          "w" : 930
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 930
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/R70xBffhbz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/taf6jNt5vU",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/02\/09\/president-obamas-2017-budget-innovating-better-future",
        "display_url" : "whitehouse.gov\/blog\/2016\/02\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697452709704822784",
    "text" : "Get the real story. @WhiteHouse uses Genius to annotate POTUS' budget message. \uD83D\uDCB8https:\/\/t.co\/taf6jNt5vU. https:\/\/t.co\/R70xBffhbz",
    "id" : 697452709704822784,
    "created_at" : "2016-02-10 16:10:58 +0000",
    "user" : {
      "name" : "Rap Genius",
      "screen_name" : "RapGenius",
      "protected" : false,
      "id_str" : "735773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719602655337656321\/kQUzR2Es_normal.jpg",
      "id" : 735773,
      "verified" : false
    }
  },
  "id" : 697466698610380801,
  "created_at" : "2016-02-10 17:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "indices" : [ 3, 12 ],
      "id_str" : "113439399",
      "id" : 113439399
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSforAll",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/tCGhq9qOlT",
      "expanded_url" : "http:\/\/bit.ly\/1o37ItM",
      "display_url" : "bit.ly\/1o37ItM"
    } ]
  },
  "geo" : { },
  "id_str" : "697463598872834048",
  "text" : "RT @smrtgrls: We went to the @WhiteHouse to talk with Smarties who are Championing #CSforAll! Take a look \u2192https:\/\/t.co\/tCGhq9qOlT https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 15, 26 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/smrtgrls\/status\/697458831375216644\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Ztd9Yortsx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3fG01UUAAl-TJ.png",
        "id_str" : "697458825666777088",
        "id" : 697458825666777088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3fG01UUAAl-TJ.png",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 615
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ztd9Yortsx"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/smrtgrls\/status\/697458831375216644\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Ztd9Yortsx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3fHGpUAAEXFBl.jpg",
        "id_str" : "697458830448263169",
        "id" : 697458830448263169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3fHGpUAAEXFBl.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Ztd9Yortsx"
      } ],
      "hashtags" : [ {
        "text" : "CSforAll",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/tCGhq9qOlT",
        "expanded_url" : "http:\/\/bit.ly\/1o37ItM",
        "display_url" : "bit.ly\/1o37ItM"
      } ]
    },
    "geo" : { },
    "id_str" : "697458831375216644",
    "text" : "We went to the @WhiteHouse to talk with Smarties who are Championing #CSforAll! Take a look \u2192https:\/\/t.co\/tCGhq9qOlT https:\/\/t.co\/Ztd9Yortsx",
    "id" : 697458831375216644,
    "created_at" : "2016-02-10 16:35:18 +0000",
    "user" : {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "protected" : false,
      "id_str" : "113439399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700467562413297664\/0qESscTd_normal.png",
      "id" : 113439399,
      "verified" : true
    }
  },
  "id" : 697463598872834048,
  "created_at" : "2016-02-10 16:54:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/697460981811654656\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Z2TYTcViIK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3gpvYUkAACeU4.jpg",
      "id_str" : "697460525010030592",
      "id" : 697460525010030592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3gpvYUkAACeU4.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2112,
        "resize" : "fit",
        "w" : 3168
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Z2TYTcViIK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/uBjUxx3hzt",
      "expanded_url" : "http:\/\/go.wh.gov\/Springfield",
      "display_url" : "go.wh.gov\/Springfield"
    } ]
  },
  "geo" : { },
  "id_str" : "697460981811654656",
  "text" : "9 yrs. ago, @POTUS announced his candidacy for President. \nToday, he's back in Springfield: https:\/\/t.co\/uBjUxx3hzt https:\/\/t.co\/Z2TYTcViIK",
  "id" : 697460981811654656,
  "created_at" : "2016-02-10 16:43:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697452567996076034\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/9amm1ziNDE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca3YoE-XIAABgiB.jpg",
      "id_str" : "697451700353966080",
      "id" : 697451700353966080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca3YoE-XIAABgiB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9amm1ziNDE"
    } ],
    "hashtags" : [ {
      "text" : "AshWednesday",
      "indices" : [ 61, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697452567996076034",
  "text" : "\"Today, Michelle and I join our fellow Christians in marking #AshWednesday.\" \u2014@POTUS https:\/\/t.co\/9amm1ziNDE",
  "id" : 697452567996076034,
  "created_at" : "2016-02-10 16:10:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 92, 101 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhereWereYou",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697437130373488640",
  "text" : "RT @vj44: 9 years later: @POTUS heads back to Springfield\nShare memories with #WhereWereYou\n@PressSec &amp; I will join in all day\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 82, 91 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhereWereYou",
        "indices" : [ 68, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/nQsTVaLbTY",
        "expanded_url" : "http:\/\/go.wh.gov\/springfield",
        "display_url" : "go.wh.gov\/springfield"
      } ]
    },
    "geo" : { },
    "id_str" : "697437055379382272",
    "text" : "9 years later: @POTUS heads back to Springfield\nShare memories with #WhereWereYou\n@PressSec &amp; I will join in all day\nhttps:\/\/t.co\/nQsTVaLbTY",
    "id" : 697437055379382272,
    "created_at" : "2016-02-10 15:08:46 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 697437130373488640,
  "created_at" : "2016-02-10 15:09:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 65, 73 ],
      "id_str" : "18734310",
      "id" : 18734310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB50",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/93dHH09nbA",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/8f9adf65-495c-43e2-bcce-95d01a9e0727",
      "display_url" : "amp.twimg.com\/v\/8f9adf65-495\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697248333006385152",
  "text" : "Watch @POTUS call to congratulate the Super Bowl champion Denver @Broncos. #SB50\nhttps:\/\/t.co\/93dHH09nbA",
  "id" : 697248333006385152,
  "created_at" : "2016-02-10 02:38:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/697238131213336577\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Ia3lw1kdID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca0WWw9VIAAYGSH.jpg",
      "id_str" : "697238097667366912",
      "id" : 697238097667366912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca0WWw9VIAAYGSH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ia3lw1kdID"
    } ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 37, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697238164902146048",
  "text" : "RT @PressSec: On the Supreme Court's #CleanPowerPlan decision, we remain confident we will prevail on the merits. https:\/\/t.co\/Ia3lw1kdID",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/697238131213336577\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/Ia3lw1kdID",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ca0WWw9VIAAYGSH.jpg",
        "id_str" : "697238097667366912",
        "id" : 697238097667366912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ca0WWw9VIAAYGSH.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ia3lw1kdID"
      } ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 23, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697238131213336577",
    "text" : "On the Supreme Court's #CleanPowerPlan decision, we remain confident we will prevail on the merits. https:\/\/t.co\/Ia3lw1kdID",
    "id" : 697238131213336577,
    "created_at" : "2016-02-10 01:58:19 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 697238164902146048,
  "created_at" : "2016-02-10 01:58:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/MpELtNtuSA",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=PuUex087EOw",
      "display_url" : "youtube.com\/watch?v=PuUex0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697197804511481857",
  "text" : "RT @PressSec: Sure do. Often the highlight of MY week. New edition every Friday! Check out the latest one: https:\/\/t.co\/MpELtNtuSA https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/MpELtNtuSA",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=PuUex087EOw",
        "display_url" : "youtube.com\/watch?v=PuUex0\u2026"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/EZOlGFPVbH",
        "expanded_url" : "https:\/\/twitter.com\/Politicon\/status\/697189676067586048",
        "display_url" : "twitter.com\/Politicon\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697197195792003073",
    "text" : "Sure do. Often the highlight of MY week. New edition every Friday! Check out the latest one: https:\/\/t.co\/MpELtNtuSA https:\/\/t.co\/EZOlGFPVbH",
    "id" : 697197195792003073,
    "created_at" : "2016-02-09 23:15:39 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 697197804511481857,
  "created_at" : "2016-02-09 23:18:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "priorities",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "csforall",
      "indices" : [ 105, 114 ]
    }, {
      "text" : "askpresssec",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697195610584252416",
  "text" : "RT @PressSec: Why not cut tax loopholes for rich &amp; help Americans get skills to succeed? #priorities #csforall #askpresssec https:\/\/t.co\/LL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "priorities",
        "indices" : [ 79, 90 ]
      }, {
        "text" : "csforall",
        "indices" : [ 91, 100 ]
      }, {
        "text" : "askpresssec",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/LLpnsld8Ci",
        "expanded_url" : "https:\/\/twitter.com\/SamSouvannason\/status\/697152489863450630",
        "display_url" : "twitter.com\/SamSouvannason\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "697195338403172353",
    "text" : "Why not cut tax loopholes for rich &amp; help Americans get skills to succeed? #priorities #csforall #askpresssec https:\/\/t.co\/LLpnsld8Ci",
    "id" : 697195338403172353,
    "created_at" : "2016-02-09 23:08:16 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 697195610584252416,
  "created_at" : "2016-02-09 23:09:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Tom Elliott",
      "screen_name" : "tomselliott",
      "indices" : [ 15, 27 ],
      "id_str" : "49698174",
      "id" : 49698174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697194504001032192",
  "text" : "RT @PressSec: .@tomselliott We've invested in middle class families &amp; cut deficit. America's economy is now the envy of the world https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Elliott",
        "screen_name" : "tomselliott",
        "indices" : [ 1, 13 ],
        "id_str" : "49698174",
        "id" : 49698174
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/697194054027620352\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/kz9Bh94dFm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaztojUUUAAIXa8.jpg",
        "id_str" : "697193323266592768",
        "id" : 697193323266592768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaztojUUUAAIXa8.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/kz9Bh94dFm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "697151616525299713",
    "geo" : { },
    "id_str" : "697194054027620352",
    "in_reply_to_user_id" : 49698174,
    "text" : ".@tomselliott We've invested in middle class families &amp; cut deficit. America's economy is now the envy of the world https:\/\/t.co\/kz9Bh94dFm",
    "id" : 697194054027620352,
    "in_reply_to_status_id" : 697151616525299713,
    "created_at" : "2016-02-09 23:03:10 +0000",
    "in_reply_to_screen_name" : "tomselliott",
    "in_reply_to_user_id_str" : "49698174",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 697194504001032192,
  "created_at" : "2016-02-09 23:04:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PressSec\/status\/697187889634000898\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/c5ynGmLJzv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cazor8kWwAA6KLE.jpg",
      "id_str" : "697187884026216448",
      "id" : 697187884026216448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cazor8kWwAA6KLE.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/c5ynGmLJzv"
    } ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 61, 73 ]
    }, {
      "text" : "POTUSbudget",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697190828587020288",
  "text" : "RT @PressSec: Ready to get started for latest installment of #AskPressSec on the #POTUSbudget https:\/\/t.co\/c5ynGmLJzv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PressSec\/status\/697187889634000898\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/c5ynGmLJzv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cazor8kWwAA6KLE.jpg",
        "id_str" : "697187884026216448",
        "id" : 697187884026216448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cazor8kWwAA6KLE.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/c5ynGmLJzv"
      } ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 47, 59 ]
      }, {
        "text" : "POTUSbudget",
        "indices" : [ 67, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697187889634000898",
    "text" : "Ready to get started for latest installment of #AskPressSec on the #POTUSbudget https:\/\/t.co\/c5ynGmLJzv",
    "id" : 697187889634000898,
    "created_at" : "2016-02-09 22:38:40 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 697190828587020288,
  "created_at" : "2016-02-09 22:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 102, 110 ],
      "id_str" : "18734310",
      "id" : 18734310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697186506654396416",
  "text" : "RT @POTUS: Just got off the phone with Coach Kubiak. Congrats to Peyton, Von Miller, and that monster @Broncos defense - see you at the Whi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Denver Broncos",
        "screen_name" : "Broncos",
        "indices" : [ 91, 99 ],
        "id_str" : "18734310",
        "id" : 18734310
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697185842209689601",
    "text" : "Just got off the phone with Coach Kubiak. Congrats to Peyton, Von Miller, and that monster @Broncos defense - see you at the White House!",
    "id" : 697185842209689601,
    "created_at" : "2016-02-09 22:30:32 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 697186506654396416,
  "created_at" : "2016-02-09 22:33:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697154004997033984\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/a7HG8pJeWB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CazJxd5WwAA64L1.jpg",
      "id_str" : "697153894011551744",
      "id" : 697153894011551744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CazJxd5WwAA64L1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/a7HG8pJeWB"
    } ],
    "hashtags" : [ {
      "text" : "Cybersecurity",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/8YP0MkzuNU",
      "expanded_url" : "http:\/\/on.wsj.com\/1RlwaSm",
      "display_url" : "on.wsj.com\/1RlwaSm"
    } ]
  },
  "geo" : { },
  "id_str" : "697154004997033984",
  "text" : "\"Too often government IT is like an Atari game in an Xbox world\" \u2014@POTUS on #Cybersecurity: https:\/\/t.co\/8YP0MkzuNU https:\/\/t.co\/a7HG8pJeWB",
  "id" : 697154004997033984,
  "created_at" : "2016-02-09 20:24:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSBudget",
      "indices" : [ 14, 26 ]
    }, {
      "text" : "AskPressSec",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697148636476612608",
  "text" : "RT @PressSec: #POTUSBudget focused Q&amp;A today at 5:30pm ET, send me your questions using #AskPressSec, looking forward to it",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUSBudget",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "AskPressSec",
        "indices" : [ 78, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697148035667603456",
    "text" : "#POTUSBudget focused Q&amp;A today at 5:30pm ET, send me your questions using #AskPressSec, looking forward to it",
    "id" : 697148035667603456,
    "created_at" : "2016-02-09 20:00:18 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 697148636476612608,
  "created_at" : "2016-02-09 20:02:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JourneyToMars",
      "indices" : [ 71, 85 ]
    }, {
      "text" : "StateOfNASA",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/sgnT2HgTpC",
      "expanded_url" : "http:\/\/go.nasa.gov\/1PA9zwX",
      "display_url" : "go.nasa.gov\/1PA9zwX"
    } ]
  },
  "geo" : { },
  "id_str" : "697147887256403968",
  "text" : "RT @NASA: We're developing the capabilities needed to send humans on a #JourneyToMars: https:\/\/t.co\/sgnT2HgTpC #StateOfNASA https:\/\/t.co\/Fp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/697129452736815104\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/FpOF6Nmo5W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CayziyOW8AAWzpS.jpg",
        "id_str" : "697129452514504704",
        "id" : 697129452514504704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CayziyOW8AAWzpS.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/FpOF6Nmo5W"
      } ],
      "hashtags" : [ {
        "text" : "JourneyToMars",
        "indices" : [ 61, 75 ]
      }, {
        "text" : "StateOfNASA",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/sgnT2HgTpC",
        "expanded_url" : "http:\/\/go.nasa.gov\/1PA9zwX",
        "display_url" : "go.nasa.gov\/1PA9zwX"
      } ]
    },
    "geo" : { },
    "id_str" : "697129452736815104",
    "text" : "We're developing the capabilities needed to send humans on a #JourneyToMars: https:\/\/t.co\/sgnT2HgTpC #StateOfNASA https:\/\/t.co\/FpOF6Nmo5W",
    "id" : 697129452736815104,
    "created_at" : "2016-02-09 18:46:28 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 697147887256403968,
  "created_at" : "2016-02-09 19:59:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ed Felten",
      "screen_name" : "EdFelten44",
      "indices" : [ 99, 110 ],
      "id_str" : "3240625473",
      "id" : 3240625473
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 112, 119 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 127, 136 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSecurity",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697141637282189313",
  "text" : "RT @NSC44: Qs on the steps @POTUS is taking on cyberthreats?\nAsk by 3:30pm ET with #CyberSecurity. @EdFelten44, @WHLive, &amp; @OMBPress will a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 16, 22 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Ed Felten",
        "screen_name" : "EdFelten44",
        "indices" : [ 88, 99 ],
        "id_str" : "3240625473",
        "id" : 3240625473
      }, {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 101, 108 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "OMBPress",
        "screen_name" : "OMBPress",
        "indices" : [ 116, 125 ],
        "id_str" : "337742544",
        "id" : 337742544
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CyberSecurity",
        "indices" : [ 72, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697140786215845888",
    "text" : "Qs on the steps @POTUS is taking on cyberthreats?\nAsk by 3:30pm ET with #CyberSecurity. @EdFelten44, @WHLive, &amp; @OMBPress will answer!",
    "id" : 697140786215845888,
    "created_at" : "2016-02-09 19:31:30 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 697141637282189313,
  "created_at" : "2016-02-09 19:34:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697136259815383041",
  "text" : "RT @VP: And of all the budget's proposals, I'm particularly proud of the nearly half a billion in funding for the Office on Violence Agains\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697135863097122816",
    "text" : "And of all the budget's proposals, I'm particularly proud of the nearly half a billion in funding for the Office on Violence Against Women.",
    "id" : 697135863097122816,
    "created_at" : "2016-02-09 19:11:56 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 697136259815383041,
  "created_at" : "2016-02-09 19:13:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSBudget",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697135726094327810",
  "text" : "RT @VP: I often say: Don't tell me what you value. Show me your budget &amp; I'll tell you what you value. #POTUSBudget makes our values crysta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUSBudget",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "697132255752261632",
    "text" : "I often say: Don't tell me what you value. Show me your budget &amp; I'll tell you what you value. #POTUSBudget makes our values crystal clear.",
    "id" : 697132255752261632,
    "created_at" : "2016-02-09 18:57:36 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 697135726094327810,
  "created_at" : "2016-02-09 19:11:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697132360744202240\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/857eoNsQHo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cay2JvHWEAAbV4A.jpg",
      "id_str" : "697132320717934592",
      "id" : 697132320717934592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cay2JvHWEAAbV4A.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/857eoNsQHo"
    } ],
    "hashtags" : [ {
      "text" : "POTUSbudget",
      "indices" : [ 15, 27 ]
    }, {
      "text" : "CancerMoonshot",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/KfMWpJDS2o",
      "expanded_url" : "http:\/\/go.wh.gov\/POTUSbudget",
      "display_url" : "go.wh.gov\/POTUSbudget"
    } ]
  },
  "geo" : { },
  "id_str" : "697132360744202240",
  "text" : "Here's how the #POTUSbudget would launch the next phase of cancer research: https:\/\/t.co\/KfMWpJDS2o #CancerMoonshot https:\/\/t.co\/857eoNsQHo",
  "id" : 697132360744202240,
  "created_at" : "2016-02-09 18:58:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Rob44\/status\/697114227622825985\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/IffG4JvNIB",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CaylrcxWcAAgJ_C.png",
      "id_str" : "697114208211726336",
      "id" : 697114208211726336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CaylrcxWcAAgJ_C.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IffG4JvNIB"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 46, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/KfMWpJVsTW",
      "expanded_url" : "http:\/\/go.wh.gov\/POTUSbudget",
      "display_url" : "go.wh.gov\/POTUSbudget"
    } ]
  },
  "geo" : { },
  "id_str" : "697118820649992192",
  "text" : ".@POTUS's final budget continues the fight to #ActOnClimate for future generations: https:\/\/t.co\/KfMWpJVsTW https:\/\/t.co\/IffG4JvNIB",
  "id" : 697118820649992192,
  "created_at" : "2016-02-09 18:04:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/697110700775366657\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/BkxLuZcZFf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CayhW2JW0AE2hkf.jpg",
      "id_str" : "697109456199536641",
      "id" : 697109456199536641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CayhW2JW0AE2hkf.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/BkxLuZcZFf"
    } ],
    "hashtags" : [ {
      "text" : "Cybersecurity",
      "indices" : [ 31, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/8YP0MkzuNU",
      "expanded_url" : "http:\/\/on.wsj.com\/1RlwaSm",
      "display_url" : "on.wsj.com\/1RlwaSm"
    } ]
  },
  "geo" : { },
  "id_str" : "697110700775366657",
  "text" : "\"Today, I\u2019m announcing our new #Cybersecurity National Action Plan\" \u2014@POTUS: https:\/\/t.co\/8YP0MkzuNU https:\/\/t.co\/BkxLuZcZFf",
  "id" : 697110700775366657,
  "created_at" : "2016-02-09 17:31:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OMBPress\/status\/697044193143865345\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/0WL92KR6QH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Caxl_vXWcAAimpz.jpg",
      "id_str" : "697044188056154112",
      "id" : 697044188056154112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Caxl_vXWcAAimpz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/0WL92KR6QH"
    } ],
    "hashtags" : [ {
      "text" : "POTUSbudget",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/KfMWpJVsTW",
      "expanded_url" : "http:\/\/go.wh.gov\/POTUSbudget",
      "display_url" : "go.wh.gov\/POTUSbudget"
    } ]
  },
  "geo" : { },
  "id_str" : "697107456778866688",
  "text" : "Here's how the #POTUSbudget builds on the progress we've made over the last 7 years: https:\/\/t.co\/KfMWpJVsTW https:\/\/t.co\/0WL92KR6QH",
  "id" : 697107456778866688,
  "created_at" : "2016-02-09 17:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSJ Editorial Page",
      "screen_name" : "WSJopinion",
      "indices" : [ 3, 14 ],
      "id_str" : "7228682",
      "id" : 7228682
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 117, 128 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/sRf3t8dsJT",
      "expanded_url" : "http:\/\/on.wsj.com\/1RlwaSm",
      "display_url" : "on.wsj.com\/1RlwaSm"
    } ]
  },
  "geo" : { },
  "id_str" : "697076258799222784",
  "text" : "RT @WSJopinion: President Obama writes on his new Cybersecurity National Action Plan: https:\/\/t.co\/sRf3t8dsJT @POTUS @WhiteHouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 94, 100 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 101, 112 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/sRf3t8dsJT",
        "expanded_url" : "http:\/\/on.wsj.com\/1RlwaSm",
        "display_url" : "on.wsj.com\/1RlwaSm"
      } ]
    },
    "geo" : { },
    "id_str" : "697044938240950272",
    "text" : "President Obama writes on his new Cybersecurity National Action Plan: https:\/\/t.co\/sRf3t8dsJT @POTUS @WhiteHouse",
    "id" : 697044938240950272,
    "created_at" : "2016-02-09 13:10:38 +0000",
    "user" : {
      "name" : "WSJ Editorial Page",
      "screen_name" : "WSJopinion",
      "protected" : false,
      "id_str" : "7228682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461999062913261568\/ObF8uSOx_normal.jpeg",
      "id" : 7228682,
      "verified" : false
    }
  },
  "id" : 697076258799222784,
  "created_at" : "2016-02-09 15:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walgreens News",
      "screen_name" : "WalgreensNews",
      "indices" : [ 3, 17 ],
      "id_str" : "95264499",
      "id" : 95264499
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "697071168117985280",
  "text" : "RT @WalgreensNews: We're proud to announce the launch of a comprehensive new effort to combat drug abuse. Learn more here https:\/\/t.co\/1uRH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/1uRHmKf1Vj",
        "expanded_url" : "http:\/\/bit.ly\/1QSLiEE",
        "display_url" : "bit.ly\/1QSLiEE"
      } ]
    },
    "geo" : { },
    "id_str" : "697043601767985152",
    "text" : "We're proud to announce the launch of a comprehensive new effort to combat drug abuse. Learn more here https:\/\/t.co\/1uRHmKf1Vj",
    "id" : 697043601767985152,
    "created_at" : "2016-02-09 13:05:19 +0000",
    "user" : {
      "name" : "Walgreens News",
      "screen_name" : "WalgreensNews",
      "protected" : false,
      "id_str" : "95264499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261577643964\/fafe2a3d51136fb6cbf4275db3226e55_normal.png",
      "id" : 95264499,
      "verified" : true
    }
  },
  "id" : 697071168117985280,
  "created_at" : "2016-02-09 14:54:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Code.org",
      "screen_name" : "codeorg",
      "indices" : [ 3, 11 ],
      "id_str" : "850107536",
      "id" : 850107536
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSforAll",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/i8usIG4bLP",
      "expanded_url" : "http:\/\/blog.code.org\/post\/138927445303\/president-obama-announced-a-ton-of-funding-for",
      "display_url" : "blog.code.org\/post\/138927445\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "697067217809113088",
  "text" : "RT @codeorg: President Obama proposed a ton of funding for computer science. Here's what that means. #CSforAll https:\/\/t.co\/i8usIG4bLP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CSforAll",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/i8usIG4bLP",
        "expanded_url" : "http:\/\/blog.code.org\/post\/138927445303\/president-obama-announced-a-ton-of-funding-for",
        "display_url" : "blog.code.org\/post\/138927445\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "696716276169895936",
    "text" : "President Obama proposed a ton of funding for computer science. Here's what that means. #CSforAll https:\/\/t.co\/i8usIG4bLP",
    "id" : 696716276169895936,
    "created_at" : "2016-02-08 15:24:39 +0000",
    "user" : {
      "name" : "Code.org",
      "screen_name" : "codeorg",
      "protected" : false,
      "id_str" : "850107536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562295957383954432\/HznhvglX_normal.png",
      "id" : 850107536,
      "verified" : true
    }
  },
  "id" : 697067217809113088,
  "created_at" : "2016-02-09 14:39:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696863597524336641\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/drXy5kSmcR",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CavBsR4XIAAK-CU.png",
      "id_str" : "696863533817077760",
      "id" : 696863533817077760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CavBsR4XIAAK-CU.png",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/drXy5kSmcR"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696863597524336641",
  "text" : "We've now taken steps to #ActOnClimate by cutting carbon pollution from every major source of transportation. https:\/\/t.co\/drXy5kSmcR",
  "id" : 696863597524336641,
  "created_at" : "2016-02-09 01:10:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/FmBII1GIPL",
      "expanded_url" : "http:\/\/go.wh.gov\/qiV28D",
      "display_url" : "go.wh.gov\/qiV28D"
    } ]
  },
  "geo" : { },
  "id_str" : "696851975359614976",
  "text" : "RT @FactsOnClimate: .@POTUS is taking action to cut carbon pollution from:\n\uD83D\uDE97 \u2713\n\uD83D\uDE9A \u2713\n\u2708 \u2713\nhttps:\/\/t.co\/FmBII1GIPL #ActOnClimate https:\/\/t.co\/H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FactsOnClimate\/status\/696841460310806529\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/HqkjcL2NzH",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CautnVWXIAAFi1k.png",
        "id_str" : "696841458616311808",
        "id" : 696841458616311808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CautnVWXIAAFi1k.png",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HqkjcL2NzH"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 91, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/FmBII1GIPL",
        "expanded_url" : "http:\/\/go.wh.gov\/qiV28D",
        "display_url" : "go.wh.gov\/qiV28D"
      } ]
    },
    "geo" : { },
    "id_str" : "696841460310806529",
    "text" : ".@POTUS is taking action to cut carbon pollution from:\n\uD83D\uDE97 \u2713\n\uD83D\uDE9A \u2713\n\u2708 \u2713\nhttps:\/\/t.co\/FmBII1GIPL #ActOnClimate https:\/\/t.co\/HqkjcL2NzH",
    "id" : 696841460310806529,
    "created_at" : "2016-02-08 23:42:05 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 696851975359614976,
  "created_at" : "2016-02-09 00:23:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696846419072851973",
  "text" : "RT @rhodes44: We've already made strong progress to cut carbon pollution from cars and trucks. Now we're doing it with planes. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/696842360911581185\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/NktZXNe4bC",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cauubm-UAAEKDum.png",
        "id_str" : "696842356700479489",
        "id" : 696842356700479489,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cauubm-UAAEKDum.png",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NktZXNe4bC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696842360911581185",
    "text" : "We've already made strong progress to cut carbon pollution from cars and trucks. Now we're doing it with planes. https:\/\/t.co\/NktZXNe4bC",
    "id" : 696842360911581185,
    "created_at" : "2016-02-08 23:45:40 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 696846419072851973,
  "created_at" : "2016-02-09 00:01:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696841054302113793\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/RJ5CGlILR9",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Causui4XIAA506O.png",
      "id_str" : "696840482996035584",
      "id" : 696840482996035584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Causui4XIAA506O.png",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/RJ5CGlILR9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/m3cpRHLn4q",
      "expanded_url" : "http:\/\/go.wh.gov\/qiV28D",
      "display_url" : "go.wh.gov\/qiV28D"
    } ]
  },
  "geo" : { },
  "id_str" : "696841054302113793",
  "text" : "BREAKING: We just secured a global deal to cut carbon pollution from commercial planes \u2192 https:\/\/t.co\/m3cpRHLn4q https:\/\/t.co\/RJ5CGlILR9",
  "id" : 696841054302113793,
  "created_at" : "2016-02-08 23:40:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696807424729206785",
  "text" : "RT @FLOTUS: \"Our children are limited only by the size of their dreams and their willingness to work for them.\" \u2014The First Lady https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/696806931940425730\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/SksDwrkzU9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CauOLPXW8AQ0A8k.jpg",
        "id_str" : "696806891113082884",
        "id" : 696806891113082884,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CauOLPXW8AQ0A8k.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 598,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1076,
          "resize" : "fit",
          "w" : 1080
        } ],
        "display_url" : "pic.twitter.com\/SksDwrkzU9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696806931940425730",
    "text" : "\"Our children are limited only by the size of their dreams and their willingness to work for them.\" \u2014The First Lady https:\/\/t.co\/SksDwrkzU9",
    "id" : 696806931940425730,
    "created_at" : "2016-02-08 21:24:53 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 696807424729206785,
  "created_at" : "2016-02-08 21:26:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 29, 33 ],
      "id_str" : "15134240",
      "id" : 15134240
    }, {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 53, 60 ],
      "id_str" : "146569971",
      "id" : 146569971
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 69, 78 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 101, 112 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/HInguKhjph",
      "expanded_url" : "http:\/\/www.snappytv.com\/tc\/1360540",
      "display_url" : "snappytv.com\/tc\/1360540"
    } ]
  },
  "geo" : { },
  "id_str" : "696799325016367104",
  "text" : "RT @NSC44: Today, Dr. Fauci (@NIH) and Dr. Schuchat (@CDCgov) joined @PressSec to discuss #ZikaVirus @WhiteHouse.\nhttps:\/\/t.co\/HInguKhjph",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NIH",
        "screen_name" : "NIH",
        "indices" : [ 18, 22 ],
        "id_str" : "15134240",
        "id" : 15134240
      }, {
        "name" : "CDC",
        "screen_name" : "CDCgov",
        "indices" : [ 42, 49 ],
        "id_str" : "146569971",
        "id" : 146569971
      }, {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 58, 67 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 90, 101 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ZikaVirus",
        "indices" : [ 79, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/HInguKhjph",
        "expanded_url" : "http:\/\/www.snappytv.com\/tc\/1360540",
        "display_url" : "snappytv.com\/tc\/1360540"
      } ]
    },
    "geo" : { },
    "id_str" : "696799009730498560",
    "text" : "Today, Dr. Fauci (@NIH) and Dr. Schuchat (@CDCgov) joined @PressSec to discuss #ZikaVirus @WhiteHouse.\nhttps:\/\/t.co\/HInguKhjph",
    "id" : 696799009730498560,
    "created_at" : "2016-02-08 20:53:24 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 696799325016367104,
  "created_at" : "2016-02-08 20:54:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696781852070191104\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/oVjYvwKJpI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Catp3niWEAE_WAd.jpg",
      "id_str" : "696766971585630209",
      "id" : 696766971585630209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Catp3niWEAE_WAd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oVjYvwKJpI"
    } ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/4Xw449EFpX",
      "expanded_url" : "http:\/\/go.wh.gov\/Zika",
      "display_url" : "go.wh.gov\/Zika"
    } ]
  },
  "geo" : { },
  "id_str" : "696781852070191104",
  "text" : "Here's how Congress can provide emergency funds to help fight the #ZikaVirus: https:\/\/t.co\/4Xw449EFpX https:\/\/t.co\/oVjYvwKJpI",
  "id" : 696781852070191104,
  "created_at" : "2016-02-08 19:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696774294324453377\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/xaKzJLD4ZI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cato-CiWcAAaF7P.jpg",
      "id_str" : "696765982400999424",
      "id" : 696765982400999424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cato-CiWcAAaF7P.jpg",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xaKzJLD4ZI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/hSiol2laJz",
      "expanded_url" : "http:\/\/on.fb.me\/1SEqrbU",
      "display_url" : "on.fb.me\/1SEqrbU"
    } ]
  },
  "geo" : { },
  "id_str" : "696774294324453377",
  "text" : "\"Michelle &amp; I send our warmest wishes to everyone celebrating the Lunar New Year\" \u2014@POTUS: https:\/\/t.co\/hSiol2laJz https:\/\/t.co\/xaKzJLD4ZI",
  "id" : 696774294324453377,
  "created_at" : "2016-02-08 19:15:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "indices" : [ 100, 115 ],
      "id_str" : "17134268",
      "id" : 17134268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bcVMem1IxO",
      "expanded_url" : "http:\/\/snpy.tv\/1TOkQyW",
      "display_url" : "snpy.tv\/1TOkQyW"
    } ]
  },
  "geo" : { },
  "id_str" : "696763926927826944",
  "text" : "Watch @POTUS call on Congress to provide $1.8 billion in emergency funds to fight the #ZikaVirus on @CBSThisMorning: https:\/\/t.co\/bcVMem1IxO",
  "id" : 696763926927826944,
  "created_at" : "2016-02-08 18:34:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/696754843269005312\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/k6rWa7tIw1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cate1mTVIAAOD4y.jpg",
      "id_str" : "696754842266574848",
      "id" : 696754842266574848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cate1mTVIAAOD4y.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/k6rWa7tIw1"
    } ],
    "hashtags" : [ {
      "text" : "SB50",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696758514643959808",
  "text" : "RT @Denis44: Next year, how about fewer ads that fuel opioid addiction and more on access to treatment. #SB50 https:\/\/t.co\/k6rWa7tIw1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/696754843269005312\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/k6rWa7tIw1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cate1mTVIAAOD4y.jpg",
        "id_str" : "696754842266574848",
        "id" : 696754842266574848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cate1mTVIAAOD4y.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/k6rWa7tIw1"
      } ],
      "hashtags" : [ {
        "text" : "SB50",
        "indices" : [ 91, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696754843269005312",
    "text" : "Next year, how about fewer ads that fuel opioid addiction and more on access to treatment. #SB50 https:\/\/t.co\/k6rWa7tIw1",
    "id" : 696754843269005312,
    "created_at" : "2016-02-08 17:57:54 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 696758514643959808,
  "created_at" : "2016-02-08 18:12:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "indices" : [ 3, 18 ],
      "id_str" : "17134268",
      "id" : 17134268
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Gayle King",
      "screen_name" : "GayleKing",
      "indices" : [ 94, 104 ],
      "id_str" : "29546945",
      "id" : 29546945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NorthKorea",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "Zika",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/KtorRMxHpR",
      "expanded_url" : "http:\/\/cbsn.ws\/1nSzVTC",
      "display_url" : "cbsn.ws\/1nSzVTC"
    } ]
  },
  "geo" : { },
  "id_str" : "696707581599821824",
  "text" : "RT @CBSThisMorning: .@POTUS on #NorthKorea and the #Zika virus during extended interview with @GayleKing: https:\/\/t.co\/KtorRMxHpR\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Gayle King",
        "screen_name" : "GayleKing",
        "indices" : [ 74, 84 ],
        "id_str" : "29546945",
        "id" : 29546945
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NorthKorea",
        "indices" : [ 11, 22 ]
      }, {
        "text" : "Zika",
        "indices" : [ 31, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/KtorRMxHpR",
        "expanded_url" : "http:\/\/cbsn.ws\/1nSzVTC",
        "display_url" : "cbsn.ws\/1nSzVTC"
      }, {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/biyI2ItPnJ",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/980fc612-615c-46cb-abac-e63958b56b08",
        "display_url" : "amp.twimg.com\/v\/980fc612-615\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "696679187944374272",
    "text" : ".@POTUS on #NorthKorea and the #Zika virus during extended interview with @GayleKing: https:\/\/t.co\/KtorRMxHpR\nhttps:\/\/t.co\/biyI2ItPnJ",
    "id" : 696679187944374272,
    "created_at" : "2016-02-08 12:57:16 +0000",
    "user" : {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "protected" : false,
      "id_str" : "17134268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651362377540112384\/eNioIfCp_normal.jpg",
      "id" : 17134268,
      "verified" : true
    }
  },
  "id" : 696707581599821824,
  "created_at" : "2016-02-08 14:50:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696503738194923520\/photo\/1",
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/lLxXegyWom",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cap6dVvUUAAuYzb.jpg",
      "id_str" : "696503736852566016",
      "id" : 696503736852566016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cap6dVvUUAAuYzb.jpg",
      "sizes" : [ {
        "h" : 508,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 897,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2500,
        "resize" : "fit",
        "w" : 1672
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1531,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lLxXegyWom"
    } ],
    "hashtags" : [ {
      "text" : "SB50",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696503738194923520",
  "text" : "Halftime break. #SB50 https:\/\/t.co\/lLxXegyWom",
  "id" : 696503738194923520,
  "created_at" : "2016-02-08 01:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696478639802679296\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/G8EU6Xatf6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CapjobDWIAQsRVS.jpg",
      "id_str" : "696478638489870340",
      "id" : 696478638489870340,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CapjobDWIAQsRVS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/G8EU6Xatf6"
    } ],
    "hashtags" : [ {
      "text" : "SuperBowl50",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696478639802679296",
  "text" : "Ready for kickoff. #SuperBowl50 https:\/\/t.co\/G8EU6Xatf6",
  "id" : 696478639802679296,
  "created_at" : "2016-02-07 23:40:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 73, 82 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696472989655769088\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/AOhvQRqg2d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CapeeAtXEAA6NXC.jpg",
      "id_str" : "696472962061504512",
      "id" : 696472962061504512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CapeeAtXEAA6NXC.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/AOhvQRqg2d"
    } ],
    "hashtags" : [ {
      "text" : "SB50",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "SuperBowl50",
      "indices" : [ 60, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696472989655769088",
  "text" : ".@POTUS is ready for #SB50. Watch his warm up tosses on the #SuperBowl50 @Snapchat story. https:\/\/t.co\/AOhvQRqg2d",
  "id" : 696472989655769088,
  "created_at" : "2016-02-07 23:17:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696453454651195392\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/uSUqqRLjoV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaozCPaXIAMYiN_.jpg",
      "id_str" : "696425205972017155",
      "id" : 696425205972017155,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaozCPaXIAMYiN_.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/uSUqqRLjoV"
    } ],
    "hashtags" : [ {
      "text" : "SuperBowlSunday",
      "indices" : [ 29, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696453454651195392",
  "text" : "He could\u2026\ngo\u2026\nall\u2026\nthe\u2026\nway!\n#SuperBowlSunday https:\/\/t.co\/uSUqqRLjoV",
  "id" : 696453454651195392,
  "created_at" : "2016-02-07 22:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "indices" : [ 3, 18 ],
      "id_str" : "17134268",
      "id" : 17134268
    }, {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "indices" : [ 27, 42 ],
      "id_str" : "17134268",
      "id" : 17134268
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 46, 56 ],
      "id_str" : "180505807",
      "id" : 180505807
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 116, 127 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB50",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696414534387548161",
  "text" : "RT @CBSThisMorning: Follow @CBSThisMorning on @Instagram ahead of Gayle's intvw for a behind-the-scenes look at the @WhiteHouse on #SB50 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CBS This Morning",
        "screen_name" : "CBSThisMorning",
        "indices" : [ 7, 22 ],
        "id_str" : "17134268",
        "id" : 17134268
      }, {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 26, 36 ],
        "id_str" : "180505807",
        "id" : 180505807
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 96, 107 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CBSThisMorning\/status\/696377974149541888\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/gQKb3pEFMt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaoIE8DW0AI8A4V.png",
        "id_str" : "696377973314867202",
        "id" : 696377973314867202,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaoIE8DW0AI8A4V.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 1190
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gQKb3pEFMt"
      } ],
      "hashtags" : [ {
        "text" : "SB50",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "696377974149541888",
    "text" : "Follow @CBSThisMorning on @Instagram ahead of Gayle's intvw for a behind-the-scenes look at the @WhiteHouse on #SB50 https:\/\/t.co\/gQKb3pEFMt",
    "id" : 696377974149541888,
    "created_at" : "2016-02-07 17:00:21 +0000",
    "user" : {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "protected" : false,
      "id_str" : "17134268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651362377540112384\/eNioIfCp_normal.jpg",
      "id" : 17134268,
      "verified" : true
    }
  },
  "id" : 696414534387548161,
  "created_at" : "2016-02-07 19:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696377989651533824\/photo\/1",
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/VKzznq4Wym",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaoF5t3XIAA9H0V.jpg",
      "id_str" : "696375581504643072",
      "id" : 696375581504643072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaoF5t3XIAA9H0V.jpg",
      "sizes" : [ {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 707,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 707,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VKzznq4Wym"
    } ],
    "hashtags" : [ {
      "text" : "SuperBowlSunday",
      "indices" : [ 10, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696377989651533824",
  "text" : "Game day. #SuperBowlSunday https:\/\/t.co\/VKzznq4Wym",
  "id" : 696377989651533824,
  "created_at" : "2016-02-07 17:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/0MoJ0ZMUuB",
      "expanded_url" : "http:\/\/go.wh.gov\/2AEwLo",
      "display_url" : "go.wh.gov\/2AEwLo"
    } ]
  },
  "geo" : { },
  "id_str" : "696350717917802496",
  "text" : "\"Rather than subsidize the past, we should invest in the future.\" \u2014@POTUS on doubling investment in clean energy R&amp;D https:\/\/t.co\/0MoJ0ZMUuB",
  "id" : 696350717917802496,
  "created_at" : "2016-02-07 15:12:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 34, 37 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/lRjFnTgKUr",
      "expanded_url" : "http:\/\/go.wh.gov\/T2y4YU",
      "display_url" : "go.wh.gov\/T2y4YU"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/9HS8pkRzLi",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/4be34f4e-b4be-4a20-a9eb-30557657e060",
      "display_url" : "amp.twimg.com\/v\/4be34f4e-b4b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696132729360941056",
  "text" : "Go behind the scenes with @POTUS, @VP and a few special guests in this week's #WestWingWeek: https:\/\/t.co\/lRjFnTgKUr\nhttps:\/\/t.co\/9HS8pkRzLi",
  "id" : 696132729360941056,
  "created_at" : "2016-02-07 00:45:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "indices" : [ 3, 18 ],
      "id_str" : "17134268",
      "id" : 17134268
    }, {
      "name" : "Gayle King",
      "screen_name" : "GayleKing",
      "indices" : [ 21, 31 ],
      "id_str" : "29546945",
      "id" : 29546945
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 66, 73 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "CBS Television",
      "screen_name" : "CBS",
      "indices" : [ 101, 105 ],
      "id_str" : "97739866",
      "id" : 97739866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB50",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/XeZm9pe9WB",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/5e50cbf4-132b-47db-99e6-996675afe613",
      "display_url" : "amp.twimg.com\/v\/5e50cbf4-132\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696083423539109888",
  "text" : "RT @CBSThisMorning: .@GayleKing's live interview with @POTUS\u200B and @FLOTUS ahead of #SB50\u200B, Sunday on @CBS\u200B!\nhttps:\/\/t.co\/XeZm9pe9WB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gayle King",
        "screen_name" : "GayleKing",
        "indices" : [ 1, 11 ],
        "id_str" : "29546945",
        "id" : 29546945
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 34, 40 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 46, 53 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "CBS Television",
        "screen_name" : "CBS",
        "indices" : [ 81, 85 ],
        "id_str" : "97739866",
        "id" : 97739866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SB50",
        "indices" : [ 63, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/XeZm9pe9WB",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/5e50cbf4-132b-47db-99e6-996675afe613",
        "display_url" : "amp.twimg.com\/v\/5e50cbf4-132\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695618937627643905",
    "text" : ".@GayleKing's live interview with @POTUS\u200B and @FLOTUS ahead of #SB50\u200B, Sunday on @CBS\u200B!\nhttps:\/\/t.co\/XeZm9pe9WB",
    "id" : 695618937627643905,
    "created_at" : "2016-02-05 14:44:13 +0000",
    "user" : {
      "name" : "CBS This Morning",
      "screen_name" : "CBSThisMorning",
      "protected" : false,
      "id_str" : "17134268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651362377540112384\/eNioIfCp_normal.jpg",
      "id" : 17134268,
      "verified" : true
    }
  },
  "id" : 696083423539109888,
  "created_at" : "2016-02-06 21:29:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/0MoJ0ZMUuB",
      "expanded_url" : "http:\/\/go.wh.gov\/2AEwLo",
      "display_url" : "go.wh.gov\/2AEwLo"
    } ]
  },
  "geo" : { },
  "id_str" : "696076008395399168",
  "text" : "\"Clean power from the wind or the sun is...cheaper in many communities than dirtier, conventional power\" \u2014@POTUS https:\/\/t.co\/0MoJ0ZMUuB",
  "id" : 696076008395399168,
  "created_at" : "2016-02-06 21:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/696053340216492032\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/emUVus05ek",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CajKFg1UsAAHf9P.jpg",
      "id_str" : "696028338490486784",
      "id" : 696028338490486784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CajKFg1UsAAHf9P.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/emUVus05ek"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/ccTHx5ysWZ",
      "expanded_url" : "http:\/\/go.wh.gov\/ZDwacX",
      "display_url" : "go.wh.gov\/ZDwacX"
    } ]
  },
  "geo" : { },
  "id_str" : "696053340216492032",
  "text" : "\"Over the last seven years, we\u2019ve made historic investments in clean energy\" \u2014@POTUS: https:\/\/t.co\/ccTHx5ysWZ https:\/\/t.co\/emUVus05ek",
  "id" : 696053340216492032,
  "created_at" : "2016-02-06 19:30:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/0MoJ0ZMUuB",
      "expanded_url" : "http:\/\/go.wh.gov\/2AEwLo",
      "display_url" : "go.wh.gov\/2AEwLo"
    } ]
  },
  "geo" : { },
  "id_str" : "696027895077040128",
  "text" : "Watch @POTUS announce new investments in clean energy research and development. #ActOnClimate https:\/\/t.co\/0MoJ0ZMUuB",
  "id" : 696027895077040128,
  "created_at" : "2016-02-06 17:49:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/0MoJ0ZMUuB",
      "expanded_url" : "http:\/\/go.wh.gov\/2AEwLo",
      "display_url" : "go.wh.gov\/2AEwLo"
    } ]
  },
  "geo" : { },
  "id_str" : "696015760087318530",
  "text" : "\"The budget I...send to Congress this Tuesday will double funding for clean energy research &amp; development\" \u2014@POTUS https:\/\/t.co\/0MoJ0ZMUuB",
  "id" : 696015760087318530,
  "created_at" : "2016-02-06 17:01:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Alabama Football",
      "screen_name" : "AlabamaFTBL",
      "indices" : [ 58, 70 ],
      "id_str" : "350508156",
      "id" : 350508156
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695762594053824513\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/IatJxZgi3o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CafO11JXEAA4yEa.jpg",
      "id_str" : "695752091646758912",
      "id" : 695752091646758912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CafO11JXEAA4yEa.jpg",
      "sizes" : [ {
        "h" : 523,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IatJxZgi3o"
    } ],
    "hashtags" : [ {
      "text" : "RollTide",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695762594053824513",
  "text" : ".@POTUS strikes the Heisman pose with this year's winner, @AlabamaFTBL running back Derrick Henry. #RollTide https:\/\/t.co\/IatJxZgi3o",
  "id" : 695762594053824513,
  "created_at" : "2016-02-06 00:15:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/695734399879528448\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/hWvvdzZ0Sk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cae-wBsW8AAkuFS.jpg",
      "id_str" : "695734399749517312",
      "id" : 695734399749517312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cae-wBsW8AAkuFS.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hWvvdzZ0Sk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/AG4uySVa0f",
      "expanded_url" : "http:\/\/go.nasa.gov\/1X9hVk3",
      "display_url" : "go.nasa.gov\/1X9hVk3"
    } ]
  },
  "geo" : { },
  "id_str" : "695736755392086016",
  "text" : "RT @NASA: We're saddened by the loss of Apollo 14 astronaut Edgar Mitchell. We salute you: https:\/\/t.co\/AG4uySVa0f https:\/\/t.co\/hWvvdzZ0Sk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/695734399879528448\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/hWvvdzZ0Sk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cae-wBsW8AAkuFS.jpg",
        "id_str" : "695734399749517312",
        "id" : 695734399749517312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cae-wBsW8AAkuFS.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hWvvdzZ0Sk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/AG4uySVa0f",
        "expanded_url" : "http:\/\/go.nasa.gov\/1X9hVk3",
        "display_url" : "go.nasa.gov\/1X9hVk3"
      } ]
    },
    "geo" : { },
    "id_str" : "695734399879528448",
    "text" : "We're saddened by the loss of Apollo 14 astronaut Edgar Mitchell. We salute you: https:\/\/t.co\/AG4uySVa0f https:\/\/t.co\/hWvvdzZ0Sk",
    "id" : 695734399879528448,
    "created_at" : "2016-02-05 22:23:01 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 695736755392086016,
  "created_at" : "2016-02-05 22:32:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 45, 51 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/695728543322406912\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/WeaEwwlonW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cae5LtyXEAQN-eb.jpg",
      "id_str" : "695728278372552708",
      "id" : 695728278372552708,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cae5LtyXEAQN-eb.jpg",
      "sizes" : [ {
        "h" : 182,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 493
      } ],
      "display_url" : "pic.twitter.com\/WeaEwwlonW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/fWSeVVIKWA",
      "expanded_url" : "http:\/\/on.fb.me\/1K3kHFO",
      "display_url" : "on.fb.me\/1K3kHFO"
    } ]
  },
  "geo" : { },
  "id_str" : "695728543322406912",
  "text" : "\"He is the shining star in heaven tonight.\" \u2014@POTUS on the passing of Maurice White: https:\/\/t.co\/fWSeVVIKWA https:\/\/t.co\/WeaEwwlonW",
  "id" : 695728543322406912,
  "created_at" : "2016-02-05 21:59:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695708131523981312\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/VKgs3eNipY",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CaemOurW4AE0TEO.png",
      "id_str" : "695707439430295553",
      "id" : 695707439430295553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CaemOurW4AE0TEO.png",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VKgs3eNipY"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/yG48wThh3g",
      "expanded_url" : "http:\/\/go.wh.gov\/386oRw",
      "display_url" : "go.wh.gov\/386oRw"
    } ]
  },
  "geo" : { },
  "id_str" : "695708131523981312",
  "text" : "Worth a read: 5 things you need to know about today's #JobsReport \u2192 https:\/\/t.co\/yG48wThh3g https:\/\/t.co\/VKgs3eNipY",
  "id" : 695708131523981312,
  "created_at" : "2016-02-05 20:38:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/sdy9UTImOQ",
      "expanded_url" : "http:\/\/snpy.tv\/20ev3o3",
      "display_url" : "snpy.tv\/20ev3o3"
    } ]
  },
  "geo" : { },
  "id_str" : "695685305467166720",
  "text" : "\"More people are entering into the workforce. They feel more confident, and they're finding work.\" \u2014@POTUS https:\/\/t.co\/sdy9UTImOQ",
  "id" : 695685305467166720,
  "created_at" : "2016-02-05 19:07:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 3, 7 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 111, 120 ],
      "id_str" : "26270913",
      "id" : 26270913
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Warriors",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695678806108086272",
  "text" : "RT @NBA: Go behind-the-scenes as the #Warriors were celebrated at the @WhiteHouse as guests of the @POTUS.(via @Warriors) https:\/\/t.co\/SUo6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 61, 72 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 90, 96 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "GoldenStateWarriors",
        "screen_name" : "warriors",
        "indices" : [ 102, 111 ],
        "id_str" : "26270913",
        "id" : 26270913
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Warriors",
        "indices" : [ 28, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/SUo6uqCYAa",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/afcd2284-b1da-4ea7-932e-8047322f0f08",
        "display_url" : "amp.twimg.com\/v\/afcd2284-b1d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695653294425972741",
    "text" : "Go behind-the-scenes as the #Warriors were celebrated at the @WhiteHouse as guests of the @POTUS.(via @Warriors) https:\/\/t.co\/SUo6uqCYAa",
    "id" : 695653294425972741,
    "created_at" : "2016-02-05 17:00:44 +0000",
    "user" : {
      "name" : "NBA",
      "screen_name" : "NBA",
      "protected" : false,
      "id_str" : "19923144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797568531047051264\/LcjOmxGH_normal.jpg",
      "id" : 19923144,
      "verified" : true
    }
  },
  "id" : 695678806108086272,
  "created_at" : "2016-02-05 18:42:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/oAm205Zui1",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    }, {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/sdy9UTqLXi",
      "expanded_url" : "http:\/\/snpy.tv\/20ev3o3",
      "display_url" : "snpy.tv\/20ev3o3"
    } ]
  },
  "geo" : { },
  "id_str" : "695664235129524224",
  "text" : "\"We've recovered from the worst economic crisis since the 1930s.\" \u2014@POTUS: https:\/\/t.co\/oAm205Zui1 https:\/\/t.co\/sdy9UTqLXi",
  "id" : 695664235129524224,
  "created_at" : "2016-02-05 17:44:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/oAm205Zui1",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "695662062157107200",
  "text" : "\u201COver the past six months, wages have grown at their fastest rate since early 2009.\u201D \u2014@POTUS: https:\/\/t.co\/oAm205Zui1 #JobsReport",
  "id" : 695662062157107200,
  "created_at" : "2016-02-05 17:35:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/oAm205Zui1",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "695661927423414272",
  "text" : "\u201CAlmost all the jobs created in that time have been full-time jobs.\u201D \u2014@POTUS on the economy: https:\/\/t.co\/oAm205Zui1 #JobsReport",
  "id" : 695661927423414272,
  "created_at" : "2016-02-05 17:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695661766680797185\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/EoyIGC9zFr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cad8m2vW4AEJw1y.jpg",
      "id_str" : "695661674423050241",
      "id" : 695661674423050241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cad8m2vW4AEJw1y.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/EoyIGC9zFr"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695661766680797185",
  "text" : "\u201COver the past six years, our businesses have added about 14 million new jobs.\u201D \u2014@POTUS #JobsReport https:\/\/t.co\/EoyIGC9zFr",
  "id" : 695661766680797185,
  "created_at" : "2016-02-05 17:34:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695661620782092288\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/i1BOvNtlBb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cad8afCW4AAypHJ.jpg",
      "id_str" : "695661461901860864",
      "id" : 695661461901860864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cad8afCW4AAypHJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/i1BOvNtlBb"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695661620782092288",
  "text" : "\u201CThe first time it\u2019s dipped below five percent in almost eight years.\u201D \u2014@POTUS on the unemployment rate #JobsReport https:\/\/t.co\/i1BOvNtlBb",
  "id" : 695661620782092288,
  "created_at" : "2016-02-05 17:33:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695661371950813184\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Qjme6Wt4Lz",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cad8R_OWEAA8v7I.png",
      "id_str" : "695661315923251200",
      "id" : 695661315923251200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cad8R_OWEAA8v7I.png",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Qjme6Wt4Lz"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/oAm205Zui1",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "695661371950813184",
  "text" : "\u201CAfter scraping 10% in 2009, the unemployment rate is now at 4.9%\" \u2014@POTUS: https:\/\/t.co\/oAm205Zui1 #JobsReport https:\/\/t.co\/Qjme6Wt4Lz",
  "id" : 695661371950813184,
  "created_at" : "2016-02-05 17:32:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/oAm205Zui1",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "695661057633812481",
  "text" : "Tune in as @POTUS delivers a statement on the economy: https:\/\/t.co\/oAm205Zui1 #JobsReport",
  "id" : 695661057633812481,
  "created_at" : "2016-02-05 17:31:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695650563938258944\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/4a2kzvuCQu",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CadyXFUW4AEuevn.png",
      "id_str" : "695650408342151169",
      "id" : 695650408342151169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CadyXFUW4AEuevn.png",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4a2kzvuCQu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/oAm205Zui1",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "695650563938258944",
  "text" : "At 12:30pm ET, watch @POTUS deliver a statement on the economy \u2192 https:\/\/t.co\/oAm205Zui1 https:\/\/t.co\/4a2kzvuCQu",
  "id" : 695650563938258944,
  "created_at" : "2016-02-05 16:49:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695647697576050688\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/BI5kotqBzJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CadvxbDWEAERJNd.jpg",
      "id_str" : "695647562318090241",
      "id" : 695647562318090241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CadvxbDWEAERJNd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/BI5kotqBzJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/oAm205Zui1",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "695647697576050688",
  "text" : "RT to share the good news: The unemployment rate is the lowest it's been in 8 years \u2192 https:\/\/t.co\/oAm205Zui1 https:\/\/t.co\/BI5kotqBzJ",
  "id" : 695647697576050688,
  "created_at" : "2016-02-05 16:38:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695641421747867648\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/nDq1kskFSC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CadqDedW4AIt85l.jpg",
      "id_str" : "695641275400380418",
      "id" : 695641275400380418,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CadqDedW4AIt85l.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/nDq1kskFSC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/oAm206h59z",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "695641421747867648",
  "text" : "Here's what the longest streak of private-sector job growth on record looks like \u2192 https:\/\/t.co\/oAm206h59z https:\/\/t.co\/nDq1kskFSC",
  "id" : 695641421747867648,
  "created_at" : "2016-02-05 16:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695629613326708738\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/lbKmf2TksF",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CadfSIVWIAEXz75.png",
      "id_str" : "695629432531329025",
      "id" : 695629432531329025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CadfSIVWIAEXz75.png",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lbKmf2TksF"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/oAm206h59z",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "695629613326708738",
  "text" : "14 million jobs over 71 months \u2713\nLowest unemployment rate in 8 years \u2713\nhttps:\/\/t.co\/oAm206h59z #JobsReport https:\/\/t.co\/lbKmf2TksF",
  "id" : 695629613326708738,
  "created_at" : "2016-02-05 15:26:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695625800796606465\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/lp3wGDFleP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cadb4ZiUMAE-rxs.jpg",
      "id_str" : "695625691937648641",
      "id" : 695625691937648641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cadb4ZiUMAE-rxs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/lp3wGDFleP"
    } ],
    "hashtags" : [ {
      "text" : "JobsReport",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/oAm206h59z",
      "expanded_url" : "http:\/\/go.wh.gov\/JanJobs",
      "display_url" : "go.wh.gov\/JanJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "695625800796606465",
  "text" : "BREAKING: The unemployment rate fell to 4.9% for the first time in 8 years \u2192 https:\/\/t.co\/oAm206h59z #JobsReport https:\/\/t.co\/lp3wGDFleP",
  "id" : 695625800796606465,
  "created_at" : "2016-02-05 15:11:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 95, 104 ],
      "id_str" : "26270913",
      "id" : 26270913
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695419140555673600\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/KY7gLEGQqV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaaYVJ1UcAAhPeY.jpg",
      "id_str" : "695410681659551744",
      "id" : 695410681659551744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaaYVJ1UcAAhPeY.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/KY7gLEGQqV"
    } ],
    "hashtags" : [ {
      "text" : "DubNation",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695419140555673600",
  "text" : "\"They\u2019re the kind of people you want representing a city, representing the NBA\" \u2014@POTUS on the @Warriors #DubNation https:\/\/t.co\/KY7gLEGQqV",
  "id" : 695419140555673600,
  "created_at" : "2016-02-05 01:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695381983162032128",
  "text" : "RT @POTUS: Just got great news - nearly 13 million Americans signed up this round for private health insurance thanks to the Affordable Car\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695381352988848128",
    "text" : "Just got great news - nearly 13 million Americans signed up this round for private health insurance thanks to the Affordable Care Act.",
    "id" : 695381352988848128,
    "created_at" : "2016-02-04 23:00:08 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 695381983162032128,
  "created_at" : "2016-02-04 23:02:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ColombiaVisit",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695375116599832581",
  "text" : "\u201CI\u2019m proud to announce a new framework for the next chapter of our partnership\u2014we're going to call it Peace Colombia\u201D \u2014@POTUS #ColombiaVisit",
  "id" : 695375116599832581,
  "created_at" : "2016-02-04 22:35:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ColombiaVisit",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/TktuLsWl9j",
      "expanded_url" : "http:\/\/go.wh.gov\/Colombia",
      "display_url" : "go.wh.gov\/Colombia"
    } ]
  },
  "geo" : { },
  "id_str" : "695372983515242496",
  "text" : "Tune in as @POTUS welcomes Colombian President Santos and President Pastrana to the White House: https:\/\/t.co\/TktuLsWl9j #ColombiaVisit",
  "id" : 695372983515242496,
  "created_at" : "2016-02-04 22:26:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 50, 61 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695371216681480195",
  "text" : "RT @vj44: Hi -- It's Valerie and Melissa from the @WhiteHouse Faith Office. Welcome to our office hours. We look forward to answering your \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 40, 51 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695370406887174144",
    "text" : "Hi -- It's Valerie and Melissa from the @WhiteHouse Faith Office. Welcome to our office hours. We look forward to answering your questions!!",
    "id" : 695370406887174144,
    "created_at" : "2016-02-04 22:16:39 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 695371216681480195,
  "created_at" : "2016-02-04 22:19:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695358006490365952\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/jzhj5gEt9x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaZoT8AUEAAe8X7.jpg",
      "id_str" : "695357884209565696",
      "id" : 695357884209565696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaZoT8AUEAAe8X7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jzhj5gEt9x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695358006490365952",
  "text" : "BREAKING: Nearly 13 million Americans have signed up for private health coverage thanks to the Affordable Care Act. https:\/\/t.co\/jzhj5gEt9x",
  "id" : 695358006490365952,
  "created_at" : "2016-02-04 21:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/QLV4d6gjLA",
      "expanded_url" : "http:\/\/go.wh.gov\/FirstJob",
      "display_url" : "go.wh.gov\/FirstJob"
    } ]
  },
  "geo" : { },
  "id_str" : "695349085008625665",
  "text" : "RT @LaborSec: .@POTUS proposal wld increase summer job access w\/ benefits for youths &amp; their communities. https:\/\/t.co\/QLV4d6gjLA https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/695289504580702209\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/5KkKAVAZDp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaYqHsEWwAAN2Lg.jpg",
        "id_str" : "695289504052199424",
        "id" : 695289504052199424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaYqHsEWwAAN2Lg.jpg",
        "sizes" : [ {
          "h" : 487,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5KkKAVAZDp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/QLV4d6gjLA",
        "expanded_url" : "http:\/\/go.wh.gov\/FirstJob",
        "display_url" : "go.wh.gov\/FirstJob"
      } ]
    },
    "geo" : { },
    "id_str" : "695289504580702209",
    "text" : ".@POTUS proposal wld increase summer job access w\/ benefits for youths &amp; their communities. https:\/\/t.co\/QLV4d6gjLA https:\/\/t.co\/5KkKAVAZDp",
    "id" : 695289504580702209,
    "created_at" : "2016-02-04 16:55:10 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 695349085008625665,
  "created_at" : "2016-02-04 20:51:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Hp7rxnc8Wj",
      "expanded_url" : "http:\/\/go.wh.gov\/CleanTransit",
      "display_url" : "go.wh.gov\/CleanTransit"
    } ]
  },
  "geo" : { },
  "id_str" : "695341888413413377",
  "text" : "RT @FactsOnClimate: Just announced: @POTUS's clean transit plan would create jobs and help us #ActOnClimate: https:\/\/t.co\/Hp7rxnc8Wj https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 16, 22 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/695341843383341056\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/aIU4V7m243",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaZZqRkUMAEigxT.jpg",
        "id_str" : "695341775280418817",
        "id" : 695341775280418817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaZZqRkUMAEigxT.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/aIU4V7m243"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 74, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/Hp7rxnc8Wj",
        "expanded_url" : "http:\/\/go.wh.gov\/CleanTransit",
        "display_url" : "go.wh.gov\/CleanTransit"
      } ]
    },
    "geo" : { },
    "id_str" : "695341843383341056",
    "text" : "Just announced: @POTUS's clean transit plan would create jobs and help us #ActOnClimate: https:\/\/t.co\/Hp7rxnc8Wj https:\/\/t.co\/aIU4V7m243",
    "id" : 695341843383341056,
    "created_at" : "2016-02-04 20:23:08 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 695341888413413377,
  "created_at" : "2016-02-04 20:23:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 11, 14 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 70, 79 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695328592247390208\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/lkZzldGptD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaZLPizW4AAE61e.jpg",
      "id_str" : "695325922887655424",
      "id" : 695325922887655424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaZLPizW4AAE61e.jpg",
      "sizes" : [ {
        "h" : 495,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 514
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lkZzldGptD"
    } ],
    "hashtags" : [ {
      "text" : "WorldCancerDay",
      "indices" : [ 43, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/3VePJXVdIG",
      "expanded_url" : "http:\/\/on.fb.me\/20cjf5y",
      "display_url" : "on.fb.me\/20cjf5y"
    } ]
  },
  "geo" : { },
  "id_str" : "695328592247390208",
  "text" : "At 3pm ET, @VP will take your questions on #WorldCancerDay on his new @Facebook page: https:\/\/t.co\/3VePJXVdIG https:\/\/t.co\/lkZzldGptD",
  "id" : 695328592247390208,
  "created_at" : "2016-02-04 19:30:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 3, 12 ],
      "id_str" : "26270913",
      "id" : 26270913
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/warriors\/status\/695316032815149058\/photo\/1",
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/QSewGlVt2K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaZCPmxUMAAXYJ9.jpg",
      "id_str" : "695316028348182528",
      "id" : 695316028348182528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaZCPmxUMAAXYJ9.jpg",
      "sizes" : [ {
        "h" : 407,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 855
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 855
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QSewGlVt2K"
    } ],
    "hashtags" : [ {
      "text" : "DubNation",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695326002214522880",
  "text" : "RT @warriors: Special delivery. #DubNation https:\/\/t.co\/QSewGlVt2K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/warriors\/status\/695316032815149058\/photo\/1",
        "indices" : [ 29, 52 ],
        "url" : "https:\/\/t.co\/QSewGlVt2K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaZCPmxUMAAXYJ9.jpg",
        "id_str" : "695316028348182528",
        "id" : 695316028348182528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaZCPmxUMAAXYJ9.jpg",
        "sizes" : [ {
          "h" : 407,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 855
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 855
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QSewGlVt2K"
      } ],
      "hashtags" : [ {
        "text" : "DubNation",
        "indices" : [ 18, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695316032815149058",
    "text" : "Special delivery. #DubNation https:\/\/t.co\/QSewGlVt2K",
    "id" : 695316032815149058,
    "created_at" : "2016-02-04 18:40:35 +0000",
    "user" : {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "protected" : false,
      "id_str" : "26270913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798024560595464193\/Z0hZzS6P_normal.jpg",
      "id" : 26270913,
      "verified" : true
    }
  },
  "id" : 695326002214522880,
  "created_at" : "2016-02-04 19:20:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 29, 33 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 99, 108 ],
      "id_str" : "26270913",
      "id" : 26270913
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 54, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/2BRd5jodtc",
      "expanded_url" : "http:\/\/Serve.gov\/mentor",
      "display_url" : "Serve.gov\/mentor"
    } ]
  },
  "geo" : { },
  "id_str" : "695324202237304832",
  "text" : "\"They\u2019ve led the way for the @NBA\u2019s commitment to our #MyBrothersKeeper initiative\" \u2014@POTUS on the @Warriors: https:\/\/t.co\/2BRd5jodtc",
  "id" : 695324202237304832,
  "created_at" : "2016-02-04 19:13:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 20, 24 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 47, 56 ],
      "id_str" : "26270913",
      "id" : 26270913
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695321691245928448\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/aHru5w5wzi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaZHUxlWQAAfpMY.jpg",
      "id_str" : "695321614708260864",
      "id" : 695321614708260864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaZHUxlWQAAfpMY.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 864
      } ],
      "display_url" : "pic.twitter.com\/aHru5w5wzi"
    } ],
    "hashtags" : [ {
      "text" : "DubNation",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/S3Wjsk6KnA",
      "expanded_url" : "http:\/\/go.wh.gov\/DPkNP1",
      "display_url" : "go.wh.gov\/DPkNP1"
    } ]
  },
  "geo" : { },
  "id_str" : "695321691245928448",
  "text" : "\"Give it up for the @NBA Champion Golden State @Warriors!\" \u2014@POTUS: https:\/\/t.co\/S3Wjsk6KnA #DubNation https:\/\/t.co\/aHru5w5wzi",
  "id" : 695321691245928448,
  "created_at" : "2016-02-04 19:03:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 30, 34 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 57, 66 ],
      "id_str" : "26270913",
      "id" : 26270913
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DubNation",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/S3Wjsk6KnA",
      "expanded_url" : "http:\/\/go.wh.gov\/DPkNP1",
      "display_url" : "go.wh.gov\/DPkNP1"
    } ]
  },
  "geo" : { },
  "id_str" : "695321506243543041",
  "text" : "Watch live: @POTUS honors the @NBA Champion Golden State @Warriors \u2192 https:\/\/t.co\/S3Wjsk6KnA #DubNation",
  "id" : 695321506243543041,
  "created_at" : "2016-02-04 19:02:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBA Cares",
      "screen_name" : "nbacares",
      "indices" : [ 3, 12 ],
      "id_str" : "126383762",
      "id" : 126383762
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 72, 81 ],
      "id_str" : "26270913",
      "id" : 26270913
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nbacares\/status\/695307476950982657\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/v77kgJgMhN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY6daTUMAAR6Gd.jpg",
      "id_str" : "695307469426274304",
      "id" : 695307469426274304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY6daTUMAAR6Gd.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/v77kgJgMhN"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/nbacares\/status\/695307476950982657\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/v77kgJgMhN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY6daUUsAAfnuG.jpg",
      "id_str" : "695307469430501376",
      "id" : 695307469430501376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY6daUUsAAfnuG.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/v77kgJgMhN"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/nbacares\/status\/695307476950982657\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/v77kgJgMhN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY6dagUMAAWP6c.jpg",
      "id_str" : "695307469480800256",
      "id" : 695307469480800256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY6dagUMAAWP6c.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/v77kgJgMhN"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/nbacares\/status\/695307476950982657\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/v77kgJgMhN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY6dalUEAAnIJJ.jpg",
      "id_str" : "695307469501763584",
      "id" : 695307469501763584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY6dalUEAAnIJJ.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/v77kgJgMhN"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 83, 100 ]
    }, {
      "text" : "MentorIRL",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695319481820774405",
  "text" : "RT @nbacares: Students from The @WhiteHouse Mentorship Program meet the @warriors! #MyBrothersKeeper #MentorIRL https:\/\/t.co\/v77kgJgMhN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 18, 29 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "GoldenStateWarriors",
        "screen_name" : "warriors",
        "indices" : [ 58, 67 ],
        "id_str" : "26270913",
        "id" : 26270913
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nbacares\/status\/695307476950982657\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/v77kgJgMhN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY6daTUMAAR6Gd.jpg",
        "id_str" : "695307469426274304",
        "id" : 695307469426274304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY6daTUMAAR6Gd.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/v77kgJgMhN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/nbacares\/status\/695307476950982657\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/v77kgJgMhN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY6daUUsAAfnuG.jpg",
        "id_str" : "695307469430501376",
        "id" : 695307469430501376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY6daUUsAAfnuG.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/v77kgJgMhN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/nbacares\/status\/695307476950982657\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/v77kgJgMhN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY6dagUMAAWP6c.jpg",
        "id_str" : "695307469480800256",
        "id" : 695307469480800256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY6dagUMAAWP6c.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/v77kgJgMhN"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/nbacares\/status\/695307476950982657\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/v77kgJgMhN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaY6dalUEAAnIJJ.jpg",
        "id_str" : "695307469501763584",
        "id" : 695307469501763584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaY6dalUEAAnIJJ.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/v77kgJgMhN"
      } ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 69, 86 ]
      }, {
        "text" : "MentorIRL",
        "indices" : [ 87, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695307476950982657",
    "text" : "Students from The @WhiteHouse Mentorship Program meet the @warriors! #MyBrothersKeeper #MentorIRL https:\/\/t.co\/v77kgJgMhN",
    "id" : 695307476950982657,
    "created_at" : "2016-02-04 18:06:35 +0000",
    "user" : {
      "name" : "NBA Cares",
      "screen_name" : "nbacares",
      "protected" : false,
      "id_str" : "126383762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797966878299848706\/zm2CkVtT_normal.jpg",
      "id" : 126383762,
      "verified" : true
    }
  },
  "id" : 695319481820774405,
  "created_at" : "2016-02-04 18:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    }, {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "indices" : [ 45, 55 ],
      "id_str" : "4796005523",
      "id" : 4796005523
    }, {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "indices" : [ 57, 65 ],
      "id_str" : "3274836392",
      "id" : 3274836392
    }, {
      "name" : "BusinessForward",
      "screen_name" : "BusinessForward",
      "indices" : [ 73, 89 ],
      "id_str" : "72732934",
      "id" : 72732934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 35, 39 ]
    }, {
      "text" : "MadeInAmerica",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695314485142233088",
  "text" : "RT @PennyPritzker: Questions about #TPP? Ask @Charlie44, @Diana44, &amp; @BusinessForward by 1:30pm ET today w\/ #MadeInAmerica https:\/\/t.co\/X5D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie Anderson",
        "screen_name" : "Charlie44",
        "indices" : [ 26, 36 ],
        "id_str" : "4796005523",
        "id" : 4796005523
      }, {
        "name" : "Diana Doukas",
        "screen_name" : "Diana44",
        "indices" : [ 38, 46 ],
        "id_str" : "3274836392",
        "id" : 3274836392
      }, {
        "name" : "BusinessForward",
        "screen_name" : "BusinessForward",
        "indices" : [ 54, 70 ],
        "id_str" : "72732934",
        "id" : 72732934
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PennyPritzker\/status\/695306016448073728\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/X5DWeGijSZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaYaSD4WQAUm9cM.jpg",
        "id_str" : "695272090056933381",
        "id" : 695272090056933381,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaYaSD4WQAUm9cM.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/X5DWeGijSZ"
      } ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 16, 20 ]
      }, {
        "text" : "MadeInAmerica",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695306016448073728",
    "text" : "Questions about #TPP? Ask @Charlie44, @Diana44, &amp; @BusinessForward by 1:30pm ET today w\/ #MadeInAmerica https:\/\/t.co\/X5DWeGijSZ",
    "id" : 695306016448073728,
    "created_at" : "2016-02-04 18:00:47 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 695314485142233088,
  "created_at" : "2016-02-04 18:34:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695298826832211970\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/aCWQPKqgdP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaYyZhvW0AAhH5A.jpg",
      "id_str" : "695298606610436096",
      "id" : 695298606610436096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaYyZhvW0AAhH5A.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/aCWQPKqgdP"
    } ],
    "hashtags" : [ {
      "text" : "FirstJob",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Mzut4bzt8X",
      "expanded_url" : "http:\/\/go.wh.gov\/FirstJob",
      "display_url" : "go.wh.gov\/FirstJob"
    } ]
  },
  "geo" : { },
  "id_str" : "695298826832211970",
  "text" : "Here\u2019s how @POTUS is helping to connect more young people with their #FirstJob: https:\/\/t.co\/Mzut4bzt8X https:\/\/t.co\/aCWQPKqgdP",
  "id" : 695298826832211970,
  "created_at" : "2016-02-04 17:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 11, 20 ],
      "id_str" : "2425151",
      "id" : 2425151
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 22, 25 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695295046677999616\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/ePd1zE6ccM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaYu-VnWYAAW3cG.jpg",
      "id_str" : "695294840964276224",
      "id" : 695294840964276224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaYu-VnWYAAW3cG.jpg",
      "sizes" : [ {
        "h" : 718,
        "resize" : "fit",
        "w" : 755
      }, {
        "h" : 571,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 323,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 755
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ePd1zE6ccM"
    } ],
    "hashtags" : [ {
      "text" : "FriendsDay",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https:\/\/t.co\/7z0J0oAR0k",
      "expanded_url" : "http:\/\/Facebook.com\/VicePresidentBiden",
      "display_url" : "Facebook.com\/VicePresidentB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "695295046677999616",
  "text" : "Welcome to @Facebook, @VP! https:\/\/t.co\/7z0J0oAR0k #FriendsDay https:\/\/t.co\/ePd1zE6ccM",
  "id" : 695295046677999616,
  "created_at" : "2016-02-04 17:17:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldCancerDay",
      "indices" : [ 16, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695292351976177666",
  "text" : "RT @VP: To mark #WorldCancerDay, I'll be taking your questions on my brand-new Facebook page at 3 p.m. ET. Talk to you soon: https:\/\/t.co\/b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldCancerDay",
        "indices" : [ 8, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/bQr1W51viv",
        "expanded_url" : "http:\/\/Facebook.com\/VicePresidentBiden",
        "display_url" : "Facebook.com\/VicePresidentB\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "695291099695304704",
    "text" : "To mark #WorldCancerDay, I'll be taking your questions on my brand-new Facebook page at 3 p.m. ET. Talk to you soon: https:\/\/t.co\/bQr1W51viv",
    "id" : 695291099695304704,
    "created_at" : "2016-02-04 17:01:30 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 695292351976177666,
  "created_at" : "2016-02-04 17:06:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPrayerBreakfast",
      "indices" : [ 76, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/TcZ10Y1ucL",
      "expanded_url" : "http:\/\/snpy.tv\/1SvhWQn",
      "display_url" : "snpy.tv\/1SvhWQn"
    } ]
  },
  "geo" : { },
  "id_str" : "695286211515121665",
  "text" : "\"Our children grow up too fast.\" \u2014@POTUS reflecting on his daughters at the #NationalPrayerBreakfast https:\/\/t.co\/TcZ10Y1ucL",
  "id" : 695286211515121665,
  "created_at" : "2016-02-04 16:42:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPrayerBreakfast",
      "indices" : [ 113, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695259021633200128",
  "text" : "\"I pray that we will uphold our obligation to be good stewards of God\u2019s creation\u2014this beautiful planet.\" \u2014@POTUS #NationalPrayerBreakfast",
  "id" : 695259021633200128,
  "created_at" : "2016-02-04 14:54:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPrayerBreakfast",
      "indices" : [ 95, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695258659706662913",
  "text" : "\u201CGod has not given us a spirit of fear, but of power and of love and of a sound mind.\u201D \u2014@POTUS #NationalPrayerBreakfast",
  "id" : 695258659706662913,
  "created_at" : "2016-02-04 14:52:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPrayerBreakfast",
      "indices" : [ 104, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695256869884026887",
  "text" : "\"This is what each of us is called on to do, to seek our common humanity in each other.\" \u2014@POTUS at the #NationalPrayerBreakfast",
  "id" : 695256869884026887,
  "created_at" : "2016-02-04 14:45:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPrayerBreakfast",
      "indices" : [ 116, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695255757827117057",
  "text" : "\u201CI\u2019ve drawn strength from witnessing...good people of all faiths who do the Lord\u2019s work each and every day\" \u2014@POTUS #NationalPrayerBreakfast",
  "id" : 695255757827117057,
  "created_at" : "2016-02-04 14:41:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPrayerBreakfast",
      "indices" : [ 100, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695254222611218432",
  "text" : "RT @WHLive: \"For me, and perhaps for many of you, faith is the great cure for fear.\" \u2014@POTUS at the #NationalPrayerBreakfast",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 74, 80 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationalPrayerBreakfast",
        "indices" : [ 88, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "695253909737066496",
    "text" : "\"For me, and perhaps for many of you, faith is the great cure for fear.\" \u2014@POTUS at the #NationalPrayerBreakfast",
    "id" : 695253909737066496,
    "created_at" : "2016-02-04 14:33:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 695254222611218432,
  "created_at" : "2016-02-04 14:34:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrayerBreakfast",
      "indices" : [ 48, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/UVn9aixnDd",
      "expanded_url" : "http:\/\/go.wh.gov\/PrayerBreakfast",
      "display_url" : "go.wh.gov\/PrayerBreakfast"
    } ]
  },
  "geo" : { },
  "id_str" : "695230196362919938",
  "text" : "Tune in as @POTUS gives remarks at the National #PrayerBreakfast: https:\/\/t.co\/UVn9aixnDd",
  "id" : 695230196362919938,
  "created_at" : "2016-02-04 12:59:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695072837258891265\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/6GCV0OEjSI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaVkddeUcAAZIFK.jpg",
      "id_str" : "695072174789390336",
      "id" : 695072174789390336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaVkddeUcAAZIFK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6GCV0OEjSI"
    } ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/B1FaqLllBq",
      "expanded_url" : "http:\/\/go.wh.gov\/MosqueVisit",
      "display_url" : "go.wh.gov\/MosqueVisit"
    } ]
  },
  "geo" : { },
  "id_str" : "695072837258891265",
  "text" : "We are one American family. https:\/\/t.co\/B1FaqLllBq #MosqueVisit https:\/\/t.co\/6GCV0OEjSI",
  "id" : 695072837258891265,
  "created_at" : "2016-02-04 02:34:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/695056766803968003\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/qwIRejOijl",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CaVSDPGW4AASGC2.png",
      "id_str" : "695051933044891648",
      "id" : 695051933044891648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CaVSDPGW4AASGC2.png",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qwIRejOijl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/B1FaqL3KcQ",
      "expanded_url" : "http:\/\/go.wh.gov\/MosqueVisit",
      "display_url" : "go.wh.gov\/MosqueVisit"
    } ]
  },
  "geo" : { },
  "id_str" : "695056766803968003",
  "text" : "To young Muslim Americans: \nYou fit in. \nRight here. \nYou're part of America, too.\nhttps:\/\/t.co\/B1FaqL3KcQ https:\/\/t.co\/qwIRejOijl",
  "id" : 695056766803968003,
  "created_at" : "2016-02-04 01:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/695046118300741632\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/JS1MrRC7o5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaVMmk0WwAANOV_.jpg",
      "id_str" : "695045943100620800",
      "id" : 695045943100620800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaVMmk0WwAANOV_.jpg",
      "sizes" : [ {
        "h" : 527,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 363,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JS1MrRC7o5"
    } ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ZjEZA7CzS6",
      "expanded_url" : "http:\/\/on.fb.me\/1PBamRF",
      "display_url" : "on.fb.me\/1PBamRF"
    } ]
  },
  "geo" : { },
  "id_str" : "695046118300741632",
  "text" : "\"We are all God's children, all born equal with inherent dignity.\" \u2014@POTUS: https:\/\/t.co\/ZjEZA7CzS6 #MosqueVisit https:\/\/t.co\/JS1MrRC7o5",
  "id" : 695046118300741632,
  "created_at" : "2016-02-04 00:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/695027767616753666\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/QvRZr0snyn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaU8BINW0AAK_kd.jpg",
      "id_str" : "695027707579650048",
      "id" : 695027707579650048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaU8BINW0AAK_kd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QvRZr0snyn"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695027767616753666",
  "text" : ".@POTUS on the signing of the Trans-Pacific Partnership\u2014a trade deal that puts American workers 1st. #MadeInAmerica https:\/\/t.co\/QvRZr0snyn",
  "id" : 695027767616753666,
  "created_at" : "2016-02-03 23:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "695023266386309123",
  "text" : "RT @Denis44: These Muslim Americans are standing up for the future they believe in. So proud to work alongside them. https:\/\/t.co\/3JVoQjb6O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MosqueVisit",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/3JVoQjb6Or",
        "expanded_url" : "http:\/\/go.wh.gov\/tRjMKA",
        "display_url" : "go.wh.gov\/tRjMKA"
      } ]
    },
    "geo" : { },
    "id_str" : "695020960232005632",
    "text" : "These Muslim Americans are standing up for the future they believe in. So proud to work alongside them. https:\/\/t.co\/3JVoQjb6Or #MosqueVisit",
    "id" : 695020960232005632,
    "created_at" : "2016-02-03 23:08:04 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 695023266386309123,
  "created_at" : "2016-02-03 23:17:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/DTUoO3XW9b",
      "expanded_url" : "http:\/\/snpy.tv\/1UKLS8L",
      "display_url" : "snpy.tv\/1UKLS8L"
    } ]
  },
  "geo" : { },
  "id_str" : "695021780692529152",
  "text" : "\"Let's start with this fact\u2014for more than 1,000 years, people have been drawn to Islam's message of peace.\" \u2014@POTUS https:\/\/t.co\/DTUoO3XW9b",
  "id" : 695021780692529152,
  "created_at" : "2016-02-03 23:11:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Fiber",
      "screen_name" : "googlefiber",
      "indices" : [ 3, 15 ],
      "id_str" : "300378623",
      "id" : 300378623
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectHome",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/gwBZAc7hrC",
      "expanded_url" : "http:\/\/googlefiberblog.blogspot.com\/2016\/02\/connecthome-gigabit.html",
      "display_url" : "googlefiberblog.blogspot.com\/2016\/02\/connec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694994770670780416",
  "text" : "RT @googlefiber: Proud to bring $0\/mo Gigabit Internet to select public housing in Fiber cities. #ConnectHome https:\/\/t.co\/gwBZAc7hrC https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/googlefiber\/status\/694918212371111936\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/N4XTa6EPn8",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CaTYaSrUsAAHkmE.png",
        "id_str" : "694918188723646464",
        "id" : 694918188723646464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CaTYaSrUsAAHkmE.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/N4XTa6EPn8"
      } ],
      "hashtags" : [ {
        "text" : "ConnectHome",
        "indices" : [ 80, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/gwBZAc7hrC",
        "expanded_url" : "http:\/\/googlefiberblog.blogspot.com\/2016\/02\/connecthome-gigabit.html",
        "display_url" : "googlefiberblog.blogspot.com\/2016\/02\/connec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694918212371111936",
    "text" : "Proud to bring $0\/mo Gigabit Internet to select public housing in Fiber cities. #ConnectHome https:\/\/t.co\/gwBZAc7hrC https:\/\/t.co\/N4XTa6EPn8",
    "id" : 694918212371111936,
    "created_at" : "2016-02-03 16:19:47 +0000",
    "user" : {
      "name" : "Google Fiber",
      "screen_name" : "googlefiber",
      "protected" : false,
      "id_str" : "300378623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661300118331613184\/zxDVfWMJ_normal.png",
      "id" : 300378623,
      "verified" : true
    }
  },
  "id" : 694994770670780416,
  "created_at" : "2016-02-03 21:24:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/GPElXfPXBi",
      "expanded_url" : "http:\/\/snpy.tv\/1SHlVrf",
      "display_url" : "snpy.tv\/1SHlVrf"
    } ]
  },
  "geo" : { },
  "id_str" : "694989110486896640",
  "text" : "\"We are one American family.\nWe rise &amp; fall together.\"\n\nWatch @POTUS speak during his first #MosqueVisit in the U.S. https:\/\/t.co\/GPElXfPXBi",
  "id" : 694989110486896640,
  "created_at" : "2016-02-03 21:01:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/AWDJ9KkZom",
      "expanded_url" : "http:\/\/snpy.tv\/209utYP",
      "display_url" : "snpy.tv\/209utYP"
    } ]
  },
  "geo" : { },
  "id_str" : "694981326638833664",
  "text" : "\"Generations of Muslim Americans have helped to build our nation.\" \u2014@POTUS #MosqueVisit https:\/\/t.co\/AWDJ9KkZom",
  "id" : 694981326638833664,
  "created_at" : "2016-02-03 20:30:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/GnEH7Xf8S1",
      "expanded_url" : "http:\/\/snpy.tv\/1StqHuc",
      "display_url" : "snpy.tv\/1StqHuc"
    } ]
  },
  "geo" : { },
  "id_str" : "694966884777619457",
  "text" : "\"You are not Muslim or American.\nYou are Muslim AND American.\"\n\u2014@POTUS to young Muslim Americans #MosqueVisit https:\/\/t.co\/GnEH7Xf8S1",
  "id" : 694966884777619457,
  "created_at" : "2016-02-03 19:33:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/eTerGn8A42",
      "expanded_url" : "http:\/\/snpy.tv\/20qIA1f",
      "display_url" : "snpy.tv\/20qIA1f"
    } ]
  },
  "geo" : { },
  "id_str" : "694962624929361920",
  "text" : "\"I'm just as American and have the obligation to fulfill my loyalty to my country as any other.\" \u2014Sabah #MosqueVisit https:\/\/t.co\/eTerGn8A42",
  "id" : 694962624929361920,
  "created_at" : "2016-02-03 19:16:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/lPWjfdzfn5",
      "expanded_url" : "http:\/\/snpy.tv\/20qN6wB",
      "display_url" : "snpy.tv\/20qN6wB"
    } ]
  },
  "geo" : { },
  "id_str" : "694959825814315015",
  "text" : "\"An attack on one faith is an attack on all our faiths.\" \u2014@POTUS #MosqueVisit https:\/\/t.co\/lPWjfdzfn5",
  "id" : 694959825814315015,
  "created_at" : "2016-02-03 19:05:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/D7LtPYgf7D",
      "expanded_url" : "http:\/\/snpy.tv\/1SHdtZl",
      "display_url" : "snpy.tv\/1SHdtZl"
    } ]
  },
  "geo" : { },
  "id_str" : "694956593851584513",
  "text" : "\"Muslim Americans enrich our lives\u2014they're our neighbors\u2014the teachers who inspire our children\" \u2014@POTUS #MosqueVisit https:\/\/t.co\/D7LtPYgf7D",
  "id" : 694956593851584513,
  "created_at" : "2016-02-03 18:52:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694955276986875905",
  "text" : "\"We are one American family. We will rise and fall together.\" \u2014@POTUS during his first visit to a mosque in America #MosqueVisit",
  "id" : 694955276986875905,
  "created_at" : "2016-02-03 18:47:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694954744125788161",
  "text" : "\"As we go forward, I want every Muslim American to remember that\u2026your fellow Americans stand with you.\" \u2014@POTUS #MosqueVisit",
  "id" : 694954744125788161,
  "created_at" : "2016-02-03 18:44:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694954233544708096",
  "text" : "\"You are not Muslim or American. You are Muslim AND American.\" \u2014@POTUS to young Muslim Americans #MosqueVisit",
  "id" : 694954233544708096,
  "created_at" : "2016-02-03 18:42:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694953806359040000",
  "text" : "\"We can\u2019t give in to profiling entire groups of people because there is no single profile of a terrorist.\" \u2014@POTUS #MosqueVisit",
  "id" : 694953806359040000,
  "created_at" : "2016-02-03 18:41:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694953601207263232",
  "text" : "\"Engagement with Muslim Americans communities must never be a cover for surveillance.\" \u2014@POTUS #MosqueVisit",
  "id" : 694953601207263232,
  "created_at" : "2016-02-03 18:40:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694953406369259520",
  "text" : "\"As Muslim communities stand up for the future you believe in...America will be your partner.\" \u2014@POTUS at his first #MosqueVisit in the U.S.",
  "id" : 694953406369259520,
  "created_at" : "2016-02-03 18:39:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694951441576894465",
  "text" : "RT @NSC44: \u201CGroups like ISIL are desperate for legitimacy\u2026We must never give them that legitimacy\u201D-@POTUS. Learn more at: https:\/\/t.co\/26Jp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 88, 94 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/26JpsJJxmY",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/isil-strategy",
        "display_url" : "whitehouse.gov\/isil-strategy"
      } ]
    },
    "geo" : { },
    "id_str" : "694951118497931265",
    "text" : "\u201CGroups like ISIL are desperate for legitimacy\u2026We must never give them that legitimacy\u201D-@POTUS. Learn more at: https:\/\/t.co\/26JpsJJxmY",
    "id" : 694951118497931265,
    "created_at" : "2016-02-03 18:30:32 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 694951441576894465,
  "created_at" : "2016-02-03 18:31:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694951115339743232",
  "text" : "\u201CAs we protect our country from terrorism, we should not reinforce the ideas and the rhetoric of terrorists themselves\u201D \u2014@POTUS #MosqueVisit",
  "id" : 694951115339743232,
  "created_at" : "2016-02-03 18:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694950941276180480",
  "text" : "\u201CWe can\u2019t be bystanders to bigotry. Together, we have to show that America truly protects all faiths.\u201D \u2014@POTUS #MosqueVisit",
  "id" : 694950941276180480,
  "created_at" : "2016-02-03 18:29:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694950594595983360",
  "text" : "\"We need to make sure hate crimes are punished and the civil rights of all Americans are upheld.\" \u2014@POTUS #MosqueVisit",
  "id" : 694950594595983360,
  "created_at" : "2016-02-03 18:28:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694950532641902592",
  "text" : "\"An attack on one faith is an attack on all our faiths.\" \u2014@POTUS during his first #MosqueVisit in the U.S.",
  "id" : 694950532641902592,
  "created_at" : "2016-02-03 18:28:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694949838719434752",
  "text" : "\"As Americans, we have to stay true to our core values, that includes freedom of religion\u2014for all faiths.\" \u2014@POTUS #MosqueVisit",
  "id" : 694949838719434752,
  "created_at" : "2016-02-03 18:25:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694949525920837633",
  "text" : "\"Mere tolerance of different religions is not enough. Our faiths summon us to embrace our common humanity.\" \u2014@POTUS #MosqueVisit",
  "id" : 694949525920837633,
  "created_at" : "2016-02-03 18:24:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694949419624566784",
  "text" : "\"We have to reaffirm that most fundamental of truths\u2014we are all God\u2019s children, all born equal with inherent dignity.\" \u2014@POTUS #MosqueVisit",
  "id" : 694949419624566784,
  "created_at" : "2016-02-03 18:23:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694948338362294272",
  "text" : "\"Muslim Americans are some of the most resilient and patriotic Americans you\u2019ll ever meet.\" \u2014@POTUS during a #MosqueVisit in Baltimore",
  "id" : 694948338362294272,
  "created_at" : "2016-02-03 18:19:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694946679972167680",
  "text" : "\"When any part of our family starts to feel separate, or second-class, or targeted, it tears at the very fabric of our nation.\" \u2014@POTUS",
  "id" : 694946679972167680,
  "created_at" : "2016-02-03 18:12:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694946000620777472",
  "text" : "RT @WHLive: \"Recently, we\u2019ve heard inexcusable political rhetoric against Muslim Americans that has no place in our country.\"  \u2014@POTUS #Mos\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 116, 122 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MosqueVisit",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694945907142316033",
    "text" : "\"Recently, we\u2019ve heard inexcusable political rhetoric against Muslim Americans that has no place in our country.\"  \u2014@POTUS #MosqueVisit",
    "id" : 694945907142316033,
    "created_at" : "2016-02-03 18:09:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 694946000620777472,
  "created_at" : "2016-02-03 18:10:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/B1FaqL3KcQ",
      "expanded_url" : "http:\/\/go.wh.gov\/MosqueVisit",
      "display_url" : "go.wh.gov\/MosqueVisit"
    } ]
  },
  "geo" : { },
  "id_str" : "694944515711348737",
  "text" : "Tune in now as @POTUS delivers remarks during his first visit to a mosque in America: https:\/\/t.co\/B1FaqL3KcQ #MosqueVisit",
  "id" : 694944515711348737,
  "created_at" : "2016-02-03 18:04:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. David Edelman",
      "screen_name" : "rD44",
      "indices" : [ 3, 8 ],
      "id_str" : "4073671214",
      "id" : 4073671214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrivacyShield",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694939680601542657",
  "text" : "RT @rD44: Have Qs about the new US-EU Data Privacy deal? I'll be answering them at #PrivacyShield, today starting @ 4:30pm ET. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rD44\/status\/694937131123212288\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/qud1KO3Tqu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTpoNFWwAAjike.jpg",
        "id_str" : "694937119438061568",
        "id" : 694937119438061568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTpoNFWwAAjike.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/qud1KO3Tqu"
      } ],
      "hashtags" : [ {
        "text" : "PrivacyShield",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694937131123212288",
    "text" : "Have Qs about the new US-EU Data Privacy deal? I'll be answering them at #PrivacyShield, today starting @ 4:30pm ET. https:\/\/t.co\/qud1KO3Tqu",
    "id" : 694937131123212288,
    "created_at" : "2016-02-03 17:34:58 +0000",
    "user" : {
      "name" : "R. David Edelman",
      "screen_name" : "rD44",
      "protected" : false,
      "id_str" : "4073671214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664566060801216513\/-QEofkKM_normal.jpg",
      "id" : 4073671214,
      "verified" : true
    }
  },
  "id" : 694939680601542657,
  "created_at" : "2016-02-03 17:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/694918798164365312\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/vfyU5KKUoR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTYy4OWYAESdJy.jpg",
      "id_str" : "694918611119529985",
      "id" : 694918611119529985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTYy4OWYAESdJy.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vfyU5KKUoR"
    } ],
    "hashtags" : [ {
      "text" : "MosqueVisit",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/B1FaqL3KcQ",
      "expanded_url" : "http:\/\/go.wh.gov\/MosqueVisit",
      "display_url" : "go.wh.gov\/MosqueVisit"
    } ]
  },
  "geo" : { },
  "id_str" : "694918798164365312",
  "text" : "Today, @POTUS makes his first visit to a mosque in America.\nWatch at 12pm ET \u2192 https:\/\/t.co\/B1FaqL3KcQ #MosqueVisit https:\/\/t.co\/vfyU5KKUoR",
  "id" : 694918798164365312,
  "created_at" : "2016-02-03 16:22:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694914367826038784",
  "text" : "RT @Denis44: The Privacy Shield agreement w the EU creates new consumer privacy protections &amp; provides certainty for businesses https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/694911207912796160\/photo\/1",
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/guhUIxjzKs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaTSD5gUkAAccro.jpg",
        "id_str" : "694911206939725824",
        "id" : 694911206939725824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaTSD5gUkAAccro.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/guhUIxjzKs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694911207912796160",
    "text" : "The Privacy Shield agreement w the EU creates new consumer privacy protections &amp; provides certainty for businesses https:\/\/t.co\/guhUIxjzKs",
    "id" : 694911207912796160,
    "created_at" : "2016-02-03 15:51:57 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 694914367826038784,
  "created_at" : "2016-02-03 16:04:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 37, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694677767435206656",
  "text" : "RT @VP: A great first meeting of the #CancerMoonshot Task Force yesterday. Feeling energized and ready for the work ahead. https:\/\/t.co\/J0I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/694663734841597952\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/J0IvxFlSvZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaPw_FlUkAAqjL_.jpg",
        "id_str" : "694663734166327296",
        "id" : 694663734166327296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaPw_FlUkAAqjL_.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/J0IvxFlSvZ"
      } ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 29, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694663734841597952",
    "text" : "A great first meeting of the #CancerMoonshot Task Force yesterday. Feeling energized and ready for the work ahead. https:\/\/t.co\/J0IvxFlSvZ",
    "id" : 694663734841597952,
    "created_at" : "2016-02-02 23:28:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 694677767435206656,
  "created_at" : "2016-02-03 00:24:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NOAA NCEI Climate",
      "screen_name" : "NOAANCEIclimate",
      "indices" : [ 3, 19 ],
      "id_str" : "916735110",
      "id" : 916735110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GroundhogDay",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/j7ETFZzmt5",
      "expanded_url" : "http:\/\/1.usa.gov\/1zfGrqq",
      "display_url" : "1.usa.gov\/1zfGrqq"
    } ]
  },
  "geo" : { },
  "id_str" : "694665162419122176",
  "text" : "RT @NOAANCEIclimate: Happy #GroundhogDay! See how the furry forecasters stack up to climate records: https:\/\/t.co\/j7ETFZzmt5 https:\/\/t.co\/C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NOAANCEIclimate\/status\/694510617353404416\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/CXypXWC7u2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaNludkWYAEYQcm.jpg",
        "id_str" : "694510616430665729",
        "id" : 694510616430665729,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaNludkWYAEYQcm.jpg",
        "sizes" : [ {
          "h" : 429,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 2100
        } ],
        "display_url" : "pic.twitter.com\/CXypXWC7u2"
      } ],
      "hashtags" : [ {
        "text" : "GroundhogDay",
        "indices" : [ 6, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/j7ETFZzmt5",
        "expanded_url" : "http:\/\/1.usa.gov\/1zfGrqq",
        "display_url" : "1.usa.gov\/1zfGrqq"
      } ]
    },
    "geo" : { },
    "id_str" : "694510617353404416",
    "text" : "Happy #GroundhogDay! See how the furry forecasters stack up to climate records: https:\/\/t.co\/j7ETFZzmt5 https:\/\/t.co\/CXypXWC7u2",
    "id" : 694510617353404416,
    "created_at" : "2016-02-02 13:20:09 +0000",
    "user" : {
      "name" : "NOAA NCEI Climate",
      "screen_name" : "NOAANCEIclimate",
      "protected" : false,
      "id_str" : "916735110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590917629642084354\/NswGA2rK_normal.png",
      "id" : 916735110,
      "verified" : true
    }
  },
  "id" : 694665162419122176,
  "created_at" : "2016-02-02 23:34:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/694663745113579520\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/4x89Z36ywq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaPw93IW0AEoCRH.jpg",
      "id_str" : "694663713106874369",
      "id" : 694663713106874369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaPw93IW0AEoCRH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/4x89Z36ywq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/M2HgnDmceC",
      "expanded_url" : "http:\/\/go.wh.gov\/Opioids",
      "display_url" : "go.wh.gov\/Opioids"
    } ]
  },
  "geo" : { },
  "id_str" : "694663745113579520",
  "text" : ".@POTUS's budget will invest $1.1 billion to help address the opioid epidemic \u2192 https:\/\/t.co\/M2HgnDmceC https:\/\/t.co\/4x89Z36ywq",
  "id" : 694663745113579520,
  "created_at" : "2016-02-02 23:28:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 3, 16 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    }, {
      "name" : "Zachary Siegel",
      "screen_name" : "ZachWritesStuff",
      "indices" : [ 27, 43 ],
      "id_str" : "2227333411",
      "id" : 2227333411
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 45, 51 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694652533516713984",
  "text" : "RT @Botticelli44: Congrats @ZachWritesStuff! @POTUS says treatment should be available to everyone who needs it. It shouldn't be a matter o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zachary Siegel",
        "screen_name" : "ZachWritesStuff",
        "indices" : [ 9, 25 ],
        "id_str" : "2227333411",
        "id" : 2227333411
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 27, 33 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opioids",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694650568682426370",
    "text" : "Congrats @ZachWritesStuff! @POTUS says treatment should be available to everyone who needs it. It shouldn't be a matter of luck #opioids",
    "id" : 694650568682426370,
    "created_at" : "2016-02-02 22:36:16 +0000",
    "user" : {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "protected" : false,
      "id_str" : "2382297056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789238935159312385\/z7RppzRN_normal.jpg",
      "id" : 2382297056,
      "verified" : true
    }
  },
  "id" : 694652533516713984,
  "created_at" : "2016-02-02 22:44:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/faa7qTz4kE",
      "expanded_url" : "https:\/\/twitter.com\/SpeakerRyan\/status\/694602640097988608",
      "display_url" : "twitter.com\/SpeakerRyan\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694642559205916672",
  "text" : "RT @Denis44: Groundhog's Day is great for a movie plot, not a legislative strategy. https:\/\/t.co\/faa7qTz4kE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/faa7qTz4kE",
        "expanded_url" : "https:\/\/twitter.com\/SpeakerRyan\/status\/694602640097988608",
        "display_url" : "twitter.com\/SpeakerRyan\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "694636902868058112",
    "text" : "Groundhog's Day is great for a movie plot, not a legislative strategy. https:\/\/t.co\/faa7qTz4kE",
    "id" : 694636902868058112,
    "created_at" : "2016-02-02 21:41:58 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 694642559205916672,
  "created_at" : "2016-02-02 22:04:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/694619036332769280\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/EvkubrFqhD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaPIIDxWIAAIgTB.jpg",
      "id_str" : "694618808321974272",
      "id" : 694618808321974272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaPIIDxWIAAIgTB.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EvkubrFqhD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/GlurJLRADC",
      "expanded_url" : "http:\/\/read.bi\/1KV6IMT",
      "display_url" : "read.bi\/1KV6IMT"
    } ]
  },
  "geo" : { },
  "id_str" : "694619036332769280",
  "text" : "Good news: U.S. auto sales in January rose to the strongest rate since 2000 \u2192 https:\/\/t.co\/GlurJLRADC https:\/\/t.co\/EvkubrFqhD",
  "id" : 694619036332769280,
  "created_at" : "2016-02-02 20:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/694606073676840961\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/JvXeD9eTr0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaO8c4zWAAAJFaO.jpg",
      "id_str" : "694605972015284224",
      "id" : 694605972015284224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaO8c4zWAAAJFaO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/JvXeD9eTr0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/M2HgnDmceC",
      "expanded_url" : "http:\/\/go.wh.gov\/Opioids",
      "display_url" : "go.wh.gov\/Opioids"
    } ]
  },
  "geo" : { },
  "id_str" : "694606073676840961",
  "text" : "It's time to address the opioid epidemic.\nHere's how @POTUS is taking action \u2192 https:\/\/t.co\/M2HgnDmceC https:\/\/t.co\/JvXeD9eTr0",
  "id" : 694606073676840961,
  "created_at" : "2016-02-02 19:39:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/694593688219955201\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/u72wH23JR8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaOxIL0W0AgjQgB.jpg",
      "id_str" : "694593521714647048",
      "id" : 694593521714647048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaOxIL0W0AgjQgB.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/u72wH23JR8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/M2HgnDDN6a",
      "expanded_url" : "http:\/\/go.wh.gov\/Opioids",
      "display_url" : "go.wh.gov\/Opioids"
    } ]
  },
  "geo" : { },
  "id_str" : "694593688219955201",
  "text" : "FACT: More Americans die every day from drug overdoses than from car crashes \u2192 https:\/\/t.co\/M2HgnDDN6a https:\/\/t.co\/u72wH23JR8",
  "id" : 694593688219955201,
  "created_at" : "2016-02-02 18:50:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 3, 16 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Opioids",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694582075949735937",
  "text" : "RT @Botticelli44: I'm taking Qs on the new steps @POTUS is taking to help fight the opioid epidemic. Ask by 5:00pm ET using #Opioids.\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 31, 37 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Opioids",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/OrdPoK326m",
        "expanded_url" : "http:\/\/go.wh.gov\/Opioids",
        "display_url" : "go.wh.gov\/Opioids"
      } ]
    },
    "geo" : { },
    "id_str" : "694581101772312576",
    "text" : "I'm taking Qs on the new steps @POTUS is taking to help fight the opioid epidemic. Ask by 5:00pm ET using #Opioids.\nhttps:\/\/t.co\/OrdPoK326m",
    "id" : 694581101772312576,
    "created_at" : "2016-02-02 18:00:14 +0000",
    "user" : {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "protected" : false,
      "id_str" : "2382297056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789238935159312385\/z7RppzRN_normal.jpg",
      "id" : 2382297056,
      "verified" : true
    }
  },
  "id" : 694582075949735937,
  "created_at" : "2016-02-02 18:04:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/694570323556110336\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/5VLktUn623",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaOb8_BVIAAWOg7.jpg",
      "id_str" : "694570239556657152",
      "id" : 694570239556657152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaOb8_BVIAAWOg7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/5VLktUn623"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/M2HgnDmceC",
      "expanded_url" : "http:\/\/go.wh.gov\/Opioids",
      "display_url" : "go.wh.gov\/Opioids"
    } ]
  },
  "geo" : { },
  "id_str" : "694570323556110336",
  "text" : "Share the news: @POTUS is taking new steps to help fight the opioid epidemic \u2192 https:\/\/t.co\/M2HgnDmceC https:\/\/t.co\/5VLktUn623",
  "id" : 694570323556110336,
  "created_at" : "2016-02-02 17:17:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GroundhogDay",
      "indices" : [ 79, 92 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694545611987816449",
  "text" : "RT @USDOL: With the tipped min. wage stuck at $2.13\/hr since \u201891, every day is #GroundhogDay for tipped workers. #RaiseTheWage https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/694532131876388864\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/TDXHMp2RAr",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CaN5SzrXEAA-lYP.png",
        "id_str" : "694532131561869312",
        "id" : 694532131561869312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CaN5SzrXEAA-lYP.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 302
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 302
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 302
        }, {
          "h" : 166,
          "resize" : "fit",
          "w" : 302
        } ],
        "display_url" : "pic.twitter.com\/TDXHMp2RAr"
      } ],
      "hashtags" : [ {
        "text" : "GroundhogDay",
        "indices" : [ 68, 81 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694532131876388864",
    "text" : "With the tipped min. wage stuck at $2.13\/hr since \u201891, every day is #GroundhogDay for tipped workers. #RaiseTheWage https:\/\/t.co\/TDXHMp2RAr",
    "id" : 694532131876388864,
    "created_at" : "2016-02-02 14:45:38 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 694545611987816449,
  "created_at" : "2016-02-02 15:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "indices" : [ 3, 11 ],
      "id_str" : "4518870555",
      "id" : 4518870555
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/694539545941913602\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Ben00Qp58p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaOAAgjUEAAGFqL.png",
      "id_str" : "694539513771593728",
      "id" : 694539513771593728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaOAAgjUEAAGFqL.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 594,
        "resize" : "fit",
        "w" : 1189
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ben00Qp58p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694542079255547905",
  "text" : "RT @Price44: Statement by @POTUS on the FY2017 European Reassurance Initiative Budget Request https:\/\/t.co\/Ben00Qp58p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Price44\/status\/694539545941913602\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/Ben00Qp58p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaOAAgjUEAAGFqL.png",
        "id_str" : "694539513771593728",
        "id" : 694539513771593728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaOAAgjUEAAGFqL.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 594,
          "resize" : "fit",
          "w" : 1189
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ben00Qp58p"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694539545941913602",
    "text" : "Statement by @POTUS on the FY2017 European Reassurance Initiative Budget Request https:\/\/t.co\/Ben00Qp58p",
    "id" : 694539545941913602,
    "created_at" : "2016-02-02 15:15:06 +0000",
    "user" : {
      "name" : "Ned Price",
      "screen_name" : "Price44",
      "protected" : false,
      "id_str" : "4518870555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685537285509611520\/OlaZhXtR_normal.jpg",
      "id" : 4518870555,
      "verified" : true
    }
  },
  "id" : 694542079255547905,
  "created_at" : "2016-02-02 15:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smarter Every Day",
      "screen_name" : "smartereveryday",
      "indices" : [ 3, 19 ],
      "id_str" : "315465682",
      "id" : 315465682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/0PSzvbcvyM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=GpWQHFzrEqc",
      "display_url" : "youtube.com\/watch?v=GpWQHF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "694361133495508992",
  "text" : "RT @smartereveryday: NEW VIDEO! What I learned from President Obama - Smarter Every Day 151 https:\/\/t.co\/0PSzvbcvyM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/0PSzvbcvyM",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=GpWQHFzrEqc",
        "display_url" : "youtube.com\/watch?v=GpWQHF\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "693816068066902017",
    "text" : "NEW VIDEO! What I learned from President Obama - Smarter Every Day 151 https:\/\/t.co\/0PSzvbcvyM",
    "id" : 693816068066902017,
    "created_at" : "2016-01-31 15:20:15 +0000",
    "user" : {
      "name" : "Smarter Every Day",
      "screen_name" : "smartereveryday",
      "protected" : false,
      "id_str" : "315465682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667860897830957056\/oxhiruqu_normal.jpg",
      "id" : 315465682,
      "verified" : true
    }
  },
  "id" : 694361133495508992,
  "created_at" : "2016-02-02 03:26:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 18, 21 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/694319495133929472\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Actw4LrRKj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaK31_FWcAAEY3K.jpg",
      "id_str" : "694319430663303168",
      "id" : 694319430663303168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaK31_FWcAAEY3K.jpg",
      "sizes" : [ {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Actw4LrRKj"
    } ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 56, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/kz4xOQyrmW",
      "expanded_url" : "http:\/\/go.wh.gov\/CancerMoonshot",
      "display_url" : "go.wh.gov\/CancerMoonshot"
    } ]
  },
  "geo" : { },
  "id_str" : "694319495133929472",
  "text" : "Today, @POTUS and @VP convened the first meeting of the #CancerMoonshot Task Force: https:\/\/t.co\/kz4xOQyrmW https:\/\/t.co\/Actw4LrRKj",
  "id" : 694319495133929472,
  "created_at" : "2016-02-02 00:40:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 32, 35 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 44, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694307185321336832",
  "text" : "RT @SecBurwell: Excited to have @VP leading #CancerMoonshot effort. Improving treatments, outcomes for patients is at the center of this wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 16, 19 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 28, 43 ]
      }, {
        "text" : "impact",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "694306183717490691",
    "geo" : { },
    "id_str" : "694306571304570880",
    "in_reply_to_user_id" : 2458567464,
    "text" : "Excited to have @VP leading #CancerMoonshot effort. Improving treatments, outcomes for patients is at the center of this work. #impact",
    "id" : 694306571304570880,
    "in_reply_to_status_id" : 694306183717490691,
    "created_at" : "2016-02-01 23:49:20 +0000",
    "in_reply_to_screen_name" : "SecBurwell",
    "in_reply_to_user_id_str" : "2458567464",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 694307185321336832,
  "created_at" : "2016-02-01 23:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 28, 31 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694258411807096833",
  "text" : "RT @PressSec: .@POTUS &amp; @VP are in the first meeting of the task force to cure cancer. Here's why we call it the #CancerMoonshot https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 14, 17 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 103, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/q0ovlp5gue",
        "expanded_url" : "http:\/\/snpy.tv\/1SyipQ5",
        "display_url" : "snpy.tv\/1SyipQ5"
      } ]
    },
    "geo" : { },
    "id_str" : "694244341192101888",
    "text" : ".@POTUS &amp; @VP are in the first meeting of the task force to cure cancer. Here's why we call it the #CancerMoonshot https:\/\/t.co\/q0ovlp5gue",
    "id" : 694244341192101888,
    "created_at" : "2016-02-01 19:42:04 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 694258411807096833,
  "created_at" : "2016-02-01 20:37:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Francis S. Collins",
      "screen_name" : "NIHDirector",
      "indices" : [ 39, 51 ],
      "id_str" : "124237063",
      "id" : 124237063
    }, {
      "name" : "Dr. Doug Lowy",
      "screen_name" : "NCIDrDoug",
      "indices" : [ 56, 66 ],
      "id_str" : "3182854863",
      "id" : 3182854863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694253450398453766",
  "text" : "RT @VP: Once we're out of the meeting, @NIHDirector and @NCIDrDoug will take your questions right here. You can ask them using #CancerMoons\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Francis S. Collins",
        "screen_name" : "NIHDirector",
        "indices" : [ 31, 43 ],
        "id_str" : "124237063",
        "id" : 124237063
      }, {
        "name" : "Dr. Doug Lowy",
        "screen_name" : "NCIDrDoug",
        "indices" : [ 48, 58 ],
        "id_str" : "3182854863",
        "id" : 3182854863
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 119, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694238001778573313",
    "text" : "Once we're out of the meeting, @NIHDirector and @NCIDrDoug will take your questions right here. You can ask them using #CancerMoonshot.",
    "id" : 694238001778573313,
    "created_at" : "2016-02-01 19:16:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 694253450398453766,
  "created_at" : "2016-02-01 20:18:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/694233552397996032\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/DIMLShUbph",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaJpvKaWcAAEjQN.jpg",
      "id_str" : "694233551538122752",
      "id" : 694233551538122752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaJpvKaWcAAEjQN.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2560,
        "resize" : "fit",
        "w" : 3840
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DIMLShUbph"
    } ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 46, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694241353769754624",
  "text" : "RT @VP: Walking into the first meeting of the #CancerMoonshot Task Force shortly. Stay tuned, folks. https:\/\/t.co\/DIMLShUbph",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/694233552397996032\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/DIMLShUbph",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CaJpvKaWcAAEjQN.jpg",
        "id_str" : "694233551538122752",
        "id" : 694233551538122752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaJpvKaWcAAEjQN.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2560,
          "resize" : "fit",
          "w" : 3840
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DIMLShUbph"
      } ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 38, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694233552397996032",
    "text" : "Walking into the first meeting of the #CancerMoonshot Task Force shortly. Stay tuned, folks. https:\/\/t.co\/DIMLShUbph",
    "id" : 694233552397996032,
    "created_at" : "2016-02-01 18:59:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 694241353769754624,
  "created_at" : "2016-02-01 19:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/694238049715130369\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/tVFsGQ9PEl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaJnAElWEAA3_7O.jpg",
      "id_str" : "694230543496515584",
      "id" : 694230543496515584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaJnAElWEAA3_7O.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tVFsGQ9PEl"
    } ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 91, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694238049715130369",
  "text" : "Let's keep marching until no one is judged by anything but the content of their character. #BlackHistoryMonth https:\/\/t.co\/tVFsGQ9PEl",
  "id" : 694238049715130369,
  "created_at" : "2016-02-01 19:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694234345448574976",
  "text" : "RT @repjohnlewis: 56 yrs ago today, four N. Carolina A&amp;T freshmen sat-in at the Woolworth's lunch counter in Greensboro &amp; helped launch a n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "694210694040961024",
    "text" : "56 yrs ago today, four N. Carolina A&amp;T freshmen sat-in at the Woolworth's lunch counter in Greensboro &amp; helped launch a nonviolent movement.",
    "id" : 694210694040961024,
    "created_at" : "2016-02-01 17:28:21 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 694234345448574976,
  "created_at" : "2016-02-01 19:02:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 126, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/AuSvC1qtVU",
      "expanded_url" : "http:\/\/go.wh.gov\/8gGmxx",
      "display_url" : "go.wh.gov\/8gGmxx"
    } ]
  },
  "geo" : { },
  "id_str" : "694230353511370753",
  "text" : "\"Our responsibility as citizens is to address the inequalities &amp; injustices that linger\" \u2014@POTUS: https:\/\/t.co\/AuSvC1qtVU #BlackHistoryMonth",
  "id" : 694230353511370753,
  "created_at" : "2016-02-01 18:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/694226852265775104\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/sZo0tMhLg4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CaJjlYNWcAEEd1P.jpg",
      "id_str" : "694226786373234689",
      "id" : 694226786373234689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CaJjlYNWcAEEd1P.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/sZo0tMhLg4"
    } ],
    "hashtags" : [ {
      "text" : "CSforAll",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/cZciTWOCCX",
      "expanded_url" : "http:\/\/wh.gov\/CSforAll",
      "display_url" : "wh.gov\/CSforAll"
    } ]
  },
  "geo" : { },
  "id_str" : "694226852265775104",
  "text" : "Here's how @POTUS is expanding K-12 computer science education: https:\/\/t.co\/cZciTWOCCX #CSforAll https:\/\/t.co\/sZo0tMhLg4",
  "id" : 694226852265775104,
  "created_at" : "2016-02-01 18:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSforAll",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/iAxqqpavO7",
      "expanded_url" : "http:\/\/go.wh.gov\/vmLWhx",
      "display_url" : "go.wh.gov\/vmLWhx"
    } ]
  },
  "geo" : { },
  "id_str" : "694214850210316288",
  "text" : ".@POTUS's new plan will help ensure all of our students get an opportunity to learn computer science. #CSforAll https:\/\/t.co\/iAxqqpavO7",
  "id" : 694214850210316288,
  "created_at" : "2016-02-01 17:44:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]